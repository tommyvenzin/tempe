// 2.9.7 "Wholesale loop (dry run)" (Tommy, 14 Nov 2026): what the wholesale helper keeps on this PC between passes
// and days (WholesaleState: wholesale-state.json beside its other files), and the plan it works to (WholesalePlan,
// pure: the self-tests check it): 06:00-18:00 Sydney time; at most 100 orders a pass, staff's go requests first, then
// orders never looked at (oldest first), then the ones due another try; a reading problem tried again every 5 minutes
// for its first hour, then hourly; an order open on another PC after 2 minutes; waits of 1, 3, 5, then 10 s between
// refreshes once a pass has nothing to do, back to 1 s whenever an order is processed; the list read again every 3
// minutes during a long pass, so a new go doesn't wait for the whole pass. The dry run changes nothing, so it keeps
// which orders it has previewed today and what their list row said: an order isn't previewed again that day unless
// its row changes (someone adds go, edits the Comment...), so every pass gets further down the list.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace TempeCostar {
    // One order as the helper last saw it. Times: ms since 1970 (UTC). last: sell, flag, leave, skip, problem, locked.
    // day: the local day (yyyy-MM-dd) it was last looked at; sig: its list row then (WholesalePlan.Sig); why: what was
    // found, in words; problems: what couldn't be read (empty when nothing). review / items: the lines a [review] /
    // [items] approval (staff's go) was given for (WholesaleRules.Print), kept for later rechecks.
    public sealed class WholesaleMemo {
        public string doc="",sig="",last="",why="",day="",problems="";
        public long at,firstProblem,retryAt,approvedAt;
        public string review,items;
    }
    public sealed class WholesaleStateFile { public int schema=1;public List<WholesaleMemo> orders=new List<WholesaleMemo>(); }

    internal sealed class WholesaleState {
        readonly object gate=new object();readonly string file;
        readonly Dictionary<string,WholesaleMemo> orders=new Dictionary<string,WholesaleMemo>(StringComparer.Ordinal);
        // Records kept: 30 days since an order was last looked at; an approval 90 days.
        internal static readonly TimeSpan Keep=TimeSpan.FromDays(30),KeepApproval=TimeSpan.FromDays(90);
        internal WholesaleState(string folder) {
            file=folder==null?null:Path.Combine(folder,"wholesale-state.json");
            if(file==null||!File.Exists(file)) return;
            try {
                var read=Wire.Read<WholesaleStateFile>(File.ReadAllText(file,Encoding.UTF8));
                if(read!=null&&read.orders!=null) foreach(var m in read.orders) if(m!=null&&!String.IsNullOrEmpty(m.doc)) orders[m.doc]=m;
            } catch(Exception e) { AppLog.Note("wholesale_state_unreadable",e.GetType().Name); }
        }
        // A copy (the tab reads it while the loop writes).
        internal WholesaleMemo Get(string doc) { lock(gate) { WholesaleMemo m;return orders.TryGetValue(doc??"",out m)?Wire.Copy(m):null; } }
        internal void Put(WholesaleMemo m) { if(m==null||String.IsNullOrEmpty(m.doc)) return;lock(gate) orders[m.doc]=Wire.Copy(m); }
        internal WholesaleApproval Approval(string doc) {
            var m=Get(doc);
            return m==null||(m.review==null&&m.items==null)?null:new WholesaleApproval {Review=m.review,Items=m.items};
        }
        internal int Count { get { lock(gate) return orders.Count; } }
        // The orders with a reading problem or a lock still being followed (copies).
        internal List<WholesaleMemo> Open() { lock(gate) return orders.Values.Where(m=>m.last=="problem"||m.last=="locked").Select(m=>Wire.Copy(m)).ToList(); }
        // Saved at once (a temporary file, then put in place); records past their keeping time left out. Never throws.
        internal void Save() {
            if(file==null) return;
            try {
                var now=DateTime.UtcNow;var keep=new WholesaleStateFile();
                lock(gate) {
                    foreach(var m in orders.Values.ToList()) {
                        bool recent=now-WholesalePlan.FromMs(m.at)<Keep,approved=(m.review!=null||m.items!=null)&&now-WholesalePlan.FromMs(m.approvedAt)<KeepApproval;
                        if(recent||approved) keep.orders.Add(m);else orders.Remove(m.doc);
                    }
                }
                string temp=file+".tmp";
                File.WriteAllText(temp,Wire.Json(keep),new UTF8Encoding(false));
                if(File.Exists(file)) File.Replace(temp,file,null);else File.Move(temp,file);
            } catch(Exception e) { AppLog.Note("wholesale_state_not_saved",e.GetType().Name); }
        }
    }

    internal static class WholesalePlan {
        // Tommy, 14 Nov: "Plan for 06:00-18:00 Sydney time" (the PC's own clock), every day.
        internal const int OpenHour=6,CloseHour=18;
        internal static bool InHours(DateTime local) { return local.Hour>=OpenHour&&local.Hour<CloseHour; }
        internal static DateTime NextOpen(DateTime local) { var open=local.Date.AddHours(OpenHour);return local<open?open:open.AddDays(1); }
        // Tommy, 14 Nov: "Once there are no orders left to process, wait 1 second, refresh, then wait 3 seconds, then 5
        // seconds, then 10 seconds between further refreshes. Reset that sequence when an order is processed." step: -1
        // when the loop starts; after each pass Step; the wait before the next refresh WaitSeconds(step).
        internal static readonly int[] Waits={1,3,5,10};
        internal static int Step(int step,bool processed) { return processed?0:Math.Min(step+1,Waits.Length-1); }
        internal static int WaitSeconds(int step) { return Waits[Math.Max(0,Math.Min(step,Waits.Length-1))]; }
        // Processed (the waits start again): the helper changed the order, or, in the dry run, would have (Sell, then
        // Cancel; the Comment's tags). Skipped, locked and unreadable orders aren't (Tommy: "Simply encountering the same
        // skipped or locked order should not keep resetting it").
        internal static bool Processed(WholesaleLook l) { return l!=null&&!l.Locked&&l.Verdict!=null&&(l.Verdict.Action=="sell"||l.Verdict.Action=="flag"); }
        // Whether a look counts for the waits: processed, and in the dry run not what was found last time for the same
        // row (an order tried again for its reading problem would flag the same again: that isn't new). before / after:
        // what was kept before the look and after it.
        internal static bool Counts(WholesaleMemo before,WholesaleMemo after,WholesaleLook l,bool dryRun) {
            if(!Processed(l)) return false;
            if(!dryRun||before==null||after==null) return true;
            return !(before.sig==after.sig&&before.last==after.last&&before.why==after.why);
        }
        // The list read again during a long pass (between two orders): a new go goes to the front of what's left.
        internal static readonly TimeSpan RefreshEvery=TimeSpan.FromMinutes(3);
        // Tommy, 14 Nov: a locked order (open on another PC) tried again after 2 minutes; a reading problem after 5
        // minutes, hourly once it has lasted an hour (a new go brings it forward).
        internal static readonly TimeSpan LockedAgain=TimeSpan.FromMinutes(2),ProblemAgain=TimeSpan.FromMinutes(5),ProblemSlow=TimeSpan.FromHours(1),SlowAfter=TimeSpan.FromHours(1);
        internal static DateTime RetryAt(bool locked,DateTime firstProblemUtc,DateTime nowUtc) {
            if(locked) return nowUtc+LockedAgain;
            return nowUtc+(nowUtc-firstProblemUtc<SlowAfter?ProblemAgain:ProblemSlow);
        }
        static readonly DateTime Epoch=new DateTime(1970,1,1,0,0,0,DateTimeKind.Utc);
        internal static long ToMs(DateTime utc) { return (long)(utc-Epoch).TotalMilliseconds; }
        internal static DateTime FromMs(long ms) { return Epoch.AddMilliseconds(ms); }
        internal static string Clock(long ms) { return ms<=0?"":FromMs(ms).ToLocalTime().ToString("HH:mm",CultureInfo.InvariantCulture); }
        // An order's list row as the helper saw it (when it changes, the order is looked at as new): its Comment,
        // ShipDate and Ship Via.
        internal static string Sig(WholesaleRow r) { return Sig(r,r.Comment); }
        internal static string Sig(WholesaleRow r,string comment) { return WholesaleComment.Same(comment)+"|"+(r.ShipDate??"").Trim()+"|"+WholesaleRules.Words(r.ShipVia); }
        // A pass: every BUF order of the list read (rows), oldest first, each with why it isn't opened (Skip) or why it
        // is (Queue: "go", "new" or "retry"); at most `most` to open, staff's go requests first, then orders never looked
        // at (or whose row changed), then those due another try. memo: what the helper kept of each (null: nothing).
        // dryRun: an order previewed today whose row hasn't changed isn't previewed again until tomorrow.
        internal static List<WholesaleLook> Queue(IList<WholesaleRow> rows,Func<string,WholesaleMemo> memo,string today,DateTime nowUtc,bool dryRun,int most) {
            var go=new List<WholesaleLook>();var fresh=new List<WholesaleLook>();var again=new List<WholesaleLook>();var skipped=new List<WholesaleLook>();
            foreach(var r in WholesaleRules.Oldest(rows.Where(x=>WholesaleRules.ShipViaBuf(x.ShipVia)))) {
                var s=WholesaleRules.Screen(r,today);var m=memo(r.Doc);bool same=m!=null&&m.sig==Sig(r);
                var l=new WholesaleLook {Row=r,ListProblem=s.Problem};
                bool waiting=same&&(m.last=="problem"||m.last=="locked");
                bool due=waiting&&FromMs(m.retryAt)<=nowUtc;
                string until=waiting?(m.last=="locked"?"open on another PC":"can't read: "+m.problems)+" (tried again at "+Clock(m.retryAt)+")":"";
                if(s.Why!=null) {
                    // A flagged order with a reading problem of its own is tried again when due (tags only added to it), also
                    // after it was found open on another PC meanwhile (its problem kept: WholesalePlan.After).
                    if(s.Comment.Kind=="flagged"&&!s.Problem&&same&&(m.last=="problem"||(m.last=="locked"&&!String.IsNullOrEmpty(m.problems)))) {
                        if(due) { l.Queue="retry";l.Retry=true;again.Add(l); } else { l.Skip=s.Why+"; "+until;skipped.Add(l); }
                        continue;
                    }
                    l.Skip=s.Why;skipped.Add(l);continue;
                }
                if(s.Comment.Kind=="go") {
                    // Staff's go: at once (Tommy: "A new go should bring it forward"), unless this same go waits for its try, or
                    // (the dry run, which never takes the go off) it was previewed today and its row hasn't changed since.
                    if(waiting&&!due) { l.Skip="go: "+until;skipped.Add(l); }
                    else if(!waiting&&dryRun&&same&&m.day==today) { l.Skip="go: previewed at "+Clock(m.at)+" (unchanged since): "+m.why;skipped.Add(l); }
                    else { l.Queue="go";go.Add(l); }
                    continue;
                }
                if(waiting) {
                    if(due) { l.Queue="retry";again.Add(l); } else { l.Skip=until;skipped.Add(l); }
                    continue;
                }
                if(dryRun&&same&&m.day==today) { l.Skip="previewed at "+Clock(m.at)+" (unchanged since): "+m.why;skipped.Add(l);continue; }
                l.Queue="new";fresh.Add(l);
            }
            var all=new List<WholesaleLook>();
            foreach(var l in go.Concat(fresh).Concat(again)) {
                if(all.Count<most) all.Add(l);
                else { l.Skip="more than "+most+" to open: the next pass";l.Queue="";l.Retry=false;skipped.Add(l); }
            }
            all.AddRange(skipped);
            return all;
        }
        // A reading problem or a lock still followed (WholesaleState.Open), after the list was read: why it no longer is
        // (null: it still is). listed: its number is on the list; r: its row there (null: not listed). Its message on
        // Discord says so, and the order is looked at as new if it's to be checked again (sig emptied). An order whose
        // row hasn't changed is still followed: tried again when due (or, flagged by the helper, as WholesalePlan.Queue).
        internal static string Dropped(WholesaleMemo m,WholesaleRow r,string today) {
            if(m==null) return null;
            if(r==null) return "no longer on COSTAR's list (sold, filled or changed by hand)";
            if(!WholesaleRules.ShipViaBuf(r.ShipVia)) return "its Ship Via isn't BUF any more";
            var s=WholesaleRules.Screen(r,today);
            if(s.Why==null||s.Problem||Sig(r)==m.sig) return null;
            // Never staff's own words (Discord hears this).
            switch(s.Comment.Kind) {
                case "staff": return "its Comment is staff's now (left for staff)";
                case "go-only": return "its Comment has go, but no helper flag";
                case "flagged": return "it's flagged "+WholesaleComment.TagText(s.Comment.Tags)+" now, waiting for staff's go";
            }
            return s.Why.IndexOf("after today",StringComparison.Ordinal)>=0?"its ShipDate is after today now":"its row on COSTAR's list changed";
        }
        // The rest of a pass once the list was read again during it (again: Queue on it): staff's new go requests first
        // (Tommy, 14 Nov: "notices a new go request during a long batch"), then the orders still to open, each as listed
        // now. One gone from the list, or not to be opened now (another ShipDate or Comment, the next pass), is left out:
        // dropped, with why (Queue's reason, or "no longer on COSTAR's list").
        internal static List<WholesaleLook> Rest(IList<WholesaleLook> left,IList<WholesaleLook> again,out List<WholesaleLook> dropped) {
            var now=new Dictionary<string,WholesaleLook>(StringComparer.Ordinal);
            foreach(var x in again) if(!now.ContainsKey(x.Row.Doc)) now[x.Row.Doc]=x;
            var keep=new List<WholesaleLook>();var still=new HashSet<string>(StringComparer.Ordinal);dropped=new List<WholesaleLook>();
            foreach(var x in left) {
                WholesaleLook y;
                if(!now.TryGetValue(x.Row.Doc,out y)) { x.Skip="no longer on COSTAR's list (or not BUF)";dropped.Add(x);continue; }
                if(y.Skip!=null) { dropped.Add(y);continue; }
                if(still.Add(y.Row.Doc)) keep.Add(y);
            }
            return again.Where(x=>x.Skip==null&&x.Queue=="go"&&!still.Contains(x.Row.Doc)).Concat(keep).ToList();
        }
        // An unreadable ShipDate on the list: kept as a reading problem of the order's (it's never opened for it), so its
        // message is let go once the row changes or leaves the list (Dropped).
        internal static WholesaleMemo ListProblem(WholesaleMemo before,WholesaleRow r,string today,DateTime nowUtc) {
            var m=before==null?new WholesaleMemo():Wire.Copy(before);
            bool same=before!=null&&before.sig==Sig(r)&&before.last=="problem";
            m.doc=r.Doc;m.sig=Sig(r);m.last="problem";m.problems="its ShipDate can't be read on COSTAR's list";m.why=m.problems;m.day=today;m.at=ToMs(nowUtc);
            m.firstProblem=same&&before.firstProblem>0?before.firstProblem:ToMs(nowUtc);m.retryAt=0;
            return m;
        }
        // What the helper keeps of an order after it was looked at (before: what it kept; dryRun: approvals aren't
        // recorded, nothing having been written; comment: the order's Comment as it is now, for its row).
        internal static WholesaleMemo After(WholesaleMemo before,WholesaleLook l,string today,DateTime nowUtc,bool dryRun,string comment) {
            var m=before==null?new WholesaleMemo {doc=l.Row.Doc}:Wire.Copy(before);
            bool same=before!=null&&before.sig==Sig(l.Row);
            m.doc=l.Row.Doc;m.sig=Sig(l.Row,comment);m.at=ToMs(nowUtc);m.day=today;
            // Locked: a reading problem it had (the same row) is kept, so it's still followed and tried again as before.
            bool kept=same&&(before.last=="problem"||before.last=="locked")&&!String.IsNullOrEmpty(before.problems);
            if(l.Locked) { m.last="locked";m.why="open on another PC (COSTAR's Document Already Open)";m.problems=kept?before.problems:"";m.firstProblem=kept?before.firstProblem:0;m.retryAt=ToMs(RetryAt(true,nowUtc,nowUtc));return m; }
            var v=l.Verdict;
            if(v==null) return m;
            if(v.Problems.Count>0) {
                m.firstProblem=kept&&before.firstProblem>0?before.firstProblem:ToMs(nowUtc);
                m.last="problem";m.problems=String.Join("; ",v.Problems.ToArray());m.retryAt=ToMs(RetryAt(false,FromMs(m.firstProblem),nowUtc));
            } else { m.last=v.Action;m.problems="";m.firstProblem=0;m.retryAt=0; }
            string plain=WholesaleRules.Plain(v);m.why=plain.Length>220?plain.Substring(0,220)+"...":plain;
            if(!dryRun&&v.Approve.Count>0) {
                var items=l.Lines.Where(x=>!x.Note&&x.Item.Length>0).ToList();
                if(v.Approve.Contains("review")) m.review=WholesaleRules.Print(items.Where(x=>x.Kind=="wheel"));
                if(v.Approve.Contains("items")) m.items=WholesaleRules.Print(items);
                m.approvedAt=ToMs(nowUtc);
            }
            return m;
        }
    }
}
