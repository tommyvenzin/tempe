// The RDP helper's Wholesale tab (2.9.0, stage 1 of the wholesale orders: a dry run). A button runs one pass of the
// dry run (WholesaleRun: nothing typed, sold or changed); Stop stops it; the list shows each BUF order of COSTAR
// Sydney's "Orders yet to be filled" and what the helper would do with it; picking one shows its lines as read.
// 2.9.7: the new rules (Tommy, 14 Nov), the list and detail shared with the wholesale helper's window (WholesaleView),
// up to 100 orders a press, and what was previewed kept (wholesale-state.json), so the next press gets further down
// the list. Checking again and again by itself is the wholesale helper's (Start-Wholesale.cmd, a Windows session of
// its own): this tab keeps COSTAR Sydney's Work-in-Progress for eBay orders.
using System;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed partial class WorkerForm {
        readonly TabPage wholesalePage=new TabPage("Wholesale");
        readonly Button wholesaleStart=Ui.PrimaryButton("Check wholesale orders (dry run)",290),wholesaleStop=Ui.DangerButton("Stop",100);
        WholesaleView wholesaleView;WholesaleState wholesaleState;
        volatile WholesaleRun wholesale;
        void WholesaleAppend(string text){if(wholesaleView!=null) wholesaleView.Append(text);}
        void BuildWholesalePage() {
            wholesalePage.BackColor=Ui.Canvas;wholesalePage.Padding=new Padding(0);
            string folder=Path.Combine(PrivateFiles.Home,"worker");PrivateFiles.DirectoryReady(folder);
            wholesaleState=new WholesaleState(folder);wholesaleView=new WholesaleView(wholesaleState);
            var card=Ui.Card();card.Dock=DockStyle.Top;
            var lines=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Surface};
            lines.Controls.Add(Ui.Title("Wholesale orders in COSTAR Sydney: dry run (2.9.7 rules)"));
            lines.Controls.Add(Ui.Hint("Opens up to 100 BUF orders on \"Orders yet to be filled\" whose ShipDate isn't after today, oldest first: staff's go requests, then orders not looked at yet, then ones to try again. "+
                "A Comment of WWW and BUF words only (any order, any spelling of BUFFALO) is a new order; the helper's tags [stock] [card] [review] [items] wait for staff's go; any other words are staff's. "+
                "It reads Terms, card details (yes or no only), and each line (tyre, wheel, tube, freight, other); each tyre's Sydney \"= Avail\" must be 4 or more. "+
                "It shows what it WOULD do: Sell, then Cancel, or the Comment with the tags it would add. Nothing is typed, sold or changed. "+
                "COSTAR Sydney comes to the front: leave the PC alone until it's done. eBay orders wait meanwhile; COSTAR Sydney goes back to Repair Order at the end. "+
                "Each press goes further down the list (orders previewed today aren't opened again unless their row changes). To check by itself all day, use the wholesale helper (Start-Wholesale.cmd) in a Windows session of its own.",820));
            lines.Controls.Add(wholesaleView.Line);
            card.Controls.Add(lines);
            var buttons=Ui.Row();buttons.Margin=new Padding(0,10,0,6);buttons.Controls.Add(wholesaleStart);buttons.Controls.Add(wholesaleStop);
            wholesalePage.Controls.Add(wholesaleView.Build(card,buttons));
            wholesaleStart.Click+=delegate{DeskForm.Attempt(StartWholesale);};
            wholesaleStop.Click+=delegate{var run=wholesale;if(run!=null&&run.Running){run.Cancel=true;WholesaleAppend("Stopping the dry run ...");}};
            wholesaleStop.Enabled=false;
            Ui.SetText(wholesaleView.Line,"Not run yet.");
        }
        void StartWholesale() {
            var last=wholesale;
            Order.Require(last==null||!last.Running,"The dry run is already running.");
            Order.Require(!coordinator.Busy,(coordinator.Owner.Length>0?coordinator.Owner:"An entry")+" is using COSTAR: wait for it to finish.");
            var run=new WholesaleRun(coordinator,WholesaleAppend,new WholesaleOptions {State=wholesaleState});wholesale=run;
            AppLog.Note("wholesale_dry_run_start","");
            var thread=new Thread(delegate() { run.Run();WholesaleAppend(run.Summary); });
            thread.IsBackground=true;thread.Start();
            UpdateStatus();
        }
        void StopWholesale() { var run=wholesale;if(run!=null&&run.Running) run.Cancel=true; }
        void UpdateWholesaleTab() {
            if(wholesaleView==null) return;
            var run=wholesale;bool running=run!=null&&run.Running;
            wholesaleStart.Enabled=!running&&!coordinator.Busy;wholesaleStop.Enabled=running;
            wholesaleView.Update(run);
        }
    }
}
