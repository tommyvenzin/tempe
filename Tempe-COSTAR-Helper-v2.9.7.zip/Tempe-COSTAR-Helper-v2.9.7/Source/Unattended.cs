// 2.8.0 "Runs by itself" (Tommy, 2 Nov 20:37: "I want it to be working by itself instead of doing things manually";
// 20:47: "we can start releasing it"): the helpers start with Windows, mobile comes back on after a restart, updates
// install themselves outside shop hours, a job that stopped before anything was typed is retried once, and Discord
// says when a person is needed.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    // The rules, pure (the self-tests check them).
    internal static class Unattended {
        // The phone's own rule (jobcard-shared.js NOT_ENTERED): a stop that typed nothing into COSTAR.
        static readonly Regex NotEnteredWords=new Regex(@"^Not entered\b|can't do this job's choices now|Add new was not pressed|before any fields were entered",RegexOptions.IgnoreCase);
        internal static bool NotEntered(string message) { return !String.IsNullOrEmpty(message)&&NotEnteredWords.IsMatch(message); }
        // Retried by itself once, RetryAfter after it stopped (COSTAR busy, Add new covered, someone at the PC...), and
        // only within RetryWithin of the stop (a desk PC that was off overnight doesn't retry yesterday's). Never a stop
        // whose words begin "Stopped": a person's Stop all or the helper closing ("Stopped before the Repair Order left
        // open ... was closed"), or the desk's "Stopped: ... can't do this job's choices now" (it needs an update).
        internal static readonly TimeSpan RetryAfter=TimeSpan.FromSeconds(60),RetryWithin=TimeSpan.FromMinutes(30);
        internal static bool Retryable(string message) { return NotEntered(message)&&!message.TrimStart().StartsWith("Stopped",StringComparison.OrdinalIgnoreCase); }
        internal static bool RetryDue(string message,DateTime stoppedAt,DateTime now,bool retriedBefore) {
            return !retriedBefore&&Retryable(message)&&now-stoppedAt>=RetryAfter&&now-stoppedAt<RetryWithin;
        }
        // An offered update installs itself only outside shop hours, with nothing being entered, nobody at this PC for
        // QuietForUpdate, at most once an hour, and each version once only (triedBefore: a version that didn't start is
        // never installed again by itself; the yellow line still can).
        internal static readonly TimeSpan QuietForUpdate=TimeSpan.FromMinutes(10);
        internal static bool UpdateDue(bool offered,bool on,DateTime now,bool busy,bool someoneHere,DateTime lastTry,bool triedBefore) {
            return offered&&on&&!busy&&!someoneHere&&!triedBefore&&!TempeOrderCheck.Text.InShopHours(now)&&now-lastTry>=TimeSpan.FromHours(1);
        }
        // Mobile back on by itself when the helper starts: wanted (the setting), on when the helper last closed, no
        // stopped job waiting for a person, the Online orders tab not holding mobile (2.9.3: showing, with someone at the PC), and the
        // selected COSTAR is the branch mobile was last started in (mobile jobs carry no branch). null: resume; "": stay
        // off, nothing to say; else why not yet.
        internal static string WhyNotResume(bool wanted,bool wasOn,bool jobStopped,bool onlineTabShowing,int selectedBranch,int mobileBranch) {
            if(!wanted||!wasOn) return "";
            if(jobStopped) return "a phone job stopped part way and needs you first (Release job or Start this job again)";
            if(onlineTabShowing) return "someone is using the PC, with the Online orders tab showing (mobile waits while they are): it comes on once the PC has been left alone for 2 minutes, or another tab is chosen";
            if(selectedBranch<=0) return "no COSTAR is selected (yet)";
            if(selectedBranch!=mobileBranch) return mobileBranch<=0?"the branch mobile was last on in isn't known":"the selected COSTAR is Branch "+selectedBranch+", mobile was last on in Branch "+mobileBranch;
            return null;
        }
    }

    // "Start with Windows": a .cmd in the user's Startup folder (run at sign-in) that runs Launch.ps1 of the folder this
    // helper came from (it hands over to a newer installed version by itself, never to an older one); only when that
    // folder has gone, the newest installed version (packages\current.txt). Each start rewrites it to its own folder.
    // A folder a cmd file can't hold (accents, as in some Windows user names, or % " ^ !) isn't written in it: then
    // only the newest installed version, found at run time. A launch that fails keeps its window open (pause).
    internal static class AutoStart {
        internal static string FileFor(string mode) { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup),"Tempe COSTAR helper - "+mode+".cmd"); }
        internal static bool On(string mode) { try { return File.Exists(FileFor(mode)); } catch(Exception) { return false; } }
        // The package folder this helper was started from (Launch.ps1 says so since 2.8.0), else the newest installed one.
        internal static string PackageFolder() {
            string from=Environment.GetEnvironmentVariable("TEMPE_PACKAGE");
            if(!String.IsNullOrEmpty(from)&&File.Exists(Path.Combine(from,"Launch.ps1"))) return from.TrimEnd('\\');
            try {
                string pointer=Path.Combine(Updater.Packages,"current.txt");
                if(File.Exists(pointer)) { string p=(File.ReadAllLines(pointer).FirstOrDefault()??"").Trim();if(p.Length>0&&File.Exists(Path.Combine(p,"Launch.ps1"))) return p.TrimEnd('\\'); }
            } catch(Exception) { }
            return null;
        }
        // A folder the file can name: plain ASCII without the characters cmd treats specially (% " ^ ! line breaks).
        internal static bool Plain(string folder) { return !String.IsNullOrEmpty(folder)&&folder.All(ch=>ch>=32&&ch<127)&&folder.IndexOfAny(new[]{'%','"','^','!'})<0; }
        // The file's text (plain ASCII). mode: Desk, RDP or Online (the launcher's own word). folder: this helper's
        // package folder, named in the file only when Plain.
        internal static string Script(string mode,string folder) {
            Order.Require(mode=="Desk"||mode=="RDP"||mode=="Online"||mode=="Wholesale","Unknown helper mode.");
            bool own=Plain(folder);
            string launch="powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Minimized ";
            string newest="$p=$null; try { $p=((Get-Content -LiteralPath (Join-Path $env:LOCALAPPDATA 'TempeMobileCostar\\packages\\current.txt') -TotalCount 1 -ErrorAction Stop)+'').Trim() } catch { }; "
                +"if(-not $p -or -not (Test-Path -LiteralPath (Join-Path $p 'Launch.ps1'))) { Write-Host 'The helper was not found: start it from its folder once.'; exit 1 }; "
                +"& powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File (Join-Path $p 'Launch.ps1') -Mode "+mode+"; exit $LASTEXITCODE";
            return "@echo off\r\n"
                +"rem Tempe COSTAR helper ("+mode+"): started when you sign in to Windows (the helper's \"Start with Windows\").\r\n"
                +"rem Untick it in the helper (or delete this file) to stop that.\r\n"
                +(own?"if not exist \""+folder+"\\Launch.ps1\" goto newest\r\n"
                    +launch+"-File \""+folder+"\\Launch.ps1\" -Mode "+mode+"\r\n"
                    +"goto done\r\n":"")
                +":newest\r\n"
                +launch+"-Command \""+newest+"\"\r\n"
                +":done\r\n"
                +"if errorlevel 1 pause\r\n";
        }
        internal static void Set(string mode,bool on) {
            string file=FileFor(mode);
            if(!on) { if(File.Exists(file)) File.Delete(file);AppLog.Note("autostart","off "+mode);return; }
            string folder=PackageFolder();
            Order.Require(folder!=null,"This helper's folder wasn't found. Start it once with its Start-"+mode+".cmd, then tick this again.");
            Order.Require(Plain(folder)||File.Exists(Path.Combine(Updater.Packages,"current.txt")),"This helper's folder name has characters a start-up file can't hold (accents, %, \", ^ or !): move the helper to a plain folder, or update it once with the yellow line.");
            string text=Script(mode,folder);
            if(File.Exists(file)&&File.ReadAllText(file,Encoding.ASCII)==text) return;
            Directory.CreateDirectory(Path.GetDirectoryName(file));
            File.WriteAllText(file,text,Encoding.ASCII);AppLog.Note("autostart","on "+mode);
        }
        internal static void Refresh(string mode) { try { if(On(mode)) Set(mode,true); } catch(Exception e) { AppLog.Note("autostart_refresh_failed",e.GetType().Name); } }
    }

    // 2.8.0: Discord messages when a person is needed. The channel's webhook is pasted once into the RDP helper,
    // kept encrypted on this PC (alerts.dat), never shown again, logged, or sent anywhere but Discord.
    public sealed class AlertSettings { public string webhook; }
    internal static class Alerts {
        static readonly Regex Hook=new Regex(@"^https://(?:(?:ptb|canary)\.)?discord(?:app)?\.com/api/(?:v\d+/)?webhooks/(\d{15,22})/([A-Za-z0-9_-]{20,})/?$");
        // The webhook in its one form, or null when it isn't a Discord webhook.
        internal static string Normal(string url) { var m=Hook.Match((url??"").Trim());return m.Success?"https://discord.com/api/webhooks/"+m.Groups[1].Value+"/"+m.Groups[2].Value:null; }
        static readonly object gate=new object();
        static string file,webhook;
        static readonly Dictionary<string,DateTime> lastSent=new Dictionary<string,DateTime>(StringComparer.Ordinal);
        static readonly List<DateTime> sent=new List<DateTime>();
        // One message per kind per KindGap, MostPerHour in all (a loop of stops never floods the channel).
        internal static readonly TimeSpan KindGap=TimeSpan.FromMinutes(15);
        internal const int MostPerHour=12;
        internal static void Load(string folder) {
            lock(gate) {
                file=Path.Combine(folder,"alerts.dat");
                try { var s=PrivateFiles.Load<AlertSettings>(file);webhook=s==null?null:Normal(s.webhook); } catch(Exception) { webhook=null; }
            }
        }
        internal static bool On { get { lock(gate) return webhook!=null; } }
        internal static void Save(string url) {
            string hook=Normal(url);Order.Require(hook!=null,"That isn't a Discord channel webhook (it starts https://discord.com/api/webhooks/...).");
            lock(gate) { Order.Require(file!=null,"Alerts aren't ready.");PrivateFiles.Save(file,new AlertSettings {webhook=hook});webhook=hook; }
            AppLog.Note("alerts","on");
        }
        internal static void Remove() { lock(gate) { webhook=null;if(file!=null&&File.Exists(file)) File.Delete(file); } AppLog.Note("alerts","off"); }
        // Whether a message of this kind goes now (pure: the self-tests check it).
        internal static bool Allowed(string kind,DateTime now,IDictionary<string,DateTime> last,IList<DateTime> recent) {
            DateTime at;
            if(last.TryGetValue(kind,out at)&&now-at<KindGap) return false;
            return recent.Count(t=>now-t<TimeSpan.FromHours(1))<MostPerHour;
        }
        // Sent in the background; never throws, never waits. kind: what it's about (one message per kind per KindGap).
        // title: the helper's own words with the job's reference (kept as it is); detail: a stop's words (numbers and
        // emails masked, as in the run reports). False when it doesn't go (alerts off, or too soon): a watch that has
        // something to say then tries again later rather than counting it said.
        internal static bool Raise(string kind,string title,string detail) {
            string hook;var now=DateTime.UtcNow;
            lock(gate) {
                hook=webhook;if(hook==null) return false;
                if(!Allowed(kind,now,lastSent,sent)) return false;
                lastSent[kind]=now;sent.Add(now);sent.RemoveAll(t=>now-t>=TimeSpan.FromHours(1));
            }
            string message=Compose(title,detail);
            ThreadPool.QueueUserWorkItem(delegate {
                string error=Post(hook,message);
                AppLog.Note(error==null?"alert_sent":"alert_failed",kind+(error==null?"":": "+error));
            });
            return true;
        }
        // A job that stopped: said at once; one that typed nothing (the desk PC retries it once by itself) only when it
        // hasn't started again within JobQuietFor (Tick says it then).
        internal static readonly TimeSpan JobQuietFor=TimeSpan.FromMinutes(3);
        static readonly Dictionary<string,KeyValuePair<DateTime,string>> pending=new Dictionary<string,KeyValuePair<DateTime,string>>(StringComparer.Ordinal);
        // what: "Phone job", "eBay order". mayRetry: it typed nothing (the desk PC retries such a stop once by itself).
        internal static void JobStopped(string what,string reference,string message,bool mayRetry) {
            reference=reference??"";string title=what+" "+reference+" stopped";
            if(mayRetry&&Unattended.Retryable(message)) { lock(gate) pending[reference]=new KeyValuePair<DateTime,string>(DateTime.UtcNow,title+"\n"+(message??""));return; }
            lock(gate) pending.Remove(reference);
            Raise("stop:"+reference,title,message);
        }
        internal static void JobStarted(string reference) { lock(gate) pending.Remove(reference??""); }
        // Called every few seconds (the RDP helper's timer).
        internal static void Tick() {
            var due=new List<KeyValuePair<string,string>>();var now=DateTime.UtcNow;
            lock(gate) { foreach(var p in pending.ToList()) if(now-p.Value.Key>=JobQuietFor) { due.Add(new KeyValuePair<string,string>(p.Key,p.Value.Value));pending.Remove(p.Key); } }
            foreach(var d in due) { int cut=d.Value.IndexOf('\n');Raise("stop:"+d.Key,d.Value.Substring(0,cut)+" (not started again within "+(int)JobQuietFor.TotalMinutes+" minutes)",d.Value.Substring(cut+1)); }
        }
        internal static int Waiting { get { lock(gate) return pending.Count; } }
        // A test message now (Files & settings): null when Discord took it, else why not.
        internal static string Test() { string hook;lock(gate) hook=webhook;return hook==null?"No webhook is set.":Post(hook,Compose("Test from the RDP helper "+AutofillForm.Version,"alerts reach this channel.")); }
        // What goes to Discord: the title as it is (control characters out, kept short), the detail with numbers and
        // emails masked as in the run reports; no mentions (allowed_mentions is empty too).
        internal static string Compose(string title,string detail) {
            string t=Regex.Replace(title??"",@"[\x00-\x1f\x7f]+"," ").Replace("@","(at)");if(t.Length>160) t=t.Substring(0,160)+"...";
            string d=Sanitize.Text(detail??"",400).Replace("@","(at)");
            return "**Tempe helper:** "+t+(d.Length>0?": "+d:"");
        }
        static string Post(string hook,string message) {
            try {
                ServicePointManager.SecurityProtocol=ServicePointManager.SecurityProtocol|SecurityProtocolType.Tls12;
                var request=(HttpWebRequest)WebRequest.Create(hook);
                request.Method="POST";request.ContentType="application/json";request.Timeout=15000;request.ReadWriteTimeout=15000;request.AllowAutoRedirect=false;
                byte[] body=Encoding.UTF8.GetBytes(Wire.Json(new {content=message,allowed_mentions=new {parse=new string[0]}}));
                request.ContentLength=body.Length;
                using(var output=request.GetRequestStream()) output.Write(body,0,body.Length);
                using(var response=(HttpWebResponse)request.GetResponse()) return (int)response.StatusCode<300?null:"Discord answered "+(int)response.StatusCode;
            } catch(WebException e) {
                var r=e.Response as HttpWebResponse;
                return r!=null?"Discord answered "+(int)r.StatusCode:e.Status.ToString();
            } catch(Exception e) { return e.GetType().Name; }
        }
    }
}
