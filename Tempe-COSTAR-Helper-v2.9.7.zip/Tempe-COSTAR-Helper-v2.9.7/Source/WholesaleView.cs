// 2.9.7: the wholesale orders as the helper shows them, shared by the RDP helper's Wholesale tab (one pass on a
// button) and the wholesale helper's own window (the loop, Start-Wholesale.cmd): a line saying where the run is, the
// BUF orders of the last list read with what the dry run would do with each (or why it isn't opened), and the picked
// order's detail: each line's kind (tyre, wheel, tube, freight, other) and Sydney's stock, the Comment before and after,
// card details yes / no / can't tell, the approvals the helper keeps for it, what couldn't be read and when it's tried
// again. Nothing here touches COSTAR.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed class WholesaleView {
        internal readonly Label Line=Ui.Text("",820),Detail=Ui.Hint("",820);
        internal readonly ListView List=new ListView {View=View.Details,FullRowSelect=true,HideSelection=false,Font=Ui.Base,MultiSelect=false,Dock=DockStyle.Fill};
        internal readonly RichTextBox Log=Ui.Log();
        readonly BoundedLog messages=new BoundedLog();
        readonly WholesaleState state;
        string shown="";
        internal WholesaleView(WholesaleState kept) {
            state=kept;
            foreach(var c in new[]{new ColumnHeader {Text="Order",Width=100},new ColumnHeader {Text="Ordered",Width=86},new ColumnHeader {Text="Ship date",Width=86},new ColumnHeader {Text="Ship Via",Width=76},
                new ColumnHeader {Text="Comment",Width=150},new ColumnHeader {Text="Terms",Width=66},new ColumnHeader {Text="Why",Width=50},new ColumnHeader {Text="What it would do",Width=760}}) List.Columns.Add(c);
            List.SelectedIndexChanged+=delegate{ShowOrder();};
            Detail.Margin=new Padding(0,6,0,6);
        }
        internal void Append(string text) { messages.Add(text); }
        // The page: the card on top (title, words, Line), the buttons, the list, the picked order, the log.
        internal TableLayoutPanel Build(Control card,Control buttons) {
            var layout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=5,Padding=new Padding(12),BackColor=Ui.Canvas};
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent,60));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,40));
            layout.Controls.Add(card,0,0);layout.Controls.Add(buttons,0,1);layout.Controls.Add(List,0,2);layout.Controls.Add(Detail,0,3);layout.Controls.Add(Log,0,4);
            return layout;
        }
        // The run's state shown (on the window's thread, from its timer).
        internal void Update(WholesaleRun run) {
            Ui.AppendColoured(Log,messages.Drain());
            if(run==null) return;
            bool running=run.Running;
            Ui.SetText(Line,run.Loop?(run.Status.Length>0?run.Status:running?"Starting ...":run.Summary):running?"Running: "+run.Count()+" so far.":run.Summary);
            var looks=run.Looks;
            string key=looks.Count+"|"+String.Join(",",looks.Select(Key).ToArray());
            if(key==shown) return;
            shown=key;
            string selected=List.SelectedItems.Count>0?List.SelectedItems[0].Text:null;
            List.BeginUpdate();
            try {
                List.Items.Clear();
                foreach(var l in looks) {
                    var r=l.Row;var v=l.Verdict;
                    var item=new ListViewItem(new[]{r.Doc,r.OrderDate,r.ShipDate,r.ShipVia,r.Comment,v!=null?l.Terms??"(unread)":"",l.Queue,Result(l)}) {Tag=l};
                    if(l.Locked) item.ForeColor=Color.FromArgb(29,78,216);
                    else if(v!=null) item.ForeColor=v.Problems.Count>0?Color.FromArgb(185,28,28):v.Action=="sell"?Color.FromArgb(21,128,61):v.Action=="flag"?Color.FromArgb(180,83,9):Ui.Muted;
                    else if(l.Skip!=null) item.ForeColor=l.ListProblem?Color.FromArgb(185,28,28):Ui.Muted;
                    List.Items.Add(item);
                    if(selected!=null&&r.Doc==selected) item.Selected=true;
                }
            } finally { List.EndUpdate(); }
            ShowOrder();
        }
        static string Key(WholesaleLook l) { return l.Row.Doc+(l.Opened?"o":"")+(l.Locked?"k":"")+(l.Verdict==null?"":l.Verdict.Action+l.Verdict.Problems.Count)+(l.Skip==null?"":"s")+(l.LeftOpen==null?"":"l"); }
        internal static string Result(WholesaleLook l) {
            var v=l.Verdict;
            if(l.Locked) return "Open on another PC (COSTAR's Document Already Open, OK pressed): skipped, tried again in 2 minutes";
            if(l.Skip!=null) return "Not opened: "+l.Skip;
            if(v!=null) return WholesaleRules.Plain(v)+(l.LeftOpen!=null?" (left open in COSTAR: "+l.LeftOpen+")":"");
            if(l.LeftOpen!=null) return "Left open in COSTAR: "+l.LeftOpen;
            return l.Opened?"Reading ...":"To open";
        }
        // The picked order: its lines as read, what would change, what the helper keeps for it.
        void ShowOrder() {
            var item=List.SelectedItems.Count>0?List.SelectedItems[0]:null;var l=item==null?null:item.Tag as WholesaleLook;
            if(l==null) { Ui.SetText(Detail,"Pick an order to see its lines and what the dry run found.");return; }
            var parts=new List<string>();
            var m=state==null?null:state.Get(l.Row.Doc);
            if(l.Verdict==null) parts.Add("Order "+l.Row.Doc+": "+Result(l)+".");
            else {
                var v=l.Verdict;
                string card=l.Card==true?"yes":l.Card==false?"no":"can't tell";
                parts.Add("Order "+l.Row.Doc+": Terms "+(l.Terms??"(unread)")+"; card details in the Notes: "+card+(l.NotesShown?"":" (no Notes popped up)")+".");
                parts.Add("Comment \""+(l.OrderComment??"(unread)")+"\""+(v.Action=="flag"?" would become \""+v.CommentAfter+"\"":v.Action=="sell"?" (Sell, then Cancel)":"")+".");
                var lines=l.Lines.Select(x=>"line "+x.Number+" "+x.Item+(x.Note?" (note)":" "+x.Kind.ToUpperInvariant()+(x.Kind=="tyre"?" "+(x.Size.Length>0?x.Size:"")+" ("+WholesaleRules.StockWords(x)+")":"")+", order qty "+x.OrderQty)).ToArray();
                parts.Add(lines.Length>0?String.Join("; ",lines)+".":"No lines read.");
                if(l.Memos.Count>0) parts.Add(String.Join("; ",l.Memos.ToArray())+".");
                if(v.Approve.Count>0) parts.Add("Staff's go would approve "+String.Join(" and ",v.Approve.Select(x=>"["+x+"]").ToArray())+" for these lines (the dry run doesn't keep it).");
            }
            // What changed or was left open (a stop: the order has no verdict then).
            if(l.ChangedValues!=null) parts.Add("Opening its tyre lines changed "+l.ChangedValues+".");
            if(l.LeftOpen!=null&&l.Verdict!=null) parts.Add("Left open in COSTAR: "+l.LeftOpen+".");   // (without a verdict: Result says it)
            if(m!=null) {
                if(m.review!=null||m.items!=null) parts.Add("Approvals kept: "+(m.review!=null?"[review] for "+m.review:"")+(m.review!=null&&m.items!=null?"; ":"")+(m.items!=null?"[items] for "+m.items:"")+" (since "+WholesalePlan.Clock(m.approvedAt)+").");
                else parts.Add("No approvals kept for it.");
                if(m.last=="problem") parts.Add("Can't read: "+m.problems+(m.retryAt>0?". Tried again at "+WholesalePlan.Clock(m.retryAt):"")+".");
                if(m.last=="locked") parts.Add("Open on another PC: tried again at "+WholesalePlan.Clock(m.retryAt)+".");
            }
            Ui.SetText(Detail,String.Join(" ",parts.ToArray()));
        }
    }
}
