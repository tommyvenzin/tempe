// 2.9.7: the wholesale channel on Discord (Tommy, 14 Nov: "One message per order, updated as its status changes",
// sales and flags, a reading problem until it clears, and a stopped run; "avoid duplicate alerts for the same
// unresolved problem"; the dry run's messages "must clearly identify dry-run results"). The channel's webhook is pasted
// once into the wholesale helper, kept encrypted on this PC (wholesale-discord.dat), never shown again, logged or sent
// anywhere but Discord. Each message's id and words are kept (wholesale-discord.json), so a change edits that message
// rather than posting another, and the same words are never sent twice. Sent one at a time in the background, never
// faster than one every 1.5 s, waiting as long as Discord asks when it says too many. Customer names, card details
// and staff's own Comment words are never in them: the order's number, Ship Via, Terms code, the helper's tags and why.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;

namespace TempeCostar {
    public sealed class WholesaleHookSettings { public string webhook; }
    public sealed class WholesalePosted { public string key="",id="",text="";public long at; }
    // hook: which channel the ids are of (a hash of its webhook, never the webhook itself).
    public sealed class WholesalePostedFile { public int schema=1;public string hook="";public List<WholesalePosted> messages=new List<WholesalePosted>(); }

    internal sealed class WholesaleDiscord {
        readonly object gate=new object();readonly string hookFile,idsFile;string hook,idsHook="";
        readonly Dictionary<string,WholesalePosted> posted=new Dictionary<string,WholesalePosted>(StringComparer.Ordinal);
        // What waits to go: the newest words for each message (an older one not yet sent is replaced).
        readonly List<string> order=new List<string>();readonly Dictionary<string,string> waiting=new Dictionary<string,string>(StringComparer.Ordinal);
        readonly AutoResetEvent wake=new AutoResetEvent(false);
        internal volatile string LastError="";internal volatile int Sent;
        internal static readonly TimeSpan Gap=TimeSpan.FromMilliseconds(1500),KeepIds=TimeSpan.FromDays(30);
        internal WholesaleDiscord(string folder) {
            hookFile=Path.Combine(folder,"wholesale-discord.dat");idsFile=Path.Combine(folder,"wholesale-discord.json");
            try { var s=PrivateFiles.Load<WholesaleHookSettings>(hookFile);hook=s==null?null:Alerts.Normal(s.webhook); } catch(Exception) { hook=null; }
            try {
                if(File.Exists(idsFile)) {
                    var read=Wire.Read<WholesalePostedFile>(File.ReadAllText(idsFile,Encoding.UTF8));
                    if(read!=null&&read.messages!=null) foreach(var p in read.messages) if(p!=null&&!String.IsNullOrEmpty(p.key)) posted[p.key]=p;
                    if(read!=null) idsHook=read.hook??"";
                }
            } catch(Exception e) { AppLog.Note("wholesale_discord_ids_unreadable",e.GetType().Name); }
            var thread=new Thread(Work) {IsBackground=true,Name="Wholesale Discord"};thread.Start();
        }
        internal bool On { get { lock(gate) return hook!=null; } }
        internal void Save(string url) {
            string normal=Alerts.Normal(url);Order.Require(normal!=null,"That isn't a Discord channel webhook (it starts https://discord.com/api/webhooks/...).");
            string which=HookHash(normal);
            lock(gate) {
                // Another channel: the message ids kept belong to the old one (the same one set again keeps them).
                if(which!=idsHook) posted.Clear();
                PrivateFiles.Save(hookFile,new WholesaleHookSettings {webhook=normal});hook=normal;idsHook=which;
            }
            SaveIds();AppLog.Note("wholesale_discord","on");
        }
        internal void Remove() { lock(gate) { hook=null;waiting.Clear();order.Clear();if(File.Exists(hookFile)) File.Delete(hookFile); } AppLog.Note("wholesale_discord","off"); }
        // A test message now (the button): null when Discord took it, else why not.
        internal string Test() {
            string h;lock(gate) h=hook;if(h==null) return "No webhook is set.";
            string id;int code=Send("POST",h+"?wait=true",Body("**Tempe wholesale helper** "+AutofillForm.Version+": messages reach this channel."),out id);
            return code>=200&&code<300?null:"Discord answered "+(code<=0?"nothing (no connection)":code.ToString());
        }
        // The message for key (an order's number, or "run"): posted the first time, edited when its words change,
        // nothing at all when they're the words it already has. null words: nothing to say.
        internal void Say(string key,string words) {
            if(String.IsNullOrEmpty(key)||String.IsNullOrEmpty(words)) return;
            string text=Clean(words);
            lock(gate) {
                if(hook==null) return;
                WholesalePosted p;string w;
                if(waiting.TryGetValue(key,out w)) { if(w==text) return; }
                else if(posted.TryGetValue(key,out p)&&p.text==text) return;
                waiting[key]=text;if(!order.Contains(key)) order.Add(key);
            }
            wake.Set();
        }
        internal int Waiting { get { lock(gate) return order.Count; } }
        // Whether a message for key was posted (or waits to go).
        internal bool Has(string key) { lock(gate) return !String.IsNullOrEmpty(key)&&(posted.ContainsKey(key)||waiting.ContainsKey(key)); }
        // Whether the message for key, as it stands (or is about to), says something can't be read.
        internal bool SaysProblem(string key) {
            lock(gate) {
                string w;WholesalePosted p;
                if(waiting.TryGetValue(key??"",out w)) return Problem(w);
                return posted.TryGetValue(key??"",out p)&&Problem(p.text);
            }
        }
        internal static bool Problem(string text) { return (text??"").IndexOf("can't read",StringComparison.Ordinal)>=0; }
        void Work() {
            var last=DateTime.MinValue;
            while(true) {
                string key=null,text=null,h=null,id=null;
                lock(gate) {
                    if(order.Count>0&&hook!=null) {
                        key=order[0];order.RemoveAt(0);text=waiting[key];waiting.Remove(key);h=hook;
                        WholesalePosted p;id=posted.TryGetValue(key,out p)?p.id:null;
                    }
                }
                if(key==null) { wake.WaitOne(5000);continue; }
                var since=DateTime.UtcNow-last;if(since<Gap) Thread.Sleep(Gap-since);
                string newId=null;int code=0;
                if(!String.IsNullOrEmpty(id)) {
                    string unused;code=Send("PATCH",h+"/messages/"+id,Body(text),out unused);
                    if(code==404) id=null;else newId=id;   // deleted in Discord: posted again
                }
                if(String.IsNullOrEmpty(id)) code=Send("POST",h+"?wait=true",Body(text),out newId);
                last=DateTime.UtcNow;
                if(code==429||code<=0||code>=500) {
                    // Too many, no connection, or Discord's own trouble: this message waits and goes again.
                    LastError=code==429?"Discord said too many messages: waiting":code<=0?"Discord couldn't be reached":"Discord answered "+code;
                    lock(gate) { if(!waiting.ContainsKey(key)) { waiting[key]=text;order.Add(key); } }
                    Thread.Sleep(code==429?retryAfter:TimeSpan.FromSeconds(30));
                    continue;
                }
                if(code>=200&&code<300) {
                    LastError="";Sent++;
                    lock(gate) posted[key]=new WholesalePosted {key=key,id=newId??"",text=text,at=WholesalePlan.ToMs(DateTime.UtcNow)};
                    SaveIds();
                } else { LastError="Discord answered "+code;AppLog.Note("wholesale_discord_failed",code.ToString()); }
            }
        }
        TimeSpan retryAfter=TimeSpan.FromSeconds(5);
        void SaveIds() {
            try {
                var keep=new WholesalePostedFile();var now=DateTime.UtcNow;
                lock(gate) {
                    keep.hook=idsHook;
                    foreach(var p in posted.Values.ToList()) { if(now-WholesalePlan.FromMs(p.at)<KeepIds) keep.messages.Add(p);else posted.Remove(p.key); }
                }
                string temp=idsFile+".tmp";
                File.WriteAllText(temp,Wire.Json(keep),new UTF8Encoding(false));
                if(File.Exists(idsFile)) File.Replace(temp,idsFile,null);else File.Move(temp,idsFile);
            } catch(Exception e) { AppLog.Note("wholesale_discord_ids_not_saved",e.GetType().Name); }
        }
        static string HookHash(string url) { return Wire.Hash(Encoding.UTF8.GetBytes(url??"")).Substring(0,16); }
        static string Body(string text) { return Wire.Json(new {content=text,allowed_mentions=new {parse=new string[0]}}); }
        // The status code (0: no answer); id: the message's id from a POST with ?wait=true.
        int Send(string method,string url,string json,out string id) {
            id=null;
            try {
                ServicePointManager.SecurityProtocol=ServicePointManager.SecurityProtocol|SecurityProtocolType.Tls12;
                var request=(HttpWebRequest)WebRequest.Create(url);
                request.Method=method;request.ContentType="application/json";request.Timeout=15000;request.ReadWriteTimeout=15000;request.AllowAutoRedirect=false;
                byte[] body=Encoding.UTF8.GetBytes(json);request.ContentLength=body.Length;
                using(var output=request.GetRequestStream()) output.Write(body,0,body.Length);
                using(var response=(HttpWebResponse)request.GetResponse()) {
                    using(var reader=new StreamReader(response.GetResponseStream(),Encoding.UTF8)) id=MessageId(reader.ReadToEnd());
                    return (int)response.StatusCode;
                }
            } catch(WebException e) {
                var r=e.Response as HttpWebResponse;if(r==null) return 0;
                int code=(int)r.StatusCode;
                if(code==429) {
                    double s;string header=r.Headers["Retry-After"];
                    retryAfter=Double.TryParse(header,System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out s)&&s>0&&s<600?TimeSpan.FromSeconds(s+0.5):TimeSpan.FromSeconds(5);
                }
                return code;
            } catch(Exception) { return 0; }
        }
        // The posted message's own id: the "id" of the answer's top level (never its author's or channel's).
        static readonly Regex IdText=new Regex(@"^\d{15,22}$");
        internal static string MessageId(string json) {
            try {
                var top=new JavaScriptSerializer().DeserializeObject(json??"") as Dictionary<string,object>;
                object id;
                if(top!=null&&top.TryGetValue("id",out id)&&id is string&&IdText.IsMatch((string)id)) return (string)id;
            } catch(Exception) { }
            return null;
        }
        // Discord's words: one line each, no mentions, no formatting from outside the helper's own (* _ ` ~ | > taken
        // out of what it quotes), 1,900 letters at most.
        internal static string Clean(string words) {
            string t=Regex.Replace((words??"").Replace("\r\n","\n"),@"[\x00-\x09\x0b-\x1f\x7f]+"," ").Replace("@","(at)");
            return t.Length>1900?t.Substring(0,1900)+"...":t;
        }
        static string Plain(string s) { return Regex.Replace(s??"",@"[*_`~|>\[\]\\]","").Trim(); }
        // An order whose reading problem was said: it can be read now, and there's nothing else to say (skipped once
        // opened: its Comment or Ship Via changed; or nothing to change). null: something else to say (OrderText).
        internal static string Cleared(WholesaleLook l,bool dry) {
            if(l==null||l.Locked||l.Verdict==null||l.Verdict.Problems.Count>0) return null;
            string head=(dry?"**DRY RUN** · ":"")+"Order "+Plain(l.Row.Doc)+" ("+Plain(l.Row.ShipVia)+")";
            if(l.Verdict.Action=="skip") return head+": can be read now · skipped: its Comment or Ship Via changed (the wholesale helper shows why)";
            if(l.Verdict.Action=="leave") return head+": can be read now · nothing to change: its Comment already shows "+(l.Verdict.Tags.Count>0?"**"+WholesaleComment.TagText(l.Verdict.Tags)+"**":"what was found");
            return null;
        }
        // An order followed for a reading problem or a lock that no longer is (WholesalePlan.Dropped's why).
        internal static string DroppedText(string doc,string why,bool dry) { return (dry?"**DRY RUN** · ":"")+"Order "+Plain(doc)+": no longer followed: "+Plain(why); }
        // An order's message (null: nothing to say about it: skipped, or open on another PC). dry: the dry run's.
        internal static string OrderText(WholesaleLook l,bool dry) {
            if(l==null||l.Locked) return null;
            string head=(dry?"**DRY RUN** · ":"")+"Order "+Plain(l.Row.Doc)+" ("+Plain(l.Row.ShipVia);
            var v=l.Verdict;
            if(v==null) {
                if(l.ListProblem&&l.Skip!=null) return head+"): can't read its ShipDate on COSTAR's list; looked at again each refresh";
                return null;
            }
            string code=WholesaleRules.TermCode(l.Terms??"");
            head+=(code.Length>0&&Array.IndexOf(WholesaleRules.TermCodes,code)>=0?", "+code:"")+")";
            string reasons=v.Reasons.Count>0?" · "+String.Join(" · ",v.Reasons.Select(x=>Plain(x)).ToArray()):"";
            string problems=v.Problems.Count>0?" · **can't read:** "+String.Join("; ",v.Problems.Select(x=>Plain(x)).ToArray())+" (not sold; tried again every 5 minutes, hourly after an hour)":"";
            string tags=WholesaleComment.TagText(v.Tags);
            switch(v.Action) {
                case "sell": return head+(dry?": would **Sell, then Cancel**":": **sold** (Sell, then Cancel)")+reasons;
                case "flag": return head+(dry?": would flag ":": flagged ")+"**"+(tags.Length>0?tags:"(no tags)")+"**"+(v.Go?(v.KeepGo?" (staff's go kept until it can be read)":" (after staff's go)"):"")+reasons+problems;
                case "skip": return null;
                default: return v.Problems.Count>0?head+": "+(tags.Length>0?"found **"+tags+"**; ":"")+"left as it is"+reasons+problems:null;
            }
        }
    }
}
