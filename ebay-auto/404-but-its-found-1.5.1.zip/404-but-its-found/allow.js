// 1.4.2: asks Chrome to let this extension reach the receiver at one shop-network address
// (Chrome 156+ needs this; its Allow box does not show reliably from the popup, so it is asked here).
const $ = id => document.getElementById(id);
const site = new URLSearchParams(location.search).get('site') || '';
const m = site.match(/^https:\/\/(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\/\*$/);
const b = m ? m.slice(1, 5).map(Number) : [];
const valid = !!m && b.every(n => n <= 255) &&
  (b[0] === 10 || (b[0] === 192 && b[1] === 168) || (b[0] === 172 && b[1] >= 16 && b[1] <= 31) || (b[0] === 127 && b[1] === 0 && b[2] === 0 && b[3] === 1));
function say(text, tone) { $('msg').textContent = text; $('msg').className = 'msg' + (tone ? ' ' + tone : ''); }
(async () => {
  if (!valid) { $('what').textContent = "This page only works when it is opened from the 404 popup's Connect button."; return; }
  const host = b.join('.');
  $('what').innerHTML = '';
  $('what').append('Click Allow so the 404 extension can send eBay orders to the Ebay-auto receiver at ', Object.assign(document.createElement('code'), { textContent: host }), '. Chrome then asks once more: choose Allow there too.');
  if (await chrome.permissions.contains({ origins: [site] })) { say('Already allowed ✓ Close this tab, click the 404 icon and Connect.', 'ok'); return; }
  $('allow').disabled = false;
  $('allow').addEventListener('click', async () => {
    let granted = false;
    try { granted = await chrome.permissions.request({ origins: [site] }); } catch (e) { granted = false; }
    if (granted) { $('allow').disabled = true; say('Allowed ✓ Close this tab, click the 404 icon and Connect.', 'ok'); }
    else say("Not allowed yet. Click Allow again, and choose Allow in Chrome's box.", 'bad');
  });
})();
