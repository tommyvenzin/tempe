# Ebay-auto 1.1.11 validation - 27 November 2026

## Diagnostics upload to GitHub (extension unchanged, 1.6.1)

All validation was local and isolated: Windows 11, Windows PowerShell 5.1, the .NET Framework 4.8 C# compiler (`/langversion:5`) and Node 24. No installed app was changed, no receiver or worker was started, COSTAR and Chrome were not touched, and no live order was sent. **Nothing was tried against the real GitHub, on Seb's PC or inside Remote Desktop.** Every GitHub answer below came from a fake GitHub on 127.0.0.1, and every token was made up.

Isolation: the compile and the self-tests ran with USERPROFILE, LOCALAPPDATA, APPDATA, TEMP and TMP all pointed at a fresh short folder (`%TEMP%\dfx-<n>`), removed afterwards. .NET's `GetFolderPath` follows USERPROFILE, not the LOCALAPPDATA variable. The executable was built in that folder, not in `build\`. Afterwards the real `%LOCALAPPDATA%\EbayAuto` and `%LOCALAPPDATA%\TempeMobileCostar` listings (names, sizes, times) were unchanged, and `%LOCALAPPDATA%\TempeDiagnosticsUpload` still did not exist.

| Suite | Result |
|---|---|
| C# 5 / .NET Framework 4.8 compile (73 sources, including `DiagUpload.cs` and `DiagUploadTests.cs`) | passed: 0 errors, the same 5 warnings as 1.1.10 |
| Application self-tests (`EbayAuto.exe --self-test`) | **275 groups passed** (271 in 1.1.10, plus 4 new), exit code 0, no FAIL lines |
| Order Check self-tests | 16 groups passed, 0 failed |
| Extension payload / parser / background / routing (`node Tests/...`) | 14 / 20 / 9 / 8 groups passed |
| Release configuration (`test-release-config.cjs`) | 7 checks passed (5 in 1.1.10, plus the unchanged-extension check and the packagers' refusal of stale notes or builds) |
| JavaScript syntax (`node --check`, every `Extension/*.js`) | all 5 passed |
| End-to-end (`e2e-branch.cjs`, headless Chrome) | **not run**: this validation was not allowed to start Chrome |

Total: 349 automated groups and checks passed, 0 failed. The browser suite was not run.

### The four new self-test groups (EbayAutoTests.Cases1111)

- **DiagUpload's own self-tests** (`DiagUploadTests.cs`, the same file as the Tempe helper 2.9.20's, copied byte for byte): 29 cases, 2756 checks, 0 failures, about 10 s, after the second review's fixes (below). They cover:
  - upload and setup paths and their names, masking, token and file-name shapes;
  - not set up, an unreadable token file, and bad or refused tokens;
  - setup, a second setup, and DPAPI keeping (never plain text, never without entropy);
  - a token that can't be kept (read-only, held open, a folder in its place): not kept, and nothing half-written left;
  - Remove while GitHub is still checking a token: the token is not kept afterwards; a Remove just as the token is kept takes it off again; a `removed.txt` dated a day ahead (the clock set back since) doesn't stop a setup;
  - a setup whose small setup file GitHub answers too late, or is busy for three times: the window's own words ("click Save again"), nothing kept; busy once: kept;
  - Remove deleting the token and anything half-written;
  - the token file being read while the other app holds it open;
  - the upload's bytes, base64 pieces and commit message for the helper, `ebay-receiver` and `ebay-worker`;
  - a public or wrong repository (nothing sent), every GitHub status, 409 retries, and redirects never followed;
  - bad, missing and over-40 MB files (nothing sent), and network failures;
  - the time an upload is allowed, from its size; an upload GitHub answers too late, never answers or reads too slowly ends as *too slow* and is not sent again; a repository check that is never answered ends as a network failure, with nothing uploaded;
  - the token page Open GitHub opens: GitHub's template address with the name (40 characters at most), owner `tommyvenzin`, no expiry and Contents: Read and write, for odd PC names too;
  - the window, built but never shown: its words for each state, that every label and button fits at this PC's scaling and long messages make it taller, not wider, that the person can't close it while a token is being checked while Windows signing out, the app exiting and its owner window closing still do, and that an `&` in GitHub's words shows as itself;
  - no token in any result.

  After the run, DiagUpload's GitHub address and token folder are checked to be back to their defaults. The tests put DiagUpload's times back themselves. If the window case ever ran past its 30 s, they would instead be left pointed at the test folder and at no server (and the tests fail), so its thread could never reach the real token or GitHub.
- **The words and the day log.** This group checks the exact save, uploaded, not-uploaded and not-set-up texts, and the parts' names. It checks the More tab's line for each state: *not set up for this Windows login*, *the token kept for this Windows login can't be read*, and *set up for this Windows login*, never "this PC". It checks that `EbayAutoDiagnostics.SaveName` makes the name DiagUpload takes (`Ebay-auto-Receiver-Diagnostics-<yyyyMMdd-HHmmss>.zip`, `...Worker...`). The day log line must be one of DiagUpload's fixed codes (now with `too_slow` and `removed`), plus `path=` only for a real upload path, and never GitHub's words or a token. An unknown code is logged as `failed`. A token in GitHub's words is masked on screen too.
- **Off the window's thread, only the saved ZIP.** Without a token nothing is sent and the save message says not set up. With a token, the upload runs on a pool thread, never the calling thread. The save returns in under 1 s while the made-up upload takes 1.5 s. Exactly the saved ZIP's path is sent, with its part's name and 1.1.11. A refusal, a thrown exception and no answer each end as *Not uploaded to GitHub: ... send it by hand* with only the code logged, and nothing is thrown. A window gone before the upload ends breaks nothing. Building a diagnostics ZIP never uploads, including the receiver's ZIP fetched by the worker (`ReceiverBundle`) and the worker's own ZIP.
- **The masker** (`Sanitize.Text`, used by the day log, the journey and the diagnostics' queue and run text). Fine-grained `github_pat_` tokens and `ghp_`/`gho_`/`ghu_`/`ghs_`/`ghr_` tokens become `[token]` whole, before the number rule, so no pieces are left between `[number]`s. A token cut at the length limit is never left partly visible. Product codes and words such as `ghost_rider` are kept, and the phone and email rules are unchanged. DiagUpload's exact repository path shape (`uploads/<date>/<time>-<app>-<version>-<PC>.zip`) is kept whole, so the day log says where a ZIP went. Numbers around such a path are still masked, and near-miss shapes are masked as before.

### Packages

`package-release.cjs` had **not been run** when this was written: it writes the release outputs. Its results are in `package-checks-1.1.11.txt`.

- Both packagers now refuse to package anything unless README.md and VALIDATION.md start with `# Ebay-auto 1.1.11 `, `build/self-test-results.txt` starts with `Ebay-auto 1.1.11 self-tests` and has no FAIL line, and `build/EbayAuto.exe` is 1.1.11. The version is read from the executable's metadata (`Product.Version`, without running any of its code). They also refuse when `build/EbayAuto.exe`, `build/self-test-results.txt` or `build/compiler-output.txt` (all three go in the packages) is older than the newest `Source/*.cs`, or the report is older than the exe, so a build of earlier 1.1.11 sources isn't packaged either. `test-release-config.cjs` checks that these refusals come before each packager's package loop, and that both packagers publish the same date (2026-11-27).
- The Node packager's opening checks were run on their own, on a scratch copy of the few files they read (the copy stops before the package loop, so nothing was packaged). With 1.1.11 notes, this build's report and this build's executable they passed. Each of these was refused: the 1.1.10 README.md or VALIDATION.md, a README starting `1.1.110` or with the heading further down, the 1.1.10 report, a report with a FAIL line or no summary, the 1.1.10 `build\EbayAuto.exe`, a file that isn't a .NET executable, and no executable.
- `test-release-config.cjs` failed, as it should, on each of six scratch copies of the packagers with one check removed or the date changed.
- `release/404-but-its-found-1.6.1.zip` still matches `Extension/` byte for byte (13 files). The 1.1.11 packagers (`extensionChanged = false`, Python `extension_changed = False`) only read it and never rewrite it. The previous release is 1.1.10, with templates from `release/Ebay-auto-*-v1.1.10` and the published feed `publish-1110/ebay-auto/latest.json`.
- `package-release.py` (kept in step for `test-release-config.cjs`) could not be run: there is no Python here.

### Second review

A second review of all of the above upheld 7 points, all fixed before packaging:

- Remove is now told by `removed.txt` changing during the check, not by comparing times, so a clock set back can't block every setup; the check is made again right after the token is kept, and a Remove just then takes it off again.
- In the setup window, a setup file GitHub answers too late or is busy for says "click Save again" instead of the ZIP's advice.
- While a token is checked only a close by the person is refused (tested now for Windows signing out, the app exiting, the owner window, Task Manager); an `&` in GitHub's words shows as itself.
- The window test can no longer reach the real token folder if it outlives its 30 s (see above).
- DiagUpload's comment on time limits is corrected (1.5 MB gets 108 s; a stalled upload ends when its time runs out).
- The packagers refuse a build older than the sources (above).

Six breakages of these fixes were each run against DiagUploadTests (built alone with a stub, isolated as above) and each failed it; DiagUpload.cs and DiagUploadTests.cs were then copied from the helper again, byte for byte.

## NOT tested

- **The real GitHub.** Not tested: the repository itself (Claude creates it, private, before release), a real fine-grained token, GitHub's real answers (repository check, contents API, size limits, rate limits), the upload through a proxy or firewall, and the time a multi-MB ZIP takes.
- **The token page.** The address Open GitHub opens follows GitHub's documented template parameters and is checked by the self-tests, but it was never opened. Whether GitHub fills in the name, owner, no expiry and Contents: Read and write has not been seen.
- **Seb's PC and Remote Desktop.** Setup, DPAPI keeping and an upload under Seb's Windows login, and under the worker's login inside Remote Desktop, have never been tried. Neither has sharing the token with the helper 2.9.20 under the same login.
- **On screen.** Nobody has looked at the GitHub upload window, the More tab's new button and line, the tray item, or the balloons. The window's layout was checked only by the self-tests, built but never shown, at this PC's scaling; other scalings were not tried.
- **An update while an upload runs.** The switch doesn't wait for an upload. An upload cut short by the switch should leave nothing in the repository (a contents-API upload is one request), and the ZIP stays saved. This was not tried.

Watch the first setup on each part, and the first export after it. The file should appear under `uploads/`.

## Original 1.1.10 release validation

## Customer-phone fixes (extension 1.6.1)

Release validation is local and isolated. No installed app was changed and no live COSTAR entry was performed. Publication does not mean these new behaviours have been tested in COSTAR.

- Windows C# 5/.NET Framework compilation: 0 errors, the same 5 warnings listed for the release baseline.
- Application self-tests: **271 groups passed**, including 8 new billing-phone groups and 5 new incomplete-customer groups. Home/Bus matches, X/Y separation, live reads, cached maps, retry detection and account confirmation are covered with made-up controls; no COSTAR window was opened or modified.
- Order Check self-tests: **16 groups passed**.
- Node tests: **14 payload, 20 parser, 9 background, 8 routing and 5 release-configuration groups passed**. All extension JavaScript syntax checks passed.
- Total: **343 test groups passed**. The old expectation that missing buyer/recipient names must reject the order was updated to require missing-field reporting and to prove no name is borrowed from the other panel.
- The full runner then attempted `Tests/e2e-branch.cjs`, but Chrome did not start (`no DevToolsActivePort`). A diagnostic rerun captured Chrome exit 4294930433 with Crashpad reporting `crash server failed to launch, self-terminating`. The isolated browser launcher now records early process failure and stderr; no security bypass or real browser profile was used. The browser integration suite therefore **did not run to completion**, and the full script exited with failure. This is not recorded as an end-to-end pass. See `build/contact-phone-validation.txt` and `build/self-test-results.txt`.
- Read-only review checked the actual lookup, header/cache guards, retry and final-verification wiring as well as account-creation eligibility. Existing non-eBay matching and global online-order validation remain unchanged.

Diagnostic basis: `Ebay-auto-Receiver-Diagnostics-20261123-110554(1).zip`, including its worker export. Run `20261123-090016-J-NCNHCQ-7da7cc` shows Contact info returning Account# blank, the old Ship to fallback running, then the phone-mismatch stop at 09:00:25 Sydney time. Phone values are masked, so Home/Bus placement is supported by the user's observation and the old Mobile-only code, not exposed phone values in the ZIP.

Watch the first live orders after updating: a Contact-only new customer, an existing customer whose Contact number is in X Home/Bus with Mobile blank, Y keeping its separate Ship to phone, and incomplete customer data entering all known fields then leaving CHECK BY HAND. A previously partial order using a different Ship to number deliberately remains manual; it is never silently switched to another customer.

## 1.1.10 package validation

- Fresh release-version compile and self-tests repeated the 343 passing groups above. The browser suite remains blocked by isolated Chrome startup.
- The receiver package's own Build.ps1 compiled in isolated app data and passed all 271 application + 16 Order Check groups. The worker has byte-identical Source files and Build.ps1 (SHA-256 F86802F74516E04D4D8E87AED94363DFEB5E360955A80D62C5234CFC3736EFB0).
- Automatic approval review stopped the separate worker installer check when an incidental telemetry connection was attempted with an unknown payload. That connection was not approved or retried. The worker's separate installer-process check is therefore incomplete.
- Final packaging uses --skip-build-check, omitting those installer processes. It still compiles and runs the file-only updater verifier, replaying both packages through the current and published 1.1.9 updaters, and checks ZIP content, source parity, manifest hashes and feed sizes/hashes. See package-checks-1.1.10.txt for the completed results; SKIPPED installer lines refer to this final packaging run.

## Original 1.1.9 release validation

Receiver and worker 1.1.9 (protocol 2, payload `tempe.ebay-order.v3`); extension 1.6.0. Built and tested locally on Windows 11 with Windows PowerShell 5.1, the .NET Framework 4.8 C# compiler and Node 24. These totals come from a fresh re-run on 20 November 2026, just before packaging.

## Automated results

| Suite | Result |
|---|---|
| C# 5 / .NET Framework 4.8 compile (`/langversion:5`) | passed: 0 errors, 5 existing warnings |
| Application self-tests (`EbayAuto.exe --self-test`, short TEMP) | 258 groups passed, no FAIL lines, exit code 0 |
| Order Check self-tests | 16 groups passed, 0 failed |
| Extension payload (`test-costar-send.cjs`) | 13 groups passed |
| Extension parser/formatter (`test-phone-parser.cjs`) | 20 groups passed |
| Extension background gate (`test-background.cjs`) | 9 groups passed |
| Sydney/Tempe routing (`test-routing.cjs`) | 8 groups passed |
| Release configuration (`test-release-config.cjs`, now also checks the Node packager) | 5 checks passed |
| JavaScript syntax (`node --check`, every `Extension/*.js` and `Tests/*.cjs`) | all passed |
| End-to-end (`e2e-branch.cjs`) | 20 scenarios passed |

Total: 349 automated groups and checks passed, 0 failed.

The end-to-end test runs the real extension panel in headless Chrome, then the real `background.js`, then the real receiver code in a test host, then a scripted worker. It covers both buttons, the confirmations, Cancel, double-send protection, the cross-branch CONFLICT, Remove-then-resend in the other branch, per-branch waiting, and a stored 1.1.8 (v2) receipt sent again for Sydney.

The self-tests cover:

- Routing rule parity between C# and JavaScript.
- Strict v3 validation: suggestion mismatch, missing confirmation and unknown branch are refused.
- A v2 send is refused with the update message; a stored v2 receipt is accepted as Sydney.
- The legacy canonical JSON and hash are byte-identical to 1.1.8, including the title-less resend of a 1.1.8 order.
- Branch conflicts in every receipt state.
- Poll picks only ready branches, oldest first, one order entering at a time across branches.
- Protocol 1 and protocol 2 mismatch messages.
- Health and status fields.
- The per-branch COSTAR choice: earliest start time, sticky while valid, busy keeps its choice, restart, never the other branch.
- The worker's branch-mismatch refusals, branch-named stock prompt text, and the per-branch "COSTAR not open" alerts.

The release packager (`Tests/package-release.cjs`) rebuilds both package folders, checks every file hash, source parity and ZIP bytes, runs the real updater verifier, and runs each packaged Build.ps1 in isolated temporary app data. It also installs the GitHub bundle through the one-click update code of both 1.1.9 and the published 1.1.8: the feed checks, size and SHA-256, the real ZIP extractor, layout and every file hash. That code reads the bundle's files instead of GitHub, and doesn't build, start or switch over anything. Its results are in `release/package-checks-1.1.9.txt`.

**Known intermittent test (existing since 1.1.0, not a 1.1.9 change).** In one of about eight self-test runs on 20 November, the case "Ebay-auto 1.1.0 updates: Update now builds before switching ..." failed once with "A newer version on GitHub is offered (and said once)". That run was the first packaged Receiver Build.ps1. The run after it, and four more runs, passed.

The cause is in the test's timing, not the product. `EbayAutoUpdater` sets the stage to Available inside its lock, then calls `Found` just after the lock is released (`EbayAutoUpdate.cs` around lines 279-284). The test checks `found` as soon as it sees Available, so on a busy PC the call can arrive a moment late. In the app, `Found` only shows the tray balloon. The source was left unchanged for this release. The fix would be for the test to wait for `found` too.

No COSTAR window was opened or modified. No real receiver or worker was launched. No live order was sent, no installed app or extension was changed, and nothing was published.

## NOT tested

- **COSTAR typing in Tempe (Br11).** It has never been run there: Rebill to EBAY, Ship Via DFE, the stock pane layout and ThisBr reading, Next # and the `<number> DFE` clipboard, and account creation in Br11 are all unverified in Tempe. The worker uses the same maps as Sydney.
- **Real Chrome extension install.** Loading the unpacked 1.6.0 extension, its permissions, pairing and the TLS connection to the real receiver were not tested. The e2e test uses plain HTTP to a test host.
- **The stock prompt inside Seb's Remote Desktop session.** It has not been shown there, for either branch.
- **Two real COSTAR instances per branch**, and Sydney and Tempe open together in one Remote Desktop session. The choice logic is tested only with simulated process lists.
- **A live update from 1.1.8.** The published 1.1.8 updater code was tested reading the 1.1.9 feed and installing both packages from the bundle's files. These were not tested: downloading from GitHub Pages, the build and switch-over on the shop PCs, the protocol 1 to 2 hand-over between real parts, and real queued 1.1.8 orders after the update. Simulated stored receipts were tested.
- **Window behaviour of the new branch lines.** The receiver and worker windows, tray and alerts with the new branch lines were not looked at on screen.

Watch the first live Tempe order from start to finish, and the first Sydney order after the update.
