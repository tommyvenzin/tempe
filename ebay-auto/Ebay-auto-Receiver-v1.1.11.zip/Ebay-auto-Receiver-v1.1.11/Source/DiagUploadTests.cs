// Self-tests of DiagUpload (diagnostics upload to GitHub), the same file in the Tempe helper and Ebay-auto: each app's
// own self-test calls DiagUploadTests.Run() and reports the failures it returns (none: all passed), so nothing here
// needs either app's test code.
//
// A fake GitHub runs on 127.0.0.1 (a TcpListener on a free port, so no URL reservation is needed) and answers each case
// from a script; it can also hold a request (to remove the token while GitHub "checks" it, or to be too slow). While
// the tests run, DiagUpload.Api points at it, DiagUpload.Root at a new folder in %TEMP% and its times (CheckTimeoutMs,
// UploadBaseMs, BytesPerSecond, StallMs) are shortened where a case needs it; all are put back afterwards and the folder
// is deleted. The GitHub upload window is built (never shown) on a thread of its own to check its layout and that it
// can't be closed while a token is checked. Nothing goes to the real GitHub, the real token folder is never read or
// changed, and the tokens here are made up. About 10 seconds: 6 of them DiagUpload's own waits after a 409, 2.5 the
// slow-GitHub case's short times running out.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace TempeCostar {
    internal static class DiagUploadTests {
        // Made up, in the shape of a fine-grained token.
        const string Token="github_pat_TEST0000000000000000000000_FakeTokenOneForDiagUploadTests";
        const string Token2="github_pat_TEST1111111111111111111111_FakeTokenTwoForDiagUploadTests";
        const string RepoApi="/repos/tommyvenzin/tempe-diagnostics";
        // No server can listen on port 0, so a connection there fails at once (a closed port takes 2 s on Windows).
        const string Unreachable="http://127.0.0.1:0/";
        static readonly byte[] Entropy=Encoding.UTF8.GetBytes("TempeDiagnosticsUpload/1"); // DiagUpload's own

        // After Run: one line per case ("ok   ..." or "FAIL ...") and how many checks ran.
        internal static List<string> Report=new List<string>();
        internal static int Checks;

        internal static List<string> Run() {
            var failures=new List<string>();
            Report=new List<string>();Checks=0;
            string oldApi=DiagUpload.Api,oldRoot=DiagUpload.Root;
            int oldCheck=DiagUpload.CheckTimeoutMs,oldBase=DiagUpload.UploadBaseMs,oldRate=DiagUpload.BytesPerSecond,oldStall=DiagUpload.StallMs,oldRetry=DiagUpload.RetryMs;
            Action oldKeep=DiagUpload.BeforeKeep;
            windowThread=null;
            IWebProxy oldProxy=null;bool proxySwapped=false;
            CultureInfo oldCulture=Thread.CurrentThread.CurrentCulture;
            // Short: a deep %TEMP% plus the longest test file name must stay under Windows' 248/260 characters.
            string folder=Path.Combine(Path.GetTempPath(),"DiagUpT-"+Guid.NewGuid().ToString("N").Substring(0,12));
            Hub github=null,elsewhere=null;
            try {
                Directory.CreateDirectory(folder);
                DiagUpload.Root=Path.Combine(folder,"token");
                // The fake GitHub is reached directly: never through a proxy, and Windows' proxy detection isn't waited for.
                oldProxy=WebRequest.DefaultWebProxy;WebRequest.DefaultWebProxy=null;proxySwapped=true;
                github=new Hub();elsewhere=new Hub();
                DiagUpload.Api=github.Url;
                new Suite(failures,github,elsewhere,folder).All();
            } catch(Exception e) {
                failures.Add(Mask("DiagUpload tests stopped: "+e.GetType().Name+": "+DiagUpload.Clip(e.Message)));
            } finally {
                // A window case that didn't end (a very slow PC) still uses DiagUpload: it stays pointed at the test folder
                // and at no server, so it can never reach the real token or GitHub (this process is a self-test).
                bool stuck=WindowStillRunning();
                if(stuck) { DiagUpload.Api=Unreachable;failures.Add("DiagUpload tests: the window case was still running, so DiagUpload was left pointed at the test folder"); }
                else { DiagUpload.Api=oldApi;DiagUpload.Root=oldRoot; }
                DiagUpload.CheckTimeoutMs=oldCheck;DiagUpload.UploadBaseMs=oldBase;DiagUpload.BytesPerSecond=oldRate;DiagUpload.StallMs=oldStall;DiagUpload.RetryMs=oldRetry;
                DiagUpload.BeforeKeep=oldKeep;
                if(proxySwapped) { try { WebRequest.DefaultWebProxy=oldProxy; } catch(Exception) { } }
                Thread.CurrentThread.CurrentCulture=oldCulture;
                if(github!=null) github.Stop();
                if(elsewhere!=null) elsewhere.Stop();
                if(!stuck) { try { if(Directory.Exists(folder)) Directory.Delete(folder,true); } catch(Exception) { } }
            }
            return failures;
        }
        static Thread windowThread;
        static bool WindowStillRunning() {
            var t=windowThread;
            return t!=null&&!t.Join(5000);
        }

        static string Mask(string s) { return (s??"").Replace(Token,"[test token]").Replace(Token2,"[test token 2]"); }

        sealed class Suite {
            readonly List<string> failures;readonly Hub github,elsewhere;readonly string folder,machine;
            readonly List<DiagUploadResult> results=new List<DiagUploadResult>();
            // DiagUpload's times as the app has them: put back after every case.
            readonly int checkMs,baseMs,rate,stallMs,retryMs;
            string name="",note,goodZip;byte[] goodBytes;

            internal Suite(List<string> failures,Hub github,Hub elsewhere,string folder) {
                this.failures=failures;this.github=github;this.elsewhere=elsewhere;this.folder=folder;machine=DiagUpload.Machine();
                checkMs=DiagUpload.CheckTimeoutMs;baseMs=DiagUpload.UploadBaseMs;rate=DiagUpload.BytesPerSecond;stallMs=DiagUpload.StallMs;retryMs=DiagUpload.RetryMs;
            }

            internal void All() {
                if(!Pointed()) { failures.Add("DiagUpload tests didn't start: not pointed at the test folder and the fake GitHub");return; }
                // Over two of DiagUpload's base64 pieces (3*16384 bytes) and not a multiple of 3.
                goodZip=Zip("Tempe-COSTAR-Diagnostics-20261126-173012.zip",3*16384*2+7);goodBytes=File.ReadAllBytes(goodZip);
                Case("names",Names);
                Case("masking",Masking);
                Case("shapes",Shapes);
                Case("the token page",TokenPage);
                Case("the window's words",WindowWords);
                Case("time allowed",TimeAllowed);
                Case("not set up",NotSetUp);
                Case("bad tokens",BadTokens);
                Case("set up refused",SetUpRefused);
                Case("set up",SetUpOk);
                Case("set up again",SetUpAgain);
                Case("upload",UploadOk);
                Case("upload sizes and app names",UploadSizes);
                Case("token file open in the other app",TokenFileShared);
                Case("not private",NotPrivate);
                Case("GitHub's answers",Answers);
                Case("busy once (409)",BusyOnce);
                Case("busy (409 three times)",Busy);
                Case("redirects",Redirects);
                Case("bad files",BadFiles);
                Case("too big",TooBig);
                Case("network",Network);
                Case("slow GitHub",SlowGitHub);
                Case("set up, GitHub slow or busy",SetUpSlowOrBusy);
                Case("not kept",NotKept);
                Case("removed while checking",RemovedWhileChecking);
                Case("the window",Window);
                Case("forget",ForgetToken);
                Case("no token in any result",NoTokenAnywhere);
            }

            // ---- the cases ----
            void Names() {
                var at=new DateTime(2026,11,26,17,30,12,345);
                const string up="uploads/2026-11-26/173012-345-";
                Same(DiagUpload.UploadPath(at,"helper","2.9.20","RDPPC"),up+"helper-2.9.20-RDPPC.zip","upload path");
                Same(DiagUpload.UploadPath(at,"ebay-receiver","1.1.11","FRONT DESK"),up+"ebay-receiver-1.1.11-FRONT-DESK.zip","a space in the PC name");
                Same(DiagUpload.UploadPath(at,"ebay-worker","1.1.11","back/office\\pc"),up+"ebay-worker-1.1.11-back-office-pc.zip","slashes in the PC name");
                Same(DiagUpload.UploadPath(at,"helper","2.9.20","..PC-1.."),up+"helper-2.9.20-PC-1.zip","dots at the ends of the PC name");
                Same(DiagUpload.UploadPath(at,"helper","2.9.20",""),up+"helper-2.9.20-PC.zip","an empty PC name");
                Same(DiagUpload.UploadPath(at,"helper","2.9.20",null),up+"helper-2.9.20-PC.zip","no PC name");
                Same(DiagUpload.UploadPath(at,"helper","2.9.20","/../"),up+"helper-2.9.20-PC.zip","a PC name of slashes and dots");
                string german="B"+(char)0xFC+"ro",russian=new string(new[]{ (char)0x41F,(char)0x41A }); // B-u-umlaut-ro, "PK" in Cyrillic
                Same(DiagUpload.UploadPath(at,"helper","2.9.20",german+" "+russian),up+"helper-2.9.20-B-ro.zip","letters outside A-Z");
                Same(DiagUpload.UploadPath(at,"helper","2.9.20",new string('M',100)),up+"helper-2.9.20-"+new string('M',32)+".zip","a very long PC name");
                Same(DiagUpload.UploadPath(at,"helper","2.9.20","ABCDEFGHIJKLMNOPQRSTUVWXYZ01234.-rest"),up+"helper-2.9.20-ABCDEFGHIJKLMNOPQRSTUVWXYZ01234.zip","a long PC name cut at a dot");
                Same(DiagUpload.UploadPath(at,"",null,"PC"),up+"app-0-PC.zip","no app or version");
                Same(DiagUpload.UploadPath(at,new string('a',40),"1.2.3.4.5.6.7.8.9.10","PC"),up+new string('a',24)+"-1.2.3.4.5.6.7.8-PC.zip","a long app name and version");
                Same(DiagUpload.SetupPath(at,"helper","RDP PC"),"setup/20261126-173012-345-helper-RDP-PC.txt","setup path");
                Same(DiagUpload.SetupPath(at,"ebay-worker","../x/"),"setup/20261126-173012-345-ebay-worker-x.txt","setup path, an odd PC name");
                Same(DiagUpload.Name("  spaced  out  ","PC",32),"spaced-out","Name, spaces");
                Same(DiagUpload.Name("a:b*c?d\"e<f>g|h","PC",32),"a-b-c-d-e-f-g-h","Name, characters Windows forbids");
                Same(DiagUpload.Name("\t\r\n","PC",32),"PC","Name, control characters only");
                foreach(string odd in new[]{ "",null," ",".","..","...","-","a/b","a\\b","../../etc/passwd",".hidden.","-x-","a..b","x:y*z?\"<>|","\t",new string('M',300),new string('.',40)+"x",german,russian }) {
                    string p=DiagUpload.UploadPath(at,"helper","2.9.20",odd);
                    var m=Regex.Match(p,@"^uploads/2026-11-26/173012-345-helper-2\.9\.20-([A-Za-z0-9.-]{1,32})\.zip$");
                    Check(m.Success&&Plain(m.Groups[1].Value),"upload path for the PC name \""+odd+"\": "+p);
                    string s=DiagUpload.SetupPath(at,"helper",odd);
                    m=Regex.Match(s,@"^setup/20261126-173012-345-helper-([A-Za-z0-9.-]{1,32})\.txt$");
                    Check(m.Success&&Plain(m.Groups[1].Value),"setup path for the PC name \""+odd+"\": "+s);
                }
                Check(Plain(machine)&&machine.Length<=32,"this PC's name in paths: "+machine);
                // Western digits and the Gregorian year, whatever the PC's culture.
                CultureInfo before=Thread.CurrentThread.CurrentCulture;
                try {
                    foreach(string culture in new[]{ "th-TH","ar-SA","fa-IR" }) {
                        try { Thread.CurrentThread.CurrentCulture=new CultureInfo(culture); } catch(Exception) { continue; }
                        Same(DiagUpload.UploadPath(at,"helper","2.9.20","PC"),up+"helper-2.9.20-PC.zip","upload path in "+culture);
                        Same(DiagUpload.SetupPath(at,"helper","PC"),"setup/20261126-173012-345-helper-PC.txt","setup path in "+culture);
                    }
                } finally { Thread.CurrentThread.CurrentCulture=before; }
            }

            void Masking() {
                Same(DiagUpload.Clip("refused "+Token+" here"),"refused [token] here","a fine-grained token");
                Same(DiagUpload.Clip("ghp_TESTclassic0123456789abcdefABCDEF0123"),"[token]","a classic token");
                Same(DiagUpload.Clip("gho_TEST1 ghu_TEST2 ghs_TEST3 ghr_TEST4"),"[token] [token] [token] [token]","GitHub's other tokens");
                Same(DiagUpload.Clip("Authorization: Bearer "+Token+"\r\n\tnext"),"Authorization: Bearer [token] next","a token, line breaks and a tab");
                Same(DiagUpload.Clip(null),"","nothing");
                Same(DiagUpload.Clip(new string('a',160)),new string('a',160),"160 characters");
                string cut=DiagUpload.Clip(new string('w',150)+" "+Token+" "+new string('z',100));
                Check(cut.Length==163&&cut.EndsWith("...",StringComparison.Ordinal),"a long text isn't cut at 160 characters ("+cut.Length.ToString(CultureInfo.InvariantCulture)+")");
                Check(cut.IndexOf("github_pat",StringComparison.Ordinal)<0&&cut.IndexOf("TEST0000",StringComparison.Ordinal)<0,"a cut text holds part of the token");
                string edge=DiagUpload.Clip(new string('w',155)+Token);
                Check(edge.IndexOf("github_pat",StringComparison.Ordinal)<0&&edge.IndexOf("TEST0000",StringComparison.Ordinal)<0,"a token where the text is cut is partly left");
            }

            void Shapes() {
                Check(DiagUpload.TokenShape.IsMatch(Token)&&DiagUpload.TokenShape.IsMatch(Token2),"the test tokens aren't token-shaped");
                Check(DiagUpload.TokenShape.IsMatch("github_pat_"+new string('A',20))&&DiagUpload.TokenShape.IsMatch("github_pat_"+new string('A',250)),"a token of 20 or 250 characters after github_pat_ isn't taken");
                foreach(string t in new[]{ "github_pat_"+new string('A',19),"github_pat_"+new string('A',251),"ghp_"+new string('A',36),"github_pat_TEST-000000000000000000000","GITHUB_PAT_"+new string('A',30)," github_pat_"+new string('A',30),"github_pat_TEST000000000 0000000000" })
                    Check(!DiagUpload.TokenShape.IsMatch(t),"the token shape takes \""+t+"\"");
                foreach(string n in new[]{ "Tempe-COSTAR-Diagnostics-20261126-173012.zip","Ebay-auto-Worker-Diagnostics-20261126-173012.zip","Ebay-auto-Receiver-Diagnostics-20261126-173012.zip" })
                    Check(DiagUpload.DiagnosticsName.IsMatch(n),"a diagnostics ZIP name isn't taken: "+n);
                foreach(string n in new[]{ "report.zip","Tempe-COSTAR-Diagnostics-.zip","Tempe-COSTAR-Diagnostics-20261126-173012.zip.exe","Tempe-COSTAR-Diagnostics-20261126-173012_zip",
                    "Tempe-COSTAR-Diagnostics-20261126-173012Xzip","Tempe-COSTAR-Diagnostics-2026 1126.zip","Tempe-COSTAR-Entry-20261126-173012.zip","Ebay-auto-Diagnostics-20261126-173012.zip",
                    "Ebay-auto-Settings-Diagnostics-20261126-173012.zip","x-Tempe-COSTAR-Diagnostics-20261126-173012.zip" })
                    Check(!DiagUpload.DiagnosticsName.IsMatch(n),"not a diagnostics ZIP name, but taken: "+n);
                Check(DiagUpload.MaxBytes==40L*1024*1024,"MaxBytes isn't 40 MB");
                Check(DiagUpload.RepoName=="tommyvenzin/tempe-diagnostics","the repository is "+DiagUpload.RepoName);
            }

            // GitHub's template URL for a new fine-grained token: a name of at most 40 characters, the owner, no expiry and
            // Contents: Read and write; never the token, whatever the PC is called.
            void TokenPage() {
                Same(DiagUpload.TokenPageFor("RDPPC"),DiagUpload.TokenPage+"?name=Tempe%20diagnostics%20RDPPC&description=Uploads%20diagnostics%20ZIPs%20to%20tempe-diagnostics"+
                    "&target_name=tommyvenzin&expires_in=none&contents=write","the token page for RDPPC");
                string german="B"+(char)0xFC+"ro",russian=new string(new[]{ (char)0x41F,(char)0x41A });
                var named=new Dictionary<string,string> { { "RDPPC","RDPPC" },{ "FRONT DESK","FRONT-DESK" },{ "DESKTOP-0A1B2C3","DESKTOP-0A1B2C3" },{ "","PC" },
                    { new string('M',100),new string('M',22) },{ "ABCDEFGHIJKLMNOPQRSTU-VWXYZ","ABCDEFGHIJKLMNOPQRSTU" },{ german+" "+russian,"B-ro" },{ russian,"PC" },
                    { "a&b=c?d#e%f+g","a-b-c-d-e-f-g" },{ "  spaced  out  ","spaced-out" } };
                foreach(var kv in named) Same(Value(Query(DiagUpload.TokenPageFor(kv.Key)),"name"),"Tempe diagnostics "+kv.Value,"the token's name for the PC \""+kv.Key+"\"");
                Same(Value(Query(DiagUpload.TokenPageFor(null)),"name"),"Tempe diagnostics PC","the token's name for no PC name");
                foreach(string odd in new[]{ "RDPPC",machine,"",null," ","..","../../etc/passwd",new string('M',300),new string('.',40)+"x","x"+new string('-',60),german,russian,
                    german+" "+russian,"a&b=c?d#e%f+g","\t\r\n","100% "+new string((char)0x4E2D,20),Token,"ghp_TESTclassic0123456789abcdefABCDEF0123" }) {
                    string url=DiagUpload.TokenPageFor(odd),what="the token page for the PC \""+odd+"\": "+url;
                    Uri u;
                    Check(url.StartsWith(DiagUpload.TokenPage+"?",StringComparison.Ordinal),what);
                    Check(Uri.TryCreate(url,UriKind.Absolute,out u)&&u.Scheme=="https"&&u.Host=="github.com"&&u.AbsolutePath=="/settings/personal-access-tokens/new","not a GitHub address: "+what);
                    Check(Regex.IsMatch(url,@"^[\x21-\x7e]+$"),"not plain ASCII without spaces: "+what);
                    // (A PC named like a token still gives only a cut, dashed name: github-pat-TEST...)
                    Check(!Regex.IsMatch(url,@"github_pat_|gh[pousr]_")&&url.IndexOf(Token,StringComparison.Ordinal)<0,"a token in "+what);
                    var q=Query(url);
                    string n=Value(q,"name")??"";
                    Check(n.StartsWith("Tempe diagnostics ",StringComparison.Ordinal)&&n.Length<=40&&Plain(n.Substring(Math.Min(n.Length,18))),"the name \""+n+"\" ("+n.Length.ToString(CultureInfo.InvariantCulture)+" characters): "+what);
                    Check(Value(q,"target_name")=="tommyvenzin"&&Value(q,"expires_in")=="none"&&Value(q,"contents")=="write","owner, expiry or contents: "+what);
                    Check(Value(q,"description")=="Uploads diagnostics ZIPs to tempe-diagnostics","description: "+what);
                    Check(q.Count==5&&url.Split('&').Length==5,"not the five parameters: "+what);
                    // The steps name it as the page does (a PC's own name has at most 15 characters).
                    if(DiagUpload.Name(odd,"PC",32).Length<=15) Check(DiagUploadForm.Steps(odd).Contains("(Tempe diagnostics "+DiagUpload.Name(odd,"PC",32)+")")&&DiagUploadForm.Steps(odd).Contains("("+n+")"),"the steps don't give the page's name "+n);
                }
            }

            // What the window says (pure): the three states, and the steps.
            void WindowWords() {
                string none=DiagUploadForm.StateWords(false,false),unread=DiagUploadForm.StateWords(true,false),set=DiagUploadForm.StateWords(true,true);
                Same(DiagUploadForm.StateWords(false,true),none,"no token file, whatever usable says");
                Check(none.StartsWith("Not set up for this Windows login",StringComparison.Ordinal),"not set up: "+none);
                Check(unread.Contains("can't be read")&&unread.Contains("Save")&&unread.Contains("Remove")&&!unread.StartsWith("Set up",StringComparison.Ordinal),"kept but unreadable: "+unread);
                Check(set.StartsWith("Set up for this Windows login",StringComparison.Ordinal)&&set.Contains("uploaded")&&!set.Contains("can't")&&!set.Contains("Not set up"),"set up: "+set);
                Check(none!=unread&&unread!=set&&none!=set,"two states say the same");
                foreach(string s in new[]{ none,unread,set }) Check(!s.Contains("set up on this PC")&&!s.Contains("Set up on this PC"),"per PC, not per Windows login: "+s);
                string steps=DiagUploadForm.Steps("RDP PC");
                Check(steps.Contains(DiagUpload.RepoName)&&steps.Contains("each Windows login")&&steps.Contains("(Tempe diagnostics RDP-PC)")&&steps.Contains("Only select repositories")&&
                    steps.Contains("Contents: Read and write")&&steps.Contains("signed in as "+DiagUpload.Owner),"the steps: "+steps);
                int one=steps.IndexOf("\n1. ",StringComparison.Ordinal),two=steps.IndexOf("\n2. ",StringComparison.Ordinal),three=steps.IndexOf("\n3. ",StringComparison.Ordinal);
                Check(one>0&&two>one&&three>two&&steps.IndexOf("\n4. ",StringComparison.Ordinal)<0,"the steps aren't 1, 2, 3 in order");
                Check(Regex.Replace(steps,"\r\n","").IndexOfAny(new[]{ '\r','\n' })<0,"a line break that isn't \\r\\n (a Label shows it as a box)");
            }

            // How long GitHub gets: the check 30 s; the upload 60 s plus 1 s for every 32 KB, at most 30 minutes.
            void TimeAllowed() {
                Check(DiagUpload.CheckTimeoutMs==30000&&DiagUpload.UploadBaseMs==60000&&DiagUpload.BytesPerSecond==32*1024&&DiagUpload.StallMs==120000,"the times aren't the shipped ones: "+
                    String.Format(CultureInfo.InvariantCulture,"{0}, {1}, {2}, {3}",DiagUpload.CheckTimeoutMs,DiagUpload.UploadBaseMs,DiagUpload.BytesPerSecond,DiagUpload.StallMs));
                Same(DiagUpload.UploadTimeoutMs(0),60000,"nothing");
                Same(DiagUpload.UploadTimeoutMs(1),60000,"1 byte");
                Same(DiagUpload.UploadTimeoutMs(-5),60000,"a negative size");
                Same(DiagUpload.UploadTimeoutMs(32767),60999,"just under 32 KB");
                Same(DiagUpload.UploadTimeoutMs(32768),61000,"32 KB");
                Same(DiagUpload.UploadTimeoutMs(goodBytes.Length),63000,"the test ZIP ("+goodBytes.Length.ToString(CultureInfo.InvariantCulture)+" bytes)");
                Same(DiagUpload.UploadTimeoutMs(1536*1024),108000,"1.5 MB");
                Same(DiagUpload.UploadTimeoutMs(DiagUpload.MaxBytes),1340000,"40 MB");
                Same(DiagUpload.UploadTimeoutMs(DiagUpload.MaxBytes+1),1340000,"1 byte over 40 MB");
                long edge=(30L*60*1000-60000)*32768/1000; // the size that gets exactly 30 minutes
                Same(DiagUpload.UploadTimeoutMs(edge-32768),1799000,"just under the cap");
                Same(DiagUpload.UploadTimeoutMs(edge),1800000,"at the cap");
                Same(DiagUpload.UploadTimeoutMs(edge+32768),1800000,"over the cap");
                Same(DiagUpload.UploadTimeoutMs(100L*1024*1024),1800000,"100 MB");
                Same(DiagUpload.UploadTimeoutMs(Int32.MaxValue),1800000,"2 GB");
                Same(DiagUpload.UploadTimeoutMs(1L<<40),1800000,"1 TB");
                int last=0;bool rising=true;
                for(long b=0;b<=200L*1024*1024;b+=777777) { int t=DiagUpload.UploadTimeoutMs(b);if(t<last||t<60000||t>1800000) rising=false;last=t; }
                Check(rising,"the time allowed doesn't grow with the size, or leaves 60 s to 30 min");
                try {
                    DiagUpload.UploadBaseMs=250;DiagUpload.BytesPerSecond=1000;
                    Same(DiagUpload.UploadTimeoutMs(0),250,"a base of 250 ms");
                    Same(DiagUpload.UploadTimeoutMs(1500),1750,"1500 bytes at 1000 a second");
                    DiagUpload.BytesPerSecond=0;
                    Same(DiagUpload.UploadTimeoutMs(7),7250,"a rate of 0 (taken as 1 byte a second)");
                    DiagUpload.BytesPerSecond=-3;
                    Same(DiagUpload.UploadTimeoutMs(7),7250,"a negative rate");
                } finally { Times(); }
                Same(DiagUpload.UploadTimeoutMs(0),60000,"after the times were put back");
            }

            void NotSetUp() {
                Check(DiagUpload.Forget()&&!DiagUpload.HasToken&&!DiagUpload.TokenUsable,"a token was there before the tests");
                github.Script(RepoOk(),Created());
                var r=Upload(goodZip);
                Is(r,"not_set_up","no token");
                Check((r.Why??"").Contains("isn't set up")&&!(r.Why??"").Contains("couldn't be read"),"why: "+r.Why);
                // A token file this Windows user can't use (damaged, empty, kept without the entropy, not a token, or the
                // token as plain text): still not set up, and nothing is sent.
                Directory.CreateDirectory(DiagUpload.Folder);
                var kept=new List<byte[]> { new byte[]{ 1,2,3,4,5 },new byte[0],ProtectedData.Protect(Encoding.UTF8.GetBytes(Token),null,DataProtectionScope.CurrentUser),
                    ProtectedData.Protect(Encoding.UTF8.GetBytes("not a token"),Entropy,DataProtectionScope.CurrentUser),Encoding.UTF8.GetBytes(Token) };
                // Too big to be a token file (over 64 KB): not read at all.
                kept.Add(new byte[64*1024+1]);
                for(int i=0;i<kept.Count;i++) {
                    File.WriteAllBytes(DiagUpload.TokenFile,kept[i]);
                    string what=" ("+i.ToString(CultureInfo.InvariantCulture)+")";
                    Check(DiagUpload.HasToken&&!DiagUpload.TokenUsable,"an unusable token file is taken as usable"+what);
                    r=Upload(goodZip);
                    Is(r,"not_set_up","an unusable token file"+what);
                    Check((r.Why??"").Contains("couldn't be read")&&(r.Why??"").Contains("set up GitHub upload again"),"why: "+r.Why);
                }
                Check(DiagUpload.Forget()&&!DiagUpload.HasToken,"Forget didn't remove an unusable token file");
                Check(github.Connections==0,"GitHub was called without a token");
            }

            void BadTokens() {
                github.Script(RepoOk(),Created());
                foreach(string p in new[]{ null,"","   ","ghp_TESTclassic00000000000000000000000000","github_pat_TEST","github_pat_TEST0000000000000000-dash",
                    "github_pat_TEST0000000000 0000000000","Bearer "+Token,Token+"\"","github_pat_"+new string('A',251) }) {
                    var r=SetUp(p);
                    Is(r,"bad_token","\""+p+"\"");
                    if(p!=null&&p.Trim().Length>0) Check(!(r.Why??"").Contains(p.Trim()),"why repeats what was pasted");
                }
                Check(github.Connections==0,"a bad token was sent to GitHub");
                Check(!DiagUpload.HasToken,"a bad token was kept");
            }

            void SetUpRefused() {
                github.Script(R(200,"{\"full_name\":\"tommyvenzin/tempe-diagnostics\",\"private\":false}"),Created());
                Is(SetUp(Token),"not_private","a public repository");
                Asked(1,"a public repository");
                github.Script(RepoOk(),R(403,"{\"message\":\"Resource not accessible by personal access token\"}"),Created());
                var r=SetUp(Token);
                Is(r,"no_write","no write");
                Check((r.Why??"").Contains("Resource not accessible by personal access token"),"GitHub's words aren't in why: "+r.Why);
                Asked(2,"no write");
                github.Script(R(401,"{\"message\":\"Bad credentials\"}"),Created());
                Is(SetUp(Token),"refused","refused");
                github.Script(R(404,"{\"message\":\"Not Found\"}"),Created());
                Is(SetUp(Token),"no_access","no access");
                DiagUpload.Api=Unreachable;
                Is(SetUp(Token),"network","GitHub unreachable");
                DiagUpload.Api=github.Url;
                Check(!DiagUpload.HasToken,"a token GitHub didn't take was kept");
            }

            void SetUpOk() {
                github.Script(RepoOk(),Created());
                var r=SetUp("  "+Token+" \r\n");
                Is(r,"set_up","set up");
                Check(Regex.IsMatch(r.RepoPath??"","^setup/[0-9]{8}-[0-9]{6}-[0-9]{3}-helper-"+Regex.Escape(machine)+"\\.txt$"),"setup path "+r.RepoPath);
                var seen=Asked(2,"set up");
                if(seen.Count==2) {
                    IsGet(seen[0],Token);
                    string message;byte[] content=IsPut(seen[1],Token,r.RepoPath,out message);
                    string text=content==null?"":Encoding.UTF8.GetString(content);
                    Check(text.StartsWith("GitHub upload set up by helper 2.9.20 on "+machine+" at ",StringComparison.Ordinal),"the setup file: "+text);
                    Check(text.IndexOf(Token,StringComparison.Ordinal)<0,"the setup file holds the token");
                }
                // Kept with DPAPI for this Windows user: the file never holds the token as text.
                Check(DiagUpload.HasToken&&DiagUpload.TokenUsable,"the token wasn't kept");
                byte[] kept=File.Exists(DiagUpload.TokenFile)?File.ReadAllBytes(DiagUpload.TokenFile):new byte[0];
                Check(kept.Length>0&&!Holds(kept,Encoding.UTF8.GetBytes(Token))&&!Holds(kept,Encoding.Unicode.GetBytes(Token))&&!Holds(kept,Encoding.ASCII.GetBytes(Convert.ToBase64String(Encoding.UTF8.GetBytes(Token)))),
                    "the token file holds the token as text");
                Check(KeptToken()==Token,"DPAPI doesn't give the kept token back");
                bool withoutEntropy=true;
                try { ProtectedData.Unprotect(kept,null,DataProtectionScope.CurrentUser); } catch(CryptographicException) { withoutEntropy=false; }
                Check(!withoutEntropy,"the token was kept without DiagUpload's entropy");
                // The token, and when Remove last ran (the tests began with one): nothing else.
                var names=new List<string>();
                foreach(string f in Directory.GetFiles(DiagUpload.Folder)) names.Add(Path.GetFileName(f));
                names.Sort(StringComparer.Ordinal);
                Same(String.Join(", ",names.ToArray()),"github-token.bin, removed.txt","the token folder");
            }

            void SetUpAgain() {
                // A new token replaces the kept one, and uploads then use it.
                github.Script(RepoOk(),Created());
                Is(SetUp(Token2),"set_up","a second token");
                Check(KeptToken()==Token2,"the second token didn't replace the first");
                github.Script(RepoOk(),Created());
                Is(Upload(goodZip),"uploaded","upload with the second token");
                var seen=Asked(2,"upload with the second token");
                foreach(var h in seen) Check(h.Header("Authorization")=="Bearer "+Token2,h.Method+" doesn't use the second token");
                github.Script(RepoOk(),Created());
                Is(SetUp(Token),"set_up","the first token again");
                Check(KeptToken()==Token,"the first token didn't come back");
                Check(!File.Exists(DiagUpload.TokenFile+".new"),"github-token.bin.new was left");
            }

            void UploadOk() {
                github.Script(RepoOk(),Created());
                DateTime before=DateTime.Now;
                var r=Upload(goodZip);
                DateTime after=DateTime.Now;
                Is(r,"uploaded","upload");
                string days=Regex.Escape(before.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture))+"|"+Regex.Escape(after.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture));
                Check(Regex.IsMatch(r.RepoPath??"","^uploads/(?:"+days+")/[0-9]{6}-[0-9]{3}-helper-2\\.9\\.20-"+Regex.Escape(machine)+"\\.zip$"),"upload path "+r.RepoPath);
                var seen=Asked(2,"upload");
                if(seen.Count!=2) return;
                IsGet(seen[0],Token);
                string message;byte[] content=IsPut(seen[1],Token,r.RepoPath,out message);
                Check(content!=null&&Equal(content,goodBytes),"the uploaded content isn't the ZIP's bytes");
                Check(message!=null&&message.Contains("helper 2.9.20"),"commit message: "+message);
                Check(github.Unused==0,"GitHub's answers weren't all used");
            }

            void UploadSizes() {
                int[] sizes={ 4,5,6,1000,3*16384,3*16384+1,3*16384+2 };
                string[][] apps={ new[]{ "Tempe-COSTAR-Diagnostics-20261126-00000{0}.zip","helper","2.9.20" },new[]{ "Ebay-auto-Receiver-Diagnostics-20261126-00000{0}.zip","ebay-receiver","1.1.11" },
                    new[]{ "Ebay-auto-Worker-Diagnostics-20261126-00000{0}.zip","ebay-worker","1.1.11" } };
                for(int i=0;i<sizes.Length;i++) {
                    string[] a=apps[i%apps.Length];
                    string zip=Zip(String.Format(CultureInfo.InvariantCulture,a[0],i),sizes[i]);
                    string what=Path.GetFileName(zip)+", "+sizes[i].ToString(CultureInfo.InvariantCulture)+" bytes";
                    byte[] bytes=File.ReadAllBytes(zip);
                    github.Script(RepoOk(),Created());
                    var r=Upload(zip,a[1],a[2]);
                    Is(r,"uploaded",what);
                    Check((r.RepoPath??"").EndsWith("-"+a[1]+"-"+a[2]+"-"+machine+".zip",StringComparison.Ordinal),what+": "+r.RepoPath);
                    var seen=Asked(2,what);
                    if(seen.Count==2) {
                        string message;byte[] content=IsPut(seen[1],Token,r.RepoPath,out message);
                        Check(content!=null&&Equal(content,bytes),what+": the content isn't the ZIP's bytes");
                        Check(message!=null&&message.Contains(a[1]+" "+a[2]),what+": commit message "+message);
                    }
                    File.Delete(zip);
                }
            }

            // The other app may have the token file open (reading it, or replacing it with a new token): it is still read.
            void TokenFileShared() {
                using(new FileStream(DiagUpload.TokenFile,FileMode.Open,FileAccess.ReadWrite,FileShare.ReadWrite|FileShare.Delete)) {
                    Check(DiagUpload.HasToken&&DiagUpload.TokenUsable,"the token can't be read while the other app has the file open");
                    github.Script(RepoOk(),Created());
                    Is(Upload(goodZip),"uploaded","the token file open in the other app");
                    Asked(2,"the token file open in the other app");
                }
                Check(KeptToken()==Token,"the kept token changed");
            }

            void NotPrivate() {
                foreach(string answer in new[]{ "{\"full_name\":\"tommyvenzin/tempe-diagnostics\",\"private\":false}","{\"full_name\":\"tommyvenzin/tempe-diagnostics\"}",
                    "{\"full_name\":\"tommyvenzin/tempe-diagnostics\",\"private\":\"true\"}","{\"full_name\":\"tommyvenzin/tempe-diagnostics\",\"private\":null}",
                    "{\"full_name\":\"tommyvenzin/tempe-diagnostics\",\"private\":1}","{\"full_name\":\"someone/tempe-diagnostics\",\"private\":true}",
                    "{\"full_name\":\"tommyvenzin/other\",\"private\":true}","{\"name\":\"tempe-diagnostics\",\"private\":true}","[]","not json","" }) {
                    github.Script(R(200,answer),Created(),Created());
                    Is(Upload(goodZip),"not_private",answer);
                    var seen=Asked(1,answer);
                    foreach(var h in seen) Check(h.Method=="GET","uploaded after "+answer);
                }
            }

            void Answers() {
                Expect("the check refused (401)","refused",1,R(401,"{\"message\":\"Bad credentials\"}"));
                var r=Expect("the check not found (404)","no_access",1,R(404,"{\"message\":\"Not Found\"}"));
                // GitHub answers 404 both for a token without the repository and for a repository that isn't there.
                Check((r.Why??"").Contains("Only select repositories, tempe-diagnostics")&&(r.Why??"").Contains("check that repository is there on GitHub"),"why: "+r.Why);
                r=Expect("the check forbidden (403)","failed",1,R(403,"{\"message\":\"Forbidden for "+Token+"\"}"));
                Check((r.Why??"").Contains("[token]"),"GitHub's words with the token in them aren't masked: "+r.Why);
                Expect("the check failing (500)","failed",1,R(500,""));
                Expect("the check answering 204","failed",1,R(204,""));
                r=Expect("the upload forbidden (403)","no_write",2,RepoOk(),R(403,"{\"message\":\"Resource not accessible by personal access token; "+Token+"\"}"));
                Check((r.Why??"").Contains("Resource not accessible by personal access token")&&(r.Why??"").Contains("[token]"),"why: "+r.Why);
                Expect("the upload refused (401)","refused",2,RepoOk(),R(401,"{\"message\":\"Bad credentials\"}"));
                r=Expect("the upload not found (404)","no_access",2,RepoOk(),R(404,"{\"message\":\"Not Found\"}"));
                Check((r.Why??"").Contains("check that repository is there on GitHub"),"why: "+r.Why);
                Expect("the upload invalid (422)","failed",2,RepoOk(),R(422,"{\"message\":\"Invalid request.\"}"));
                Expect("the upload failing (500)","failed",2,RepoOk(),R(500,"not json"));
            }

            void BusyOnce() {
                github.Script(RepoOk(),R(409,"{\"message\":\"is at 1 but expected 2\"}"),Created(),Created());
                var watch=System.Diagnostics.Stopwatch.StartNew();
                var r=Upload(goodZip);
                watch.Stop();
                Is(r,"uploaded","409, then 201");
                var seen=Asked(3,"409, then 201");
                if(seen.Count==3) {
                    string message;
                    byte[] first=IsPut(seen[1],Token,r.RepoPath,out message),second=IsPut(seen[2],Token,r.RepoPath,out message);
                    Check(first!=null&&second!=null&&Equal(first,goodBytes)&&Equal(second,goodBytes),"the second try didn't send the same ZIP");
                }
                Check(watch.ElapsedMilliseconds>=1000,"it didn't wait before trying again ("+watch.ElapsedMilliseconds.ToString(CultureInfo.InvariantCulture)+" ms)");
            }

            void Busy() {
                var busy=R(409,"{\"message\":\"is at 1 but expected 2\"}");
                github.Script(RepoOk(),busy,busy,busy,Created());
                Is(Upload(goodZip),"conflict","409 three times");
                var seen=Asked(4,"409 three times");
                for(int i=1;i<seen.Count;i++) Check(seen[i].Method=="PUT","request "+(i+1).ToString(CultureInfo.InvariantCulture)+" was "+seen[i].Method);
                Check(github.Unused==1,"it tried a fourth time");
            }

            void Redirects() {
                elsewhere.Script(RepoOk(),Created(),RepoOk(),Created(),RepoOk(),Created());
                github.Script(new Reply { Code=301,Location=elsewhere.Url+"repositories/1",Body="{\"message\":\"Moved Permanently\"}" },Created());
                Is(Upload(goodZip),"failed","the check redirected (301)");
                Asked(1,"the check redirected");
                github.Script(RepoOk(),new Reply { Code=307,Location=elsewhere.Url+"repositories/1/contents/x",Body="{\"message\":\"Temporary Redirect\"}" },Created());
                Is(Upload(goodZip),"failed","the upload redirected (307)");
                Asked(2,"the upload redirected");
                // A failed SetUp leaves the kept token as it was.
                github.Script(new Reply { Code=302,Location=elsewhere.Url+"repositories/1" },Created());
                Is(SetUp(Token2),"failed","SetUp redirected (302)");
                Check(KeptToken()==Token,"a failed SetUp changed the kept token");
                Check(elsewhere.Connections==0,"a redirect was followed ("+elsewhere.Connections.ToString(CultureInfo.InvariantCulture)+" connections to where it pointed)");
            }

            void BadFiles() {
                github.Script(RepoOk(),Created());
                foreach(string n in new[]{ "report.zip","settings.json","Tempe-COSTAR-Entry-20261126-173012.zip","Tempe-COSTAR-Diagnostics-20261126-173012.zip.txt",
                    "Tempe-COSTAR-Diagnostics-20261126-173012_zip","Ebay-auto-Settings-Diagnostics-20261126-173012.zip" }) {
                    string path=Zip(n,2000);
                    Is(Upload(path),"bad_file",n);
                    File.Delete(path);
                }
                string right=Path.Combine(folder,"Tempe-COSTAR-Diagnostics-20261126-000001.zip");
                foreach(byte[] bytes in new[]{ Encoding.ASCII.GetBytes("this is not a ZIP"),new byte[0],new byte[]{ 0x50,0x4B,3 },new byte[]{ 0x50,0x4B,3,3,0,0 },new byte[]{ 0x4B,0x50,3,4,0 } }) {
                    File.WriteAllBytes(right,bytes);
                    Is(Upload(right),"bad_file","named right, but "+bytes.Length.ToString(CultureInfo.InvariantCulture)+" bytes that aren't a ZIP");
                }
                File.Delete(right);
                Is(Upload(Path.Combine(folder,"Tempe-COSTAR-Diagnostics-20261126-999999.zip")),"bad_file","a ZIP that isn't there");
                string dir=Path.Combine(folder,"Tempe-COSTAR-Diagnostics-20261126-888888.zip");
                Directory.CreateDirectory(dir);
                Is(Upload(dir),"bad_file","a folder named like a ZIP");
                Directory.Delete(dir);
                Is(Upload(null),"bad_file","no path");
                Is(Upload(""),"bad_file","an empty path");
                Is(Upload(folder+Path.DirectorySeparatorChar+"bad<name>|.zip"),"bad_file","a path Windows can't have");
                Check(github.Connections==0,"GitHub was called for a file that isn't a diagnostics ZIP");
            }

            void TooBig() {
                string path=Path.Combine(folder,"Tempe-COSTAR-Diagnostics-20261126-000002.zip");
                try {
                    // Sparse: only the first 4 bytes are written.
                    using(var f=new FileStream(path,FileMode.Create,FileAccess.Write)) { f.Write(new byte[]{ 0x50,0x4B,3,4 },0,4);f.SetLength(DiagUpload.MaxBytes+1); }
                    github.Script(RepoOk(),Created());
                    var r=Upload(path);
                    Is(r,"too_big","1 byte over 40 MB");
                    Check((r.Why??"").Contains("MB"),"why: "+r.Why);
                    Check(github.Connections==0,"GitHub was called for a ZIP over 40 MB");
                } finally { File.Delete(path); }
            }

            void Network() {
                DiagUpload.Api=Unreachable;
                Is(Upload(goodZip),"network","GitHub unreachable");
                Is(SetUp(Token2),"network","SetUp, GitHub unreachable");
                DiagUpload.Api=github.Url;
                Check(KeptToken()==Token,"SetUp without GitHub changed the kept token");
                // GitHub takes the request and closes the connection without an answer. .NET itself sends a GET once more
                // after that, so the check is left unanswered twice: still nothing is uploaded.
                var drop=new Reply { Drop=true };
                github.Script(drop,drop,RepoOk(),Created());
                Is(Upload(goodZip),"network","no answer to the check");
                var seen=github.Requests;
                Check(seen.Count>=1&&seen.Count<=2,"no answer to the check: "+seen.Count.ToString(CultureInfo.InvariantCulture)+" requests to GitHub");
                foreach(var h in seen) Check(h.Method=="GET","no answer to the check, but a "+h.Method+" was sent");
                github.Script(RepoOk(),new Reply { Drop=true },Created());
                Is(Upload(goodZip),"network","no answer to the upload");
                Asked(2,"no answer to the upload");
            }

            // A slow connection. The upload's time comes from its size, and running out of it is too_slow (soon, with the
            // size in why); the repository check running out of time is network. The times are made short here.
            void SlowGitHub() {
                var watch=new System.Diagnostics.Stopwatch();
                // GitHub answers the upload after 0.6 s: in time, as 0.1 s plus 1 s for every 100 KB is 1.08 s for this ZIP.
                DiagUpload.UploadBaseMs=100;DiagUpload.BytesPerSecond=100*1000;DiagUpload.StallMs=5000;
                Same(DiagUpload.UploadTimeoutMs(goodBytes.Length),100+goodBytes.Length*1000L/100000,"the time allowed for the test ZIP");
                github.Script(RepoOk(),Late(Created(),600));
                Is(Upload(goodZip),"uploaded","GitHub answering the upload after 0.6 s of 1.08 s");
                Asked(2,"GitHub answering the upload after 0.6 s");
                // GitHub takes the upload and doesn't answer: 0.3 s allowed.
                DiagUpload.UploadBaseMs=300;DiagUpload.BytesPerSecond=Int32.MaxValue;DiagUpload.StallMs=300;
                github.Script(RepoOk(),Late(Created(),4000),Created());
                watch.Restart();var r=Upload(goodZip);watch.Stop();
                Is(r,"too_slow","GitHub not answering the upload");
                Quick(watch,"GitHub not answering the upload");
                Check((r.Why??"").Contains("the upload of "+AppData.Bytes(goodBytes.LongLength)+" took too long")&&!NamesToken(r.Why),"why: "+r.Why);
                github.WaitIdle(3000);
                Asked(2,"GitHub not answering the upload");
                Check(github.Unused==1,"the upload was sent again after its time ran out");
                // GitHub reads a 2 MB upload slowly (4 KB every 50 ms): the time runs out while it is still being sent.
                string big=Zip("Tempe-COSTAR-Diagnostics-20261126-000003.zip",2*1024*1024);
                try {
                    github.Script(RepoOk(),new Reply { Code=201,Body=Created().Body,ReadPauseMs=50,HoldMs=700 },Created());
                    watch.Restart();r=Upload(big);watch.Stop();
                    Is(r,"too_slow","GitHub reading a 2 MB upload slowly");
                    Quick(watch,"GitHub reading a 2 MB upload slowly");
                    Check((r.Why??"").Contains("the upload of "+AppData.Bytes(2*1024*1024)+" took too long")&&!NamesToken(r.Why),"why: "+r.Why);
                    github.WaitIdle(3000);
                    var seen=github.Requests;
                    Check(seen.Count==2&&seen[1].Method=="PUT"&&seen[1].Body.Length<2*1024*1024,"GitHub reading slowly: "+seen.Count.ToString(CultureInfo.InvariantCulture)+" requests");
                    Check(github.Unused==1,"the slow upload was sent again");
                } finally { File.Delete(big); }
                // The repository check isn't answered: 0.3 s allowed, then GitHub couldn't be reached and nothing is uploaded.
                DiagUpload.CheckTimeoutMs=300;
                github.Script(Late(RepoOk(),4000),Created(),Created());
                watch.Restart();r=Upload(goodZip);watch.Stop();
                Is(r,"network","GitHub not answering the check");
                Quick(watch,"GitHub not answering the check");
                Check((r.Why??"").StartsWith("GitHub couldn't be reached (",StringComparison.Ordinal)&&!NamesToken(r.Why),"why: "+r.Why);
                github.WaitIdle(3000);
                Asked(1,"GitHub not answering the check");
                github.Script(Late(RepoOk(),4000),Created());
                watch.Restart();r=SetUp(Token2);watch.Stop();
                Is(r,"network","SetUp, GitHub not answering the check");
                Quick(watch,"SetUp, GitHub not answering the check");
                github.WaitIdle(3000);
                Asked(1,"SetUp, GitHub not answering the check");
                Check(KeptToken()==Token,"a SetUp GitHub didn't answer changed the kept token");
            }

            // SetUp's own words when the setup file's upload takes too long or GitHub stays busy: click Save again (the
            // advice for a diagnostics ZIP is not shown in the set-up window), and nothing is kept.
            void SetUpSlowOrBusy() {
                Check(KeptToken()==Token,"no token before the case");
                var watch=new System.Diagnostics.Stopwatch();
                DiagUpload.UploadBaseMs=300;DiagUpload.BytesPerSecond=Int32.MaxValue;DiagUpload.StallMs=300;
                github.Script(RepoOk(),Late(Created(),4000),Created());
                watch.Restart();var r=SetUp(Token2);watch.Stop();
                Is(r,"too_slow","SetUp, GitHub not answering the setup file");
                Quick(watch,"SetUp, GitHub not answering the setup file");
                Same(r.Why,"GitHub took too long to answer on this connection: click Save again","SetUp too slow, why");
                github.WaitIdle(3000);
                Asked(2,"SetUp, GitHub not answering the setup file");
                Check(KeptToken()==Token,"a SetUp that took too long changed the kept token");
                Times();
                DiagUpload.RetryMs=10;
                var busy=R(409,"{\"message\":\"is at 1 but expected 2\"}");
                github.Script(RepoOk(),busy,busy,busy,Created());
                r=SetUp(Token2);
                Is(r,"conflict","SetUp, 409 three times");
                Same(r.Why,"GitHub was busy: click Save again","SetUp busy, why");
                Asked(4,"SetUp, 409 three times");
                Check(github.Unused==1,"SetUp tried a fourth time");
                Check(KeptToken()==Token,"a SetUp GitHub was busy for changed the kept token");
                // Busy once: the setup file goes on the second try and the token is kept.
                github.Script(RepoOk(),busy,Created());
                Is(SetUp(Token2),"set_up","SetUp, 409 then 201");
                Check(KeptToken()==Token2,"the token set up after a 409 wasn't kept");
                github.Script(RepoOk(),Created());
                Is(SetUp(Token),"set_up","the token kept again");
                Check(KeptToken()==Token,"the token wasn't kept again");
            }

            // The token works but can't be kept (the file can't be replaced, or made): not kept, no github-token.bin.new left
            // behind, and the token kept before stays.
            void NotKept() {
                Check(KeptToken()==Token,"no token before the case");
                string temp=DiagUpload.TokenFile+".new";
                try {
                    File.SetAttributes(DiagUpload.TokenFile,FileAttributes.ReadOnly);
                    github.Script(RepoOk(),Created());
                    var r=SetUp(Token2);
                    Is(r,"not_kept","a read-only token file");
                    Check((r.Why??"").StartsWith("the token works, but it couldn't be kept for this Windows login (",StringComparison.Ordinal)&&!NamesToken(r.Why),"why: "+r.Why);
                    Asked(2,"a read-only token file");
                    Check(!File.Exists(temp),"github-token.bin.new was left after the replace failed (read-only)");
                } finally { File.SetAttributes(DiagUpload.TokenFile,FileAttributes.Normal); }
                Check(KeptToken()==Token,"a token that wasn't kept replaced the kept one (read-only)");
                // The other app reading it without letting it be deleted (as File.ReadAllBytes does): it can't be replaced.
                using(new FileStream(DiagUpload.TokenFile,FileMode.Open,FileAccess.Read,FileShare.Read)) {
                    github.Script(RepoOk(),Created());
                    Is(SetUp(Token2),"not_kept","the token file held open");
                    Check(!File.Exists(temp),"github-token.bin.new was left after the replace failed (held open)");
                }
                Check(KeptToken()==Token,"a token that wasn't kept replaced the kept one (held open)");
                // No token file, but a folder where it goes: it can't be made.
                Check(DiagUpload.Forget(),"Forget");
                Thread.Sleep(20);
                Directory.CreateDirectory(DiagUpload.TokenFile);
                try {
                    github.Script(RepoOk(),Created());
                    Is(SetUp(Token2),"not_kept","a folder where the token file goes");
                    Check(!File.Exists(temp)&&!DiagUpload.HasToken,"github-token.bin.new was left, or a token taken (a folder in the way)");
                } finally { Directory.Delete(DiagUpload.TokenFile,true); }
                github.Script(RepoOk(),Created());
                Is(SetUp(Token),"set_up","the token kept again");
                Check(KeptToken()==Token&&!File.Exists(temp),"the token wasn't kept again");
            }

            // Remove (in this app's window or the other app's: the same Windows login) while GitHub checks a pasted token:
            // the token isn't kept afterwards, whether Remove ran during the repository check or the setup file's upload.
            void RemovedWhileChecking() {
                Check(KeptToken()==Token,"no token before the case");
                var forgot=new bool[1];
                Action remove=delegate { forgot[0]=DiagUpload.Forget(); };
                github.Script(Then(RepoOk(),remove),Created());
                var r=SetUp(Token2);
                Is(r,"removed","Remove while GitHub checks the repository");
                Asked(2,"Remove while GitHub checks the repository");
                Check(forgot[0]&&!DiagUpload.HasToken&&KeptToken()==null&&!File.Exists(DiagUpload.TokenFile+".new"),"a token was kept after Remove (during the check)");
                Check((r.Why??"").Contains("removed for this Windows login")&&(r.Why??"").Contains("wasn't kept")&&!NamesToken(r.Why),"why: "+r.Why);
                // A Remove before Save is only a Remove: this set up is kept.
                github.Script(RepoOk(),Created());
                Is(SetUp(Token),"set_up","set up after a Remove");
                Check(KeptToken()==Token,"the token set up after a Remove wasn't kept");
                forgot[0]=false;
                github.Script(RepoOk(),Then(Created(),remove));
                r=SetUp(Token2);
                Is(r,"removed","Remove while GitHub writes the setup file");
                Check(forgot[0]&&!DiagUpload.HasToken&&KeptToken()==null&&!File.Exists(DiagUpload.TokenFile+".new"),"a token was kept after Remove (during the setup file)");
                // A Remove just before, a removed.txt that isn't a time, and one dated a day ahead (the clock was set back
                // since): none stops a set up.
                Check(DiagUpload.Forget(),"Forget");
                github.Script(RepoOk(),Created());
                Is(SetUp(Token2),"set_up","set up just after a Remove");
                string removedTxt=Path.Combine(DiagUpload.Folder,"removed.txt");
                File.WriteAllText(removedTxt,"not a time");
                github.Script(RepoOk(),Created());
                Is(SetUp(Token),"set_up","a removed.txt that isn't a time");
                File.WriteAllText(removedTxt,DateTime.UtcNow.AddDays(1).Ticks.ToString(CultureInfo.InvariantCulture));
                github.Script(RepoOk(),Created());
                Is(SetUp(Token2),"set_up","a removed.txt dated a day ahead");
                Check(KeptToken()==Token2,"the token set up with a removed.txt dated ahead wasn't kept");
                github.Script(RepoOk(),Created());
                Is(SetUp(Token),"set_up","set up again with a removed.txt dated ahead");
                Check(KeptToken()==Token,"the token wasn't kept again");
                // Remove just as the token is being kept: it is taken off again.
                forgot[0]=false;
                DiagUpload.BeforeKeep=remove;
                github.Script(RepoOk(),Created());
                r=SetUp(Token2);
                DiagUpload.BeforeKeep=null;
                Is(r,"removed","Remove just as the token is kept");
                Check(forgot[0]&&!DiagUpload.HasToken&&KeptToken()==null&&!File.Exists(DiagUpload.TokenFile+".new"),"a token was kept after Remove (as it was kept)");
                Check((r.Why??"").Contains("wasn't kept")&&!NamesToken(r.Why),"why: "+r.Why);
                github.Script(RepoOk(),Created());
                Is(SetUp(Token),"set_up","set up after that");
                Check(KeptToken()==Token,"the token wasn't kept again");
            }

            // The GitHub upload window, made but never shown, on a thread of its own: a window needs a single-threaded
            // apartment. Both apps call Run on their [STAThread] Main, but a thread of its own works from any thread and
            // keeps the window's messages and WinForms' SynchronizationContext off the caller's thread.
            void Window() {
                string skip=null;Exception error=null;
                var t=new Thread(delegate() {
                    try { skip=CantMakeWindows();if(skip==null) WindowHere(); } catch(Exception e) { error=e; }
                });
                t.SetApartmentState(ApartmentState.STA);t.IsBackground=true;t.Name="DiagUploadTests window";
                windowThread=t;
                t.Start();
                if(!t.Join(30000)) { Fail("the window case didn't end in 30 s");return; }
                if(error!=null) {
                    var e=error is TargetInvocationException&&error.InnerException!=null?error.InnerException:error;
                    Fail("stopped: "+e.GetType().Name+": "+DiagUpload.Clip(e.Message));
                }
                if(skip!=null) note="skipped: a window can't be made here ("+skip+")";
            }
            static string CantMakeWindows() {
                try { using(var probe=new Form()) { if(probe.Handle==IntPtr.Zero) return "no window handle"; } return null; }
                catch(Exception e) { return e.GetType().Name+": "+DiagUpload.Clip(e.Message); }
            }
            void WindowHere() {
                if(!Pointed()) { Fail("not pointed at the test folder and the fake GitHub");return; }
                byte[] kept=File.ReadAllBytes(DiagUpload.TokenFile);
                try {
                    using(var f=Open("helper","2.9.20")) Opened(f);
                    // A token file this login can't read, then none.
                    Guard();File.WriteAllBytes(DiagUpload.TokenFile,new byte[]{ 1,2,3 });
                    using(var f=Open("helper","2.9.20")) {
                        Same(Get<Label>(f,"state").Text,DiagUploadForm.StateWords(true,false),"opened with an unreadable token file");
                        Check(Get<Button>(f,"remove").Enabled,"Remove is off with an unreadable token file");
                        Fits(f,"an unreadable token file");
                    }
                    Guard();File.Delete(DiagUpload.TokenFile);
                    using(var f=Open("helper","2.9.20")) {
                        Same(Get<Label>(f,"state").Text,DiagUploadForm.StateWords(false,false),"opened without a token");
                        Check(!Get<Button>(f,"remove").Enabled,"Remove is on without a token");
                        Fits(f,"no token");
                        // Save with nothing pasted: nothing is sent.
                        github.Script(RepoOk(),Created());
                        Get<TextBox>(f,"token").Text="  ";Click(Get<Button>(f,"save"));
                        Same(Get<Label>(f,"state").Text,"Paste the token first.","Save with nothing pasted");
                        Check(!(bool)Field(f,"busy")&&Get<Button>(f,"close").Enabled&&github.Connections==0,"Save with nothing pasted started a check");
                    }
                    Guard();File.WriteAllBytes(DiagUpload.TokenFile,kept);
                    using(var f=Open(new string('a',40),"1.2.3.4.5.6.7.8.9.10")) Outcomes(f);
                    // Remove in the window.
                    using(var f=Open("helper","2.9.20")) {
                        Button remove=Get<Button>(f,"remove");
                        Check(remove.Enabled,"Remove is off with a token kept");
                        Guard();Click(remove);
                        Check(Get<Label>(f,"state").Text.StartsWith("Removed for this Windows login:",StringComparison.Ordinal),"after Remove: "+Get<Label>(f,"state").Text);
                        Check(!remove.Enabled&&!DiagUpload.HasToken,"Remove in the window left the token");
                        Fits(f,"removed");
                    }
                } finally { if(Pointed()) File.WriteAllBytes(DiagUpload.TokenFile,kept); }
                Check(KeptToken()==Token,"the window case changed the kept token");
            }
            // As it opens with a token kept; Save while GitHub holds the check (nothing can be clicked and it can't be
            // closed); GitHub refusing; then Close.
            void Opened(DiagUploadForm f) {
                Label state=Get<Label>(f,"state");TextBox box=Get<TextBox>(f,"token");
                Button open=Get<Button>(f,"open"),save=Get<Button>(f,"save"),remove=Get<Button>(f,"remove"),close=Get<Button>(f,"close");
                Same(state.Text,DiagUploadForm.StateWords(true,true),"opened with a token kept");
                Check(open.Enabled&&save.Enabled&&remove.Enabled&&close.Enabled&&box.Enabled,"a control is off with nothing being checked");
                Check(f.CancelButton==close&&close.DialogResult==DialogResult.Cancel,"Close (and Esc) don't close the window");
                Check(box.UseSystemPasswordChar,"the token box shows what is pasted");
                Check(remove.Text=="Remove for this Windows login","the Remove button says "+remove.Text);
                int wrap=TextRenderer.MeasureText(new string('n',78),f.Font).Width;
                Label steps=null;
                foreach(Control c in Inside(f)) if(c is Label&&c.Text==DiagUploadForm.Steps(DiagUpload.Machine())) steps=(Label)c;
                Check(steps!=null&&steps.MaximumSize.Width==wrap&&state.MaximumSize.Width==wrap&&box.Width==wrap,"the steps aren't in the window, or it isn't laid out at 78 n's of its font ("+wrap.ToString(CultureInfo.InvariantCulture)+" pixels)");
                Check(!state.UseMnemonic&&steps!=null&&!steps.UseMnemonic,"an & in the window's words would show as an underline");
                Fits(f,"as it opens");
                using(var hold=new ManualResetEvent(false)) {
                    try {
                        github.Script(Then(R(401,"{\"message\":\"Bad credentials\"}"),delegate { hold.WaitOne(5000); }));
                        box.Text=Token2;Guard();Click(save);
                        Check((bool)Field(f,"busy"),"Save didn't start a check");
                        Check(!open.Enabled&&!save.Enabled&&!remove.Enabled&&!close.Enabled&&!box.Enabled,"a control is on while the token is checked (Close: "+close.Enabled+")");
                        Check(state.Text.StartsWith("Checking the token",StringComparison.Ordinal),"while checking: "+state.Text);
                        Fits(f,"while checking");
                        f.Close(); // as the title bar's X does
                        Check(!f.IsDisposed,"the window closed while the token was being checked");
                        if(f.IsDisposed) return;
                        Check(state.Text.StartsWith("Still checking",StringComparison.Ordinal),"closing while checking says: "+state.Text);
                        Fits(f,"closing while checking");
                        var closing=typeof(Form).GetMethod("OnFormClosing",BindingFlags.NonPublic|BindingFlags.Instance,null,new[]{ typeof(FormClosingEventArgs) },null);
                        foreach(CloseReason why in new[]{ CloseReason.WindowsShutDown,CloseReason.ApplicationExitCall,CloseReason.FormOwnerClosing,CloseReason.TaskManagerClosing,CloseReason.MdiFormClosing,CloseReason.None }) {
                            var e=new FormClosingEventArgs(why,false);
                            closing.Invoke(f,new object[]{ e });
                            Check(!e.Cancel,"while checking, a close by "+why+" was refused");
                        }
                        var user=new FormClosingEventArgs(CloseReason.UserClosing,false);
                        closing.Invoke(f,new object[]{ user });
                        Check(user.Cancel,"while checking, a close by the person (UserClosing) wasn't refused");
                    } finally { hold.Set(); }
                    Answered(f);
                }
                Check(open.Enabled&&save.Enabled&&close.Enabled&&box.Enabled&&remove.Enabled==DiagUpload.HasToken,"the controls didn't come back after GitHub answered");
                Check(state.Text.StartsWith("Not set up: GitHub refused the upload token",StringComparison.Ordinal),"after GitHub refused: "+state.Text);
                Check(KeptToken()==Token,"a refused token replaced the kept one");
                Asked(1,"the window's check");
                Fits(f,"refused");
                f.Close();
                Check(f.IsDisposed,"Close didn't close the window with nothing being checked");
            }
            // Set up in the window with the longest names, then GitHub's longest answer; every outcome the tests have seen,
            // as the window words it, fits, and the window grows for the longest and shrinks back.
            void Outcomes(DiagUploadForm f) {
                Label state=Get<Label>(f,"state");TextBox box=Get<TextBox>(f,"token");Button save=Get<Button>(f,"save");
                github.Script(RepoOk(),Created());
                box.Text=" "+Token+" ";Guard();Click(save);Answered(f);
                Check(state.Text.StartsWith("Set up: the token works (setup/",StringComparison.Ordinal)&&state.Text.Contains("-"+new string('a',24)+"-"+machine+".txt was written)"),"set up in the window: "+state.Text);
                Check(box.Text.Length==0,"the token stays in the box after it was kept");
                Check(KeptToken()==Token,"the token set up in the window wasn't kept");
                Asked(2,"set up in the window");
                Fits(f,"set up, with the longest names");
                var texts=new List<string> { state.Text };
                const string words="Invalid request. For 'content', the value is not valid and the commit message is far too long to be taken as it is. ";
                github.Script(RepoOk(),R(422,"{\"message\":"+new JavaScriptSerializer().Serialize(words+words+words)+"}"));
                box.Text=Token;Click(save);Answered(f);
                Check(state.Text.StartsWith("Not set up: GitHub answered 422 to the upload (Invalid request.",StringComparison.Ordinal)&&state.Text.EndsWith("...).",StringComparison.Ordinal),"GitHub's long answer in the window: "+state.Text);
                Fits(f,"GitHub's long answer");
                texts.Add(state.Text);
                foreach(var r in results) {
                    if(r.Code=="set_up") texts.Add("Set up: the token works ("+r.RepoPath+" was written) and is kept for this Windows login. Each saved diagnostics ZIP is now uploaded.");
                    else if(!r.Ok) texts.Add("Not set up: "+r.Why+".");
                }
                texts.Add("Not set up: the token works, but it couldn't be kept for this Windows login ("+DiagUpload.Clip("Access to the path '"+DiagUpload.TokenFile+".new' is denied. "+words+words)+").");
                texts.Add("GitHub couldn't be opened ("+DiagUpload.Clip(words+words)+"): open "+DiagUpload.TokenPage+" yourself.");
                string longest="";
                var said=new HashSet<string>();
                foreach(string s in texts) if(said.Add(s)) { Say(f,s);Fits(f,"saying \""+Short(s)+"\"");if(s.Length>longest.Length) longest=s; }
                Say(f,"Paste the token first.");
                int small=f.Height,width=f.Width;
                Say(f,longest);
                Check(state.Text==longest&&f.Height>small,"the window didn't grow for the longest words ("+small.ToString(CultureInfo.InvariantCulture)+" to "+f.Height.ToString(CultureInfo.InvariantCulture)+" pixels)");
                // It grows down, not sideways (the words wrap).
                Check(f.Width==width,"the window got wider for the longest words ("+width.ToString(CultureInfo.InvariantCulture)+" to "+f.Width.ToString(CultureInfo.InvariantCulture)+" pixels)");
                Fits(f,"the longest words");
                Say(f,"Paste the token first.");
                Check(f.Height==small,"the window didn't shrink back ("+f.Height.ToString(CultureInfo.InvariantCulture)+" pixels, was "+small.ToString(CultureInfo.InvariantCulture)+")");
                Check(Get<Button>(f,"close").Enabled,"Close is off with nothing being checked");
            }
            // Everything in the window is inside what holds it, and big enough for its text.
            void Fits(Form f,string when) {
                string at=" ("+when+")";
                Check(f.Controls.Count==1&&f.Controls[0] is TableLayoutPanel,"the window isn't one table"+at);
                if(f.Controls.Count!=1) return;
                Size need=f.Controls[0].PreferredSize,inside=f.ClientSize;
                Check(need.Width+f.Padding.Horizontal<=inside.Width&&need.Height+f.Padding.Vertical<=inside.Height,"the window's inside ("+Px(inside)+") is smaller than what it holds ("+Px(need)+" and its padding)"+at);
                foreach(Control c in Inside(f)) {
                    string what=c.GetType().Name+" \""+Short(c.Text)+"\"";
                    Size room=c.Parent.ClientSize;
                    Check(c.Left>=0&&c.Top>=0&&c.Right<=room.Width&&c.Bottom<=room.Height,what+" at "+c.Left.ToString(CultureInfo.InvariantCulture)+","+c.Top.ToString(CultureInfo.InvariantCulture)+" "+Px(c.Size)+" is outside its "+c.Parent.GetType().Name+" ("+Px(room)+")"+at);
                    var label=c as Label;
                    if(label!=null) {
                        Size wants=label.MaximumSize.Width>0?label.GetPreferredSize(new Size(label.MaximumSize.Width,0)):label.PreferredSize;
                        Check(wants.Width<=label.Width&&wants.Height<=label.Height,what+" needs "+Px(wants)+", has "+Px(label.Size)+at);
                        // Drawn, it shows as many lines as the same text drawn in a box of its width twice as tall: none cut off.
                        // (TextRenderer.MeasureText can differ from the label's own measure by a few pixels, so it is drawn.)
                        int shown=Lines(label,label.Size),all=Lines(label,new Size(label.Width,label.Height*2));
                        Check(shown>0&&shown==all,what+" shows "+shown.ToString(CultureInfo.InvariantCulture)+" of its "+all.ToString(CultureInfo.InvariantCulture)+" lines"+at);
                        if(label.MaximumSize.Width>0) Check(label.Width<=label.MaximumSize.Width,what+" is wider than it wraps at"+at);
                    }
                    var button=c as Button;
                    if(button!=null) {
                        Size wants=button.PreferredSize,text=TextRenderer.MeasureText(button.Text,button.Font);
                        Check(wants.Width<=button.Width&&wants.Height<=button.Height&&text.Width+button.Padding.Horizontal<=button.Width&&text.Height<=button.Height,what+" ("+Px(button.Size)+") is too small for its text ("+Px(text)+")"+at);
                    }
                }
            }
            // GitHub's answer comes back to the window's thread as a message: let it in (at most 5 s).
            void Answered(DiagUploadForm f) {
                var w=System.Diagnostics.Stopwatch.StartNew();
                while((bool)Field(f,"busy")&&w.ElapsedMilliseconds<5000) { Application.DoEvents();Thread.Sleep(5); }
                Check(!(bool)Field(f,"busy"),"GitHub's answer didn't come back to the window in 5 s");
            }

            void ForgetToken() {
                Check(DiagUpload.HasToken,"no token before Forget");
                string temp=DiagUpload.TokenFile+".new";
                // Another program has the token file open without letting it be deleted: Forget says so, and it stays.
                using(new FileStream(DiagUpload.TokenFile,FileMode.Open,FileAccess.Read,FileShare.Read)) {
                    Check(!DiagUpload.Forget(),"Forget said the token was removed while it couldn't be deleted");
                    Check(DiagUpload.HasToken,"the token went while it was held open");
                }
                // A github-token.bin.new left by a set up that stopped half-way goes too, and when Remove ran is written down.
                File.WriteAllBytes(temp,new byte[]{ 1,2,3 });
                long before=DateTime.UtcNow.Ticks;
                Check(DiagUpload.Forget(),"Forget said the token is still there");
                long after=DateTime.UtcNow.Ticks,at=RemovedTicks();
                Check(!DiagUpload.HasToken&&!File.Exists(DiagUpload.TokenFile),"the token is still there after Forget");
                Check(!File.Exists(temp),"github-token.bin.new is still there after Forget");
                Check(at>=before&&at<=after,"removed.txt doesn't say when Remove ran ("+at.ToString(CultureInfo.InvariantCulture)+")");
                var left=Directory.GetFiles(DiagUpload.Folder);
                Check(left.Length==1&&Path.GetFileName(left[0])=="removed.txt","the token folder holds "+left.Length.ToString(CultureInfo.InvariantCulture)+" files after Forget");
                github.Script(RepoOk(),Created());
                Is(Upload(goodZip),"not_set_up","after Forget");
                Check(github.Connections==0,"GitHub was called after Forget");
                // Only a github-token.bin.new: not a token, and Forget removes it.
                File.WriteAllBytes(temp,new byte[]{ 1,2,3 });
                Check(!DiagUpload.HasToken&&!DiagUpload.TokenUsable,"github-token.bin.new is taken as a token");
                Check(DiagUpload.Forget()&&!File.Exists(temp),"Forget left github-token.bin.new");
                Check(RemovedTicks()>=at,"removed.txt went back in time");
                Check(DiagUpload.Forget(),"Forget with nothing kept");
            }
            long RemovedTicks() {
                try { return Int64.Parse(File.ReadAllText(Path.Combine(DiagUpload.Folder,"removed.txt")).Trim(),NumberStyles.None,CultureInfo.InvariantCulture); } catch(Exception) { return -1; }
            }

            void NoTokenAnywhere() {
                Check(results.Count>=50,"only "+results.Count.ToString(CultureInfo.InvariantCulture)+" results were looked at");
                foreach(var r in results) {
                    string all=(r.Why??"")+"|"+(r.Code??"")+"|"+(r.RepoPath??"");
                    Check(all.IndexOf(Token,StringComparison.Ordinal)<0&&all.IndexOf(Token2,StringComparison.Ordinal)<0&&all.IndexOf("github_pat_TEST",StringComparison.Ordinal)<0&&
                        all.IndexOf("ghp_TEST",StringComparison.Ordinal)<0&&all.IndexOf("FakeToken",StringComparison.Ordinal)<0,"a result ("+r.Code+") holds a token");
                }
            }

            // ---- helpers ----
            void Case(string title,Action body) {
                name=title;note=null;int before=failures.Count,checks=Checks;
                try { body(); } catch(Exception e) { Fail("stopped: "+e.GetType().Name+": "+DiagUpload.Clip(e.Message)); }
                finally { DiagUpload.Api=github.Url;Times();github.WaitIdle(3000);github.Script();elsewhere.Script(); }
                Report.Add((failures.Count==before?"ok   ":"FAIL ")+title+(note!=null?", "+note:"")+" ("+(Checks-checks).ToString(CultureInfo.InvariantCulture)+" checks)");
            }
            void Check(bool ok,string what) { Checks++;if(!ok) Fail(what); }
            void Fail(string what) { failures.Add(Mask("DiagUpload, "+name+": "+what)); }
            void Same(string got,string expected,string what) { Check(got==expected,what+": \""+got+"\", expected \""+expected+"\""); }
            void Same(long got,long expected,string what) { Check(got==expected,what+": "+got.ToString(CultureInfo.InvariantCulture)+", expected "+expected.ToString(CultureInfo.InvariantCulture)); }
            void Times() { DiagUpload.CheckTimeoutMs=checkMs;DiagUpload.UploadBaseMs=baseMs;DiagUpload.BytesPerSecond=rate;DiagUpload.StallMs=stallMs;DiagUpload.RetryMs=retryMs;DiagUpload.BeforeKeep=null; }
            // A short time ran out soon (the times allowed here are 0.3 s).
            void Quick(System.Diagnostics.Stopwatch watch,string what) { Check(watch.ElapsedMilliseconds<2500,what+" took "+watch.ElapsedMilliseconds.ToString(CultureInfo.InvariantCulture)+" ms"); }

            void Guard() { if(!Pointed()) throw new InvalidOperationException("not pointed at the fake GitHub and the test folder"); }
            bool Pointed() {
                return DiagUpload.Api.StartsWith("http://127.0.0.1:",StringComparison.Ordinal)&&
                    DiagUpload.TokenFile.StartsWith(folder+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase);
            }
            DiagUploadResult Upload(string zip) { return Upload(zip,"helper","2.9.20"); }
            DiagUploadResult Upload(string zip,string app,string version) {
                if(!Pointed()) throw new InvalidOperationException("not pointed at the fake GitHub and the test folder");
                return Keep(DiagUpload.Upload(zip,app,version));
            }
            DiagUploadResult SetUp(string pasted) {
                if(!Pointed()) throw new InvalidOperationException("not pointed at the fake GitHub and the test folder");
                return Keep(DiagUpload.SetUp(pasted,"helper","2.9.20"));
            }
            DiagUploadResult Keep(DiagUploadResult r) { if(r==null) { Fail("no result");r=new DiagUploadResult(); } results.Add(r);return r; }

            // The result says code, and the rest of it fits.
            void Is(DiagUploadResult r,string code,string when) {
                string why=r.Why??"",path=r.RepoPath??"",got=r.Code??"",at=" ("+when+")";
                Check(got==code,"code "+got+", expected "+code+at+(why.Length>0?": "+why:""));
                bool ok=code=="uploaded"||code=="set_up";
                Check(r.Ok==ok,"Ok is "+r.Ok+" with "+got+at);
                Check(r.NotSetUp==(code=="not_set_up"),"NotSetUp is "+r.NotSetUp+" with "+got+at);
                if(ok) Check(path.Length>0&&why.Length==0,"uploaded without a RepoPath, or with a why"+at);
                else Check(path.Length==0&&why.Length>0,"not uploaded, but with a RepoPath or without a why"+at);
            }
            // GitHub answers with replies (and would then take more uploads): the result is code after count requests.
            DiagUploadResult Expect(string what,string code,int count,params Reply[] replies) {
                var all=new List<Reply>(replies);all.Add(Created());all.Add(Created());
                github.Script(all.ToArray());
                var r=Upload(goodZip);
                Is(r,code,what);
                var seen=Asked(count,what);
                if(seen.Count>0) IsGet(seen[0],Token);
                if(seen.Count>1) Check(seen[1].Method=="PUT",what+": the second request was "+seen[1].Method);
                return r;
            }
            List<Heard> Asked(int count,string what) {
                var seen=github.Requests;
                var b=new StringBuilder();
                foreach(var h in seen) b.Append(" [").Append(h.Method).Append(' ').Append(h.Path).Append(']');
                Check(seen.Count==count,what+": "+seen.Count.ToString(CultureInfo.InvariantCulture)+" requests to GitHub, expected "+count.ToString(CultureInfo.InvariantCulture)+b);
                return seen;
            }
            void IsGet(Heard h,string token) {
                Check(h.Method=="GET"&&h.Path==RepoApi,"the repository check was "+h.Method+" "+h.Path+", expected GET "+RepoApi);
                Check(h.Body.Length==0,"the repository check sent a body");
                Sent(h,token);
            }
            // GitHub's contents API: PUT .../contents/<path> with JSON {"message":..., "content": the bytes in base64}.
            byte[] IsPut(Heard h,string token,string repoPath,out string message) {
                message=null;
                Check(h.Method=="PUT"&&h.Path==RepoApi+"/contents/"+repoPath,"the upload was "+h.Method+" "+h.Path+", expected PUT "+RepoApi+"/contents/"+repoPath);
                Sent(h,token);
                Check((h.Header("Content-Type")??"").StartsWith("application/json",StringComparison.OrdinalIgnoreCase),"Content-Type "+h.Header("Content-Type"));
                Check(h.Header("Content-Length")==h.Body.Length.ToString(CultureInfo.InvariantCulture),"Content-Length "+h.Header("Content-Length")+" for a body of "+h.Body.Length.ToString(CultureInfo.InvariantCulture));
                Dictionary<string,object> json;
                try { var js=new JavaScriptSerializer();js.MaxJsonLength=Int32.MaxValue;json=js.DeserializeObject(h.Text) as Dictionary<string,object>; } catch(Exception) { json=null; }
                if(json==null) { Fail("the upload's body isn't a JSON object");return null; }
                object m,c;
                Check(json.TryGetValue("message",out m)&&m is string&&((string)m).Trim().Length>0,"the upload has no commit message");
                message=m as string;
                if(!json.TryGetValue("content",out c)||!(c is string)) { Fail("the upload has no content");return null; }
                string base64=(string)c;
                Check(Regex.IsMatch(base64,"^[A-Za-z0-9+/]*={0,2}$"),"the content isn't plain base64");
                try { return Convert.FromBase64String(base64); } catch(FormatException) { Fail("the content isn't base64");return null; }
            }
            // Every request: the token in Authorization (Bearer) and nowhere else, and the headers GitHub asks for.
            void Sent(Heard h,string token) {
                Check(h.Header("Authorization")=="Bearer "+token,"Authorization on the "+h.Method+" isn't Bearer and the token");
                Check(!String.IsNullOrEmpty(h.Header("User-Agent")),"no User-Agent on the "+h.Method);
                Check((h.Header("Accept")??"").Contains("application/vnd.github"),"Accept on the "+h.Method+": "+h.Header("Accept"));
                Check(!String.IsNullOrEmpty(h.Header("X-GitHub-Api-Version")),"no X-GitHub-Api-Version on the "+h.Method);
                bool loose=h.Line.Contains(token)||h.Text.Contains(token);
                foreach(var kv in h.Headers) if(!String.Equals(kv.Key,"Authorization",StringComparison.OrdinalIgnoreCase)&&kv.Value.Contains(token)) loose=true;
                Check(!loose,"the token is in the "+h.Method+" outside Authorization");
            }
            string KeptToken() {
                try { return Encoding.UTF8.GetString(ProtectedData.Unprotect(File.ReadAllBytes(DiagUpload.TokenFile),Entropy,DataProtectionScope.CurrentUser)); } catch(Exception) { return null; }
            }
            // A file that starts like a ZIP, then made-up bytes.
            string Zip(string fileName,int size) {
                var bytes=new byte[size];new Random(size).NextBytes(bytes);
                bytes[0]=0x50;bytes[1]=0x4B;bytes[2]=3;bytes[3]=4;
                string path=Path.Combine(folder,fileName);File.WriteAllBytes(path,bytes);return path;
            }
        }

        static bool NamesToken(string s) {
            s=s??"";
            return s.IndexOf(Token,StringComparison.Ordinal)>=0||s.IndexOf(Token2,StringComparison.Ordinal)>=0||Regex.IsMatch(s,@"github_pat_|gh[pousr]_|FakeToken");
        }
        // One name in a path: only A-Z, 0-9, dots and dashes, and not starting or ending with a dot or a dash.
        static bool Plain(string s) { return s.Length>0&&Regex.IsMatch(s,"^[A-Za-z0-9.-]+$")&&s.Trim('.','-')==s; }
        static bool Equal(byte[] a,byte[] b) {
            if(a.Length!=b.Length) return false;
            for(int i=0;i<a.Length;i++) if(a[i]!=b[i]) return false;
            return true;
        }
        static bool Holds(byte[] hay,byte[] needle) {
            for(int i=0;i+needle.Length<=hay.Length;i++) {
                int j=0;while(j<needle.Length&&hay[i+j]==needle[j]) j++;
                if(j==needle.Length) return true;
            }
            return false;
        }
        // A URL's query as name -> value (decoded).
        static Dictionary<string,string> Query(string url) {
            var q=new Dictionary<string,string>(StringComparer.Ordinal);
            int at=(url??"").IndexOf('?');
            if(at<0) return q;
            foreach(string pair in url.Substring(at+1).Split('&')) {
                int eq=pair.IndexOf('=');
                if(eq>0) q[Uri.UnescapeDataString(pair.Substring(0,eq))]=Uri.UnescapeDataString(pair.Substring(eq+1));
            }
            return q;
        }
        static string Value(Dictionary<string,string> q,string key) { string v;return q.TryGetValue(key,out v)?v:null; }
        static string Short(string s) { s=Regex.Replace(s??"",@"\s+"," ");return s.Length>40?s.Substring(0,40)+"...":s; }
        static string Px(Size s) { return s.Width.ToString(CultureInfo.InvariantCulture)+"x"+s.Height.ToString(CultureInfo.InvariantCulture); }

        // ---- the window (DiagUploadForm's own fields and methods, by name) ----
        static DiagUploadForm Open(string app,string version) {
            var f=new DiagUploadForm(app,version);
            if(f.Handle==IntPtr.Zero) throw new InvalidOperationException("the window has no handle"); // made, as Show would, never shown
            f.PerformLayout();
            return f;
        }
        static object Field(object o,string name) {
            var f=o.GetType().GetField(name,BindingFlags.NonPublic|BindingFlags.Instance);
            if(f==null) throw new InvalidOperationException(o.GetType().Name+" has no "+name);
            return f.GetValue(o);
        }
        static T Get<T>(object o,string name) where T:class {
            var v=Field(o,name) as T;
            if(v==null) throw new InvalidOperationException(o.GetType().Name+"."+name+" isn't a "+typeof(T).Name);
            return v;
        }
        // A click, as Button.PerformClick would do on a window that is showing.
        static void Click(Button b) {
            try { typeof(Button).GetMethod("OnClick",BindingFlags.NonPublic|BindingFlags.Instance,null,new[]{ typeof(EventArgs) },null).Invoke(b,new object[]{ EventArgs.Empty }); }
            catch(TargetInvocationException e) { if(e.InnerException!=null) throw e.InnerException;throw; }
        }
        static void Say(DiagUploadForm f,string text) {
            var m=typeof(DiagUploadForm).GetMethod("Say",BindingFlags.NonPublic|BindingFlags.Instance,null,new[]{ typeof(string) },null);
            if(m==null) throw new InvalidOperationException("DiagUploadForm has no Say(string)");
            m.Invoke(f,new object[]{ text });
        }
        // How many lines of text the label draws in a box of size (itself at its own size, else a copy of it).
        static int Lines(Label l,Size size) {
            if(size.Width<=0||size.Height<=0) return 0;
            Label copy=size==l.Size?null:new Label { AutoSize=false,Size=size,Text=l.Text,Font=l.Font,Padding=l.Padding,TextAlign=l.TextAlign,
                UseMnemonic=l.UseMnemonic,AutoEllipsis=l.AutoEllipsis,BackColor=l.BackColor,ForeColor=l.ForeColor };
            try {
                using(var b=new Bitmap(size.Width,size.Height,System.Drawing.Imaging.PixelFormat.Format32bppArgb)) {
                    (copy??l).DrawToBitmap(b,new Rectangle(Point.Empty,size));
                    var data=b.LockBits(new Rectangle(Point.Empty,size),System.Drawing.Imaging.ImageLockMode.ReadOnly,System.Drawing.Imaging.PixelFormat.Format32bppArgb);
                    try {
                        Color back=l.BackColor;var row=new byte[size.Width*4];int lines=0;bool inked=false;
                        for(int y=0;y<size.Height;y++) {
                            System.Runtime.InteropServices.Marshal.Copy(new IntPtr(data.Scan0.ToInt64()+(long)y*data.Stride),row,0,row.Length);
                            bool ink=false;
                            for(int x=0;x<size.Width&&!ink;x++) ink=Math.Abs(row[x*4]-back.B)+Math.Abs(row[x*4+1]-back.G)+Math.Abs(row[x*4+2]-back.R)>150;
                            if(ink&&!inked) lines++;
                            inked=ink;
                        }
                        return lines;
                    } finally { b.UnlockBits(data); }
                }
            } finally { if(copy!=null) copy.Dispose(); }
        }
        static List<Control> Inside(Control c) {
            var list=new List<Control>();
            foreach(Control k in c.Controls) { list.Add(k);list.AddRange(Inside(k)); }
            return list;
        }

        static Reply R(int code,string body) { return new Reply { Code=code,Body=body }; }
        // GitHub holds the request up to ms (or until DiagUpload gives up) before answering.
        static Reply Late(Reply r,int ms) { r.HoldMs=ms;return r; }
        // Something happens at GitHub's end once the request is in, before it's answered.
        static Reply Then(Reply r,Action before) { r.Before=before;return r; }
        static Reply RepoOk() { return R(200,"{\"id\":1,\"full_name\":\"tommyvenzin/tempe-diagnostics\",\"private\":true,\"visibility\":\"private\"}"); }
        static Reply Created() { return R(201,"{\"content\":{\"name\":\"x\"},\"commit\":{\"sha\":\"0123abcd\"}}"); }

        // ---- the fake GitHub ----
        sealed class Reply {
            internal int Code;internal string Body="";internal string Location;internal bool Drop;
            // Run on the fake GitHub's thread once the request is in, before it is answered.
            internal Action Before;
            // HoldMs: wait that long (unless DiagUpload gives up first) before answering. ReadPauseMs: read the body 4 KB at
            // a time with this pause after each, for at most HoldMs, and answer nothing if it didn't all come.
            internal int HoldMs,ReadPauseMs;
        }
        sealed class Heard {
            internal string Method="",Path="",Line="";
            internal readonly Dictionary<string,string> Headers=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
            internal byte[] Body=new byte[0];
            string text;
            internal string Text { get { if(text==null) text=Encoding.UTF8.GetString(Body);return text; } }
            internal string Header(string key) { string v;return Headers.TryGetValue(key,out v)?v:null; }
        }
        // HTTP/1.1 on 127.0.0.1, one connection at a time: each request is read (headers, then Content-Length bytes),
        // kept, and answered with the next scripted reply (500 when the script has run out), then the connection closes.
        sealed class Hub {
            readonly TcpListener listener;readonly Thread thread;readonly object gate=new object();
            readonly Queue<Reply> script=new Queue<Reply>();readonly List<Heard> heard=new List<Heard>();
            int connections,serving;
            internal readonly string Url;

            internal Hub() {
                listener=new TcpListener(IPAddress.Loopback,0);
                listener.Start();
                Url="http://127.0.0.1:"+((IPEndPoint)listener.LocalEndpoint).Port.ToString(CultureInfo.InvariantCulture)+"/";
                thread=new Thread(Serve);thread.IsBackground=true;thread.Name="DiagUploadTests fake GitHub";
                thread.Start();
            }
            internal void Script(params Reply[] replies) { lock(gate) { script.Clear();heard.Clear();connections=0;foreach(var r in replies) script.Enqueue(r); } }
            internal List<Heard> Requests { get { lock(gate) return new List<Heard>(heard); } }
            internal int Connections { get { lock(gate) return connections; } }
            internal int Unused { get { lock(gate) return script.Count; } }
            // Until the request DiagUpload gave up on is done with here (at most ms).
            internal void WaitIdle(int ms) {
                var w=System.Diagnostics.Stopwatch.StartNew();
                while(w.ElapsedMilliseconds<ms) {
                    bool idle;lock(gate) idle=serving==0;
                    try { if(idle&&!listener.Pending()) return; } catch(Exception) { return; }
                    Thread.Sleep(5);
                }
            }
            internal void Stop() {
                try { listener.Stop(); } catch(Exception) { }
                thread.Join(3000);
            }

            void Serve() {
                while(true) {
                    TcpClient c;
                    try { c=listener.AcceptTcpClient(); } catch(Exception) { return; } // stopped
                    lock(gate) serving++;
                    try { Answer(c); } catch(Exception) { } finally { try { c.Close(); } catch(Exception) { } lock(gate) serving--; }
                }
            }
            // Waits up to ms; true when the client closed the connection first (DiagUpload gave up).
            static bool Gone(TcpClient c,int ms) {
                var w=System.Diagnostics.Stopwatch.StartNew();
                while(w.ElapsedMilliseconds<ms) {
                    try { if(c.Client.Poll(20000,SelectMode.SelectRead)&&c.Client.Available==0) return true; } catch(Exception) { return true; }
                }
                return false;
            }
            void Answer(TcpClient c) {
                lock(gate) connections++;
                c.ReceiveTimeout=5000;c.SendTimeout=5000;
                NetworkStream s=c.GetStream();
                var head=new List<byte>();
                while(!(head.Count>=4&&head[head.Count-4]==13&&head[head.Count-3]==10&&head[head.Count-2]==13&&head[head.Count-1]==10)) {
                    int b=s.ReadByte();
                    if(b<0||head.Count>65536) return;
                    head.Add((byte)b);
                }
                var h=new Heard();
                string[] lines=Encoding.ASCII.GetString(head.ToArray()).Split(new[]{ "\r\n" },StringSplitOptions.None);
                h.Line=lines[0];
                string[] parts=lines[0].Split(' ');
                if(parts.Length>=2) { h.Method=parts[0];h.Path=parts[1]; }
                for(int i=1;i<lines.Length;i++) {
                    int colon=lines[i].IndexOf(':');
                    if(colon>0) h.Headers[lines[i].Substring(0,colon).Trim()]=lines[i].Substring(colon+1).Trim();
                }
                long length=0;string given=h.Header("Content-Length");
                if(given!=null&&!Int64.TryParse(given,NumberStyles.None,CultureInfo.InvariantCulture,out length)) return;
                if(length>64L*1024*1024) return;
                Reply r;
                lock(gate) r=script.Count>0?script.Dequeue():null;
                if(r==null) r=R(500,"{\"message\":\"the test didn't expect this request\"}");
                var body=new byte[length];int at=0;
                var reading=System.Diagnostics.Stopwatch.StartNew();
                try {
                    while(at<body.Length) {
                        if(r.ReadPauseMs>0&&reading.ElapsedMilliseconds>r.HoldMs) break;
                        int n=s.Read(body,at,r.ReadPauseMs>0?Math.Min(4096,body.Length-at):body.Length-at);
                        if(n<=0) break;
                        at+=n;
                        if(r.ReadPauseMs>0) Thread.Sleep(r.ReadPauseMs);
                    }
                } catch(IOException) { } // DiagUpload gave up
                bool whole=at==body.Length;
                if(!whole) Array.Resize(ref body,at);
                h.Body=body;
                lock(gate) heard.Add(h);
                if(r.ReadPauseMs>0&&!whole) return;
                if(r.Before!=null) { try { r.Before(); } catch(Exception) { } }
                if(r.HoldMs>0&&r.ReadPauseMs==0&&Gone(c,r.HoldMs)) return;
                if(r.Drop) return;
                byte[] text=Encoding.UTF8.GetBytes(r.Body??"");
                var top=new StringBuilder();
                top.Append("HTTP/1.1 ").Append(r.Code.ToString(CultureInfo.InvariantCulture)).Append(' ').Append(Reason(r.Code)).Append("\r\n");
                top.Append("Content-Type: application/json; charset=utf-8\r\n");
                top.Append("Content-Length: ").Append(text.Length.ToString(CultureInfo.InvariantCulture)).Append("\r\n");
                if(r.Location!=null) top.Append("Location: ").Append(r.Location).Append("\r\n");
                top.Append("Connection: close\r\n\r\n");
                byte[] bytes=Encoding.ASCII.GetBytes(top.ToString());
                s.Write(bytes,0,bytes.Length);s.Write(text,0,text.Length);s.Flush();
                try { c.Client.Shutdown(SocketShutdown.Send); } catch(Exception) { }
            }
            static string Reason(int code) {
                switch(code) {
                    case 200: return "OK";
                    case 201: return "Created";
                    case 204: return "No Content";
                    case 301: return "Moved Permanently";
                    case 302: return "Found";
                    case 307: return "Temporary Redirect";
                    case 401: return "Unauthorized";
                    case 403: return "Forbidden";
                    case 404: return "Not Found";
                    case 409: return "Conflict";
                    case 422: return "Unprocessable Entity";
                    default: return "Error";
                }
            }
        }
    }
}
