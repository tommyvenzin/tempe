// Diagnostics upload to GitHub: Tempe helper 2.9.20 and Ebay-auto 1.1.11 (this file is the same in both).
// Tommy, 26 Nov 2026: "update helper and ebay so it upload diagnostic to github, I dont have claude there so its a
// headache to keep it posted here".
//
// A diagnostics ZIP the app has just saved (already masked: DiagnosticsBundle, EbayAutoDiagnostics) is also put in
// Tommy's PRIVATE GitHub repository tommyvenzin/tempe-diagnostics, at uploads/<date>/<time>-<app>-<version>-<PC>.zip.
// Nothing else is sent: no settings, no entry reports (they hold customer details), no pairing key. It needs a
// fine-grained GitHub token made for that one repository (Contents: Read and write), pasted once per Windows user in
// the GitHub upload window. The token is kept with DPAPI (only this Windows user on this PC can read it) in
// %LOCALAPPDATA%\TempeDiagnosticsUpload, where both apps find it. Before every upload the repository is read with the
// token: unless GitHub says it is tommyvenzin/tempe-diagnostics and private, nothing is uploaded. The token is never
// written to a log, a diagnostics file, a message or the screen, and it goes only to api.github.com.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed class DiagUploadResult {
        internal bool Ok;            // the file is in the repository (RepoPath)
        internal bool NotSetUp;      // no token on this PC: nothing was sent
        internal string RepoPath=""; // where it went (Ok)
        internal string Why="";      // why it wasn't uploaded, in plain words (never the token)
        // A fixed word for day logs: uploaded, set_up, not_set_up, bad_token, bad_file, too_big, network, too_slow,
        // refused, no_access, no_write, not_private, conflict, failed, not_kept, removed.
        internal string Code="";
    }

    internal static class DiagUpload {
        internal const string Owner="tommyvenzin",Repo="tempe-diagnostics",RepoName=Owner+"/"+Repo;
        internal const long MaxBytes=40L*1024*1024;
        internal const string TokenPage="https://github.com/settings/personal-access-tokens/new";
        // Tests point these at their own server and folder; nothing else changes them.
        internal static string Api="https://api.github.com/";
        internal static string Root;
        // How long GitHub gets: the check 30 s; the upload 60 s plus 1 s for every 32 KB (1.5 MB gets 108 s), at most
        // 30 min. A stalled upload ends only when that time runs out: StallMs only limits reading GitHub's answer.
        // After GitHub answers 409 (busy), the upload is tried again after RetryMs, then twice that.
        internal static int CheckTimeoutMs=30000,UploadBaseMs=60000,BytesPerSecond=32*1024,StallMs=120000,RetryMs=1500;
        // Tests only: run between the last Remove check and keeping the token (null in the apps).
        internal static Action BeforeKeep;
        internal static string Folder { get { return Root??Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TempeDiagnosticsUpload"); } }
        internal static string TokenFile { get { return Path.Combine(Folder,"github-token.bin"); } }
        static readonly byte[] Entropy=Encoding.UTF8.GetBytes("TempeDiagnosticsUpload/1");
        // Only a fine-grained token (made for one repository); a classic one (ghp_) reaches every repository.
        internal static readonly Regex TokenShape=new Regex(@"^github_pat_[A-Za-z0-9_]{20,250}$");
        static readonly Regex NotName=new Regex(@"[^A-Za-z0-9.-]+");
        // Only a ZIP that Save diagnostics / Export diagnostics names is ever sent (never an entry report or a setting).
        internal static readonly Regex DiagnosticsName=new Regex(@"^(?:Tempe-COSTAR-Diagnostics-|Ebay-auto-(?:Receiver|Worker)-Diagnostics-)[0-9-]+\.zip$",RegexOptions.IgnoreCase);

        // A token file is there (it may still be unreadable: TokenUsable).
        internal static bool HasToken { get { try { return File.Exists(TokenFile); } catch(Exception) { return false; } } }
        internal static bool TokenUsable { get { return ReadToken()!=null; } }
        // When Remove last ran for this Windows login (UTC ticks; 0 if never): a check still under way when the token
        // was removed must not keep it afterwards (the window of either app, the same login). SetUp only looks at
        // whether it changed, never at the clock.
        static string RemovedFile { get { return Path.Combine(Folder,"removed.txt"); } }

        // ---- the token ----
        static string ReadToken() {
            try {
                if(!File.Exists(TokenFile)) return null;
                byte[] data;
                // Read while the other app may be replacing it (a reader never blocks Replace or Delete).
                using(var s=new FileStream(TokenFile,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)) {
                    if(s.Length>64*1024) return null;
                    data=new byte[(int)s.Length];int at=0,n;
                    while(at<data.Length&&(n=s.Read(data,at,data.Length-at))>0) at+=n;
                    if(at!=data.Length) return null;
                }
                string t=Encoding.UTF8.GetString(ProtectedData.Unprotect(data,Entropy,DataProtectionScope.CurrentUser)).Trim();
                return TokenShape.IsMatch(t)?t:null;
            } catch(Exception) { return null; }
        }
        static void KeepToken(string token) {
            Directory.CreateDirectory(Folder);
            byte[] data=ProtectedData.Protect(Encoding.UTF8.GetBytes(token),Entropy,DataProtectionScope.CurrentUser);
            string temp=TokenFile+".new";
            try {
                File.WriteAllBytes(temp,data);
                if(File.Exists(TokenFile)) File.Replace(temp,TokenFile,null); else File.Move(temp,TokenFile);
            } catch(Exception) {
                try { if(File.Exists(temp)) File.Delete(temp); } catch(Exception) { }
                throw;
            }
        }
        // 0 with no removed.txt (or one that isn't a time), -1 when it can't be read (tried 4 times: Forget may be
        // writing it just then).
        static long RemovedAt() {
            for(int i=0;;i++) {
                try {
                    if(!File.Exists(RemovedFile)) return 0;
                    long t;
                    return Int64.TryParse(File.ReadAllText(RemovedFile).Trim(),NumberStyles.None,CultureInfo.InvariantCulture,out t)?t:0;
                } catch(Exception) { if(i>=3) return -1;Thread.Sleep(50); }
            }
        }
        // Removes the token for this Windows login on this PC (both apps). True when none is left.
        internal static bool Forget() {
            try {
                Directory.CreateDirectory(Folder);
                File.WriteAllText(RemovedFile,DateTime.UtcNow.Ticks.ToString(CultureInfo.InvariantCulture));
            } catch(Exception) { }
            bool gone=true;
            foreach(string f in new[] { TokenFile,TokenFile+".new" }) {
                try { if(File.Exists(f)) File.Delete(f); } catch(Exception) { }
                try { if(File.Exists(f)) gone=false; } catch(Exception) { gone=false; }
            }
            return gone;
        }
        // The token page with what can be filled in already filled in (GitHub's template URL: name of at most 40
        // characters, resource owner, no expiry, Contents: Read and write). Repository access is picked by hand.
        internal static string TokenPageFor(string machine) {
            string name="Tempe diagnostics "+Name(machine,"PC",32);
            if(name.Length>40) name=name.Substring(0,40).Trim('-','.',' ');
            return TokenPage+"?name="+Uri.EscapeDataString(name)+"&description="+Uri.EscapeDataString("Uploads diagnostics ZIPs to "+Repo)+
                "&target_name="+Owner+"&expires_in=none&contents=write";
        }

        // ---- names (pure) ----
        internal static string Name(string value,string fallback,int limit) {
            string s=NotName.Replace(value??"","-").Trim('-','.');
            if(s.Length>limit) s=s.Substring(0,limit).Trim('-','.');
            return s.Length==0?fallback:s;
        }
        internal static string Machine() { string m;try { m=Environment.MachineName; } catch(Exception) { m=""; } return Name(m,"PC",32); }
        // uploads/2026-11-26/173012-345-helper-2.9.20-RDPPC.zip
        internal static string UploadPath(DateTime local,string app,string version,string machine) {
            return "uploads/"+local.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture)+"/"+local.ToString("HHmmss-fff",CultureInfo.InvariantCulture)+"-"+Name(app,"app",24)+"-"+Name(version,"0",16)+"-"+Name(machine,"PC",32)+".zip";
        }
        internal static string SetupPath(DateTime local,string app,string machine) {
            return "setup/"+local.ToString("yyyyMMdd-HHmmss-fff",CultureInfo.InvariantCulture)+"-"+Name(app,"app",24)+"-"+Name(machine,"PC",32)+".txt";
        }

        // ---- set up and upload (network: call them off the window's thread) ----
        // Checks the pasted token: it must be fine-grained, see the private repository and write one small file to
        // setup/. Only then is it kept.
        internal static DiagUploadResult SetUp(string pasted,string app,string version) {
            string token=(pasted??"").Trim();
            if(!TokenShape.IsMatch(token)) return Fail("bad_token","that isn't a fine-grained GitHub token (one starts with github_pat_): make one for "+Repo+" only, as the steps say, and paste it here");
            // Remove (in either app's window) writes a new time to removed.txt: any change while this check runs means
            // Remove was clicked meanwhile. Compared as it was, not with the clock, so a clock set back doesn't matter.
            long before=RemovedAt();
            var r=CheckPrivate(token);
            if(r!=null) return r;
            DateTime now=DateTime.Now;string machine=Machine();
            byte[] text=Encoding.UTF8.GetBytes("GitHub upload set up by "+Name(app,"app",24)+" "+Name(version,"0",16)+" on "+machine+" at "+now.ToString("yyyy-MM-dd HH:mm:ss",CultureInfo.InvariantCulture)+".\n");
            r=Put(token,SetupPath(now,app,machine),text,"Upload set up: "+Name(app,"app",24)+" on "+machine);
            if(!r.Ok) {
                // Put's advice is for a diagnostics ZIP; here the token is being set up.
                if(r.Code=="too_slow") r.Why="GitHub took too long to answer on this connection: click Save again";
                else if(r.Code=="conflict") r.Why="GitHub was busy: click Save again";
                return r;
            }
            if(RemovedAt()!=before) return Removed();
            if(BeforeKeep!=null) BeforeKeep();
            try { KeepToken(token); } catch(Exception e) { return Fail("not_kept","the token works, but it couldn't be kept for this Windows login ("+Clip(e.Message)+")"); }
            // A Remove just as it was kept: take it off again.
            if(RemovedAt()!=before) {
                Forget();
                return HasToken?Fail("removed","GitHub upload was removed for this Windows login while the token was being kept, and the token couldn't be taken off again: click Remove"):Removed();
            }
            r.Code="set_up";
            return r;
        }
        static DiagUploadResult Removed() { return Fail("removed","GitHub upload was removed for this Windows login while the token was being checked, so it wasn't kept"); }

        internal static DiagUploadResult Upload(string zipPath,string app,string version) {
            string token=ReadToken();
            if(token==null) return new DiagUploadResult { NotSetUp=true,Code="not_set_up",Why=HasToken?"the GitHub upload token kept for this Windows login couldn't be read: set up GitHub upload again":"GitHub upload isn't set up for this Windows login" };
            byte[] bytes;
            try {
                var f=new FileInfo(zipPath);
                if(!f.Exists) return Fail("bad_file","the diagnostics ZIP wasn't found");
                if(!DiagnosticsName.IsMatch(f.Name)) return Fail("bad_file","only a saved diagnostics ZIP is uploaded");
                if(f.Length>MaxBytes) return Fail("too_big","the ZIP is "+AppData.Bytes(f.Length)+", more than the 40 MB GitHub upload takes: send it by hand");
                bytes=File.ReadAllBytes(f.FullName);
                if(bytes.Length<4||bytes[0]!=0x50||bytes[1]!=0x4B||bytes[2]!=3||bytes[3]!=4) return Fail("bad_file","the diagnostics file isn't a ZIP");
            } catch(Exception e) { return Fail("bad_file","the diagnostics ZIP couldn't be read ("+Clip(e.Message)+")"); }
            var r=CheckPrivate(token);
            if(r!=null) return r;
            string machine=Machine();
            return Put(token,UploadPath(DateTime.Now,app,version,machine),bytes,"Diagnostics: "+Name(app,"app",24)+" "+Name(version,"0",16)+" on "+machine);
        }

        // Null when GitHub says the token sees tommyvenzin/tempe-diagnostics and it is private.
        static DiagUploadResult CheckPrivate(string token) {
            int code;string text;
            try { code=Send(Request("GET",Api+"repos/"+RepoName,token,CheckTimeoutMs),null,out text); }
            catch(Exception e) { return Fail("network","GitHub couldn't be reached ("+Clip(e.Message)+")"); }
            if(code==401) return Fail("refused","GitHub refused the upload token (it may have expired or been deleted): set up GitHub upload again with a new token");
            if(code==404) return Fail("no_access","the upload token can't see "+RepoName+": make the token with Repository access, Only select repositories, "+Repo+" (and check that repository is there on GitHub)");
            if(code!=200) return Fail("failed","GitHub answered "+code.ToString(CultureInfo.InvariantCulture)+" when "+RepoName+" was checked"+Said(text));
            var repo=Json(text);
            object priv,full;
            if(repo==null||!repo.TryGetValue("full_name",out full)||!String.Equals(full as string,RepoName,StringComparison.OrdinalIgnoreCase))
                return Fail("not_private","GitHub didn't answer for "+RepoName+", so nothing was uploaded");
            if(!repo.TryGetValue("private",out priv)||!(priv is bool)||!(bool)priv)
                return Fail("not_private",RepoName+" isn't private on GitHub, so nothing was uploaded: diagnostics go only to a private repository");
            return null;
        }

        // One new file in the repository (GitHub's contents API: one commit).
        static DiagUploadResult Put(string token,string path,byte[] bytes,string message) {
            for(int attempt=1;;attempt++) {
                int code;string text;
                try {
                    var q=Request("PUT",Api+"repos/"+RepoName+"/contents/"+path,token,UploadTimeoutMs(bytes.LongLength));
                    code=SendContent(q,message,bytes,out text);
                } catch(Exception e) {
                    var w=e as WebException;
                    if(w!=null&&(w.Status==WebExceptionStatus.Timeout||w.Status==WebExceptionStatus.RequestCanceled))
                        return Fail("too_slow","the upload of "+AppData.Bytes(bytes.LongLength)+" took too long on this connection: save diagnostics again later, or send the ZIP by hand");
                    return Fail("network","GitHub couldn't be reached ("+Clip(e.Message)+")");
                }
                if(code==201||code==200) return new DiagUploadResult { Ok=true,Code="uploaded",RepoPath=path };
                if(code==409&&attempt<3) { Thread.Sleep(Math.Max(0,RetryMs)*attempt);continue; }
                if(code==401) return Fail("refused","GitHub refused the upload token (it may have expired or been deleted): set up GitHub upload again with a new token");
                if(code==403) return Fail("no_write","the upload token can't write to "+RepoName+": give it Repository permissions, Contents: Read and write"+Said(text));
                if(code==404) return Fail("no_access","the upload token can't see "+RepoName+": make the token with Repository access, Only select repositories, "+Repo+" (and check that repository is there on GitHub)");
                if(code==409) return Fail("conflict","GitHub was busy with another upload: save diagnostics again");
                return Fail("failed","GitHub answered "+code.ToString(CultureInfo.InvariantCulture)+" to the upload"+Said(text));
            }
        }

        // ---- HTTP ----
        internal static int UploadTimeoutMs(long bytes) {
            return (int)Math.Min(30L*60*1000,UploadBaseMs+Math.Max(0,bytes)*1000/Math.Max(1,BytesPerSecond));
        }
        static HttpWebRequest Request(string method,string url,string token,int timeoutMs) {
            ServicePointManager.SecurityProtocol=ServicePointManager.SecurityProtocol|SecurityProtocolType.Tls12;
            var q=(HttpWebRequest)WebRequest.Create(url);
            q.Method=method;
            q.UserAgent="TempeDiagnosticsUpload/1";
            q.Accept="application/vnd.github+json";
            q.Headers["Authorization"]="Bearer "+token;
            q.Headers["X-GitHub-Api-Version"]="2022-11-28";
            // A redirect is an answer of its own (never followed with the token).
            q.AllowAutoRedirect=false;
            q.ServicePoint.Expect100Continue=false;
            q.Timeout=timeoutMs;q.ReadWriteTimeout=StallMs;
            return q;
        }
        // {"message":...,"content":"<base64>"}, written in pieces (a big ZIP isn't held twice as text).
        static int SendContent(HttpWebRequest q,string message,byte[] bytes,out string text) {
            byte[] head=Encoding.UTF8.GetBytes("{\"message\":"+new JavaScriptSerializer().Serialize(message??"")+",\"content\":\"");
            byte[] tail=Encoding.ASCII.GetBytes("\"}");
            long base64=(bytes.LongLength+2)/3*4;
            q.ContentType="application/json";
            q.ContentLength=head.Length+base64+tail.Length;
            q.AllowWriteStreamBuffering=false;
            using(var s=q.GetRequestStream()) {
                s.Write(head,0,head.Length);
                const int chunk=3*16384;
                for(int at=0;at<bytes.Length;at+=chunk) {
                    byte[] part=Encoding.ASCII.GetBytes(Convert.ToBase64String(bytes,at,Math.Min(chunk,bytes.Length-at)));
                    s.Write(part,0,part.Length);
                }
                s.Write(tail,0,tail.Length);
            }
            return Answer(q,out text);
        }
        static int Send(HttpWebRequest q,byte[] body,out string text) {
            if(body!=null) {
                q.ContentType="application/json";q.ContentLength=body.Length;
                using(var s=q.GetRequestStream()) s.Write(body,0,body.Length);
            }
            return Answer(q,out text);
        }
        static int Answer(HttpWebRequest q,out string text) {
            try {
                using(var r=(HttpWebResponse)q.GetResponse()) { text=Read(r);return (int)r.StatusCode; }
            } catch(WebException e) {
                var r=e.Response as HttpWebResponse;
                if(r==null) throw;
                using(r) { text=Read(r);return (int)r.StatusCode; }
            }
        }
        static string Read(HttpWebResponse r) {
            try {
                using(var s=r.GetResponseStream()) using(var reader=new StreamReader(s,Encoding.UTF8)) {
                    var buffer=new char[64*1024];int n=reader.ReadBlock(buffer,0,buffer.Length);
                    return new string(buffer,0,n);
                }
            } catch(Exception) { return ""; }
        }
        static Dictionary<string,object> Json(string text) {
            try { return new JavaScriptSerializer().DeserializeObject(text??"") as Dictionary<string,object>; } catch(Exception) { return null; }
        }
        // GitHub's own words, when it gave some (": Resource not accessible by personal access token").
        static string Said(string text) {
            var j=Json(text);object m;
            if(j==null||!j.TryGetValue("message",out m)||!(m is string)||((string)m).Trim().Length==0) return "";
            return " ("+Clip((string)m)+")";
        }
        static readonly Regex Secret=new Regex(@"(?:github_pat_|gh[pousr]_)[A-Za-z0-9_]+");
        internal static string Clip(string s) {
            s=Secret.Replace(Regex.Replace(s??"",@"[\x00-\x1f\x7f]+"," ").Trim(),"[token]");
            return s.Length>160?s.Substring(0,160)+"...":s;
        }
        static DiagUploadResult Fail(string code,string why) { return new DiagUploadResult { Code=code,Why=why }; }
    }

    // The GitHub upload window: the steps to make the token, a box to paste it, Save (checks it with GitHub first) and
    // Remove. It is laid out from its text (labels wrap at about 78 characters of its font and the window grows), so it
    // fits at any Windows scaling. While a token is being checked it can't be closed, so the outcome is always seen.
    internal sealed class DiagUploadForm : Form {
        readonly string app,version;
        readonly Label state=new Label { AutoSize=true,UseMnemonic=false,Margin=new Padding(0,10,0,6) };
        readonly TextBox token=new TextBox { UseSystemPasswordChar=true };
        readonly Button open=Make("Open GitHub"),save=Make("Save"),remove=Make("Remove for this Windows login"),close=Make("Close");
        bool busy;

        internal static void ShowFor(IWin32Window owner,string app,string version) {
            using(var f=new DiagUploadForm(app,version)) { if(owner!=null) f.ShowDialog(owner); else f.ShowDialog(); }
        }
        static Button Make(string text) { return new Button { Text=text,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Padding=new Padding(8,3,8,3),Margin=new Padding(0,0,8,0) }; }

        // What the window says before anything is done (pure, for the tests).
        internal static string StateWords(bool kept,bool usable) {
            if(!kept) return "Not set up for this Windows login: diagnostics are only saved on this PC.";
            if(!usable) return "The token kept for this Windows login can't be read here: paste a new token and click Save, or click Remove.";
            return "Set up for this Windows login: each saved diagnostics ZIP is uploaded. Paste a new token here to replace it.";
        }
        internal static string Steps(string machine) {
            return "Saved diagnostics also go to Tommy's private GitHub repository "+DiagUpload.RepoName+", so Claude can read them there. "+
                "Only the diagnostics ZIP is sent (masked: no customer details).\r\n\r\n"+
                "Once for each Windows login on each PC (the Tempe helper and Ebay-auto share it under the same login). "+
                "The same token can be pasted on every PC.\r\n"+
                "1. Click Open GitHub (signed in as "+DiagUpload.Owner+"). The page comes with the name (Tempe diagnostics "+DiagUpload.Name(machine,"PC",32)+"), "+
                "owner "+DiagUpload.Owner+", no expiry and Contents: Read and write filled in. If it doesn't: Expiration No expiration, "+
                "Repository permissions, Contents: Read and write.\r\n"+
                "2. Repository access: Only select repositories, then pick "+DiagUpload.Repo+".\r\n"+
                "3. Click Generate token, copy it, paste it below and click Save.";
        }

        internal DiagUploadForm(string app,string version) {
            this.app=app;this.version=version;
            Text="GitHub upload";FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;ShowInTaskbar=false;
            StartPosition=FormStartPosition.CenterParent;Font=new Font("Segoe UI",9.5f);
            AutoSize=true;AutoSizeMode=AutoSizeMode.GrowAndShrink;Padding=new Padding(14);CancelButton=close;
            int wrap=TextRenderer.MeasureText(new string('n',78),Font).Width;
            var steps=new Label { AutoSize=true,UseMnemonic=false,MaximumSize=new Size(wrap,0),Text=Steps(DiagUpload.Machine()),Margin=new Padding(0,0,0,10) };
            state.MaximumSize=new Size(wrap,0);
            var paste=new Label { Text="Token (github_pat_...):",AutoSize=true,Margin=new Padding(0,0,0,3) };
            token.Width=wrap;token.Margin=new Padding(0);
            var buttons=new FlowLayoutPanel { AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,FlowDirection=FlowDirection.LeftToRight,WrapContents=false,Margin=new Padding(0,4,0,0) };
            buttons.Controls.AddRange(new Control[] { open,save,remove,close });
            var all=new TableLayoutPanel { AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,ColumnCount=1,Dock=DockStyle.Fill };
            foreach(Control c in new Control[] { steps,paste,token,state,buttons }) { all.RowStyles.Add(new RowStyle(SizeType.AutoSize));all.Controls.Add(c); }
            Controls.Add(all);
            open.Click+=delegate {
                string page=DiagUpload.TokenPageFor(DiagUpload.Machine());
                try { Process.Start(page); } catch(Exception e) { Say("GitHub couldn't be opened ("+DiagUpload.Clip(e.Message)+"): open "+DiagUpload.TokenPage+" yourself."); }
            };
            save.Click+=delegate { Check(); };
            remove.Click+=delegate {
                Say(DiagUpload.Forget()?"Removed for this Windows login: diagnostics aren't uploaded from it until it's set up again. Other logins and PCs keep theirs; deleting the token on GitHub stops it everywhere.":"The token couldn't be removed: close the Tempe helper and Ebay-auto and try again.");
                remove.Enabled=DiagUpload.HasToken;
            };
            token.KeyDown+=delegate(object s,KeyEventArgs e) { if(e.KeyCode==Keys.Enter) { e.SuppressKeyPress=true;Check(); } };
            FormClosing+=delegate(object s,FormClosingEventArgs e) {
                if(busy&&e.CloseReason==CloseReason.UserClosing) { e.Cancel=true;Say("Still checking the token with GitHub: wait for the answer (at most a minute or two)."); }
            };
            remove.Enabled=DiagUpload.HasToken;
            Say(StateWords(DiagUpload.HasToken,DiagUpload.TokenUsable));
        }
        void Say(string text) { state.Text=text; }
        void Check() {
            if(busy) return;
            string pasted=token.Text;
            if(pasted.Trim().Length==0) { Say("Paste the token first.");return; }
            busy=true;save.Enabled=remove.Enabled=open.Enabled=token.Enabled=close.Enabled=false;Say("Checking the token with GitHub ...");
            ThreadPool.QueueUserWorkItem(delegate(object unused) {
                DiagUploadResult r;
                try { r=DiagUpload.SetUp(pasted,app,version); } catch(Exception e) { r=new DiagUploadResult { Code="failed",Why=DiagUpload.Clip(e.Message) }; }
                pasted=null;
                if(IsDisposed) return;
                try {
                    BeginInvoke(new Action(delegate {
                        busy=false;save.Enabled=open.Enabled=token.Enabled=close.Enabled=true;
                        if(r.Ok) { token.Text="";Say("Set up: the token works ("+r.RepoPath+" was written) and is kept for this Windows login. Each saved diagnostics ZIP is now uploaded."); }
                        else Say("Not set up: "+r.Why+".");
                        remove.Enabled=DiagUpload.HasToken;
                    }));
                } catch(InvalidOperationException) { }
            });
        }
    }
}
