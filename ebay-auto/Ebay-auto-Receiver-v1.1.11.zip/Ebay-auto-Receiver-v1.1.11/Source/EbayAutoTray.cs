// Ebay-auto 1.0.0: what both parts' windows share. They start in the notification area (the window hidden), keep working
// while hidden, hide again when X is clicked, come back from the tray icon (double-click, or Open), and have Open,
// Start/Pause, Export diagnostics and Exit there. Exit is the one way to close them (it stops safely first). The icon's
// colour and words say how things stand: green ready, blue working, amber waiting or something to look at, red stopped or
// out of touch, grey paused. A second start of the same part opens the running one's window instead.
// 1.1.0: a compact window (tabs) sized for the screen it opens on and its scaling; Minimise hides it too, so it is never
// left on the taskbar; a message the window asks or tells always opens the window first (never a box behind nothing);
// the Updates tab (EbayAutoUpdater) and an "Update to ..." tray item; the window checks its own layout at the scaling it
// runs with and writes what it found in the journey (diagnostics).
// 1.1.11 (26 Nov 2026): GitHub upload... beside Export diagnostics (and a GitHub upload button beside it on the More tab):
// the setup window of DiagUpload. Each exported ZIP is then also uploaded to Tommy's private GitHub repository, off this
// window's thread (EbayAutoUpload).
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace TempeCostar {
    internal enum TrayState { Ready, Working, Attention, Problem, Paused }
    // Pure: the window's size for a scaling and a screen, and a layout check (the self-tests check both).
    internal static class EbayAutoLayout {
        // The window's client size: wanted (at 100 %) times the scale, never more than the screen's working area allows
        // (less a margin and the window's frame: title bar and borders); min likewise. Returns {width,height,minWidth,minHeight}.
        internal static int[] Size(int width,int height,int minWidth,int minHeight,float scale,Rectangle area,Size frame) {
            int margin=(int)Math.Round(24*scale);
            int maxW=Math.Max(200,area.Width-margin-frame.Width),maxH=Math.Max(160,area.Height-margin-frame.Height);
            int w=Math.Min((int)Math.Round(width*scale),maxW),h=Math.Min((int)Math.Round(height*scale),maxH);
            int mw=Math.Min((int)Math.Round(minWidth*scale),w),mh=Math.Min((int)Math.Round(minHeight*scale),h);
            return new[]{w,h,mw,mh};
        }
        // Bottom-right of the working area (by the clock), inside it.
        internal static Point Place(Size outer,Rectangle area,float scale) {
            int margin=(int)Math.Round(12*scale);
            return new Point(Math.Max(area.Left,area.Right-outer.Width-margin),Math.Max(area.Top,area.Bottom-outer.Height-margin));
        }
        // What is wrong with controls laid out in a page of the given width (each: name, bounds within the page): one
        // reaching past the page's width (it scrolls sideways: still usable, but said), or two overlapping. Empty: fine.
        internal static List<string> Problems(IList<KeyValuePair<string,Rectangle>> boxes,int width) {
            var problems=new List<string>();
            foreach(var b in boxes) {
                if(b.Value.Width<=0||b.Value.Height<=0) problems.Add(b.Key+" has no size");
                else if(b.Value.Right>width+1) problems.Add(b.Key+" reaches "+(b.Value.Right-width)+" px past the page (it scrolls)");
            }
            for(int i=0;i<boxes.Count;i++) for(int j=i+1;j<boxes.Count;j++) {
                var a=boxes[i].Value;var c=boxes[j].Value;a.Inflate(-1,-1);c.Inflate(-1,-1);
                if(a.Width>0&&a.Height>0&&c.Width>0&&c.Height>0&&a.IntersectsWith(c)) problems.Add(boxes[i].Key+" overlaps "+boxes[j].Key);
            }
            return problems;
        }
    }
    internal abstract class EbayAutoForm : Form {
        [DllImport("user32.dll")] static extern bool DestroyIcon(IntPtr handle);
        protected readonly NotifyIcon tray=new NotifyIcon {Visible=false};
        readonly ContextMenuStrip menu=new ContextMenuStrip();
        readonly ToolStripMenuItem openItem=new ToolStripMenuItem("Open"),toggleItem=new ToolStripMenuItem("Pause"),updateItem=new ToolStripMenuItem("Update"),exportItem=new ToolStripMenuItem("Export diagnostics"),uploadItem=new ToolStripMenuItem("GitHub upload..."),exitItem=new ToolStripMenuItem("Exit");
        readonly Icon[] icons=new Icon[5];readonly IntPtr[] handles=new IntPtr[5];
        bool allowVisible,exiting,toldHidden,updateExit;TrayState shown=(TrayState)(-1);string tip="";
        EventWaitHandle showSignal;Thread showWatch;volatile bool closing;
        internal readonly string Part;
        // 1.1.0: the scaling this window runs at (1 = 96 dpi) and its pixel sizes at that scaling.
        protected readonly float K;
        protected int S(int px) { return (int)Math.Round(px*K); }
        protected readonly TabControl Tabs=new TabControl {Dock=DockStyle.Fill};
        protected readonly EbayAutoUpdater Updates;
        readonly List<TabPage> checkedPages=new List<TabPage>();
        protected readonly DateTime StartedUtc=DateTime.UtcNow;
        protected EbayAutoForm(string part,bool startVisible) {
            Part=part;allowVisible=startVisible;
            using(var g=Graphics.FromHwnd(IntPtr.Zero)) K=Math.Max(1f,g.DpiX/96f);
            Text=Product.Name+" "+part+" "+Product.Version;Font=Ui.Base;BackColor=Ui.Canvas;StartPosition=FormStartPosition.Manual;
            AutoScaleMode=AutoScaleMode.None;
            for(int i=0;i<5;i++) { using(var b=Draw((TrayState)i)) { handles[i]=b.GetHicon();icons[i]=Icon.FromHandle(handles[i]); } }
            Icon=icons[0];
            updateItem.Visible=false;updateItem.Font=new Font(updateItem.Font,FontStyle.Bold);
            menu.Items.Add(openItem);menu.Items.Add(toggleItem);menu.Items.Add(updateItem);menu.Items.Add(exportItem);menu.Items.Add(uploadItem);menu.Items.Add(new ToolStripSeparator());menu.Items.Add(exitItem);
            openItem.Font=new Font(openItem.Font,FontStyle.Bold);
            openItem.Click+=delegate { ShowFromTray(); };
            toggleItem.Click+=delegate { Attempt(TrayToggle); };
            updateItem.Click+=delegate { Attempt(delegate { ShowUpdates();Updates.Begin(); }); };
            exportItem.Click+=delegate { Attempt(ExportDiagnostics); };
            uploadItem.Click+=delegate { Attempt(OpenUploadSetup); };   // 1.1.11
            exitItem.Click+=delegate { RequestExit(); };
            menu.Opening+=delegate {
                toggleItem.Text=ToggleWords;toggleItem.Enabled=ToggleEnabled;
                var r=Updates.Release;bool can=r!=null&&Updates.Now==EbayAutoUpdater.Stage.Available;
                updateItem.Visible=can;if(can) updateItem.Text="Update to "+r.version;
            };
            tray.ContextMenuStrip=menu;tray.Icon=icons[(int)TrayState.Paused];tray.Text=Product.Name+" "+part;
            tray.DoubleClick+=delegate { ShowFromTray(); };
            tray.BalloonTipClicked+=delegate { ShowFromTray(); };
            tray.Visible=true;
            // The update steps for this part (the window shows them on its Updates tab).
            Updates=new EbayAutoUpdater(part);
            Updates.Note=delegate(string line) { int colon=line.IndexOf(':');Journey.Note(colon>0?line.Substring(0,colon):"update","","",colon>0?line.Substring(colon+1).Trim():line);AppLog.Note("update",line); };
            Updates.NotSafe=UpdateNotSafe;Updates.Hold=UpdateHold;Updates.Unhold=UpdateUnhold;
            Updates.Resume=delegate { var s=UpdateResume();s.shown=Visible;return s; };
            Updates.Stop=delegate { UpdateStop();tray.Visible=false;EbayAutoProgram.ReleaseInstance(); };
            Updates.Exit=delegate { try { BeginInvoke(new Action(delegate { updateExit=true;exiting=true;Close(); })); } catch(InvalidOperationException) { } };
            Updates.Found=delegate(EbayRelease r) { try { BeginInvoke(new Action(delegate { Balloon("Ebay-auto "+r.version+" is available","Open the "+Part.ToLowerInvariant()+" (Updates tab) and click Update now: it waits for a safe moment and keeps everything.",ToolTipIcon.Info); })); } catch(InvalidOperationException) { } };
            // An update that didn't start: this version was started again with its window open; the Updates tab says why.
            var failed=EbayAutoUpdate.TakeFailure(part);
            Updates.Failed(failed);
            if(failed!=null) Shown+=delegate { ShowUpdates();Balloon("The update to "+failed.to+" didn't start",Product.Name+" "+Product.Version+" is running again: the Updates tab says why.",ToolTipIcon.Warning); };
            // A second start of this part asks this one to show its window (Program sets the event).
            try {
                showSignal=new EventWaitHandle(false,EventResetMode.AutoReset,ShowEventName(part));
                showWatch=new Thread(delegate() {
                    while(!closing) {
                        try { if(showSignal.WaitOne(1000)&&!closing&&IsHandleCreated) BeginInvoke(new Action(ShowFromTray)); }
                        catch(ObjectDisposedException) { return; } catch(InvalidOperationException) { }
                    }
                });
                showWatch.IsBackground=true;showWatch.Start();
            } catch(Exception) { showSignal=null; }
            FormClosing+=OnClosingToTray;
            FormClosed+=delegate {
                closing=true;tray.Visible=false;tray.Dispose();
                for(int i=0;i<5;i++) { try { icons[i].Dispose();DestroyIcon(handles[i]); } catch(Exception) { } }
                try { if(showSignal!=null) showSignal.Dispose(); } catch(Exception) { }
            };
            Tabs.SelectedIndexChanged+=delegate { CheckLayout(Tabs.SelectedTab); };
            Shown+=delegate { CheckLayout(Tabs.SelectedTab); };
        }
        internal static string ShowEventName(string part) { return Product.ShowEventName(part); }
        // The window's size and place: wanted at 100 % (scaled for this screen), bottom-right by the clock.
        protected void Compact(int width,int height,int minWidth,int minHeight) {
            var area=Screen.FromPoint(Cursor.Position).WorkingArea;
            var frame=new Size(Width-ClientSize.Width,Height-ClientSize.Height);
            var s=EbayAutoLayout.Size(width,height,minWidth,minHeight,K,area,frame);
            ClientSize=new Size(s[0],s[1]);MinimumSize=new Size(0,0);
            var outer=Size;MinimumSize=new Size(s[2]+(outer.Width-ClientSize.Width),s[3]+(outer.Height-ClientSize.Height));
            Location=EbayAutoLayout.Place(outer,area,K);
        }
        // Kept hidden until it is to be shown (it still has its handle, timers and threads: it works hidden).
        protected override void SetVisibleCore(bool value) {
            if(!allowVisible) { value=false;if(!IsHandleCreated) CreateHandle(); }
            base.SetVisibleCore(value);
        }
        internal void ShowFromTray() {
            allowVisible=true;
            if(!Visible) Show();
            // Hidden while minimised (Windows+M, the taskbar's button): restored here, never left as a taskbar button only.
            if(WindowState==FormWindowState.Minimized||(IsHandleCreated&&Native.IsIconic(Handle))) WindowState=FormWindowState.Normal;
            KeepOnScreen();
            Activate();BringToFront();
        }
        // Back inside the screen's working area when it isn't (a Remote Desktop window made smaller meanwhile, another
        // screen gone): its size within the area, by the clock.
        void KeepOnScreen() {
            try {
                if(WindowState!=FormWindowState.Normal) return;
                var area=Screen.FromControl(this).WorkingArea;
                if(area.Contains(Bounds)) return;
                MinimumSize=new Size(Math.Min(MinimumSize.Width,area.Width),Math.Min(MinimumSize.Height,area.Height));
                Size=new Size(Math.Min(Width,area.Width),Math.Min(Height,area.Height));
                Location=EbayAutoLayout.Place(Size,area,K);
            } catch(Exception) { }
        }
        // Minimise or X: the window goes (and with it its taskbar button); everything goes on working.
        void HideToTray() {
            Hide();
            if(!toldHidden) { toldHidden=true;Balloon(Product.Name+" "+Part+" is still running","It keeps working in the notification area. Double-click its icon to open it; right-click it for Exit.",ToolTipIcon.Info); }
        }
        protected override void WndProc(ref Message m) {
            // WM_SYSCOMMAND SC_MINIMIZE (the button, Alt+Space N): hidden instead.
            if(m.Msg==0x0112&&(m.WParam.ToInt64()&0xFFF0)==0xF020) { HideToTray();return; }
            base.WndProc(ref m);
        }
        protected override void OnResize(EventArgs e) {
            base.OnResize(e);
            // Minimised another way (Windows+M, the taskbar's button): hidden as well, unless opened again meanwhile.
            if(WindowState==FormWindowState.Minimized&&Visible) BeginInvoke(new Action(delegate { if(WindowState==FormWindowState.Minimized&&Visible) HideToTray(); }));
        }
        // X hides (never stops anything); Windows shutting down or signing out, or Exit, closes.
        void OnClosingToTray(object sender,FormClosingEventArgs e) {
            if(exiting||e.CloseReason==CloseReason.WindowsShutDown||e.CloseReason==CloseReason.TaskManagerClosing) {
                if(!exiting) { exiting=true;Shutdown(e.CloseReason.ToString()); }
                return;
            }
            e.Cancel=true;HideToTray();
        }
        // Exit: the part may first need to stop safely (ConfirmExit false: try again when Ready says so).
        internal void RequestExit() {
            if(Updates.Now==EbayAutoUpdater.Stage.Switching) return;
            if(!ConfirmExit()) return;
            if(Updates.Now==EbayAutoUpdater.Stage.Waiting) Updates.Cancel();
            exiting=true;Shutdown("Exit");Close();
        }
        // A box the window asks or tells: the window is opened first, so the box is never behind nothing.
        protected DialogResult Ask(string text,string caption,MessageBoxButtons buttons,MessageBoxIcon icon,MessageBoxDefaultButton first) {
            ShowFromTray();return MessageBox.Show(this,text,caption,buttons,icon,first);
        }
        protected void Tell(string text) { ShowFromTray();MessageBox.Show(this,text,Product.Name); }
        protected void Tell(string text,string caption) { ShowFromTray();MessageBox.Show(this,text,caption); }
        protected void Attempt(Action action) { try { action(); } catch(Exception e) { Tell(e.Message); } }
        protected void Balloon(string title,string text,ToolTipIcon icon) {
            try { tray.ShowBalloonTip(10000,Trim(title,60),Trim(text,250),icon); } catch(Exception) { }
        }
        // The icon and its words (Windows shows 63 characters at most).
        protected void SetTray(TrayState state,string words) {
            if(Updates.Now==EbayAutoUpdater.Stage.Waiting||Updates.Now==EbayAutoUpdater.Stage.Switching) { state=TrayState.Working;words="updating to "+(Updates.Release==null?"":Updates.Release.version); }
            if(state!=shown) { shown=state;tray.Icon=icons[(int)state]; }
            string t=Trim(Product.Name+" "+Part+": "+(words??""),63);
            if(t!=tip) { tip=t;try { tray.Text=t; } catch(ArgumentException) { } }
        }
        static string Trim(string s,int n) { s=s??"";return s.Length<=n?s:s.Substring(0,n-1)+"…"; }
        // ---- pages ----
        // A tab whose controls stack top-down and scroll when the window is small; labels wrap to the page's width.
        protected FlowLayoutPanel Page(string title) {
            var page=new TabPage(title) {BackColor=Ui.Canvas,Padding=new Padding(0)};
            var flow=new FlowLayoutPanel {Dock=DockStyle.Fill,FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoScroll=true,Padding=new Padding(S(10)),BackColor=Ui.Canvas};
            page.Controls.Add(flow);Tabs.TabPages.Add(page);
            flow.Resize+=delegate { Fit(flow); };
            flow.ControlAdded+=delegate { Fit(flow); };
            return flow;
        }
        // Wrapping text and button rows follow the page's width (less its padding and a scroll bar).
        protected void Fit(FlowLayoutPanel flow) {
            int width=Math.Max(S(160),flow.ClientSize.Width-flow.Padding.Horizontal-SystemInformation.VerticalScrollBarWidth);
            foreach(Control c in flow.Controls) {
                if(c is Label&&c.MaximumSize.Width>0) c.MaximumSize=new Size(width,0);
                else if(c is FlowLayoutPanel) c.MaximumSize=new Size(width,0);
                else if(c is CheckBox) c.MaximumSize=new Size(width,0);
            }
        }
        protected Label Line(string text) { return new Label {Text=text,AutoSize=true,Font=Ui.Base,ForeColor=Ui.Ink,MaximumSize=new Size(S(500),0),Margin=new Padding(0,0,0,S(4))}; }
        protected Label Note(string text) { return new Label {Text=text,AutoSize=true,Font=Ui.Small,ForeColor=Ui.Muted,MaximumSize=new Size(S(500),0),Margin=new Padding(0,0,0,S(4))}; }
        protected Label Heading(string text) { return new Label {Text=text,AutoSize=true,Font=Ui.Bold,ForeColor=Ui.Ink,Margin=new Padding(0,S(6),0,S(4))}; }
        protected FlowLayoutPanel Buttons(params Control[] items) {
            var row=new FlowLayoutPanel {AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,FlowDirection=FlowDirection.LeftToRight,WrapContents=true,Margin=new Padding(0,0,0,S(6)),Padding=new Padding(0),MaximumSize=new Size(S(500),0)};
            foreach(var c in items) { c.Margin=new Padding(0,0,S(6),S(6));row.Controls.Add(c); }
            return row;
        }
        protected Button Primary(string text) { var b=Ui.PrimaryButton(text,S(90));b.Height=S(32);b.MinimumSize=new Size(S(90),S(32));return b; }
        protected Button Secondary(string text) { var b=Ui.SecondaryButton(text,S(90));b.Height=S(32);b.MinimumSize=new Size(S(90),S(32));return b; }
        protected Button Danger(string text) { var b=Ui.DangerButton(text,S(90));b.Height=S(32);b.MinimumSize=new Size(S(90),S(32));return b; }
        protected CheckBox TickBox(string text,bool on) { var c=Ui.Check(text,on);c.MaximumSize=new Size(S(500),0);c.Margin=new Padding(0,S(3),0,S(3));return c; }
        // ---- the Updates tab ----
        readonly Label updInstalled=new Label {AutoSize=true,Font=Ui.Base},updOnline=new Label {AutoSize=true,Font=Ui.Base},updState=new Label {AutoSize=true,Font=Ui.Bold},updOther=new Label {AutoSize=true,Font=Ui.Small,ForeColor=Ui.Muted};
        Button updCheck,updNow,updCancel;readonly ProgressBar updBar=new ProgressBar {Minimum=0,Maximum=100,Visible=false};
        protected void BuildUpdatesPage() {
            var f=Page("Updates");
            foreach(var l in new[]{updInstalled,updOnline,updState,updOther}) { l.MaximumSize=new Size(S(500),0);l.Margin=new Padding(0,0,0,S(6)); }
            updCheck=Secondary("Check for updates");updNow=Primary("Update now");updCancel=Secondary("Cancel update");
            updBar.Size=new Size(S(300),S(14));updBar.Margin=new Padding(0,0,0,S(8));
            f.Controls.Add(updInstalled);f.Controls.Add(updOnline);f.Controls.Add(updState);f.Controls.Add(updBar);
            f.Controls.Add(Buttons(updCheck,updNow,updCancel));f.Controls.Add(updOther);
            f.Controls.Add(Note("Updates come only from Ebay-auto's own folder on Tommy's GitHub page and are checked (fingerprint, file list, product, part, version) and built on this PC before anything changes. The switch waits until nothing is being entered; the queue, pairing, certificate, settings, history and Start with Windows are kept, and it comes back as it was (running or paused, window open or hidden). If the new version doesn't start, this one starts again and says why."));
            updCheck.Click+=delegate { Attempt(delegate { Updates.Check(true); }); };
            updNow.Click+=delegate { Attempt(Updates.Begin); };
            updCancel.Click+=delegate { Attempt(Updates.Cancel); };
        }
        protected void ShowUpdates() { ShowFromTray();foreach(TabPage p in Tabs.TabPages) if(p.Text=="Updates") Tabs.SelectedTab=p; }
        // The other part's version, for the Updates tab ("" when not known).
        protected abstract string OtherPartVersion { get; }
        // Once a second.
        protected void UpdateTick() {
            Updates.AutoCheck(StartedUtc);Updates.Tick();
            if(updCheck==null) return;
            var stage=Updates.Now;var r=Updates.Release;
            Ui.SetText(updInstalled,"This "+Part.ToLowerInvariant()+": "+Product.Name+" "+Product.Version+" (protocol "+Product.Protocol+")");
            DateTime at=Updates.CheckedAt;
            Ui.SetText(updOnline,r!=null?"On GitHub: "+r.version+(String.IsNullOrEmpty(r.name)?"":" - "+r.name)+(String.IsNullOrEmpty(r.notes)?"":"\r\n"+r.notes):
                stage==EbayAutoUpdater.Stage.UpToDate?"On GitHub: nothing newer (checked "+at.ToString("d MMM HH:mm",CultureInfo.InvariantCulture)+")":at==DateTime.MinValue?"On GitHub: not checked yet (it checks a minute after starting, then every 6 hours)":"On GitHub: checked "+at.ToString("d MMM HH:mm",CultureInfo.InvariantCulture));
            string words;Color colour=Ui.Ink;
            switch(stage) {
                case EbayAutoUpdater.Stage.Checking: words="Checking GitHub ...";break;
                case EbayAutoUpdater.Stage.UpToDate: words="You have the newest version.";colour=Ui.Success;break;
                case EbayAutoUpdater.Stage.Available: words="Ebay-auto "+r.version+" is ready to install: click Update now."+(EbayAutoUpdate.ProtocolNote(r,Part)==null?"":"\r\n"+EbayAutoUpdate.ProtocolNote(r,Part));colour=Ui.Primary;break;
                case EbayAutoUpdater.Stage.Downloading: case EbayAutoUpdater.Stage.Building: case EbayAutoUpdater.Stage.Waiting: case EbayAutoUpdater.Stage.Switching: words=Updates.Words;colour=Ui.Info;break;
                case EbayAutoUpdater.Stage.Failed: words=Updates.Error;colour=Ui.Danger;break;
                default: words="";break;
            }
            Ui.SetText(updState,words);if(updState.ForeColor!=colour) updState.ForeColor=colour;
            int p=Updates.Percent;bool bar=stage==EbayAutoUpdater.Stage.Downloading&&p>=0;
            if(updBar.Visible!=bar) updBar.Visible=bar;if(bar&&updBar.Value!=p) updBar.Value=Math.Max(0,Math.Min(100,p));
            updCheck.Enabled=!Updates.Busy;updNow.Enabled=stage==EbayAutoUpdater.Stage.Available;updCancel.Enabled=stage==EbayAutoUpdater.Stage.Waiting;
            updNow.Text=r!=null&&stage==EbayAutoUpdater.Stage.Available?"Update now to "+r.version:"Update now";
            string other=OtherPartVersion;
            Ui.SetText(updOther,other.Length==0?"":(Part==Product.ReceiverMode?"The worker (in Remote Desktop): ":"The receiver (Seb's PC): ")+other+(other.StartsWith(Product.Version,StringComparison.Ordinal)?"":" - they work together while their versions differ (same protocol); update it too when you can."));
        }
        // ---- the layout check (journey) ----
        // Each tab the first time it shows: its controls at this scaling and size, and anything that doesn't fit.
        void CheckLayout(TabPage page) {
            if(page==null||checkedPages.Contains(page)||!Visible) return;
            checkedPages.Add(page);
            try {
                var flow=page.Controls.Count>0?page.Controls[0]:null;
                var boxes=new List<KeyValuePair<string,Rectangle>>();
                if(flow is FlowLayoutPanel) foreach(Control c in flow.Controls) if(c.Visible) boxes.Add(new KeyValuePair<string,Rectangle>(Describe(c),c.Bounds));
                int width=flow==null?page.ClientSize.Width:flow.ClientSize.Width;
                var problems=EbayAutoLayout.Problems(boxes,width);
                Journey.Note("layout_check","","","tab "+page.Text+" at "+((int)Math.Round(K*96))+" dpi ("+((int)Math.Round(K*100))+" %), window "+ClientSize.Width+"x"+ClientSize.Height+", screen "+Screen.FromControl(this).WorkingArea.Width+"x"+Screen.FromControl(this).WorkingArea.Height+": "+boxes.Count+" controls, "+(problems.Count==0?"all fit":String.Join("; ",problems.Take(6).ToArray())));
            } catch(Exception e) { Journey.Note("layout_check","","","tab "+page.Text+": not checked ("+e.GetType().Name+")"); }
        }
        static string Describe(Control c) {
            string t=c.Text??"";
            if(c is Label) t="text \""+(t.Length>24?t.Substring(0,24)+"…":t)+"\"";
            else if(c is FlowLayoutPanel) t="row of "+c.Controls.Count;
            return c.GetType().Name+" "+t;
        }
        // 1.1.0: older builds of this program (each update builds one) are removed; the two newest builds and the running
        // one are kept (Cleanup.Runtimes), so the version before an update can start again from its own.
        protected static void TidyRuntimes() {
            ThreadPool.QueueUserWorkItem(delegate {
                try { var plan=Cleanup.Runtimes(System.IO.Path.Combine(Product.Home,"runtime"),AppDomain.CurrentDomain.BaseDirectory);foreach(var f in plan.Folders) { try { System.IO.Directory.Delete(f,true); } catch(Exception) { } } } catch(Exception) { }
            });
        }
        // ---- the parts' own ----
        // The tray's Start/Pause, Export diagnostics, whether Exit may go ahead, and what Exit stops.
        protected abstract string ToggleWords { get; }
        protected virtual bool ToggleEnabled { get { return true; } }
        protected abstract void TrayToggle();
        protected abstract void ExportDiagnostics();
        // ---- 1.1.11: GitHub upload (EbayAutoUpload, DiagUpload) ----
        Label uploadState;
        // The GitHub upload window (paste the token, Save, Remove for this Windows login): this window is opened first, so it is
        // never behind nothing. It needs no COSTAR, and the work goes on while it is open (as with any message box).
        protected void OpenUploadSetup() {
            ShowFromTray();
            DiagUploadForm.ShowFor(this,EbayAutoUpload.App(Part),Product.Version);
            if(uploadState!=null&&!uploadBusy) Ui.SetText(uploadState,UploadSetUpWords);
        }
        protected Button UploadButton() { var b=Secondary("GitHub upload");b.Click+=delegate { Attempt(OpenUploadSetup); };return b; }
        // The More tab's line: set up or not, then the last upload's words.
        protected Label UploadState() { if(uploadState==null) uploadState=Note(UploadSetUpWords);return uploadState; }
        static string UploadSetUpWords { get { return EbayAutoUpload.SetUpLine(DiagUpload.HasToken,DiagUpload.TokenUsable); } }
        volatile bool uploadBusy;
        // On this window's thread, once Export diagnostics has saved a ZIP: its upload is started (on a pool thread; set up
        // only) and the line the save message ends with comes back. What the upload ends with is said without opening the
        // window or taking the focus (a balloon, the More tab's line, and the worker's log): never a box over COSTAR.
        protected string UploadSaved(string saved) {
            string line;
            try {
                uploadBusy=true;
                line=EbayAutoUpload.Start(saved,Part,UploadEnded);
                if(line!=EbayAutoUpload.Uploading) uploadBusy=false;
            } catch(Exception e) { uploadBusy=false;line="Not uploaded to GitHub: "+DiagUpload.Clip(e.Message)+". The ZIP is saved at "+saved+": send it by hand."; }
            try { if(uploadState!=null) Ui.SetText(uploadState,line);UploadNoted(line); } catch(Exception) { }
            return line;
        }
        // On the pool thread.
        void UploadEnded(string words,bool ok) {
            if(IsDisposed) return;
            try {
                BeginInvoke(new Action(delegate {
                    if(IsDisposed) return;
                    uploadBusy=false;
                    if(uploadState!=null) Ui.SetText(uploadState,words);
                    UploadNoted(words);
                    Balloon(ok?"Uploaded to GitHub":"Not uploaded to GitHub",words,ok?ToolTipIcon.Info:ToolTipIcon.Warning);
                }));
            } catch(InvalidOperationException) { }
        }
        // The worker writes them in its log too.
        protected virtual void UploadNoted(string words) { }
        protected abstract bool ConfirmExit();
        protected abstract void Shutdown(string why);
        // The update's hooks: why the switch must wait (null: now), holding new work back, what to restore, and what to stop.
        protected abstract string UpdateNotSafe();
        protected virtual void UpdateHold() { }
        protected virtual void UpdateUnhold() { }
        protected abstract EbayResumeState UpdateResume();
        protected abstract void UpdateStop();
        // True when this window is closing for an update (the new version is up).
        protected bool ClosingForUpdate { get { return updateExit; } }
        // A round icon with an "e": its colour says how things stand.
        static Bitmap Draw(TrayState state) {
            Color c=state==TrayState.Ready?Ui.Success:state==TrayState.Working?Ui.Primary:state==TrayState.Attention?Ui.Gold:state==TrayState.Problem?Ui.Danger:Ui.Muted;
            var b=new Bitmap(32,32);
            using(var g=Graphics.FromImage(b)) {
                g.SmoothingMode=SmoothingMode.AntiAlias;g.Clear(Color.Transparent);
                using(var brush=new SolidBrush(c)) g.FillEllipse(brush,1,1,30,30);
                using(var font=new Font("Segoe UI",16F,FontStyle.Bold,GraphicsUnit.Pixel))
                using(var format=new StringFormat {Alignment=StringAlignment.Center,LineAlignment=StringAlignment.Center})
                    g.DrawString("e",font,Brushes.White,new RectangleF(0,-1,32,32),format);
            }
            return b;
        }
    }
}
