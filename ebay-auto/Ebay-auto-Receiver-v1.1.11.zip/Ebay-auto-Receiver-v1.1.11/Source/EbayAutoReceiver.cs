// Ebay-auto 1.0.0: the receiver, on Seb's physical PC (where Chrome and the 404 extension are). It takes the orders the
// extension sends (HTTPS on this PC's LAN address, its own certificate and ports, the eBay key from the PIN pairing),
// keeps the queue (encrypted, ebay.dat), and hands the orders one at a time to the worker inside Seb's Remote Desktop
// session (the worker key and certificate fingerprint in its connection). Everything the Tempe desk receiver's eBay tab
// did is here (Retry, Start again in a new RO, Mark done by hand, Remove, Hide finished, the one retry by itself, pairing,
// the worker connection), plus the orders handed over for manual completion. Nothing else is served: no phone jobs, no
// website, no Repair Orders.
// 1.1.0: a compact window with tabs (Orders, Pairing, Updates, More), the same functions; one-click updates (it switches
// only while the worker isn't entering an order, and comes back receiving or paused as it was).
// 1.1.9 (20 Nov 2026): each order goes into COSTAR Sydney (Br1) or COSTAR Tempe (Br11), as chosen on the eBay page: the list
// shows each order's branch, and Start again, Mark done and Remove name it (an order never changes branch here).
// 1.1.11 (26 Nov 2026): Export diagnostics also uploads the saved ZIP to Tommy's private GitHub repository when GitHub
// upload is set up for this Windows login (More tab: GitHub upload). The ZIP served to the worker for its own export is not uploaded.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed class EbayAutoReceiverForm : EbayAutoForm {
        readonly ReceiverSettings settings;readonly string folder;readonly X509Certificate2 cert;
        readonly ReceiverApi api;readonly EbayQueue queue;LocalServer server,trust;
        readonly Label chipReceiving=Ui.Chip("STARTING",Ui.Muted),chipWorker=Ui.Chip("WORKER",Ui.Muted),chipEbay=Ui.Chip("EBAY",Ui.Muted);
        readonly Label headline=Ui.BigText("Starting ..."),workerLine=new Label {AutoSize=true,Font=Ui.Small,ForeColor=Ui.Muted};
        Label addressLine,detail,selection;
        readonly ListView list=new ListView {View=View.Details,FullRowSelect=true,HideSelection=false,Font=Ui.Base,MultiSelect=false,Dock=DockStyle.Fill};
        Button retry,startAgain,markDone,remove,hide,pair,resetPair,receiving,exportConnection,copyConnection,export,upload,openFolder;
        CheckBox autoStart;
        readonly System.Windows.Forms.Timer refresh=new System.Windows.Forms.Timer {Interval=1000},portRetry=new System.Windows.Forms.Timer {Interval=1000};
        bool serverUp,trustUp,syncingAuto,exporting,readySaid;int portWaits,ticks;string signature="",lastWaiting="";
        EbayAutoPairForm pairForm;List<EbayReceipt> last=new List<EbayReceipt>();
        // What the tray last said about (so a balloon is shown once per order and state).
        readonly HashSet<string> told=new HashSet<string>(StringComparer.Ordinal);bool workerOutSaid,certificateSaid;
        // 1.1.0: what the version before this one was doing (after an update), applied once listening.
        readonly EbayResumeState resumed;
        internal EbayAutoReceiverForm(ReceiverSettings config,string data,bool startVisible,EbayResumeState resume) : base(Product.ReceiverMode,startVisible||(resume!=null&&resume.shown)) {
            settings=config;folder=data;cert=Certificate(config.certificateThumbprint);resumed=resume;
            if(String.IsNullOrEmpty(settings.ebayToken)) { settings.ebayToken=Wire.Token();PrivateFiles.Save(Path.Combine(folder,"settings.dat"),settings);Journey.Note("ebay_key_created","","","a new eBay key (not shown)"); }
            string file=Path.Combine(folder,"ebay.dat");EbayState saved=null;
            // An unreadable queue must not keep the receiver from starting: kept aside, and said.
            try { saved=PrivateFiles.Load<EbayState>(file); }
            catch(Exception e) {
                string aside=file+".unreadable-"+DateTime.Now.ToString("yyyyMMdd-HHmmss",CultureInfo.InvariantCulture);
                try{File.Move(file,aside);}catch(Exception){}
                AppLog.Note("ebay_queue_unreadable",e.GetType().Name+"; kept as "+Path.GetFileName(aside));Journey.Note("queue_unreadable","","",e.GetType().Name+": kept aside as "+Path.GetFileName(aside)+"; an empty queue is used");
            }
            queue=new EbayQueue(saved,delegate(EbayState s){PrivateFiles.Save(file,s);});
            queue.Noted=delegate(string kind,string job,string attempt,string words){Journey.Note(kind,job,attempt,words);};
            var kept=queue.List();
            Journey.Note("queue_loaded","","",kept.Count+" order(s) kept: "+String.Join(", ",kept.GroupBy(EbayQueue.Category).Select(g=>g.Count()+" "+g.Key).ToArray()));
            api=new ReceiverApi(settings);api.UseEbay(queue);
            api.EbayIncoming=delegate(string number) { try{BeginInvoke(new Action(UpdateStatus));}catch(InvalidOperationException){} };
            api.EbayPaired=delegate(string unused) {
                AppLog.Note("ebay_paired","");Journey.Note("ebay_paired","","","the eBay PC's extension took the eBay key with the PIN");
                try{BeginInvoke(new Action(delegate{if(pairForm!=null&&!pairForm.IsDisposed)pairForm.Paired();UpdateStatus();}));}catch(InvalidOperationException){}
            };
            api.EbayRefused=delegate(string kind,string words){Journey.Note(kind,"","",words);};
            api.ReceiverBundle=delegate{return EbayAutoDiagnostics.ReceiverZip(queue,api,settings,null,null,false);};
            // While starting after an update, nothing new is taken until the state from before is applied.
            if(resume!=null) api.Receiving=resume.receiving;
            BuildWindow();
            server=new LocalServer(settings.address,settings.port,cert,api.Handle);server.HugeBody=api.HugeBody;
            trust=new LocalServer(settings.address,settings.trustPort,null,Trust);
            portRetry.Tick+=delegate{portRetry.Stop();StartListening();};
            refresh.Tick+=delegate{UpdateStatus();Tick();UpdateTick();};
            FormClosed+=delegate{portRetry.Dispose();refresh.Dispose();try{server.Dispose();}catch(Exception){}try{trust.Dispose();}catch(Exception){}cert.Dispose();};
            // Started at once, shown or not (the window may stay in the notification area).
            var created=Handle;BeginInvoke(new Action(StartListening));
        }
        static X509Certificate2 Certificate(string thumbprint) {
            using(var store=new X509Store(StoreName.My,StoreLocation.CurrentUser)) {
                store.Open(OpenFlags.ReadOnly);var found=store.Certificates.Find(X509FindType.FindByThumbprint,thumbprint??"",false);
                Order.Require(found.Count==1&&found[0].HasPrivateKey&&found[0].NotAfter>DateTime.Now,"The receiver's certificate is missing or has expired. Run Setup-Receiver.cmd again on this PC (under this Windows user).");
                return found[0];
            }
        }
        void BuildWindow() {
            Compact(600,480,440,360);
            // The header: the three chips, what is going on, and the worker in a line.
            var head=new FlowLayoutPanel {Dock=DockStyle.Top,FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Padding=new Padding(S(10),S(8),S(10),S(4)),BackColor=Ui.Surface};
            var chips=new FlowLayoutPanel {AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,FlowDirection=FlowDirection.LeftToRight,WrapContents=true,Margin=new Padding(0,0,0,S(4))};
            foreach(var c in new[]{chipReceiving,chipWorker,chipEbay}) { c.Margin=new Padding(0,0,S(6),S(4));c.Padding=new Padding(S(8),S(3),S(8),S(3));chips.Controls.Add(c); }
            headline.MaximumSize=new Size(S(560),0);workerLine.MaximumSize=new Size(S(560),0);
            head.Controls.Add(chips);head.Controls.Add(headline);head.Controls.Add(workerLine);
            Resize+=delegate { int w=Math.Max(S(200),ClientSize.Width-S(24));headline.MaximumSize=new Size(w,0);workerLine.MaximumSize=new Size(w,0);chips.MaximumSize=new Size(w,0); };
            // Orders: the actions over the list.
            retry=Secondary("Retry");startAgain=Secondary("Start again in a new RO");markDone=Secondary("Mark done by hand");remove=Danger("Remove");hide=Secondary("Hide finished");
            var ordersPage=new TabPage("Orders") {BackColor=Ui.Canvas};
            var grid=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Padding=new Padding(S(8))};
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));grid.RowStyles.Add(new RowStyle(SizeType.Percent,100));
            var actions=Buttons(retry,startAgain,markDone,remove,hide);actions.Dock=DockStyle.Fill;actions.MaximumSize=new Size(0,0);
            selection=Note("");selection.Dock=DockStyle.Fill;selection.MaximumSize=new Size(0,0);
            grid.Controls.Add(actions,0,0);grid.Controls.Add(selection,0,1);grid.Controls.Add(list,0,2);
            ordersPage.Controls.Add(grid);Tabs.TabPages.Add(ordersPage);
            list.Columns.Add("Job",S(76));list.Columns.Add("Branch",S(92));list.Columns.Add("eBay order",S(104));list.Columns.Add("Buyer",S(120));list.Columns.Add("Total",S(66),HorizontalAlignment.Right);list.Columns.Add("Status",S(140));list.Columns.Add("Message",S(380));
            // Pairing: this receiver's address, the 404 extension's PIN, receiving, and the worker's connection.
            var p=Page("Pairing");
            addressLine=Line("");detail=Note("");
            pair=Primary("Pair eBay PC");resetPair=Secondary("Reset eBay pairing");receiving=Secondary("Pause receiving");
            copyConnection=Secondary("Copy connection");exportConnection=Secondary("Export worker connection...");
            p.Controls.Add(Heading("This receiver"));p.Controls.Add(addressLine);p.Controls.Add(Buttons(receiving));p.Controls.Add(detail);
            p.Controls.Add(Heading("The 404 extension (Chrome on this PC)"));p.Controls.Add(Buttons(pair,resetPair));
            p.Controls.Add(Note("Pair eBay PC shows this receiver's address and a PIN to type into the 404 extension (Ebay-auto receiver, Connect). Reset eBay pairing makes a new key: the extension must pair again."));
            p.Controls.Add(Heading("The worker (inside Remote Desktop)"));p.Controls.Add(Buttons(copyConnection,exportConnection));
            p.Controls.Add(Note("Copy connection, then Paste connection in the worker inside Remote Desktop (it is taken off the clipboard after 2 minutes). Or Export worker connection and Import connection there. It holds the worker's key: don't send it anywhere else."));
            // Updates.
            BuildUpdatesPage();
            // More: Start with Windows, diagnostics, the data folder, and how it works.
            var m=Page("More");
            autoStart=TickBox("Start the receiver when I sign in to Windows (in the notification area)",false);
            export=Secondary("Export diagnostics");upload=UploadButton();openFolder=Secondary("Open data folder");
            m.Controls.Add(autoStart);m.Controls.Add(Buttons(export,upload,openFolder));m.Controls.Add(UploadState());
            m.Controls.Add(Note("Orders are entered one at a time by the worker inside Remote Desktop, each into a NEW Repair Order in COSTAR Sydney (Br1) or COSTAR Tempe (Br11), as chosen for that order on the eBay page (Seb's button; the page suggests Tempe when an item title says wheel or package), left open once it's in and verified for you to check and close (it says \"ez, next\"; the worker's Settings tab can have them closed instead). The same eBay order is never entered twice. Retry continues in the same Repair Order if nothing in it changed; Start again uses a new one (only if the first is NOT in COSTAR). An order whose item COSTAR doesn't know is handed over: left open in COSTAR for you to finish (it is never retried by itself); finish it there, close it, then Mark done by hand."));
            m.Controls.Add(Note("Minimise or X hides this window: the receiver keeps working in the notification area (double-click its icon to open it; right-click it for Exit)."));
            Controls.Add(Tabs);Controls.Add(head);
            retry.Click+=delegate{Attempt(delegate{var r=Selected();queue.Retry(r.order.orderNumber,"the receiver's Retry");api.WakeEbay();UpdateStatus();});};
            startAgain.Click+=delegate{Attempt(StartAgain);};
            markDone.Click+=delegate{Attempt(MarkDone);};
            remove.Click+=delegate{Attempt(Remove);};
            hide.Click+=delegate{Attempt(delegate{queue.HideFinished();UpdateStatus();});};
            pair.Click+=delegate{Attempt(Pair);};
            resetPair.Click+=delegate{Attempt(ResetPairing);};
            receiving.Click+=delegate{Attempt(TrayToggle);};
            exportConnection.Click+=delegate{Attempt(ExportConnection);};
            copyConnection.Click+=delegate{Attempt(CopyConnection);};
            export.Click+=delegate{Attempt(ExportDiagnostics);};
            openFolder.Click+=delegate{Attempt(delegate{Directory.CreateDirectory(AppData.Home);Process.Start("explorer.exe","\""+AppData.Home+"\"");});};
            autoStart.Checked=AutoStart.On(Product.ReceiverMode);
            autoStart.CheckedChanged+=delegate {
                if(syncingAuto) return;
                try { AutoStart.Set(Product.ReceiverMode,autoStart.Checked);Journey.Note("autostart","","",autoStart.Checked?"on":"off"); }
                catch(Exception e) { Tell(e.Message,"Start with Windows");syncingAuto=true;try{autoStart.Checked=AutoStart.On(Product.ReceiverMode);}finally{syncingAuto=false;} }
            };
            list.SelectedIndexChanged+=delegate{UpdateButtons();};
        }
        // ---- listening ----
        void StartListening() {
            try {
                if(!serverUp) serverUp=server.TryStart();
                if(!trustUp) trustUp=trust.TryStart();
                if(serverUp&&trustUp) {
                    if(portWaits>0) AppLog.Note("receiver_port_wait",portWaits+" s");
                    Journey.Note("listening","","","HTTPS on "+settings.address+":"+settings.port+", certificate on "+settings.trustPort+(portWaits>0?" (after waiting "+portWaits+" s for the ports)":""));
                    refresh.Start();UpdateStatus();
                    // Up: the version before (after an update) is told, every launcher now starts this one, Start with Windows too.
                    if(!readySaid) {
                        readySaid=true;
                        if(resumed!=null) Journey.Note("update_completed","","","now "+Product.Version+" (was "+resumed.from+"): receiving "+(api.Receiving?"on":"paused")+", window "+(resumed.shown?"open":"hidden")+", "+queue.List().Count+" order(s) kept");
                        EbayAutoProgram.Ready(Part);AutoStart.Refresh(Product.ReceiverMode);
                    }
                    return;
                }
                int port=serverUp?settings.trustPort:settings.port;
                if(++portWaits<=60) {
                    Ui.SetChip(chipReceiving,"STARTING",Ui.Warn);Ui.SetText(headline,"Waiting for port "+port+" (an older receiver may still be closing) ... "+portWaits+" s");
                    SetTray(TrayState.Attention,"waiting for port "+port);portRetry.Start();return;
                }
                throw new InvalidOperationException("port "+port+" is still used by another program after a minute. Close any other Ebay-auto receiver (Task Manager → Details → EbayAuto.exe), or run Setup-Receiver.cmd again with another port, then start this one again.");
            } catch(Exception e) {
                portRetry.Stop();api.Receiving=false;try{server.Dispose();}catch(Exception){}try{trust.Dispose();}catch(Exception){}
                Ui.SetChip(chipReceiving,"NOT RECEIVING",Ui.Danger);headline.Text="The receiver could not start: "+e.Message;
                Journey.Note("listen_failed","","",Sanitize.Text(e.Message,300));SetTray(TrayState.Problem,"could not start");
                // After an update the version before is waiting: it is told (and starts again) instead of a box here.
                if(EbayAutoProgram.AfterUpdate&&!readySaid) { EbayAutoUpdate.RecordStartFailure(Part,"the receiver couldn't listen: "+e.Message);Environment.Exit(1); }
                Tell(headline.Text);
            }
        }
        // The root that signed this receiver's certificate (as the Tempe desk hands out), else the setup's file.
        byte[] trustBytes;
        HttpOutput Trust(HttpInput r) {
            if(r.method=="GET"&&r.path=="/trust.cer") {
                if(trustBytes==null) {
                    try { using(var root=TrustRoot.Of(cert,null)) if(root!=null) trustBytes=root.RawData; } catch(Exception) { trustBytes=null; }
                    if(trustBytes==null) trustBytes=File.ReadAllBytes(Path.Combine(folder,"Ebay-auto-Root.cer"));
                }
                return new HttpOutput {type="application/x-x509-ca-cert",bytes=trustBytes};
            }
            return HttpOutput.Text("This port only supplies this PC's public trust certificate at /trust.cer. The Ebay-auto receiver uses HTTPS on port "+settings.port+".","text/plain; charset=utf-8");
        }
        // ---- the list ----
        EbayReceipt Selected() {
            Order.Require(list.SelectedItems.Count==1,"Select an eBay order in the list first.");
            string number=(string)list.SelectedItems[0].Tag;var r=queue.List().FirstOrDefault(o=>o.order.orderNumber==number);
            Order.Require(r!=null,"Select an eBay order first.");return r;
        }
        static string Money(int cents){return "$"+(cents/100m).ToString("0.00",CultureInfo.InvariantCulture);}
        static string StatusWords(EbayReceipt o) {
            switch(EbayQueue.Category(o)) {
                case "verified": return "In COSTAR ✓";
                case "check_by_hand": return "In COSTAR: check by hand";
                case "handed_over": return "NEEDS YOU: finish by hand";
                case "marked_done": return "Done by hand";
                case "stopped": return "Stopped";
                default: return o.status=="entering"?"Being entered":o.status=="queued"?"Waiting":o.status.Replace('_',' ');
            }
        }
        // 1.1.9: the orders waiting or being entered, per branch ("2 for Sydney (Br1), 1 for Tempe (Br11)").
        static string Waits(List<EbayReceipt> all) {
            return String.Join(", ",new[]{EbayBranch.Sydney,EbayBranch.Tempe}.Select(b=>new {b,n=all.Count(o=>o.order!=null&&o.order.Branch==b&&(o.status=="queued"||o.status=="entering"))}).Where(x=>x.n>0).Select(x=>x.n+" for "+EbayBranch.Name(x.b)).ToArray());
        }
        // 1.1.9: each branch as the worker's last poll said: ready, or why not.
        string Branches() {
            return String.Join("  ·  ",new[]{EbayBranch.Sydney,EbayBranch.Tempe}.Select(b=>{string why;return api.EbayBranchReady(b,out why)?EbayBranch.Name(b)+": ready":why;}).ToArray());
        }
        void StartAgain() {
            var r=Selected();bool handed=r.status=="handed_over";
            string text=r.order.Reference+"  |  "+r.order.BuyerName+"  ("+r.jobId+")\r\n\r\n"+
                (handed?"This order was handed over for manual completion: its Repair Order was left open in "+r.Costar+" ("+(r.remaining??"")+").\r\n\r\nStart again types the whole order into a NEW Repair Order. The one it was handed over in stays as it is: close it in COSTAR without saving first (or finish it there and use Mark done by hand instead). If its item still isn't a COSTAR code, it is handed over again.":
                 (r.typed?"The worker had already typed part of this order into a Repair Order in "+r.Costar+".":"The worker stopped before typing anything.")+"\r\n\r\nCheck "+r.Costar+" first. If this order is already there (part done), choose No: finish it there and use Mark done by hand.")+
                "\r\n\r\nEnter it again from the start in a NEW Repair Order in "+r.Costar+" (the same branch: it is never moved to the other one)?";
            if(Ask(text,"Start again",MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            queue.StartAgain(r.order.orderNumber);AppLog.Note("ebay_start_again",r.jobId);api.WakeEbay();UpdateStatus();
        }
        void MarkDone() {
            var r=Selected();
            string text=r.order.Reference+"  |  "+r.order.BuyerName+"  ("+r.jobId+")\r\n\r\nMark this eBay order as done by hand? Choose Yes only when it is finished in "+r.Costar+".\r\n\r\nThe worker will not type anything for it.";
            if(Ask(text,"Mark done by hand",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            queue.MarkDone(r.order.orderNumber,api.EbayConnected);AppLog.Note("ebay_mark_done",r.jobId);api.WakeEbay();UpdateStatus();
        }
        void Remove() {
            var r=Selected();
            string text=r.order.Reference+"  |  "+r.order.BuyerName+"  ("+r.jobId+")\r\n\r\nRemove this eBay order? It will not be entered. If it is half-entered in "+r.Costar+", finish or close that Repair Order by hand.\r\n\r\nThe eBay page can send it again later (if nothing was typed, in either branch).";
            if(Ask(text,"Remove eBay order",MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            queue.Remove(r.order.orderNumber,api.EbayConnected);AppLog.Note("ebay_remove",r.jobId);api.WakeEbay();UpdateStatus();
        }
        void Pair() {
            if(pairForm!=null&&!pairForm.IsDisposed){pairForm.Activate();return;}
            string pin=api.Pairing.Begin();AppLog.Note("ebay_pairing_open","");Journey.Note("pairing_open","","","a PIN for "+EbayPairing.Minutes+" minutes (not recorded)");
            ShowFromTray();
            pairForm=new EbayAutoPairForm(settings.address,settings.port,settings.trustPort,pin,K);
            pairForm.FormClosed+=delegate{api.Pairing.End();pairForm=null;};
            pairForm.Show(this);
        }
        void ResetPairing() {
            if(Ask("Make a new eBay key? The 404 extension stops sending until it is paired again (Pair eBay PC). Orders already here are kept.","Reset eBay pairing",MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            string previous=settings.ebayToken;settings.ebayToken=Wire.Token();
            try{PrivateFiles.Save(Path.Combine(folder,"settings.dat"),settings);}catch{settings.ebayToken=previous;throw;}
            AppLog.Note("ebay_key_reset","");Journey.Note("ebay_key_reset","","","a new eBay key (not shown): the extension must pair again");
            Tell("The old eBay key no longer works. Click Pair eBay PC and pair the 404 extension again.","Reset eBay pairing");
        }
        WorkerSettings Connection() { return new WorkerSettings {baseUrl=settings.Origin+"/",token=settings.workerToken,workerId=settings.workerId,certificateHash=Wire.Hash(cert.RawData)}; }
        // The worker's connection as a file (to copy into the Remote Desktop session) or as text (Copy connection, pasted
        // on the worker with Paste connection). It holds the worker key: never on GitHub, email or chat.
        void ExportConnection() {
            string file;
            using(var dialog=new SaveFileDialog {Title="Save the worker's connection (copy it into the Remote Desktop session)",FileName="worker-connection.json",Filter="Connection file|*.json",InitialDirectory=Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)}) {
                ShowFromTray();if(dialog.ShowDialog(this)!=DialogResult.OK) return;
                file=dialog.FileName;
            }
            File.WriteAllText(file,Wire.Json(Connection()),new UTF8Encoding(false));
            Journey.Note("connection_exported","","","worker connection saved as a file (the key is not recorded)");
            Process.Start("explorer.exe","/select,\""+file+"\"");
            Tell("Copy worker-connection.json into your Remote Desktop session, then on the worker (inside Remote Desktop) click Import connection and pick it (or put it beside Start-Worker.cmd before starting it). Delete it afterwards: it holds the worker's private key.","Worker connection");
        }
        void CopyConnection() {
            string json=Wire.Json(Connection());
            Clipboard.SetText(json);
            Journey.Note("connection_copied","","","worker connection copied as text (the key is not recorded)");
            // Taken off the clipboard again after 2 minutes if it is still there, so it isn't pasted anywhere else later.
            var clear=new System.Windows.Forms.Timer {Interval=120000};
            clear.Tick+=delegate { clear.Stop();clear.Dispose();try { if(Clipboard.ContainsText()&&Clipboard.GetText()==json) Clipboard.Clear(); } catch(Exception) { } };
            clear.Start();
            Tell("The worker's connection is on the clipboard for 2 minutes.\r\n\r\nIn your Remote Desktop session, open the worker (its tray icon) and click Paste connection. Remote Desktop passes the clipboard over (if it doesn't, use Export worker connection and copy the file).\r\n\r\nIt holds the worker's private key: don't paste it anywhere else.","Copy connection");
        }
        // ---- the tray's and the window's state ----
        protected override string ToggleWords { get { return api.Receiving?"Pause receiving":"Resume receiving"; } }
        protected override void TrayToggle() {
            api.Receiving=!api.Receiving;AppLog.Note("receiving",api.Receiving?"on":"off");
            Journey.Note(api.Receiving?"receiving_resumed":"receiving_paused","","",api.Receiving?"new orders are taken again":"new orders are refused until Resume (orders already here still go to the worker)");
            UpdateStatus();
        }
        protected override string OtherPartVersion { get { return api.EbayWorkerVersion??""; } }
        void UpdateStatus() {
            if(IsDisposed) return;
            var all=queue.List();last=all;
            string selected=list.SelectedItems.Count==1?(string)list.SelectedItems[0].Tag:null;
            var shown=all.Where(o=>!o.hidden).OrderByDescending(o=>o.receivedUtc,StringComparer.Ordinal).Take(80).ToList();
            string sig=String.Join("|",shown.Select(o=>o.order.orderNumber+":"+o.status+":"+o.version).ToArray());
            if(sig!=signature) {
                signature=sig;list.BeginUpdate();list.Items.Clear();
                foreach(var o in shown) {
                    string message=o.status=="handed_over"&&!String.IsNullOrEmpty(o.remaining)?o.remaining+"  ·  "+(o.message??""):(o.message??"");
                    var item=new ListViewItem(new[]{o.jobId??"",EbayBranch.Name(o.order.Branch),o.order.orderNumber,o.order.BuyerName,Money(o.order.totalCents),StatusWords(o),message}){Tag=o.order.orderNumber};
                    string c=EbayQueue.Category(o);
                    item.ForeColor=c=="stopped"?Ui.Danger:c=="handed_over"?Ui.Warn:c=="check_by_hand"?Ui.Warn:c=="verified"||c=="marked_done"?Ui.Success:o.status=="entering"?Ui.Info:Ui.Ink;
                    if(c=="handed_over") item.Font=Ui.Bold;
                    list.Items.Add(item);
                    if(o.order.orderNumber==selected) item.Selected=true;
                }
                list.EndUpdate();
            }
            int waiting=all.Count(o=>o.status=="queued"||o.status=="entering"),failed=all.Count(o=>o.status=="failed"),handed=all.Count(o=>o.status=="handed_over"),checks=all.Count(o=>EbayQueue.Category(o)=="check_by_hand"&&!o.hidden);
            bool connected,on,ready;string why;api.EbaySide(out connected,out on,out ready,out why);
            int since=api.SecondsSinceEbayWorker;
            bool listening=serverUp&&trustUp;
            Ui.SetChip(chipReceiving,!listening?"NOT RECEIVING":api.Receiving?"RECEIVING":"PAUSED",!listening?Ui.Danger:api.Receiving?Ui.Success:Ui.Warn);
            Ui.SetChip(chipWorker,connected?(on?"WORKER: ON":"WORKER: PAUSED"):"WORKER: OUT OF TOUCH",connected?(on?Ui.Success:Ui.Warn):Ui.Danger);
            Ui.SetChip(chipEbay,handed>0?"EBAY: "+handed+" NEED YOU":failed>0?"EBAY: "+failed+" STOPPED":waiting>0?"EBAY: "+waiting+" WAITING":"EBAY: NOTHING WAITING",handed>0?Ui.Gold:failed>0?Ui.Danger:waiting>0?Ui.Info:Ui.Success);
            string holding=api.EbayHolding;
            string head=!listening?headline.Text:holding!=null?holding:handed>0?handed+" order(s) need finishing by hand in COSTAR (see Orders)":failed>0?failed+" order(s) stopped: select one for Retry, Start again or Mark done":waiting>0?waiting+" order(s) waiting for COSTAR ("+Waits(all)+")":"Ready: orders sent with Sydney — Branch 1 or Tempe — Branch 11 go straight to the worker";
            if(listening) Ui.SetText(headline,head);
            Ui.SetText(workerLine,connected?"Worker (in Remote Desktop) in touch "+(since<=1?"now":since+" s ago")+(api.EbayWorkerVersion.Length>0?" · "+api.EbayWorkerVersion:"")+"  ·  "+(on?Branches():"eBay orders paused there"+(why.Length>0?" ("+why+")":"")):
                "Worker (in Remote Desktop) not in touch"+(since>=0?" for "+since+" s":" yet")+": orders wait here until it is. Start it inside Remote Desktop (Start-Worker.cmd, or its tray icon).");
            Ui.SetText(addressLine,"https://"+settings.address+":"+settings.port+"  (certificate download: http://"+settings.address+":"+settings.trustPort+"/trust.cer)"+(api.Pairing.Active?"  ·  PAIRING OPEN":"")+
                (CertificateDaysLeft<=30?"  ·  ITS CERTIFICATE EXPIRES "+cert.NotAfter.ToString("d MMM yyyy",CultureInfo.InvariantCulture).ToUpperInvariant()+": run Setup-Receiver.cmd again before then, then Copy connection to the worker again":""));
            Ui.SetText(detail,"Shown on the eBay page while an order waits: "+api.EbayWaiting);
            receiving.Text=api.Receiving?"Pause receiving":"Resume receiving";
            // The tray: the worst first.
            if(!listening) SetTray(TrayState.Problem,"not receiving");
            else if(handed>0) SetTray(TrayState.Attention,handed+" need finishing by hand");
            else if(failed>0) SetTray(TrayState.Problem,failed+" stopped");
            else if(!connected) SetTray(TrayState.Problem,"worker out of touch");
            else if(!api.Receiving) SetTray(TrayState.Paused,"receiving paused");
            else if(waiting>0) SetTray(all.Any(o=>o.status=="entering")?TrayState.Working:TrayState.Attention,waiting+" waiting"+(ready?"":": "+why));
            else SetTray(TrayState.Ready,checks>0?"ready ("+checks+" to check by hand)":"ready");
            // A balloon once for each order that needs Seb (handed over, stopped, CHECK BY HAND).
            foreach(var o in all.Where(o=>!o.hidden)) {
                string c=EbayQueue.Category(o),key=o.jobId+":"+c+":"+o.version;
                if((c=="handed_over"||c=="stopped"||c=="check_by_hand")&&told.Add(key)&&ticks>3)
                    Balloon(c=="handed_over"?"eBay order needs finishing by hand":c=="stopped"?"eBay order stopped":"eBay order in COSTAR: check by hand",o.order.Reference+" ("+EbayBranch.Name(o.order.Branch)+"): "+(c=="handed_over"&&!String.IsNullOrEmpty(o.remaining)?o.remaining:o.message),c=="stopped"?ToolTipIcon.Warning:ToolTipIcon.Info);
                else if(ticks<=3) told.Add(key);
            }
            UpdateButtons();
        }
        void UpdateButtons() {
            var choice=list.SelectedItems.Count==1?last.FirstOrDefault(o=>o.order.orderNumber==(string)list.SelectedItems[0].Tag):null;
            bool stranded=choice!=null&&choice.status=="entering"&&!api.EbayConnected;
            retry.Enabled=choice!=null&&choice.status=="failed";
            startAgain.Enabled=choice!=null&&(choice.status=="failed"||choice.status=="handed_over");
            markDone.Enabled=choice!=null&&(choice.status=="failed"||choice.status=="queued"||choice.status=="handed_over"||stranded);
            remove.Enabled=choice!=null&&(choice.status=="failed"||choice.status=="queued"||choice.status=="handed_over"||stranded);
            hide.Enabled=last.Any(o=>o.status=="ready_for_review"&&!o.hidden);
            Ui.SetText(selection,choice==null?"Select an order for Retry, Start again, Mark done by hand or Remove.":
                choice.jobId+"  ·  "+choice.Costar+"  ·  "+StatusWords(choice)+(choice.status=="handed_over"?"  ·  Retry isn't offered: a handed-over order is never continued by the worker (finish it in COSTAR, then Mark done by hand; or Start again in a new Repair Order).":""));
        }
        int CertificateDaysLeft { get { return (int)Math.Floor((cert.NotAfter-DateTime.Now).TotalDays); } }
        // Every second: the one retry by itself (every 10 s), the worker out of touch, the certificate running out (said once
        // a start), and the waiting reason when it changes.
        void Tick() {
            ticks++;
            // 1.1.0: older builds of this program (from updates) are tidied away once, ten minutes after starting.
            if(ticks==600) TidyRuntimes();
            if(!certificateSaid&&ticks>5&&CertificateDaysLeft<=30) {
                certificateSaid=true;string on=cert.NotAfter.ToString("d MMM yyyy",CultureInfo.InvariantCulture);
                Journey.Note("certificate_expiring","","","the receiver's certificate expires on "+on);
                Balloon("The receiver's certificate expires on "+on,"Run Setup-Receiver.cmd again on this PC before then (the pairing is kept); then Copy connection and Paste connection in the worker again.",ToolTipIcon.Warning);
            }
            var now=DateTime.UtcNow;
            if(ticks%10==0&&api.EbayConnected&&api.EbayAccepting) foreach(var o in queue.List()) {
                if(o.order==null||!EbayQueue.AutoRetryDue(o,now)) continue;
                try { if(queue.AutoRetry(o.order.orderNumber,now)) { AppLog.Note("auto_retry","ebay "+o.jobId);UpdateStatus(); } } catch(Exception e) { AppLog.Note("auto_retry_failed","ebay "+o.jobId+" "+e.Message); }
            }
            int since=api.SecondsSinceEbayWorker;
            if(since>300&&!workerOutSaid) {
                workerOutSaid=true;Journey.Note("worker_out_of_touch","","",since+" s without a poll");
                Balloon("The worker is out of touch","The worker inside Remote Desktop hasn't been in touch for 5 minutes: eBay orders wait here. Check it in your Remote Desktop session.",ToolTipIcon.Warning);
            } else if(since>=0&&since<60&&workerOutSaid) { workerOutSaid=false;Journey.Note("worker_back","","","in touch again"); }
            if(since>=0&&since<5&&ticks<=1) Journey.Note("worker_in_touch","","","version "+api.EbayWorkerVersion);
            string waiting=api.EbayWaiting;
            if(waiting!=lastWaiting) { lastWaiting=waiting;Journey.Note("waiting_reason","","",waiting); }
        }
        // ---- diagnostics ----
        // This receiver's logs, and the worker's when it answers within 20 s (asked over its own poll).
        protected override void ExportDiagnostics() {
            Order.Require(!exporting,"Diagnostics are being put together already.");
            exporting=true;export.Enabled=false;export.Text="Asking the worker ...";
            bool asked=api.EbayConnected;string token=asked?api.AskWorkerDiagnostics(25):null;
            var thread=new Thread(delegate() {
                byte[] worker=null;string note=null,version=null;
                if(asked) {
                    var clock=Stopwatch.StartNew();
                    while(clock.ElapsedMilliseconds<20000) { worker=api.WorkerDiagnostics(token,out note,out version);if(worker!=null||note!=null) break;Thread.Sleep(250); }
                    api.EndWorkerDiagnostics(token);
                    if(worker!=null&&worker.Length==0) worker=null;
                    if(worker==null&&note==null) note="the worker didn't send its logs within 20 s";
                } else note="the worker isn't in touch (it is not running in Remote Desktop, or can't reach this PC)";
                string path=null,error=null;
                try { path=EbayAutoDiagnostics.Save(Product.ReceiverMode,EbayAutoDiagnostics.ReceiverZip(queue,api,settings,worker,note,true)); }
                catch(Exception e) { error=e.Message; }
                try {
                    BeginInvoke(new Action(delegate {
                        exporting=false;export.Enabled=true;export.Text="Export diagnostics";
                        if(error!=null) { Tell("Diagnostics could not be saved: "+error);return; }
                        // 1.1.11: the ZIP just saved goes to GitHub as well (set up: started now on a pool thread).
                        string uploadWords=UploadSaved(path);
                        Process.Start("explorer.exe","/select,\""+path+"\"");
                        Tell("Saved "+Path.GetFileName(path)+(worker!=null?" (with the worker's logs).":".\r\n\r\nThe worker's logs are NOT in it: "+note+". Export diagnostics on the worker too (inside Remote Desktop).")+"\r\n\r\n"+uploadWords);
                    }));
                } catch(InvalidOperationException) { }
            });
            thread.IsBackground=true;thread.Start();
        }
        // ---- exit ----
        protected override bool ConfirmExit() {
            bool entering=last.Any(o=>o.status=="entering")&&api.EbayConnected;
            return Ask("Exit the Ebay-auto receiver?\r\n\r\nThe 404 extension can't send orders until it is started again (Start-Receiver.cmd, or sign in again if it starts with Windows). Orders already here are kept"+(entering?"; the worker finishes the order it is entering and reports it when the receiver is back":"")+".","Exit "+Product.Name,MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button2)==DialogResult.Yes;
        }
        protected override void Shutdown(string why) {
            var all=queue.List();
            Journey.Note("app_exit","","",why+": "+all.Count(o=>o.status=="queued")+" waiting, "+all.Count(o=>o.status=="entering")+" being entered, "+all.Count(o=>o.status=="handed_over")+" handed over, "+all.Count(o=>o.status=="failed")+" stopped (all kept)");
            refresh.Stop();api.Receiving=false;
        }
        // ---- the update's hooks ----
        // Switched only while the worker isn't entering an order (its reports would wait for the new version: nothing is
        // lost, but the entry isn't cut across), and with the pairing window closed.
        protected override string UpdateNotSafe() {
            if(pairForm!=null&&!pairForm.IsDisposed) return "the pairing window is open (close it first)";
            if(exporting) return "diagnostics are being put together";
            if(queue.List().Any(o=>o.status=="entering")&&api.EbayConnected) return "the worker is entering an eBay order";
            return null;
        }
        // While it waits: orders from the extension are still taken, none is handed to the worker (so the one being entered
        // is the last before the switch).
        protected override void UpdateHold() { var r=Updates.Release;api.EbayHolding="The Ebay-auto receiver is updating to "+(r==null?"a new version":r.version)+": orders are kept here and go to COSTAR once it is back (about a minute)."; }
        protected override void UpdateUnhold() { api.EbayHolding=null; }
        protected override EbayResumeState UpdateResume() { return new EbayResumeState {receiving=api.Receiving}; }
        protected override void UpdateStop() {
            var all=queue.List();
            Journey.Note("app_exit","","","update: "+all.Count(o=>o.status=="queued")+" waiting, "+all.Count(o=>o.status=="entering")+" being entered, "+all.Count(o=>o.status=="handed_over")+" handed over, "+all.Count(o=>o.status=="failed")+" stopped (all kept); receiving "+(api.Receiving?"on":"paused"));
            refresh.Stop();portRetry.Stop();api.Receiving=false;
            try{server.Dispose();}catch(Exception){}try{trust.Dispose();}catch(Exception){}
            if(pairForm!=null&&!pairForm.IsDisposed) pairForm.Close();
        }
    }
    // Shown while the 404 extension pairs: the address with its port, the PIN, and the certificate step for another PC.
    internal sealed class EbayAutoPairForm:Form {
        readonly Label status;
        readonly System.Windows.Forms.Timer clock=new System.Windows.Forms.Timer {Interval=1000};
        readonly DateTime until=DateTime.UtcNow.AddMinutes(EbayPairing.Minutes);bool done;
        internal EbayAutoPairForm(string address,int port,int trustPort,string pin,float k) {
            Func<int,int> S=delegate(int px){return (int)Math.Round(px*k);};
            status=Ui.Text("Waiting for the 404 extension ...",S(480));
            Text="Pair the 404 extension";ClientSize=new Size(S(540),S(440));StartPosition=FormStartPosition.CenterParent;FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;Font=Ui.Base;BackColor=Ui.Surface;ShowInTaskbar=false;
            var flow=new FlowLayoutPanel {Dock=DockStyle.Fill,FlowDirection=FlowDirection.TopDown,WrapContents=false,Padding=new Padding(S(16)),BackColor=Ui.Surface,AutoScroll=true};
            flow.Controls.Add(Ui.Title("In Chrome on this PC (once):"));
            flow.Controls.Add(Ui.Text("Click the 404 extension's icon. Under \"Ebay-auto receiver\" type this address and PIN, then click Connect (Chrome may first ask you to Allow the address in a tab: click Allow, then Connect again):",S(490)));
            var addressLine=new Label {Text=address+":"+port,AutoSize=true,Font=new Font("Segoe UI",18F,FontStyle.Bold),ForeColor=Ui.Ink,Margin=new Padding(0,S(8),0,0)};
            var pinLine=new Label {Text=pin.Substring(0,3)+" "+pin.Substring(3),AutoSize=true,Font=new Font("Consolas",30F,FontStyle.Bold),ForeColor=Ui.Primary,Margin=new Padding(0,S(4),0,S(8))};
            flow.Controls.Add(addressLine);flow.Controls.Add(pinLine);
            flow.Controls.Add(Ui.Hint("The PIN works once, for "+EbayPairing.Minutes+" minutes (5 tries). Keep it to yourself: it lets a PC send eBay orders into COSTAR.",S(490)));
            flow.Controls.Add(Ui.Hint("On this PC the receiver's certificate was already trusted by Setup-Receiver. Pairing Chrome on ANOTHER PC: first open http://"+address+":"+trustPort+"/trust.cer there, open the downloaded file: Install Certificate → Current User → Place all certificates in the following store → Trusted Root Certification Authorities → Finish → Yes, then restart Chrome.",S(490)));
            flow.Controls.Add(status);
            var close=Ui.SecondaryButton("Close",S(110));close.Click+=delegate{Close();};flow.Controls.Add(close);
            Controls.Add(flow);
            clock.Tick+=delegate {
                if(done)return;
                int left=(int)Math.Max(0,(until-DateTime.UtcNow).TotalSeconds);
                if(left==0){Ui.SetText(status,"The PIN has expired. Close this and click Pair eBay PC again.");status.ForeColor=Ui.Danger;clock.Stop();return;}
                Ui.SetText(status,"Waiting for the 404 extension ...  ("+(left/60)+":"+(left%60).ToString("00")+" left)");
            };
            Shown+=delegate{clock.Start();};
            FormClosed+=delegate{clock.Dispose();};
        }
        internal void Paired() { done=true;clock.Stop();Ui.SetText(status,"Paired. The 404 extension can send orders now. You can close this.");status.ForeColor=Ui.Success;status.Font=Ui.Bold; }
    }
}
