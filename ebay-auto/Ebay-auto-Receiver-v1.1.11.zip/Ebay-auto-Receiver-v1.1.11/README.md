# Ebay-auto 1.1.11 - 27 November 2026

Receiver and worker 1.1.11. The 404 extension stays at 1.6.1. This update sends each saved diagnostics ZIP to Tommy's private GitHub repository as well, so Claude can read it there and nobody has to post it by hand.

## Patch notes

- **Diagnostics go to GitHub too.** **Export diagnostics** saves the ZIP exactly as before: same folder, same Explorer window, same message. If GitHub upload is set up, the same ZIP is also uploaded to the private repository `tommyvenzin/tempe-diagnostics`, at `uploads/<date>/<time>-ebay-receiver-1.1.11-<PC>.zip` (or `...-ebay-worker-...`). The upload runs in the background. A slow or failed upload never holds up, breaks or undoes the save.
- **What it says.** The save message ends with *Uploading the diagnostics to GitHub ...*. When the upload finishes, a balloon by the clock and the line under the More tab's buttons say *Uploaded to GitHub (tommyvenzin/tempe-diagnostics): uploads/... Claude can read it there now.* If it fails, they say *Not uploaded to GitHub: <why>. The ZIP is saved at <path>: send it by hand.* The worker also writes this in its Activity log. Nothing pops up over COSTAR when the upload finishes. If upload isn't set up, the save message says *Not uploaded to GitHub: not set up for this Windows login* and how to set it up.
- **Set up once for each Windows login.** The **GitHub upload** button sits beside Export diagnostics on the More tab, and **GitHub upload...** is in the tray icon's menu. Either one opens the GitHub upload window. Its **Open GitHub** button opens GitHub's new-token page with everything it can already filled in, so you only pick the repository, generate the token, paste it and click **Save**. The token is checked with GitHub before it is kept. It is stored with Windows DPAPI in `%LOCALAPPDATA%\TempeDiagnosticsUpload`, so only that Windows login on that PC can read it. The Tempe helper 2.9.20 uses the same file under the same login. **Remove for this Windows login** deletes it. While a token is being checked, the window can't be closed (it takes a minute or two at most), so its answer is always seen. The window is laid out from its text, so it should fit at any Windows scaling. Opening it doesn't need COSTAR and doesn't interrupt an order being entered.
- **Only diagnostics, only to the private repository.** Before each upload, GitHub has to confirm that the repository is `tommyvenzin/tempe-diagnostics` and that it is private. Otherwise nothing is sent. Only Export diagnostics ZIPs are sent, up to 40 MB each; the receiver's copy for the worker's own export is never uploaded. Settings, entry reports (which hold customer details), keys and the pairing are never sent.
- **Slow connections.** An upload gets 60 seconds plus 1 second for every 32 KB of the ZIP, and at most 30 minutes. A slower one stops and says it took too long; the ZIP stays saved.
- **The token stays secret.** It is never written to a log, the diagnostics, a message or the screen. The diagnostics masker now also removes any GitHub token from free text. Each export adds one `diag_upload` line to the day log: a fixed code such as `uploaded`, `not_set_up`, `refused`, `network` or `too_slow`, plus the repository path when the upload worked. GitHub's own words are never logged.

Order entry is unchanged, including Sydney/Tempe routing, Contact info lookup, prices, stock prompts, open Repair Orders, Next #, the clipboard reference and duplicate protection. Protocol 2 and order schema v3 are unchanged.

## Install this update

1. Finish any active entry and pause order processing while updating.
2. Click **Update now** on the receiver on Seb's PC and on the worker inside Remote Desktop. Check that both say **1.1.11** before resuming. Nothing changes in Chrome: keep the 1.6.1 extension, its folder and its pairing. (A part still on 1.1.9 also needs the 1.6.1 extension: see the 1.1.10 notes below.)
3. Resume processing. Until GitHub upload is set up, Export diagnostics works exactly as in 1.1.10.

## Set up GitHub upload (Tommy)

Before this release is published, Claude creates the private repository `tommyvenzin/tempe-diagnostics` on GitHub. There is nothing to do for it here.

GitHub upload is set up once for each Windows login on each PC: the receiver's login on Seb's PC, and the worker's login inside Remote Desktop. One token is enough. The same token can be pasted on every PC and login.

1. **Open the window.** On the receiver (Seb's PC), open the More tab and click **GitHub upload**, or click **GitHub upload...** in the tray icon's menu.
2. **Open GitHub.** Click **Open GitHub** while signed in to GitHub as `tommyvenzin`. GitHub's new fine-grained token page opens already filled in: the name `Tempe diagnostics <PC>`, the resource owner `tommyvenzin`, no expiry, and **Contents: Read and write**. GitHub adds Metadata: Read-only by itself. If anything isn't filled in, set it as listed here; the window lists it too.
3. **Pick the repository.** This is the only choice to make: under **Repository access**, choose **Only select repositories**, then `tempe-diagnostics`.
4. **Generate.** Click **Generate token** and copy it. It starts with `github_pat_`. Classic `ghp_` tokens are refused.
5. **Paste and Save.** Paste it into the window and click **Save**. The window checks it with GitHub before keeping it: GitHub must confirm the private repository, and a small `setup/...txt` file is written there. A refused token is not kept, and the window says why. The More tab then says *GitHub upload: set up for this Windows login*.
6. **Inside Remote Desktop (worker).** The worker shares the Tempe helper's GitHub upload under the same Windows login. If the helper 2.9.20 is already set up there, the worker's More tab already says *set up for this Windows login*. Otherwise do steps 1 and 5 on the worker's More tab with the same token, or make another from step 2. A token file can't be copied between PCs or logins (DPAPI).
7. **Check it.** Click Export diagnostics on each part. The message should end with *Uploading the diagnostics to GitHub ...*. A balloon should then say *Uploaded to GitHub* with the path, and the ZIP should appear under `uploads/` in the repository.
8. **To stop.** Click **GitHub upload**, then **Remove for this Windows login**. Other logins and PCs keep theirs. If a PC is lost or the token leaks, delete the token on GitHub: that stops it everywhere.

## Validation

See `VALIDATION.md` and `package-checks-1.1.11.txt` for exact results. The upload was tested only against a fake GitHub server on this PC, with made-up tokens. Nothing has been tried against the real GitHub, on Seb's PC or inside Remote Desktop. The GitHub upload window, the new buttons and the balloons have not been looked at on screen, and the token page that Open GitHub opens has not been seen. Watch the first setup and the first export on each part.

## Bundle contents

- Receiver ZIP for Seb's PC and worker ZIP for Remote Desktop.
- `404-but-its-found-1.6.1.zip`: the same file published with 1.1.10, unchanged.
- Source backup including tests and validation reports.
- GitHub upload ZIP containing only the `ebay-auto` release files.

Full release history is in the packages' `CHANGES.md`. Earlier published ZIPs are kept unchanged.

## Local development

`Tests/run-local.ps1` compiles and tests without typing into COSTAR. It needs PowerShell 7.4 or later, because Windows PowerShell 5.1 has no `Start-Process -Environment`. It also runs the Chrome end-to-end test wherever Chrome is installed. `node Tests/package-release.cjs` builds and verifies both packages, including isolated installer builds and replay through the published 1.1.10 updater. It first refuses to package unless README.md and VALIDATION.md start with this version's heading, `build/self-test-results.txt` is this version's report, and `build/EbayAuto.exe` is this version. Templates come from the existing 1.1.10 package folders. The unchanged extension ZIP is only read, never rebuilt. Packaging itself does not publish or install the live apps.

## Original 1.1.10 release notes

Receiver and worker 1.1.10, with 404 extension 1.6.1. This update keeps customer lookup on Contact info and fixes the stop when COSTAR puts that number in Home Ph or Bus Ph.

## Patch notes

- **Contact info is the customer phone.** The helper no longer tries Ship to's phone to find an account. If no account is found, it fills known billing details and uses the existing guarded new-account step with the same Contact info phone. Billing name comes from Order/Buyer; the address comes from Ship to.
- **Home and business numbers count.** The Contact number may match billing X's Mobile Ph, Home Ph or Bus Ph. Mobile being blank does not stop the order. COSTAR's phone placement is kept; unrelated phone numbers still fail verification. Diagnostics record which field matched without its phone value.
- **Delivery stays separate.** Y keeps the Ship to name, phone and delivery address.
- **Missing details do not throw away the order.** Known customer names and address fields are entered and verified. Incomplete account creation is skipped, and the open Repair Order is marked CHECK BY HAND with what is missing. The extension shows missing details before sending. Missing data is not invented or reported as verified.
- **Old partial orders stay protected.** A partial order that previously used a different Ship to phone must be finished manually. It is never silently moved to a different customer account. Completed orders are untouched.

A readable Contact info phone is still required. Supplied-invalid values, item/price/total checks, branch confirmation, duplicate protection and uncertain-popup stops remain enforced.

## Install this update

1. Finish any active entry and pause order processing while updating.
2. Click **Update now** on the receiver on Seb's PC and the worker inside Remote Desktop. Confirm **1.1.10 on both** before resuming. Protocol 2 remains compatible with 1.1.9, so updating only the receiver does not change the old worker's phone behaviour.
3. Extract `404-but-its-found-1.6.1.zip` into the existing unpacked extension folder, replacing its files. In `chrome://extensions`, click Reload on **404 But It's Found**. Keep the same folder so its identity and pairing are retained.
4. Refresh the eBay order page, then resume processing. Keep the required Sydney (Br1) and/or Tempe (Br11) COSTAR windows open inside Remote Desktop.

Settings, pairing, queued orders and completion history keep their existing storage. No re-pairing or fresh setup is required for an existing installation. The updater does not change the separately installed Tempe helper.

## Existing behaviour retained

- Sydney and Tempe buttons, with wheel/wheels/package/packages suggesting Tempe and confirmation for the other choice. Mixed orders stay together; package SKUs are not trimmed.
- One order at a time, the first-opened valid COSTAR instance for each branch, and each new order starting its own Repair Order with Add New.
- Uppercase unit/slash address formatting and the wheel-only numeric SKU suffix fix.
- Rebill EBAY, Card#, Terms 7INV, Ship Via DFE, staff SA/SA, original quantities/prices, product/freight/message lines and final verification.
- Stock above 2 continues; 0-2 requires typed `ok` or `check`; negative stock requires `yes`. `check` adds `low stock - currently checking`. Unknown-SKU hand-over is unchanged.
- Successfully verified Repair Orders stay open for manual checking, with `ez, next`. A blank Repair Order number gets Next #, then `<number> DFE` is copied to the clipboard. Orders needing checks remain open with CHECK BY HAND.
- Tray icons, one-click GitHub updates, diagnostics and duplicate/retry protection.

## Validation

See `VALIDATION.md` and `package-checks-1.1.10.txt` for exact test and packaging results. These new behaviours have not been exercised in live COSTAR. Watch the first Contact-only new customer, an existing account with Home/Bus populated and Mobile blank, and an incomplete-details order.

The browser integration suite could not start isolated Chrome in this environment. Its launcher now records the crash output rather than silently timing out. This is recorded as an uncompleted check, not a pass.

## Bundle contents

- Receiver ZIP for Seb's PC and worker ZIP for Remote Desktop.
- `404-but-its-found-1.6.1.zip` for Chrome.
- Source backup including tests and validation reports.
- GitHub upload ZIP containing only the `ebay-auto` release files.

Full release history is in the packages' `CHANGES.md`. Earlier published ZIPs are kept unchanged.

## Local development

`Tests/run-local.ps1` compiles and tests without typing into COSTAR. `node Tests/package-release.cjs` builds and verifies both packages, including isolated installer builds and replay through the published 1.1.9 updater. Templates come from the existing 1.1.9 package folders. Packaging itself does not publish or install the live apps.
