// The eBay side of the COSTAR helper (2.5.0), and since Ebay-auto 1.0.0 the Ebay-auto worker inside Seb's Remote
// Desktop session: asks the receiver (Seb's PC) for eBay orders, finds COSTAR Sydney (Branch 1) in this Windows session by
// itself, waits for a quiet moment, enters each order in a new Repair Order and reports back. Stopped attempts are
// remembered (encrypted) so a Retry continues in the same Repair Order only while nothing in it changed; an order entered
// once is never entered again. Ebay-auto: an item COSTAR doesn't know is left for Seb (Runner.EbayAuto.cs) and the order is
// handed over: released at once for the next order, never retried or continued by itself, and remembered here so it is
// never entered again without Start again.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    public sealed class EbayAttempt {
        public string orderNumber,lease,stopPrint,message,atUtc;
        public long window,processStart;public int processId,sessionId,branch;
        // typed: fields were written for this order; running: an entry was going (result unknown);
        // touched: this attempt's run wrote into its Repair Order (saved just before its first write).
        public bool typed,running,touched;
        // Ebay-auto 1.0.0: the receiver's ids for it; unknown: an item of it was left unresolved (its words in unresolved).
        public string jobId,attemptId,unresolved;public bool unknown;
    }
    // Ebay-auto 1.0.0: a Repair Order handed over to Seb (looked at now and then: whether it is still open in COSTAR).
    public sealed class EbayHeldRo { public string jobId,atUtc,closedUtc;public long window,processStart;public int processId; }
    public sealed class EbayJournal {
        public List<EbayAttempt> attempts=new List<EbayAttempt>();
        // "order number|UTC time" of every eBay order this helper finished (newest last).
        public List<string> entered=new List<string>();
        // The last report the desk has not acknowledged yet.
        public EbayReport report;public int sequence;
        // Ebay-auto 1.0.0: "order number|UTC time|jobId" of every order handed over to Seb (newest last), and their
        // Repair Orders.
        public List<string> handedOver=new List<string>();
        public List<EbayHeldRo> held=new List<EbayHeldRo>();
        // Ebay-auto 1.1.1: the Repair Orders of orders entered and verified, left open on purpose for Seb to check and close
        // (looked at now and then, so the diagnostics say when each was closed by hand). Never "handed over".
        public List<EbayHeldRo> leftOpen=new List<EbayHeldRo>();
        // Ebay-auto 1.1.6: the Repair Order numbers copied for Seb with DFE, newest last (RoNumber.Keep): never copied again;
        // the last one is taken off the clipboard when an order's own number can't be copied. Here only: the diagnostics
        // have their shape, never the numbers.
        public List<EbayRoNumber> roNumbers=new List<EbayRoNumber>();
    }
    // Ebay-auto 1.1.1 (Tommy, 17 Nov: "Seb prefers every successfully entered eBay Repair Order to stay OPEN in COSTAR so
    // he can check it and close it manually"): what the worker reports for an order that is in, and the one-time switch of
    // "Close each Repair Order once it's in" to off (an earlier installation's tick included; ticked again later, kept).
    internal static class EbayFinish {
        // The words for an order entered, verified and left open on purpose (nothing to do but check and close it).
        internal const string EzNext="ez, next";
        // Pure: the report's message. leftOpen: verified and left open on purpose with nothing to check by hand.
        internal static string Words(string label,bool closed,bool leftOpen,IList<string> notices,IList<string> checks) {
            string noted=notices==null||notices.Count==0?"":" "+String.Join(" ",notices.ToArray());
            if(leftOpen&&(checks==null||checks.Count==0)) return EzNext+noted;
            string byHand=checks==null||checks.Count==0?"":" CHECK BY HAND: "+String.Join(" ",checks.ToArray());
            return "In COSTAR "+label+(closed?", entered and closed (it's in Work-in-Progress).":", ready for review (Repair Order left open).")+noted+byHand;
        }
        // Pure: turns "close each Repair Order" off once per installation (true when it changed the settings: save them).
        internal static bool LeaveOpenOnce(AppSettings s,string version) {
            if(s==null||!String.IsNullOrEmpty(s.ebayLeaveOpenFrom)) return false;
            s.ebayClose=false;s.ebayLeaveOpenFrom=version;
            return true;
        }
    }
    // What to do with an order the desk hands over, given what this helper remembers about it.
    internal static class EbayAttempts {
        internal const string Fresh="fresh",Resume="resume",Reuse="reuse",Refuse="refuse";
        // alive: the attempt's Repair Order window still exists in the same COSTAR process.
        internal static string Decide(EbayAttempt attempt,bool fresh,bool alive,out string why) {
            why="";
            if(attempt==null||fresh) return Fresh;
            // Ebay-auto: an attempt that left an item for Seb is never continued (he may be finishing it by hand).
            if(attempt.unknown) { why="eBay order "+attempt.orderNumber+" had an item COSTAR doesn't know and was left for manual completion. It isn't continued: finish it in COSTAR Sydney and click Mark done by hand on the receiver (or Start again there for a new Repair Order).";return Refuse; }
            if(!attempt.typed) return alive?Reuse:Fresh;
            if(!alive) { why="eBay order "+attempt.orderNumber+" was partly entered in a Repair Order that is now closed (or COSTAR restarted). Check COSTAR Sydney: if the order is there, finish it and click Mark done by hand on the receiver; if it is not, click Start again there.";return Refuse; }
            if(attempt.stopPrint==null) { why="The earlier attempt of eBay order "+attempt.orderNumber+" couldn't be recorded when it stopped, so its Repair Order isn't continued. Finish it in COSTAR Sydney and click Mark done by hand on the receiver.";return Refuse; }
            return Resume;
        }
        // Whether an order handed over may be started at all, before COSTAR is touched; null if it may.
        // enteredAt: when this helper finished it before (null: never). deskTyped: the desk says it was
        // partly typed. Only Start again (after checking COSTAR) passes the first rule. handedOverAt (Ebay-auto): when
        // this worker handed it over to Seb (null: never).
        internal static string Refusal(string number,bool fresh,bool startAgain,bool deskTyped,EbayAttempt earlier,string enteredAt,string handedOverAt=null) {
            if(startAgain) return null;
            if(enteredAt!=null) return "Not entered twice: this helper already entered eBay order "+number+" ("+enteredAt+"). Check COSTAR Sydney, then click Mark done by hand on the receiver (or Start again there if it is really not in COSTAR).";
            if(handedOverAt!=null) return "Not entered again: eBay order "+number+" was handed over for manual completion ("+handedOverAt+"); its Repair Order was left open in COSTAR Sydney. Finish it there and click Mark done by hand on the receiver (or Start again there for a new Repair Order).";
            if(fresh&&earlier!=null&&earlier.typed) return "eBay order "+number+" was partly typed into a Repair Order before, so it isn't entered again as new. Check COSTAR Sydney, then on the receiver: Retry (continues that Repair Order if nothing in it changed), Start again (a new Repair Order) or Mark done by hand.";
            if(!fresh&&earlier==null&&deskTyped) return "The receiver says eBay order "+number+" was partly typed before, but this worker has no record of that Repair Order. Check COSTAR Sydney, then use Start again (a new Repair Order) or Mark done by hand on the receiver.";
            return null;
        }
        internal static string Entered(EbayJournal j,string number) {
            if(j==null||j.entered==null) return null;
            var hit=j.entered.LastOrDefault(e=>e.StartsWith(number+"|",StringComparison.Ordinal));
            return hit==null?null:hit.Substring(number.Length+1);
        }
        // Ebay-auto: when this worker handed the order over (its UTC time), or null.
        internal static string HandedOver(EbayJournal j,string number) {
            if(j==null||j.handedOver==null) return null;
            var hit=j.handedOver.LastOrDefault(e=>e.StartsWith(number+"|",StringComparison.Ordinal));
            if(hit==null) return null;
            var parts=hit.Split('|');return parts.Length>1?parts[1]:"";
        }
    }
    internal sealed class EbayEngine : IDisposable {
        readonly EntryCoordinator coordinator;readonly WorkerSettings settings;readonly string journalPath;readonly object gate=new object();readonly Action<string> log;
        EbayJournal state;volatile Runner runner;volatile bool disposed,busy;int started;
        internal volatile bool Enabled;
        // How long nobody may have used the PC before an eBay order starts in COSTAR. 2.6.7 (Tommy, 28 Oct 15:34:
        // "change all idle time to 3 seconds"): 3 s (it was 10 s).
        internal const int QuietSeconds=3;
        internal volatile string Connection="Receiver: connecting ...",Detail="eBay orders are off. Click Start eBay orders.",Current="",LastLine="",LastReport="";
        volatile int lastContactTick;internal volatile int RoundTripMs=-1;
        internal int SecondsSinceContact { get { int t=lastContactTick;return t==0?-1:unchecked(Environment.TickCount-t)/1000; } }
        volatile HttpWebRequest pending;volatile bool interrupted;readonly AutoResetEvent wake=new AutoResetEvent(false);
        readonly Stopwatch progressClock=Stopwatch.StartNew();
        // COSTAR Sydney, looked for again at most every 3 s (a window scan). 1.1.0: chosen by SydneyChoice (the
        // earliest-started Sydney, kept while it is valid; see EbayAutoCostar.cs), never by window order or PID.
        CostarInstance target;DateTime targetAt=DateTime.MinValue;string targetDetail="",scanSignature="";
        readonly SydneyChoice choice;
        // The chosen Sydney in words for the window (PID, start time, how many Sydney are open), "" when none.
        internal volatile string TargetWords="";
        // 1.1.0: the receiver's own version and protocol (from its replies), and why orders can't be taken from it (a
        // protocol this worker doesn't know), else null.
        internal volatile string ReceiverVersion="",ProtocolProblem;
        // 1.1.0: set while this worker updates itself (the new version's words): it takes no new order (the receiver keeps
        // them, saying why) and waits for the one being entered to finish. Polls since it was set, for the safe point.
        volatile string updating;volatile int pollsSinceUpdating;
        internal string Updating { get { return updating; } set { pollsSinceUpdating=0;updating=value; } }
        // The receiver has had a poll sent with the hold since it was set (a poll already on its way before doesn't count).
        internal bool UpdateHeld { get { return updating!=null&&pollsSinceUpdating>0; } }
        internal bool Busy {get{return busy;}}
        // Why the Online orders tab is typing or about to (set by the window), null when it isn't;
        // eBay orders wait meanwhile.
        internal Func<string> OnlineWaiting;
        internal int Branch {get{int b=AppSettings.Current.ebayBranch;return b>0?b:1;}}
        internal CostarInstance Target {get{return target;}}
        // Ebay-auto 1.0.0: told (on the engine's own thread) when an order is handed over or stops, for the window's tray.
        internal Action<string,string> Attention;
        // The last order handed over or stopped, for the window (its jobId and the words said).
        internal volatile string LastAttention="";
        internal EbayEngine(WorkerSettings config,string folder,Action<string> notify,EntryCoordinator entries) {
            coordinator=entries;NetworkRules.Worker(config);settings=config;log=notify;journalPath=Path.Combine(folder,"ebay-journal.dat");choice=new SydneyChoice(Branch);
            try { state=PrivateFiles.Load<EbayJournal>(journalPath); }
            catch(Exception e) {
                try{File.Copy(journalPath,journalPath+".unreadable-"+DateTime.Now.ToString("yyyyMMdd-HHmmss"),true);}catch(Exception){}
                AppLog.Note("ebay_journal_unreadable",e.GetType().Name);Journey.Note("journal_unreadable","","",e.GetType().Name+": a fresh journal is started (the old one is kept beside it)");state=null;
            }
            // A new journal counts its reports on from the time, so they always come after any earlier
            // journal's (the desk compares them; see EbayHello.sequence).
            if(state==null) state=new EbayJournal {sequence=(int)Math.Min(Int32.MaxValue/2,Math.Max(0,(DateTime.UtcNow-new DateTime(2026,1,1,0,0,0,DateTimeKind.Utc)).TotalSeconds))};
            if(state.attempts==null) state.attempts=new List<EbayAttempt>();
            if(state.entered==null) state.entered=new List<string>();
            if(state.handedOver==null) state.handedOver=new List<string>();
            if(state.held==null) state.held=new List<EbayHeldRo>();
            if(state.leftOpen==null) state.leftOpen=new List<EbayHeldRo>();
            if(state.roNumbers==null) state.roNumbers=new List<EbayRoNumber>();
            Journey.Note("journal_loaded","","",state.attempts.Count+" attempt(s) kept, "+state.entered.Count+" entered, "+state.handedOver.Count+" handed over, "+state.held.Count(h=>h.closedUtc==null)+" handed-over Repair Order(s) last seen open, "+state.leftOpen.Count(h=>h.closedUtc==null)+" verified Repair Order(s) left open for Seb last seen open"+(state.report!=null?", one report not yet acknowledged by the receiver":""));
            // An entry that was going when the helper closed: its result is unknown.
            var lost=state.attempts.FirstOrDefault(a=>a.running);
            if(lost!=null) {
                // Typed by that run (touched): its stop print no longer describes the Repair Order. Not
                // touched: what was recorded before it (an earlier stop, or nothing typed) still holds.
                foreach(var a in state.attempts.Where(a=>a.running)) { a.running=false;if(a.touched){a.typed=true;a.stopPrint=null;}a.message="The worker closed while entering this order."; }
                runJobId=lost.jobId;runAttemptId=lost.attemptId;
                if(lost.unknown) {
                    // Ebay-auto: an item had already been left for Seb: handed over (never continued by itself).
                    string message="NEEDS MANUAL COMPLETION in COSTAR Sydney: the worker closed while entering this eBay order, after "+(lost.unresolved??"an item COSTAR doesn't know")+". The Repair Order is left as it is: finish it by hand there (or close it without saving and use Start again on the receiver), then click Mark done by hand on the receiver.";
                    lock(gate) {
                        state.attempts.RemoveAll(a=>a.orderNumber==lost.orderNumber);
                        state.handedOver.Add(lost.orderNumber+"|"+DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture)+"|"+(lost.jobId??""));
                        while(state.handedOver.Count>500) state.handedOver.RemoveAt(0);
                        if(lost.window!=0) Hold(lost.jobId,lost.window,lost.processId,lost.processStart);
                        SetReport(lost.orderNumber,lost.lease,"handed_over",message,"",true,"the worker closed part way: check the whole order");
                        Save();
                    }
                    Journey.Note("restart_recovery",lost.jobId,lost.attemptId,"the worker closed while entering it, after an unresolved item: reported as handed over");
                    Detail=message;
                } else {
                    Report(lost.orderNumber,lost.lease,"failed","The worker closed while entering this eBay order. Check COSTAR Sydney: if it is there, finish it and click Mark done by hand on the receiver; if not, click Start again there.","",lost.typed);
                    Journey.Note("restart_recovery",lost.jobId,lost.attemptId,"the worker closed while entering it: reported as stopped ("+(lost.typed?"typed before":"nothing typed")+")");
                }
                runJobId=null;runAttemptId=null;
            }
            Enabled=AppSettings.Current.ebayOn;
        }
        void Save() { lock(gate) PrivateFiles.Save(journalPath,state); }
        EbayAttempt Attempt(string number) { lock(gate) return state.attempts.FirstOrDefault(a=>a.orderNumber==number); }
        void Remember(EbayAttempt attempt) {
            lock(gate) {
                state.attempts.RemoveAll(a=>a.orderNumber==attempt.orderNumber);state.attempts.Add(attempt);
                while(state.attempts.Count>50) state.attempts.RemoveAt(0);
                Save();
            }
        }
        void Forget(string number) { lock(gate) { if(state.attempts.RemoveAll(a=>a.orderNumber==number)>0) Save(); } }
        // 2.6.10: the Repair Order windows of eBay orders this helper started and hasn't finished (a stopped one's is
        // kept for its Retry): a new phone job never closes them (WorkerEngine.HeldForReview), should COSTAR Sydney
        // be the selected COSTAR. Ebay-auto: and the ones handed over to Seb that are still open.
        internal List<long> HeldWindows { get { lock(gate) return state.attempts.Where(a=>a.window!=0).Select(a=>a.window).Concat(state.held.Where(h=>h.closedUtc==null).Select(h=>h.window)).ToList(); } }
        // Under gate: a handed-over Repair Order, to be looked at now and then.
        void Hold(string jobId,long window,int processId,long processStart) {
            state.held.RemoveAll(h=>h.window==window);
            state.held.Add(new EbayHeldRo {jobId=jobId??"",window=window,processId=processId,processStart=processStart,atUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture)});
            while(state.held.Count>100) state.held.RemoveAt(0);
        }
        // Ebay-auto 1.0.0: how many handed-over Repair Orders are still open in COSTAR (as last looked at).
        internal int HeldOpen { get { lock(gate) return state.held.Count(h=>h.closedUtc==null); } }
        // Ebay-auto 1.1.1: under gate: a verified Repair Order left open on purpose, to be looked at now and then.
        void KeepLeftOpen(string jobId,long window,int processId,long processStart) {
            state.leftOpen.RemoveAll(h=>h.window==window);
            state.leftOpen.Add(new EbayHeldRo {jobId=jobId??"",window=window,processId=processId,processStart=processStart,atUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture)});
            while(state.leftOpen.Count>200) state.leftOpen.RemoveAt(0);
        }
        // Looked at every 30 s by the window: a handed-over Repair Order that is no longer open is recorded as closed (by
        // Seb, or COSTAR closed). Nothing in COSTAR is touched.
        internal void CheckHeld() {
            List<EbayHeldRo> open;lock(gate) open=state.held.Where(h=>h.closedUtc==null).ToList();
            var closed=new List<EbayHeldRo>();
            foreach(var h in open) {
                bool there;
                try { var w=new IntPtr(h.window);there=Native.IsWindow(w)&&(int)Native.Pid(w)==h.processId; } catch(Exception) { there=true; }
                if(!there) closed.Add(h);
            }
            if(closed.Count>0) {
                lock(gate) { foreach(var c in closed) { var h=state.held.FirstOrDefault(x=>x.window==c.window&&x.closedUtc==null);if(h!=null) h.closedUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture); } try{Save();}catch(Exception){} }
                foreach(var c in closed) Journey.Note("handed_over_ro_closed",c.jobId,"","its Repair Order is no longer open in COSTAR Sydney (closed by Seb, or COSTAR closed); handed over at "+c.atUtc);
            }
            // 1.1.1: the verified ones left open on purpose: closed by hand, as intended.
            List<EbayHeldRo> mine;lock(gate) mine=state.leftOpen.Where(h=>h.closedUtc==null).ToList();
            var done=new List<EbayHeldRo>();
            foreach(var h in mine) {
                bool there;
                try { var w=new IntPtr(h.window);there=Native.IsWindow(w)&&(int)Native.Pid(w)==h.processId; } catch(Exception) { there=true; }
                if(!there) done.Add(h);
            }
            if(done.Count==0) return;
            var now=DateTime.UtcNow;
            lock(gate) { foreach(var c in done) { var h=state.leftOpen.FirstOrDefault(x=>x.window==c.window&&x.closedUtc==null);if(h!=null) h.closedUtc=now.ToString("o",CultureInfo.InvariantCulture); } try{Save();}catch(Exception){} }
            foreach(var c in done) {
                DateTime at;string openFor=DateTime.TryParse(c.atUtc,CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out at)?", open about "+Math.Max(0,(int)Math.Round((now-at.ToUniversalTime()).TotalMinutes))+" min":"";
                Journey.Note("left_open_ro_closed",c.jobId,"","its Repair Order, verified and left open on purpose at "+c.atUtc+", is no longer open in COSTAR Sydney: closed by hand, as intended (or COSTAR closed)"+openFor);
            }
        }
        // Under gate: the next report (the desk acknowledges it by its sequence).
        void SetReport(string number,string lease,string status,string message,string progress,bool typed,string remaining=null) {
            state.sequence++;
            state.report=new EbayReport {orderNumber=number,lease=lease,status=status,message=EbayText.Clean(message,2000),progress=EbayText.Clean(progress,1000),sequence=state.sequence,typed=typed,
                jobId=runJobId,attemptId=runAttemptId,remaining=remaining==null?null:EbayText.Clean(remaining,600)};
        }
        void Report(string number,string lease,string status,string message,string progress,bool typed,string remaining=null) {
            lock(gate) { SetReport(number,lease,status,message,progress,typed,remaining);Save(); }
            if(status!="entering"||(progress??"").Length==0) { Detail=message;log(message); }
            Interrupt();
        }
        // A claim this helper can't start now goes back in line on the desk with the reason (sent
        // with the next poll; if that is lost, the claim comes back and is declined again).
        volatile string declineLease,declineReason;
        void Decline(string lease,string why) {
            declineReason=EbayText.Clean(why,400);declineLease=lease;
            if(Detail!=why) { Detail=why; }
            Interrupt();
        }
        internal void Start() {
            if(disposed) return;
            if(!AppSettings.Current.ebayOn){AppSettings.Current.ebayOn=true;AppSettings.Current.Save();}
            bool was=Enabled;Enabled=true;AppLog.Note("ebay_start","");if(!was)Journey.Note("ebay_start","","","eBay orders on");Connect();if(!was)Interrupt();
        }
        // persist: the eBay orders switch itself (Stop eBay orders). Stop all entry only pauses.
        internal void Stop(bool persist) {
            if(persist&&AppSettings.Current.ebayOn){AppSettings.Current.ebayOn=false;AppSettings.Current.Save();}
            bool was=Enabled;Enabled=false;var active=runner;if(active!=null)active.Cancel=true;
            if(was){AppLog.Note("ebay_stop",persist?"switched off":"stop all");Journey.Note("ebay_stop",runJobId??"",runAttemptId??"",persist?"eBay orders paused (kept off until started again)":"Stop all (Ctrl+Alt+F10 or Exit): paused"+(active!=null?", the order being entered is stopped safely":""));Interrupt();}
        }
        internal void Connect(){if(disposed)return;if(Interlocked.Exchange(ref started,1)!=0)return;var t=new Thread(Loop);t.IsBackground=true;t.Start();}
        void Interrupt(){interrupted=true;var r=pending;if(r!=null){try{r.Abort();}catch(Exception){}}wake.Set();}
        internal void Reconnect(){Interrupt();}
        // 1.1.0: the COSTAR Sydney new orders go into (never Order Check's WIP window): SydneyChoice keeps the earliest-started
        // Sydney while it is valid, whatever else is open. Null with the reason when there is none. Looked for every 3 s.
        CostarInstance FindTarget(out string detail) {
            if(DateTime.UtcNow-targetAt<TimeSpan.FromSeconds(3)) { detail=targetDetail;return target; }
            CostarInstance found=null;
            try {
                var scan=EbayAutoCostar.Scan(Branch);
                string signature=EbayAutoCostar.Signature(scan);
                if(signature!=scanSignature) { scanSignature=signature;Journey.Note("costar_scan","","",EbayAutoCostar.Summary(scan)); }
                string change;var chosen=choice.Next(scan,EbayAutoCostar.Alive,DateTime.UtcNow,out change);
                if(change.Length>0) { Journey.Note("costar_target","","",change);AppLog.Note("costar_target",change); }
                if(chosen==null) { detail="COSTAR Branch "+Branch+" (Sydney) is not open in this Remote Desktop session";TargetWords=""; }
                else {
                    found=chosen.Instance();
                    int sydney=scan.Count(s=>s.Branch==Branch&&!s.OrderCheck);
                    TargetWords="COSTAR "+chosen.Label+" · PID "+chosen.Pid+" · started "+EbayAutoCostar.Time(chosen.Started)+(sydney>1?" · "+sydney+" Sydney open: the earliest-started one is used":"");
                    detail=choice.Waiting??"COSTAR "+chosen.Label+" ready (PID "+chosen.Pid+")";
                }
            } catch(Exception e) {
                // A scan that fails is not a change: the COSTAR chosen before stays chosen.
                detail="COSTAR couldn't be looked for just now ("+Sanitize.Text(e.Message,120)+"): looking again";found=target;
            }
            // Keep the same instance object while it is the same COSTAR, so Same() checks hold.
            if(found!=null&&target!=null&&found.Same(target)) found=target;
            target=found;targetDetail=detail;targetAt=DateTime.UtcNow;return found;
        }
        // Ebay-auto 1.0.0: COSTAR Sydney usable for Add new, or why not (a person may be working in it: a window of COSTAR's
        // own over it, or COSTAR not answering). Read only: nothing is pressed. Never a window's title (it can name a
        // customer or say things that stay on the screen only).
        internal static string Blocked(CostarInstance t) {
            IntPtr main=CostarWindows.Main(t);UIntPtr answer;
            if(Native.SendNull(main,0,UIntPtr.Zero,IntPtr.Zero,0x0002,250,out answer)==IntPtr.Zero) return "COSTAR "+t.Label+" isn't answering (busy): waiting until it is";
            if(Native.IsWindowEnabled(main)) return null;
            return "COSTAR "+t.Label+" has a window of its own open over it (someone may be working in it, e.g. a Repair Order left for manual completion): waiting until that window is closed";
        }
        // Whether an eBay order may start now, and why not.
        bool Available(out string detail) {
            if(coordinator.Busy) { detail=coordinator.Owner+" is filling COSTAR";return false; }
            var online=OnlineWaiting;string onlineWhy=null;
            try { onlineWhy=online==null?null:online(); } catch(Exception) { onlineWhy=null; }
            if(onlineWhy!=null) { detail="Waiting: "+onlineWhy;return false; }
            if(CostarInputLock.LegacyOpen()) { detail="Another COSTAR helper is typing into COSTAR in this session (or the old standalone autofill is open): waiting";return false; }
            var t=FindTarget(out detail);
            if(t==null) return false;
            // 1.1.0: the chosen Sydney can't be read just now, or may be changing branch: wait for it.
            string waiting=choice.Waiting;if(waiting!=null) { detail=waiting;return false; }
            return Ready(t,true,out detail);
        }
        // Whether COSTAR t can take an order now (the checks after the choice), and why not. needWip: Add new will be pressed
        // (a new Repair Order). 1.1.0: a check that fails (t busy, closed or changed) never chooses another COSTAR: FindTarget
        // looks again (SydneyChoice keeps the choice unless it closed or showed another branch twice).
        bool Ready(CostarInstance t,bool needWip,out string detail) {
            // Ebay-auto: COSTAR busy, or a window of COSTAR's over it: the order waits (instead of being taken and stopping).
            try { string why=Blocked(t);if(why!=null) { detail=why;return false; } }
            catch(Exception) { targetAt=DateTime.MinValue;detail="COSTAR "+t.Label+" (PID "+t.Pid+") couldn't be checked just now (closed, busy or changing): looking again";return false; }
            // 2.6.8: Add new starts a Repair Order only from Work-in-Progress (CostarWindows.WhyNotOnWip): on
            // another list the order waits in the desk's queue, with the reason on the panel, until it's back.
            if(needWip) {
                try { string why=CostarWindows.WhyNotOnWip(t); if(why!=null) { detail=why;return false; } }
                catch(Exception) { targetAt=DateTime.MinValue;detail="COSTAR "+t.Label+" (PID "+t.Pid+") couldn't be checked just now (closed, busy or changing): looking again";return false; }
            }
            if(Native.UserActiveWithin(QuietSeconds*1000)) { detail="Waiting for a quiet moment: someone is using this Remote Desktop session";return false; }
            detail="";return true;
        }
        // 1.1.0: an order typed part-way goes on only in its own COSTAR (the same process: PID and start time) and its own
        // Repair Order, whichever Sydney is chosen for new orders now. Null when that COSTAR or Repair Order is gone (Run
        // then refuses it, as before: it is never moved into another COSTAR).
        CostarInstance PinnedTarget(EbayAttempt a) {
            if(a==null||a.window==0||a.processId<=0) return null;
            var own=new CostarSeen {Pid=a.processId,Started=a.processStart,Session=a.sessionId>0?a.sessionId:LocalProcess.Session};
            if(!EbayAutoCostar.Alive(own)) return null;
            var w=new IntPtr(a.window);if(!Native.IsWindow(w)||(int)Native.Pid(w)!=a.processId) return null;
            var seen=EbayAutoCostar.Scan(Branch).FirstOrDefault(s=>s.SameProcess(own));
            return seen==null?null:seen.Instance();
        }
        // Ebay-auto 1.0.0: the waiting reason, recorded when it changes (not on every look; the same few reasons
        // alternating are recorded at most once a minute each).
        string lastWait="";readonly Dictionary<string,DateTime> waitSaid=new Dictionary<string,DateTime>(StringComparer.Ordinal);
        void NoteWait(string detail,bool available) {
            string now=available?"ready":Sanitize.Text(detail??"",300);
            if(now==lastWait) return;
            lastWait=now;DateTime at;
            if(waitSaid.TryGetValue(now,out at)&&DateTime.UtcNow-at<TimeSpan.FromMinutes(1)) return;
            waitSaid[now]=DateTime.UtcNow;if(waitSaid.Count>50) waitSaid.Clear();
            Journey.Note(available?"ready":"waiting","","",now);
        }
        // The receiver's address, its key and its certificate (by its fingerprint) from the connection.
        HttpWebRequest Make(string method,string path,int timeoutMs) {
            var request=(HttpWebRequest)WebRequest.Create(settings.baseUrl.TrimEnd('/')+path);
            request.Method=method;request.Headers["Authorization"]="Bearer "+settings.token;request.AllowAutoRedirect=false;request.Proxy=null;
            request.Timeout=timeoutMs;request.ReadWriteTimeout=timeoutMs;request.ServicePoint.Expect100Continue=false;
            request.ServerCertificateValidationCallback=delegate(object sender,X509Certificate cert,X509Chain chain,System.Net.Security.SslPolicyErrors errors) {
                if(cert==null)return false;using(var c=new X509Certificate2(cert))return DateTime.Now>=c.NotBefore&&DateTime.Now<=c.NotAfter&&Wire.Equal(Wire.Hash(c.RawData),settings.certificateHash);
            };
            return request;
        }
        EbayReply Request(EbayHello hello) {
            var request=Make("POST","/api/worker/v1/ebay",8000+hello.waitMs);request.ContentType="application/json";
            byte[] bytes=Encoding.UTF8.GetBytes(Wire.Json(hello));request.ContentLength=bytes.Length;
            pending=request;
            try {
                using(var output=request.GetRequestStream())output.Write(bytes,0,bytes.Length);
                try {using(var response=request.GetResponse())using(var input=response.GetResponseStream())using(var reader=new StreamReader(input,Encoding.UTF8))return Wire.Read<EbayReply>(reader.ReadToEnd());}
                catch(WebException e) {
                    if(e.Response!=null)using(var input=e.Response.GetResponseStream())using(var reader=new StreamReader(input)) {
                        string body=reader.ReadToEnd();
                        var code=((HttpWebResponse)e.Response).StatusCode;
                        if(code==HttpStatusCode.NotFound||code==HttpStatusCode.Unauthorized) throw new InvalidOperationException("The receiver did not take the eBay request ("+(int)code+"). Import the receiver's connection again (Paste connection, or Import connection) on this worker.");
                        throw new InvalidOperationException("Receiver rejected the request: "+body);
                    }
                    throw;
                }
            } finally { pending=null; }
        }
        // Ebay-auto 1.0.0: in touch with the receiver or not (recorded when that changes), and the diagnostics it asks for.
        bool inTouch;int failures;DateTime lostSince=DateTime.MinValue;string diagnosticsDone;
        // Whether the last look found everything ready for the next order (for the window).
        internal volatile bool LastAvailable;
        void Loop() {
            while(!disposed) {
                bool held=false;
                try {
                    string detail;string updating=Updating,protocolProblem=ProtocolProblem;bool accepting=Enabled&&updating==null&&protocolProblem==null,available=false;
                    if(updating!=null) detail=updating;
                    else if(protocolProblem!=null) detail=protocolProblem;
                    else if(!Enabled) detail="eBay orders paused on the Ebay-auto worker";
                    else if(busy) detail="Entering an eBay order";
                    else available=Available(out detail);
                    LastAvailable=accepting&&!busy&&available;
                    if(accepting&&!busy) NoteWait(detail,available);
                    // The order being entered is read BEFORE the report: an entry's last report is saved
                    // before it lets go of its lease, so the desk never sees "not entering" without it.
                    string working=runLease??"";
                    EbayReport report;int sequence;lock(gate){report=state.report==null?null:Wire.Copy(state.report);sequence=state.sequence;}
                    string declined=declineLease,declinedWhy=declineReason;
                    int waitMs=accepting&&!busy&&declined==null&&AppSettings.Current.longPoll?(available?8000:2000):0;
                    var clock=Stopwatch.StartNew();interrupted=false;
                    string requestId=EbayQueue.NewId("R");
                    var reply=Request(new EbayHello {workerId=settings.workerId,accepting=accepting,available=available,detail=EbayText.Clean(detail,400),report=report,waitMs=waitMs,working=working,declined=declined,declineReason=declinedWhy,sequence=sequence,version=AutofillForm.Version,requestId=requestId,protocol=Product.Protocol});
                    if(updating!=null&&Updating==updating) pollsSinceUpdating++;
                    if(reply!=null) {
                        ReceiverVersion=EbayText.Clean(reply.version,80);
                        string problem=Product.Speaks(reply.protocol)?null:"The receiver ("+(String.IsNullOrEmpty(reply.version)?"another version":reply.version)+") speaks protocol "+Product.ProtocolOf(reply.protocol)+"; this worker ("+Product.Version+") knows "+Product.MinProtocol+(Product.MinProtocol==Product.Protocol?"":"-"+Product.Protocol)+": update "+(Product.ProtocolOf(reply.protocol)>Product.Protocol?"this worker":"the receiver")+" (orders wait on the receiver meanwhile)";
                        if(problem!=ProtocolProblem) { ProtocolProblem=problem;Journey.Note(problem==null?"protocol_ok":"protocol_mismatch","","",problem??"the receiver's protocol is one this worker knows again"); }
                    }
                    if(declined!=null&&declineLease==declined){declineLease=null;declineReason=null;}
                    held=reply!=null&&reply.held;
                    int waited=reply==null?0:Math.Max(0,reply.waitedMs);
                    RoundTripMs=(int)Math.Max(0,clock.ElapsedMilliseconds-waited);lastContactTick=Environment.TickCount==0?1:Environment.TickCount;
                    Connection="Receiver connected ("+ReceiverHost+")";if(!busy)Detail=detail;
                    if(!inTouch) { inTouch=true;Journey.Note("receiver_connected","","",(failures>0?"again after "+failures+" failed poll(s)"+(lostSince==DateTime.MinValue?"":", out of touch since "+lostSince.ToLocalTime().ToString("HH:mm:ss",CultureInfo.InvariantCulture)):"first contact")+" (request "+requestId+")");failures=0;lostSince=DateTime.MinValue; }
                    if(report!=null) Journey.Note("report_sent",report.jobId??"",report.attemptId??"",report.status+" (sequence "+report.sequence+", request "+requestId+")"+(reply!=null&&reply.ack==report.sequence?": acknowledged":": not acknowledged yet"));
                    if(reply!=null&&report!=null&&reply.ack==report.sequence) lock(gate) { if(state.report!=null&&state.report.sequence==report.sequence){state.report=null;try{Save();}catch(Exception){}} }
                    if(reply!=null&&reply.command=="forget") Journey.Note("report_forgotten",report==null?"":report.jobId??"",report==null?"":report.attemptId??"","the receiver no longer has that claim");
                    if(declined!=null) Journey.Note("decline_sent","","",Sanitize.Text(declinedWhy,300)+" (request "+requestId+")");
                    // Ebay-auto: the receiver wants this worker's diagnostics (Seb exported them there).
                    if(reply!=null&&!String.IsNullOrEmpty(reply.diagnostics)&&reply.diagnostics!=diagnosticsDone) { diagnosticsDone=reply.diagnostics;SendDiagnostics(reply.diagnostics); }
                    // Switched off meanwhile: the order goes back in line. While busy, a handed-back claim
                    // can only be the order being entered (one at a time): it is never declined.
                    if(reply!=null&&reply.command=="enter"&&!busy&&!disposed) {
                        string not=Updating??ProtocolProblem;
                        if(Enabled&&not==null) Accept(reply);
                        else if(!String.IsNullOrEmpty(reply.lease)&&reply.lease!=lastStartedLease) Decline(reply.lease,not??"eBay orders paused on the Ebay-auto worker");
                    }
                } catch(Exception e) {
                    if(disposed) break;
                    if(interrupted){interrupted=false;continue;}
                    Connection="Receiver not reachable: "+NetworkRules.Unreachable(e);AppLog.PollError("ebay: "+e.Message);
                    failures++;
                    if(inTouch||failures==1) { if(inTouch) lostSince=DateTime.UtcNow;inTouch=false;Journey.Note("receiver_unreachable","","",Sanitize.Text(NetworkRules.Unreachable(e),300)); }
                }
                if(!disposed){int ms=held?100:Enabled?2000:3000;wake.WaitOne(ms);}
            }
        }
        string ReceiverHost { get { try { var u=new Uri(settings.baseUrl);return u.Host+":"+u.Port; } catch(Exception) { return "?"; } } }
        // The lease of the last order this helper started: a claim the desk hands back again before it
        // has the result (a run that stopped early) is never started a second time.
        volatile string lastStartedLease;
        void Accept(EbayReply reply) {
            Order.Require(reply.order!=null&&!String.IsNullOrWhiteSpace(reply.lease),"The receiver omitted the eBay order.");
            if(reply.lease==lastStartedLease) return;
            string number=reply.order.orderNumber??"",jobId=reply.jobId??"",attemptId=reply.attemptId??"";
            Journey.Note("claim_received",jobId,attemptId,(reply.startAgain?"Start again: a new Repair Order":reply.fresh?"a new Repair Order":"continues where it stopped, if unchanged")+"; "+EbayDiag.Shape(reply.order));
            Alerts.JobStarted(number);   // 2.8.0: a stop said earlier is old news
            try { reply.order.Validate(); }
            catch(InvalidOperationException e) { runJobId=jobId;runAttemptId=attemptId;Report(number,reply.lease,"failed","Not entered: "+e.Message,"",false);runJobId=null;runAttemptId=null;Journey.Note("refused",jobId,attemptId,"not a valid order: "+Sanitize.Text(e.Message,300));return; }
            string when,handed;EbayAttempt earlier;lock(gate){when=EbayAttempts.Entered(state,number);handed=EbayAttempts.HandedOver(state,number);earlier=state.attempts.FirstOrDefault(a=>a.orderNumber==number);}
            string refusal=EbayAttempts.Refusal(number,reply.fresh,reply.startAgain,reply.status!=null&&reply.status.typed,earlier,when==null?null:When(when),handed==null?null:When(handed));
            // Typed as far as anyone here knows: the desk's Start again dialog then warns.
            if(refusal!=null) {
                runJobId=jobId;runAttemptId=attemptId;
                bool again=handed!=null&&when==null;
                Report(number,reply.lease,again?"handed_over":"failed",refusal,"",when!=null||handed!=null||(earlier!=null&&earlier.typed)||(reply.status!=null&&reply.status.typed),
                    again?"handed over before ("+When(handed)+"): finish it in the Repair Order left open in COSTAR Sydney; close it":null);
                runJobId=null;runAttemptId=null;
                AppLog.Note("ebay_refused",jobId+" "+refusal);Journey.Note("refused",jobId,attemptId,Sanitize.Text(refusal,300));
                if(handed==null) Alerts.JobStopped("eBay order",number,refusal,false);
                return;
            }
            // The quiet moment and the other tabs are checked again now: the desk may have held this
            // poll for seconds, or handed back an earlier claim.
            string detail;CostarInstance t;
            // 1.1.0: a Retry of an order typed part-way goes back into its own COSTAR and Repair Order (never another).
            var pinned=!reply.fresh&&!reply.startAgain&&earlier!=null&&(earlier.typed||earlier.touched)&&!earlier.unknown?PinnedTarget(earlier):null;
            if(pinned!=null) {
                bool free=!coordinator.Busy;
                if(!free) detail=coordinator.Owner+" is filling COSTAR";
                else if(!Ready(pinned,false,out detail)) free=false;
                if(!free) { Decline(reply.lease,detail);Journey.Note("declined",jobId,attemptId,Sanitize.Text(detail,300));return; }
                t=pinned;
                Journey.Note("costar_pinned",jobId,attemptId,"typed part-way before: it goes on only in its own COSTAR "+t.Label+" PID "+t.Pid+" (started "+EbayAutoCostar.Time(t.Started)+") and its own Repair Order");
            } else {
                if(!Available(out detail)) { Decline(reply.lease,detail);Journey.Note("declined",jobId,attemptId,Sanitize.Text(detail,300));return; }
                t=FindTarget(out detail);
                if(t==null) { Decline(reply.lease,detail);Journey.Note("declined",jobId,attemptId,Sanitize.Text(detail,300));return; }
            }
            var entry=coordinator.TryBegin("eBay order",t);
            if(entry==null) { string why=(coordinator.Owner??"Another entry")+" is filling COSTAR";Decline(reply.lease,why);Journey.Note("declined",jobId,attemptId,why);return; }
            bool startedThread=false,claimed=false;
            try {
                lock(gate) {
                    if(busy||disposed) return;
                    if(!Enabled) { Decline(reply.lease,"eBay orders paused on the Ebay-auto worker");return; }
                    // From here every poll says this order is being worked on (working = its lease).
                    busy=true;claimed=true;runNumber=number;runLease=reply.lease;lastStartedLease=reply.lease;runJobId=jobId;runAttemptId=attemptId;
                }
                var thread=new Thread(delegate(){Run(reply,entry);});thread.IsBackground=true;thread.SetApartmentState(ApartmentState.STA);thread.Start();startedThread=true;
            } finally { if(!startedThread){if(claimed){runNumber=null;runLease=null;lastStartedLease=null;runJobId=null;runAttemptId=null;busy=false;}entry.Dispose();} }
        }
        static string When(string utc) {
            DateTime at;
            return DateTime.TryParse(utc,CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out at)?at.ToLocalTime().ToString("ddd d MMM, HH:mm",CultureInfo.InvariantCulture):utc;
        }
        // The order being entered and its lease, for progress reports (at most one every 2.5 s).
        volatile string runNumber,runLease,runJobId,runAttemptId;volatile bool runTyped;
        internal string CurrentJob { get { return runJobId??""; } }
        void Progress(string message) {
            log(message);Detail=message;
            if(progressClock.ElapsedMilliseconds<2500) return;
            progressClock.Restart();
            var r=runner;string number=runNumber,lease=runLease;
            if(number==null||lease==null) return;
            try { Report(number,lease,"entering",message,message,runTyped||(r!=null&&r.Writes>0)); } catch(Exception) { }
        }
        void Run(EbayReply reply,EntryLease entry) {
            CostarInputLock inputLock=null;var clock=Stopwatch.StartNew();var job=reply.order;string number=job.orderNumber;
            string jobId=reply.jobId??"",attemptId=reply.attemptId??"";
            EbayAttempt attempt=null;IntPtr window=IntPtr.Zero;bool typedBefore=false;
            try {
                Current=job.Reference+"  ·  "+job.BuyerName+"  ·  $"+(job.totalCents/100m).ToString("0.00",CultureInfo.InvariantCulture);
                inputLock=new CostarInputLock();CostarWindows.Main(entry.Target);
                var earlier=Attempt(number);typedBefore=earlier!=null&&earlier.typed;
                // Start again: Tommy checked COSTAR. The earlier record of this order (finished or not)
                // is retired, so a Retry of this new attempt works like any other.
                if(reply.startAgain) lock(gate) { if(state.entered.RemoveAll(e=>e.StartsWith(number+"|",StringComparison.Ordinal))+state.handedOver.RemoveAll(e=>e.StartsWith(number+"|",StringComparison.Ordinal))>0) Save(); }
                if(reply.fresh&&earlier!=null){Forget(number);log("Start again: the earlier attempt of "+number+" is set aside; a new Repair Order is used.");earlier=null;}
                bool alive=earlier!=null&&earlier.window!=0&&Native.IsWindow(new IntPtr(earlier.window))&&(int)Native.Pid(new IntPtr(earlier.window))==earlier.processId&&
                    earlier.processId==entry.Target.Pid&&earlier.processStart==entry.Target.Started&&Branches.OrderTitle(Native.Caption(new IntPtr(earlier.window)),entry.Target.Branch);
                string why;string plan=EbayAttempts.Decide(earlier,reply.fresh,alive,out why);
                Order.Require(plan!=EbayAttempts.Refuse,why);
                // Recorded before the desk hears anything: if the helper closes from here on, it reports
                // this order as stopped when it starts again (never left "being entered" on the desk).
                bool resume=plan==EbayAttempts.Resume;
                attempt=new EbayAttempt {orderNumber=number,lease=reply.lease,window=plan==EbayAttempts.Fresh?0:earlier.window,processId=entry.Target.Pid,processStart=entry.Target.Started,
                    branch=entry.Target.Branch,typed=resume&&earlier.typed,stopPrint=resume?earlier.stopPrint:null,running=true,atUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture),jobId=jobId,attemptId=attemptId};
                Remember(attempt);
                runTyped=earlier!=null&&earlier.typed;progressClock.Restart();
                Report(number,reply.lease,"entering",resume?"Continuing in the Repair Order it stopped in":"Opening a Repair Order in COSTAR "+entry.Target.Label,"",runTyped);
                AppLog.Note("ebay_fill_start",jobId+" "+plan+(earlier!=null?" (earlier attempt "+(earlier.typed?"typed":"untyped")+")":""));
                Journey.Note("started",jobId,attemptId,plan+" in COSTAR "+entry.Target.Label+" (PID "+entry.Target.Pid+", session "+entry.Target.Session+")");
                coordinator.Progress.Begin("eBay order",job.Reference,6+job.Plan().Count);
                bool reopened=false;
                while(true) {
                    long openMs=-1;bool own=plan==EbayAttempts.Resume;
                    if(plan==EbayAttempts.Fresh) {
                        var openTimer=Stopwatch.StartNew();
                        window=CostarWindows.OpenNew(entry.Target,delegate{},delegate{return !Enabled||disposed;},true);
                        openMs=openTimer.ElapsedMilliseconds;AppLog.Note("ebay_add_new",jobId+" "+openMs+" ms");
                    } else window=new IntPtr(earlier.window);
                    ProcessIdentity identity;Order.Require(LocalProcess.IsNamed((int)Native.Pid(window),"COSTAR",out identity),"COSTAR changed while opening the order.");
                    attempt=new EbayAttempt {orderNumber=number,lease=reply.lease,window=window.ToInt64(),processId=(int)Native.Pid(window),processStart=identity.Started,sessionId=identity.Session,branch=entry.Target.Branch,
                        typed=earlier!=null&&earlier.typed&&own,stopPrint=own?earlier.stopPrint:null,running=true,atUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture),jobId=jobId,attemptId=attemptId};
                    Remember(attempt);
                    Journey.Note("repair_order",jobId,attemptId,(openMs>=0?"opened with Add new in "+openMs+" ms":"the one it stopped in")+": window "+window.ToInt64()+", COSTAR PID "+attempt.processId);
                    // Ebay-auto: the run is named by the job's id (its report folder and diagnostics carry no eBay number).
                    runner=new Runner(entry.Target.Pid,entry.Target.Branch,job.EngineOrder(),"",false,Progress,window.ToInt64(),String.IsNullOrEmpty(jobId)?null:jobId);
                    runner.Diag.Job(jobId,attemptId);
                    runner.OnStage=coordinator.Progress.Stage;
                    runner.FreshlyOpened=openMs>=0;if(openMs>=0)runner.Diag.OpenNewMs=openMs;
                    runner.OwnAttempt=own;runner.ResumePrint=own?earlier.stopPrint:null;
                    // Recorded just before the first field is written: a close from then on can't be
                    // taken for an untouched Repair Order.
                    var current=attempt;
                    runner.BeforeFirstWrite=delegate { if(current!=null&&!current.touched){current.touched=true;Remember(current);} };
                    // Ebay-auto: an item COSTAR doesn't know is left for Seb (Runner.EbayAuto.cs); the journal knows at once.
                    runner.HandOffUnknownItems=true;
                    runner.OnUnknownItem=delegate(EbayUnresolved u) {
                        current.unknown=true;current.touched=true;current.unresolved=EbayText.Clean((current.unresolved==null?"":current.unresolved+"; ")+"item "+u.Sku+" (line "+u.Line+")",300);Remember(current);
                        Journey.Note("unknown_item",jobId,attemptId,u.Record);
                    };
                    runner.Cancel=!Enabled||disposed;
                    runner.CloseWhenEntered=AppSettings.Current.ebayClose;
                    // 1.1.1: off (the default): verified, then left open on purpose for Seb to check and close.
                    runner.LeaveOpenWhenEntered=!runner.CloseWhenEntered;
                    // 1.1.6: the Repair Order numbers copied before (never copied again), and the text copied last (taken off the
                    // clipboard if this order's own number can't be copied).
                    lock(gate) { runner.EarlierRoNumbers=RoNumber.Earlier(state.roNumbers);runner.LastCopiedText=RoNumber.LastText(state.roNumbers); }
                    try { runner.RunEbay(job);break; }
                    catch(RepairOrderInUseException) {
                        // The earlier EMPTY Repair Order (nothing typed there) holds something now: leave
                        // it, open a new one. Never for a Repair Order this order was typed into.
                        if(reopened||plan!=EbayAttempts.Reuse) throw;
                        reopened=true;var used=runner;runner=null;try{used.Dispose();}catch(Exception){}
                        log("The earlier Repair Order is no longer empty; it is left untouched and a new one is opened.");
                        Journey.Note("reopen",jobId,attemptId,"the earlier empty Repair Order holds something now: left untouched, a new one is opened");
                        plan=EbayAttempts.Fresh;earlier=null;
                    }
                }
                if(runner.HandedOver) { HandOver(reply,number,attempt,clock,null);return; }
                // 1.1.1: verified and left open on purpose, nothing to check by hand: "ez, next" (never a warning, never NEEDS YOU).
                // 1.1.6: and its number on the clipboard with DFE (a number not copied is a CHECK BY HAND note: no "ez, next").
                bool leftOpen=runner.LeftOpen&&!runner.Closed&&runner.Checks.Count==0;
                string done=EbayFinish.Words(entry.Target.Label,runner.Closed,leftOpen,runner.Notices,runner.Checks);
                string roNumber=runner.RoNumberCopied;
                // Entered and its report in one write: a close in between can't lose either.
                lock(gate) {
                    state.attempts.RemoveAll(a=>a.orderNumber==number);
                    state.entered.Add(number+"|"+DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture));
                    while(state.entered.Count>500) state.entered.RemoveAt(0);
                    if(leftOpen&&attempt!=null&&attempt.window!=0) KeepLeftOpen(jobId,attempt.window,attempt.processId,attempt.processStart);
                    if(roNumber!=null) { try { RoNumber.Keep(state.roNumbers,number,jobId,roNumber,DateTime.UtcNow); } catch(InvalidOperationException e) { AppLog.Note("ro_number_keep",e.GetType().Name); } }
                    SetReport(number,reply.lease,"ready_for_review",done,"",true);
                    Save();
                }
                // The number itself only here, in this window (its log isn't kept): never in the report, journey or diagnostics.
                Detail=leftOpen?done+" ("+number+" is in COSTAR "+entry.Target.Label+(roNumber!=null?" as Repair Order "+roNumber:"")+", verified; its Repair Order is left open for you to check and close"+(roNumber!=null?"; \""+roNumber+RoNumber.Suffix+"\" is on the clipboard":"")+")":done;log(Detail);Interrupt();
                LastLine=number+" in COSTAR"+(roNumber!=null?" as RO "+roNumber:"")+(runner.Checks.Count>0?" (check by hand)":runner.Closed?" (closed)":leftOpen?" (left open for you: ez, next)":"")+" at "+DateTime.Now.ToString("HH:mm");
                coordinator.Progress.End(true,job.Reference+" ready for review");
                AppLog.Note("ebay_fill_ok",jobId+" in "+(clock.ElapsedMilliseconds/100/10.0).ToString("0.0",CultureInfo.InvariantCulture)+" s run="+runner.Diag.RunId+(runner.Checks.Count>0?" checks="+runner.Checks.Count:"")+(runner.RoNumberOutcome!="not_reached"?" ro_number="+runner.RoNumberOutcome:""));
                string numberWords=runner.RoNumberOutcome=="not_reached"?"":"; Repair Order number "+(roNumber!=null?"copied with DFE ("+runner.RoNumberShape+", read back the same)":"not copied ("+runner.RoNumberOutcome+(String.IsNullOrEmpty(runner.RoNumberWhy)?"":": "+runner.RoNumberWhy)+")");
                Journey.Note("completed",jobId,attemptId,(runner.Checks.Count>0?"entered and checked, CHECK BY HAND ("+runner.Checks.Count+"): "+Sanitize.Text(String.Join(" ",runner.Checks.ToArray()),300):"entered and verified")+"; Repair Order "+(runner.Closed?"closed (in Work-in-Progress)":leftOpen?"left open on purpose for Seb to check and close by hand (close after entry is off; window "+(attempt==null?0:attempt.window)+"); reported \""+EbayFinish.EzNext+"\"":"left open")+numberWords+"; "+Seconds(clock)+"; stages: "+Stages(runner));
                if(runner.Checks.Count>0) { LastAttention=jobId+": entered, CHECK BY HAND";var attention=Attention;if(attention!=null){try{attention("check",number+": entered; check by hand: "+String.Join(" ",runner.Checks.ToArray()));}catch(Exception){}} }
            } catch(EbayHandoffException h) {
                try{if(runner!=null)runner.Diag.HandedOver(h.Message);}catch{}
                HandOver(reply,number,attempt,clock,h);
            } catch(Exception e) {
                try{if(runner!=null)runner.Diag.Stopped(e);}catch{}
                bool typed=attempt==null&&typedBefore&&!reply.fresh;
                try {
                    var r=runner;
                    if(attempt!=null) {
                        // This run touched the Repair Order (typed, or checked it for a resume): its stop
                        // print counts. Otherwise the earlier one still describes it.
                        bool touched=r!=null&&(r.Writes>0||r.ResumeVerified);
                        typed=attempt.typed||touched;
                        attempt.running=false;attempt.typed=typed;attempt.stopPrint=touched?r.StopPrint:attempt.stopPrint;attempt.message=e.Message;
                        Remember(attempt);
                    }
                } catch(Exception persist) { Enabled=false;log("eBay orders stopped: the attempt could not be saved. "+persist.Message);Journey.Note("journal_write_failed",jobId,attemptId,persist.GetType().Name+": eBay orders paused"); }
                LastLine=number+" stopped at "+DateTime.Now.ToString("HH:mm");
                coordinator.Progress.End(false,job.Reference+" stopped: "+e.Message);
                AppLog.Note("ebay_fill_stopped",jobId+" "+e.Message+(runner!=null?" run="+runner.Diag.RunId:""));
                Journey.Note("stopped",jobId,attemptId,(e is OperationCanceledException?"Stop pressed: ":"")+(typed?"typed into COSTAR before it stopped: ":"nothing typed: ")+Sanitize.Text(e.Message,300)+"; "+Seconds(clock)+(runner!=null?"; stages: "+Stages(runner):""));
                try { Report(number,reply.lease,"failed",e.Message,"",typed); } catch(Exception persist) { Enabled=false;log("eBay orders stopped: the result could not be saved. "+persist.Message); }
                // 2.8.0: Discord (one that typed nothing is said only if the desk PC's own retry doesn't start it again).
                if(!(e is OperationCanceledException)) Alerts.JobStopped("eBay order",number,e.Message,!typed);
                LastAttention=jobId+": stopped";var attention=Attention;if(attention!=null){try{attention("stopped",number+" stopped: "+e.Message);}catch(Exception){}}
            } finally {
                try{var r=runner;if(r!=null){r.Dispose();LastReport=r.ZipPath;log("COSTAR report: "+r.ZipPath);}}
                catch(Exception e){log("Report cleanup failed: "+e.Message);}
                finally{runner=null;Current="";runNumber=null;runLease=null;runJobId=null;runAttemptId=null;try{if(inputLock!=null)inputLock.Dispose();}finally{busy=false;entry.Dispose();Interrupt();}}
            }
        }
        // Ebay-auto 1.0.0: entered as far as it safely could; the Repair Order is left open for Seb. Released at once for the
        // next order (busy is cleared by Run's finally); never retried or continued by itself (handedOver, Refusal).
        void HandOver(EbayReply reply,string number,EbayAttempt attempt,Stopwatch clock,EbayHandoffException stop) {
            var r=runner;string jobId=reply.jobId??"",attemptId=reply.attemptId??"";
            string message=r!=null&&r.HandedOver?r.HandoffMessage:(stop!=null?stop.Message:"NEEDS MANUAL COMPLETION in COSTAR Sydney.");
            string remaining=r!=null&&r.HandedOver?r.HandoffRemaining:"check the whole order";
            lock(gate) {
                state.attempts.RemoveAll(a=>a.orderNumber==number);
                state.handedOver.Add(number+"|"+DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture)+"|"+jobId);
                while(state.handedOver.Count>500) state.handedOver.RemoveAt(0);
                if(attempt!=null&&attempt.window!=0) Hold(jobId,attempt.window,attempt.processId,attempt.processStart);
                SetReport(number,reply.lease,"handed_over",message,"",true,remaining);
                Save();
            }
            Detail=message;log(message);Interrupt();
            LastLine=number+" handed over (needs manual completion) at "+DateTime.Now.ToString("HH:mm");
            coordinator.Progress.End(false,reply.order.Reference+" handed over for manual completion");
            bool open=attempt!=null&&attempt.window!=0&&Native.IsWindow(new IntPtr(attempt.window));
            AppLog.Note("ebay_handed_over",jobId+" "+Sanitize.Text(remaining,300)+(r!=null?" run="+r.Diag.RunId:""));
            Journey.Note("handed_over",jobId,attemptId,(stop!=null?"stopped part way: ":"all lines tried: ")+Sanitize.Text(remaining,400)+"; Repair Order (window "+(attempt==null?0:attempt.window)+") "+(open?"left open":"no longer open")+"; "+Seconds(clock)+(r!=null?"; stages: "+Stages(r):""));
            Alerts.Raise("handover:"+number,"eBay order "+number+" needs manual completion in COSTAR Sydney (Repair Order left open)",remaining);
            LastAttention=jobId+": needs manual completion";var attention=Attention;if(attention!=null){try{attention("handed_over",number+" needs manual completion: "+remaining);}catch(Exception){}}
        }
        static string Seconds(Stopwatch clock) { return (clock.ElapsedMilliseconds/100/10.0).ToString("0.0",CultureInfo.InvariantCulture)+" s"; }
        // The run's stage timings in short ("Customer phone lookup 3.5 s, ...").
        static string Stages(Runner r) {
            try { return String.Join(", ",r.Diag.Report.Stages.Take(20).Select(s=>DiagnosticsBundle.StageGroup(s.Stage)+" "+(s.DurationMs/100/10.0).ToString("0.0",CultureInfo.InvariantCulture)+" s"+(s.Completed?"":" (not finished)")).ToArray()); }
            catch(Exception) { return "(not read)"; }
        }
        // Check Sydney layout (types nothing): one open, EMPTY Repair Order in COSTAR Sydney.
        internal string CheckLayout() {
            string detail;var t=FindTarget(out detail);
            Order.Require(t!=null,detail+".");
            var entry=coordinator.TryBegin("Layout check",t);
            Order.Require(entry!=null,"Wait for the current entry to finish, then check again.");
            Runner check=null;
            try {
                using(new CostarInputLock()) {
                    var orders=CostarWindows.Orders(t);
                    Order.Require(orders.Count==1,orders.Count==0?"Open a NEW, empty Repair Order in COSTAR "+t.Label+" (Add New), then click Check again.":"Leave just one Repair Order open in COSTAR "+t.Label+" (a new, empty one), then click Check again.");
                    check=new Runner(t.Pid,t.Branch,new Order {orderId="LAYOUT-CHECK",customer=new Customer {name="",phone=""},lines=new List<OrderLine>()},"",false,log,orders[0].ToInt64());
                    string text=check.CheckLayout();
                    AppLog.Note("ebay_layout_check",text.Replace("\r","").Replace("\n"," | "));
                    Journey.Note("layout_check","","",Sanitize.Text(text.Replace("\r","").Replace("\n"," | "),500));
                    return text;
                }
            } finally {
                try{if(check!=null){check.Dispose();log("Layout report: "+check.ZipPath);}}catch(Exception){}
                entry.Dispose();
            }
        }
        // ---- Ebay-auto 1.0.0: diagnostics with the receiver ----
        // The receiver's diagnostics ZIP (for this worker's export), or null with why not.
        internal byte[] ReceiverDiagnostics(out string why) {
            why=null;
            try {
                var request=Make("GET",ReceiverApi.EbayDiagnosticsPath,30000);
                using(var response=request.GetResponse())using(var input=response.GetResponseStream())using(var reader=new StreamReader(input,Encoding.UTF8)) {
                    var answer=Wire.Read<Dictionary<string,object>>(reader.ReadToEnd());object zip;
                    if(answer==null||!answer.TryGetValue("zip",out zip)||!(zip is string)) { why="the receiver sent no ZIP";return null; }
                    return Convert.FromBase64String((string)zip);
                }
            } catch(Exception e) { why=NetworkRules.Unreachable(e);return null; }
        }
        // Sends this worker's diagnostics to the receiver (it asked: token), on a thread of its own.
        void SendDiagnostics(string token) {
            var thread=new Thread(delegate() {
                string note=null;byte[] zip=null;
                try { zip=EbayAutoDiagnostics.WorkerZip(this,false,out note); }
                catch(Exception e) { note="the worker couldn't put its diagnostics together: "+e.GetType().Name+": "+Sanitize.Text(e.Message,200); }
                if(zip!=null&&zip.Length>LocalServer.HugeLimit*3/4-4096) { note="the worker's diagnostics are too big to send ("+AppData.Bytes(zip.Length)+"): export them on the worker itself";zip=null; }
                try {
                    var request=Make("POST",ReceiverApi.EbayDiagnosticsPath,60000);request.ContentType="application/json";
                    byte[] body=Encoding.UTF8.GetBytes(Wire.Json(new ReceiverApi.DiagnosticsUpload {token=token,version=AutofillForm.Version,note=note,zip=zip==null?null:Convert.ToBase64String(zip)}));
                    request.ContentLength=body.Length;
                    using(var output=request.GetRequestStream()) output.Write(body,0,body.Length);
                    using(request.GetResponse()) { }
                    Journey.Note("diagnostics_sent","","",zip==null?"no ZIP: "+note:AppData.Bytes(zip.Length)+" to the receiver (it asked: "+token+")");
                } catch(Exception e) { Journey.Note("diagnostics_not_sent","","",Sanitize.Text(NetworkRules.Unreachable(e),200)); }
            });
            thread.IsBackground=true;thread.Start();
        }
        // For the diagnostics: the journal in short (jobIds, states and times only).
        internal string JournalSummary() {
            lock(gate) {
                var b=new StringBuilder();
                b.AppendLine("Attempts kept: "+state.attempts.Count);
                foreach(var a in state.attempts) b.AppendLine("  "+(a.jobId??"(no job id)")+" "+(a.attemptId??"")+" typed="+a.typed+" running="+a.running+" touched="+a.touched+" unknown="+a.unknown+" window="+a.window+" at "+a.atUtc+(a.unresolved!=null?" unresolved: "+a.unresolved:""));
                b.AppendLine("Entered (kept for the duplicate check): "+state.entered.Count);
                b.AppendLine("Handed over (kept for the duplicate check): "+state.handedOver.Count);
                foreach(var h in state.handedOver.Skip(Math.Max(0,state.handedOver.Count-30))) { var p=h.Split('|');b.AppendLine("  "+(p.Length>2?p[2]:"")+" at "+(p.Length>1?p[1]:"")); }
                b.AppendLine("Handed-over Repair Orders: "+state.held.Count(h=>h.closedUtc==null)+" open, "+state.held.Count(h=>h.closedUtc!=null)+" since closed");
                foreach(var h in state.held.Skip(Math.Max(0,state.held.Count-30))) b.AppendLine("  "+h.jobId+" window "+h.window+" PID "+h.processId+" handed over "+h.atUtc+(h.closedUtc==null?" (open when last looked at)":" closed by "+h.closedUtc));
                b.AppendLine("Verified Repair Orders left open on purpose for Seb (\""+EbayFinish.EzNext+"\"; close after entry "+(AppSettings.Current.ebayClose?"ON":"off")+"): "+state.leftOpen.Count(h=>h.closedUtc==null)+" open, "+state.leftOpen.Count(h=>h.closedUtc!=null)+" since closed by hand");
                foreach(var h in state.leftOpen.Skip(Math.Max(0,state.leftOpen.Count-30))) b.AppendLine("  "+h.jobId+" window "+h.window+" PID "+h.processId+" left open "+h.atUtc+(h.closedUtc==null?" (open when last looked at)":" closed by hand by "+h.closedUtc));
                // 1.1.6: how many, never the numbers.
                b.AppendLine("Repair Order numbers copied with DFE (kept so none is copied for another order): "+state.roNumbers.Count+(state.roNumbers.Count>0?", the last for "+(state.roNumbers[state.roNumbers.Count-1].jobId??"")+" at "+state.roNumbers[state.roNumbers.Count-1].atUtc:""));
                b.AppendLine("Report not yet acknowledged by the receiver: "+(state.report==null?"none":state.report.status+" "+(state.report.jobId??"")+" sequence "+state.report.sequence));
                return b.ToString();
            }
        }
        public void Dispose(){disposed=true;Stop(false);}
    }
}
