// Ebay-auto 1.1.6 (Tommy, 18 Nov 10:13): once an eBay order is entered and verified and its Repair Order is left open for Seb,
// the number in the box at the top of THIS order's Repair Order (beside COSTAR's "RepairOrder" label) is read twice and
// copied to the clipboard as "<number> DFE": the number exactly as COSTAR shows it (leading zeros kept), one space, DFE, and
// nothing else (no label, no line break). The clipboard is read back; only then is "ez, next" reported and the job released
// as before. A number that isn't there, can't be read, changed between the two reads, isn't COSTAR's 8 digits, or was
// copied before (for an earlier order) is never copied: the reason is recorded, Seb is told (CHECK BY HAND), and the text copied
// for the previous order is taken off the clipboard if it is still there (so it can't be pasted for this one). The order
// is never stopped, retried or entered again because of its number.
// Next # (the button beside the box): looked at, never pressed in 1.1.6. The maps show where it is and that it is greyed
// whenever the box holds a number, but none shows what pressing it does; a Repair Order with no number yet is left for Seb.
// The diagnostics hold the number's shape (blank, 8 digits, a leading zero), never its digits.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace TempeCostar {
    // A Repair Order number copied for an eBay order (kept in the worker's journal only, never in the diagnostics).
    public sealed class EbayRoNumber { public string orderNumber,jobId,number,atUtc; }

    // One look at the Repair Order's number: its box (found, COSTAR's read-only box, read), what it holds, and the PO# the
    // same look shows.
    internal sealed class RoNumberLook {
        internal bool Box,ReadOnly,Read,PoRead;
        internal string Text,Po;
    }
    // What two looks come to: the number to copy (Outcome "ok"), or why not (Outcome: a code for the diagnostics).
    internal sealed class RoNumberVerdict { internal string Number,Outcome,Why,Shape=""; }

    internal static class RoNumber {
        internal const string Suffix=" DFE";
        // Every Repair Order number in the maps (Tempe and Sydney): 8 characters; Tommy's example has a leading zero.
        internal const int Digits=8;
        // Between the two looks at the number.
        internal const int GapMs=300;
        static readonly Regex Eight=new Regex("^[0-9]{8}$"),AllDigits=new Regex("^[0-9]+$");
        internal static bool IsNumber(string text) { return text!=null&&Eight.IsMatch(text); }
        // What is copied: the number as COSTAR shows it, one space, DFE. Only ever for a number of COSTAR's 8 digits.
        internal static string Text(string number) {
            Order.Require(IsNumber(number),"Only a Repair Order number of "+Digits+" digits is copied.");
            return number+Suffix;
        }
        // For the diagnostics: what the box holds, never its digits.
        internal static string Shape(string text) {
            if(text==null) return "not read";
            string t=text.Trim();
            if(t.Length==0) return "blank";
            if(Eight.IsMatch(t)) return Digits+" digits"+(t[0]=='0'?", a leading zero":"");
            if(AllDigits.IsMatch(t)) return t.Length+" digits";
            return t.Length+" characters, not all digits";
        }
        // From one snapshot of the Repair Order: the box beside its one "RepairOrder" label (Runner.NumberBox, 2.6.2: the
        // read-only box at [214,82] in every map), whether it is COSTAR's read-only box (an EDIT with ES_READONLY, as in every
        // map), what it holds (null: not read), this order's PO# from the same look (Selectors.Header), and the button on its
        // line just right of it (Next # in every map; a snapshot of the Repair Order doesn't read buttons' words).
        internal static RoNumberLook Look(List<ControlInfo> s,out ControlInfo next) {
            var l=new RoNumberLook();next=null;
            if(s==null) return l;
            var box=Runner.NumberBox(s);
            if(box!=null) {
                l.Box=true;
                l.ReadOnly=(box.Class??"").IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)>=0&&(box.Style&0x800)!=0;
                l.Read=box.TextState=="read"&&box.Text!=null;
                l.Text=l.Read?box.Text:null;
                next=NextBeside(s,box);
            }
            try {
                var po=Selectors.Header(s).PO;
                l.PoRead=po!=null&&po.TextState=="read";
                l.Po=l.PoRead?Order.Clean(po.Text):null;
            } catch(InvalidOperationException) { }
            return l;
        }
        // The button on the number box's line just right of it (Next # at [388,81], beside the box's [214..384], every map).
        internal static ControlInfo NextBeside(List<ControlInfo> s,ControlInfo box) {
            if(s==null||box==null||box.Bounds==null) return null;
            int mid=box.Bounds[1]+box.Bounds[3]/2,right=box.Bounds[0]+box.Bounds[2];
            ControlInfo best=null;
            foreach(var c in s) {
                if(Object.ReferenceEquals(c,box)||c.Bounds==null||!c.Visible||(c.Class??"").IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)<0) continue;
                if(Math.Abs(c.Bounds[1]+c.Bounds[3]/2-mid)>8||c.Bounds[0]<right-4||c.Bounds[0]>right+60) continue;
                if(best==null||c.Bounds[0]<best.Bounds[0]) best=c;
            }
            return best;
        }
        // COSTAR's words for Next # ("Ne&xt #").
        internal static bool IsNextWords(string words) { return Regex.Replace((words??"").Replace("&",""),@"\s+"," ").Trim().ToUpperInvariant()=="NEXT #"; }
        internal static string NextShape(bool found,bool isNext,bool enabled) {
            return !found?"no button beside it":!isNext?"the button beside it isn't Next #":"Next # beside it, "+(enabled?"enabled":"greyed");
        }
        static RoNumberVerdict Not(RoNumberVerdict v,string outcome,string why) { v.Outcome=outcome;v.Why=why;v.Number=null;return v; }
        // Two looks, GapMs apart, at this order's own Repair Order. Copied only when both found COSTAR's read-only number box,
        // read it, and showed this order's PO#; the two read the same; it holds 8 digits; and it isn't a number copied before
        // (earlier).
        internal static RoNumberVerdict Judge(RoNumberLook a,RoNumberLook b,string orderId,ICollection<string> earlier) {
            var v=new RoNumberVerdict();
            v.Shape=Shape(a==null?null:a.Text);
            foreach(var l in new[]{a,b}) {
                if(l==null||!l.Box) return Not(v,"no_box","the helper couldn't find its number box (the box beside COSTAR's RepairOrder label)");
                if(!l.ReadOnly) return Not(v,"not_number_box","the box beside COSTAR's RepairOrder label isn't its read-only number box");
                if(!l.Read) return Not(v,"unreadable","COSTAR didn't let the helper read it");
                if(!l.PoRead||Order.Clean(l.Po).Length==0||Order.Clean(l.Po)!=Order.Clean(orderId)) return Not(v,"po","the Repair Order didn't show this order's PO# with it");
            }
            string x=a.Text.Trim(),y=b.Text.Trim();
            if(x!=y) return Not(v,"changed","it changed while it was being read");
            if(x.Length==0) return Not(v,"blank","the Repair Order has no number yet");
            if(!Eight.IsMatch(x)) return Not(v,"not_8_digits","COSTAR doesn't show a number of "+Digits+" digits there");
            if(earlier!=null&&earlier.Contains(x)) return Not(v,"earlier_order","it is a number already copied for an earlier order");
            v.Number=x;v.Outcome="ok";v.Why=null;
            return v;
        }
        // The CHECK BY HAND words for Seb when the number wasn't copied (never the number itself).
        internal static string Words(string outcome,string why,bool cleared) {
            string todo=outcome=="blank"?"Press Next # on it, then copy its number followed by DFE."
                :outcome=="earlier_order"?"Check this Repair Order's number, then copy it followed by DFE."
                :outcome=="po"?"Check which Repair Order is open, then copy its number followed by DFE."
                :outcome=="skipped_checks"?"Once the rest is checked, copy its number followed by DFE."
                :"Copy it from the Repair Order, followed by DFE.";
            return "Repair Order number not copied: "+(String.IsNullOrEmpty(why)?"it couldn't be read":why)+". "+todo+(cleared?" (The previous order's number was taken off the clipboard.)":"");
        }
        // For the diagnostics' summary: each outcome in words.
        internal static string OutcomeWords(string outcome) {
            switch(outcome??"") {
                case "copied": return "copied with DFE and read back";
                case "blank": return "no number yet (Next # not pressed: left for Seb)";
                case "unreadable": return "couldn't be read";
                case "changed": return "changed between the two looks";
                case "not_8_digits": return "not 8 digits";
                case "earlier_order": return "the number copied for an earlier order";
                case "po": return "the Repair Order didn't show the order's PO#";
                case "no_box": return "number box not found";
                case "not_number_box": return "not COSTAR's read-only number box";
                case "clipboard": return "the clipboard couldn't be set";
                case "skipped_checks": return "not looked at (something to check by hand)";
                case "stopped": return "Stop pressed";
                case "error": return "the Repair Order couldn't be looked at";
                default: return outcome??"";
            }
        }
        // ---- the worker's journal ----
        // A number is kept once an order is entered and verified with it copied; such an order is never entered again
        // except by Start again, in a NEW Repair Order. So every number kept belongs to another Repair Order than the one
        // being entered (a Retry of a stopped order goes on in its own Repair Order, whose number was never kept): none is
        // ever copied again.
        internal static List<string> Earlier(IEnumerable<EbayRoNumber> kept) {
            if(kept==null) return new List<string>();
            return kept.Where(k=>k!=null&&IsNumber(k.number)).Select(k=>k.number).Distinct().ToList();
        }
        // What the worker put on the clipboard last (for an earlier order): taken off it if this order's number can't be
        // copied, and only if the clipboard still holds exactly that.
        internal static string LastText(IList<EbayRoNumber> kept) {
            if(kept==null||kept.Count==0) return null;
            var last=kept[kept.Count-1];
            return last==null||!IsNumber(last.number)?null:Text(last.number);
        }
        // Under the worker's gate: the number copied for this order, newest last (the last 200 kept).
        internal static void Keep(List<EbayRoNumber> kept,string orderNumber,string jobId,string number,DateTime utc) {
            Order.Require(IsNumber(number),"Only a Repair Order number of "+Digits+" digits is kept.");
            kept.RemoveAll(k=>k==null);
            kept.Add(new EbayRoNumber {orderNumber=orderNumber??"",jobId=jobId??"",number=number,atUtc=utc.ToUniversalTime().ToString("o",CultureInfo.InvariantCulture)});
            while(kept.Count>200) kept.RemoveAt(0);
        }
    }

    // The Windows clipboard, on a thread of its own (the clipboard needs a single-threaded apartment; the runner's thread
    // isn't one). Unicode text only, left on the clipboard after the worker closes, then read back.
    internal static class RoClipboard {
        internal const int Attempts=3,PauseMs=250,TimeoutMs=8000;
        // Pure: set, then read back, up to Attempts times; null once exactly text was read back, else why not.
        internal static string CopyChecked(string text,Action<string> set,Func<string> get,Action<int> pause,out int attempts) {
            string why="not tried";attempts=0;
            for(int i=1;i<=Attempts;i++) {
                attempts=i;
                try {
                    set(text);
                    string back=get();
                    if(back==text) return null;
                    why=String.IsNullOrEmpty(back)?"nothing was read back":"something else was read back ("+back.Length+" characters)";
                } catch(Exception e) { why=Failure(e); }
                if(i<Attempts) pause(PauseMs);
            }
            return why;
        }
        // Pure: taken off the clipboard only when it still holds exactly that text.
        internal static bool StillThere(string shown,string text) { return !String.IsNullOrEmpty(text)&&shown==text; }
        static string Failure(Exception e) {
            return e is ExternalException?"the clipboard was busy ("+e.GetType().Name+")":e.GetType().Name+": "+Sanitize.Text(e.Message,120);
        }
        // Copies text: null once it was read back the same, else why not.
        internal static string Copy(string text,out int attempts) {
            int tries=0;
            string why=OnSta(delegate {
                return CopyChecked(text,
                    delegate(string t) { var data=new DataObject();data.SetData(DataFormats.UnicodeText,false,t);Clipboard.SetDataObject(data,true,10,100); },
                    delegate { return Clipboard.ContainsText(TextDataFormat.UnicodeText)?Clipboard.GetText(TextDataFormat.UnicodeText):null; },
                    delegate(int ms) { Thread.Sleep(ms); },out tries);
            });
            attempts=tries;
            return why;
        }
        // Takes text off the clipboard only when it still holds exactly that (what this worker copied for an earlier order).
        // null: looked at (cleared: it was taken off); else why the clipboard couldn't be looked at.
        internal static string ClearIfStill(string text,out bool cleared) {
            bool done=false;
            string why=OnSta(delegate {
                string shown=Clipboard.ContainsText(TextDataFormat.UnicodeText)?Clipboard.GetText(TextDataFormat.UnicodeText):null;
                if(!StillThere(shown,text)) return null;
                Clipboard.Clear();done=true;
                return null;
            });
            cleared=done;
            return why;
        }
        static string OnSta(Func<string> work) {
            string result="not done";
            var thread=new Thread(delegate() { try { result=work(); } catch(Exception e) { result=Failure(e); } });
            thread.SetApartmentState(ApartmentState.STA);thread.IsBackground=true;thread.Name="Ebay-auto clipboard";
            thread.Start();
            if(!thread.Join(TimeoutMs)) return "the clipboard didn't answer within "+(TimeoutMs/1000)+" s";
            return result;
        }
    }
}
