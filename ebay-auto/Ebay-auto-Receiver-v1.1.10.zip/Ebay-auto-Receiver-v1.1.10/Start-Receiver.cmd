@echo off
setlocal
rem Ebay-auto receiver (Seb's physical PC): starts in the notification area. Run it again to open its window.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Launch.ps1" -Mode Receiver
set "EbayAutoExit=%ERRORLEVEL%"
if not "%EbayAutoExit%"=="0" pause
exit /b %EbayAutoExit%
