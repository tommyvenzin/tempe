﻿param([switch]$CheckOnly, [switch]$PassThru, [string]$ReportTo = '')
# Ebay-auto: builds EbayAuto.exe on this PC with the Windows .NET Framework C# compiler (nothing is downloaded or
# installed) into %LOCALAPPDATA%\EbayAuto\runtime\<build id>\bin, then runs its self-tests. The Tempe helper's folder
# (TempeMobileCostar) is never touched.
# 1.1.0: -ReportTo <file>: the outcome as JSON (ok, executable, bin, report, startupLog / error) for the update, which
# builds a new version beside the running one before anything is switched over.
$ErrorActionPreference = 'Stop'
$stage = 'Create local build folder'
$startupLog = $null
$version = '?'
try { $version = ((Get-Content -LiteralPath (Join-Path $PSScriptRoot 'VERSION.txt') -ErrorAction Stop | Select-Object -First 1) + '').Trim() } catch { }
function Write-Outcome([hashtable]$Outcome) {
    if (!$ReportTo) { return }
    try { [IO.File]::WriteAllText($ReportTo, (ConvertTo-Json -InputObject $Outcome -Compress)) } catch { }
}
try {
    if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) { throw 'Windows did not provide LOCALAPPDATA for this user.' }
    $appFolder = Join-Path $env:LOCALAPPDATA 'EbayAuto'
    [IO.Directory]::CreateDirectory($appFolder) | Out-Null
    $startupLog = Join-Path $appFolder ('startup-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + $PID + '.txt')
    @(('Ebay-auto ' + $version + ' startup'), ('Source: ' + $PSScriptRoot), ('Local data: ' + $appFolder)) | Set-Content -LiteralPath $startupLog -Encoding UTF8
    $stage = 'Read the source files'
    $requiredSources = @('AccountTests.cs','AppData.cs','AuPlaceData.cs','AuStates.cs','CostarMap.cs','CostarSession.cs','DesktopUi.cs','Diagnostics.cs','Direct.cs','EbayAutoCostar.cs','EbayAutoDiagnostics.cs','EbayAutoProgram.cs','EbayAutoReceiver.cs','EbayAutoTests.cs','EbayAutoTray.cs','EbayAutoUpdate.cs','EbayAutoWorker.cs','EbayCustomerPhone.cs','EbayCustomerPhoneTests.cs','EbayDesk.cs','EbayIncomplete.cs','EbayIncompleteTests.cs','EbayModel.cs','EbayRoNumber.cs','EbayStock.cs','EbayStockTests.cs','EbayTab.cs','EbayTests.cs','EbayWorker.cs','LocalHttp.cs','MobileModel.cs','MobileRunner.cs','MobileTests.cs','Native.cs','NewAccount.cs','OnlineAuto.cs','OnlineModelTests.cs','OnlineTab.cs','OrderCheck.cs','OrderModel.cs','Product.cs','ResourceBudget.cs','RoDesk.cs','RoModel.cs','RoTab.cs','RoTests.cs','RoWorker.cs','Runner.Customer.cs','Runner.Ebay.cs','Runner.EbayAuto.cs','Runner.EbayStock.cs','Runner.Grid.cs','Runner.NewAccount.cs','Runner.Online.cs','Runner.Popups.cs','Runner.Print.cs','Runner.Ro.cs','Runner.cs','RunsByItself.cs','Ui.cs','Unattended.cs','Updater.cs','Wholesale.cs','WholesaleDiscord.cs','WholesaleForm.cs','WholesaleSpeed.cs','WholesaleState.cs','WholesaleTab.cs','WholesaleTests.cs','WholesaleView.cs','Worker.cs')
    $sourceRoot = Join-Path $PSScriptRoot 'Source'
    $missingSources = @($requiredSources | Where-Object { !(Test-Path -LiteralPath (Join-Path $sourceRoot $_) -PathType Leaf) })
    if ($missingSources.Count -gt 0) { throw ('The Ebay-auto folder is incomplete. Missing Source files: ' + ($missingSources -join ', ') + '. Extract the complete Ebay-auto ' + $version + ' ZIP into a fresh folder and start it from there.') }
    $sourceFiles = @($requiredSources | ForEach-Object { Get-Item -LiteralPath (Join-Path $sourceRoot $_) })
    $resourceSource = Join-Path $PSScriptRoot 'Source\qr.js'
    if (!(Test-Path -LiteralPath $resourceSource)) { throw 'Extract the complete Ebay-auto ZIP, including Source.' }
    $fingerprintInputs = @($sourceFiles.FullName) + @($resourceSource, $PSCommandPath)
    $fingerprint = ($fingerprintInputs | ForEach-Object { (Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash }) -join ''
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $buildId = ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($fingerprint)))).Replace('-', '').Substring(0, 20) }
    finally { $sha.Dispose() }
    # A source-specific local folder: never runs from a network share, never overwrites an older EbayAuto.exe still open.
    $runtimeFolder = Join-Path $appFolder ('runtime\' + $buildId)
    $bin = Join-Path $runtimeFolder 'bin'
    $localSource = Join-Path $runtimeFolder 'Source'
    $stage = 'Copy build files to the local user folder'
    [IO.Directory]::CreateDirectory($bin) | Out-Null
    [IO.Directory]::CreateDirectory($localSource) | Out-Null
    foreach ($sourceFile in $sourceFiles) { Copy-Item -LiteralPath $sourceFile.FullName -Destination (Join-Path $localSource $sourceFile.Name) -Force }
    Copy-Item -LiteralPath $resourceSource -Destination (Join-Path $localSource 'qr.js') -Force
    Write-Host ('Local build folder: ' + $runtimeFolder)
    ('Build: ' + $runtimeFolder) | Add-Content -LiteralPath $startupLog -Encoding UTF8
    $stage = 'Locate the Windows C# compiler'
    $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
    if (!(Test-Path $compiler)) { $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe' }
    if (!(Test-Path $compiler)) { throw 'The Windows .NET Framework compiler is unavailable. Send this message; no software has been installed.' }
    $sources = @($requiredSources | ForEach-Object { Join-Path $localSource $_ })
    $resource = Join-Path $localSource 'qr.js'
    $exe = Join-Path $bin 'EbayAuto.exe'
    $stamp = Join-Path $bin 'build.sha256'
    if (!(Test-Path $exe) -or !(Test-Path $stamp) -or ([IO.File]::ReadAllText($stamp) -ne $fingerprint)) {
        $stage = 'Compile Ebay-auto locally'
        $refs = @('System.dll','System.Core.dll','System.Windows.Forms.dll','System.Drawing.dll','System.Web.dll','System.Web.Extensions.dll','System.Security.dll','System.IO.Compression.dll','System.IO.Compression.FileSystem.dll','Accessibility.dll')
        $arguments = @('/nologo','/target:winexe','/platform:anycpu','/langversion:5','/codepage:65001',('/out:' + $exe),('/resource:' + $resource + ',TempeQR.js'))
        $arguments += $refs | ForEach-Object { '/reference:' + $_ }
        Push-Location -LiteralPath $bin
        try {
            & $compiler @arguments @sources | Tee-Object -FilePath (Join-Path $bin 'compiler-output.txt') | Out-Host
            if ($LASTEXITCODE -ne 0) { throw ('The C# compiler exited with code ' + $LASTEXITCODE + '. See compiler-output.txt in the local bin folder and the error above.') }
        } finally { Pop-Location }
        [IO.File]::WriteAllText($stamp, $fingerprint)
    }
    $stage = 'Run the self-tests'
    $report = Join-Path $bin 'self-test-results.txt'
    $testStamp = Join-Path $bin 'self-test.sha256'
    $exeHash = (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash
    $needsTest = $CheckOnly -or !(Test-Path -LiteralPath $testStamp) -or !(Test-Path -LiteralPath $report)
    if (!$needsTest) { $needsTest = [IO.File]::ReadAllText($testStamp) -ne $exeHash }
    if ($needsTest) {
        if (Test-Path -LiteralPath $testStamp) { Remove-Item -LiteralPath $testStamp -Force }
        if (Test-Path -LiteralPath $report) { Remove-Item -LiteralPath $report -Force }
        $test = Start-Process -FilePath $exe -WorkingDirectory $bin -ArgumentList @('--self-test', ('"' + $report + '"')) -WindowStyle Hidden -PassThru -Wait
        try {
            if (!(Test-Path -LiteralPath $report)) { throw ('The self-test process exited with code ' + $test.ExitCode + ' without a report. Windows may have blocked startup; check the exact error with IT.') }
            Get-Content -LiteralPath $report | Out-Host
            if ($test.ExitCode -ne 0) { throw 'Self-tests failed. COSTAR was not changed.' }
            [IO.File]::WriteAllText($testStamp, $exeHash)
        } finally { $test.Dispose() }
    } else { Write-Host 'Reusing passing self-tests for this unchanged program. Check-Build.cmd forces a fresh run.' }
    'Build and self-tests passed.' | Add-Content -LiteralPath $startupLog -Encoding UTF8
    Write-Host ('Build and self-tests passed. Report: ' + $report) -ForegroundColor Green
    Write-Outcome @{ ok = $true; executable = $exe; bin = $bin; report = $report; startupLog = $startupLog }
    if ($PassThru) { [pscustomobject]@{ Executable=$exe; Bin=$bin; Root=$runtimeFolder; Report=$report; StartupLog=$startupLog } }
} catch {
    $message = 'Startup failed during "' + $stage + '": ' + $_.Exception.Message
    if ($startupLog) {
        try { @($message, $_.ScriptStackTrace) | Add-Content -LiteralPath $startupLog -Encoding UTF8 } catch { }
        $message += [Environment]::NewLine + 'Startup report: ' + $startupLog
    }
    Write-Outcome @{ ok = $false; error = ('during "' + $stage + '": ' + $_.Exception.Message); startupLog = $startupLog }
    throw $message
}
