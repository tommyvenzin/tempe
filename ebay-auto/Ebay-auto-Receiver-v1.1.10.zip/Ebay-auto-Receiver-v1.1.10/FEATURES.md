# 1.1.10 additions

## 1.1.10 - 24 November 2026

- Customer lookup uses Contact info only. The Ship to phone is kept for delivery contact and is never a fallback for choosing the billing account.
- A matching Contact info number in billing Mobile Ph, Home Ph or Bus Ph is accepted. COSTAR's account and phone-field placement are kept; the eBay Order/Buyer name still fills billing.
- Missing customer name/address details no longer stop the known details and order lines from being entered. Missing mandatory fields skip new-account creation; the result says CHECK BY HAND. Supplied invalid values still stop entry.
- A stopped older attempt that used a different Ship to phone is left for manual completion instead of silently changing its customer account.
- Sydney/Tempe routing, prices, totals, stock prompts, open Repair Orders, Next #, clipboard references and duplicate protection are unchanged.

Pause order entry and update BOTH app parts to 1.1.10 and the 404 extension to 1.6.1 before resuming. Keep the existing extension folder and pairing. Protocol 2 and order schema v3 are unchanged. Live COSTAR validation of the new customer behaviour is still required.

Source: Contact-only rule and incomplete-order validation in EbayModel.cs; billing Mobile/Home/Bus matching in EbayCustomerPhone.cs, OrderModel.cs, Runner.cs, Runner.Customer.cs, Runner.Ebay.cs and Runner.NewAccount.cs; known-field verification in EbayIncomplete.cs; incomplete-detail preview in extension 1.6.1 (costar_send.js, ebay_order_console.js). Historical phone fallback below is superseded by Contact-only lookup; other earlier features remain.

# 1.1.9 additions

## 1.1.9 - 20 November 2026

- Each eBay order goes into COSTAR Sydney (Br1) or COSTAR Tempe (Br11): Seb chooses with two buttons in the 404 extension 1.6.0 panel.
- Suggested Tempe when an item's own title has the whole word wheel/wheels/package/packages; otherwise Sydney; nothing when titles can't be read.
- Choosing against the suggestion (or with unread titles) asks to confirm in the panel. Package SKUs are never trimmed.
- Same receiver and worker for both branches, one order at a time; one chosen COSTAR per branch (earliest started); never moved to the other branch.
- Order payload tempe.ebay-order.v3, protocol 2. Stored 1.1.8 orders stay Sydney orders and keep their duplicate-order hashes (a 1.1.8 order sent again with the same details is the same order, not a CONFLICT).
- Stock prompt, statuses, alerts and diagnostics name the order's branch.
- Includes the extension-only 1.5.3 wheel SKU fix (published 19 November).

Requires BOTH app parts 1.1.9 and extension 1.6.0 (a 1.1.8 part gets no orders from a 1.1.9 part). The first live Tempe order still needs a watched check.

Source: branch model, routing rule and queue in EbayModel.cs; per-branch COSTAR choice in EbayAutoCostar.cs and EbayWorker.cs; branch words in Runner.Ebay.cs and Runner.EbayStock.cs; two buttons and routing in extension 1.6.0 (costar_send.js, ebay_order_console.js, background.js). All earlier features below remain.

# 1.1.8 additions

## 1.1.8 - 19 November 2026

- Contact info phone first; Ship to fallback only when no account is found; restore Contact info if both miss.
- Billing X uses the real Order/Buyer name even on a linked account. Delivery Y uses Ship to; M BUY keeps the username.
- Sydney stock: above 2 continues, 0-2 needs typed ok/check, negative needs yes confirming Seb will contact the customer.
- check preserves the existing comment and adds low stock - currently checking. Prompts cannot be skipped; Stop remains available.
- Unit addresses use slash notation and capitals; clear number/street spacing is cleaned up in preview and COSTAR.
- Stable duplicate-order hashes, retry records and diagnostic detail retained.
- Successful Repair Orders stay open; ez, next and the Repair Order + DFE clipboard remain.

Requires BOTH app parts 1.1.8 and extension 1.5.2. Live Repair Order stock layout and RDP prompt still need a watched check.

Source: phone/name routing in EbayModel.cs, Runner.Ebay.cs, Runner.Customer.cs and EbayWorker.cs; stock in EbayStock.cs and Runner.EbayStock.cs; parser and shared address formatter in extension 1.5.2. All earlier features below remain.

# Ebay-auto 1.1.7: the eBay features of helper 2.9.10 and extension 1.4.3, and where each one is now

Taken from the 2.9.10 source (commit f77a254) and the 1.4.3 extension before anything was changed. Every row is kept
in Ebay-auto (1.0.0, and still in 1.1.0); the last column says where it lives now and how it was checked (see
VALIDATION.md for the runs). The 1.1.0 additions, the 1.1.1 change, the 1.1.2, 1.1.3 and 1.1.4 additions, the 1.1.5 fix and the 1.1.6 / 1.1.7 additions are at the end.

R = Ebay-auto Receiver (Seb's physical PC). W = Ebay-auto Worker (inside Seb's Remote Desktop session).
X = the 404 But It's Found extension (Chrome on Seb's physical PC).

Checked: S = self-test (source level, made-up data), E = end-to-end test here (real extension in Chromium, the real
receiver code over TLS, the worker side played by a script), C = compiled and inspected only, L = needs live COSTAR
(not tested here).

## The eBay PC's extension (1.4.3 → 1.5.0)

| ID | Feature | 2.9.10 / 1.4.3 | Ebay-auto | Checked |
|---|---|---|---|---|
| X1 | Copy panel on eBay order pages, opened automatically (tick box) | ebay_order_console.js, background.js | X, unchanged | E |
| X2 | Copy the console script, Show copy panel on this page | popup.js | X, unchanged | C |
| X3 | Send to COSTAR: the order built from the page (state code, eBay prices, postage, total must add up, discounts refused, SKU required, 1-4 items) | costar_send.js build() | X, unchanged (1.5.1: an address with no state is sent, A8) | S, E |
| X4 | Panel status: waiting (with the reason), being entered (progress), in COSTAR ✓ / CHECK BY HAND, stopped (Send again = Retry), removed (Send again = send again) | costar_send.js describe() | X + new "needs manual completion" | S, E |
| X5 | Status followed every 3 s for 20 minutes; checked again when the page is opened | ebay_order_console.js | X, unchanged | E |
| X6 | Pairing with address + PIN, Chrome's host access (allow tab), certificate install link, Check again, Forget | popup.js, allow.js, background.js | X; the address takes a port (IP:8811); certificate link uses the receiver's own trust port; its own pairing (the 1.4 pairing with Tommy's PC is never used, left as it was) | E (the Allow tab itself: L) |
| X7 | Health in the popup (receiving, worker in touch, eBay on, ready, waiting) | popup.js | X, wording names the receiver | E |
| X8 | Only the extension's own pages and its panel on ebay.com.au may ask; the key stays in the extension | background.js allowed() | X, unchanged | E |
| X9 | (new) Cut-over: an order sold on or before the day of the switch from Tommy's PC, unknown to the receiver, asks first ("Send to COSTAR anyway") | - | X (costar_send.js beforeSwitch, the panel) | S, E |

## The receiver (Tommy's desk PC → Seb's physical PC)

| ID | Feature | 2.9.10 | Ebay-auto | Checked |
|---|---|---|---|---|
| D1 | HTTPS on the PC's LAN address with its own certificate; trust.cer on a second port | DeskForm, LocalServer, Setup-Desk | R (Setup-Receiver: own certificate, own ports 8811/8812; warned 30 days before the certificate runs out) | S, E (Setup-Receiver on Windows: L) |
| D2 | eBay key separate from everything else; 6-digit PIN pairing (10 min, 5 tries, one use); Reset eBay pairing | EbayPairing, EbayDesk | R | S, E |
| D3 | eBay routes only for the extension's origin; health, submit, status, retry | ReceiverApi.EbayRoute | R (and nothing but the eBay routes is served) | S, E |
| D4 | One receipt per eBay order number; same details = same order; changed before pickup replaces; after pickup CONFLICT; removed and sent again (new RO, or continues if typed) | EbayQueue.Submit | R | S, E |
| D5 | FIFO, leases, a lost claim comes back with the same lease, declines go back in line with the reason, "no longer entering" → stopped, reports acknowledged by sequence, 50 waiting at most, old finished pruned past 300 | EbayQueue.Poll | R | S, E |
| D6 | Queue kept on disk, encrypted (ebay.dat); unreadable → set aside, receiver still starts | EbayDesk.SetupEbay | R (its own folder) | S |
| D7 | eBay list: order, buyer, total, status, message, colours; Retry, Start again in a new RO, Mark done by hand, Remove (each confirmed), Hide finished | EbayDesk | R + Job column; the new "needs manual completion" state | C, S |
| D8 | Retried once by itself 60 s after a stop that typed nothing (within 30 min, worker in touch and on) | RunsByItself.RetryOnce | R | S |
| D9 | Tray message when the worker has been out of touch 5 minutes | DeskRunsTick | R (tray) | C |
| D10 | Receiving on/off | DeskForm | R (Pause / Resume receiving, also in the tray) | S, E |
| D11 | Export the worker connection (worker-connection.json) | DeskForm.ExportWorker | R + Copy connection (text, for the Remote Desktop clipboard; taken off it after 2 minutes) | S, C |
| D12 | Start with Windows | DeskRunsRow | R ("Ebay-auto - Receiver.cmd"; 1.1.0: hidden, follows updates) | S, E (Launch.ps1 hand-over) |

## The worker (the RDP helper's eBay side → inside Seb's Remote Desktop session)

| ID | Feature | 2.9.10 | Ebay-auto | Checked |
|---|---|---|---|---|
| W1 | Long-poll to the receiver, declines, acknowledgements, the journal (ebay-journal.dat, encrypted; unreadable → set aside) | EbayEngine | W | S, E (protocol) |
| W2 | Exactly one COSTAR Branch 1 in this Windows session, never Order Check's window, looked for again every 3 s | EbayEngine.FindTarget, CostarWindows.Choices | W (same session only, as before). 1.1.0: any number of COSTARs; of several Sydney the earliest-started, kept while valid (N1) | S, L |
| W3 | Waits: another entry, the old online helper, COSTAR Sydney missing or two open, not on Work-in-Progress, someone using the PC (3 s) | EbayEngine.Available | W + waits while COSTAR Sydney doesn't answer or a COSTAR window blocks it (instead of taking the order and stopping). 1.1.0: two Sydney open no longer wait (N1); the chosen one unreadable for a moment waits | S, L |
| W4 | Refusals before COSTAR is touched: bad order, entered before (unless Start again), typed before but sent as new, typed on the desk's word with no record | EbayAttempts.Refusal | W (+ handed over counts as entered) | S |
| W5 | Attempts: fresh / reuse an empty RO / resume an unchanged RO / refuse; recorded before the receiver hears; restart finds a lost attempt and reports it | EbayAttempts.Decide, EbayEngine | W (+ a lost attempt with an unknown item is reported as handed over) | S |
| W6 | Add New only on Work-in-Progress, cover waited out 1.5 s, one press, 30 s for the RO, a new RO beside any already open | CostarWindows.OpenNew | W, unchanged | L |
| W7 | Startup checks, Ship to tab first, resume only in the same unchanged RO, blank checks, an earlier empty RO that changed → a new RO once | Runner.RunEbay | W, unchanged | L |
| W8 | Customer by phone: account kept, Customer Not found dismissed, two accounts → first, all-branch search, Notes/memo answered, popup recovery | Runner.Customer.cs, Runner.Popups.cs | W, unchanged | L |
| W9 | Header (PO# = eBay number, comment EBAY DFE), Ship to (buyer, DFE), identity checks | Runner.Customer.cs | W, unchanged | L |
| W10 | Rebill to EBAY + Card# (tab, layout, locked boxes, the RO it stopped in, rebill name, a window after EBAY) | Runner.Ebay.cs FillRebill | W, unchanged | L |
| W11 | Written By and Salesperson SA (not found / locked / not kept → CHECK BY HAND) | FillStaff | W, unchanged | L |
| W12 | Lines spaced as the example RO: items at the eBay price, F, M E per item, M BUY, M DFE; note key press; resumed lines checked | Runner.Ebay.cs, Runner.Grid.cs | W + unknown item: Quick Item Add cancelled, the rest entered where safe | S (rules), L |
| W13 | Final check: header, Ship to, staff, Terms 7INV (CHECK BY HAND), the lines exactly, total = eBay total | VerifyEbay | W unchanged for a complete order; an order handed over is never reported verified | S (rules), L |
| W14 | Close after entry (setting, on by default): out of the lines, PO# and total checked, WM_CLOSE, nothing answered, CHECK BY HAND if it stays | CloseEntered | W (never for an order handed over). 1.1.1: off by default; the same steps and checks, then left open on purpose, no WM_CLOSE (M1) | S (words, setting), L |
| W15 | Reports: in COSTAR (closed / left open), Notes, CHECK BY HAND; entered list and report in one write | EbayEngine.Run | W + "handed over" with the unresolved items | S, E |
| W16 | Stops: report with typed flag, stop print, attempt saved; Discord at once or after 3 min; Stop all (Ctrl+Alt+F10) | EbayEngine.Run, Alerts | W | S, C |
| W17 | Check Sydney layout (types nothing) | EbayEngine.CheckLayout | W | C, L |
| W18 | Start / Stop eBay orders (kept); Stop all pauses (not kept) | EbayTab, DesktopUi.StopAll | W (also in the tray) | C |
| W19 | Close each Repair Order once it's in (tick box) | EbayTab | W (1.1.1: unticked by default; an earlier installation's tick turned off once, M1) | S |
| W20 | Discord alerts: webhook set / test / off, encrypted, rate limits, masked words; receiver unreachable for 5 minutes | Alerts, RunsByItself | W | S |
| W21 | Import the connection (file, or worker-connection.json beside the launcher) | RunsByItself.ImportConnection, Launch.ps1 | W + Paste connection (text) | S |
| W22 | Diagnostics: run records, day log, Save diagnostics ZIP; full entry reports kept locally 30 days | Diagnostics.cs | W + the receiver's logs in the same ZIP when it can be reached | S, E |
| W23 | Direct presses and long poll settings | Files & settings | W | C |
| W24 | Start with Windows | RunsByItselfCard | W ("Ebay-auto - Worker.cmd"; 1.1.0: hidden, follows updates) | S, E (Launch.ps1 hand-over) |
| W25 | One helper types into COSTAR at a time in a Windows session (input lock) | CostarInputLock | W, the same lock as the Tempe helper (they never type at once in one session) | C |

## Not part of Ebay-auto (not eBay features)

Phone jobs, online orders, the phone's Repair Orders, Order Check, the wholesale dry run, the Job Card website, the
time-saved boss report and the Tempe updater stay in the Tempe helper. Their code is compiled into EbayAuto.exe (the eBay
engine shares it) but nothing in Ebay-auto starts or shows them.

## Added in 1.1.0

Checked: S = self-test, E = end-to-end here (extension + real receiver code; for updates: the real update code against
the real release files served over HTTP, Tests/update_replay.ps1), C = compiled and read, L = needs Windows / Remote
Desktop / COSTAR (not tested here).

| ID | Feature | Where | Checked |
|---|---|---|---|
| N1 | COSTAR Sydney chosen by itself: other branches never in the way; of several Sydney the earliest-started (process start time, not PID, window order or foreground), kept while valid; busy / unreadable / a window over it: wait, never switch; another branch only after two looks a second apart; closed or restarted (PID reused counts as new): the earliest-started remaining, for new orders only; none: wait | W: EbayAutoCostar.cs (SydneyChoice, Scan), EbayEngine.FindTarget / Available / Ready | S (made-up scans), L |
| N2 | A Retry of an order typed part-way goes back only into its own COSTAR process and Repair Order (refused, as before, when that COSTAR closed or restarted); an order being entered is never moved | W: EbayEngine.Accept, PinnedTarget, Run | C, L |
| N3 | The COSTARs seen, the choice and every change, in the journey (branch, PID, start time; never a title); the COSTAR in use in the worker's window | W | S, C |
| N4 | One-click update of each part from Ebay-auto's own GitHub folder: check (by itself a minute after start and every 6 h; Check for updates), versions shown (this, GitHub, the other part), Update now, progress, Cancel update, failures in words | R, W: EbayAutoUpdate.cs (EbayAutoUpdater), Updates tab, tray | S, E (download, checks, install), L (the window) |
| N5 | Never the Tempe helper's release: product, part, package names, folder, one top folder, every file, VERSION/PART, Ebay-auto's source, no Tempe launchers | EbayAutoUpdate.Validate / Install / Verify | S, E (the helper's latest.json and ZIP, re-wrapped, a changed byte, the other part's package: refused) |
| N6 | Built and self-tested on the PC before the switch; a failed build never switched to | EbayAutoUpdate.Build (Build.ps1 -ReportTo) | S (stubbed build), E (the report), L (csc on Windows) |
| N7 | The switch at a safe point only (no entry; new orders held on the receiver; the receiver keeps taking orders), state kept (receiving/paused, eBay on/paused, window), the same part restarted, the old version back by itself if the new one doesn't start | EbayAutoUpdater.Tick / Switch / Fail, EbayAutoProgram (--after-update, --restart-after), the forms' hooks | S (hold, wait, cancel, resume, failure records), E (receiver hold, worker updating), L (two programs switching on Windows) |
| N8 | Launchers and Start with Windows hand over to the newest installed version of the same part; one that can't build is set aside for the newest earlier one | Launch.ps1, AutoStart.Script | E (Launch.ps1 under PowerShell 7 with a stand-in for powershell.exe), S (the Startup file) |
| N9 | Mixed versions: version and protocol in every poll and reply; 1.0.0 (no number) = protocol 1; an unknown protocol takes or hands out nothing and both say which part to update | LocalHttp.cs EbayWorkerPoll, EbayEngine.Loop, Product.Protocol | S, E |
| N10 | Compact windows with tabs, sized for the screen and scaling (100–200 %), by the clock; a status line on top | EbayAutoTray.cs (EbayAutoLayout), the forms | S (sizes and places at 5 screens × 5 scalings), L |
| N11 | Start hidden; minimise (any way) and X hide completely (no taskbar button); double-click / Open restores (on screen); Exit safe; one icon; boxes open the window first; launch windows hidden | EbayAutoForm | C, L |
| N12 | Layout check per tab in the journey (anything that doesn't fit at this scaling and size) | EbayAutoForm.CheckLayout | S (the rule), L |

## Changed in 1.1.1

| ID | Feature | Where | Checked |
|---|---|---|---|
| M1 | Each order entered and verified is left open for Seb to check and close: every step and check before the close as before (out of the item lines, PO# and total checked again), no WM_CLOSE; reported "ez, next" (the eBay page: "In COSTAR Sydney ✓ ez, next"); the job released at once, the next order in its own new Repair Order; not a warning or NEEDS YOU (verified, completed without help; no balloon, no Discord, no close-by-hand note); CHECK BY HAND and NEEDS YOU as before | W: Runner.Ebay.cs CloseEntered(total, close: false), EbayFinish.Words, EbayEngine.Run; R: EbayDiag.Outcome | S (words, receiver, counts; mutation-checked), E (V11), L (COSTAR) |
| M2 | "Close each Repair Order once it's in" off by default; an earlier installation's tick turned off once on the first start of 1.1.1 (recorded; ticked again later: kept) | AppSettings.ebayClose / ebayLeaveOpenFrom, EbayFinish.LeaveOpenOnce, the worker window | S (mutation-checked) |
| M3 | Diagnostics: verified and left open on purpose (journey, run record `ebay_left_open`, review.json LeftOpen), each one's closing by hand noticed every 30 s (`left_open_ro_closed`, how long it was open), the worker's diagnostics listing them | EbayEngine.CheckHeld / JournalSummary, Runner.Ebay.cs | S (journal), C, L |

## Added in 1.1.2

The same code as the Tempe helper 2.9.11's (Tommy, 17 Nov 15:18 and 15:25).

| ID | Feature | Where | Checked |
|---|---|---|---|
| A1 | A new buyer's COSTAR customer account: after Customer Not found alone, with Account# blank and every detail COSTAR's form asks for (a name of two words or more, street, suburb, state, postcode, a phone of 8 digits): X checked against the order, the magnifier beside X's Account#, Add new, COSTAR's new-customer form read box by box and checked (every word of the name in Last and First, address, city, state, postcode, the phone, a personal service file), COSTAR's defaults untouched, nobody using the session, OK once per order | NewAccount.cs, Runner.NewAccount.cs, Selectors.AccountLookup, Runner.Ebay.cs | S (mutation-checked, the 17 Nov maps' geometry), C, L |
| A2 | After OK: made only with the form gone, nothing over the order, the order in front and free, Account# a number at two looks, the same name's words and phone; then X again (COSTAR's number and name kept, the rest put back) and Ship to with the order's own delivery details | NewAccount.Uncertain, Runner.NewAccount.cs AfterOk, FillOnlineHeader(true,false) | S (mutation-checked), C, L |
| A3 | No account and the order goes on as before: a detail missing, the tick off, direct presses off, X not the order's, no magnifier, a COSTAR window open, the form unfamiliar or not the order's, someone using the session (Cancel, back to the Repair Order) | NewAccount.Decide / PanelProblems / FormProblems, CancelBack | S (mutation-checked), L |
| A4 | Unsure after OK: stopped, nothing more pressed, never again for that order (`new-accounts.dat`: part of a SHA-256, the state, a year); Retry: compared without Account#, the name's word order and Ship to, an account kept, a blank Account# read twice (CHECK BY HAND), a COSTAR window over the order left for Seb; Start again: the lookup's own path, no account if Customer Not found again | NewAccountLog, NewAccount.SamePrint, Selectors.OrderPrint(loose), SteadyAccount, AccountLeftUnsure | S (mutation-checked), C, L |
| A5 | COSTAR's new-customer form never taken for a list of accounts; nothing else answers or cancels the step's windows | OrderModel.cs AccountChooser, the guards in Runner.cs, Runner.Popups.cs, Runner.Customer.cs | S (mutation-checked), C |
| A6 | The tick (worker, Settings tab; on by default, also after the update), its journey note, diagnostics (`new_account` events, review.json `NewAccount`) | EbayAutoWorker.cs, AppSettings.newAccounts | S (mutation-checked), C |

## Added in 1.1.3

The same code as the Tempe helper 2.9.12's (Tommy, 18 Nov 00:44).

| ID | Feature | Where | Checked |
|---|---|---|---|
| A7 | The new buyer's account state: the one written in the address first (code or full name, any case, extra spaces or dots), never replaced; none written: looked up by suburb AND postcode in the address list (Australia Post's localities and postcodes as compiled by Matthew Proctor, 6 Sep 2025), used only when that suburb under that postcode is in one state; never from the postcode alone, the store or COSTAR's default; none: no account, the order goes on; where it came from (or why none) in the diagnostics | AuStates.cs (AuState, AuPlaces), AuPlaceData.cs, Runner.NewAccount.cs MaybeMakeAccount | S (mutation-checked), C, L |

## Added in 1.1.4

The same code as the Tempe helper 2.9.13's (Tommy, 18 Nov 02:20), with the 404 extension 1.5.1.

| ID | Feature | Where | Checked |
|---|---|---|---|
| A8 | An eBay order whose address has no state: sent by the extension 1.5.1 (a state that isn't one of the eight, or no suburb or postcode, still stops it on the page); its state looked up by suburb AND postcode before the receiver's check, the worker's check and the entry (customer panel and Ship to), used only when they are in one state, never from the postcode alone, the store or COSTAR's default; the order kept as sent (its content hash unchanged: a second Send is the same order); not found: refused before it is queued, the eBay page saying why; where the state came from in the journey (`received`, `claim_received`), the run's details (`billingState`, `deliveryState`), `address_states` and review.json, and the account step's `NewAccountState` | costar_send.js build(), EbayModel.cs (EbayOrder.AddressState, Validate, EngineOrder), EbayAutoDiagnostics.cs (EbayDiag.Shape), Runner.NewAccount.cs (NoteAddressStates), NewAccount.AccountState | S (mutation-checked), E, L |

## Fixed in 1.1.5

The same code as the Tempe helper 2.9.14's (its diagnostics of 18 Nov 08:36).

| ID | Feature | Where | Checked |
|---|---|---|---|
| A9 | The account step's own windows looked at once COSTAR has drawn them: COSTAR's customer search and its new-customer form looked at again every 0.15 s until recognised (10 s at most); left for Seb only when unchanged for 1.5 s without being recognised, or not recognised in 10 s; never pressed on unless recognised; when each was known (looks, time, controls) in the `new_account` events | NewAccount.cs (WindowLooks), Runner.NewAccount.cs (Complete) | S (mutation-checked), C, L |

## Added in 1.1.6 and 1.1.7

Ebay-auto only (Tommy, 18 Nov 10:13; 1.1.7: 12:09 and 12:12); the Tempe helper is unchanged. 1.1.6 was never uploaded.

| ID | Feature | Where | Checked |
|---|---|---|---|
| A10 | Once an order is entered and verified and its Repair Order left open: the number in the box at the top of that order's own Repair Order (the read-only box beside its one "RepairOrder" label, as in every map) read at two looks 0.3 s apart, each with the order's PO#; a number already there kept as COSTAR shows it; copied to the clipboard as the number, one space and DFE (Unicode text only: no label, no line break) and read back (3 tries), before "ez, next" and the job's release; the next order in its own new Repair Order as before | EbayRoNumber.cs (RoNumber.Look, Judge, Text; RoClipboard), Runner.EbayAuto.cs (CopyRoNumber), Runner.Ebay.cs, EbayWorker.cs | S (mutation-checked, the maps' geometry), C, L |
| A11 | Never copied: no number yet, unreadable, changed between the looks, not 8 digits (0-9), not shown with this order's PO#, not COSTAR's read-only number box, a number copied before (the last 200 kept in the worker's journal), a clipboard not set and read back in 3 tries; then CHECK BY HAND for Seb saying why and what to do (no number yet: press Next #, then copy it), the previous order's text taken off the clipboard only while it still holds exactly that; never stopped, retried or entered again for it | RoNumber.Judge / Words / Earlier / LastText / Keep, RoClipboard.CopyChecked / StillThere / ClearIfStill, EbayWorker.cs | S (mutation-checked), C, L |
| A12 | 1.1.7: a blank box at both looks: Next # (the button right beside the box, COSTAR's words "Ne&xt #", enabled, inside this order's Repair Order, that Repair Order in front with no COSTAR window over it) pressed ONCE (direct press), the box read every 0.15 s until the number shows (10 s at most; a COSTAR window over the Repair Order ends the wait, never answered), then read twice more and copied as A10; never pressed twice; not pressed, or no number: CHECK BY HAND | RoNumber.NextBeside / IsNextWords / WaitForNumber, Runner.EbayAuto.cs (PressNextOnce, NumberBlocked) | S (the wait mutation-checked), C, L |
| A13 | Diagnostics: `ro_number`, `ro_number_next` (1.1.7), `ro_number_copy`, `ro_number_clear` events, the run's `roNumber` and `roNumberShape`, counts by reason in the worker's summary, the journey's "completed" line, review.json; the number's shape only (never its digits); the number itself in the worker's window and its entry report only | Runner.EbayAuto.cs, EbayAutoDiagnostics.cs (RoNumberCounts), EbayWorker.cs | S, C |
