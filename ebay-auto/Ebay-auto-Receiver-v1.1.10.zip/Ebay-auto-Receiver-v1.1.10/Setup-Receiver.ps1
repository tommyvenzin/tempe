param([string]$Address = '', [int]$Port = 8811)
# Ebay-auto 1.0.0, Seb's physical PC (once, and again if this PC's LAN address changes): builds Ebay-auto, picks this PC's
# LAN address, makes the receiver's own certificate (trusted for this Windows user only), opens the receiver's two ports
# to the shop network in Windows Firewall (asks for an administrator's OK), and sets the receiver up. Run Setup-Receiver.cmd.
$ErrorActionPreference = 'Stop'
try {
    if ($Port -lt 1024 -or $Port -gt 65534) { throw 'The port must be 1024 to 65534 (the next one is the certificate port).' }
    $trustPort = $Port + 1
    foreach ($p in @($Port, $trustPort)) { if ($p -eq 8790 -or $p -eq 8791 -or ($p -ge 8795 -and $p -le 8804)) { throw ('Port ' + $p + ' belongs to the Tempe helper: choose another with -Port (8811 is Ebay-auto''s own).') } }
    $runtime = & (Join-Path $PSScriptRoot 'Build.ps1') -PassThru
    if (!$runtime -or !(Test-Path -LiteralPath $runtime.Executable)) { throw 'Build did not provide an executable path.' }
    # This PC's private LAN IPv4 address: the worker inside Remote Desktop reaches the receiver there (never 127.0.0.1:
    # inside Remote Desktop that is the Remote Desktop server itself).
    if ($Address) { $ip = $Address } else {
        $addresses = @(Get-NetIPAddress -AddressFamily IPv4 | Where-Object {
            $_.AddressState -eq 'Preferred' -and ($_.IPAddress -match '^10\.' -or $_.IPAddress -match '^192\.168\.' -or $_.IPAddress -match '^172\.(1[6-9]|2[0-9]|3[01])\.')
        } | Sort-Object InterfaceIndex,IPAddress)
        if ($addresses.Count -eq 0) { throw 'No private LAN IPv4 address found. Connect this PC to the shop network (the same network the Remote Desktop server can reach).' }
        if ($addresses.Count -eq 1) { $ip = $addresses[0].IPAddress } else {
            for ($i=0; $i -lt $addresses.Count; $i++) { Write-Host ("{0}: {1}  {2}" -f ($i+1),$addresses[$i].IPAddress,$addresses[$i].InterfaceAlias) }
            $selection = Read-Host 'Choose the number of the shop network (Ethernet/Wi-Fi) address'
            $number = 0
            if (![int]::TryParse($selection,[ref]$number) -or $number -lt 1 -or $number -gt $addresses.Count) { throw 'Invalid address selection.' }
            $ip = $addresses[$number-1].IPAddress
        }
    }
    # The ports must be free (or held by Ebay-auto's own receiver, which is restarted below).
    foreach ($p in @($Port, $trustPort)) {
        $holders = @(Get-NetTCPConnection -State Listen -LocalPort $p -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)
        foreach ($holder in $holders) {
            $name = (Get-Process -Id $holder -ErrorAction SilentlyContinue).ProcessName
            if ($name -ne 'EbayAuto') { throw ('Port ' + $p + ' is used by another program (' + $name + '). Run Setup-Receiver.cmd with another port, e.g. powershell -File Setup-Receiver.ps1 -Port 8821') }
        }
    }
    $running = @(Get-Process -Name 'EbayAuto' -ErrorAction SilentlyContinue)
    if ($running.Count -gt 0) {
        Write-Host 'Ebay-auto is running on this PC: Exit it first (its icon in the notification area, right-click, Exit), then press Enter here.' -ForegroundColor Yellow
        Read-Host | Out-Null
        if (@(Get-Process -Name 'EbayAuto' -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Ebay-auto is still running. Exit it (tray icon, Exit) and run Setup-Receiver.cmd again.' }
    }
    $folder = Join-Path $env:LOCALAPPDATA 'EbayAuto\receiver'
    [IO.Directory]::CreateDirectory($folder) | Out-Null
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $root = New-SelfSignedCertificate -Type Custom -Subject ('CN=Ebay-auto Receiver Root ' + $stamp) -KeyAlgorithm RSA -KeyLength 2048 -HashAlgorithm SHA256 -KeyExportPolicy NonExportable -KeyUsage CertSign,CRLSign -TextExtension @('2.5.29.19={critical}{text}ca=1&pathlength=1') -CertStoreLocation 'Cert:\CurrentUser\My' -NotAfter (Get-Date).AddYears(3)
    $leaf = New-SelfSignedCertificate -Type Custom -Subject ('CN=' + $ip) -Signer $root -KeyAlgorithm RSA -KeyLength 2048 -HashAlgorithm SHA256 -KeyExportPolicy NonExportable -KeyUsage DigitalSignature,KeyEncipherment -TextExtension @(('2.5.29.17={text}IPAddress=' + $ip),'2.5.29.37={text}1.3.6.1.5.5.7.3.1','2.5.29.19={critical}{text}ca=0') -CertStoreLocation 'Cert:\CurrentUser\My' -NotAfter (Get-Date).AddDays(825)
    $public = Join-Path $folder 'Ebay-auto-Root.cer'
    Export-Certificate -Cert $root -FilePath $public -Force | Out-Null
    Write-Host 'Windows now asks whether to install the certificate "Ebay-auto Receiver Root": click Yes (Chrome on this PC then trusts the receiver).' -ForegroundColor Yellow
    # Trusted for this Windows user only: Chrome on this PC can then reach the receiver over HTTPS.
    Import-Certificate -FilePath $public -CertStoreLocation 'Cert:\CurrentUser\Root' | Out-Null
    # Windows Firewall: the receiver's two ports, from private (shop network) addresses only. Needs an administrator's OK.
    $rule = 'Ebay-auto receiver (TCP ' + $Port + '-' + $trustPort + ')'
    $exists = @(Get-NetFirewallRule -DisplayName $rule -ErrorAction SilentlyContinue).Count -gt 0
    if (-not $exists) {
        $command = "New-NetFirewallRule -DisplayName '$rule' -Direction Inbound -Action Allow -Protocol TCP -LocalPort $Port,$trustPort -Profile Domain,Private -RemoteAddress 10.0.0.0/8,172.16.0.0/12,192.168.0.0/16 | Out-Null"
        $admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        try {
            if ($admin) { Invoke-Expression $command }
            else {
                Write-Host 'Windows now asks for an administrator''s OK to open the receiver''s ports in Windows Firewall (shop network only).' -ForegroundColor Yellow
                $elevated = Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-Command',$command) -PassThru -Wait
                if ($elevated.ExitCode -ne 0) { throw 'not allowed' }
            }
            $exists = @(Get-NetFirewallRule -DisplayName $rule -ErrorAction SilentlyContinue).Count -gt 0
        } catch { $exists = $false }
        if (-not $exists) { Write-Host ('The firewall rule was not added. Ask IT to allow inbound TCP ' + $Port + ' and ' + $trustPort + ' to this PC from the shop network (the Remote Desktop server must reach it), or run Setup-Receiver.cmd again as an administrator.') -ForegroundColor Yellow }
    }
    $exe = $runtime.Executable
    $init = Start-Process -FilePath $exe -WorkingDirectory $runtime.Bin -ArgumentList @('--init-receiver',$ip,$Port,$leaf.Thumbprint,('"'+$public+'"')) -PassThru -Wait
    if ($init.ExitCode -ne 0) { throw 'The receiver setup did not finish.' }
    $category = (Get-NetConnectionProfile -ErrorAction SilentlyContinue | Where-Object { $_.IPv4Connectivity -ne 'Disconnected' } | Select-Object -First 1).NetworkCategory
    Write-Host ''
    Write-Host ('Ebay-auto receiver set up on https://' + $ip + ':' + $Port + ' (certificate download on ' + $trustPort + ').') -ForegroundColor Green
    if ($category -eq 'Public') { Write-Host 'Windows calls this network Public: the firewall rule only opens the ports on Private (or Domain) networks. Set this network to Private (Settings, Network, its Properties) or ask IT.' -ForegroundColor Yellow }
    Write-Host 'Next: in the receiver window, click Pair eBay PC and pair the 404 extension (address and PIN), then Copy connection and paste it into the worker inside Remote Desktop.'
    $env:EBAYAUTO_PACKAGE = (Resolve-Path -LiteralPath $PSScriptRoot).Path
    Start-Process -FilePath $exe -WorkingDirectory $runtime.Bin -ArgumentList @('--receiver','--show')
} catch { Write-Host $_.Exception.ToString() -ForegroundColor Red; exit 1 }
