# Ebay-auto 1.1.10 - 24 November 2026

Receiver and worker 1.1.10, with 404 extension 1.6.1. This update keeps customer lookup on Contact info and fixes the stop when COSTAR puts that number in Home Ph or Bus Ph.

## Patch notes

- **Contact info is the customer phone.** The helper no longer tries Ship to's phone to find an account. If no account is found, it fills known billing details and uses the existing guarded new-account step with the same Contact info phone. Billing name comes from Order/Buyer; the address comes from Ship to.
- **Home and business numbers count.** The Contact number may match billing X's Mobile Ph, Home Ph or Bus Ph. Mobile being blank does not stop the order. COSTAR's phone placement is kept; unrelated phone numbers still fail verification. Diagnostics record which field matched without its phone value.
- **Delivery stays separate.** Y keeps the Ship to name, phone and delivery address.
- **Missing details do not throw away the order.** Known customer names and address fields are entered and verified. Incomplete account creation is skipped, and the open Repair Order is marked CHECK BY HAND with what is missing. The extension shows missing details before sending. Missing data is not invented or reported as verified.
- **Old partial orders stay protected.** A partial order that previously used a different Ship to phone must be finished manually. It is never silently moved to a different customer account. Completed orders are untouched.

A readable Contact info phone is still required. Supplied-invalid values, item/price/total checks, branch confirmation, duplicate protection and uncertain-popup stops remain enforced.

## Install this update

1. Finish any active entry and pause order processing while updating.
2. Click **Update now** on the receiver on Seb's PC and the worker inside Remote Desktop. Confirm **1.1.10 on both** before resuming. Protocol 2 remains compatible with 1.1.9, so updating only the receiver does not change the old worker's phone behaviour.
3. Extract `404-but-its-found-1.6.1.zip` into the existing unpacked extension folder, replacing its files. In `chrome://extensions`, click Reload on **404 But It's Found**. Keep the same folder so its identity and pairing are retained.
4. Refresh the eBay order page, then resume processing. Keep the required Sydney (Br1) and/or Tempe (Br11) COSTAR windows open inside Remote Desktop.

Settings, pairing, queued orders and completion history keep their existing storage. No re-pairing or fresh setup is required for an existing installation. The updater does not change the separately installed Tempe helper.

## Existing behaviour retained

- Sydney and Tempe buttons, with wheel/wheels/package/packages suggesting Tempe and confirmation for the other choice. Mixed orders stay together; package SKUs are not trimmed.
- One order at a time, the first-opened valid COSTAR instance for each branch, and each new order starting its own Repair Order with Add New.
- Uppercase unit/slash address formatting and the wheel-only numeric SKU suffix fix.
- Rebill EBAY, Card#, Terms 7INV, Ship Via DFE, staff SA/SA, original quantities/prices, product/freight/message lines and final verification.
- Stock above 2 continues; 0-2 requires typed `ok` or `check`; negative stock requires `yes`. `check` adds `low stock - currently checking`. Unknown-SKU hand-over is unchanged.
- Successfully verified Repair Orders stay open for manual checking, with `ez, next`. A blank Repair Order number gets Next #, then `<number> DFE` is copied to the clipboard. Orders needing checks remain open with CHECK BY HAND.
- Tray icons, one-click GitHub updates, diagnostics and duplicate/retry protection.

## Validation

See `VALIDATION.md` and `package-checks-1.1.10.txt` for exact test and packaging results. These new behaviours have not been exercised in live COSTAR. Watch the first Contact-only new customer, an existing account with Home/Bus populated and Mobile blank, and an incomplete-details order.

The browser integration suite could not start isolated Chrome in this environment. Its launcher now records the crash output rather than silently timing out. This is recorded as an uncompleted check, not a pass.

## Bundle contents

- Receiver ZIP for Seb's PC and worker ZIP for Remote Desktop.
- `404-but-its-found-1.6.1.zip` for Chrome.
- Source backup including tests and validation reports.
- GitHub upload ZIP containing only the `ebay-auto` release files.

Full release history is in the packages' `CHANGES.md`. Earlier published ZIPs are kept unchanged.

## Local development

`Tests/run-local.ps1` compiles and tests without typing into COSTAR. `node Tests/package-release.cjs` builds and verifies both packages, including isolated installer builds and replay through the published 1.1.9 updater. Templates come from the existing 1.1.9 package folders. Packaging itself does not publish or install the live apps.
