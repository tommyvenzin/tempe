// Made-up COSTAR panels only. No process lookup, window reads, account creation or UI input.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;

namespace TempeCostar {
    internal static class EbayCustomerPhoneTests {
        const string ST="WindowsForms10.STATIC.app.0.1",ED="WindowsForms10.EDIT.app.0.1";
        const string Phone="0400000001",Other="0400000002";
        static void Check(bool yes,string message) { if(!yes) throw new InvalidOperationException(message); }
        static ControlInfo Mk(long h,long parent,string cls,int x,int y,int w,int height,string text) {
            return EbayTests.Mk(h,parent,cls,x,y,w,height,text);
        }
        static List<ControlInfo> Screen(string mobile,string home,string business) {
            var s=EbayTests.Grid(new Dictionary<int,string[]>());
            s.Add(Mk(9001,100,ST,37,111,285,17,"Account#                        Name"));
            s.Add(Mk(2,100,ED,37,128,122,20,"1234567"));s.Add(Mk(3,100,ED,158,128,226,20,"QUINN TESTBUYER"));
            s.Add(Mk(4,100,ED,37,147,347,20,"7 MADEUP ROAD"));s.Add(Mk(5,100,ED,37,166,347,20,""));
            s.Add(Mk(6,100,ED,37,185,208,20,"TESTVILLE"));s.Add(Mk(7,100,ED,244,185,56,20,"NSW"));s.Add(Mk(8,100,ED,299,185,85,20,"2799"));
            s.Add(Mk(11,100,ST,37,250,148,15,"eMail"));s.Add(Mk(12,100,ST,184,250,100,15,"Mobile Ph"));
            s.Add(Mk(13,100,ED,37,265,148,20,""));s.Add(Mk(14,100,ED,184,265,100,20,mobile));
            s.Add(Mk(15,100,ST,274,295,109,15,"PO#"));s.Add(Mk(16,100,ED,274,310,109,20,"12-34567-89012"));
            s.Add(Mk(17,1000,ST,706,85,51,13,"Comment"));s.Add(Mk(18,1000,ED,782,82,265,20,"EBAY DFE"));
            s.Add(Mk(30,100,ST,37,210,120,15,"Home Ph"));s.Add(Mk(31,100,ED,37,225,120,20,home));
            s.Add(Mk(32,100,ST,184,210,120,15,"Bus Ph"));s.Add(Mk(33,100,ED,184,225,120,20,business));
            // Same labels in Y must never be selected as the billing phone.
            s.Add(Mk(40,201,ST,600,210,120,15,"Home Ph"));s.Add(Mk(41,201,ED,600,225,120,20,Phone));
            s.Add(Mk(42,201,ST,746,210,120,15,"Bus Ph"));s.Add(Mk(43,201,ED,746,225,120,20,Phone));
            s.Add(Mk(50,1000,ST,1000,1300,100,17,"TAX IN"));s.Add(Mk(51,1000,ST,1000,1317,100,17,"0.00"));
            return s;
        }
        internal static void Cases(Action<string,Action> Case) {
            Case("eBay billing phone: Home or Business matches with Mobile blank; no fields changed",()=>{
                foreach(bool home in new[]{true,false}) {
                    var s=Screen("",home?Phone:"",home?"":Phone);var h=Selectors.Header(s);
                    string before=String.Join("|",s.Select(c=>c.Text));
                    Check(EbayCustomerPhone.Value(h,Phone)==Phone,"A matched non-mobile phone was rejected.");
                    Check(CustomerEntry.LookupResolved(h.Account.Value,h.Name.Value,EbayCustomerPhone.Value(h,Phone),Phone),"Lookup still rejected the matched account.");
                    Check(EbayCustomerPhone.FieldName(h,Phone)==(home?"Home Ph":"Bus Ph"),"Diagnostic field source is incorrect.");
                    Check(EbayCustomerPhone.MatchedFields(h,Phone)==(home?"Home Ph":"Bus Ph"),"Diagnostic exposes numbers or the wrong field.");
                    Check(before==String.Join("|",s.Select(c=>c.Text))&&h.Phone.Value=="","Matching modified COSTAR's phone classification.");
                }
            });
            Case("eBay billing phone: unrelated Mobile is preserved when Contact matches Home",()=>{
                var h=Selectors.Header(Screen(Other,"+61 400 000 001",""));
                Check(EbayCustomerPhone.Value(h,Phone)==Phone&&h.Phone.Value==Other,"The existing Mobile was used or overwritten.");
                Check(EbayCustomerPhone.Match("+61 400 000 001","",Phone,"")==Phone,"International Contact formatting was not normalised.");
                h.Phone.Text=Phone;h.BusinessPhone.Text=Phone;
                Check(EbayCustomerPhone.MatchedFields(h,Phone)=="Mobile Ph, Home Ph, Bus Ph","Multiple matching fields were not recorded without phone values.");
            });
            Case("eBay billing phone: delivery-only, unrelated and ambiguous X numbers do not match",()=>{
                var s=Screen("",Other,Other);var h=Selectors.Header(s);
                Check(!EbayCustomerPhone.Matches(h,Phone),"Y's matching delivery number was accepted as X's customer.");
                s.RemoveAll(c=>c.Handle==30||c.Handle==31||c.Handle==32||c.Handle==33);
                Check(!EbayCustomerPhone.Matches(Selectors.Header(s),Phone),"Missing X labels borrowed Y's phone.");
                var ambiguous=Screen("",Phone,"");ambiguous.Add(Mk(35,100,ST,37,210,120,15,"Home Ph"));
                Check(!EbayCustomerPhone.Matches(Selectors.Header(ambiguous),Phone),"An ambiguous Home label was accepted.");
                Check(EbayCustomerPhone.Match("123","123","123","123")=="","A short or absent requested number became a match.");
            });
            Case("eBay billing phone: account and name guards remain strict across alternate fields",()=>{
                var h=Selectors.Header(Screen("","",Phone));string phone=EbayCustomerPhone.Value(h,Phone);
                Check(CustomerEntry.SameIdentity(h.Account.Value,h.Name.Value,phone,"1234567","QUINN TESTBUYER",Phone),"The correct customer was refused.");
                Check(!CustomerEntry.SameIdentity(h.Account.Value,h.Name.Value,phone,"7654321","QUINN TESTBUYER",Phone),"A different account was accepted.");
                Check(!CustomerEntry.SameIdentity(h.Account.Value,h.Name.Value,phone,"1234567","OTHER BUYER",Phone),"A changed name was accepted.");
                Check(!CustomerEntry.HasMatch(h.Account.Value,h.Name.Value,h.Phone.Value,Phone),"Non-eBay Mobile-only matching was weakened.");
            });
            Case("eBay billing phone: live guard rechecks all three controls rather than cached text",()=>{
                var h=Selectors.Header(Screen("",Phone,""));var read=new List<long>();
                Check(EbayCustomerPhone.Read(h,Phone,c=>{read.Add(c.Handle);return c.Value;})==Phone,"Live Home match was missed.");
                Check(read.SequenceEqual(new[]{h.Phone.Handle,h.HomePhone.Handle,h.BusinessPhone.Handle}),"The guard skipped a live phone field.");
                Check(EbayCustomerPhone.Read(h,Phone,c=>c==h.HomePhone?Other:c.Value)=="","The guard trusted stale matching Home text.");
                string before=EbayCustomerPhone.Signature(h);h.BusinessPhone.Text=Other;
                Check(EbayCustomerPhone.Signature(h)!=before,"Changes to Business were omitted from the stable-read signature.");
            });
            Case("eBay billing phone: cached header retains and refreshes Home and Business",()=>{
                var h=Selectors.Header(Screen("",Phone,""));
                var fields=(ControlInfo[])typeof(Runner).GetMethod("Fields",BindingFlags.Static|BindingFlags.NonPublic).Invoke(null,new object[]{h});
                Check(fields.Contains(h.HomePhone)&&fields.Contains(h.BusinessPhone),"Header validity checks omit alternate phones.");
                // Only the cache-copy function is exercised; this object never runs or accesses Windows.
                var runner=(Runner)FormatterServices.GetUninitializedObject(typeof(Runner));
                var live=new Dictionary<long,string>{{h.Phone.Handle,""},{h.HomePhone.Handle,Other},{h.BusinessPhone.Handle,Phone}};
                Action<ControlInfo> refresh=c=>{c.Text=live[c.Handle];c.TextState="read";};
                typeof(Runner).GetField("liveRead",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(runner,refresh);
                var cached=(FieldMap)typeof(Runner).GetMethod("LiveHeader",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(runner,new object[]{h});
                Check(cached.HomePhone!=h.HomePhone&&cached.BusinessPhone!=h.BusinessPhone,"The cache reused old phone snapshots.");
                Check(EbayCustomerPhone.Value(cached,Phone)==Phone&&cached.HomePhone.Value==Other,"The cache did not read the moved matching number live.");
            });
            Case("eBay billing phone: retry predicates accept X alternate fields only when requested",()=>{
                var s=Screen("",Phone,"");var order=EbayTests.Sample().EngineOrder();order.orderId="12-34567-89012";order.comment="EBAY DFE";order.customer.phone=Phone;
                Check(Selectors.SameOrderInProgress(s,order,true),"The eBay partial order was rejected because Mobile is blank.");
                Check(!Selectors.SameOrderInProgress(s,order),"Other workflows changed their retry phone rule.");
                s.First(c=>c.Handle==16).Text="";
                Check(Selectors.SameCustomerStart(s,order,true),"The eBay customer-only stop could not resume.");
                Check(!Selectors.SameCustomerStart(s,order),"Other workflows changed their customer-start rule.");
                s.First(c=>c.Handle==31).Text=Other;
                Check(!Selectors.SameCustomerStart(s,order,true),"A changed X phone was accepted on retry.");
            });
            Case("eBay billing phone: account creation confirmation accepts COSTAR's alternate field",()=>{
                var h=Selectors.Header(Screen("","",Phone));
                var look=new AfterOkLook {AccountBefore="",Account="1234567",AccountAgain="1234567",NameBefore="QUINN TESTBUYER",Name="QUINN TESTBUYER",OrderPhone=Phone,Phone=EbayCustomerPhone.Value(h,Phone),OrderFront=true,OrderEnabled=true};
                Check(NewAccount.Uncertain(look)==null,"A created account was marked uncertain solely because its Mobile is blank.");
                h.BusinessPhone.Text=Other;look.Phone=EbayCustomerPhone.Value(h,Phone);
                Check(NewAccount.Uncertain(look)!=null,"A created account with a different phone was accepted.");
            });
        }
    }
}
