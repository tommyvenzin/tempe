// eBay orders (2.5.0). The eBay PC's "404 But It's Found" extension sends an order to the desk
// receiver (HTTPS on the shop network, its own pairing key); the RDP helper takes it from there
// and enters it into a NEW Repair Order in the Sydney COSTAR (Branch 1), left open for review.
// Ebay-auto 1.1.9 (20 Nov 2026): each order names its branch, COSTAR Sydney (Br1) or COSTAR Tempe (Br11), chosen by Seb's
// button on the eBay page (schema tempe.ebay-order.v3; a suggestion from the item titles, EbayBranch). Both go through the
// same receiver and the same worker in Seb's Remote Desktop session. A stored 1.1.8 order (v2) is Sydney, never reclassified.
// This file: the order as sent, the plan of COSTAR lines, the desk's eBay queue and its wire types.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace TempeCostar {
    public sealed class EbayBuyer { public string name, phone, email, username; }
    public sealed class EbayPhones { public string contact, shipping; }
    // Saved before each lookup, then once it finishes. No customer phone numbers in the journal.
    public sealed class EbayPhoneState { public string phase; public bool complete, noticeOnly; }
    internal static class EbayPhoneChoice {
        internal const string Contact="contact",Shipping="ship-to",ContactFinal="contact-final";
        internal static string Normalize(string value) {
            string p=Order.Phone(value);
            return p.Length==11&&p.StartsWith("61",StringComparison.Ordinal)?"0"+p.Substring(2):p;
        }
        internal static string Phone(EbayPhones phones,string phase) {
            Order.Require(phase==Contact||phase==Shipping||phase==ContactFinal,"The saved eBay phone lookup step is unknown; check the stopped order by hand.");
            Order.Require(phones!=null,"The eBay Contact info phone is missing.");
            // A partial order previously matched through Ship to belongs to that old account. Never silently
            // relabel it as a Contact-info match or clear its account to run a new lookup.
            Order.Require(phase!=Shipping||Normalize(phones.shipping)==Normalize(phones.contact),
                "This stopped order previously used a different Ship to phone. Finish its existing Repair Order by hand; the helper now uses Contact info only and will not switch its customer account.");
            string value=Normalize(phones.contact);
            Order.Require(value.Length>=8,"The saved eBay phone lookup has no phone number.");
            return value;
        }
        // Contact info only. No match continues to the existing guarded new-account step; Ship to is delivery only.
        internal static bool Run(EbayPhones phones,string phase,Func<string,string,bool> lookup) {
            return lookup(Contact,Phone(phones,phase));
        }
    }
    public sealed class EbayAddress { public string recipientName, street, street2, suburb, state, postcode; }
    public sealed class EbayItem { public string sku, itemId, title; public int quantity, unitCents; }
    // Ebay-auto 1.1.9 (20 Nov 2026): the two branches an eBay order can go into, and the suggestion the item titles give.
    // Routing rule (the same in the 404 extension's costar_send.js): a title matches when it has the whole word wheel,
    // wheels, package or packages (any case; not next to an ASCII letter or digit). Only each item's OWN title counts.
    // titlesRead: every item has a title. Suggested: Tempe (Br11) when any title matches (a mixed order stays one order),
    // else Sydney (Br1); 0 when the titles weren't all read. Seb still chooses by button. This is separate from the wheel
    // SKU cleanup (costarSku): a package qualifies for Tempe, but its SKU is never trimmed.
    internal static class EbayBranch {
        internal const int Sydney=1,Tempe=11;
        internal static bool Known(int b) { return b==Sydney||b==Tempe; }
        internal static string Place(int b) { return b==Sydney?"Sydney":b==Tempe?"Tempe":"Branch "+b.ToString(CultureInfo.InvariantCulture); }
        internal static string Name(int b) { return Known(b)?Place(b)+" (Br"+b.ToString(CultureInfo.InvariantCulture)+")":Place(b); }
        internal static string Costar(int b) { return "COSTAR "+Name(b); }
        static readonly Regex Words=new Regex(@"(?<![A-Za-z0-9])(wheels?|packages?)(?![A-Za-z0-9])",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant);
        // word: the first matching word, lowercased (null: none).
        internal static bool TitleMatches(string title,out string word) {
            var m=Words.Match(title??"");word=m.Success?m.Groups[1].Value.ToLowerInvariant():null;return m.Success;
        }
        // Every matching word of a title, lowercased, in order, each once.
        internal static List<string> TitleWords(string title) {
            var found=new List<string>();
            foreach(Match m in Words.Matches(title??"")) { string w=m.Groups[1].Value.ToLowerInvariant();if(!found.Contains(w)) found.Add(w); }
            return found;
        }
        // matched: every matching word of every title that was read (lowercased, each once, in order), also when another
        // title wasn't read (as costar_send.js suggest() lists them; the suggestion is then 0 all the same).
        internal static int Suggest(IList<EbayItem> items,out bool titlesRead,out List<string> matched) {
            matched=new List<string>();
            titlesRead=items!=null&&items.Count>0&&items.All(i=>i!=null&&!String.IsNullOrWhiteSpace(i.title));
            if(items!=null) foreach(var i in items) if(i!=null) foreach(var x in TitleWords(i.title)) if(!matched.Contains(x)) matched.Add(x);
            if(!titlesRead) return 0;
            return matched.Count>0?Tempe:Sydney;
        }
        // Confirm rule: Seb confirmed on the eBay page when the titles weren't read reliably or he chose the other branch.
        internal static bool NeedsConfirm(int suggested,int branch) { return suggested==0||suggested!=branch; }
    }
    // What the eBay page suggested and whether Seb confirmed a different choice (shown on the page; kept with the order, but
    // never part of its content hash).
    public sealed class EbayRouting { public int suggested;public bool titlesRead,confirmed;public List<string> matched; }
    public sealed class EbayOrder {
        public string schema, submissionId, createdUtc, orderNumber, orderDate, priceSource, sentFrom;
        public EbayBuyer buyer;
        public EbayPhones phones;
        public EbayAddress address;
        public List<EbayItem> items;
        public int freightCents, totalCents;
        // 1.1.9: the branch Seb chose by button (1 or 11) and the page's suggestion. 0 / null in a stored 1.1.8 (v2) order.
        public int branch;
        public EbayRouting routing;
        internal const string Schema="tempe.ebay-order.v3",LegacySchema="tempe.ebay-order.v2";
        internal bool Legacy { get { return schema==LegacySchema; } }
        // The branch this order goes into: a stored 1.1.8 order (v2) was always Sydney and stays Sydney.
        internal int Branch { get { return Legacy?EbayBranch.Sydney:branch; } }
        internal const string OlderExtension="This order was made by an older 404 extension. Update the 404 extension to 1.6.1 (and both Ebay-auto parts to 1.1.10), refresh the eBay page and send it again.";
        // Base comment EBAY DFE; a stock "check" answer appends the checking note on the Repair Order.
        // Written By and Salesperson SA;
        // Rebill to EBAY (COSTAR then fills EBAY PAYMENTS, its note and Terms 7INV by itself).
        internal const string Comment="EBAY DFE",Staff="SA",RebillCode="EBAY",ExpectedTerms="7INV";
        internal const int MaxItems=4;
        static readonly Regex Number=new Regex(@"^\d{2}-\d{5}-\d{5}$");
        internal static bool IsNumber(string value) { return Number.IsMatch(value??""); }
        internal static string SubmissionFor(string number) { return "EBY-"+number; }
        // What goes into Rebill to's Card#: the order number and the order date, as in the example RO.
        internal string CardNumber { get { return orderNumber+" "+orderDate; } }
        internal string Reference { get { return "EBAY "+orderNumber; } }
        internal string BuyerName { get { return Order.EntryText(buyer==null?"":Order.Clean(buyer.name)); } }
        static void Text(string value,string label,int limit,bool required) {
            Order.Safe(value,label,limit); Order.Require(!required || !String.IsNullOrWhiteSpace(value),"The eBay order has no "+label+".");
        }
        // 1.1.9: a NEW order (the receiver's Submit) must be v3: its branch and the page's suggestion are checked.
        public void Validate() { Validate(false); }
        // allowLegacy: also a stored 1.1.8 order (v2, no branch: Sydney), for the queue's receipts and the worker's Accept.
        public void Validate(bool allowLegacy) {
            bool legacy=allowLegacy&&Legacy;
            Order.Require(legacy||schema==Schema,schema==LegacySchema?OlderExtension:"This order has no separate Contact info and Ship to phones and no branch. Update the 404 extension to 1.6.1 and both Ebay-auto parts to 1.1.10, then re-send the order. If already partly entered, finish that Repair Order by hand.");
            Order.Require(IsNumber(orderNumber),"The eBay order number is missing or not in the 12-34567-89012 form.");
            Order.Require(submissionId==SubmissionFor(orderNumber),"The eBay submission does not match its order number.");
            DateTimeOffset created;
            Order.Require(DateTimeOffset.TryParse(createdUtc,CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out created),"The eBay order has no send time.");
            DateTime sold;
            Order.Require(DateTime.TryParseExact(orderDate??"","dd/MM/yy",CultureInfo.InvariantCulture,DateTimeStyles.None,out sold),"The eBay order date must be dd/mm/yy.");
            Order.Require(sold<=created.UtcDateTime.AddDays(2) && sold>=created.UtcDateTime.AddDays(-400),"The eBay order date is out of range.");
            Order.Require(buyer!=null && address!=null && items!=null,"The eBay order needs the buyer, the address and the items.");
            Text(buyer.name,"buyer name",200,false); Text(buyer.phone,"buyer phone",30,true);
            Text(address.recipientName,"Ship to recipient name",200,false);
            Order.Require(Regex.IsMatch(buyer.phone,@"^\+?[\d ()-]+$") && Regex.IsMatch(Order.Phone(buyer.phone),@"^\d{8,15}$"),"The buyer's phone number is not valid.");
            Order.Require(phones!=null,"The eBay phone sources are missing. Refresh the order page with extension 1.5.2 or later.");
            Text(phones.contact,"Contact info phone",30,true);Text(phones.shipping,"Ship to phone",30,false);
            Order.Require(Regex.IsMatch(phones.contact,@"^\+?[\d ()-]+$")&&Regex.IsMatch(Order.Phone(phones.contact),@"^\d{8,15}$"),"The Contact info phone is not valid.");
            Order.Require(String.IsNullOrEmpty(phones.shipping)||(Regex.IsMatch(phones.shipping,@"^\+?[\d ()-]+$")&&Regex.IsMatch(Order.Phone(phones.shipping),@"^\d{8,15}$")),"The Ship to phone is not valid.");
            Order.Require(EbayPhoneChoice.Normalize(buyer.phone)==EbayPhoneChoice.Normalize(phones.contact),"The buyer phone must be the Contact info phone.");
            Text(buyer.email,"buyer email",240,false);
            Order.Require(String.IsNullOrEmpty(buyer.email) || Regex.IsMatch(buyer.email,@"^[^@\s]+@[^@\s]+\.[^@\s]+$"),"The buyer's email is not valid.");
            Text(buyer.username,"eBay username",64,true);
            Order.Require(Regex.IsMatch(buyer.username,@"^[A-Za-z0-9._*-]{1,64}$"),"The eBay username has characters that can't go into COSTAR.");
            Text(address.street,"street",240,false); Text(address.street2,"second address line",240,false); Text(address.suburb,"suburb",120,false);
            // 2.9.13 (Tommy, 18 Nov): the state as AddressState finds it, before this check: written (as its code), else looked up.
            Text(address.state,"state",30,false);
            var found=AddressState();
            if(Order.Clean(address.state).Length>0) Order.Require(found.State!=null,"The state must be NSW, VIC, QLD, SA, WA, TAS, NT or ACT.");
            // An absent state/postcode is incomplete customer data, not a reason to discard the rest of the order.
            // A supplied invalid value is still refused; neither the store nor COSTAR's default state substitutes for it.
            Text(address.postcode,"postcode",4,false);
            Order.Require(Order.Clean(address.postcode).Length==0||Regex.IsMatch(address.postcode??"",@"^\d{4}$"),"The postcode must be 4 digits.");
            Order.Require(items.Count>=1 && items.Count<=MaxItems,"The helper enters eBay orders with 1 to "+MaxItems+" items; enter this one by hand.");
            var ids=new HashSet<string>(StringComparer.Ordinal);long sum=0;
            foreach(var item in items) {
                Order.Require(item!=null,"An eBay item is missing.");
                Order.Require(Regex.IsMatch(item.sku??"",@"^[A-Z0-9][A-Z0-9._-]{0,39}$") && !Regex.IsMatch(item.sku,@"^(F|M|DET|WA|WAFR|SERVICES?|UNKNOWN|UNAVAILABLE)$"),
                    "Item "+(item.sku??"(no SKU)")+" is not a COSTAR item code (the eBay custom label must be the COSTAR code).");
                Order.Require(Regex.IsMatch(item.itemId??"",@"^\d{9,15}$"),"An eBay item number is missing.");
                Order.Require(ids.Add(item.itemId),"The same eBay item is listed twice.");
                Order.Require(item.quantity>=1 && item.quantity<=20,"The quantity of "+item.sku+" must be 1 to 20.");
                Order.Require(item.unitCents>=1 && item.unitCents<=10000000,"The price of "+item.sku+" is missing.");
                Text(item.title,"item title",300,false);
                sum+=(long)item.quantity*item.unitCents;
            }
            Order.Require(freightCents>=0 && freightCents<=1000000,"The freight amount is not valid.");
            Order.Require(totalCents>0 && totalCents<=100000000 && sum+freightCents==totalCents,"The items and freight don't add up to the eBay total.");
            Text(priceSource,"price source",40,false); Text(sentFrom,"sender",80,false);
            Order.Require(Plan().Count>0,"Nothing to enter.");
            // 1.1.9: the branch, after every check of 1.1.8. A stored v2 order has none (Sydney, as it was sent).
            if(legacy) { Order.Require(branch==0&&routing==null,"A stored eBay order from before 1.1.9 can't name a branch.");return; }
            Order.Require(EbayBranch.Known(branch),"The eBay order has no branch: choose Sydney (Branch 1) or Tempe (Branch 11) on the eBay page.");
            Order.Require(routing!=null,"The eBay order has no branch suggestion. Refresh the eBay page and send it again.");
            bool read;List<string> words;int suggested=EbayBranch.Suggest(items,out read,out words);
            Order.Require(routing.titlesRead==read&&routing.suggested==suggested,"The branch suggestion doesn't match the item titles. Refresh the eBay page and send it again.");
            var sent=routing.matched??new List<string>();
            Order.Require(sent.Count<=20&&sent.All(w=>w!=null&&w.Length<=20),"The branch suggestion's words are not valid.");
            // The matching words, compared as a set (any case): exactly the words Suggest finds in the titles (costar_send.js
            // suggest() lists every match of every title read), never one no title has, never one missing.
            var given=new HashSet<string>(sent,StringComparer.OrdinalIgnoreCase);
            Order.Require(given.SetEquals(words),"The branch suggestion's words don't match the item titles. Refresh the eBay page and send it again.");
            if(EbayBranch.NeedsConfirm(suggested,branch)) Order.Require(routing.confirmed,suggested==0?"The item titles couldn't be read reliably: the branch ("+EbayBranch.Name(branch)+") must be confirmed on the eBay page.":"This order looks like a "+EbayBranch.Name(suggested)+" order: sending it to "+EbayBranch.Name(branch)+" must be confirmed on the eBay page.");
            else Order.Require(!routing.confirmed,"The branch was confirmed although it is the suggested one. Refresh the eBay page and send it again.");
        }
        // 2.9.13 (Tommy, 18 Nov): the buyer's state. Written in the address: kept (a full name as its code; the extension sends
        // codes), never replaced by a lookup. None written: looked up by the address's suburb and postcode in the address list
        // (AuPlaces.Resolve), used only when they are in exactly one state (never from the postcode alone, the store or
        // COSTAR's NSW). Worked out again wherever it is needed (the receiver's check, the worker's check, the entry) and never
        // put into the order: what the receiver keeps and its content hash (a send again of the same order) stay as sent.
        internal StateFound AddressState() {
            if(address==null) return new StateFound {State=null,Source="",Why="no address"};
            return AuPlaces.Resolve(address.state,address.suburb,address.postcode);
        }
        // Derived only: the received payload and duplicate hash stay unchanged. An unresolved missing state remains
        // missing even if COSTAR displays its default NSW or a linked customer's previous state.
        internal List<string> MissingCustomerDetails() {
            var missing=new List<string>();
            if(buyer==null||Order.Clean(buyer.name).Length==0) missing.Add("billing name from eBay Order/Buyer");
            if(address==null) { missing.Add("Ship to details");return missing; }
            if(Order.Clean(address.recipientName).Length==0) missing.Add("Ship to name");
            if(Order.Clean(address.street).Length==0) missing.Add("street address");
            if(Order.Clean(address.suburb).Length==0) missing.Add("suburb");
            if(AddressState().State==null) missing.Add("state");
            if(Order.Clean(address.postcode).Length==0) missing.Add("postcode");
            return missing;
        }
        // Content only: a second click on Send (new send time) is the same order.
        internal string ContentHash() { return Wire.Hash(Encoding.UTF8.GetBytes(CanonicalJson())); }
        // 1.1.9: the branch counts (the same order for another branch is not the same order); the page's suggestion (routing)
        // doesn't. A stored 1.1.8 order (v2) hashes without the branch and routing keys: byte for byte as 1.1.8 did, so the
        // hashes 1.1.8 kept still match.
        internal string CanonicalJson() {
            var copy=Wire.Copy(this);copy.createdUtc=null;copy.sentFrom=null;copy.routing=null;
            // Reflection's field order can change between serializer calls. Hash the same key order
            // recursively so an identical resend is never mistaken for changed order details.
            object tree=Wire.Read<object>(Wire.Json(copy));
            var top=tree as IDictionary<string,object>;
            if(top!=null) { top.Remove("routing");if(Legacy) top.Remove("branch"); }
            return Wire.Json(Canonical(tree));
        }
        // 1.1.9: this order's hash as a receipt kept by 1.1.8 (v2) would have it, so a Sydney order sent again from the new
        // extension with the same details is still the same order. Any other receipt: the ordinary hash.
        internal string ContentHashLike(EbayOrder stored) {
            if(stored==null||!stored.Legacy||Legacy||Branch!=EbayBranch.Sydney) return ContentHash();
            var v2=Wire.Copy(this);v2.schema=LegacySchema;v2.branch=0;v2.routing=null;
            // 1.1.9 (20 Nov 2026): the 1.5.x extension always sent items[].title "" (titles are only routing input, new in
            // 1.6.0), so a receipt kept by 1.1.8 was hashed without them. Blank them on this copy too (only when the stored
            // receipt has none), or the same order sent again never matches. The order being sent keeps its titles.
            if(stored.items==null||stored.items.All(i=>i==null||String.IsNullOrEmpty(i.title))) { if(v2.items!=null) foreach(var i in v2.items) if(i!=null) i.title=""; }
            return v2.ContentHash();
        }
        static object Canonical(object value) {
            var map=value as IDictionary<string,object>;
            if(map!=null) {
                var sorted=new SortedDictionary<string,object>(StringComparer.Ordinal);
                foreach(var pair in map)sorted[pair.Key]=Canonical(pair.Value);
                return sorted;
            }
            var list=value as System.Collections.IEnumerable;
            if(list!=null&&!(value is string)) {
                var items=new List<object>();foreach(object item in list)items.Add(Canonical(item));return items;
            }
            return value;
        }
        // The Repair Order's lines, spaced as in Tommy's example RO 07497644 (22 Oct): an empty line
        // between every entry. Items (eBay price), freight, one M E per item, M BUY, then M DFE (COSTAR's
        // own text; the consignment number is someone else's job).
        internal List<EbayLine> Plan() {
            var lines=new List<EbayLine>();int n=1;
            foreach(var it in items) {
                lines.Add(new EbayLine {Line=n,Kind="product",Code=it.sku,Quantity=it.quantity,UnitCents=it.unitCents,Label="Item "+it.sku,
                    Item=new OrderLine {kind="product",sourceSku=it.sku,code=it.sku,description=String.IsNullOrWhiteSpace(it.title)?it.sku:it.title,quantity=it.quantity,unitCents=it.unitCents,totalCents=it.quantity*it.unitCents}});
                n+=2;
            }
            if(freightCents>0) { lines.Add(new EbayLine {Line=n,Kind="freight",Code="F",Quantity=1,UnitCents=freightCents,Label="Freight"});n+=2; }
            foreach(var it in items) { lines.Add(new EbayLine {Line=n,Kind="note",Code="M E",Text="EBAY ITEM # "+it.itemId,Label="M E (eBay item "+it.itemId+")"});n+=2; }
            lines.Add(new EbayLine {Line=n,Kind="note",Code="M BUY",Text="EBAY BUYER NAME: "+Order.EntryText(buyer.username.Trim()),Label="M BUY (buyer name)"});n+=2;
            lines.Add(new EbayLine {Line=n,Kind="code",Code="M DFE",Label="M DFE"});
            Order.Require(n<=Grid.CostarLines,"This eBay order needs more than COSTAR's "+Grid.CostarLines+" lines.");
            return lines;
        }
        // The online-delivery engine's view: billing uses Buyer's display name, Ship to its recipient,
        // PO# the eBay order number, comment EBAY DFE, Ship Via DFE.
        internal Order EngineOrder() {
            string phone=EbayPhoneChoice.Normalize(phones.contact),email=Order.Clean(buyer.email);
            string street=Order.EntryText(Order.Clean(address.street)),street2=Order.EntryText(Order.Clean(address.street2)),suburb=Order.EntryText(Order.Clean(address.suburb));
            // 2.9.13: billing and Ship to both take the state AddressState finds (the buyer has one address), and where it came from.
            var found=AddressState();string state=found.State??Order.Clean(address.state),from=found.State==null?null:found.Source;
            return new Order {
                schema=2,type="delivery",deliveryMethod="EBAY",orderId=orderNumber,createdUtc=createdUtc,comment=Comment,vehicle="",rego="",store="",
                freightCents=freightCents,totalCents=totalCents,
                customer=new Customer {name=BuyerName,streetAddress=street,address2=street2,suburb=suburb,state=state,postcode=address.postcode,phone=phone,email=email,StateFrom=from},
                shipping=new Shipping {name=Order.EntryText(Order.Clean(address.recipientName)),streetAddress=street,address2=street2,suburb=suburb,state=state,postcode=address.postcode,
                    contact="",businessPhone="",mobilePhone=EbayPhoneChoice.Normalize(phones.shipping),email=email,shipVia="DFE",instructions="",StateFrom=from},
                lines=Plan().Where(l=>l.Item!=null).Select(l=>l.Item).ToList()
            };
        }
    }
    // One COSTAR line of an eBay order. Kind: product (code, quantity, eBay unit price), freight
    // (F with the eBay postage), note (code with this exact text) or code (COSTAR's own text).
    internal sealed class EbayLine {
        internal int Line,Quantity,UnitCents;
        internal string Kind,Code,Text,Label;
        internal OrderLine Item;
    }

    // One rule on both sides for words the RDP helper sends (messages, progress, details): any
    // control character becomes a space and the text is cut to its limit, so a report can never be
    // refused for its words (and resent forever).
    internal static class EbayText {
        internal static string Clean(string text,int limit) {
            var b=new StringBuilder(text??"");
            for(int i=0;i<b.Length;i++) if(Char.IsControl(b[i])) b[i]=' ';
            string clean=b.ToString();
            return clean.Length>limit?clean.Substring(0,limit):clean;
        }
    }
    // ---- The desk's eBay queue -------------------------------------------------------------
    // Statuses: queued (waiting for the worker), entering, ready_for_review, failed, removed, and (Ebay-auto 1.0.0)
    // handed_over: entered as far as it safely could, then left open in its branch's COSTAR for Seb to finish by hand (an item
    // COSTAR doesn't know). One receipt per eBay order number: the same order can never be queued twice.
    // jobId (Ebay-auto): the order's own id across the receiver, the worker and their diagnostics ("J-" and six letters,
    // never the eBay number). remaining: what is left to do by hand (handed_over only).
    // 1.1.9: branch, the branch the order goes into (EbayOrder.Branch), so every status the eBay page shows names it.
    public sealed class EbayStatus { public string orderNumber,status,message,progress,updatedUtc,waiting,jobId,remaining;public int version,branch;public bool typed; }
    public sealed class EbayReceipt {
        public EbayOrder order;public string hash,status,message,progress,lease,workerId,receivedUtc,updatedUtc;
        // fresh: use a NEW Repair Order (the earlier attempt is set aside). startAgain: Tommy chose
        // "Start again" on the desk after checking COSTAR, the only thing that lets the helper enter
        // an order its journal says it already entered. Both last until the helper's first report.
        // claimedOnce: handed to the RDP helper at least once (its details are fixed from then on).
        public int version,workerSequence;public bool awaitingWorker,fresh,startAgain,hidden,typed,claimedOnce;
        // 2.8.0: retried by the desk by itself (once, ever; only when nothing was typed).
        public bool autoRetried;
        // Ebay-auto 1.0.0: jobId (kept for good, see EbayStatus), attemptId (the current claim's, "A-" and six letters),
        // remaining and handedOverUtc (handed_over), markedDone (Mark done by hand: finished, but not by the worker).
        public string jobId,attemptId,remaining,handedOverUtc;public bool markedDone;
        internal EbayStatus Status() { return new EbayStatus {orderNumber=order.orderNumber,status=status,message=message,progress=progress,updatedUtc=updatedUtc,version=version,typed=typed,jobId=jobId,remaining=status=="handed_over"?remaining:null,branch=order.Branch}; }
        // 1.1.9: "COSTAR Sydney (Br1)" / "COSTAR Tempe (Br11)", for this receipt's words.
        internal string Costar { get { return EbayBranch.Costar(order==null?EbayBranch.Sydney:order.Branch); } }
    }
    public sealed class EbayState { public List<EbayReceipt> orders=new List<EbayReceipt>(); }
    // typed: the helper has typed into COSTAR for this order (the desk then offers "Start again").
    // Ebay-auto: jobId and attemptId as the claim named them; remaining (handed_over): what is left to do by hand.
    public sealed class EbayReport { public string orderNumber,lease,status,message,progress,jobId,attemptId,remaining;public int sequence;public bool typed; }
    // working: the lease of the order the helper is entering right now, "" when none (an order the
    // desk still has as entering for it, under another lease, was lost: it is marked stopped).
    // declined: the lease of an order handed over that the helper could not start (it waits again).
    // sequence: the helper's report counter when it wrote this hello (read after working and report).
    // An order is only taken as lost by a hello written after the desk's last report for it, so a
    // late, older poll can never mark an order being typed as stopped.
    // Ebay-auto: version (the worker's), requestId (this poll's own id, "R-" and six letters, for the diagnostics).
    // Ebay-auto 1.1.0: protocol (Product.Protocol; 1.0.0 sent none: 1).
    // Ebay-auto 1.1.9 (protocol 2): branches, the branches this worker can start a NEW order in right now (1 and/or 11);
    // branchWaiting ("1" / "11"): why a branch can't take one now. available stays branches.Count>0 (older code paths). Only a
    // protocol-2 worker is handed orders, each only in a branch it named.
    public sealed class EbayHello { public string workerId,detail,working,declined,declineReason,version,requestId;public bool accepting,available;public EbayReport report;public int waitMs,sequence,protocol;public List<int> branches;public Dictionary<string,string> branchWaiting; }
    // command: enter, wait or forget (the report names an order this desk no longer has for that lease).
    // ack: the sequence of the report the desk applied (or dropped); the helper stops sending it.
    // Ebay-auto: jobId and attemptId of the order handed over; diagnostics: the receiver asks for the worker's logs (a token
    // the worker sends back with them, see ReceiverApi.EbayDiagnostics).
    // Ebay-auto 1.1.0: the receiver's version and protocol (a 1.0.0 receiver sends neither: protocol 1).
    public sealed class EbayReply { public string command,lease,jobId,attemptId,diagnostics,version;public EbayOrder order;public bool fresh,startAgain,held;public EbayStatus status;public int ack,waitedMs,protocol; }
    internal sealed class EbayQueue {
        readonly object gate=new object();readonly Action<EbayState> save;EbayState state;
        internal const int Keep=300;
        internal event Action Changed;
        // Ebay-auto 1.0.0: what happened to which order, for the receiver's diagnostics (kind, the order's jobId, the claim's
        // attemptId, words of this program's own: never the buyer's details). Told after the change is saved, outside the lock.
        internal Action<string,string,string,string> Noted;
        readonly List<string[]> notes=new List<string[]>();
        void Note(string kind,EbayReceipt r,string detail) {
            string request=CurrentRequest;
            notes.Add(new[]{kind,r==null?"":r.jobId??"",r==null?"":r.attemptId??"",(detail??"")+(request==null?"":" (request "+request+")")});
        }
        // The extension's request id while the receiver handles its send or retry (ReceiverApi.EbayRoute), for Note.
        [ThreadStatic] internal static string CurrentRequest;
        internal EbayQueue(EbayState initial,Action<EbayState> persist) {
            state=initial??new EbayState();if(state.orders==null)state.orders=new List<EbayReceipt>();save=persist;
            // Receipts kept by an earlier version have no jobId yet: given one now (saved with the next change).
            foreach(var r in state.orders) if(String.IsNullOrEmpty(r.jobId)) r.jobId=NewId("J");
        }
        // "J-KQXTMB": a prefix and six consonants (no digits, so the masking of numbers in the logs never hides it; no
        // vowels, so it never spells a word).
        internal static string NewId(string prefix) {
            const string letters="BCDFGHJKLMNPQRSTVWXZ";var bytes=new byte[6];
            using(var rng=RandomNumberGenerator.Create()) rng.GetBytes(bytes);
            var b=new StringBuilder(prefix+"-");foreach(var x in bytes) b.Append(letters[x%letters.Length]);
            return b.ToString();
        }
        T Change<T>(Func<T> action) {
            T value;List<string[]> told;
            lock(gate) {
                var old=Wire.Copy(state);notes.Clear();
                try {value=action();save(state);}catch {state=old;notes.Clear();throw;}
                told=notes.ToList();notes.Clear();
            }
            var noted=Noted;if(noted!=null) foreach(var n in told) { try{noted(n[0],n[1],n[2],n[3]);}catch(Exception){} }
            var changed=Changed;if(changed!=null){try{changed();}catch(Exception){}}
            return value;
        }
        // Ebay-auto 1.0.0: what an order's state means for a person (the diagnostics' and the windows' words): verified
        // (entered and checked by the worker, nothing to do by hand), check_by_hand (entered and checked, one thing left to
        // do by hand: CHECK BY HAND), handed_over (left open, items or steps unresolved), marked_done (finished by hand),
        // waiting (queued or being entered), stopped (stopped or uncertain), removed.
        internal static string Category(EbayReceipt r) {
            if(r==null) return "";
            switch(r.status) {
                case "ready_for_review": return r.markedDone?"marked_done":(r.message??"").IndexOf("CHECK BY HAND",StringComparison.Ordinal)>=0?"check_by_hand":"verified";
                case "handed_over": return "handed_over";
                case "queued": case "entering": return "waiting";
                case "failed": return "stopped";
                default: return r.status??"";
            }
        }
        static string Now { get { return DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture); } }
        static void Set(EbayReceipt r,string status,string message) { r.status=status;r.message=message??"";r.version++;r.updatedUtc=Now; }
        EbayReceipt Find(string number) { return state.orders.FirstOrDefault(o=>o.order.orderNumber==number); }
        EbayReceipt Must(string number) { var r=Find(number);Order.Require(r!=null,"That eBay order is not on this receiver.");return r; }
        internal List<EbayReceipt> List() { lock(gate) return Wire.Copy(state.orders); }
        internal EbayStatus Get(string number) { lock(gate) { var r=Find(number);return r==null?null:r.Status(); } }
        internal int Waiting { get { lock(gate) return state.orders.Count(o=>o.status=="queued"||o.status=="entering"); } }
        internal EbayStatus Submit(EbayOrder order) {
            // 1.1.9: a new send is always v3 (its branch chosen on the eBay page); a v2 one is from an older extension.
            Order.Require(order!=null,"No eBay order was sent.");order.Validate();string hash=order.ContentHash();
            return Change(delegate {
                var old=Find(order.orderNumber);
                if(old!=null) {
                    // 1.1.9: compared as the receipt was hashed (a receipt kept by 1.1.8 is a v2 Sydney order).
                    string same=order.ContentHashLike(old.order);int was=old.order.Branch,now=order.Branch;
                    if(old.status=="removed") {
                        if(old.typed) {
                            // Partly typed into COSTAR before it was removed: a re-send never means a NEW
                            // Repair Order. The helper continues the one it stopped in only if nothing in
                            // it changed; otherwise it refuses and Tommy decides on the desk. 1.1.9: another
                            // branch is a change too (it is never moved out of the COSTAR it was typed in).
                            if(!Wire.Equal(old.hash,same)) throw new InvalidOperationException("CONFLICT: eBay order "+order.orderNumber+" was partly entered in "+old.Costar+" before it was removed, and these details are different"+(was!=now?" (it was never moved to "+EbayBranch.Name(now)+")":"")+". Finish it in "+old.Costar+" by hand.");
                            old.lease=null;old.workerId=null;old.awaitingWorker=false;old.fresh=false;old.startAgain=false;old.hidden=false;old.markedDone=false;old.receivedUtc=Now;
                            Set(old,"queued","Sent again after it was removed. It was partly entered before: the worker continues that Repair Order only if nothing in it changed");Note("sent_again",old,"partly entered before");return old.Status();
                        }
                        // Nothing typed before: a new entry, in a NEW Repair Order. Not a Start again:
                        // if the helper's journal says it entered it, it still refuses.
                        // 1.1.9: in the branch it was sent for now (it may be the other one: nothing was typed anywhere).
                        old.order=Wire.Copy(order);old.hash=hash;old.lease=null;old.workerId=null;old.awaitingWorker=false;old.fresh=true;old.startAgain=false;old.hidden=false;old.typed=false;old.claimedOnce=false;old.markedDone=false;old.receivedUtc=Now;
                        Set(old,"queued","Sent again after it was removed; waiting for the worker ("+old.Costar+")");Note("sent_again",old,"nothing typed before: a new Repair Order in "+old.Costar+(was!=now?" (was "+EbayBranch.Name(was)+" before it was removed)":""));return old.Status();
                    }
                    // 1.1.9: the other branch's button on an order the receiver already has: never re-routed by itself (not even
                    // while it waits, unclaimed). Seb removes it first, and only when nothing was typed.
                    // (Refused, so nothing is noted here: the receiver's send_conflict says it.)
                    if(was!=now) { throw new InvalidOperationException("CONFLICT: eBay order "+order.orderNumber+" was already sent to "+old.Costar+". It is not sent to "+EbayBranch.Costar(now)+" as well. To change its branch, Remove it on the Ebay-auto receiver first (only if nothing was typed), then send it again."); }
                    if(Wire.Equal(old.hash,same)) { Note("duplicate_send",old,"same details as the "+old.status.Replace('_',' ')+" order: nothing new queued");return old.Status(); }
                    // Changed before the worker ever took it: the newer details replace the older ones.
                    if(old.status=="queued" && !old.awaitingWorker && !old.claimedOnce && !old.typed) { old.order=Wire.Copy(order);old.hash=hash;Set(old,"queued","Updated details received; waiting for the worker");Note("updated",old,"changed before the worker took it");return old.Status(); }
                    throw new InvalidOperationException("CONFLICT: eBay order "+order.orderNumber+" was already sent with different details ("+old.status.Replace('_',' ')+"). Remove it on the Ebay-auto receiver first.");
                }
                Order.Require(state.orders.Count(o=>o.status=="queued"||o.status=="entering")<50,"Too many eBay orders are waiting on the receiver.");
                var r=new EbayReceipt {order=Wire.Copy(order),hash=hash,receivedUtc=Now,version=0,jobId=NewId("J")};
                Set(r,"queued","Waiting for the worker");
                Note("received",r,EbayDiag.Shape(order)+"; "+EbayDiag.Route(order));
                state.orders.Add(r);Prune();return r.Status();
            });
        }
        // Old finished receipts go first once there are more than Keep; waiting ones always stay.
        void Prune() {
            int extra=state.orders.Count-Keep;if(extra<=0) return;
            var gone=state.orders.Where(o=>o.status=="ready_for_review"||o.status=="removed").OrderBy(o=>o.updatedUtc,StringComparer.Ordinal).Take(extra).ToList();
            foreach(var g in gone) state.orders.Remove(g);
        }
        // 2.8.0: an order that stopped before anything was typed, retried once by itself (Unattended.RetryDue); its
        // stop time is the receipt's own (updatedUtc). True when it was set to wait again.
        internal static bool AutoRetryDue(EbayReceipt r,DateTime nowUtc) {
            DateTime at;
            return r!=null&&r.status=="failed"&&!r.typed&&!r.autoRetried&&DateTime.TryParse(r.updatedUtc??"",CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out at)&&Unattended.RetryDue(r.message,at.ToUniversalTime(),nowUtc,false);
        }
        internal bool AutoRetry(string number,DateTime nowUtc) {
            lock(gate) { if(!AutoRetryDue(Find(number),nowUtc)) return false; }
            return Change(delegate {
                var r=Find(number);if(!AutoRetryDue(r,nowUtc)) return false;
                r.autoRetried=true;r.lease=null;r.awaitingWorker=false;Set(r,"queued","Retried by itself once (it stopped before anything was typed); the worker continues in the same Repair Order if nothing in it changed");
                Note("auto_retry",r,"once, by itself: it stopped before anything was typed");
                return true;
            });
        }
        // by: who asked (the receiver's window, or the extension's Send again), for the diagnostics. A handed-over order is
        // never retried (Ebay-auto 1.0.0): the worker never continues one while Seb finishes it by hand; it stays as it is.
        internal EbayStatus Retry(string number,string by="receiver") { return Change(delegate {
            var r=Must(number);
            if(r.status=="failed") { r.lease=null;r.awaitingWorker=false;Set(r,"queued","Retry requested; the worker continues in the same Repair Order if nothing in it changed");Note("retry",r,"by "+by); }
            else if(r.status=="handed_over") Note("retry_refused",r,"by "+by+": handed over for manual completion, left as it is");
            return r.Status();
        }); }
        // The earlier attempt is set aside: the worker enters the order in a NEW Repair Order. Also for a handed-over order
        // (Ebay-auto 1.0.0): its Repair Order stays as it is in COSTAR (the window that asks says so).
        internal EbayStatus StartAgain(string number) { return Change(delegate {
            var r=Must(number);Order.Require(r.status=="failed"||r.status=="handed_over","Only a stopped or handed-over eBay order can be started again.");
            string was=r.status;
            r.lease=null;r.awaitingWorker=false;r.fresh=true;r.startAgain=true;r.typed=false;r.remaining=null;Set(r,"queued","Start again: a new Repair Order will be used");Note("start_again",r,"was "+was.Replace('_',' '));return r.Status();
        }); }
        // workerReachable: the worker is in touch. An order it has taken is left alone while it is
        // (even before its first report: it may be typing); with the worker gone it can be closed here.
        internal EbayStatus MarkDone(string number,bool workerReachable) { return Change(delegate {
            var r=Must(number);
            Order.Require(r.status=="failed"||r.status=="queued"||r.status=="handed_over"||(r.status=="entering"&&!workerReachable),r.status=="entering"?"The worker is entering this order right now. Stop it there first.":"This eBay order is already finished or removed.");
            string was=r.status;
            r.awaitingWorker=false;r.markedDone=true;Set(r,"ready_for_review","Marked done by hand on the receiver. Check it in COSTAR.");Note("mark_done",r,"was "+was.Replace('_',' '));return r.Status();
        }); }
        internal EbayStatus Remove(string number,bool workerReachable) { return Change(delegate {
            var r=Must(number);
            Order.Require(r.status=="queued"||r.status=="failed"||r.status=="handed_over"||(r.status=="entering"&&!workerReachable),r.status=="entering"?"The worker is entering this order right now. Stop it there first.":"Only a waiting, stopped or handed-over eBay order can be removed.");
            string was=r.status;
            r.awaitingWorker=false;r.hidden=true;Set(r,"removed","Removed on the receiver");Note("remove",r,"was "+was.Replace('_',' '));return r.Status();
        }); }
        internal void Hide(string number) { Change(delegate { var r=Must(number);Order.Require(r.status=="ready_for_review","Only finished eBay orders can be hidden.");r.hidden=true;Note("hide",r,"");return true; }); }
        internal void HideFinished() { Change(delegate { int n=0;foreach(var r in state.orders.Where(o=>o.status=="ready_for_review"&&!o.hidden)) { r.hidden=true;n++; } Note("hide_finished",null,n+" finished order(s)");return true; }); }
        // 1.1.9: the branches a worker can start a NEW order in now: a protocol-2 worker's own list (1 and 11 only), none
        // from an older worker (it would enter every order into COSTAR Sydney) or one that says it can't take any.
        internal static HashSet<int> Ready(EbayHello hello) {
            var ready=new HashSet<int>();
            if(hello==null||!hello.available||Product.ProtocolOf(hello.protocol)<2||hello.branches==null) return ready;
            foreach(int b in hello.branches) if(EbayBranch.Known(b)) ready.Add(b);
            return ready;
        }
        // Why an order for this branch waits, in the worker's words when it said why ("Waiting for COSTAR Tempe (Br11): ...").
        internal static string BranchWaiting(EbayHello hello,int branch) {
            string why=null;
            if(hello!=null&&hello.branchWaiting!=null) hello.branchWaiting.TryGetValue(branch.ToString(CultureInfo.InvariantCulture),out why);
            why=EbayText.Clean(why,300).Trim();
            // The worker may already name the COSTAR it waits for: said once.
            string costar=EbayBranch.Costar(branch);
            if(why.StartsWith("Waiting for "+costar,StringComparison.OrdinalIgnoreCase)) return why;
            return "Waiting for "+costar+(why.Length>0?": "+why:" (it can't take an order there yet)");
        }
        static EbayReply Enter(EbayReceipt r,int ack) { return new EbayReply {command="enter",order=Wire.Copy(r.order),lease=r.lease,jobId=r.jobId,attemptId=r.attemptId,fresh=r.fresh,startAgain=r.startAgain,status=r.Status(),ack=ack}; }
        internal EbayReply Poll(EbayHello hello) {
            Order.Require(hello!=null,"Missing worker hello.");
            return Change(delegate {
                int ack=0;
                if(hello.report!=null) {
                    var p=hello.report;ack=p.sequence;var r=p.orderNumber==null?null:Find(p.orderNumber);
                    // A report for an order this desk dropped, or for an older lease (retried since):
                    // nothing to apply; the helper forgets it.
                    if(r==null || r.workerId!=hello.workerId || !Wire.Equal(r.lease,p.lease)) { Note("report_forgotten",r,"a report for "+(r==null?"an order this receiver no longer has":"an older claim")+": the worker forgets it");return new EbayReply {command="forget",ack=ack,status=r==null?new EbayStatus {orderNumber=p.orderNumber,status="removed",message="Unknown to this receiver"}:r.Status()}; }
                    if(p.sequence>r.workerSequence) {
                        Order.Require(p.status=="entering"||p.status=="failed"||p.status=="ready_for_review"||p.status=="handed_over","Invalid eBay worker status.");
                        bool first=r.workerSequence==0;   // reset to 0 by each claim
                        // The worker has the order from its first report on: its details are fixed from then.
                        r.workerSequence=p.sequence;r.awaitingWorker=false;r.fresh=false;r.startAgain=false;r.claimedOnce=true;r.typed|=p.typed;
                        // Finished, removed or marked done on the receiver stays as it is.
                        if(r.status=="entering") {
                            if(first&&p.status=="entering") Note("started",r,"the worker reports it is entering it");
                            Set(r,p.status,p.message);r.progress=p.progress??"";
                            if(p.status=="handed_over") {
                                // A report without what is left (an older worker, or a refusal) keeps what this receiver already had.
                                string left=EbayText.Clean(p.remaining,600).Trim();
                                r.typed=true;r.remaining=left.Length>0?left:!String.IsNullOrEmpty(r.remaining)?r.remaining:"see the message";r.handedOverUtc=Now;Note("handed_over",r,r.remaining);
                            }
                            else if(p.status=="ready_for_review") Note("completed",r,Category(r)+": "+EbayDiag.Outcome(p.message));
                            else if(p.status=="failed") Note("stopped",r,(p.typed?"typed into COSTAR before it stopped: ":"nothing typed: ")+Sanitize.Text(p.message,300));
                        } else if(p.status!="entering") Note("late_report",r,p.status+" reported after the order was "+r.status.Replace('_',' ')+" here: kept as it is");
                    }
                }
                // A claim the helper could not start (its branch's COSTAR not open, someone working, another
                // entry): back in line, saying why.
                EbayReceipt declinedNow=null;
                if(!String.IsNullOrEmpty(hello.declined)) {
                    var d=state.orders.FirstOrDefault(o=>o.status=="entering"&&o.awaitingWorker&&o.workerId==hello.workerId&&Wire.Equal(o.lease,hello.declined));
                    if(d!=null) {
                        declinedNow=d;   // 1.1.9: its reason (the worker's own words) is kept for this poll
                        string why=EbayText.Clean(String.IsNullOrWhiteSpace(hello.declineReason)?"the worker could not start it yet":hello.declineReason.Trim(),400);
                        d.lease=null;d.workerId=null;d.awaitingWorker=false;Set(d,"queued",why.StartsWith("Waiting",StringComparison.OrdinalIgnoreCase)?why:"Waiting: "+why);
                        Note("declined",d,why);
                    }
                }
                // An order this helper took (and reported on) but is no longer entering: it was closed,
                // restarted or lost its record. Stopped, so Tommy can deal with it (never left stuck).
                if(hello.working!=null) {
                    string reported=hello.report==null?null:hello.report.lease;
                    foreach(var o in state.orders.Where(o=>o.status=="entering"&&!o.awaitingWorker&&o.workerId==hello.workerId&&!Wire.Equal(o.lease,hello.working)&&!Wire.Equal(o.lease,reported)&&o.workerSequence<=hello.sequence).ToList()) {
                        // It may have been typed into: Start again then warns, and Tommy checks COSTAR first.
                        o.typed=true;
                        Set(o,"failed","The worker is no longer entering this eBay order (it was closed or restarted). Check "+o.Costar+" for it first: Retry continues only in the same, unchanged Repair Order; otherwise Mark done by hand, or Start again only if it is NOT in COSTAR.");
                        Note("lost",o,"the worker is no longer entering it (closed or restarted)");
                    }
                }
                // A claim whose reply was lost comes back with the same lease, also to a helper that is
                // switched off (it hands it back) or busy with it (it ignores it): never stuck.
                var again=state.orders.FirstOrDefault(o=>o.status=="entering"&&o.awaitingWorker&&o.workerId==hello.workerId);
                if(again!=null) return Enter(again,ack);
                if(!hello.accepting) return new EbayReply {command="wait",ack=ack};
                // 1.1.9: only in a branch the worker can start one in now (a protocol-2 worker names them; an older one is
                // handed nothing: it can't tell the branches apart). The others wait, saying for which COSTAR and why.
                var ready=Ready(hello);
                foreach(var w in state.orders.Where(o=>o.status=="queued"&&!ready.Contains(o.order.Branch)&&o!=declinedNow).ToList()) {
                    string why=BranchWaiting(hello,w.order.Branch);
                    if(w.message!=why) Set(w,"queued",why);
                }
                // One order at a time, across both branches.
                if(state.orders.Any(o=>o.status=="entering"&&o.workerId==hello.workerId)) return new EbayReply {command="wait",ack=ack};
                var next=state.orders.Where(o=>o.status=="queued"&&ready.Contains(o.order.Branch)).OrderBy(o=>o.receivedUtc,StringComparer.Ordinal).FirstOrDefault();
                if(next==null) return new EbayReply {command="wait",ack=ack};
                next.workerId=hello.workerId;next.lease=Wire.Token();next.attemptId=NewId("A");next.awaitingWorker=true;next.workerSequence=0;
                Set(next,"entering","The worker is opening a Repair Order in "+next.Costar);
                Note("claimed",next,(next.fresh?"a new Repair Order":"continues where it stopped, if unchanged")+" in "+next.Costar+(String.IsNullOrEmpty(hello.requestId)?"":" (worker request "+hello.requestId+")"));
                return Enter(next,ack);
            });
        }
    }
    // A 6-digit PIN shown on the desk for 10 minutes; the eBay PC's extension trades it once for
    // the eBay key. Five wrong tries close it.
    internal sealed class EbayPairing {
        readonly object gate=new object();string pin;DateTime until;int tries;
        internal const int Minutes=10,Tries=5;
        internal string Begin() {
            var bytes=new byte[4];using(var rng=RandomNumberGenerator.Create())rng.GetBytes(bytes);
            string code=((BitConverter.ToUInt32(bytes,0)%900000)+100000).ToString(CultureInfo.InvariantCulture);
            lock(gate) { pin=code;until=DateTime.UtcNow.AddMinutes(Minutes);tries=0; }
            return code;
        }
        internal bool Active { get { lock(gate) return pin!=null&&DateTime.UtcNow<until; } }
        internal void End() { lock(gate) pin=null; }
        internal bool Try(string candidate) {
            lock(gate) {
                if(pin==null||DateTime.UtcNow>=until) return false;
                tries++;
                if(Wire.Equal(candidate??"",pin)) { pin=null;return true; }
                if(tries>=Tries) pin=null;
                return false;
            }
        }
    }
}
