using System;

namespace TempeCostar {
    // Customer details absent from eBay remain unverified, not invented from COSTAR's defaults or another panel.
    // The run separately reports MissingCustomerDetails() as CHECK BY HAND and still verifies every supplied value.
    internal static class EbayIncomplete {
        internal static bool KnownMatches(string actual,string expected) {
            return String.IsNullOrWhiteSpace(expected)||Order.Norm(actual)==Order.Norm(expected);
        }
        internal static void VerifyKnown(string actual,string expected,string label) {
            Order.Require(KnownMatches(actual,expected),"Final check failed: "+label+".");
        }
    }
}
