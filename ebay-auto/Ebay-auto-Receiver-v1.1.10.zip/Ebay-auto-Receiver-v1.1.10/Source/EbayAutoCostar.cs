// Ebay-auto 1.1.0: which COSTAR Sydney (Branch 1) the worker's NEW orders go into when several COSTARs are open in this
// Remote Desktop session (Seb keeps other branches open beside Sydney, and may open more than one Sydney).
//
// What 1.0.0 did (EbayEngine.FindTarget, traced 16 Nov): every 3 s it listed the COSTAR main windows of this session
// (CostarWindows.Choices: by window title "COSTAR: <branch> ...", sorted by PID), kept those of Branch 1, and went on only
// when exactly ONE was left; with two Sydney instances every order waited ("2 COSTARs of Branch 1 are open in this
// session: close all but one"). Other branches were filtered out by their titles, so they alone never stopped it. Simply
// taking the first of several would not have been safe either: the list is re-made every 3 s, sorted by PID (not by when
// a COSTAR started), a Sydney whose title can't be read for a moment drops out of it, and any failed check on the chosen
// one (Blocked, WhyNotOnWip) cleared the choice, so the next look could pick the other Sydney: a busy COSTAR would have
// been swapped instead of waited for. A Retry of an order typed part-way was also checked against whichever COSTAR was
// chosen at the time, not its own.
//
// Now: the earliest-STARTED Sydney (the process's start time, never PID order, window order or what is in front) is
// chosen and KEPT while it is valid: the same process (PID and start time: a restarted COSTAR is a new one, even with a
// reused PID) still running in this session and not seen to show another branch. A title that can't be read, a busy or
// blocked COSTAR: new orders wait, saying why; nothing else is chosen meanwhile. Only when the chosen one has closed, or
// has shown another branch on two looks a second or more apart, is the earliest-started remaining Sydney chosen, for new
// orders only. An order being entered, and a Retry of one typed part-way, stay in their own COSTAR and Repair Order
// (EbayEngine.Accept / Run). Every scan that finds a different set of COSTARs, and every change of choice, is in the
// journey (branch, PID, start time: never a window title, so never a customer).
//
// 1.1.9 (20 Nov 2026): eBay orders go into COSTAR Sydney (Br1) OR COSTAR Tempe (Br11), the branch Seb chose per order on
// the eBay page (EbayOrder.Branch). SydneyChoice is BranchChoice now: one per branch (EbayEngine keeps one for 1 and one
// for 11), each with exactly the rules above for its own branch (earliest start time, kept while valid, wait on a busy or
// unreadable one, a restart is a new process, the other branch seen twice a second apart drops it). A choice never returns
// an instance of another branch, and nothing here ever changes a COSTAR window's branch.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace TempeCostar {
    // One COSTAR process of this session as a scan saw it: its identity (PID, start time in UTC ticks, session) and its main
    // window's branch (from the title "COSTAR: 1 Tempe Tyres Sydney ...").
    internal sealed class CostarSeen {
        internal int Pid,Session,Branch;internal long Started,MainWindow;internal string Place="",Title="";internal bool OrderCheck;
        internal bool SameProcess(CostarSeen o) { return o!=null&&Pid==o.Pid&&Started==o.Started&&Session==o.Session; }
        internal string Label { get { return "Branch "+Branch+(Place.Length>0?" ("+Place+")":""); } }
        internal string Describe() { return Label+" PID "+Pid+" started "+EbayAutoCostar.Time(Started); }
        internal CostarInstance Instance() { return new CostarInstance(Pid,MainWindow,Started,Session,Title); }
    }
    internal static class EbayAutoCostar {
        // A process start time (UTC ticks) as local time with its offset: "2026-11-16 08:01:12 +11:00".
        internal static string Time(long utcTicks) {
            try { var local=new DateTimeOffset(new DateTime(utcTicks,DateTimeKind.Utc)).ToLocalTime();return local.ToString("yyyy-MM-dd HH:mm:ss zzz",CultureInfo.InvariantCulture); }
            catch(ArgumentException) { return "(unknown)"; }
        }
        // Pure: the earliest-started instance showing the branch (never Order Check's window); ties (never seen) by PID
        // then window, so the same scan always gives the same answer whatever order it came in.
        internal static CostarSeen Earliest(IEnumerable<CostarSeen> seen,int branch) {
            return seen.Where(s=>s!=null&&s.Branch==branch&&!s.OrderCheck).OrderBy(s=>s.Started).ThenBy(s=>s.Pid).ThenBy(s=>s.MainWindow).FirstOrDefault();
        }
        // The set of COSTARs a scan found, in one line (for the journey, written only when it changes).
        internal static string Summary(IList<CostarSeen> seen) {
            if(seen.Count==0) return "no COSTAR main window in this session";
            return seen.Count+" COSTAR in this session: "+String.Join("; ",seen.OrderBy(s=>s.Started).ThenBy(s=>s.Pid).Select(s=>s.Describe()+(s.OrderCheck?" (Order Check's, never used)":"")).ToArray());
        }
        internal static string Signature(IList<CostarSeen> seen) { return String.Join("|",seen.OrderBy(s=>s.Pid).ThenBy(s=>s.Started).Select(s=>s.Pid+"@"+s.Started+":"+s.Branch+(s.OrderCheck?"*":"")).ToArray()); }
        // The COSTAR processes of this Windows session with a COSTAR main window showing now (visible windows titled
        // "COSTAR: <branch> ..."; a process with several such windows counts once, by the window showing the branch wanted,
        // else its first). Read only: window titles and process identities, nothing pressed.
        internal static List<CostarSeen> Scan(int branch) {
            var found=new Dictionary<int,CostarSeen>();var identities=new Dictionary<int,ProcessIdentity>();
            string wip=OrderCheckLink.WipKey();
            Native.EnumWindows(delegate(IntPtr h,IntPtr unused) {
                if(!Native.IsWindowVisible(h)) return true;
                string title=Native.Caption(h);int b=Branches.OfMain(title);
                if(b==0) return true;
                int pid=(int)Native.Pid(h);ProcessIdentity identity;
                if(!identities.TryGetValue(pid,out identity)) { if(!LocalProcess.IsNamed(pid,"COSTAR",out identity)) identity=null;identities[pid]=identity; }
                if(identity==null) return true;
                CostarSeen had;
                if(found.TryGetValue(pid,out had)&&!(had.Branch!=branch&&b==branch)) return true;
                found[pid]=new CostarSeen {Pid=pid,Session=identity.Session,Started=identity.Started,MainWindow=h.ToInt64(),Branch=b,Place=Branches.Place(Branches.NameOfMain(title)),Title=title,OrderCheck=OrderCheckLink.Matches(wip,pid,identity.Started)};
                return true;
            },IntPtr.Zero);
            return found.Values.ToList();
        }
        // Whether that COSTAR process (PID and start time) is still running in this session.
        internal static bool Alive(CostarSeen c) {
            ProcessIdentity identity;
            return c!=null&&LocalProcess.IsNamed(c.Pid,"COSTAR",out identity)&&identity.Started==c.Started&&identity.Session==c.Session;
        }
    }
    // The choice for one branch, kept from one scan to the next (pure: the self-tests give it scans and say which processes
    // are alive). 1.1.9: was SydneyChoice; the same rules for Sydney (Br1) and Tempe (Br11), each its own BranchChoice.
    internal sealed class BranchChoice {
        internal readonly int Branch;
        // How far apart two looks showing another branch must be before the chosen COSTAR counts as changed.
        internal static readonly TimeSpan ConfirmAfter=TimeSpan.FromSeconds(1);
        internal CostarSeen Chosen;
        int otherReads,otherBranch;DateTime otherSince;
        // Why new orders wait on the chosen COSTAR right now (its title can't be read, or it may be changing branch), else null.
        internal string Waiting;
        internal BranchChoice(int branch) { Branch=branch; }
        // "Sydney (Br1)" / "Tempe (Br11)": the branch in words (EbayBranch.Name).
        internal string Name { get { return EbayBranch.Name(Branch); } }
        // The COSTAR new orders go into after this scan (null: none). change: what changed, for the journey ("" when nothing).
        internal CostarSeen Next(IList<CostarSeen> scan,Func<CostarSeen,bool> alive,DateTime now,out string change) {
            change="";Waiting=null;
            if(Chosen!=null) {
                var same=scan.FirstOrDefault(s=>s.SameProcess(Chosen));
                if(same==null) {
                    if(alive(Chosen)) {
                        // Still running, but no COSTAR main title of it could be read just now (busy, redrawing, a window of
                        // its own in front of its main one): it stays the choice; new orders wait for it.
                        otherReads=0;
                        Waiting="COSTAR "+Chosen.Label+" (PID "+Chosen.Pid+")'s window can't be read just now (busy, or another of its windows is in front): waiting for it (no other COSTAR is used meanwhile; close that COSTAR if it is no longer "+Name+")";
                        return Chosen;
                    }
                    bool reused=scan.Any(s=>s.Pid==Chosen.Pid&&s.Started!=Chosen.Started);
                    change="the chosen "+Chosen.Describe()+(reused?" restarted (a new COSTAR process has its PID)":" closed");
                    Chosen=null;otherReads=0;
                } else if(same.Branch==Branch) {
                    otherReads=0;
                    if(same.MainWindow!=Chosen.MainWindow) change="the chosen "+same.Describe()+" has a new main window (same process): kept";
                    Chosen=same;
                    return Chosen;
                } else {
                    if(otherReads==0||same.Branch!=otherBranch) { otherReads=1;otherBranch=same.Branch;otherSince=now; }
                    else otherReads++;
                    if(otherReads>=2&&now-otherSince>=ConfirmAfter) {
                        change="the chosen COSTAR PID "+Chosen.Pid+" (started "+EbayAutoCostar.Time(Chosen.Started)+") now shows "+same.Label+" (seen twice): it is no longer "+Name;
                        Chosen=null;otherReads=0;
                    } else {
                        Waiting="COSTAR PID "+Chosen.Pid+" (the chosen "+Name+") shows "+same.Label+" just now: looking again before choosing another "+Name;
                        return Chosen;
                    }
                }
            }
            // Earliest() keeps this branch only: a choice never returns an instance of another branch.
            var next=EbayAutoCostar.Earliest(scan,Branch);
            if(next!=null) {
                int count=scan.Count(s=>s.Branch==Branch&&!s.OrderCheck);
                change=(change.Length>0?change+"; ":"")+"chose "+next.Describe()+(count==1?" (the only "+Name+" open)":" (the earliest-started of "+count+" "+Name+" instances)");
                Chosen=next;
            } else if(change.Length>0) change+="; no other "+EbayBranch.Costar(Branch)+" is open: new orders wait for one";
            return Chosen;
        }
    }
}
