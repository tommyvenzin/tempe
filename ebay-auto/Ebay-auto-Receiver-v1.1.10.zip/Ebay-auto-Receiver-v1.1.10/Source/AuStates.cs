// 2.9.12 (Tommy, 18 Nov): a new customer's state for COSTAR's new-customer form. The state written in the customer's
// address comes first (a code or a full name; case, extra spaces and dots don't matter) and is never replaced by a
// lookup. Only when none is written is it looked up, by the customer's suburb AND postcode, in the address list
// (AuPlaceData), and used only when that suburb under that postcode is in exactly one state. Never from the postcode
// alone, its first digit, the store, or COSTAR's own default (NSW). No state: no account, as before.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace TempeCostar {
    internal static class AuState {
        internal static readonly string[] Codes={"NSW","VIC","QLD","SA","WA","TAS","NT","ACT"};
        static readonly Dictionary<string,string> Names=new Dictionary<string,string> {
            {"NEW SOUTH WALES","NSW"},{"VICTORIA","VIC"},{"QUEENSLAND","QLD"},{"SOUTH AUSTRALIA","SA"},{"WESTERN AUSTRALIA","WA"},
            {"TASMANIA","TAS"},{"NORTHERN TERRITORY","NT"},{"AUSTRALIAN CAPITAL TERRITORY","ACT"}};
        // The state a text is on its own, read as the eBay extension's stateCode and the Tempe Orders page read it: "NSW",
        // " nsw ", "N.S.W.", "N S W", "New  South Wales" are all NSW. Anything else (a place, "JBT", "Australia"): "".
        internal static string Code(string text) {
            string s=Regex.Replace((text??"").ToUpperInvariant().Replace(".",""),@"\s+"," ").Trim();
            string code;
            if(Names.TryGetValue(s,out code)) return code;
            string tight=s.Replace(" ","");
            return Array.IndexOf(Codes,tight)>=0?tight:"";
        }
        static readonly Dictionary<string,string> Words=new Dictionary<string,string> {{"SAINT","ST"},{"MOUNT","MT"},{"NORTH","NTH"},{"SOUTH","STH"}};
        // A place's name as the address list holds it (Tests/make-au-places.py writes it the same way): upper case,
        // apostrophes gone, "&" as AND, anything but letters and digits a space, single spaces, and Saint, Mount, North and
        // South as ST, MT, NTH and STH ("St. Peters", "Saint Peters" and "ST PETERS" are the same place).
        internal static string Place(string text) {
            var b=new StringBuilder();
            foreach(char ch in text??"") {
                char c=ch>='a'&&ch<='z'?(char)(ch-32):ch;
                if(c=='\''||c=='\u2019'||c=='\u2018'||c=='`') continue;
                if(c=='&') { b.Append(" AND ");continue; }
                b.Append((c>='A'&&c<='Z')||(c>='0'&&c<='9')?c:' ');
            }
            var words=new List<string>();
            foreach(string w in b.ToString().Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries)) {
                string m;
                words.Add(Words.TryGetValue(w,out m)?m:w);
            }
            return String.Join(" ",words.ToArray());
        }
    }

    // Where a new customer's state came from (AuPlaces.Resolve). State: one of the eight codes, or null (none to use).
    // Source: "address" (written in the customer's address) or "lookup" (the address list, by suburb and postcode); ""
    // with none. Why: why none was found, or (with "address") that the list puts this suburb and postcode elsewhere.
    // Never a customer's suburb, postcode or state, so it can go into the diagnostics.
    internal sealed class StateFound { internal string State,Source,Why; }

    internal static class AuPlaces {
        static Dictionary<string,Dictionary<string,List<string>>> table;
        static readonly object gate=new object();
        // The address list: postcode -> place (as AuState.Place writes it) -> its states. Read once, on first use.
        internal static Dictionary<string,Dictionary<string,List<string>>> Table {
            get {
                lock(gate) {
                    if(table!=null) return table;
                    var t=new Dictionary<string,Dictionary<string,List<string>>>(StringComparer.Ordinal);
                    foreach(string raw in AuPlaceData.Text.Split('\n')) {
                        string line=raw.TrimEnd('\r');
                        if(line.Length==0) continue;
                        int a=line.IndexOf(' '),b=a<0?-1:line.IndexOf(' ',a+1);
                        if(a!=4||b<0) throw new InvalidOperationException("The address list has a line it can't read.");
                        string postcode=line.Substring(0,4),state=line.Substring(a+1,b-a-1);
                        Dictionary<string,List<string>> places;
                        if(!t.TryGetValue(postcode,out places)) t[postcode]=places=new Dictionary<string,List<string>>(StringComparer.Ordinal);
                        foreach(string place in line.Substring(b+1).Split('|')) {
                            List<string> states;
                            if(!places.TryGetValue(place,out states)) places[place]=states=new List<string>();
                            if(!states.Contains(state)) states.Add(state);
                        }
                    }
                    table=t;
                    return t;
                }
            }
        }
        // The states the list has the suburb in under the postcode: null when the postcode isn't in the list, empty when
        // the suburb isn't under it.
        internal static List<string> States(string suburb,string postcode) {
            Dictionary<string,List<string>> places;
            if(!Table.TryGetValue(Order.Clean(postcode),out places)) return null;
            List<string> states;
            return places.TryGetValue(AuState.Place(suburb),out states)?new List<string>(states):new List<string>();
        }
        internal static StateFound Resolve(string state,string suburb,string postcode) {
            string written=Order.Clean(state);
            if(written.Length>0) {
                string code=AuState.Code(written);
                if(code.Length==0) return None("the state written in the address isn't one of the eight states and territories");
                List<string> listed=null;
                try { listed=States(suburb,postcode); } catch(InvalidOperationException) { }
                string why=listed!=null&&listed.Count>0&&!listed.Contains(code)?"the address list has this suburb and postcode in another state (the written state is kept)":null;
                return new StateFound {State=code,Source="address",Why=why};
            }
            string pc=Order.Clean(postcode);
            if(pc.Length==0) return None("no postcode to look it up by");
            if(!Regex.IsMatch(pc,@"^\d{4}$")) return None("the postcode isn't 4 digits");
            if(AuState.Place(suburb).Length==0) return None("no suburb to look it up by");
            List<string> states;
            try { states=States(suburb,pc); } catch(InvalidOperationException) { return None("the address list couldn't be read"); }
            if(states==null) return None("the postcode isn't in the address list");
            if(states.Count==0) return None("the suburb isn't in the address list under that postcode");
            if(states.Count>1) return None("that suburb and postcode are in more than one state");
            return new StateFound {State=states[0],Source="lookup"};
        }
        static StateFound None(string why) { return new StateFound {State=null,Source="",Why=why}; }
    }
}
