// eBay's requested Contact info number may be placed by COSTAR in any billing phone box.
// Mobile remains the lookup input target; matching never moves or overwrites phone fields.
using System;
using System.Collections.Generic;

namespace TempeCostar {
    internal static class EbayCustomerPhone {
        internal static string Match(string expected,string mobile,string home,string business) {
            string want=EbayPhoneChoice.Normalize(expected);
            if(want.Length<8) return "";
            foreach(string value in new[]{mobile,home,business})
                if(EbayPhoneChoice.Normalize(value)==want) return want;
            return "";
        }
        internal static string Value(FieldMap h,string expected) {
            return Read(h,expected,c=>c.Value);
        }
        internal static bool Matches(FieldMap h,string expected) { return Value(h,expected).Length>=8; }
        internal static string FieldName(FieldMap h,string expected) {
            string want=EbayPhoneChoice.Normalize(expected);
            if(want.Length<8) return "none";
            if(EbayPhoneChoice.Normalize(h.Phone.Value)==want) return "Mobile Ph";
            if(h.HomePhone!=null&&EbayPhoneChoice.Normalize(h.HomePhone.Value)==want) return "Home Ph";
            if(h.BusinessPhone!=null&&EbayPhoneChoice.Normalize(h.BusinessPhone.Value)==want) return "Bus Ph";
            return "none";
        }
        internal static string MatchedFields(FieldMap h,string expected) {
            string want=EbayPhoneChoice.Normalize(expected);var names=new List<string>();
            if(want.Length<8) return "";
            if(EbayPhoneChoice.Normalize(h.Phone.Value)==want) names.Add("Mobile Ph");
            if(h.HomePhone!=null&&EbayPhoneChoice.Normalize(h.HomePhone.Value)==want) names.Add("Home Ph");
            if(h.BusinessPhone!=null&&EbayPhoneChoice.Normalize(h.BusinessPhone.Value)==want) names.Add("Bus Ph");
            return String.Join(", ",names.ToArray());
        }
        internal static string Read(FieldMap h,string expected,Func<ControlInfo,string> read) {
            return Match(expected,read(h.Phone),h.HomePhone==null?"":read(h.HomePhone),h.BusinessPhone==null?"":read(h.BusinessPhone));
        }
        // Internal stability evidence only, never emitted to diagnostics: all three fields must settle.
        internal static string Signature(FieldMap h) {
            return h.Phone.Value+"|"+(h.HomePhone==null?"":h.HomePhone.Value)+"|"+(h.BusinessPhone==null?"":h.BusinessPhone.Value);
        }
    }
}
