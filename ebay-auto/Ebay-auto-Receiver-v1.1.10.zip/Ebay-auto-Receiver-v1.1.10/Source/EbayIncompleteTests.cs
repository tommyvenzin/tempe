using System;
using System.Collections.Generic;
using System.Linq;

namespace TempeCostar {
    internal static class EbayIncompleteTests {
        static void Check(bool value,string why) { if(!value)throw new InvalidOperationException(why); }
        static void Reject(Action action,string why) {
            bool rejected=false;try { action(); } catch(InvalidOperationException) { rejected=true; }
            Check(rejected,why);
        }
        internal static void Cases(Action<string,Action> Case) {
            Case("eBay incomplete: missing customer fields keep known details and financial/branch checks",()=>{
                var cases=new[] {
                    new {Change=(Action<EbayOrder>)(o=>o.buyer.name=""),Label="billing name from eBay Order/Buyer"},
                    new {Change=(Action<EbayOrder>)(o=>o.address.recipientName=""),Label="Ship to name"},
                    new {Change=(Action<EbayOrder>)(o=>o.address.street=""),Label="street address"},
                    new {Change=(Action<EbayOrder>)(o=>o.address.suburb=""),Label="suburb"},
                    new {Change=(Action<EbayOrder>)(o=>o.address.state=""),Label="state"},
                    new {Change=(Action<EbayOrder>)(o=>o.address.postcode=""),Label="postcode"}
                };
                foreach(var c in cases) {
                    var o=EbayTests.Sample();c.Change(o);string hash=o.ContentHash();o.Validate();
                    Check(o.MissingCustomerDetails().Contains(c.Label),"Missing field not reported: "+c.Label);
                    var entry=o.EngineOrder();Check(entry.customer.phone=="0400000001"&&entry.shipping.mobilePhone=="0400000001","Phone sources changed.");
                    Check(o.totalCents==15000&&o.Plan()[0].UnitCents==14000&&o.Branch==EbayBranch.Sydney,"Known order details changed.");
                    Check(o.ContentHash()==hash,"Checking missing details changed the received order.");
                    var bad=Wire.Copy(o);bad.totalCents++;Reject(()=>bad.Validate(),"Missing customer data weakened totals validation.");
                    bad=Wire.Copy(o);bad.items[0].sku="F";Reject(()=>bad.Validate(),"Missing customer data weakened SKU validation.");
                    bad=Wire.Copy(o);bad.branch=99;Reject(()=>bad.Validate(),"Missing customer data weakened branch validation.");
                }
            });
            Case("eBay incomplete: no invented names or state; account creation skips missing mandatory data",()=>{
                var o=EbayTests.Sample();o.buyer.name="";o.address.recipientName="DELIVERY RECIPIENT";
                o.address.street="";o.address.suburb="";o.address.state="";o.address.postcode="";o.buyer.email="";
                o.Validate();var entry=o.EngineOrder();
                Check(entry.customer.name==""&&entry.shipping.name=="DELIVERY RECIPIENT","Delivery name borrowed for billing.");
                Check(entry.customer.state==""&&entry.shipping.state==""&&entry.customer.StateFrom==null,"COSTAR/store state invented.");
                Check(entry.customer.streetAddress==""&&entry.customer.suburb==""&&entry.customer.email=="","Missing fields were invented.");
                var missing=NewAccount.Missing(entry.customer);
                Check(missing.Contains("name")&&missing.Contains("street address")&&missing.Contains("suburb")&&missing.Contains("state")&&missing.Contains("postcode"),"Account requirements lost missing fields.");
                Check(NewAccount.Decide(true,true,true,"",o.orderNumber,missing,false).StartsWith("missing: ",StringComparison.Ordinal),"Incomplete account would be created.");
                Check(o.MissingCustomerDetails().Count==5,"Missing order details list incorrect.");
                var complete=EbayTests.Sample();var c=complete.EngineOrder().customer;
                Check(NewAccount.Decide(true,true,true,"",complete.orderNumber,NewAccount.Missing(c),false)==NewAccount.Make,"Complete new customer no longer qualifies.");
            });
            Case("eBay incomplete: supplied malformed values and Contact info remain required",()=>{
                var changes=new Action<EbayOrder>[] {
                    o=>o.address.state="XX",o=>o.address.postcode="12",o=>o.address.postcode="ABCD",
                    o=>o.buyer.email="not-an-email",o=>o.phones.contact="",o=>o.buyer.name="LINE\nBREAK",
                    o=>o.address.street="LINE\nBREAK"
                };
                foreach(var change in changes) {var o=EbayTests.Sample();change(o);Reject(()=>o.Validate(),"Malformed or unsafe data accepted.");}
                var missingEmail=EbayTests.Sample();missingEmail.buyer.email="";missingEmail.Validate();
                Check(missingEmail.EngineOrder().customer.email=="","Missing optional email substituted.");
            });
            Case("eBay incomplete: supplied values must match; absent source fields stay unverified with CHECK BY HAND",()=>{
                EbayIncomplete.VerifyKnown("OLD ACCOUNT ADDRESS","","address");
                EbayIncomplete.VerifyKnown("SOMEONE IN COSTAR",null,"name");
                EbayIncomplete.VerifyKnown("TEST BUYER","test buyer","name");
                Reject(()=>EbayIncomplete.VerifyKnown("OLD ADDRESS","NEW ADDRESS","address"),"A supplied address mismatch was ignored.");
                var o=EbayTests.Sample();o.address.state="";o.Validate();
                Check(o.MissingCustomerDetails().Contains("state"),"Default NSW could be treated as a verified source state.");
                var checks=new List<string>{"Missing eBay customer details: "+String.Join(", ",o.MissingCustomerDetails().ToArray())+". Complete the missing details by hand."};
                string done=EbayFinish.Words("Sydney",false,true,new List<string>(),checks);
                Check(done.Contains("CHECK BY HAND")&&!done.Contains(EbayFinish.EzNext),"Incomplete customer reported as clean ez,next.");
            });
            Case("eBay incomplete: unresolved state queues without mutating payload or duplicating; online rules stay strict",()=>{
                var o=EbayTests.Sample();o.address.state="";o.address.suburb="Texas";o.address.postcode="4385";
                string hash=o.ContentHash();var q=new EbayQueue(null,s=>{});
                Check(q.Submit(o).status=="queued"&&q.Submit(Wire.Copy(o)).status=="queued"&&q.List().Count==1,"Incomplete order duplicated or refused.");
                Check(o.ContentHash()==hash&&o.EngineOrder().customer.state==""&&o.MissingCustomerDetails().Contains("state"),"Ambiguous state guessed or payload changed.");
                var found=EbayTests.Sample();found.address.state="";found.address.suburb="Tempe";found.address.postcode="2044";found.Validate();
                Check(found.EngineOrder().customer.state=="NSW"&&!found.MissingCustomerDetails().Contains("state"),"Unique lookup no longer resolves missing state.");
                var online=EbayTests.Sample().EngineOrder();online.orderId="TTW123";online.deliveryMethod="WITHIN AUSTRALIA";online.comment="DFE";online.shipping.suburb="";
                Reject(()=>online.Validate(false),"Shared online delivery validation was relaxed by the eBay change.");
            });
        }
    }
}
