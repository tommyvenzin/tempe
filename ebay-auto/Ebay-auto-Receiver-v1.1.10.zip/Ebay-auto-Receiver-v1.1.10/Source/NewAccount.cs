// 2.9.11 (Tommy, 17 Nov 2026): a COSTAR customer account for a new customer, made the way it is done by hand. When the phone
// lookup ends with COSTAR's "Customer Not found" notice (and nothing else) and Account# is still blank, X (the customer panel on
// the left of the Repair Order) is filled as before, then: the magnifier beside Account# (COSTAR's "Search for an Existing
// Customer"), its Add new (COSTAR's "Add new cash customer" form, which COSTAR fills from X), every required box checked
// against X and the order, OK, and the new account number confirmed on the Repair Order. COSTAR copies X into Y (Ship to) as
// it makes the account, so the delivery details go in after it. Mapped on 28 Oct and 17 Nov 14:34-14:42 (the maps are lengths
// only; claude/37-New-Customer-Account-Mapping.md).
// Only with every detail COSTAR's form asks for (a name of two or more words, street, suburb, state, postcode and phone): without
// one there is no account and the order goes on as before. COSTAR's own choices on the form are left as they are. OK is
// pressed at most once per order, ever (NewAccountLog): after an OK whose result can't be confirmed the order stops for a
// person, and no attempt of that order makes an account again. This file is pure (no COSTAR); Runner.NewAccount.cs presses.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace TempeCostar {
    internal static class NewAccount {
        // On unless switched off (the RDP helper's Files & settings tab, Ebay-auto's worker window: AppSettings.newAccounts).
        internal static volatile bool On=true;
        // The decision (Decide): Make, or why not (the order then goes on without an account, as before).
        internal const string Make="make",HasAccount="an account is on the order",NotNotice="the lookup didn't end with Customer Not found",
            Off="switched off",Mouse="direct presses are off",NoNumber="no order number",Tried="OK was pressed for this order before",
            NoRecord="the helper's record of accounts can't be read";
        // A stop after an OK whose result wasn't confirmed: its print (Runner.StopPrint) starts with this, and leaves out what
        // COSTAR changes as it makes an account (SamePrint).
        internal const string LoosePrint="new-account?|";

        // The words of a name as COSTAR keeps them: capitals, split at spaces and commas, every word kept, repeated ones too.
        internal static List<string> Words(string s) {
            var words=new List<string>();
            foreach(var w in Order.Norm(s).Replace(',',' ').Split(' ')) if(w.Length>0) words.Add(w);
            return words;
        }
        // The state the account step uses for this customer, and where it came from: the state written in the address (2.9.12),
        // else looked up by suburb and postcode (AuPlaces.Resolve), else none. 2.9.13: a state looked up when the order was
        // received (an online delivery, an eBay order: StateFrom "lookup") is a looked-up one here too.
        internal static StateFound AccountState(Customer c) {
            if(c==null) return new StateFound {State=null,Source="",Why="no customer details"};
            var found=AuPlaces.Resolve(c.state,c.suburb,c.postcode);
            if(found.State!=null && c.StateFrom=="lookup") return new StateFound {State=found.State,Source="lookup"};
            return found;
        }
        // 2.9.13: where an order's state came from when it was received (Customer.StateFrom, Shipping.StateFrom), in words.
        internal static string StateFromWords(string from) {
            return from=="lookup"?"looked up from its suburb and postcode in the address list ("+AuPlaceData.Source+")":from=="address"?"written in the address":"not looked at";
        }
        // 2.9.12: the order's customer with the state the account step uses (AuPlaces.Resolve: written, looked up, or none).
        internal static Customer WithState(Customer c,string state) {
            if(c==null) return null;
            return new Customer {name=c.name,streetAddress=c.streetAddress,address2=c.address2,suburb=c.suburb,state=state,postcode=c.postcode,phone=c.phone,email=c.email};
        }
        // What the order's own details lack for the form's required boxes (never COSTAR's defaults): empty when every one is
        // there. The names are for the person ("postcode", "state" ...).
        internal static List<string> Missing(Customer c) {
            var missing=new List<string>();
            if(c==null) { missing.Add("customer details");return missing; }
            int words=Words(c.name).Count;
            if(words<2) missing.Add(words==0?"name":"first and last name");
            if(Order.Clean(c.streetAddress).Length==0) missing.Add("street address");
            if(Order.Clean(c.suburb).Length==0) missing.Add("suburb");
            if(Order.Clean(c.state).Length==0) missing.Add("state");
            if(Order.Clean(c.postcode).Length==0) missing.Add("postcode");
            if(Order.Phone(c.phone).Length<8) missing.Add("phone");
            return missing;
        }
        // COSTAR's split of X's Name into the form's First name and Last name: both hold words, and together, First then Last or
        // Last then First, they are exactly the name's words in its order (none lost, none added, repeated words counted).
        internal static bool SplitKeeps(string name,string first,string last) {
            var n=Words(name);var f=Words(first);var l=Words(last);
            if(n.Count<2||f.Count==0||l.Count==0) return false;
            return f.Concat(l).SequenceEqual(n)||l.Concat(f).SequenceEqual(n);
        }
        // The same words, each as often, in any order: the name as COSTAR shows it once the account is made ("SMITH, JOHN").
        internal static bool SameWords(string a,string b) {
            var x=Words(a);var y=Words(b);
            if(x.Count==0||x.Count!=y.Count) return false;
            x.Sort(StringComparer.Ordinal);y.Sort(StringComparer.Ordinal);
            return x.SequenceEqual(y);
        }
        // The lookup ended with COSTAR's Customer Not found and nothing else: no list of accounts, no search of every branch
        // (with its Cancel), no popup cancelled, escaped or closed, no search cancelled. Those endings stay as they are.
        internal static bool NoticeOnly(bool notFound,bool chooser,bool branchesCancelled,int recoveries,int searchCancels) {
            return notFound&&!chooser&&!branchesCancelled&&recoveries==0&&searchCancels==0;
        }
        // In this order: an account on the order (kept, as before); not after Customer Not found (as before); switched off;
        // direct presses off (the step presses COSTAR's buttons directly); no order number (nothing to keep the account by);
        // details missing ("missing: postcode, state"); the record unreadable (tried null); OK pressed for this order before
        // (never again); else Make. tried is only read when everything before allows an account.
        internal static string Decide(bool on,bool direct,bool notice,string account,string orderId,List<string> missing,bool? tried) {
            if(Order.Clean(account).Length>0) return HasAccount;
            if(!notice) return NotNotice;
            if(!on) return Off;
            if(!direct) return Mouse;
            if(Order.Clean(orderId).Length==0) return NoNumber;
            if(missing!=null&&missing.Count>0) return "missing: "+String.Join(", ",missing.ToArray());
            if(tried==null) return NoRecord;
            if(tried.Value) return Tried;
            return Make;
        }
        // X (as COSTAR shows it) against the order: the required details must be what the order gave (COSTAR keeps capitals),
        // the phone the same digits, Account# blank. What differs, by name.
        internal static List<string> PanelProblems(CustomerPanel x,Customer c) {
            var p=new List<string>();
            if(Order.Clean(x.Account).Length>0) p.Add("Account# (not blank)");
            if(!Words(x.Name).SequenceEqual(Words(c.name))||Words(x.Name).Count<2) p.Add("name");
            if(!Same(x.Address,c.streetAddress)) p.Add("street address");
            if(!Same(x.Suburb,c.suburb)) p.Add("suburb");
            if(!Same(x.State,c.state)) p.Add("state");
            if(!Same(x.Postcode,c.postcode)) p.Add("postcode");
            if(Order.Phone(x.Phone).Length<8||Order.Phone(x.Phone)!=Order.Phone(c.phone)) p.Add("phone");
            return p;
        }
        // Both filled and the same (COSTAR's capitals and spacing aside).
        static bool Same(string a,string b) { return Order.Norm(a).Length>0&&Order.Norm(a)==Order.Norm(b); }
        // The form's required boxes against X (what COSTAR filled them from): First name and Last name together exactly the
        // name's words, Address = X's street, City = X's suburb, State/Province = X's state, Postcode = X's, one of the phone
        // boxes the order's phone, and COSTAR's own choice, a personal service file for the customer (its default), still
        // chosen. What isn't, by name: none, and OK may go.
        internal static List<string> FormProblems(NewAccountValues f,CustomerPanel x,Customer c) {
            var p=new List<string>();
            if(!SplitKeeps(x.Name,f.First,f.Last)) p.Add(Order.Clean(f.First).Length==0||Order.Clean(f.Last).Length==0?"first or last name empty":"first and last name don't hold the name's words");
            if(!Same(f.Address,x.Address)) p.Add(Order.Clean(f.Address).Length==0?"address empty":"address");
            if(!Same(f.City,x.Suburb)) p.Add(Order.Clean(f.City).Length==0?"city empty":"city");
            if(f.State==null) p.Add("state/province unreadable");
            else if(!Same(f.State,x.State)) p.Add(Order.Clean(f.State).Length==0?"state/province empty":"state/province");
            if(!Same(f.Postcode,x.Postcode)) p.Add(Order.Clean(f.Postcode).Length==0?"postcode empty":"postcode");
            string phone=Order.Phone(c.phone);
            bool phoned=phone.Length>=8&&new[]{f.Home,f.Mobile,f.Business,f.Fax}.Any(n=>Order.Phone(n)==phone);
            if(!phoned) p.Add(new[]{f.Home,f.Mobile,f.Business,f.Fax}.All(n=>Order.Phone(n).Length==0)?"phone numbers empty":"phone number");
            if(f.PersonalFile!=true) p.Add(f.PersonalFile==null?"the personal service file choice unreadable":"a personal service file not chosen");
            return p;
        }
        // What the Repair Order shows once OK went: null when the account is made (the form gone, nothing of COSTAR's over the
        // order, the order in front and free, Account# filled where it was blank, read the same twice, the same name's words
        // and the same phone), else what makes it uncertain.
        internal static string Uncertain(AfterOkLook o) {
            if(o.FormUp) return "COSTAR's new-customer form is still open";
            if(o.OtherWindow) return "another COSTAR window is open over the order";
            if(!o.OrderFront||!o.OrderEnabled) return "the Repair Order isn't back in front, free to use";
            if(Order.Clean(o.AccountBefore).Length>0) return "Account# wasn't blank before";
            if(Order.Clean(o.Account).Length==0) return "Account# is still blank";
            if(Order.Clean(o.Account)!=Order.Clean(o.AccountAgain)) return "Account# keeps changing";
            if(!SameWords(o.NameBefore,o.Name)) return "the customer name changed";
            if(Order.Phone(o.Phone)!=Order.Phone(o.OrderPhone)||Order.Phone(o.Phone).Length<8) return "the customer phone changed";
            return null;
        }
        // Whether the Repair Order holds what it held at a stop (the retry of that same Repair Order). After a stop with an OK
        // that wasn't confirmed (LoosePrint) Account#, the name's word order and Ship to (COSTAR copies X there as it makes the
        // account) aren't compared: the loose prints are (Selectors.OrderPrint). Otherwise the full prints, as before.
        internal static bool SamePrint(string stopped,string strict,string loose) {
            if(stopped==null) return false;
            if(stopped.StartsWith(LoosePrint,StringComparison.Ordinal)) return loose!=null&&LoosePrint+loose==stopped;
            return strict!=null&&strict==stopped;
        }
        // Whether an earlier attempt of this order pressed OK on COSTAR's new-customer form with no account confirmed (its
        // NewAccountLog state "pressed": the helper went before it could look, or "unsure"): COSTAR's windows over the order are
        // then left for a person. "made", "not sent" (OK couldn't be pressed, the form was cancelled), none, or a record that
        // can't be read ("?": no account is made then anyway): as before.
        internal static bool LeftUnsure(string state) { return state=="pressed"||state=="unsure"; }
    }

    // X as COSTAR shows it (the words read from its boxes).
    internal sealed class CustomerPanel { internal string Account,Name,Address,Suburb,State,Postcode,Phone; }
    // What the new-customer form showed: its boxes' words (State null: it couldn't be read) and COSTAR's personal service file
    // choice (null: couldn't be read).
    internal sealed class NewAccountValues {
        internal string Last,First,Address,City,State,Postcode,Home,Mobile,Business,Fax;
        internal bool? PersonalFile;
        internal string Print() { return String.Join("|",new[]{Last,First,Address,City,State??"?",Postcode,Home,Mobile,Business,Fax,PersonalFile==null?"?":PersonalFile.Value?"1":"0"}.Select(v=>Order.Norm(v)).ToArray()); }
    }
    // The Repair Order after OK (NewAccount.Uncertain).
    internal sealed class AfterOkLook {
        internal bool FormUp,OtherWindow,OrderFront,OrderEnabled;
        internal string AccountBefore,Account,AccountAgain,NameBefore,Name,Phone,OrderPhone;
    }

    // 2.9.14 (Tommy's diagnostics of 18 Nov 08:36): COSTAR draws a window it opens over the Repair Order in steps. At 08:15 its
    // customer search had 35 controls 0.27 s after the magnifier, not yet Add new or Cancel, and the step took it for "a window
    // that isn't its customer search" and stopped; 0.44 s after the press it had 58, Add new among them. A window the step
    // waits for (the customer search, the new-customer form) is now looked at again until it is that window, or it has
    // stayed the same for SettledMs without being it, or the step's time for it is up: only then is it "not that window".
    internal static class WindowLooks {
        internal const int SettledMs=1500,PauseMs=150;
        // One look at a window, to tell one still being drawn from one that has stopped changing: its controls (each by its
        // handle and kind), shown or not, usable or not, and their words.
        internal static string Print(List<ControlInfo> s) {
            if(s==null) return "";
            return s.Count+":"+String.Join("|",s.Select(c=>c.Handle+","+(c.Class??"")+","+(c.Visible?"1":"0")+(c.Enabled?"1":"0")+","+(c.Peek??"")).ToArray());
        }
        // look: the window's controls, every one read (null: it closed, or couldn't be read whole: the end). read: the window
        // known from them, or null (not that window, or not yet). elapsed: ms since the window opened; pause: PauseMs. What
        // read found, or null with why ("it stayed the same for … ms", "not within … ms", "it closed or couldn't be read") and
        // last, the last look (null if there was none).
        internal static T WhenComplete<T>(Func<List<ControlInfo>> look,Func<List<ControlInfo>,T> read,Func<long> elapsed,Action pause,int limitMs,
                out List<ControlInfo> last,out int looks,out string why) where T:class {
            last=null;looks=0;why=null;string print=null;long sameSince=0;
            while(true) {
                var s=look();
                if(s==null) { why="it closed or couldn't be read";return null; }
                looks++;last=s;
                var found=read(s);
                if(found!=null) return found;
                long now=elapsed();string p=Print(s);
                if(p!=print) { print=p;sameSince=now; }
                else if(now-sameSince>=SettledMs) { why="it stayed the same for "+(now-sameSince)+" ms";return null; }
                if(now>=limitMs) { why="not within "+limitMs+" ms";return null; }
                pause();
            }
        }
    }

    // COSTAR's "Search for an Existing Customer" (the magnifier beside Account#; mapped 28 Oct, and three times on 17 Nov: every
    // box empty but Branch, OK greyed, no rows; nothing copied from X): its words, one Add new, one Cancel, one OK. Null:
    // anything else.
    internal sealed class NewAccountSearch {
        internal ControlInfo AddNew,Cancel,Ok;
        internal static NewAccountSearch Read(string caption,List<ControlInfo> s) {
            if(s==null||!Order.Norm(caption).StartsWith("SEARCH",StringComparison.Ordinal)) return null;
            if(s.Count(c=>c.Static&&Order.Norm(c.Peek).StartsWith("SEARCH FOR AN EXISTING CUSTOMER",StringComparison.Ordinal))!=1) return null;
            var add=Button(s,"ADD NEW");var cancel=Button(s,"CANCEL");var ok=Button(s,"OK");
            if(add==null||cancel==null||ok==null||!add.Enabled||!cancel.Enabled) return null;
            return new NewAccountSearch {AddNew=add,Cancel=cancel,Ok=ok};
        }
        // The one visible button reading caption (& left out), or null.
        internal static ControlInfo Button(List<ControlInfo> s,string caption) {
            var found=s.Where(c=>c.Visible&&c.Class.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0&&c.TextState=="read"&&Order.Norm(c.Text).Replace("&","")==caption).ToList();
            return found.Count==1?found[0]:null;
        }
    }

    // COSTAR's "Add new cash customer" form (mapped 28 Oct and 17 Nov, 557 x 765): each box found by the label on its row (the
    // box starts at most 40 px right of the label's end, their middles at most 7 px apart, same parent panel), State/Province a
    // COSTAR drop-down whose words are in the panel inside it, the two choices of a personal service file or the CASH account,
    // OK and Cancel. Null: not that form, or laid out differently (nothing is pressed on it then but its Cancel).
    internal sealed class NewAccountForm {
        internal ControlInfo Last,First,Address,City,Postcode,Home,Mobile,Business,Fax,State,Ok,Cancel,PersonalFile,CashFile;
        internal static bool IsTitle(string caption) { return Order.Norm(caption)=="ADD NEW CASH CUSTOMER"; }
        // Whether a window's controls are this form's (its labels), whatever its title: never a customer list (AccountChooser).
        internal static bool Looks(List<ControlInfo> s) {
            if(s==null) return false;
            bool last=s.Any(c=>c.Static&&Order.Norm(c.Peek)=="LAST NAME"),first=s.Any(c=>c.Static&&Order.Norm(c.Peek)=="FIRST NAME");
            return (last&&first)||s.Any(c=>c.Static&&Order.Norm(c.Peek)=="CASH CUSTOMER!");
        }
        static ControlInfo Label(List<ControlInfo> s,string text) {
            var found=s.Where(c=>c.Static&&Order.Norm(c.Peek)==text).ToList();
            return found.Count==1?found[0]:null;
        }
        static bool Beside(ControlInfo label,ControlInfo c) {
            return c.X>=label.X+label.W-6&&c.X<=label.X+label.W+40&&Math.Abs((c.Y+c.H/2)-(label.Y+label.H/2))<=7;
        }
        static ControlInfo Box(List<ControlInfo> s,string label) {
            var l=Label(s,label);if(l==null) return null;
            var found=s.Where(c=>c.Edit&&c.Parent==l.Parent&&Beside(l,c)).ToList();
            return found.Count==1?found[0]:null;
        }
        // The State/Province drop-down: COSTAR's panel beside its label, and the panel inside it that holds its words (the
        // outer one when it has none inside).
        static ControlInfo Drop(List<ControlInfo> s,string label) {
            var l=Label(s,label);if(l==null) return null;
            var outer=s.Where(c=>c.Visible&&c.Class.IndexOf("WindowsForms10.Window",StringComparison.OrdinalIgnoreCase)>=0&&c.Parent==l.Parent&&Beside(l,c)&&c.W<=200&&c.H<=40).ToList();
            if(outer.Count!=1) return null;
            var inner=s.Where(c=>c.Visible&&c.Parent==outer[0].Handle&&c.Class.IndexOf("WindowsForms10.Window",StringComparison.OrdinalIgnoreCase)>=0).ToList();
            return inner.Count==1?inner[0]:inner.Count==0?outer[0]:null;
        }
        static ControlInfo Choice(List<ControlInfo> s,string starts) {
            var found=s.Where(c=>c.Visible&&c.Class.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0&&c.TextState=="read"&&Order.Norm(c.Text).StartsWith(starts,StringComparison.Ordinal)).ToList();
            return found.Count==1?found[0]:null;
        }
        internal static NewAccountForm Read(string caption,List<ControlInfo> s) {
            if(s==null||!IsTitle(caption)) return null;
            var f=new NewAccountForm {Last=Box(s,"LAST NAME"),First=Box(s,"FIRST NAME"),Address=Box(s,"ADDRESS"),City=Box(s,"CITY"),Postcode=Box(s,"POSTCODE"),
                Home=Box(s,"HOME"),Mobile=Box(s,"MOBILE"),Business=Box(s,"BUS."),Fax=Box(s,"FAX"),State=Drop(s,"STATE/PROVINCE"),
                Ok=NewAccountSearch.Button(s,"OK"),Cancel=NewAccountSearch.Button(s,"CANCEL"),
                PersonalFile=Choice(s,"OPEN A PERSONAL SERVICE FILE"),CashFile=Choice(s,"FILE SERVICE RECORD UNDER")};
            foreach(var c in new[]{f.Last,f.First,f.Address,f.City,f.Postcode,f.Home,f.Mobile,f.Business,f.Fax,f.State,f.Ok,f.Cancel,f.PersonalFile,f.CashFile}) if(c==null) return null;
            if(!f.Ok.Enabled||!f.Cancel.Enabled) return null;
            return f;
        }
        // Its Cancel alone (a form laid out differently): the one enabled button reading Cancel, or null.
        internal static ControlInfo CancelOnly(List<ControlInfo> s) {
            var c=NewAccountSearch.Button(s,"CANCEL");
            return c!=null&&c.Enabled?c:null;
        }
    }

    // Which orders an account was attempted for: OK was pressed on COSTAR's new-customer form ("pressed", kept before the
    // press; then "made" or "unsure"). An order found here never gets OK pressed again (NewAccount.Tried), whatever the result
    // was. Each order is kept as part of a SHA-256 of its number, never the number; in a DPAPI file of this Windows user
    // (PrivateFiles: the RDP helper's %LOCALAPPDATA%\TempeMobileCostar, Ebay-auto's EbayAuto), for KeepDays. Never shared.
    public sealed class AccountMark { public string key,state,atUtc; }
    public sealed class AccountMarks { public int schema=1;public List<AccountMark> marks=new List<AccountMark>(); }
    internal static class NewAccountLog {
        internal const int KeepDays=365,Most=5000;
        static readonly object gate=new object();
        internal static string FileName { get { return Path.Combine(PrivateFiles.Home,"new-accounts.dat"); } }
        internal static string Key(string orderId) {
            using(var sha=SHA256.Create()) {
                byte[] hash=sha.ComputeHash(Encoding.UTF8.GetBytes("tempe.new-account.v1|"+Order.Norm(orderId)));
                return BitConverter.ToString(hash).Replace("-","").Substring(0,32);
            }
        }
        static bool Fresh(AccountMark m,DateTime nowUtc) {
            DateTime at;
            if(m==null||!DateTime.TryParse(m.atUtc,CultureInfo.InvariantCulture,DateTimeStyles.AdjustToUniversal|DateTimeStyles.AssumeUniversal,out at)) return m!=null;   // unreadable time: kept (never again)
            return (nowUtc-at).TotalDays<=KeepDays;
        }
        // Pure: the order's mark (null: none, or older than KeepDays).
        internal static AccountMark Find(AccountMarks m,string key,DateTime nowUtc) {
            if(m==null||m.marks==null) return null;
            return m.marks.LastOrDefault(x=>x!=null&&x.key==key&&Fresh(x,nowUtc));
        }
        // Pure: the order marked (its state now), old marks dropped (KeepDays; the newest Most kept).
        internal static AccountMarks Mark(AccountMarks m,string key,string state,DateTime nowUtc) {
            var list=(m==null||m.marks==null?new List<AccountMark>():m.marks).Where(x=>x!=null&&x.key!=key&&Fresh(x,nowUtc)).ToList();
            list.Add(new AccountMark {key=key,state=state,atUtc=nowUtc.ToString("o",CultureInfo.InvariantCulture)});
            if(list.Count>Most) list=list.Skip(list.Count-Most).ToList();
            return new AccountMarks {marks=list};
        }
        // Pure: the order's state ("pressed", "unsure", "made", "not sent"; "?" when the mark has none), null when it has no mark.
        internal static string StateOf(AccountMarks m,string key,DateTime nowUtc) {
            var f=Find(m,key,nowUtc);
            return f==null?null:String.IsNullOrEmpty(f.state)?"?":f.state;
        }
        // The order's state now (StateOf); "?" when the record can't be read.
        internal static string State(string orderId) {
            try {
                lock(gate) {
                    var m=File.Exists(FileName)?PrivateFiles.Load<AccountMarks>(FileName):null;
                    return StateOf(m,Key(orderId),DateTime.UtcNow);
                }
            } catch(Exception) { return "?"; }
        }
        // Whether OK was pressed for this order before; null when the record can't be read (then no account is made).
        internal static bool? Tried(string orderId) {
            try {
                lock(gate) {
                    var m=File.Exists(FileName)?PrivateFiles.Load<AccountMarks>(FileName):null;
                    return Find(m,Key(orderId),DateTime.UtcNow)!=null;
                }
            } catch(Exception) { return null; }
        }
        // Kept on disk before it returns (flushed); throws when it can't be (OK isn't pressed then). A record that can't be
        // read is never written over.
        internal static void Record(string orderId,string state) {
            lock(gate) {
                var m=File.Exists(FileName)?PrivateFiles.Load<AccountMarks>(FileName):null;
                PrivateFiles.Save(FileName,Mark(m,Key(orderId),state,DateTime.UtcNow),true);
            }
        }
    }
}
