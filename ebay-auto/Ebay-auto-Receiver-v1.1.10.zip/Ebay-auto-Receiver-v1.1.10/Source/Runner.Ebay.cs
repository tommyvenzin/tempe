// The entry engine for eBay orders (2.5.0). A NEW Repair Order in COSTAR Sydney (Branch 1; Ebay-auto 1.1.9: or COSTAR
// Tempe, Branch 11: the order's own branch, the Runner's branch; every word names it via EbayBranch.Costar(branch)):
// customer by phone first, header (PO# = eBay order number, comment EBAY DFE), Ship to (the buyer,
// Ship Via DFE), Rebill to EBAY with the Card#, Written By and Salesperson SA, then the lines spaced
// as in Tommy's example (items at the eBay price, F, M E, M BUY, M DFE) and a final check.
// Built on the online delivery engine. Never saves, sells, prints or takes payment.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace TempeCostar {
    internal sealed class RebillMap { internal ControlInfo Code,Name,Card,Notes; }
    // Read-only layout rules for the parts of the Repair Order that only eBay orders use.
    internal static class EbaySelectors {
        static bool Near(int a,int b,int t){return Math.Abs(a-b)<=t;}
        static bool HasLabel(List<ControlInfo> s,string text){return s.Any(c=>c.Static&&Order.Norm(c.Peek)==text);}
        // The Rebill to tab is showing when its "Rebill to Customer" heading is (hidden tab pages
        // are not visible to Windows); Ship to when its Ship Via heading is and Rebill to's is not.
        internal static bool OnRebillTab(List<ControlInfo> s){return HasLabel(s,"REBILL TO CUSTOMER");}
        internal static bool OnShipToTab(List<ControlInfo> s){return HasLabel(s,"SHIP VIA")&&!HasLabel(s,"REBILL TO CUSTOMER");}
        // Rebill to Customer: a code box and a wider name box under the heading (like Account# and
        // Name), Card# under its heading, Rebill Notes under theirs (optional).
        internal static RebillMap Rebill(List<ControlInfo> s) {
            var label=Selectors.Label(s,"REBILL TO CUSTOMER",0);int t=Math.Max(4,label.H/3);
            var first=s.Where(c=>c.Edit&&c.Parent==label.Parent&&Near(c.Y,label.Y+label.H,t)).OrderBy(c=>c.X).ToList();
            Order.Require(first.Count==2&&first[0].W<first[1].W&&Near(first[0].X,label.X,t),"Rebill to's customer boxes are not laid out as expected (found "+first.Count+").");
            var cardLabels=s.Where(c=>c.Static&&Order.Norm(c.Peek)=="CARD#").ToList();
            Order.Require(cardLabels.Count==1,"Rebill to's Card# heading was not found.");
            var card=UnderLabel(s,cardLabels[0]);
            Order.Require(card!=null,"Rebill to's Card# box was not found.");
            var notesLabels=s.Where(c=>c.Static&&Order.Norm(c.Peek)=="REBILL NOTES").ToList();
            ControlInfo notes=null;
            if(notesLabels.Count==1){var l=notesLabels[0];int nt=Math.Max(4,l.H/3);var boxes=s.Where(c=>c.Visible&&c.Class.IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)>=0&&Near(c.X,l.X,nt+2)&&Near(c.Y,l.Y+l.H,nt+2)).ToList();if(boxes.Count==1)notes=boxes[0];}
            return new RebillMap {Code=first[0],Name=first[1],Card=card,Notes=notes};
        }
        // Written By and Salesperson as they are, for the stop/retry comparison (2.5.0 eBay runs):
        // a retry must not overwrite what someone changed there after the stop.
        internal static string StaffPrint(List<ControlInfo> s) {
            var b=new StringBuilder();
            foreach(var heading in new[]{"WRITTEN BY","SALESPERSON"}) { var box=UnderLabel(s,heading);b.Append(heading.Substring(0,1)).Append('=').Append(box==null?"-":Order.Norm(box.Value)).Append('|'); }
            return b.ToString();
        }
        // A box under its heading ("Written By", "Salesperson", "Terms"); null if not exactly one.
        internal static ControlInfo UnderLabel(List<ControlInfo> s,string text) {
            var labels=s.Where(c=>c.Static&&Order.Norm(c.Peek)==text).ToList();
            return labels.Count==1?UnderLabel(s,labels[0]):null;
        }
        static ControlInfo UnderLabel(List<ControlInfo> s,ControlInfo l) {
            int t=Math.Max(4,l.H/3);
            var same=s.Where(c=>c.Edit&&c.Parent==l.Parent&&Near(c.X,l.X,t)&&Near(c.Y,l.Y+l.H,t)).ToList();
            if(same.Count==1)return same[0];
            if(same.Count>1)return null;
            // A lookup box may sit in its own little panel under the heading: then by place alone.
            var any=s.Where(c=>c.Edit&&Near(c.X,l.X,t+2)&&Near(c.Y,l.Y+l.H,t+2)).ToList();
            return any.Count==1?any[0]:null;
        }
    }
    // The final check of an eBay order's lines, on one look at the grid: exactly the planned lines,
    // on their lines when spaced (in order otherwise), with the eBay quantities, prices and texts.
    internal static class EbayCheck {
        // Ebay-auto 1.0.0: skip, the planned lines left unresolved for Seb (an item COSTAR doesn't know): looked at and
        // described in notes, never checked; every other planned line is checked as below, and nothing else may be filled.
        internal static void Lines(List<ControlInfo> s,List<EbayLine> plan,bool spaced,ICollection<int> skip,List<string> notes) {
            if(skip==null||skip.Count==0) { Lines(s,plan,spaced);return; }
            var g=Selectors.ProductGrid(s);
            var filled=g.Rows.Where(r=>r.Value.Length>0).ToList();
            if(spaced) {
                Order.Require(g.Countable(),"Final check failed: COSTAR's item lines can't be counted.");
                var planned=new HashSet<int>(plan.Select(l=>l.Line));
                for(int i=0;i<g.Rows.Count;i++) if(g.Rows[i].Value.Length>0&&!planned.Contains(i+1)) throw new InvalidOperationException("Final check failed: line "+(i+1)+" holds "+Order.Norm(g.Rows[i].Value)+", which isn't in this eBay order.");
                foreach(var l in plan) {
                    var row=g.Rows[l.Line-1];
                    if(skip.Contains(l.Line)) { if(notes!=null) notes.Add("line "+l.Line+(row.Value.Length==0?" is empty":" shows "+Order.Norm(row.Value))+" (unresolved)");continue; }
                    Row(s,g,row,l,"line "+l.Line+" should hold ");
                }
                return;
            }
            int at=0;
            foreach(var l in plan) {
                if(skip.Contains(l.Line)) {
                    if(at<filled.Count&&Order.Norm(filled[at].Value)==l.Code) { if(notes!=null) notes.Add(l.Code+" is on the next line (unresolved)");at++; }
                    else if(notes!=null) notes.Add(l.Code+" is not on the Repair Order (unresolved)");
                    continue;
                }
                Order.Require(at<filled.Count,"Final check failed: "+l.Code+" is missing.");
                Row(s,g,filled[at],l,"the next line should be ");at++;
            }
            Order.Require(at==filled.Count,"Final check failed: the Repair Order has "+(filled.Count-at)+" more filled line(s) than this eBay order.");
        }
        // One planned line on its row: the code, and the quantity and price (items, freight) or the text (notes).
        static void Row(List<ControlInfo> s,Grid g,ControlInfo row,EbayLine l,string where) {
            Order.Require(Order.Norm(row.Value)==l.Code,"Final check failed: "+where+l.Code+".");
            if(l.Kind=="product"||l.Kind=="freight") {
                Order.Require(Selectors.Cell(s,row,g.Quantity).Value==l.Quantity.ToString(CultureInfo.InvariantCulture),"Final check failed: the quantity of "+l.Code+".");
                Order.Require(Selectors.Cents(Selectors.Cell(s,row,g.Net))==l.UnitCents,"Final check failed: the price of "+l.Code+" is not the eBay price.");
            } else if(l.Kind=="note") {
                Order.Require(Order.Norm(Selectors.Cell(s,row,g.Description).Value)==Order.Norm(l.Text),"Final check failed: the text of "+l.Code+".");
            }
        }
        internal static void Lines(List<ControlInfo> s,List<EbayLine> plan,bool spaced) {
            var g=Selectors.ProductGrid(s);
            var filled=g.Rows.Where(r=>r.Value.Length>0).ToList();
            if(filled.Count!=plan.Count) {
                // Codes only: what COSTAR has that the plan doesn't (a line it added by itself?) and back.
                var extra=filled.Select(r=>Order.Norm(r.Value)).ToList();foreach(var l in plan) extra.Remove(l.Code);
                var missing=plan.Select(l=>l.Code).ToList();foreach(var r in filled) missing.Remove(Order.Norm(r.Value));
                throw new InvalidOperationException("Final check failed: the Repair Order has "+filled.Count+" filled lines; this eBay order has "+plan.Count+"."+
                    (extra.Count>0?" Not in this eBay order: "+String.Join(", ",extra.Distinct().ToArray())+" (added by COSTAR?).":"")+(missing.Count>0?" Missing: "+String.Join(", ",missing.Distinct().ToArray())+".":"")+" Check the lines and the total by hand, then Mark done on the receiver.");
            }
            if(spaced) Order.Require(g.Countable(),"Final check failed: COSTAR's item lines can't be counted.");
            for(int i=0;i<plan.Count;i++) {
                var l=plan[i];var row=spaced?g.Rows[l.Line-1]:filled[i];
                Order.Require(Order.Norm(row.Value)==l.Code,"Final check failed: "+(spaced?"line "+l.Line+" should hold ":"the next line should be ")+l.Code+".");
                if(l.Kind=="product"||l.Kind=="freight") {
                    Order.Require(Selectors.Cell(s,row,g.Quantity).Value==l.Quantity.ToString(CultureInfo.InvariantCulture),"Final check failed: the quantity of "+l.Code+".");
                    Order.Require(Selectors.Cents(Selectors.Cell(s,row,g.Net))==l.UnitCents,"Final check failed: the price of "+l.Code+" is not the eBay price.");
                } else if(l.Kind=="note") {
                    Order.Require(Order.Norm(Selectors.Cell(s,row,g.Description).Value)==Order.Norm(l.Text),"Final check failed: the text of "+l.Code+".");
                }
            }
        }
    }
    internal sealed partial class Runner {
        EbayOrder ebay;bool spaced=true,rebillDone,writtenByDone,salespersonDone;
        internal EbayPhoneState EbayPhonesState;
        internal Action<EbayPhoneState> OnEbayPhoneState;
        void SaveEbayPhoneState(EbayPhoneState state) {
            // Persistence must succeed before typing a different phone or starting the account step.
            if(OnEbayPhoneState!=null) OnEbayPhoneState(state);
            EbayPhonesState=state;
            Diag.EventRaw("ebay_phone_source",state.phase+"; "+(state.complete?"lookup complete":"lookup starting")+"; customer-not-found-only="+state.noticeOnly);
        }
        bool LookupEbayPhones() {
            string phase=EbayPhonesState==null?EbayPhoneChoice.Contact:EbayPhonesState.phase;
            return EbayPhoneChoice.Run(ebay.phones,phase,delegate(string source,string phone) {
                Ready();var h=HeaderNow();
                // A saved matched account is never cleared to force another lookup.
                Order.Require(Order.Clean(h.Account.Value).Length==0 || EbayCustomerPhone.Matches(h,phone),
                    "COSTAR already has an account for a different phone. Check the customer before continuing.");
                SaveEbayPhoneState(new EbayPhoneState {phase=source});
                order.customer.phone=phone;lookupPhone=phone;
                lookupCancelled=false;sawChooser=false;chooserAttempts=0;chooserClock.Reset();
                notFoundShown=false;branchesCancelled=false;lookupNotFound=false;
                Say("Looking up the Contact info phone only.");
                // A retry can arrive with its account already loaded and the matching number in Home/Bus Ph.
                // Keep COSTAR's phone placement rather than typing into Mobile and triggering another lookup.
                if(Order.Clean(h.Account.Value).Length==0) {
                    Put(h.Phone,phone,"customer phone ("+source+")",true);
                    LookupCustomer(true);
                }
                var found=HeaderNow();
                Order.Require(CustomerEntry.LookupResolved(found.Account.Value,found.Name.Value,CustomerPhone(found),phone),"The customer changed after the phone lookup.");
                bool account=Order.Clean(found.Account.Value).Length>0;
                verifiedCustomerAccount=found.Account.Value;verifiedCustomerName=account?found.Name.Value:null;
                Diag.EventRaw("ebay_phone_lookup",source+": "+(account?"account found":"Account# blank"));
                Diag.EventRaw("ebay_billing_phone_field","Contact info matched X: "+EbayCustomerPhone.MatchedFields(found,phone)+"; phone fields preserved");
                return account;
            });
        }
        // 2.5.2: close the Repair Order once the order is in and nothing needs checking by hand (Closed: it did).
        // Ebay-auto 1.1.1 (Tommy, 17 Nov: Seb checks and closes every Repair Order himself): LeaveOpenWhenEntered: every step
        // before the close is still done (out of the item lines, PO# and total checked again), then the verified Repair
        // Order is LEFT OPEN, the close never sent (LeftOpen: it was, on purpose).
        internal bool CloseWhenEntered,Closed,LeaveOpenWhenEntered,LeftOpen;
        // While Rebill to may be showing: what the Repair Order showed just before (Ship to). A stop
        // there is compared with this on a retry; only Rebill to's own (hidden) boxes changed since.
        bool inRebill;string preRebillPrint;
        static bool Locked(ControlInfo c) { return (Native.GetWindowLong(new IntPtr(c.Handle),-16)&0x800)!=0; }
        // What the reviewer must still do by hand; the order is otherwise finished.
        internal readonly List<string> Checks=new List<string>();
        void CheckLater(string text){if(Checks.Contains(text))return;Checks.Add(text);Diag.EventRaw("ebay_check",text);Say("CHECK BY HAND: "+text);}
        internal void RunEbay(EbayOrder job) {
            List<EbayLine> plan=null;
            try {
                // 1.1.9: a stored 1.1.8 (v2) order is taken as Sydney's (Validate(true)); a new one names its branch, and
                // it goes only into a Repair Order of that branch (checked before anything is typed).
                Diag.Kind="ebay";ebay=job;job.Validate(true);NoteAddressStates();
                Order.Require(job.Branch==branch,"eBay order "+job.orderNumber+" is for "+EbayBranch.Costar(job.Branch)+", not Branch "+branch+": not entered (nothing typed).");
                var missingCustomer=job.MissingCustomerDetails();
                if(missingCustomer.Count>0) CheckLater("Missing eBay customer details: "+String.Join(", ",missingCustomer.ToArray())+". Known details will be entered; complete/check the rest by hand.");
                order.comment=EbayStock.Comment(order.comment,StockDecisions);
                if(OwnAttempt&&EbayPhonesState!=null) order.customer.phone=EbayPhoneChoice.Phone(job.phones,EbayPhonesState.phase);
                Order.Require(order.orderId==job.orderNumber,"The eBay order does not match this run.");
                plan=job.Plan();
                runClock.Restart();
                stageCount=5+plan.Count;
                Diag.BeginStage(FreshlyOpened?"Startup: wait for new Repair Order":"Startup: verify Repair Order");Stage("Opening the Repair Order");
                List<ControlInfo> initial;
                // No COSTAR window is dealt with on its own before the customer step: a retry (it can be
                // asked for from the eBay PC) stops if anything but the Repair Order is in front.
                enteringCustomer=false;
                if(FreshlyOpened) { Activate();initial=WaitForMobileStartup(); }
                else { ActivateAndWait();initial=Settled(Current()); }
                // Left on another tab (Rebill to after a stop, or Contacts / Notes by hand): back to Ship to
                // first, so the Repair Order can be read and compared with the stop. A tab click only.
                if(!EbaySelectors.OnShipToTab(initial)) {
                    if(ShowTab("Ship to",false)) initial=Settled(Current());
                    else Order.Require(!EbaySelectors.OnRebillTab(initial),"This Repair Order shows Rebill to and the helper could not switch it back to Ship to. Nothing was typed; click its Ship to tab, then Retry.");
                }
                Dump("before-controls",initial);Diag.Layout(initial);
                // The Repair Order this helper stopped this order in is only used again if it holds
                // exactly what it held at the stop (as for online orders).
                if(OwnAttempt) {
                    Order.Require(ResumePrint!=null,"The stopped attempt couldn't be recorded when it stopped, so this Repair Order isn't continued. Nothing was typed; finish it in "+EbayBranch.Costar(branch)+", then Mark done by hand on the receiver.");
                    // 2.9.11: after an unconfirmed OK on COSTAR's new-customer form, compared without Account#, the name's word
                    // order and Ship to (SameAsStop): whatever account COSTAR put on the order is then kept.
                    string now;bool same=SameAsStop(out now);
                    if(!same) Diag.EventRaw("resume_changed",now==null?"could not read it steadily":"held "+ResumePrint.Length+" chars at the stop, "+now.Length+" now");
                    Order.Require(same,"This Repair Order changed after the helper stopped (or couldn't be read steadily), so it isn't continued. Nothing was typed; finish it in "+EbayBranch.Costar(branch)+", then Mark done by hand on the receiver.");
                    ResumeVerified=true;
                }
                bool resuming=false;
                if(!FreshlyOpened && Selectors.SameOrderInProgress(initial,order,true)) {
                    Order.Require(OwnAttempt,"This Repair Order already holds eBay order "+order.orderId+" (same PO# and phone), but this helper didn't start it, so it isn't continued. Nothing was typed.");
                    resuming=true;
                }
                if(resuming) Say("This Repair Order already holds eBay order "+order.orderId+" from the earlier attempt. Continuing where it stopped.");
                else if(OwnAttempt && Selectors.SameCustomerStart(initial,order,true)) {
                    // Stopped before PO# went in (the phone lookup is a common place): this unchanged Repair
                    // Order is this order's own, so the buyer is looked up again here, as for online orders.
                    Diag.EventRaw("same_customer_start","the Repair Order it stopped in holds this buyer's phone and no items");
                    Say("This Repair Order already holds this order's buyer and no items (where it stopped). Looking the phone up again, then filling the rest.");
                } else {
                    try { Selectors.Blank(initial,branch);Selectors.BlankDelivery(initial,branch); }
                    catch(InvalidOperationException busy) {
                        // Only an earlier Repair Order nothing was typed into may be swapped for a new one.
                        if(OwnAttempt) throw new InvalidOperationException("The Repair Order this order stopped in can't be continued from where it stopped. Nothing was typed; finish it in "+EbayBranch.Costar(branch)+", or close it without saving and use Start again on the receiver.");
                        if(writes==0 && !FreshlyOpened) throw new RepairOrderInUseException(busy.Message);
                        throw;
                    }
                    Say("Verified an empty Repair Order in Branch "+branch+". Looking up the buyer's phone first.");
                }
                Diag.EndStage(true);
                enteringCustomer=true;
                bool existing=false;
                if(OwnAttempt&&EbayPhonesState!=null&&EbayPhonesState.complete) Timed("Resume: customer already looked up",delegate {
                    // 2.9.11: after an unconfirmed OK on COSTAR's new-customer form, Account# read the same twice (SteadyAccount).
                    var current=AfterUnsureStop?SteadyAccount():HeaderNow();lookupPhone=order.customer.phone;
                    verifiedCustomerAccount=current.Account.Value;existing=Order.Clean(current.Account.Value).Length>0;
                    if(existing)verifiedCustomerName=current.Name.Value;
                    Order.Require(CustomerEntry.LookupResolved(current.Account.Value,current.Name.Value,CustomerPhone(current),order.customer.phone),"The saved eBay customer phone no longer matches the Repair Order.");
                    lookupNotFound=!existing&&EbayPhonesState.noticeOnly;
                    Diag.EventRaw("ebay_phone_resume",EbayPhonesState.phase+": "+(existing?"account kept":"Account# blank; main phone kept"));
                    Diag.EventRaw("ebay_billing_phone_field","Contact info matched X on resume: "+EbayCustomerPhone.MatchedFields(current,order.customer.phone)+"; phone fields preserved");
                    Say(existing?"Customer account already on the order; keeping it.":"No customer account on the order; checking the entered details.");
                });
                else Timed("Customer phone lookup",delegate {
                    existing=LookupEbayPhones();
                    SaveEbayPhoneState(new EbayPhoneState {phase=EbayPhonesState.phase,complete=true,noticeOnly=lookupNotFound});
                    Say(existing?"Matched phone; keeping COSTAR's account and using the eBay order's Buyer name in billing.":"No matching customer; entering the buyer's details.");
                });
                Timed("Customer, header and Ship to",delegate {
                    FillOnlineHeader(existing);
                    // 2.9.11: a new buyer (Customer Not found, every detail given): COSTAR's account made after X, then X checked
                    // again (COSTAR's account number kept, the order's Buyer name restored) before Ship to goes in.
                    if(!existing&&MaybeMakeAccount()) FillOnlineHeader(true,false);
                    FillDelivery();
                    CustomerFormReady(0);
                    var confirmed=HeaderNow();
                    Order.Require(CustomerEntry.SameIdentity(confirmed.Account.Value,confirmed.Name.Value,CustomerPhone(confirmed),verifiedCustomerAccount,verifiedCustomerName,order.customer.phone),"The selected customer account/name/phone changed during entry.");
                });
                enteringCustomer=false;
                // Rebill to before the lines: an account COSTAR rebills to may bring its own pricing
                // or terms, and the eBay prices then go in over whatever it brought.
                Timed("Rebill to EBAY",delegate { FillRebill(); });
                Timed("Written By and Salesperson",delegate { FillStaff(); });
                spaced=SpacedLines();
                foreach(var line in plan) { var l=line;currentLine=l;Timed(l.Label,delegate { EnterEbayLine(l,plan,resuming); });doneLines.Add(l.Line); }
                currentLine=null;
                // Ebay-auto 1.0.0: an item COSTAR doesn't know was left for Seb: a last look, then handed over (never closed).
                if(HandOffUnknownItems&&Unresolved.Count>0) { FinishHandoff(plan);return; }
                Diag.BeginStage("Final verification and report");Stage("Final check");Ready();var final=Current();VerifyEbay(final,plan);Dump("after-controls",final);
                int total=Selectors.Total(final);
                if(CloseWhenEntered) CloseEntered(total); // never throws: closed, or a CHECK BY HAND note
                else if(LeaveOpenWhenEntered) {
                    CloseEntered(total,false); // never throws: left open on purpose, or a CHECK BY HAND note
                    // Ebay-auto 1.1.6: its number copied for Seb with DFE (never throws: not copied is a CHECK BY HAND note).
                    CopyRoNumber();
                }
                // From here on nothing may turn an entered (maybe closed) order into a stopped one.
                try {
                    File.WriteAllText(Path.Combine(Folder,"review.json"),json.Serialize(new{Kind="ebay",OrderId=order.orderId,EbayTotalCents=order.totalCents,CostarTotalCents=total,Branch=branch,Spaced=spaced,RebillFilled=rebillDone,Closed=Closed,LeftOpen=LeftOpen,
                        CustomerEntryMode="Contact info only; Ship to phone is delivery contact only",PhoneSource=EbayPhonesState.phase,CustomerPopupRecoveryActions=recoveryActions,CustomerLookupCancelled=lookupCancelled,NewAccount=NewAccountResult,NewAccountState=NewAccountState,BillingStateFrom=BillingStateFrom,DeliveryStateFrom=DeliveryStateFrom,
                        RoNumber=RoNumberCopied,RoNumberOutcome=RoNumberOutcome,RoNumberShape=RoNumberShape,Checks=Checks.ToArray()}),new UTF8Encoding(false));
                } catch(Exception e) { Diag.EventRaw("review_file",e.GetType().Name); }
                Say("READY FOR REVIEW - eBay "+order.orderId+" - total $"+(total/100m).ToString("0.00",CultureInfo.InvariantCulture)+" in COSTAR Branch "+branch+(Closed?". Repair Order closed (in Work-in-Progress).":LeftOpen?". Repair Order left open on purpose for a person to check and close"+(RoNumberCopied!=null?"; its number is on the clipboard with DFE.":"."):". Repair Order left open."));
                Diag.ChecksByHand=Checks.Count;Diag.EndStage(true);Diag.Completed();
            } catch(Exception error) {
                // Ebay-auto 1.0.0: after an item was left unresolved (or while one was being dealt with) a stop is a hand-over.
                bool handoff=HandOffUnknownItems&&(Unresolved.Count>0||error is EbayHandoffException);
                if(handoff) StopHandoff(plan,error); else Diag.Stopped(error);
                TraceFocus("Stopped run",null);
                Say((handoff?"HANDED OVER at ":"STOPPED: ")+error.Message);
                try { if(!process.HasExited && Native.IsWindow(root)) { bool saved=Cancel; Cancel=false; try {
                    CaptureForegroundWindow(error.Message);var stopped=Snapshot(root);Dump("stopped-controls",stopped);
                    if(writes>0 || ResumeVerified) {
                        // Stopped while Rebill to shows (Stop pressed, or a COSTAR window after EBAY): nothing is
                        // clicked now; the Repair Order as it was just before Rebill to is what a retry checks.
                        bool rebillShowing=false;try{rebillShowing=EbaySelectors.OnRebillTab(stopped);}catch(Exception){}
                        try { StopPrint=inRebill&&rebillShowing?preRebillPrint:StopPrintNow(); } catch(Exception) { StopPrint=null; }
                        if(inRebill&&rebillShowing) Diag.EventRaw("stop_on_rebill",preRebillPrint==null?"no earlier print":"the print from before Rebill to is kept");
                    } } finally { Cancel=saved; } } } catch { }
                if(handoff) throw new EbayHandoffException(HandoffMessage,error);
                throw;
            } finally { log.Flush(); }
        }
        // 2.5.2 (Tommy, 26 Oct): an eBay order that is in and needs nothing by hand has its Repair Order
        // closed, as Next Order closes a reviewed phone job: the window's own close (WM_CLOSE), nothing
        // saved, sold or printed; COSTAR keeps it in Work-in-Progress. First out of the item lines, as a
        // person's click on Close does, so COSTAR keeps the last line (the PO# field is clicked, its text
        // unchanged); then only this order's Repair Order, in front with nothing else open and the total
        // as checked. Anything COSTAR asks on closing is never answered: the order is in, and a CHECK BY
        // HAND note says to close it by hand.
        void CloseEntered(int total) { CloseEntered(total,true); }
        // close false (Ebay-auto 1.1.1): the same steps and checks, then the Repair Order is left open on purpose: no
        // WM_CLOSE, and no "close it by hand" note (it is meant to be closed by hand). A check that finds something (the
        // total changed once the last line was committed) is still a CHECK BY HAND; a step that couldn't be done after
        // the order was verified is only recorded.
        void CloseEntered(int total,bool close) {
            if(Checks.Count>0) { Say("Repair Order left open: something needs checking by hand."); return; }
            try {
                LeaveGrid(close?"before closing":"before leaving it open");
                Ready();Check(true);var now=Current();
                Order.Require(Order.Clean(Selectors.Header(now).PO.Value)==Order.Clean(order.orderId),"the Repair Order in front no longer shows this order's PO#");
                // 2.8.0: an online pickup's Customer Waiting, ticked last, still ticked now its box has been left (COSTAR
                // takes a tick in then).
                if(waitingBox!=IntPtr.Zero) {
                    int role;bool on;
                    if(!TickState(waitingBox,out role,out on)||role!=44||!on) {
                        Diag.EventRaw("customer_waiting","not kept before closing");
                        CheckLater(close?"Customer Waiting didn't stay ticked, so the Repair Order was left open: tick it by hand.":"Customer Waiting didn't stay ticked: tick it by hand.");
                        return;
                    }
                }
                int after=Selectors.Total(now);
                if(after!=total) {
                    Diag.EventRaw("ebay_close_total",total+" -> "+after);
                    CheckLater("COSTAR's total changed from $"+(total/100m).ToString("0.00",CultureInfo.InvariantCulture)+" to $"+(after/100m).ToString("0.00",CultureInfo.InvariantCulture)+" after the last line was committed"+(close?", so the Repair Order was left open":"")+": check it by hand.");
                    return;
                }
                if(!close) {
                    LeftOpen=true;Diag.EventRaw("ebay_left_open","verified, out of the item lines, PO# and total checked again; left open on purpose for a person to check and close (close after entry is off)");
                    Say("Verified. The Repair Order is left open for you to check and close (close after entry is off).");
                    return;
                }
                UIntPtr result;Native.WriteMessage(root,0x10,UIntPtr.Zero,null,3,1000,out result);
                var timer=Stopwatch.StartNew();
                while(timer.ElapsedMilliseconds<8000) {
                    if(!Native.IsWindow(root)) { Closed=true;Diag.EventRaw("ebay_closed",timer.ElapsedMilliseconds+" ms");Say("Closed the Repair Order (it stays in COSTAR's Work-in-Progress).");return; }
                    System.Threading.Thread.Sleep(100); // not Pause: its checks fail once the window has gone
                }
                Diag.EventRaw("ebay_close_open","still open after 8 s");
                CheckLater("COSTAR didn't close the Repair Order (it may be asking something). Nothing was answered: check it and close it by hand.");
            } catch(OperationCanceledException) {
                if(!close) { LeftOpen=true;Diag.EventRaw("ebay_left_open","verified; left open on purpose; the look after leaving the item lines was skipped: stop pressed");return; }
                Diag.EventRaw("ebay_close_skipped","stop pressed");
                CheckLater("The Repair Order wasn't closed because Stop was pressed. Close it by hand.");
            } catch(Exception e) {
                // The helper's own words only (no order details) go to the run diagnostics.
                if(!close) { LeftOpen=true;Diag.EventRaw("ebay_left_open","verified; left open on purpose; the look after leaving the item lines was skipped: "+e.GetType().Name+": "+e.Message);return; }
                Diag.EventRaw("ebay_close_skipped",e.GetType().Name+": "+e.Message);
                CheckLater("The Repair Order wasn't closed: COSTAR wasn't ready for it (another window may be open). Close it by hand.");
            }
        }
        // ---- Rebill to ----
        // EBAY in Rebill to Customer (COSTAR fills EBAY PAYMENTS, its note and Terms 7INV), the order
        // number and date in Card#. Rebill to is a tab next to Ship to: the helper switches there and
        // back. A tab it can't open is left for the reviewer (nothing was typed there).
        void FillRebill() {
            string byHand="Enter EBAY and Card# "+ebay.CardNumber+" there.";
            preRebillPrint=SettledPrint();inRebill=true;
            if(!ShowTab("Rebill to",true)) {
                // A tab that didn't open must leave Ship to showing (a late switch, or another tab).
                Order.Require(ShowTab("Ship to",false),"The helper could not show COSTAR's Ship to tab again after trying Rebill to. Entry stopped; check which tab is showing.");
                inRebill=false;
                CheckLater("Rebill to was not filled: the helper could not open COSTAR's Rebill to tab. "+byHand);return;
            }
            RebillMap m;
            try { m=EbaySelectors.Rebill(Settled(Current())); }
            catch(InvalidOperationException e) {
                // Nothing typed there yet: leave Rebill to for the reviewer and carry on.
                Diag.EventRaw("rebill_layout",e.Message);
                Order.Require(ShowTab("Ship to",false),"The helper could not switch COSTAR back from Rebill to to Ship to. Entry stopped; check the order.");
                inRebill=false;
                CheckLater("Rebill to was not filled: "+e.Message+" "+byHand);return;
            }
            string leave=null;
            try {
                string code=ReadLive(m.Code);
                if(Locked(m.Code)||Locked(m.Card)) leave="Rebill to's boxes are locked on this Repair Order. "+byHand;
                else if(code.Length>0 && Order.Norm(code)!=EbayOrder.RebillCode) {
                    // A new Repair Order's own value is replaced; in the one it stopped in it may be Tommy's.
                    if(OwnAttempt) leave="Rebill to shows "+code+" (not EBAY) in the Repair Order it stopped in: left as it is. Check it.";
                    else Say("Rebill to showed "+code+"; replacing it with EBAY.");
                }
                if(leave==null) {
                    if(Order.Norm(code)!=EbayOrder.RebillCode) PutMapped(m.Code,EbayOrder.RebillCode,"Rebill to customer");
                    else Say("Rebill to already shows EBAY.");
                    string name=WaitRebillName();
                    Order.Require(Order.Norm(name).Contains("EBAY"),"After EBAY, COSTAR's Rebill to shows \""+name+"\". Entry stopped; check Rebill to.");
                    Say("Rebill to: EBAY ("+name+").");
                    m=EbaySelectors.Rebill(Current());
                    string card=ReadLive(m.Card);
                    if(OwnAttempt && card.Length>0 && Order.Norm(card)!=Order.Norm(ebay.CardNumber))
                        CheckLater("Card# shows "+card+" in the Repair Order it stopped in: left as it is (this order's is "+ebay.CardNumber+").");
                    else {
                        PutMapped(m.Card,ebay.CardNumber,"Card#");
                        m=EbaySelectors.Rebill(Current());
                        Order.Require(Order.Norm(ReadLive(m.Code))==EbayOrder.RebillCode&&Order.Norm(ReadLive(m.Card))==Order.Norm(ebay.CardNumber),"Rebill to did not keep EBAY and the Card#. Entry stopped; check Rebill to.");
                    }
                    if(m.Notes!=null) { string notes;bool read=Native.TryText(new IntPtr(m.Notes.Handle),out notes);Diag.EventRaw("rebill_notes",!read?"not readable":Order.Clean(notes).Length>0?"filled":"empty"); }
                    rebillDone=true;
                }
            } catch(Exception e) {
                // A window COSTAR opened for EBAY (an account list, a notice): named in the stop, captured.
                var front=Native.GetForegroundWindow();
                if(!(e is OperationCanceledException) && front!=root && front!=IntPtr.Zero && Native.Pid(front)==pid)
                    throw new InvalidOperationException("COSTAR opened a window (\""+Sanitize.Text(Native.Caption(front),40)+"\") while Rebill to was being filled. It is captured in the report. Close it, fill Rebill to by hand (EBAY, Card# "+ebay.CardNumber+"), click Ship to, then Retry: the helper carries on with the rest.",e);
                // Back to Ship to if possible (not after Stop), so the stop is recorded as usual.
                try { if(!Cancel && ShowTab("Ship to",false)) inRebill=false; } catch(Exception) { }
                throw;
            }
            Order.Require(ShowTab("Ship to",false),"The helper filled Rebill to but could not switch COSTAR back to Ship to. Entry stopped; check the order.");
            inRebill=false;
            if(leave!=null) CheckLater(leave);
        }
        // COSTAR looks the rebill account up when EBAY is committed: wait for its name (two equal reads).
        string WaitRebillName() {
            var wait=Diag.Wait("rebill_lookup");
            try {
                var timer=Stopwatch.StartNew();string previous=null;
                while(timer.ElapsedMilliseconds<8000) {
                    wait.Tick();Ready();
                    try {
                        var m=EbaySelectors.Rebill(Current());string name=ReadLive(m.Name);
                        if(name.Length>0&&name==previous){wait.Done("ok");return name;}
                        previous=name.Length>0?name:null;
                    } catch(InvalidOperationException) { previous=null; }
                    Pause(60);
                }
                wait.Done("timeout");
                throw new InvalidOperationException("COSTAR did not fill Rebill to's name after EBAY (is EBAY the rebill account in this branch?). Entry stopped; check Rebill to.");
            } finally { wait.End(); }
        }
        // ---- Tabs (Ship to | Rebill to | Contacts | Notes) ----
        // Place: its place among the tab control's tabs as accessibility lists them (-1: not known).
        sealed class PageTab { internal IntPtr Strip;internal int Left,Top,Width,Height,Place=-1; }
        bool OnTab(List<ControlInfo> s,bool rebill){return rebill?EbaySelectors.OnRebillTab(s):EbaySelectors.OnShipToTab(s);}
        // Shows a tab of the Ship to / Rebill to strip: a click on the tab's name where Windows'
        // accessibility says it is (the way a person does it); then, for a Windows tab control only,
        // Ctrl+Tab / Ctrl+Shift+Tab from a box on the page. Each way is checked by what is showing.
        bool ShowTab(string name,bool rebill) {
            Ready();
            if(OnTab(Current(),rebill)) return true;
            List<IntPtr> strips;var tab=FindPageTab(name,out strips);
            // 2.6.5: the tab shown directly (TCM_SETCURFOCUS: COSTAR is told as by a click on it), when the tab
            // control has that many tabs; what shows is checked, and a click follows if it isn't that page.
            int at=tab!=null&&tab.Strip!=IntPtr.Zero&&Direct.On?TabIndex(tab.Strip,tab.Place):-1;
            if(at>=0) {
                Check(true);WaitIdle(2000);
                bool answered=Direct.ShowTab(tab.Strip,at,2000);Diag.Pressed();
                if(WaitTab(rebill,3000)) { Diag.EventRaw("tab_switch",name+": direct"); return true; }
                Diag.EventRaw("direct_fallback","tab "+name+": "+(answered?"shown, but its page didn't show":"COSTAR didn't answer")+", a click instead");
            }
            if(tab!=null) {
                ClickPageTab(tab);
                if(WaitTab(rebill,3000)) { Diag.EventRaw("tab_switch",name+": click"); return true; }
                Diag.EventRaw("tab_switch",name+": the click did not show it");
            }
            if(strips.Count>0) {
                var s=Current();
                ControlInfo inside=null;
                try { inside=rebill?Selectors.ShipVia(s):EbaySelectors.Rebill(s).Card; } catch(InvalidOperationException) { inside=null; }
                if(inside!=null && IsInside(new IntPtr(inside.Handle),strips)) {
                    Focus(inside);Check(true);
                    if(rebill) Native.Chord(0x11,0x09); else Native.Chord(0x11,0x10,0x09);
                    Diag.Key();
                    if(WaitTab(rebill,3000)) { Diag.EventRaw("tab_switch",name+": keyboard"); return true; }
                    Diag.EventRaw("tab_switch",name+": the keyboard did not show it");
                }
            }
            return false;
        }
        bool WaitTab(bool rebill,int ms) {
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<ms) { Ready(); if(OnTab(Current(),rebill)) return true; Pause(60); }
            return false;
        }
        static bool IsInside(IntPtr h,List<IntPtr> strips) {
            for(IntPtr p=Native.GetParent(h);p!=IntPtr.Zero;p=Native.GetParent(p)) if(strips.Contains(p)) return true;
            return false;
        }
        // The tab with this name on COSTAR's tab control(s): Windows tab controls first, then (for a
        // drawn-by-itself strip) the Repair Order's accessibility tree. Exactly one match, else null.
        PageTab FindPageTab(string name,out List<IntPtr> strips) {
            var found=new List<PageTab>();var shapes=new List<string>();var list=new List<IntPtr>();
            Native.EnumChildWindows(root,delegate(IntPtr h,IntPtr unused){if(Native.IsWindowVisible(h)&&Native.Class(h).IndexOf("SysTabControl32",StringComparison.OrdinalIgnoreCase)>=0)list.Add(h);return list.Count<20;},IntPtr.Zero);
            strips=list;
            foreach(var strip in list) {
                Accessibility.IAccessible acc=null;
                try {
                    acc=Msaa.FromWindow(strip);
                    int index=-1;
                    foreach(object child in Msaa.Children(acc,40)) {
                        try {
                            if(Msaa.RoleOf(acc,child)!=Msaa.RolePageTab) continue;
                            index++;   // the tab control's tabs, in their order
                            if(Order.Norm(Msaa.NameOf(acc,child))!=Order.Norm(name)) continue;
                            int l,t,w,hh;if(Msaa.LocationOf(acc,child,out l,out t,out w,out hh)&&w>4&&hh>4) found.Add(new PageTab {Strip=strip,Left=l,Top=t,Width=w,Height=hh,Place=index});
                        } finally { if(child is Accessibility.IAccessible) Msaa.Release(child); }
                    }
                    if(shapes.Count<4) shapes.Add(WindowSize(strip)+" "+Msaa.Shape(acc,12));
                } catch(Exception e) { if(shapes.Count<4) shapes.Add(WindowSize(strip)+" "+e.GetType().Name); }
                finally { Msaa.Release(acc); }
            }
            if(found.Count==0) {
                Accessibility.IAccessible top=null;
                try { top=Msaa.FromWindow(root); foreach(var p in Msaa.FindPageTabs(top,name,6,600)) found.Add(new PageTab {Strip=IntPtr.Zero,Left=p[0],Top=p[1],Width=p[2],Height=p[3]}); }
                catch(Exception e) { if(shapes.Count<4) shapes.Add("tree "+e.GetType().Name); }
                finally { Msaa.Release(top); }
            }
            Diag.EventRaw("tab_strip",list.Count+" tab control(s); \""+name+"\" found "+found.Count+(shapes.Count>0?" | "+String.Join(" || ",shapes.ToArray()):""));
            return found.Count==1?found[0]:null;
        }
        // 2.6.5: a tab's place as the tab control counts them, when it has that many tabs (else -1: not shown
        // directly).
        static int TabIndex(IntPtr strip,int index) {
            UIntPtr count;
            if(Native.SendNull(strip,Direct.TcmGetItemCount,UIntPtr.Zero,IntPtr.Zero,0x0002,1000,out count)==IntPtr.Zero) return -1;
            return index>=0&&(long)count.ToUInt64()>index?index:-1;
        }
        void ClickPageTab(PageTab tab) {
            Check(true);WaitIdle(2000);
            var point=new Native.Point {X=tab.Left+tab.Width/2,Y=tab.Top+tab.Height/2};
            Native.Rect rb;Order.Require(Native.GetWindowRect(root,out rb)&&point.X>rb.Left&&point.X<rb.Right&&point.Y>rb.Top&&point.Y<rb.Bottom,"COSTAR's "+"tab is outside the Repair Order window.");
            IntPtr hit=Native.WindowFromPoint(point);
            bool onStrip=tab.Strip!=IntPtr.Zero?hit==tab.Strip:(hit!=IntPtr.Zero&&Native.Pid(hit)==pid&&Native.GetAncestor(hit,2)==root&&Native.Class(hit).IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)<0&&Native.Class(hit).IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)<0);
            Order.Require(onStrip,"COSTAR's tab is covered (found "+DescribeCover(hit)+"). Leave COSTAR unobstructed.");
            Native.Click(point);Diag.Click();
        }
        // ---- Written By and Salesperson ----
        void FillStaff() {
            writtenByDone=FillStaffBox("WRITTEN BY","Written By");
            salespersonDone=FillStaffBox("SALESPERSON","Salesperson");
        }
        // SA in one staff box. Not found, locked, or not kept by COSTAR: a CHECK BY HAND note, not a stop.
        bool FillStaffBox(string heading,string label) {
            Ready();var box=EbaySelectors.UnderLabel(Current(),heading);
            if(box==null) { CheckLater(label+" was not found on this Repair Order: enter "+EbayOrder.Staff+" by hand.");return false; }
            string now=ReadLive(box);
            if(Order.Norm(now)==EbayOrder.Staff) { Say(label+" already shows "+EbayOrder.Staff+".");return true; }
            if(Locked(box)) { CheckLater(label+" is locked on this Repair Order (shows "+(now.Length==0?"nothing":now)+"): set "+EbayOrder.Staff+" by hand if it should be.");return false; }
            Put(box,EbayOrder.Staff,label,true);Ready();
            now=ReadLive(box);
            if(Order.Norm(now)==EbayOrder.Staff) return true;
            CheckLater(label+" shows "+(now.Length==0?"nothing":now)+" after "+EbayOrder.Staff+" was typed: check it.");return false;
        }
        // ---- Lines ----
        // Spaced (an empty line between entries) needs COSTAR's 25 lines counted, as DET first does.
        // If they can't be counted the lines go one after another, and the log says so.
        bool SpacedLines() {
            List<ControlInfo> s;bool counted;
            var g=SteadyGrid("eBay lines",true,out s,out counted);
            if(g!=null&&counted) return true;
            Diag.EventRaw("ebay_lines","not spaced: "+(g==null?"the grid kept changing":"the lines can't be counted"));
            Say("COSTAR's item lines can't be counted right now, so the eBay lines go in one after another (no empty line between them).");
            return false;
        }
        // On a resumed order, the row this line already has (0: none yet). Anything else there stops.
        long PlannedRow(EbayLine l,List<EbayLine> plan) {
            if(spaced) {
                List<ControlInfo> s;bool counted;
                var g=SteadyGrid("resume: line "+l.Line,true,out s,out counted);
                Order.Require(g!=null&&counted,"COSTAR's item lines can't be counted, so the stopped eBay order can't be checked. Entry stopped; check the order.");
                var row=g.Rows[l.Line-1];string code=Order.Norm(row.Value);
                if(code.Length==0) return 0;
                Order.Require(code==l.Code,"Line "+l.Line+" holds "+code+" instead of "+l.Code+". Entry stopped; check the order.");
                return row.Handle;
            }
            int nth=plan.TakeWhile(p=>!Object.ReferenceEquals(p,l)).Count(p=>p.Code==l.Code);
            return ExistingRow(l.Code,nth);
        }
        void EnterEbayLine(EbayLine l,List<EbayLine> plan,bool resuming) {
            int at=spaced?l.Line:0;
            long already=resuming?PlannedRow(l,plan):0;
            if(already!=0) Say(l.Label+" was already entered; checking it.");
            // Ebay-auto 1.0.0: EbayAddCode is AddCode, except that a code COSTAR doesn't know (its Quick Item Add) is left for
            // Seb: then 0, and that line gets nothing more.
            long h;
            switch(l.Kind) {
                case "product":
                    h=already!=0?already:EbayAddCode(l,plan,delegate{return AddCode(l.Code,false,true,false,at);});
                    if(h!=0){FinishLine(l.Item,h);ValidateEbayStock(l,h);} break;
                case "freight": h=already!=0?already:EbayAddCode(l,plan,delegate{return AddCode("F",false,true,false,at);});if(h!=0) FinishFreightAt(h,l.UnitCents); break;
                case "note": h=already!=0?already:EbayAddCode(l,plan,delegate{return AddCode(l.Code,true,false,false,at);});if(h!=0) NoteText(h,l,already==0); break;
                default:
                    if(already==0) { h=EbayAddCode(l,plan,delegate{return AddCode(l.Code,true,false,false,at);});if(h==0) break;NoteDefault(h,l.Code); }
                    Say("Entered "+l.Code+" (COSTAR's own text).");
                    break;
            }
        }
        void FinishFreightAt(long handle,int cents) {
            Order.Require(cents==order.freightCents,"Freight does not match the order.");
            FinishFreight(handle);Say("Entered freight $"+(cents/100m).ToString("0.00",CultureInfo.InvariantCulture)+".");
        }
        // COSTAR's own text for a note code (no customer data): recorded once so its default is known.
        void NoteDefault(long handle,string code) {
            try {
                var s=GridCurrent();var g=Selectors.ProductGrid(s);var row=Row(s,handle,code);
                string text=Selectors.Cell(s,row,g.Description).Value;
                Diag.EventRaw("note_default",code+": "+(text.Length==0?"(empty)":text.Length>70?text.Substring(0,70)+"...":text));
            } catch(InvalidOperationException) { }
        }
        // A note line's text: COSTAR's own default text for that code (if any) is replaced by ours.
        void NoteText(long handle,EbayLine l,bool fresh) {
            Func<MemoTarget> locate=delegate {
                var s=GridCurrent();var g=Selectors.ProductGrid(s);var row=Row(s,handle,l.Code);
                return new MemoTarget {Row=row,Editor=Selectors.Cell(s,row,g.Description)};
            };
            string expected=Order.EntryText(l.Text);
            var first=locate();
            if(fresh) NoteDefault(handle,l.Code);
            // 2.5.1: a line from a run that stopped may show our words without its key press: confirmed again.
            if(first.Editor.Value!=expected || !fresh) {
                var target=FocusMemo(locate,l.Label,first);
                WriteNote(target.Editor,expected,l.Label);
                Ready();
            }
            var wait=Diag.Wait("memo_readback");
            try {
                var timer=Stopwatch.StartNew();
                while(timer.ElapsedMilliseconds<3000) {
                    wait.Tick();Ready();
                    try { if(locate().Editor.Value==expected) { wait.Done("ok");return; } } catch(InvalidOperationException) { }
                    Pause(25);
                }
                wait.Done("timeout");
            } finally { wait.End(); }
            throw new InvalidOperationException(l.Label+" did not keep its text after COSTAR checked it.");
        }
        // ---- Final check ----
        void VerifyEbay(List<ControlInfo> s,List<EbayLine> plan) {
            VerifyEbayHeader(s);
            EbayCheck.Lines(s,plan,spaced);
            int total=Selectors.Total(s);
            Order.Require(total==order.totalCents,"COSTAR's total $"+(total/100m).ToString("0.00",CultureInfo.InvariantCulture)+" does not match the eBay total $"+(order.totalCents/100m).ToString("0.00",CultureInfo.InvariantCulture)+". Check the order; nothing was saved.");
        }
        // Everything the final check looks at but the lines and the total (Ebay-auto 1.0.0: shared with the partial check of
        // an order handed over).
        void VerifyEbayHeader(List<ControlInfo> s) {
            var h=Selectors.Header(s);var c=order.customer;
            Order.Require(CustomerEntry.SameIdentity(h.Account.Value,h.Name.Value,CustomerPhone(h),verifiedCustomerAccount,verifiedCustomerName,c.phone),"The customer account/name/phone changed after lookup. Check the Repair Order before saving.");
            var checks=new[]{new{Actual=h.Name.Value,Expected=c.name,Label="billing name from eBay Order/Buyer"},
                new{Actual=h.Address.Value,Expected=c.streetAddress,Label="address"},
                new{Actual=h.Suburb.Value,Expected=c.suburb,Label="suburb"},new{Actual=h.State.Value,Expected=c.state,Label="state"},new{Actual=h.Postcode.Value,Expected=c.postcode,Label="postcode"}};
            foreach(var check in checks) EbayIncomplete.VerifyKnown(check.Actual,check.Expected,check.Label);
            // A supplied street deliberately clears an absent second line. With no street, existing billing data is
            // retained rather than erased; it is not presented as verified against the missing eBay address.
            if(!String.IsNullOrWhiteSpace(c.streetAddress)||!String.IsNullOrWhiteSpace(c.address2))
                Order.Require(Order.Norm(h.Address2.Value)==Order.Norm(c.address2),"Final check failed: address line 2.");
            Order.Require(Order.Norm(h.PO.Value)==Order.Norm(order.orderId),"Final check failed: PO#.");
            Order.Require(Order.Norm(h.Comment.Value)==Order.Norm(order.comment),"Final check failed: comment.");
            // No eBay email: a matched COSTAR customer keeps theirs (nothing was typed there).
            if(!String.IsNullOrWhiteSpace(c.email)) Order.Require(Order.Clean(h.Email.Value)==Order.Clean(FieldText(c.email,true)),"Final email check failed: the buyer's address must be kept in lowercase.");
            Order.Require(EbayPhoneChoice.Normalize(CustomerPhone(h))==EbayPhoneChoice.Normalize(c.phone),"Final phone check failed.");
            var d=Selectors.Delivery(s);var x=order.shipping;
            var ship=new[]{new{Actual=d.Name.Value,Expected=x.name,Label="Ship to name"},new{Actual=d.Address.Value,Expected=x.streetAddress,Label="Ship to street"},
                new{Actual=d.Suburb.Value,Expected=x.suburb,Label="Ship to suburb"},new{Actual=d.State.Value,Expected=x.state,Label="Ship to state"},new{Actual=d.Postcode.Value,Expected=x.postcode,Label="Ship to postcode"}};
            foreach(var check in ship) EbayIncomplete.VerifyKnown(check.Actual,check.Expected,check.Label);
            // These optional fields are intentionally cleared by FillDelivery, and operational Ship Via is always known.
            var cleared=new[]{new{Actual=d.Address2.Value,Expected=x.address2,Label="Ship to address line 2"},
                new{Actual=d.Contact.Value,Expected=x.contact,Label="Ship to contact"},new{Actual=d.ShipVia.Value,Expected=x.shipVia,Label="Ship Via"},new{Actual=d.Instructions.Value,Expected=x.instructions,Label="shipping instructions"}};
            foreach(var check in cleared) Order.Require(Order.Norm(check.Actual)==Order.Norm(check.Expected),"Final check failed: "+check.Label+".");
            Order.Require(Order.Clean(d.Email.Value)==Order.Clean(FieldText(x.email,true)),"Final check failed: Ship to email (lowercase).");
            Order.Require(Order.Phone(d.MobilePhone.Value)==Order.Phone(x.mobilePhone)&&Order.Phone(d.BusinessPhone.Value)==Order.Phone(x.businessPhone),"Final check failed: Ship to phone.");
            foreach(var staff in new[]{new{Heading="WRITTEN BY",Done=writtenByDone},new{Heading="SALESPERSON",Done=salespersonDone}}) {
                if(!staff.Done) continue; // a CHECK BY HAND note says what to do
                var box=EbaySelectors.UnderLabel(s,staff.Heading);
                Order.Require(box!=null&&Order.Norm(box.Value)==EbayOrder.Staff,"Final check failed: "+staff.Heading.ToLowerInvariant()+" is not "+EbayOrder.Staff+".");
            }
            var terms=EbaySelectors.UnderLabel(s,"TERMS");
            if(rebillDone && terms!=null && Order.Norm(terms.Value)!=EbayOrder.ExpectedTerms)
                CheckLater("Terms shows "+(terms.Value.Length==0?"nothing":terms.Value)+", not "+EbayOrder.ExpectedTerms+" (it normally comes with Rebill to EBAY).");
        }
        // ---- Check Sydney layout (types nothing) ---- (1.1.9: Sydney or Tempe, the Runner's branch)
        // Reads an EMPTY Repair Order: header, Ship to, Written By / Salesperson / Terms, the item
        // lines, the tab strip; switches to Rebill to and back (a tab click, no typing) and reads it.
        internal string CheckLayout() {
            var report=new StringBuilder();Func<bool,string> mark=delegate(bool ok){return ok?"OK  ":"NO  ";};
            try {
                Diag.Kind="ebay-layout-check";runClock.Restart();Diag.BeginStage("Layout check");Stage("Layout check");
                enteringCustomer=false;ActivateAndWait();var s=Settled(Current());
                Selectors.Blank(s,branch);Selectors.BlankDelivery(s,branch);
                report.AppendLine(mark(true)+"Empty Repair Order in Branch "+branch+": customer fields, PO#, comment and lines are blank.");
                Dump("layout-ship-to",s);
                bool header=true,delivery=true;try{Selectors.Header(s);}catch(InvalidOperationException){header=false;}try{Selectors.Delivery(s);}catch(InvalidOperationException){delivery=false;}
                report.AppendLine(mark(header)+"Customer and order header");report.AppendLine(mark(delivery)+"Ship to panel (name, address, phones, Ship Via)");
                foreach(var label in new[]{"WRITTEN BY","SALESPERSON","TERMS"}) {
                    var box=EbaySelectors.UnderLabel(s,label);
                    bool locked=box!=null&&Locked(box);
                    report.AppendLine(mark(box!=null&&(!locked||label=="TERMS"))+label.Substring(0,1)+label.Substring(1).ToLowerInvariant()+" box"+(box!=null&&box.Value.Length>0?" (shows "+box.Value+")":"")+(locked?" - LOCKED (can't be typed into)":""));
                }
                List<ControlInfo> gs;bool counted;var g=SteadyGrid("layout check",true,out gs,out counted);
                report.AppendLine(mark(g!=null&&counted)+"Item lines counted ("+(g==null?"grid kept changing":g.Rows.Count+" lines")+"): eBay lines can be spaced");
                List<IntPtr> strips;var tab=FindPageTab("Rebill to",out strips);
                report.AppendLine(mark(tab!=null)+"Rebill to tab found ("+strips.Count+" Windows tab control(s))");
                bool shown=ShowTab("Rebill to",true);
                report.AppendLine(mark(shown)+"Switched to Rebill to");
                if(shown) {
                    var r=Settled(Current());Dump("layout-rebill",r);
                    try {
                        var m=EbaySelectors.Rebill(r);
                        report.AppendLine(mark(!Locked(m.Code)&&!Locked(m.Card))+"Rebill to Customer: code and name boxes; Card# box"+(m.Notes!=null?"; Rebill Notes box":" (Rebill Notes box not found: not needed)")+(Locked(m.Code)||Locked(m.Card)?" - LOCKED (can't be typed into)":""));
                        report.AppendLine(mark(ReadLive(m.Code).Length==0&&ReadLive(m.Card).Length==0)+"Rebill to is empty on this new Repair Order");
                    } catch(InvalidOperationException e) { report.AppendLine(mark(false)+"Rebill to boxes: "+e.Message); }
                    bool back=ShowTab("Ship to",false);
                    report.AppendLine(mark(back)+"Switched back to Ship to");
                }
                Diag.EndStage(true);Diag.Completed();
                report.AppendLine(writes==0?"Nothing was typed.":"WARNING: "+writes+" field(s) were written.");
            } catch(Exception e) {
                Diag.Stopped(e);report.AppendLine("STOPPED: "+e.Message);
                try{CaptureForegroundWindow(e.Message);Dump("stopped-controls",Snapshot(root));}catch{}
            } finally { log.Flush(); }
            return report.ToString();
        }
    }
}
