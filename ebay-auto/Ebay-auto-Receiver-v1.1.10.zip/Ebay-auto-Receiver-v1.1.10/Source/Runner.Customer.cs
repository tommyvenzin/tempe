// The entry engine, part 2 of 4: the customer lookup, COSTAR's account list and Search window,
// the header fields, Time in, Ship Via and the delivery panel.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed partial class Runner {
        // eBay accepts the requested Contact info number in X's Mobile, Home or Business box.
        // Other entry workflows keep their existing Mobile-only checks.
        string CustomerPhone(FieldMap h) { return ebay==null?h.Phone.Value:EbayCustomerPhone.Value(h,order.customer.phone); }
        string LiveCustomerPhone(FieldMap h) { return ebay==null?ReadLive(h.Phone):EbayCustomerPhone.Read(h,order.customer.phone,ReadLive); }
        string CustomerPhoneSignature(FieldMap h) { return ebay==null?h.Phone.Value:EbayCustomerPhone.Signature(h); }
        // A phone with two or more COSTAR accounts opens COSTAR's customer "Search" list
        // (seen on 3 Oct: a WinForms form with a results grid and Add new, Include Inactive,
        // Print Results, Search, Cancel, OK and Clear). OK stays unusable until a row is
        // highlighted. Take the first account: highlight the top row of the results grid
        // (accessibility first, a click on that row if needed), wait for OK, press OK.
        // Cancel, Add new, Search, Clear and Print are never pressed, and a new customer is
        // never created once this list was shown. An unfamiliar list stops with a capture.
        bool TryChooseFirstAccount(IntPtr front,List<ControlInfo> popup) {
            if(popup==null || front==root || Native.Pid(front)!=pid || IsNotesWindow(front)) return false;   // 2.6.11: never the customer's Notes
            // 2.9.11: never COSTAR's new-customer form (its OK makes a customer), nor anything while the account step's own
            // windows may be up.
            if(accountStep || NewAccountForm.IsTitle(Native.Caption(front))) return false;
            var kind=Selectors.AccountChooser(Native.Class(front),popup);
            if(!kind.IsChooser) return false;
            if(chooserAttempts==0) { Diag.Popup(front,popup); try { Dump("account-chooser-controls",popup); } catch(IOException) { } }
            Diag.EventRaw("account_chooser",kind.Reason+" accept="+(kind.Accept!=null)+" acceptEnabled="+(kind.Accept!=null&&Native.IsWindowEnabled(new IntPtr(kind.Accept.Handle)))+" listbox="+(kind.ListBox!=0)+" attempt="+(chooserAttempts+1));
            Order.Require(chooserAttempts<2,"The customer list did not close after choosing the first account. It is captured in the report; choose the customer in COSTAR, then retry.");
            chooserAttempts++;
            Check(false);
            Order.Require(Native.GetForegroundWindow()==front && IsCustomerPopup(front),"The customer list changed before the first account was chosen.");
            UIntPtr result;
            IntPtr okButton=kind.Accept==null?IntPtr.Zero:new IntPtr(kind.Accept.Handle);
            if(okButton!=IntPtr.Zero && !Native.IsWindowEnabled(okButton) && kind.ListBox==0) {
                // OK greyed out: COSTAR found nothing in Tempe. Search every branch (Tommy's steps).
                if(!SearchAllBranches(front,popup,okButton)) {
                    var cancel=popup.Where(c=>c.TextState=="read" && c.Class.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0 && Order.Norm(c.Text).Replace("&","")=="CANCEL").ToList();
                    Order.Require(cancel.Count==1 && Native.GetAncestor(new IntPtr(cancel[0].Handle),2)==front,"No account in any branch, and the search window's Cancel button was not found. Close it, then retry.");
                    Native.WriteMessage(new IntPtr(cancel[0].Handle),0xF5,UIntPtr.Zero,null,3,1000,out result); // BM_CLICK Cancel
                    var closing=Stopwatch.StartNew();
                    while(Native.IsWindow(front) && Native.IsWindowVisible(front) && closing.ElapsedMilliseconds<2500) Pause(25);
                    lookupCancelled=true;branchesCancelled=true;chooserClock.Restart();
                    Say("No account for this phone in any branch; entering the order's customer details.");
                    return true;
                }
            }
            sawChooser=true;lookupCancelled=false;
            if(kind.ListBox!=0) {
                var list=new IntPtr(kind.ListBox);
                if(Native.IsWindow(list) && Native.GetAncestor(list,2)==front) Native.WriteMessage(list,0x0186,UIntPtr.Zero,null,3,1000,out result); // LB_SETCURSEL row 0
            } else {
                string how=SelectFirstRow(front,kind.Accept==null?IntPtr.Zero:new IntPtr(kind.Accept.Handle));
                Diag.EventRaw("account_first_row",how);
            }
            if(kind.Accept!=null) {
                var button=new IntPtr(kind.Accept.Handle);string caption;
                var ready=Stopwatch.StartNew();
                while(!Native.IsWindowEnabled(button) && ready.ElapsedMilliseconds<1500) Pause(25);
                Order.Require(Native.GetAncestor(button,2)==front && Native.IsWindowEnabled(button) && Native.IsWindowVisible(button) &&
                    Native.TryText(button,out caption) && Order.Norm(caption)==Order.Norm(kind.Accept.Text),
                    "The customer list's OK button did not become available after selecting the first account. Nothing was pressed; the list is captured in the report.");
                Native.WriteMessage(button,0xF5,UIntPtr.Zero,null,3,1000,out result); // BM_CLICK
                Say("Two or more accounts share this phone: chose the first one ("+Order.Clean(kind.Accept.Text).Replace("&","")+").");
            } else {
                Order.Require(kind.EnterAllowed,"The customer list has no OK button and has buttons that could change data. Nothing was pressed; it is captured in the report.");
                Native.Key(13);Diag.Key();
                Say("Two or more accounts share this phone: chose the first one (Enter).");
            }
            var timer=Stopwatch.StartNew();
            while(Native.IsWindow(front) && Native.IsWindowVisible(front) && Native.GetForegroundWindow()==front && timer.ElapsedMilliseconds<2500) Pause(25);
            chooserClock.Restart();
            return true;
        }
        // 6 Oct (Tommy's video, TTW1730345): COSTAR's phone lookup only searches Tempe
        // (Branch 11). When the customer's accounts belong to other branches its "Search for
        // an Existing Customer" window opens with "Nothing found!" and OK greyed out. Done by
        // hand: the phone into that window's Phone box, its Branch box cleared, Search; the
        // accounts from every branch appear with row 1 highlighted and OK takes it.
        // Returns true when accounts were found (OK available), false when no branch has it.
        bool SearchAllBranches(IntPtr front,List<ControlInfo> popup,IntPtr ok) {
            var phoneBox=Selectors.FieldRightOf(popup,"PHONE");var branchBox=Selectors.FieldRightOf(popup,"BRANCH");
            var search=popup.Where(c=>c.TextState=="read" && c.Class.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0 && Order.Norm(c.Text).Replace("&","")=="SEARCH").ToList();
            Order.Require(phoneBox!=null && branchBox!=null && search.Count==1,"COSTAR's customer search window is not laid out as expected (Phone, Branch, Search). Nothing was changed; it is captured in the report.");
            string digits=Order.Phone(lookupPhone);
            Order.Require(digits.Length>=8,"The customer phone for the all-branch search is missing.");
            SetPopupText(front,phoneBox,digits,"the search window's Phone box");
            SetPopupText(front,branchBox,"","the search window's Branch box");
            Say("No account for this phone in this branch (Branch "+branch+"): searching every branch.");
            UIntPtr result;
            Native.WriteMessage(new IntPtr(search[0].Handle),0xF5,UIntPtr.Zero,null,3,1000,out result); // BM_CLICK Search
            var wait=Diag.Wait("customer_search_all_branches");
            try {
                var timer=Stopwatch.StartNew();
                while(timer.ElapsedMilliseconds<15000) {
                    wait.Tick();Check(false);
                    Order.Require(Native.IsWindow(front) && Native.IsWindowVisible(front),"COSTAR's customer search window closed during the all-branch search.");
                    if(Native.IsWindowEnabled(ok)) { wait.Done("accounts found");return true; }
                    if(timer.ElapsedMilliseconds>=800) {
                        var now=PopupSnapshot(front);
                        if(!lastSnapshotBusy && Selectors.NothingFound(now)) { wait.Done("none in any branch");return false; }
                    }
                    Pause(150);
                }
            } finally { wait.End(); }
            throw new InvalidOperationException("COSTAR's all-branch customer search did not finish within 15 s. Check the search window, then retry.");
        }
        void SetPopupText(IntPtr front,ControlInfo box,string value,string label) {
            var h=new IntPtr(box.Handle);UIntPtr result;string now;
            Order.Require(Native.IsWindow(h) && Native.GetAncestor(h,2)==front && Native.IsWindowEnabled(h),"COSTAR's search window changed before "+label+" could be set.");
            BeforeWrite();
            Order.Require(Native.WriteMessage(h,0xC,UIntPtr.Zero,value,3,1500,out result)!=IntPtr.Zero,"COSTAR did not accept "+label+".");
            Order.Require(Native.TryText(h,out now) && Order.Clean(now)==Order.Clean(value),"COSTAR did not keep "+label+".");
            writes++;Diag.Write(0,0);
        }
        // Tommy's rule (6 Oct): an order whose customer has a COSTAR customer number gets Ship
        // Via SHOP, entered as the last step. Deliveries keep their own Ship Via; a new
        // customer (no customer number) is left as it is. Never fatal.
        // always (2.5.3, Tommy 26 Oct: phone jobs): SHOP for every customer, not only those with a
        // COSTAR customer number (online pickups keep that rule).
        // True when Ship Via is SHOP after it (2.6.2: for the phone job's result).
        bool SetShipViaShop(bool always=false) {
            var s=Current();
            var h=Selectors.Header(s);
            if(!always && Order.Clean(ReadLive(h.Account)).Length==0) return false;
            var box=Selectors.ShipVia(s);
            if(box==null) { Say("Ship Via box not found; enter SHOP by hand.");Diag.EventRaw("ship_via","box not found");return false; }
            if(Order.Norm(ReadLive(box))=="SHOP") { Say("Ship Via already SHOP.");return true; }
            PutMapped(box,"SHOP","Ship Via",true);
            Say("Entered Ship Via: SHOP"+(always?".":" (customer has a COSTAR customer number)."));Diag.EventRaw("ship_via","SHOP");
            return true;
        }
        // 2.5.3 (Tommy, 26 Oct): phone jobs get Customer Waiting ticked (Order Check asks for it).
        // COSTAR draws its own check boxes, so the tick is read through accessibility (a check box
        // with its checked state), set with one real click on the box and read again. Never fatal:
        // not found, unreadable, locked or not kept, the log says to tick it by hand.
        // The Customer Waiting tick box (2.6.0: shared by phone jobs and Repair Orders from the phone):
        // a box with those words, else a box without words beside a "Customer Waiting" label. Null when
        // there isn't exactly one; names: the boxes' words seen, for the diagnostics.
        ControlInfo FindWaitingBox(List<ControlInfo> s,out int count,List<string> names) {
            var found=new List<ControlInfo>();
            var boxes=s.Where(c=>c.Visible&&c.Class.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0).Take(300).ToList();
            foreach(var c in boxes) {
                string t;if(!Native.TryText(new IntPtr(c.Handle),out t)) continue;
                string n=WaitingName(t);if(n.Length>0&&names!=null&&names.Count<40) names.Add(n);
                if(IsCustomerWaiting(n)) found.Add(c);
            }
            if(found.Count==0) {
                // A box without words of its own beside a "Customer Waiting" label.
                foreach(var l in s.Where(c=>c.Static).Take(600)) {
                    string lt;if(!Native.TryText(new IntPtr(l.Handle),out lt)||!IsCustomerWaiting(WaitingName(lt))) continue;
                    int mid=l.Y+l.H/2;
                    found.AddRange(boxes.Where(b=>b.Parent==l.Parent&&Math.Abs(b.Y+b.H/2-mid)<=Math.Max(6,l.H/2)&&(Math.Abs(b.X+b.W-l.X)<=40||Math.Abs(l.X+l.W-b.X)<=40)));
                }
                found=found.Distinct().ToList();
            }
            count=found.Count;
            return found.Count==1?found[0]:null;
        }
        // 2.6.0: whether Customer Waiting is ticked: yes, no, or "" with why it can't be told.
        string WaitingState(List<ControlInfo> s,out string why) {
            int count;var box=FindWaitingBox(s,out count,null);why="";
            if(box==null) { why=count==0?"no Customer Waiting box was found on this Repair Order.":"the Customer Waiting box isn't clear ("+count+" boxes).";return ""; }
            int role;bool on;
            if(!TickState(new IntPtr(box.Handle),out role,out on)||role!=44) { why="the Customer Waiting box can't be read as a tick box.";return ""; }
            if(!Native.IsWindowEnabled(new IntPtr(box.Handle))) why="Customer Waiting is locked on this Repair Order.";
            return on?"yes":"no";
        }
        // 2.6.0 (Repair Orders from the phone): tick or untick Customer Waiting, one real click, then
        // read again. Stops when it can't be done or isn't kept (the phone was told it would be).
        void SetWaiting(bool want) {
            var s=Current();int count;var box=FindWaitingBox(s,out count,null);
            Order.Require(box!=null,count==0?"No Customer Waiting box was found.":"The Customer Waiting box isn't clear ("+count+" boxes).");
            var h=new IntPtr(box.Handle);int role;bool on;
            Order.Require(TickState(h,out role,out on)&&role==44,"Customer Waiting can't be read as a tick box.");
            if(on==want) { Say("Customer Waiting already "+(want?"ticked.":"unticked."));return; }
            Order.Require(Native.IsWindowEnabled(h),"Customer Waiting is locked on this Repair Order.");
            BeforeWrite();
            // 2.6.5: pressed directly (PressTick); one real click only when that says so.
            if(PressTick(box,root,want,"Customer Waiting",false)=="click") ClickTickBox(box);
            writes++;
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<3000) {
                Pause(50);
                if(TickState(h,out role,out on)&&on==want) { Say(want?"Ticked Customer Waiting.":"Unticked Customer Waiting.");Diag.EventRaw("customer_waiting",want?"ticked":"unticked");return; }
                Order.Require(Native.GetForegroundWindow()==root&&Native.IsWindowEnabled(root),"COSTAR opened a window after Customer Waiting was clicked: answer it at the PC.");
            }
            throw new InvalidOperationException("COSTAR didn't keep Customer Waiting "+(want?"ticked":"unticked")+".");
        }
        // The Customer Waiting box TickCustomerWaiting found ticked (2.8.0: an online pickup's is read again before its
        // Repair Order is closed); waitingBox: the one this online order ticked, else zero.
        IntPtr tickedWaiting,waitingBox;
        // True when Customer Waiting is ticked after it (2.6.2: for the phone job's result).
        bool TickCustomerWaiting() {
            var s=Current();var names=new List<string>();int count;
            var found=FindWaitingBox(s,out count,names);
            if(found==null) {
                Say("Customer Waiting box "+(count==0?"not found":"not clear ("+count+" boxes)")+"; tick it by hand.");
                Diag.EventRaw("customer_waiting",(count==0?"not found":count+" found")+"; buttons: "+String.Join(" | ",names));return false;
            }
            var box=found;var h=new IntPtr(box.Handle);int role;bool on;
            if(!TickState(h,out role,out on)||role!=44) { Say("Customer Waiting couldn't be read as a tick box; tick it by hand.");Diag.EventRaw("customer_waiting","role "+role);return false; }
            if(on) { Say("Customer Waiting already ticked.");Diag.EventRaw("customer_waiting","already");tickedWaiting=h;return true; }
            if(!Native.IsWindowEnabled(h)) { Say("Customer Waiting is locked on this Repair Order; tick it by hand.");Diag.EventRaw("customer_waiting","locked");return false; }
            if(PressTick(box,root,true,"Customer Waiting",false)=="click") ClickTickBox(box);
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<3000) {
                Pause(50);
                if(TickState(h,out role,out on)&&on) { Say("Ticked Customer Waiting.");Diag.EventRaw("customer_waiting","ticked");tickedWaiting=h;return true; }
                if(Native.GetForegroundWindow()!=root||!Native.IsWindowEnabled(root)) { Say("COSTAR opened a window after Customer Waiting was clicked: answer it by hand.");Diag.EventRaw("customer_waiting","window opened");return false; }
            }
            Say("COSTAR didn't keep Customer Waiting ticked; tick it by hand.");Diag.EventRaw("customer_waiting","not kept");return false;
        }
        internal static string WaitingName(string text) { return System.Text.RegularExpressions.Regex.Replace((text??"").Replace("&","").ToUpperInvariant(),@"[^A-Z]+"," ").Trim(); }
        // "Customer Waiting", "Cust. Waiting", "Customer waiting?" (a few words at most).
        internal static bool IsCustomerWaiting(string n) { return n.StartsWith("CUST",StringComparison.Ordinal)&&n.Contains("WAITING")&&n.Split(' ').Length<=4; }
        static bool TickState(IntPtr h,out int role,out bool on) {
            role=-1;on=false;Accessibility.IAccessible a=null;
            try {
                a=Msaa.FromWindow(h);role=Msaa.Role(a);
                object st=a.get_accState(0);if(!(st is int)) return false;
                on=(((int)st)&0x10)!=0;return true; // STATE_SYSTEM_CHECKED
            } catch(Exception) { return false; }
            finally { Msaa.Release(a); }   // 2.6.2: read often on the print form
        }
        // 2.6.5: a tick box set to `want` without the mouse, the way a click does it: the keyboard to the box
        // first (a click gives it that too: the box being left is checked by COSTAR, and the tick is taken in
        // when the box is left later), then the box's own click (BM_CLICK), then the tick read back. "done";
        // "click": one real click is to follow (COSTAR took the press and the tick reads unchanged, or the
        // keyboard didn't go to the box); "leave": it may still change (the press unanswered, or the tick
        // unreadable): nothing more is pressed. window: the window it is on (the Repair Order, the print form),
        // in front; quiet: nobody may be using the PC (the print). Direct presses off: "click".
        string PressTick(ControlInfo box,IntPtr window,bool want,string label,bool quiet) {
            if(!Direct.On) return "click";
            var h=new IntPtr(box.Handle);
            WaitIdle(2000);Check(false);
            // 2.6.6: with the keyboard in the item lines, the tick is clicked, as in 2.6.4 (ClickOnly); looked at
            // with COSTAR idle.
            string clickOnly=window==root?ClickOnly(h):null;
            if(clickOnly!=null) { Diag.EventRaw("direct_skipped",label+": "+clickOnly+", a click");return "click"; }
            Order.Require(Native.GetForegroundWindow()==window&&Native.IsWindowEnabled(window),"COSTAR isn't in front with "+label+" free to change");
            Order.Require(Native.Pid(h)==pid&&Native.IsWindowVisible(h)&&Native.IsWindowEnabled(h)&&Native.GetAncestor(h,2)==window&&Native.GetParent(h).ToInt64()==box.Parent&&Native.Class(h)==box.Class,label+" changed.");
            if(quiet) Quiet(label);
            if(Native.Focus(window)!=h) {
                Direct.Focus(h,1500,()=>Cancel);Diag.Pressed();
                var wait=Stopwatch.StartNew();
                while(Native.Focus(window)!=h&&wait.ElapsedMilliseconds<600) Pause(25);
                if(Native.Focus(window)!=h) { Diag.EventRaw("direct_fallback",label+": the keyboard didn't go to it, a click instead");return "click"; }
            }
            Order.Require(Native.GetForegroundWindow()==window&&Native.IsWindowEnabled(window),"COSTAR opened a window when "+label+" got the keyboard");
            if(quiet) Quiet(label);
            int sent=Direct.Press(h,1500);Diag.Pressed();
            var timer=Stopwatch.StartNew();
            while(true) {
                int role;bool on;bool? now=TickState(h,out role,out on)&&role==44?on:(bool?)null;
                string next=Direct.AfterPress(sent,now,want);
                if(next=="done") return next;
                if(timer.ElapsedMilliseconds>=(sent==0?4000:1500)) {
                    Diag.EventRaw("direct_fallback",label+": "+(sent==1?"pressed":sent==0?"COSTAR didn't answer the press":"the press couldn't be sent")+(now==null?", can't be read back":", reads unchanged")+(next=="click"?", a click instead":", nothing more pressed"));
                    return next;
                }
                Pause(50);
            }
        }
        // One click on the box (as ClickTarget does for a field): COSTAR in front, the box where it
        // was, nothing over it.
        void ClickTickBox(ControlInfo c) {
            WaitIdle(2000);Check(true);var h=new IntPtr(c.Handle);
            Order.Require(Native.Pid(h)==pid&&Native.IsWindowVisible(h)&&Native.IsWindowEnabled(h)&&Native.GetAncestor(h,2)==root&&Native.GetParent(h).ToInt64()==c.Parent&&Native.Class(h)==c.Class,"The Customer Waiting box changed.");
            Native.Rect r;Order.Require(Native.GetWindowRect(h,out r),"Cannot locate the Customer Waiting box.");
            var point=new Native.Point {X=r.Left+Math.Min(8,Math.Max(2,(r.Right-r.Left)/4)),Y=r.Top+(r.Bottom-r.Top)/2};
            Order.Require(Native.WindowFromPoint(point)==h,"The Customer Waiting box is covered.");
            Native.Click(point);Diag.Click();
        }
        // Highlights the first customer row of the list's results grid until OK lights up.
        // 5 Oct: the old version searched the list's panels smallest first, found the small
        // search-criteria panel (a table with no customer rows) and gave up there. Now every
        // grid-like panel is tried, largest first, then one level deeper; a row is selected
        // through accessibility and clicked near its left edge (row selector / first cell),
        // up to 3 top rows, stopping as soon as OK is enabled. On failure the grid's shape
        // (roles, counts, positions; never names or values) goes into the report.
        string SelectFirstRow(IntPtr front,IntPtr ok) {
            var grids=new List<KeyValuePair<IntPtr,int>>();
            Native.EnumChildWindows(front,delegate(IntPtr h,IntPtr unused) {
                Native.Rect r;
                if(Native.IsWindowVisible(h) && Native.Class(h).IndexOf("WindowsForms10.Window",StringComparison.OrdinalIgnoreCase)>=0 && Native.GetWindowRect(h,out r)) {
                    int w=r.Right-r.Left,hh=r.Bottom-r.Top;
                    if(w>=200 && hh>=60) grids.Add(new KeyValuePair<IntPtr,int>(h,w*hh));
                }
                return grids.Count<200;
            },IntPtr.Zero);
            var shapes=new List<string>();
            var ordered=grids.OrderByDescending(x=>x.Value).Take(20).Select(x=>x.Key).ToList();
            for(int depth=1;depth<=2;depth++) {
                foreach(var grid in ordered) {
                    Accessibility.IAccessible client=null,table=null;List<Msaa.Row> rows=null;
                    try {
                        client=Msaa.FromWindow(grid);
                        table=Msaa.Role(client)==Msaa.RoleTable?client:Msaa.FindTable(client,depth);
                        if(table==null) { if(depth==1 && shapes.Count<8) shapes.Add(WindowSize(grid)+" "+Msaa.Shape(client,8)); continue; }
                        rows=Msaa.TopRows(table,3);
                        if(rows.Count==0) { if(shapes.Count<8) shapes.Add(WindowSize(grid)+" table without rows "+Msaa.Shape(table,10)); continue; }
                        int tried=0;
                        foreach(var row in rows) {
                            tried++;
                            Msaa.SelectChild(table,row.Child);Pause(120);
                            if(ok!=IntPtr.Zero && Native.IsWindowEnabled(ok)) return "row "+tried+" selected";
                            if(row.Width>0 && row.Height>0) {
                                var point=new Native.Point{X=row.Left+Math.Min(40,Math.Max(4,row.Width/4)),Y=row.Top+row.Height/2};
                                IntPtr hit=Native.WindowFromPoint(point);
                                if(hit!=IntPtr.Zero && (hit==front || Native.GetAncestor(hit,2)==front)) { Native.Click(point);Diag.Click(); }
                            }
                            var wait=Stopwatch.StartNew();
                            while(ok!=IntPtr.Zero && !Native.IsWindowEnabled(ok) && wait.ElapsedMilliseconds<700) Pause(30);
                            if(ok==IntPtr.Zero || Native.IsWindowEnabled(ok)) return "row "+tried+" selected and clicked";
                        }
                        if(shapes.Count<8) shapes.Add(WindowSize(grid)+" rows tried "+tried+", OK still off "+Msaa.Shape(table,10));
                    } catch(Exception e) {
                        if(shapes.Count<8) shapes.Add(WindowSize(grid)+" "+e.GetType().Name);
                    } finally {
                        if(rows!=null) foreach(var row in rows) Msaa.Release(row.Child);
                        if(!Object.ReferenceEquals(table,client)) Msaa.Release(table);
                        Msaa.Release(client);
                    }
                }
            }
            Diag.EventRaw("account_grid_shape",String.Join(" || ",shapes));
            return "no customer row found";
        }
        static string WindowSize(IntPtr h) { Native.Rect r; return Native.GetWindowRect(h,out r)?(r.Right-r.Left)+"x"+(r.Bottom-r.Top):"?"; }
        bool CustomerPopup(IntPtr front,List<ControlInfo> controls) {
            if(front==root || controls==null || !Selectors.CustomerNotFoundNotice(controls)) return false;
            Check(false); Order.Require(Native.GetForegroundWindow()==front && Native.Pid(front)==pid && Native.IsWindowVisible(front),"Customer popup changed.");
            // 2.6.5: its one button (OK) pressed directly; Escape only when COSTAR took that and the notice stayed.
            if(Direct.On) {
                var ok=controls.Where(c=>c.Visible&&c.Enabled&&c.Class.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0).ToList();
                if(ok.Count==1&&Native.GetAncestor(new IntPtr(ok[0].Handle),2)==front) {
                    int sent=Direct.Press(new IntPtr(ok[0].Handle),1500);Diag.Pressed();
                    var gone=Stopwatch.StartNew();
                    while(Native.IsWindowVisible(front) && Native.GetForegroundWindow()==front && gone.ElapsedMilliseconds<(sent==0?3000:1500))Pause(25);
                    if(!Native.IsWindowVisible(front) || Native.GetForegroundWindow()!=front) { notFoundShown=true;Say("Dismissed Customer Not found.");return true; }
                    Diag.EventRaw("direct_fallback","Customer Not found: "+(sent==1?"OK pressed, the notice stayed":sent==0?"COSTAR didn't answer OK":"OK couldn't be pressed")+(sent==0?"":", Escape instead"));
                    Order.Require(sent!=0,"The Customer Not found notice didn't answer OK. Nothing more was pressed: close it in COSTAR.");
                    Order.Require(Native.GetForegroundWindow()==front && Native.IsWindowVisible(front),"Customer popup changed.");
                }
            }
            Native.Key(27);Diag.Key();var timer=Stopwatch.StartNew();
            while(Native.IsWindowVisible(front) && Native.GetForegroundWindow()==front && timer.ElapsedMilliseconds<1500)Pause(25);
            Order.Require(!Native.IsWindowVisible(front) || Native.GetForegroundWindow()!=front,"The Customer Not found notice did not close after Escape.");
            notFoundShown=true;Say("Dismissed Customer Not found.");return true;
        }
        bool IsCustomerPopup(IntPtr window) {
            if(window==IntPtr.Zero || window==root || !Native.IsWindowVisible(window) || Native.Caption(window).StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase)) return false;
            var owner=window;
            for(int i=0;i<16 && owner!=IntPtr.Zero;i++) {
                owner=Native.GetWindow(owner,4); // GW_OWNER
                if(owner==root) return true;
            }
            // Existing COSTAR main windows must never receive a Close request.
            return Native.Pid(window)==pid && !originalWindows.Contains(window.ToInt64());
        }
        List<ControlInfo> PopupSnapshot(IntPtr window) {
            try { return Snapshot(window); }
            catch(InvalidOperationException) {
                if(!Native.IsWindow(window) || Native.GetForegroundWindow()!=window) return null;
                throw;
            }
        }
        void RecoverCustomerUi(IntPtr front,List<ControlInfo> popup,List<ControlInfo> snapshot) {
            Check(false);
            if(Native.GetForegroundWindow()!=front) return;
            if(IsCustomerPopup(front)) {
                // 2.9.11: COSTAR's new-customer form (its OK makes a customer) is never answered, cancelled or closed here, nor any
                // window while the account step's own may be up.
                Order.Require(!accountStep && !NewAccountForm.IsTitle(Native.Caption(front)),"COSTAR's new-customer form (or its customer search) is open over the order. Nothing was pressed on it: finish or cancel it at the PC, then Retry.");
                if(AnswerPopup(front)) return;   // 2.6.11: a notice with one OK, not something to cancel
                // 2.6.11: the customer's Notes that couldn't be answered: nothing of them is read or kept.
                Order.Require(!IsNotesWindow(front),"COSTAR's Notes window is open over the order and couldn't be closed with OK. Close it at the PC, then retry.");
                popup=popup??PopupSnapshot(front);
                if(popup==null) return;
                CaptureForegroundWindow("Customer popup recovery");
                if(Native.GetForegroundWindow()!=front || !IsCustomerPopup(front)) return;
                if(Native.Pid(front)==pid && CustomerPopup(front,popup)) { lookupCancelled=true;return; }
                if(TryChooseFirstAccount(front,popup)) return;
                int stage;popupCloseStages.TryGetValue(front.ToInt64(),out stage);
                Order.Require(stage<3 && recoveryActions<8,"The customer popup did not close. Close it in COSTAR and check the partial order before retrying.");
                Check(false);
                Order.Require(Native.GetForegroundWindow()==front && IsCustomerPopup(front),"Customer popup changed before cancellation.");
                var button=Selectors.CustomerCancelButton(popup); UIntPtr result;
                if(stage==0 && button!=null) {
                    var handle=new IntPtr(button.Handle);string caption;
                    Order.Require(Native.GetAncestor(handle,2)==front && Native.IsWindowEnabled(handle) && Native.IsWindowVisible(handle) && Native.TryText(handle,out caption) && Order.Norm(caption)==Order.Norm(button.Text),"The popup Cancel/Close button changed.");
                    Native.WriteMessage(handle,0xF5,UIntPtr.Zero,null,3,1000,out result); // BM_CLICK on Cancel/Close only
                    Say("Requested "+Order.Clean(button.Text).Replace("&","")+" on the customer popup.");
                } else if(stage<2) {
                    Native.Key(27);Diag.Key();Say("Sent Escape to cancel the customer popup.");
                } else {
                    // Normal title-bar Close; never destroy/disable a window or confirm OK/Yes.
                    Native.WriteMessage(front,0x10,UIntPtr.Zero,null,3,1000,out result);
                    Say("Requested Close on the customer popup.");
                }
                popupCloseStages[front.ToInt64()]=stage+1;recoveryActions++;lookupCancelled=true;
                Pause(400);return;
            }
            if(front!=root) {
                if(front==IntPtr.Zero) { Pause(150);return; }
                CaptureForegroundWindow("Customer lookup focus changed");
                Order.Require(!restoredCustomerFocus && Native.IsWindowEnabled(root),"Another window is blocking COSTAR. Its title/process are in the report. Close it and check the partial order before retrying.");
                restoredCustomerFocus=true;Native.BringToFront(root);
                Say("Returning to the original Repair Order after the customer lookup lost focus.");Pause(350);return;
            }
            if(Selectors.CustomerSearchInProgress(snapshot)) {
                Order.Require(Native.IsWindowEnabled(root) && searchCancelAttempts<2 && recoveryActions<8,"COSTAR's search did not cancel. Close the search and check the partial order before retrying.");
                Dump("cancel-search-controls",snapshot);
                Check(false);Order.Require(Native.GetForegroundWindow()==root,"COSTAR changed before cancelling its search.");
                Native.Key(27);Diag.Key();searchCancelAttempts++;recoveryActions++;lookupCancelled=true;
                Say("Sent Escape to cancel the customer search; checking that the Repair Order is editable.");Pause(400);
            }
        }
        void CustomerFormReady(int quietMilliseconds) {
            var wait=Diag.Wait("customer_form_ready");
            try {
            var timer=Stopwatch.StartNew();var quiet=Stopwatch.StartNew();string previous=null;
            while(timer.ElapsedMilliseconds<CustomerLookupTimeoutMs) {
                wait.Tick();Check(false);var front=Native.GetForegroundWindow();
                var snapshot=Snapshot(root);
                if(lastSnapshotBusy) { previous=null;quiet.Restart();Pause(150);continue; }
                if(front!=Native.GetForegroundWindow()) { quiet.Restart();Pause(40);continue; }
                bool searching=Selectors.CustomerSearchInProgress(snapshot);
                if(front!=root || searching) {
                    previous=null;quiet.Restart();
                    if(front!=root && AnswerPopup(front)) { Pause(100);continue; }   // 2.6.11
                    if(timer.ElapsedMilliseconds>=(front!=root?750:SearchPatienceMs)) RecoverCustomerUi(front,null,snapshot);
                    Pause(searching?120:50);continue;
                }
                if(!Native.IsWindowEnabled(root)) { previous=null;quiet.Restart();Pause(40);continue; }
                try {
                    var m=Selectors.Header(snapshot);
                    string signature=m.Account.Value+"|"+m.Name.Value+"|"+CustomerPhoneSignature(m);
                    if(signature!=previous) { previous=signature;quiet.Restart(); }
                    if(quiet.ElapsedMilliseconds>=quietMilliseconds) {wait.Done("ok");return;}
                } catch(InvalidOperationException) { previous=null;quiet.Restart(); }
                Pause(40);
            }
            wait.Done("timeout");
            throw new InvalidOperationException("COSTAR did not return to an editable customer form after popup recovery. Close the remaining popup and retry on an empty Repair Order.");
            } finally {wait.End();}
        }
        bool LookupCustomer(bool requireAccountNumber=false) {
            var wait=Diag.Wait("customer_lookup");
            // 2.9.11: how this lookup ends, for the new-customer account step (only after Customer Not found and nothing else).
            notFoundShown=false;branchesCancelled=false;lookupNotFound=false;int recoveriesBefore=recoveryActions,searchCancelsBefore=searchCancelAttempts;
            try {
            int stable=0;string previous=null;var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<CustomerLookupTimeoutMs) {
                wait.Tick();Check(false);var front=Native.GetForegroundWindow();var snapshot=Snapshot(root);
                if(lastSnapshotBusy) { stable=0;Pause(150);continue; }
                if(front!=Native.GetForegroundWindow()) { stable=0;Pause(40);continue; }
                // 2.6.11: an account customer's Notes or memo, shown as the account loads: answered with OK, before
                // anything of the window is read.
                if(front!=root && IsCustomerPopup(front) && AnswerPopup(front)) { stable=0;previous=null;Pause(100);continue; }
                List<ControlInfo> popup=IsCustomerPopup(front)&&!IsNotesWindow(front)?PopupSnapshot(front):null;
                if(front!=Native.GetForegroundWindow()) { stable=0;Pause(40);continue; }
                if(popup!=null && Native.Pid(front)==pid && CustomerPopup(front,popup)) { lookupCancelled=true;stable=0;continue; }
                if(popup!=null && TryChooseFirstAccount(front,popup)) { stable=0;previous=null;continue; }
                bool searching=Selectors.CustomerSearchInProgress(snapshot) || (popup!=null && Selectors.CustomerSearchInProgress(popup));
                if(front!=root || searching || !Native.IsWindowEnabled(root)) {
                    stable=0;
                    int patience=front!=root?750:searching?SearchPatienceMs:3000;
                    if(timer.ElapsedMilliseconds>=patience) RecoverCustomerUi(front,popup,snapshot);
                    Pause(searching?120:50);continue;
                }
                FieldMap m;
                // An existing customer's account makes COSTAR rebuild the customer panel.
                // Missing labels during that redraw are transient: keep waiting.
                try { m=Selectors.Header(snapshot); }
                catch(InvalidOperationException) { stable=0;previous=null;Pause(60);continue; }
                string signature=m.Account.Value+"|"+m.Name.Value+"|"+CustomerPhoneSignature(m);
                stable=signature==previous?stable+1:1;previous=signature;
                if(stable>=2) {
                    if((!requireAccountNumber||Order.Clean(m.Account.Value).Length>0)&&CustomerEntry.HasMatch(m.Account.Value,m.Name.Value,CustomerPhone(m),order.customer.phone)){wait.Done(sawChooser?"existing-customer-first-of-several":"existing-customer");return true;}
                    if(sawChooser) {
                        // The first account was chosen from the list: give COSTAR time to load it.
                        Order.Require(chooserClock.ElapsedMilliseconds<5000,"The first account was chosen from the list, but COSTAR did not load an account with this phone. Choose it in COSTAR, then retry; the list is captured in the report.");
                        stable=0;previous=null;Pause(40);continue;
                    }
                    Order.Require(m.Account.Value.Length==0,"COSTAR selected an account whose phone does not match. Check the account before continuing.");
                    if(lookupCancelled || timer.ElapsedMilliseconds>=3000) {
                        Order.Require(CustomerEntry.LookupResolved(m.Account.Value,m.Name.Value,CustomerPhone(m),order.customer.phone),"The customer phone changed during lookup recovery.");
                        lookupNotFound=lookupCancelled&&NewAccount.NoticeOnly(notFoundShown,sawChooser,branchesCancelled,recoveryActions-recoveriesBefore,searchCancelAttempts-searchCancelsBefore);
                        wait.Done(lookupCancelled?"new-customer-after-popup":"new-customer-after-3s-wait");return false;
                    }
                }
                Pause(30);
            }
            wait.Done("timeout");
            throw new InvalidOperationException("Customer lookup did not return to an editable form. Check the popup and customer account.");
            } finally {wait.End();}
        }
        void CustomerField(Func<FieldMap,ControlInfo> selector,string value,string label,bool allowEmpty=false) {
            if(!allowEmpty && String.IsNullOrWhiteSpace(value)) return;
            value=Order.EntryText(value);
            Ready();var header=HeaderNow();
            if(verifiedCustomerAccount!=null)Order.Require(header.Account.Value==verifiedCustomerAccount &&
                (verifiedCustomerName==null || header.Name.Value==verifiedCustomerName),"The selected customer account/name changed while filling the header.");
            var c=selector(header);
            if(c.Value==Order.Clean(value)) return;
            Put(c,value,label,true); Ready(); ReadEquals(selector(HeaderNow()),value,label);
        }
        string ReadLive(ControlInfo c) {
            CheckTarget(c);string value;
            Order.Require(Native.TryText(new IntPtr(c.Handle),out value),"A mapped COSTAR field is not readable.");
            return Order.Clean(value);
        }
        void PutMapped(ControlInfo c,string value,string label,bool allowEmpty=false,bool lowerCase=false) {
            if(!allowEmpty && String.IsNullOrWhiteSpace(value))return;
            value=FieldText(value,lowerCase);Ready();
            if(ReadLive(c)==Order.Clean(value))return;
            Put(c,value,label,true,lowerCase);Ready();ReadEquals(c,value,label);
        }
        void GuardCustomer(FieldMap h) {
            Order.Require(ReadLive(h.Account)==verifiedCustomerAccount &&
                (verifiedCustomerName==null || ReadLive(h.Name)==verifiedCustomerName) &&
                Order.Phone(LiveCustomerPhone(h))==Order.Phone(order.customer.phone),"The selected customer account/name/phone changed while filling the header.");
        }
        // timeIn=false only for the second pass after a new account: Time in was handled on the first.
        void FillOnlineHeader(bool existing,bool timeIn=true) {
            // Header controls do not expand like grid rows. Map once, then check
            // each live HWND/parent/class and retained text rather than rereading
            // hundreds of unrelated grid controls for every field.
            var h=HeaderNow();var c=order.customer;GuardCustomer(h);
            // eBay X always takes the order's Buyer display name, including after a phone match
            // or account creation. Only the Repair Order's Name box is written; Account# stays guarded.
            if((!existing || ebay!=null)&&(ebay==null||!String.IsNullOrWhiteSpace(c.name))) {
                bool changed=ReadLive(h.Name)!=Order.Clean(Order.EntryText(c.name));
                PutMapped(h.Name,c.name,"customer name");
                verifiedCustomerName=Order.Clean(Order.EntryText(c.name));
                GuardCustomer(h);
                if(ebay!=null) Diag.EventRaw("ebay_billing_name","source=Order/Buyer; "+(changed?"updated":"already matched")+"; Account# unchanged");
            } else if(ebay!=null&&String.IsNullOrWhiteSpace(c.name)) verifiedCustomerName=ReadLive(h.Name);
            GuardCustomer(h);PutMapped(h.Email,c.email,"email",lowerCase:true);
            var fields=new[] {
                new {Field=h.Address,Value=c.streetAddress,Label="address",Clear=false},
                new {Field=h.Address2,Value=c.address2,Label="address line 2",Clear=!String.IsNullOrWhiteSpace(c.streetAddress)},
                new {Field=h.Suburb,Value=c.suburb,Label="suburb",Clear=false},
                new {Field=h.State,Value=c.state,Label="state",Clear=false},
                new {Field=h.Postcode,Value=c.postcode,Label="postcode",Clear=false},
                new {Field=h.PO,Value=order.orderId,Label="PO#",Clear=false},
                new {Field=h.Comment,Value=order.comment,Label="order comment",Clear=true}
            };
            foreach(var field in fields){GuardCustomer(h);PutMapped(field.Field,field.Value,field.Label,field.Clear);}
            GuardCustomer(h);
            if(!order.IsDelivery&&timeIn) SetTimeIn();
        }
        // Time in: COSTAR fills it with the moment the order was opened. For an online pickup
        // the booking time is what the workshop needs, so it goes in instead. Never fatal:
        // if COSTAR will not take it, the order is still finished and the log says so.
        void SetTimeIn() {
            string want=Order.TimeInText(order.pickupTime);
            if(want==null) return;
            var box=Selectors.TimeIn(Current());
            if(box==null) { Say("Time in box not found on this Repair Order; left as COSTAR set it.");Diag.EventRaw("time_in","box not found");Checks.Add("Time in wasn't set: make it "+want+" (the booking time) by hand.");return; }
            if(Order.ClockMinutes(ReadLive(box))==Order.ClockMinutes(want)) { Say("Time in already shows the booking time ("+want+").");return; }
            Put(box,want,"Time in",true);Ready();
            string now=ReadLive(box);
            if(Order.ClockMinutes(now)==Order.ClockMinutes(want)) { Say("Entered Time in: "+want+" (booking time).");Diag.EventRaw("time_in","set"); }
            else { Say("COSTAR did not keep Time in "+want+" (shows "+now+"). Set it by hand.");Diag.EventRaw("time_in","not kept");Checks.Add("COSTAR didn't keep Time in: make it "+want+" (the booking time) by hand."); }
        }
        void FillDelivery() {
            // Billing has already been committed; shipping is a separate panel.
            var d=order.shipping;var m=Selectors.Delivery(Current());
            PutMapped(m.Name,d.name,"delivery recipient",true);
            PutMapped(m.Address,d.streetAddress,"delivery street",true);
            PutMapped(m.Address2,d.address2,"delivery address line 2",true);
            PutMapped(m.Suburb,d.suburb,"delivery suburb",true);
            PutMapped(m.State,d.state,"delivery state",true);
            PutMapped(m.Postcode,d.postcode,"delivery postcode",true);
            PutMapped(m.Contact,d.contact,"delivery contact",true);
            PutMapped(m.BusinessPhone,d.businessPhone,"delivery business phone",true);
            PutMapped(m.MobilePhone,d.mobilePhone,"delivery mobile",true);
            PutMapped(m.Email,d.email,"delivery email",true,lowerCase:true);
            PutMapped(m.ShipVia,d.shipVia,"Ship Via",true);
            PutMapped(m.Instructions,d.instructions,"shipping instructions",true);
            Say("Billing and delivery panels filled separately.");
        }
    }
}
