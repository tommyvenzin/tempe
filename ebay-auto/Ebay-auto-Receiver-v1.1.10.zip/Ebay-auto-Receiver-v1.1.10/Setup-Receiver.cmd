@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup-Receiver.ps1"
set "EbayAutoExit=%ERRORLEVEL%"
pause
exit /b %EbayAutoExit%
