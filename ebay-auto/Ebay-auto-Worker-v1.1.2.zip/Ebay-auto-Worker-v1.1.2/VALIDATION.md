# Ebay-auto 1.1.2: what was tested, and how

Everything below ran in Claude's Linux sandbox (1.1.2 and 1.1.1 on 17 Nov 2026, 1.1.0 on 16 Nov), with made-up orders, made-up
COSTAR scans and made-up packages only (plus the real release files). **Nothing was run on Windows, inside Remote
Desktop, or against COSTAR, and no Windows window was ever shown.** These are automated tests of the code; the live
checks Seb's PCs still need are listed for each version.

Levels used here and in FEATURES.md:
- **S**: source level: the app's own self-tests (the same ones Build.ps1 runs on each PC before starting, and before an
  update is switched to).
- **E**: end-to-end here: the real 404 extension 1.5.0 in Chromium (headless) on made-up eBay order pages, talking over
  TLS to the **real receiver code** (Tests/receiver_harness.ps1); the worker is **played by the test script** over the
  worker API, sending what the real worker sends. For updates: the **real update code** against the **real release
  files** served over HTTP the way GitHub Pages serves them (Tests/update_replay.ps1), and `Launch.ps1` itself under
  PowerShell 7.
- **C**: compiled and read only.
- **L**: needs live Windows / Remote Desktop / COSTAR: **not tested**.

## 1.1.2: a new buyer's COSTAR customer account

The same account code as the Tempe helper 2.9.11 (its VALIDATION.md has the review and the code-level detail). The
sequence was captured on Tempe on 17 Nov (10 maps, lengths only); the self-tests use those maps' geometry with made-up
words.

| Run | What | Result |
|---|---|---|
| Compile | Roslyn at C# 5 against the five reference sets (4.8 as Build.ps1 and as the .rsp, 4.6.2, 4.7.1, 4.7.2), Build.ps1's 61 files (1.1.1: 58) | 0 errors; the same 3 warnings, each set. The old compiler's one-meaning-per-name rule (CS0135/CS0136): nothing |
| Self-tests | 1.1.1's cases plus the 13 new-customer cases of 2.9.11; the identity case now 1.1.2 | 209 pass, the same 4 Windows-only fails (1.1.1: 196; all 196 still pass) |
| Mutations | 26 deliberate bugs in the account code, run through the Tempe helper 2.9.11's self-tests (the same files), and 5 of them again through Ebay-auto's own (the split by sorted words, the form taken for a list of accounts, the tick off by default, every record holding COSTAR's windows back, the phone not required) | 26 of 26 caught; 5 of 5 caught |
| Node | Tests/test-costar-send.cjs (the extension, unchanged) | 11 groups pass |
| End-to-end | 1.1.1's 67 checks (COSTAR isn't part of it: the worker is played by the script) | 67 checks pass |
| Update replay | The real 1.1.2 upload set over HTTP, run with **1.1.0's** and with **1.1.1's own code** (a fresh build of each from its commit): each offers 1.1.2, downloads and checks it (both parts), the build stood in for, new orders held, switched at the safe point; the Tempe helper 2.9.11's files, a changed byte and the other part's package refused; Launch.ps1's hand-over and fallback. Run again with 1.1.2's code (nothing offered) | 28 checks pass, each of the three |
| Scans | Both packages, the upload set and the source bundle: no tokens, webhooks, keys, pairing or connection files, no `new-accounts.dat`, no Tests in the packages or the upload set; eBay order numbers, phones and e-mails made-up only; no number from the saved diagnostics (28 Oct to 17 Nov) in what 1.1.2 adds (2.9.10's few historical ones in shared files, as before) | clean |

| Asked | Tested here | Level | Not tested |
|---|---|---|---|
| The trigger: Customer Not found and X's Account# blank, nothing else | `NewAccount.NoticeOnly` and `Decide` (a list of accounts, no account in any branch, a cancelled search or a recovery never qualify); the lookup records it (code read) | S (mutation-checked), C | **L** |
| Every mandatory detail, the phone included, before anything is opened | `NewAccount.Missing` (a name of two words, street, suburb, state, postcode, a phone of 8 digits) | S (mutation-checked) | |
| Every word of the name, repeats too; no split that loses or adds words | `Words` / `SplitKeeps` on the form's Last and First; X's name word for word before the magnifier; the same words in any order after OK | S (mutation-checked) | **COSTAR's own split: L** |
| X, the magnifier, Add new, the fields checked, OK, the account confirmed, then Y | `Runner.NewAccount.cs` and the hook in Runner.Ebay.cs; the magnifier, the customer search and the form found by label, parent and place in the 17 Nov maps' geometry (X's magnifier, never Ship to's) | S, C | **Every press in COSTAR Sydney: L** |
| COSTAR's defaults and ticks unchanged | Nothing on the form is typed, ticked or chosen: only OK (or Cancel) is pressed; a personal service file must already be chosen | S, C | L |
| A detail missing: no account, Account# blank, the order goes on; the form open: Cancel back | `NotMade` (said, recorded, no stop); `CancelBack` (Cancel, then the Repair Order in front with nothing over it) | S, C | **L** |
| After OK, the account confirmed | `NewAccount.Uncertain`: the form gone, nothing over the order, the order in front and free, Account# a number at two looks, the same name's words and phone | S (mutation-checked) | **L** |
| Unsure after OK: never again for that order; Retry keeps an account; blank only when confirmed blank and the Repair Order ready; a dialog left for Seb | `NewAccountLog` (pure parts), the loose stop print and `SamePrint`, `LeftUnsure` (mutation-checked); `SteadyAccount`, `AccountLeftUnsure` in Check and `AnswerPopup` (code read) | S, C | **An unsure stop and its retry: L** |
| X checked again keeping COSTAR's Account# and name; the order's details restored; then Y | `FillOnlineHeader(true,false)` (the existing-customer path: Account# and name kept, every other box put back where it differs), then `FillDelivery` | C | **L** |
| Phone jobs and Repair Order edits unchanged | not called there (Ebay-auto enters eBay orders only) | C | |
| Every feature and diagnostic kept | every 1.1.1 self-test and end-to-end check passes; `new_account` events, review.json `NewAccount`, the tick's journey note | S, E, C | |

### Not tested live (1.1.2)

1. A new buyer's order in COSTAR Sydney: the magnifier, Add new, the form, OK, the account number on the Repair Order;
   then Ship to with the eBay delivery details, Rebill to EBAY, Terms (7INV), every check, "ez, next".
2. In COSTAR afterwards: one customer for that phone, the name split into Last and First with every word, the address
   and phone as on the order, a personal service file.
3. A new buyer missing a detail (a one-word name, no postcode): no account, the order as in 1.1.1.
4. An existing buyer: as in 1.1.1 (no magnifier).
5. An unsure stop and its Retry, if one ever happens (look at COSTAR first).
6. The update itself: 1.1.1's Update now to 1.1.2 on both parts; the new tick on afterwards.

## 1.1.1: each verified Repair Order left open ("ez, next")

| Run | What | Result |
|---|---|---|
| Compile | Roslyn at C# 5 against the .NET Framework 4.8 reference assemblies, Build.ps1's 58 files | 0 errors; the same 3 warnings |
| Self-tests | 1.1.0's cases plus 2 new 1.1.1 cases; the settings case of 2.5.2 ("closed by default") replaced by 1.1.1's (left open by default, an earlier tick turned off once, ticked again kept) | 196 pass, the same 4 Windows-only fails (1.1.0: 194) |
| Mutations | 4 deliberate bugs: "ez, next" despite a CHECK BY HAND; the one-time switch applied again after Seb ticked it; the receiver's words for "ez, next" missing; closing back on by default | 4 of 4 caught |
| Node | Tests/test-costar-send.cjs (the extension, unchanged) | 11 groups pass |
| End-to-end | 1.1.0's 62 checks plus V11: two orders, the worker reporting "ez, next" | 67 checks pass |
| Update replay | The real 1.1.1 upload set over HTTP, run with **1.1.0's own code** (the version Seb has after the move): 1.1.0 offers 1.1.1, downloads and checks it (both parts), the build stood in for, new orders held, switched at the safe point; the Tempe helper's files, a changed byte and the other part's package refused; Launch.ps1's hand-over and fallback. Run again with 1.1.1's code (nothing offered) | 28 checks pass, each way |
| Scans | Everything added since 1.1.0: only made-up order numbers, no addresses, e-mails, keys, tokens or webhooks | clean |

| Asked | Tested here | Level | Not tested |
|---|---|---|---|
| Keep every entry and verification step | The entry code is unchanged; the steps that came before the close (out of the item lines, PO# and total checked again) still run, only the close is not sent (code read: Runner.Ebay.cs) | C | **In COSTAR: L** |
| Leave the verified Repair Order open, no automatic close | The close (WM_CLOSE) is only sent with "Close each Repair Order" ticked; unticked by default | C, S | **L** |
| Report "ez, next" | The worker's words are exactly "ez, next" for a verified order left open (COSTAR's Notes still said after it); with a CHECK BY HAND, or closed (ticked), as before. On the eBay page: "In COSTAR Sydney ✓ ez, next" (green) | S, E | |
| Release the job; the next order in its own new Repair Order | The receiver hands out the next order in the same reply as "ez, next" (its own job); the worker opens each order with Add new as before, beside any Repair Order already open (1.1.0's code, unchanged) | E, C | **Add new in COSTAR with the earlier Repair Order open: L** |
| Not an error or NEEDS YOU, no failed-close warning | Counted as "fully entered and verified (completed without help)"; never CHECK BY HAND, handed over or stopped; no warning words; Hide finished tidies it like any finished order | S, E | |
| Diagnostics: verified and intentionally left for manual closure | Worker journey "left open on purpose for Seb to check and close by hand"; run record `ebay_left_open`; receiver journey "verified, left open on purpose"; the journal keeps each such Repair Order and notes when it is closed by hand (`left_open_ro_closed`); the worker's diagnostics list them | S, E, C | The 30-second look in Windows: L |
| Applies to the existing installation after updating | New settings: off; settings of 1.0.0 / 1.1.0 with the tick on: turned off once on the first start of 1.1.1 (recorded, said in the worker's window); ticked again later: kept; kept in the settings file | S (mutation-checked) | L |
| Add new while an order is open (as now) | Unchanged code (OpenNew with Repair Orders already open, as 1.1.0 does for handed-over orders and when the tick was off) | C | **L** |

### Not tested live (1.1.1)

1. One order in COSTAR Sydney: "ez, next" on the eBay page, the Repair Order left open with every line in, nothing
   closed.
2. The next order while that Repair Order is open: Add new, its own new Repair Order, the open one untouched.
3. Seb closing an open one by hand: the worker's diagnostics then say "closed by hand" for it.
4. The update itself: 1.1.0's Update now to 1.1.1 on both parts (the tick off afterwards, eBay orders on or paused as
   before).

## 1.1.0 (16 Nov 2026)

### The runs (1.1.0)

| Run | What | Result |
|---|---|---|
| Compile | Roslyn at C# 5 against the .NET Framework 4.8 reference assemblies, the same 58 files and references as Build.ps1 (tools/compile_check.ps1) | 0 errors; the same 3 warnings as 2.9.10 and 1.0.0 (CS0028, CS0649 ×2) |
| Self-tests | MobileTests under .NET 8 with shims (tools/harness/run_tests.ps1): 1.0.0's cases plus 9 new 1.1.0 cases (2 renamed) | 194 pass, 4 fail. 1.0.0 gave 185 pass and the same 4 fails; all 185 still pass. The 4 need Windows (WinForms process identity, the WinForms progress log, SetAccessControl, user32). Order Check's 16 pass |
| Mutations | 8 deliberate bugs in the new code, each run through the self-tests: Sydney by PID instead of start time; a branch change taken on one look; an unreadable Sydney given up; the product check removed; the receiver's hold ignored; the safe-point wait skipped; any protocol accepted; the window frame left out of the size | 8 of 8 caught (each fails its 1.1.0 case; nothing else changes) |
| Node | Tests/test-costar-send.cjs: the extension (unchanged since 1.0.0) | 11 groups pass |
| End-to-end | Tests/e2e_ebay_auto.py: 1.0.0's 53 checks plus V10 (1.1.0): mixed versions and updates through the real receiver code | 62 checks pass |
| Update replay | Tests/update_replay.ps1: the real update code and the real GitHub upload set (`GitHub-upload-Ebay-auto-v1.1.0.zip`) on a local web server, the Tempe helper's 2.9.10 upload set beside it; then `Launch.ps1` with a stand-in for powershell.exe | 27 checks pass |
| Scans | Everything added since 1.0.0 (git diff): no order numbers but the made-up ones (`15-11111-11111`, `16-11111-11111`, `22-22222-22222`, `33-33333-33333`), no addresses but 127.0.0.1, no e-mails, phone numbers, keys, tokens or webhooks; URLs only the GitHub Pages folder, 127.0.0.1 and example.invalid. The packages hold no Tests, keys, connections, queues or journals (the packaging refuses them) | clean |

### Tommy's checks for 1.1.0

| # | Asked | Tested here | Level | Not tested |
|---|---|---|---|---|
| 1 | COSTAR Sydney with other branches open | Made-up scans: Sydney chosen beside Tempe and Penrith; other branches never chosen; only other branches open → no COSTAR, orders wait; Order Check's COSTAR never chosen; the journey names branch, PID and start time, never a title | S | **Real COSTAR windows and process start times in Seb's session: L** |
| 2 | Several Sydney: the earliest-started | Two Sydney in three scan orders, the earlier-started one with the higher PID: always the earliest-started | S (mutation-checked) | L |
| 3 | A new Sydney or another window in front changes nothing | A third Sydney opens and the scan order changes: kept; an earlier-started COSTAR switched to Sydney: kept; the same COSTARs in another order are the same scan | S | L |
| 4 | Busy / unreadable / a dialog: wait, don't switch | The chosen Sydney missing from a scan but still running: kept, new orders wait with the reason; another branch on one look, and twice within a second: still kept (waiting); only two looks a second or more apart change it. In the code: a failed busy/dialog/Work-in-Progress check only waits and looks again (never re-chooses) | S (mutation-checked), C | **COSTAR busy or with a dialog in Remote Desktop: L** |
| 5 | Closing the chosen one: the earliest remaining, for new work | Closed: the earliest-started remaining is chosen; none left: wait; a Sydney back on Sydney later doesn't take the choice back | S | L |
| 6 | Closing or restarting COSTAR during an entry: no redirect, recreate or duplicate | Same PID with another start time = a new COSTAR (never taken for the old one). In the code: the order being entered keeps its own COSTAR to the end; the Retry of an order typed part-way is sent back only to its own COSTAR process and Repair Order, and when that COSTAR is gone the Retry is refused (1.0.0's rule, its self-tests unchanged and passing); the receiver never hands out an order twice (E2E V2, V7) | S, C, E | **An entry with COSTAR closed or restarted underneath it: L** |
| 7 | Start hidden, minimise, X, reopen, Exit | The window sizes and places for 5 screens (incl. 1280×680 and a screen left of the main one) × 5 scalings (100–200 %): always inside the working area, by the clock; the layout rule (past the page, overlapping). In the code: hidden start, minimise (button and other ways) and X hide with no taskbar button, double-click/Open restore (and back on screen), Exit, boxes opening the window first | S, C | **All of it on Windows (no window was shown here): L** |
| 8 | An update keeps settings, pairing, queue, duplicate history and hand-overs | The update writes only its own `packages\` and `update\` folders (replay); the state a part was in comes back once, for that part only, and an old one is ignored; a 1.0.0 worker and a 1.1.0 receiver work together (E2E V10); the receiver restart test of 1.0.0 (all orders back, nothing twice, the hand-over kept) still passes (E2E V7) | S, E | **A real switch between two running versions on Windows: L** |
| 9 | An update waits during an entry | The switch waits while the part says it isn't safe (an order being entered), saying why, with new orders held; Cancel takes orders again; then switches at the safe point (S). The receiver holding: an order sent meanwhile is kept, the worker gets none, the eBay page says the receiver is updating, then the order goes in (E2E V10); a worker updating itself takes nothing and the page says so (E2E V10) | S (mutation-checked), E | L |
| 10 | A failed update leaves a working install and diagnostics | A failed build: nothing switched or held, the version and the launchers' pointer unchanged, the error in words; a failed start is recorded for the version that starts again (round trip); downloads refused before anything is installed: the Tempe helper's latest.json, its ZIP (as is, and re-wrapped in an Ebay-auto folder name), a changed byte, the other part's package, a download outside Ebay-auto's folder, a version that doesn't match; `Launch.ps1` setting aside an installed version that can't build and starting the newest earlier one | S, E | **The old version starting again by itself after a new one fails on Windows: L** |
| 11 | Normal orders and NEEDS YOU unchanged | The COSTAR entry code (Runner*.cs) and the extension are byte-for-byte as in 1.0.0, and the queue's rules too (EbayModel.cs only gained the version and protocol fields); all 1.0.0 self-tests and the 53 end-to-end checks (normal orders, duplicates, one at a time, NEEDS YOU hand-over, restart, diagnostics, cut-over) pass | S, E | Typing into COSTAR: L (as for 1.0.0) |

#### The update replay (Tests/update_replay.ps1), in short

The upload set holds only README.txt and `ebay-auto/` (latest.json and the two packages). latest.json read over HTTP
past the cache and accepted (Ebay-auto 1.1.0, protocol 1). Each part: downloaded with progress to 100 %, size and
SHA-256 matched, unpacked, every file checked, exactly the package's files installed (receiver 75, worker 73), PART.txt
right, its own launcher, no Tests; installed again: reused once it checks out; the launchers' pointer names it. Then
refused, with nothing installed: the Tempe helper's latest.json; its ZIP under the worker's name with a latest.json made
to match; its package re-wrapped in a folder named as Ebay-auto's; the worker package with one byte changed; the
receiver's package under the worker's name; a latest.json naming a download outside the folder; a latest.json whose
version doesn't match; a download from outside the folder (refused by the downloader). Then `Launch.ps1` of 1.1.0:
hands over to a newer installed worker, hidden; never to the other part's package or an older version; and sets aside a
pointed version that can't build (no Windows compiler here) for the newest earlier one.

### Not tested live (1.1.0: please check with Seb)

1. **The move from 1.0.0** (MIGRATE-FROM-1.0.0.txt) on both parts: both start, the receiver keeps its orders, the
   worker its connection, "Start ... when I sign in" starts 1.1.0 at the next sign-in, no console window stays open.
2. **Which Sydney**, inside Seb's Remote Desktop session: with other branches open, then with two Sydney (the one
   started first is used; the worker's window shows its PID and start time; opening another or bringing it to the front
   changes nothing; closing the one in use while nothing is entered moves new orders to the other).
3. **The windows**: start hidden; minimise and X leave no taskbar button; double-click the icon and Open bring the window
   back; every tab readable at Seb's scaling on both PCs; Exit.
4. **The first one-click update** (when Tommy uploads the next version): the balloon, Update now, the progress, the wait
   while an order is entered, the switch (about a minute), back as it was (running or paused, window), the order list,
   the duplicate history and the worker's connection kept.
5. GitHub Pages serving `https://tommyvenzin.github.io/tempe/ebay-auto/latest.json` after the upload.
6. Everything 1.0.0 listed as not tested live (Setup-Receiver, Chrome's Allow tab, an unknown-SKU order with Quick Item
   Add cancelled, the next order beside a handed-over Repair Order, Export diagnostics on both parts).

Suggested first live test: move both parts (MIGRATE-FROM-1.0.0.txt), send one normal order with Sydney and another
branch open, then open a second Sydney and send another; Export diagnostics on the worker and send the ZIP.

## 1.0.0 (for reference)

16 Nov 2026, same sandbox: compile 0 errors (3 warnings); self-tests 185 pass, 4 Windows-only; Node 11 groups;
end-to-end 53 checks (normal order, duplicate, one at a time, unknown SKU hand-over, the next order beside it, the
receiver restarted, diagnostics, Tommy's PC not needed, pairing, paused receiving, the cut-over). Not tested live: as
listed above in item 6.
