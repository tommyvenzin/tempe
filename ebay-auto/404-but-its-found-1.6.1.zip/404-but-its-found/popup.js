// Clicking the extension icon opens this popup. It copies the console script straight away,
// can show the copy panel on the eBay tab you're looking at, and (1.4) pairs this PC with
// the receiver for Send to COSTAR (1.5.0: the Ebay-auto receiver on this PC, address with its port).
const SCRIPT = 'ebay_order_console.js';
const PANEL_FILES = ['costar_send.js', SCRIPT];
const PANEL_ID = 'ebay-order-copy-panel';
const $ = id => document.getElementById(id);
const ask = msg => new Promise(resolve => {
  try { chrome.runtime.sendMessage(msg, r => resolve(r || { ok: false, error: chrome.runtime.lastError ? chrome.runtime.lastError.message : 'No answer.' })); }
  catch (e) { resolve({ ok: false, error: String(e.message || e) }); }
});

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (e) {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.append(ta);
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  }
}

async function copyScript() {
  const msg = $('copyMsg');
  try {
    const text = await (await fetch(chrome.runtime.getURL(SCRIPT))).text();
    if (!(await copyText(text))) throw new Error('copy failed');
    msg.textContent = '✓ Script copied - paste it in the console (F12) if you need it.';
    msg.className = 'msg ok';
  } catch (e) {
    msg.textContent = 'Could not copy the script.';
    msg.className = 'msg bad';
  }
}

async function setupShowButton() {
  const btn = $('show'), hint = $('showMsg');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^https:\/\/([\w-]+\.)*ebay\.com\.au\//i.test(tab.url || '')) {
    btn.disabled = true;
    hint.textContent = 'Open an eBay order page to use this.';
    return;
  }
  btn.addEventListener('click', async () => {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: PANEL_FILES });
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: id => !!document.getElementById(id),
        args: [PANEL_ID],
      });
      if (result) window.close();
      else hint.textContent = 'No order found on this page.';
    } catch (e) {
      hint.textContent = 'Could not run on this page.';
    }
  });
}

async function setupAutoBox() {
  const box = $('auto');
  box.checked = (await chrome.storage.local.get({ auto: true })).auto;
  box.addEventListener('change', () => chrome.storage.local.set({ auto: box.checked }));
}

// ---- The Ebay-auto receiver ----
// 1.4.1: Chrome (156+) lets an extension reach a shop-network address only with access to that
// address. It is asked for on Connect / Check again (a click), for the receiver's address only.
function siteFor(text) {
  const t = String(text || '').trim().replace(/^https?:\/\//i, '').replace(/[/?#].*$/, '').replace(/:\d{1,5}$/, '');
  const m = t.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!m) return null;
  const b = m.slice(1, 5).map(Number);
  if (b.some(n => n > 255)) return null;
  const ok = b[0] === 10 || (b[0] === 192 && b[1] === 168) || (b[0] === 172 && b[1] >= 16 && b[1] <= 31) || (b[0] === 127 && b[1] === 0 && b[2] === 0 && b[3] === 1);
  return ok ? `https://${b.join('.')}/*` : null;
}
// 1.4.2: Chrome's Allow box doesn't show reliably from this popup, so the OK is asked for in a tab
// (allow.html).
async function hasSite(site) {
  try { return await chrome.permissions.contains({ origins: [site] }); } catch (e) { return false; }
}
function openAllow(site) { chrome.tabs.create({ url: chrome.runtime.getURL('allow.html') + '?site=' + encodeURIComponent(site) }); }
const ALLOW_TAB = "Chrome needs your OK for this extension to reach the Ebay-auto receiver: click Allow in the tab that just opened, then click the 404 icon and Connect again.";
let pairedHost = '';
function state(text, tone) { const el = $('pcState'); el.textContent = text; el.className = 'msg' + (tone ? ' ' + tone : ''); }
function describeHealth(h) {
  const waiting = h.pendingCount > 0 ? ` ${h.pendingCount} order(s) waiting there.` : '';
  if (!h.receiving) return ['The Ebay-auto receiver is paused (Resume receiving on it).' + waiting, 'warn'];
  if (!h.helperConnected) return ['The receiver is running, but the worker in Remote Desktop is not in touch: orders wait on the receiver until it is.' + waiting, 'warn'];
  if (!h.ebayOn) return ['eBay orders are paused in the worker (in Remote Desktop): orders wait on the receiver.' + waiting, 'warn'];
  // 1.6.0 (20 Nov 2026): a 1.1.9 receiver says for each branch whether the worker can start an order there now.
  if (h.branchReady && typeof h.branchReady === 'object') {
    const word = { 1: 'COSTAR Sydney (Br1)', 11: 'COSTAR Tempe (Br11)' }, w = h.branchWaiting || {};
    const parts = [1, 11].map(b => word[b] + (h.branchReady[b] ? ' ready' : ': ' + (w[b] || 'not ready')));
    const all = h.branchReady[1] && h.branchReady[11];
    return [(all ? 'Connected ✓ ' : 'Connected. ') + parts.join('; ') + '.' + waiting, all ? 'ok' : 'warn'];
  }
  if (h.orderSchema !== 'tempe.ebay-order.v3') return ['Connected, but the Ebay-auto receiver' + (h.version ? ' (' + h.version + ')' : '') + " can't take Sydney/Tempe orders yet: update both Ebay-auto parts to 1.1.10." + waiting, 'warn'];
  if (!h.ready) return ['Connected. ' + (h.waiting || 'Waiting for COSTAR.') + waiting, 'warn'];
  return ['Connected ✓ The worker is ready.' + waiting, 'ok'];
}
async function showPaired(host) {
  pairedHost = host;
  $('pairForm').hidden = true; $('pairedBox').hidden = false;
  state(`Connected to ${host}. Checking…`);
  const r = await ask({ type: 'costar-health' });
  if (!r.ok) { state(r.error || 'Could not check.', 'bad'); return; }
  const [text, tone] = describeHealth(r.health);
  state(`${r.host}: ${text}`, tone);
}
let earlier = false;
function showUnpaired(message, tone) {
  $('pairForm').hidden = false; $('pairedBox').hidden = true;
  state(message || (earlier ? "Not paired with the Ebay-auto receiver yet. The earlier pairing with Tommy's PC (1.4) is no longer used: pair once with the receiver on this PC." : 'Not paired yet. Pair once to use Send to COSTAR on order pages.'), tone || (earlier ? 'warn' : ''));
}
async function setupCostar() {
  const d = await ask({ type: 'costar-desk' });
  earlier = !!(d.ok && d.earlier);
  if (d.ok && d.paired) await showPaired(d.host); else showUnpaired();
  $('pcConnect').addEventListener('click', async () => {
    const btn = $('pcConnect'), site = siteFor($('pcAddress').value);
    if (!site) { showUnpaired('Type the address shown by Pair eBay PC on the Ebay-auto receiver, like 192.168.1.20:8811.', 'bad'); return; }
    if (!(await hasSite(site))) { openAllow(site); showUnpaired(ALLOW_TAB, 'warn'); return; }
    btn.disabled = true; state('Connecting…');
    try {
      const r = await ask({ type: 'costar-pair', address: $('pcAddress').value, pin: $('pcPin').value });
      if (!r.ok) { showUnpaired(r.error, 'bad'); return; }
      $('pcPin').value = '';
      await showPaired(r.host);
    } finally { btn.disabled = false; }
  });
  $('pcPin').addEventListener('keydown', e => { if (e.key === 'Enter') $('pcConnect').click(); });
  $('pcTrust').addEventListener('click', async () => {
    const r = await ask({ type: 'costar-trust-url', address: $('pcAddress').value });
    if (!r.ok) { showUnpaired(r.error, 'bad'); return; }
    chrome.tabs.create({ url: r.url });
  });
  $('pcCheck').addEventListener('click', async () => {
    const site = siteFor(pairedHost);
    if (site && !(await hasSite(site))) { openAllow(site); state(ALLOW_TAB, 'warn'); return; }
    const x = await ask({ type: 'costar-desk' }); if (x.ok && x.paired) await showPaired(x.host); else showUnpaired();
  });
  $('pcForget').addEventListener('click', async () => { await ask({ type: 'costar-forget' }); showUnpaired('Forgotten. Pair again to send orders.'); });
}

copyScript();
setupShowButton();
setupAutoBox();
setupCostar();
