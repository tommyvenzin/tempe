# Ebay-auto 1.1.8 - 19 November 2026

Receiver and worker 1.1.8, with 404 extension 1.5.2. This bundle includes all the phone, name, stock and address changes.

## Patch notes

- **Phone priority:** Contact info first. If Account# stays blank, try Ship to. If neither finds an account, return to Contact info before the existing new-customer step. A matched account keeps its matching phone; Y keeps the Ship to phone. Missing Contact info stops Send. Retry remembers the lookup step.
- **Correct names:** billing X uses the real name from eBay's Order/Buyer section above the username. A different name is corrected even when an account is linked, keeping Account#. Delivery Y uses the Ship to recipient. M BUY still uses the username. Missing names stop Send instead of borrowing another name.
- **Stock check:** read Sydney's displayed ThisBr Avail for each recognised product after quantity and price. Above 2 continues automatically. From 0 to 2 inclusive, type `ok` or `check`. Negative availability requires `yes`, confirming Seb will call or message the customer. Every accepted answer continues normal entry. The helper does not contact customers.
- **Checking stock:** `check` adds `low stock - currently checking` to the existing comment, using COSTAR's normal uppercase. The note survives Retry. Answers and readings are recorded in diagnostics. Changed stock is checked again.
- **Required prompt:** no default approval or close button. Escape and Alt+F4 cannot skip it. Stop still stops the order; the next order waits. Unreadable or ambiguous stock stops entry and records why.
- **Cleaner addresses:** `1/1,sample st` becomes `1/1 SAMPLE STREET`; `Unit 8. 15-23 Sample street` becomes `8/15-23 SAMPLE STREET`. An explicit unit on its own line can join the next complete street line. Clear glued number/street words and spacing are cleaned up. Suffixes, ranges, building/level details and uncertain addresses are preserved. Preview and COSTAR use the same formatter. Local formatting only; no new lookup service, account, paid API or database.
- **Stable duplicate checks:** identical resends remain identical if the runtime changes JSON field order.

## Existing behaviour retained

Sydney selection, the first-opened Sydney instance, multiple COSTAR windows, sequential entry, tray icons, one-click app updates, pairing, diagnostics and unknown-SKU handover remain. New-customer account checks and the once-per-order OK safeguard remain.

Successful Repair Orders stay open for Seb's checks and manual closure. The helper reports `ez, next` and releases the job; the next order uses its own new Repair Order. If its number is blank, Next # generates it. The clipboard receives the number followed by `DFE`.

## Installing this update

1. Finish any order currently being entered. Update BOTH receiver and worker to 1.1.8.
2. Replace the contents of the existing unpacked extension folder with `404-but-its-found-1.5.2.zip`, then click Reload on its Chrome extensions card. Keep the same folder so pairing stays in place.
3. Refresh the eBay page before sending another order.

Older queued orders have the old payload and are refused before entry. If nothing was entered, remove that waiting order on the receiver and re-send it with extension 1.5.2. If partly entered, finish that Repair Order by hand. Finished-order records are retained.

The order payload is `tempe.ebay-order.v2`. Older receivers/workers reject it rather than silently losing the separate phone or names. Transport protocol and pairing are unchanged.

## Bundle contents

Receiver ZIP for Seb's PC, worker ZIP for RDP, Chrome extension ZIP, source backup with tests, and GitHub upload ZIP. Upload only the GitHub bundle's `ebay-auto` folder when ready; extension updates are separate.

Source is based on corrected published 1.1.7, including its number-and-popup protections. Packaging does not publish, install, reload Chrome or send an order.

## Validation and first live check

Windows C# 5/.NET Framework compilation and all 286 automated test groups passed: 245 application, 16 Order Check, 11 extension payload and 14 parser/formatter groups. All extension JavaScript syntax checks passed. See `VALIDATION.md` and the included package verification reports.

The stock pane read and visible prompt have not been tested on a live eBay Repair Order or inside RDP. Its reader comes from existing wholesale maps; missing or ambiguous readings stop. Full receiver/Chromium end-to-end replay was not run.

Watch the first live order: phone selection, X/Y names, shipping address, stock prompt/comment, and open Repair Order with DFE clipboard text. Negative stock asks Seb to contact the customer without sending a message itself.

## Local development

Run `Tests/run-local.ps1` with PowerShell 7 to compile and test without opening or typing into COSTAR. Then run `Tests/package-release.py` with Python to build and verify release ZIPs. Packaging uses corrected 1.1.7 templates in neighbouring `publish-117`. The older end-to-end/replay harnesses require their original environment.
