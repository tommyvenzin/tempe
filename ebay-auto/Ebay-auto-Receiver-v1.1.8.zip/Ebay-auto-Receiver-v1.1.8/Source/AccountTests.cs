// Self-tests for the new-customer account step (2.9.11): the decision, the order's details, the name's words, COSTAR's
// customer search and new-customer form read from made-up controls laid out as the maps of 17 Nov (lengths only in the maps:
// every word here is made up), the magnifier beside Account#, what the Repair Order must show after OK, the record that keeps
// OK to once per order, and the print a retry compares. Never opens, clicks or types into COSTAR.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace TempeCostar {
    internal static class AccountTests {
        static void Check(bool value,string message){if(!value)throw new InvalidOperationException(message);}
        const string ST="WindowsForms10.STATIC.app.0.1",ED="WindowsForms10.EDIT.app.0.1",BT="WindowsForms10.BUTTON.app.0.1",WF="WindowsForms10.Window.8.app.0.1";
        static ControlInfo Mk(long h,long parent,string cls,int x,int y,int w,int hh,string text,bool enabled=true) {
            return new ControlInfo {Handle=h,Parent=parent,Class=cls,Visible=true,Enabled=enabled,Bounds=new[]{x,y,w,hh},RelativeBounds=new[]{x,y,w,hh},Text=text,TextState="read"};
        }
        // A made-up new customer (every detail COSTAR's form asks for).
        static Customer Buyer() { return new Customer {name="Jamie Testfield",streetAddress="1 TEST CRESCENT",address2="",suburb="TESTVILLE",state="NSW",postcode="2799",phone="0400 000 001",email="test.buyer@example.com"}; }
        // The Repair Order's customer panel (X, panel 100), Ship to (Y, panel 201) and one item line, as the 17 Nov maps lay them out.
        sealed class Ro { internal string Account="",Name="JAMIE TESTFIELD",Address="1 TEST CRESCENT",Suburb="TESTVILLE",State="NSW",Postcode="2799",Phone="0400000001",Email="test.buyer@example.com",Po="TTW0000001",Comment="";
            internal string YAccount="",YName="",YAddress="",YSuburb="",YState="",YPostcode="",YMobile="",YEmail="";internal bool Magnifier=true,SecondMagnifier,YMagnifier=true,StrayButton; }
        static List<ControlInfo> RoControls(Ro r) {
            var s=new List<ControlInfo>();
            s.Add(Mk(9001,100,ST,37,111,285,17,"Account#                        Name"));
            s.Add(Mk(2,100,ED,37,128,122,20,r.Account));
            if(r.Magnifier) s.Add(Mk(3,2,BT,136,130,21,16,null));
            if(r.SecondMagnifier) s.Add(Mk(9,2,BT,115,130,21,16,null));
            if(r.StrayButton) s.Add(Mk(98,100,BT,136,130,21,16,null));
            s.Add(Mk(4,100,ED,158,128,226,20,r.Name));
            s.Add(Mk(5,100,ED,37,147,347,20,r.Address));s.Add(Mk(6,100,ED,37,166,347,20,""));
            s.Add(Mk(7,100,ED,37,185,208,20,r.Suburb));s.Add(Mk(8,100,ED,244,185,56,20,r.State));s.Add(Mk(10,100,ED,299,185,85,20,r.Postcode));
            s.Add(Mk(11,100,ST,37,215,148,15,"Contact"));s.Add(Mk(12,100,ST,184,215,100,15,"Bus Ph"));s.Add(Mk(13,100,ED,37,230,148,20,""));s.Add(Mk(14,100,ED,184,230,100,20,""));
            s.Add(Mk(15,100,ST,37,250,148,15,"eMail"));s.Add(Mk(16,100,ST,184,250,100,15,"Mobile Ph"));s.Add(Mk(17,100,ED,37,265,148,20,r.Email));s.Add(Mk(18,100,ED,184,265,100,20,r.Phone));
            s.Add(Mk(19,100,ST,274,295,109,15,"PO#"));s.Add(Mk(20,100,ED,274,310,109,20,r.Po));
            s.Add(Mk(21,1,ST,706,85,51,13,"Comment"));s.Add(Mk(22,1,ED,782,82,265,20,r.Comment));
            s.Add(Mk(50,201,ED,600,128,122,20,r.YAccount));if(r.YMagnifier) s.Add(Mk(51,50,BT,699,130,21,16,null));
            s.Add(Mk(52,201,ED,721,128,226,20,r.YName));s.Add(Mk(53,201,ED,600,147,347,20,r.YAddress));s.Add(Mk(54,201,ED,600,166,347,20,""));
            s.Add(Mk(55,201,ED,600,185,208,20,r.YSuburb));s.Add(Mk(56,201,ED,807,185,56,20,r.YState));s.Add(Mk(57,201,ED,862,185,85,20,r.YPostcode));
            s.Add(Mk(58,201,ST,600,215,147,15,"Contact"));s.Add(Mk(59,201,ST,746,215,101,15,"Bus Ph"));s.Add(Mk(60,201,ED,600,230,147,20,""));s.Add(Mk(61,201,ED,746,230,101,20,""));
            s.Add(Mk(62,201,ST,600,250,147,15,"eMail"));s.Add(Mk(63,201,ST,746,250,101,15,"Mobile Ph"));s.Add(Mk(64,201,ED,600,265,147,20,r.YEmail));s.Add(Mk(65,201,ED,746,265,101,20,r.YMobile));
            s.Add(Mk(66,201,ST,600,295,147,15,"Ship Via"));s.Add(Mk(67,201,ST,846,295,195,15,"Shipping Instructions"));s.Add(Mk(68,201,ED,600,310,147,20,""));s.Add(Mk(69,201,ED,846,310,195,20,""));
            s.Add(Mk(80,300,ST,69,341,79,27,"Item"));s.Add(Mk(81,300,ST,223,341,87,27,"Description"));s.Add(Mk(82,300,ST,728,341,45,27,"Qty   or Hrs"));s.Add(Mk(83,300,ST,769,341,56,26,"List"));s.Add(Mk(84,300,ST,873,341,56,27,"Net"));
            for(int i=0;i<25;i++) {
                int y=369+19*i;long panel=500+i,b=1000+10*i;
                s.Add(Mk(panel,300,WF,37,y,1010,20,""));
                s.Add(Mk(b,panel,ED,72,y,155,20,i==0?"W43116":""));s.Add(Mk(b+1,panel,ED,225,y,480,20,i==0?"WINRUN 265/70R16 112T MAXCLAW A/T":""));
                if(i==0) { s.Add(Mk(b+2,panel,ED,728,y,40,20,"1"));s.Add(Mk(b+3,panel,ED,769,y,56,20,"140.00"));s.Add(Mk(b+4,panel,ED,873,y,56,20,"140.00")); }
            }
            return s;
        }
        // COSTAR's customer search as the magnifier opens it (17 Nov, three times alike).
        static List<ControlInfo> Search(bool addNew=true,bool twoCancels=false) {
            var s=new List<ControlInfo>{Mk(1,0,ST,13,72,991,19,"Search for an Existing Customer"),Mk(2,0,BT,238,93,128,21,"C&lear"),Mk(3,0,BT,472,98,72,64,"&Search"),
                Mk(4,0,BT,545,98,72,64,"&Cancel"),Mk(5,0,BT,618,98,72,64,"&OK",false),Mk(6,0,BT,501,169,153,21,"Include Inactive [X]"),Mk(7,0,BT,912,261,97,25,"&Print Results"),
                Mk(8,0,ST,0,114,235,19,"Cust# / Name"),Mk(9,0,ED,239,112,126,21,""),Mk(10,0,ST,0,132,235,17,"Phone"),Mk(11,0,ED,239,130,126,21,""),Mk(12,0,ST,0,222,235,17,"Branch"),Mk(13,0,ED,239,220,126,21,"11")};
            if(addNew) s.Add(Mk(20,0,BT,15,93,66,56,"&Add new"));
            if(twoCancels) s.Add(Mk(21,0,BT,700,98,72,64,"&Cancel"));
            return s;
        }
        // COSTAR's "Add new cash customer" as the 17 Nov maps show it (14:39 and 14:41), with made-up words.
        sealed class Form { internal string Last="TESTFIELD",First="JAMIE",Address="1 TEST CRESCENT",City="TESTVILLE",State="NSW",Postcode="2799",Mobile="0400000001",Home="",Email="test.buyer@example.com";
            internal bool NoCity,TwoOk,InnerState=true; }
        static List<ControlInfo> FormControls(Form f) {
            var s=new List<ControlInfo>{Mk(1,0,ST,14,71,314,20,"Cash Customer!"),
                Mk(2,50,BT,35,121,506,19,"File service record under \"CASH\" account"),Mk(3,50,BT,35,152,506,25,"Open a personal service file for this new cash customer"),
                Mk(10,10,ST,15,205,95,20,"Last name"),Mk(11,10,ED,121,207,305,21,f.Last),Mk(12,10,ST,108,208,10,20,"*"),Mk(13,10,BT,439,208,98,20,"Individual ?"),
                Mk(14,10,ST,24,236,86,20,"First name"),Mk(15,10,ED,121,238,305,21,f.First),Mk(16,10,ST,24,259,86,20,"Title"),Mk(17,10,ED,121,261,155,21,""),
                Mk(20,20,ST,24,288,86,20,"Address"),Mk(21,20,ED,121,290,415,21,f.Address),Mk(22,20,ED,121,313,415,21,""),
                Mk(25,20,ST,326,335,114,20,"State/Province"),Mk(26,20,WF,451,336,85,22,null),Mk(29,20,ST,326,358,116,20,"Country"),Mk(30,20,ED,451,360,85,21,""),
                Mk(31,20,ST,24,359,86,20,"Postcode"),Mk(32,20,ED,121,359,89,21,f.Postcode),Mk(33,20,BT,214,358,92,23,"&Search..."),
                Mk(40,30,ST,34,389,83,20,"Contact"),Mk(41,30,ED,121,390,185,21,""),Mk(42,30,ST,38,409,268,20,"Phone Number(s)"),
                Mk(43,30,ST,29,428,83,20,"Home"),Mk(44,30,ED,121,430,185,21,f.Home),Mk(45,30,ST,29,451,83,20,"Mobile"),Mk(46,30,ED,121,453,185,21,f.Mobile),
                Mk(47,30,ST,29,474,83,20,"Bus."),Mk(48,30,ED,121,476,185,21,""),Mk(49,30,ST,29,497,83,20,"Fax"),Mk(50,30,ED,121,499,185,21,""),
                Mk(51,30,ST,29,520,83,20,"eMail"),Mk(52,30,ED,121,522,185,21,f.Email),Mk(53,30,ST,308,412,112,20,"GST Exemption"),Mk(54,30,ED,431,414,105,21,""),
                Mk(60,60,BT,25,594,249,25,"Customer consents to future follow up"),Mk(61,60,BT,30,638,158,25,"Mail"),
                Mk(70,70,BT,297,721,120,28,"&OK"),Mk(71,70,BT,423,721,120,28,"&Cancel")};
            if(!f.NoCity) { s.Add(Mk(23,20,ST,24,334,86,20,"City"));s.Add(Mk(24,20,ED,121,336,185,21,f.City)); }
            if(f.InnerState) s.Add(Mk(27,26,WF,451,336,85,22,f.State));
            if(f.TwoOk) s.Add(Mk(72,70,BT,200,721,90,28,"&OK"));
            return s;
        }
        static CustomerPanel X() { return new CustomerPanel {Account="",Name="JAMIE TESTFIELD",Address="1 TEST CRESCENT",Suburb="TESTVILLE",State="NSW",Postcode="2799",Phone="0400000001"}; }
        static NewAccountValues Values() { return new NewAccountValues {Last="TESTFIELD",First="JAMIE",Address="1 TEST CRESCENT",City="TESTVILLE",State="NSW",Postcode="2799",Home="",Mobile="0400000001",Business="",Fax="",PersonalFile=true}; }
        static AfterOkLook Made() { return new AfterOkLook {FormUp=false,OtherWindow=false,OrderFront=true,OrderEnabled=true,AccountBefore="",Account="T123456",AccountAgain="T123456",NameBefore="JAMIE TESTFIELD",Name="JAMIE TESTFIELD",Phone="0400000001",OrderPhone="0400 000 001"}; }

        internal static void Cases(Action<string,Action> Case) {
            Case("New accounts (2.9.11): a name's words, COSTAR's split into First and Last kept only with every word (repeats too), the name after OK the same words in any order",()=>{
                Check(NewAccount.Words(" jamie   o'neil-smith, jr ").SequenceEqual(new[]{"JAMIE","O'NEIL-SMITH","JR"}),"Words not COSTAR's capitals split at spaces and commas.");
                Check(NewAccount.SplitKeeps("JAMIE TESTFIELD","JAMIE","TESTFIELD")&&NewAccount.SplitKeeps("JAMIE TESTFIELD","TESTFIELD","JAMIE"),"A split keeping both words (either way) refused.");
                Check(NewAccount.SplitKeeps("jamie  testfield","JAMIE","testfield"),"Capitals or spacing counted as a difference.");
                Check(NewAccount.SplitKeeps("MARY ANN TESTFIELD","MARY ANN","TESTFIELD")&&NewAccount.SplitKeeps("MARY ANN TESTFIELD","MARY","ANN TESTFIELD"),"A three-word name split at either place refused.");
                Check(!NewAccount.SplitKeeps("MARY ANN TESTFIELD","ANN","MARY TESTFIELD"),"A split that reorders the name's words accepted.");
                Check(NewAccount.SplitKeeps("ANNA ANNA TESTFIELD","ANNA ANNA","TESTFIELD"),"A repeated word kept twice refused.");
                Check(!NewAccount.SplitKeeps("ANNA ANNA TESTFIELD","ANNA","TESTFIELD"),"A split that loses a repeated word accepted.");
                Check(!NewAccount.SplitKeeps("JAMIE TESTFIELD","JAMIE","TESTFIELD TESTFIELD")&&!NewAccount.SplitKeeps("JAMIE TESTFIELD","JAMIE","TESTFIELD JR"),"A split that adds a word accepted.");
                Check(!NewAccount.SplitKeeps("JAMIE TESTFIELD","","JAMIE TESTFIELD")&&!NewAccount.SplitKeeps("JAMIE TESTFIELD","JAMIE TESTFIELD",""),"A split with an empty box accepted.");
                Check(!NewAccount.SplitKeeps("CHER","CHER","CHER")&&!NewAccount.SplitKeeps("","",""),"A one-word or empty name accepted.");
                Check(!NewAccount.SplitKeeps("DR JAMIE TESTFIELD","JAMIE","TESTFIELD"),"A word moved elsewhere (a title) accepted.");
                Check(NewAccount.SameWords("TESTFIELD, JAMIE","JAMIE TESTFIELD")&&NewAccount.SameWords("jamie testfield","JAMIE  TESTFIELD"),"COSTAR's own order or commas for the same name refused.");
                Check(!NewAccount.SameWords("JAMIE TESTFIELD","JAMIE TESTFELD")&&!NewAccount.SameWords("ANNA ANNA LEE","ANNA LEE")&&!NewAccount.SameWords("ANNA LEE","ANNA LEE LEE")&&!NewAccount.SameWords("",""),"A different name (a word changed, lost or added) taken for the same.");
            });
            Case("New accounts (2.9.11): every detail COSTAR's form asks for, phone included, from the order itself",()=>{
                Check(NewAccount.Missing(Buyer()).Count==0,"A complete order said to lack something.");
                Func<Action<Customer>,string> lack=delegate(Action<Customer> change) { var c=Buyer();change(c);return String.Join(", ",NewAccount.Missing(c).ToArray()); };
                Check(lack(c=>c.name="Cher")=="first and last name"&&lack(c=>c.name="  ")=="name","A one-word or missing name not named.");
                Check(lack(c=>c.streetAddress=" ")=="street address"&&lack(c=>c.suburb="")=="suburb"&&lack(c=>c.state=null)=="state"&&lack(c=>c.postcode="")=="postcode","A missing street, suburb, state or postcode not named.");
                Check(lack(c=>c.phone="")=="phone"&&lack(c=>c.phone="0400 000")=="phone"&&lack(c=>c.phone="+61 400 000 001")=="","The phone (8 digits at least) not required, or a good one refused.");
                Check(lack(c=>{c.postcode="";c.state="";})=="state, postcode"&&NewAccount.Missing(null).Count==1,"Several missing details not all named.");
                Check(lack(c=>c.email="")==""&&lack(c=>c.address2="")=="","An email or second address line (not required by COSTAR) required.");
            });
            Case("New accounts (2.9.11): only after Customer Not found with nothing else, Account# blank, switched on, direct presses on, an order number, every detail, the record readable and OK never pressed for the order before",()=>{
                var none=new List<string>();var some=new List<string>{"postcode"};
                Check(NewAccount.NoticeOnly(true,false,false,0,0),"Customer Not found alone refused.");
                Check(!NewAccount.NoticeOnly(false,false,false,0,0)&&!NewAccount.NoticeOnly(true,true,false,0,0)&&!NewAccount.NoticeOnly(true,false,true,0,0)&&!NewAccount.NoticeOnly(true,false,false,1,0)&&!NewAccount.NoticeOnly(true,false,false,0,1),
                    "A lookup ending another way (no notice, a list, every branch searched, a popup or search cancelled) taken for Customer Not found.");
                Check(NewAccount.Decide(true,true,true,"","TTW0000001",none,false)==NewAccount.Make,"An eligible new customer refused.");
                Check(NewAccount.Decide(true,true,true,"C100","TTW0000001",none,false)==NewAccount.HasAccount,"An account on the order not kept.");
                Check(NewAccount.Decide(true,true,false,"","TTW0000001",none,false)==NewAccount.NotNotice,"A lookup that didn't end with Customer Not found made an account.");
                Check(NewAccount.Decide(false,true,true,"","TTW0000001",none,false)==NewAccount.Off&&NewAccount.Decide(true,false,true,"","TTW0000001",none,false)==NewAccount.Mouse,"Switched off, or direct presses off, still makes one.");
                Check(NewAccount.Decide(true,true,true,"","  ",none,false)==NewAccount.NoNumber,"An order without a number (nothing to keep it by) makes one.");
                Check(NewAccount.Decide(true,true,true,"","TTW0000001",some,false)=="missing: postcode","Missing details not said.");
                Check(NewAccount.Decide(true,true,true,"","TTW0000001",none,null)==NewAccount.NoRecord,"An unreadable record of accounts (OK maybe pressed before) still makes one.");
                Check(NewAccount.Decide(true,true,true,"","TTW0000001",none,true)==NewAccount.Tried,"OK pressed before for this order: pressed again.");
                Check(NewAccount.Decide(true,true,true,"","TTW0000001",some,null)=="missing: postcode","The record looked at before the details (it is only read once the rest allows an account).");
            });
            Case("New accounts (2.9.11): the Repair Order's customer details must be the order's before the magnifier (Account# blank, the name's words, street, suburb, state, postcode, phone)",()=>{
                Check(NewAccount.PanelProblems(X(),Buyer()).Count==0,"X as entered refused.");
                Func<Action<CustomerPanel>,string> wrong=delegate(Action<CustomerPanel> change) { var x=X();change(x);return String.Join(", ",NewAccount.PanelProblems(x,Buyer()).ToArray()); };
                Check(wrong(x=>x.Account="C100")=="Account# (not blank)"&&wrong(x=>x.Name="JAMIE")=="name"&&wrong(x=>x.Name="TESTFIELD JAMIE")=="name","An account, a lost word or another word order on X accepted.");
                Check(wrong(x=>x.Suburb="OTHERVILLE")=="suburb"&&wrong(x=>x.Postcode="")=="postcode"&&wrong(x=>x.State="VIC")=="state"&&wrong(x=>x.Address="2 TEST CRESCENT")=="street address","A suburb, postcode, state or street other than the order's accepted.");
                Check(wrong(x=>x.Phone="0400000002")=="phone"&&wrong(x=>x.Phone="0400 000 001")=="","Another phone accepted, or the same digits spaced refused.");
            });
            Case("New accounts (2.9.11): the magnifier beside Account# found on X's Account# box (never Ship to's), only when it is the one there",()=>{
                var s=RoControls(new Ro());var h=Selectors.Header(s);
                var m=Selectors.AccountLookup(s,h);
                Check(m!=null&&m.Handle==3,"The magnifier inside X's Account# box not found.");
                Check(Selectors.AccountLookup(RoControls(new Ro {Magnifier=false}),Selectors.Header(RoControls(new Ro {Magnifier=false})))==null,"Ship to's magnifier (or another button) taken for X's.");
                var two=RoControls(new Ro {SecondMagnifier=true});Check(Selectors.AccountLookup(two,Selectors.Header(two))==null,"Two buttons in the Account# box: one pressed anyway.");
                var stray=RoControls(new Ro {Magnifier=false,StrayButton=true});Check(Selectors.AccountLookup(stray,Selectors.Header(stray))==null,"A button over the Account# box that isn't inside it taken for the magnifier.");
            });
            Case("New accounts (2.9.11): COSTAR's customer search known by its words, Add new, Cancel and OK (only then is Add new pressed)",()=>{
                var w=NewAccountSearch.Read("Search ...",Search());
                Check(w!=null&&w.AddNew.Handle==20&&w.Cancel.Handle==4&&w.Ok.Handle==5,"COSTAR's customer search not read.");
                Check(NewAccountSearch.Read("Search ...",Search(false))==null,"A search without Add new read as COSTAR's.");
                Check(NewAccountSearch.Read("Search ...",Search(true,true))==null,"A search with two Cancels read as COSTAR's.");
                Check(NewAccountSearch.Read("Notes",Search())==null,"Another window's title read as the customer search.");
                Check(NewAccountSearch.Read("Search ...",Search().Where(c=>c.Handle!=1).ToList())==null,"A search without its words read as COSTAR's.");
            });
            Case("New accounts (2.9.11): COSTAR's new-customer form read box by box from its labels (State/Province from the panel inside its drop-down), and never taken for a list of accounts",()=>{
                var f=NewAccountForm.Read("Add new cash customer",FormControls(new Form()));
                Check(f!=null,"The new-customer form not read.");
                Check(f.Last.Handle==11&&f.First.Handle==15&&f.Address.Handle==21&&f.City.Handle==24&&f.Postcode.Handle==32&&f.Home.Handle==44&&f.Mobile.Handle==46&&f.Business.Handle==48&&f.Fax.Handle==50,"A box taken from the wrong label.");
                Check(f.State.Handle==27&&f.Ok.Handle==70&&f.Cancel.Handle==71&&f.PersonalFile.Handle==3&&f.CashFile.Handle==2,"The state, OK, Cancel or the two choices wrong.");
                Check(NewAccountForm.Read("Add new cash customer",FormControls(new Form {InnerState=false})).State.Handle==26,"A drop-down without a panel inside not read from itself.");
                Check(NewAccountForm.Read("Add new cash customer",FormControls(new Form {NoCity=true}))==null&&NewAccountForm.CancelOnly(FormControls(new Form {NoCity=true})).Handle==71,"A form laid out differently read (its Cancel alone must be found).");
                Check(NewAccountForm.Read("Add new cash customer",FormControls(new Form {TwoOk=true}))==null,"A form with two OKs read.");
                Check(NewAccountForm.Read("Add new customer",FormControls(new Form()))==null&&NewAccountForm.IsTitle(" Add new cash  customer "),"The form known by another title, or its own refused.");
                var chooser=Selectors.AccountChooser("WindowsForms10.Window.8.app.0.13965fa_r10_ad1",FormControls(new Form()).Concat(new[]{Mk(90,0,WF,13,183,532,572,null)}).ToList());
                Check(!chooser.IsChooser&&chooser.Reason=="new-customer form","The new-customer form taken for a list of accounts (its OK would make a customer).");
                Check(Selectors.AccountChooser("WindowsForms10.Window.8.app.0.13965fa_r10_ad1",Search().Concat(new[]{Mk(91,0,WF,16,288,992,396,null)}).ToList()).IsChooser,"COSTAR's customer search no longer a list of accounts for the phone lookup.");
            });
            Case("New accounts (2.9.11): OK only when every required box of the form holds the order's details (as COSTAR filled them from X) and a personal service file is chosen",()=>{
                Check(NewAccount.FormProblems(Values(),X(),Buyer()).Count==0,"A complete form refused.");
                Func<Action<NewAccountValues>,string> wrong=delegate(Action<NewAccountValues> change) { var v=Values();change(v);return String.Join(", ",NewAccount.FormProblems(v,X(),Buyer()).ToArray()); };
                Check(wrong(v=>v.Postcode="")=="postcode empty"&&wrong(v=>v.Postcode="2800")=="postcode","An empty or other postcode (17 Nov: X's empty postcode left it empty) accepted.");
                Check(wrong(v=>{v.First="";})=="first or last name empty"&&wrong(v=>{v.First="JAMIE";v.Last="";})=="first or last name empty","An empty first or last name accepted.");
                Check(wrong(v=>{v.First="JAMIE";v.Last="TESTFIELD TESTFIELD";})=="first and last name don't hold the name's words","A split adding a word accepted.");
                Check(wrong(v=>{v.First="TESTFIELD";v.Last="JAMIE";})=="","COSTAR's split the other way round refused.");
                Check(wrong(v=>v.City="")=="city empty"&&wrong(v=>v.City="OTHERVILLE")=="city"&&wrong(v=>v.Address="")=="address empty","An empty or other city or address accepted.");
                Check(wrong(v=>v.State=null)=="state/province unreadable"&&wrong(v=>v.State="VIC")=="state/province"&&wrong(v=>v.State="")=="state/province empty","An unreadable, other or empty state accepted.");
                Check(wrong(v=>{v.Mobile="";v.Home="0400 000 001";})=="","The order's phone in another phone box refused.");
                Check(wrong(v=>v.Mobile="")=="phone numbers empty"&&wrong(v=>v.Mobile="0400000002")=="phone number","No phone, or another phone, accepted.");
                Check(wrong(v=>v.PersonalFile=false)=="a personal service file not chosen"&&wrong(v=>v.PersonalFile=null)=="the personal service file choice unreadable","COSTAR's CASH account choice (or an unreadable choice) accepted.");
                var a=Values();var b=Values();Check(a.Print()==b.Print(),"The same form read twice differs.");b.Postcode="2800";Check(a.Print()!=b.Print(),"A changed box not seen before OK.");
                b=Values();b.PersonalFile=false;Check(a.Print()!=b.Print(),"A changed choice not seen before OK.");
            });
            Case("New accounts (2.9.11): after OK the account is made only with the form gone, nothing over the order, the order in front and free, an account number read twice, the same name's words and the same phone",()=>{
                Check(NewAccount.Uncertain(Made())==null,"A made account (17 Nov 14:42) not confirmed.");
                Func<Action<AfterOkLook>,string> look=delegate(Action<AfterOkLook> change) { var o=Made();change(o);return NewAccount.Uncertain(o); };
                Check(look(o=>o.Name="TESTFIELD, JAMIE")==null,"COSTAR's own order for the name refused.");
                Check(look(o=>o.FormUp=true)=="COSTAR's new-customer form is still open","The form still open taken as made.");
                Check(look(o=>o.OtherWindow=true)=="another COSTAR window is open over the order","A message over the order taken as made.");
                Check(look(o=>o.OrderFront=false)!=null&&look(o=>o.OrderEnabled=false)!=null,"The order not back in front (or not free) taken as made.");
                Check(look(o=>{o.Account="";o.AccountAgain="";})=="Account# is still blank","No account number taken as made.");
                Check(look(o=>o.AccountAgain="T123457")=="Account# keeps changing","An account number still changing taken as made.");
                Check(look(o=>o.AccountBefore="C100")=="Account# wasn't blank before","An account number already there taken as new.");
                Check(look(o=>o.Name="ROBIN TESTFIELD")=="the customer name changed"&&look(o=>o.Phone="0400000002")=="the customer phone changed","Another customer after OK taken as made.");
            });
            Case("New accounts (2.9.11): the record of OK pressed: each order by part of a SHA-256 (never its number), its newest state, kept a year, the newest 5000",()=>{
                string k=NewAccountLog.Key("TTW0000001");
                Check(k.Length==32&&k==NewAccountLog.Key(" ttw0000001 ")&&k!=NewAccountLog.Key("TTW0000002")&&!k.Contains("0000001"),"The key isn't the order's own, steady, or holds its number.");
                var now=new DateTime(2026,11,17,4,0,0,DateTimeKind.Utc);
                var m=NewAccountLog.Mark(null,k,"pressed",now);
                Check(NewAccountLog.Find(m,k,now).state=="pressed"&&NewAccountLog.Find(m,NewAccountLog.Key("TTW0000002"),now)==null,"A pressed order not found (or another order found).");
                m=NewAccountLog.Mark(m,k,"made",now.AddMinutes(1));
                Check(m.marks.Count==1&&NewAccountLog.Find(m,k,now).state=="made","The newest state not kept once.");
                Check(NewAccountLog.Find(m,k,now.AddDays(364))!=null&&NewAccountLog.Find(m,k,now.AddDays(400))==null,"Not kept a year, or kept for ever.");
                var old=new AccountMarks {marks=new List<AccountMark>{new AccountMark {key="A",state="made",atUtc=now.AddDays(-500).ToString("o",CultureInfo.InvariantCulture)},new AccountMark {key="B",state="pressed",atUtc="not a time"}}};
                var pruned=NewAccountLog.Mark(old,k,"pressed",now);
                Check(pruned.marks.Count==2&&NewAccountLog.Find(pruned,"A",now)==null&&NewAccountLog.Find(pruned,"B",now)!=null,"An old mark kept, or one with an unreadable time dropped (it must stay: never again).");
                var many=new AccountMarks();for(int i=0;i<NewAccountLog.Most+10;i++) many.marks.Add(new AccountMark {key="K"+i,state="made",atUtc=now.ToString("o",CultureInfo.InvariantCulture)});
                var cut=NewAccountLog.Mark(many,k,"pressed",now);Check(cut.marks.Count==NewAccountLog.Most&&NewAccountLog.Find(cut,k,now)!=null&&NewAccountLog.Find(cut,"K0",now)==null,"More than the newest marks kept, or the new one dropped.");
                var back=Wire.Read<AccountMarks>(Wire.Json(m));Check(back.marks.Count==1&&back.marks[0].state=="made"&&back.marks[0].key==k,"The record doesn't survive its file.");
            });
            Case("New accounts (2.9.11): after an OK that wasn't confirmed (or the helper went before it could look), COSTAR's windows over that order are left for a person at every later attempt; an account made, OK not sent, or no mark: as before",()=>{
                string k=NewAccountLog.Key("TTW0000001");var now=new DateTime(2026,11,17,4,0,0,DateTimeKind.Utc);
                Check(NewAccountLog.StateOf(null,k,now)==null&&!NewAccount.LeftUnsure(NewAccountLog.StateOf(null,k,now)),"No mark isn't as before.");
                foreach(var state in new[]{"pressed","unsure"}) {
                    var m=NewAccountLog.Mark(null,k,state,now);
                    Check(NewAccountLog.StateOf(m,k,now)==state&&NewAccount.LeftUnsure(NewAccountLog.StateOf(m,k,now)),"\""+state+"\" doesn't leave COSTAR's windows for a person.");
                    Check(!NewAccount.LeftUnsure(NewAccountLog.StateOf(m,NewAccountLog.Key("TTW0000002"),now)),"Another order's mark counted.");
                    Check(!NewAccount.LeftUnsure(NewAccountLog.StateOf(m,k,now.AddDays(400))),"A mark older than a year counted.");
                }
                foreach(var state in new[]{"made","not sent"}) Check(!NewAccount.LeftUnsure(NewAccountLog.StateOf(NewAccountLog.Mark(null,k,state,now),k,now)),"\""+state+"\" left COSTAR's windows for a person.");
                var blank=new AccountMarks {marks=new List<AccountMark>{new AccountMark {key=k,state=null,atUtc=now.ToString("o",CultureInfo.InvariantCulture)}}};
                Check(NewAccountLog.StateOf(blank,k,now)=="?"&&!NewAccount.LeftUnsure("?")&&!NewAccount.LeftUnsure(""),"A mark without a state isn't \"?\" (as before).");
            });
            Case("New accounts (2.9.11): a retry of the Repair Order after an unconfirmed OK compares without Account#, the name's word order and Ship to (the account COSTAR put on it is kept); every other stop as before",()=>{
                var before=RoControls(new Ro());
                var after=RoControls(new Ro {Account="T123456",Name="TESTFIELD, JAMIE",YName="JAMIE TESTFIELD",YAddress="1 TEST CRESCENT",YSuburb="TESTVILLE",YState="NSW",YPostcode="2799",YMobile="0400000001",YEmail="test.buyer@example.com"});
                string strictBefore=Selectors.OrderPrint(before,true),looseBefore=Selectors.OrderPrint(before,true,true);
                Check(strictBefore!=Selectors.OrderPrint(after,true),"The full print missed the account COSTAR put on the order.");
                Check(looseBefore==Selectors.OrderPrint(after,true,true),"The loose print saw what COSTAR changes as it makes an account.");
                Check(strictBefore=="|JAMIE TESTFIELD|1 TEST CRESCENT||TESTVILLE|NSW|2799|0400000001|TEST.BUYER@EXAMPLE.COM|TTW0000001||-"+new string('|',14)+"W43116x1@140.00;","The full print (every stop but an unconfirmed OK's) isn't what 2.9.10 kept: "+strictBefore);
                Check(Selectors.OrderPrint(before,false)=="|JAMIE TESTFIELD|1 TEST CRESCENT||TESTVILLE|NSW|2799|0400000001|TEST.BUYER@EXAMPLE.COM|TTW0000001||-||W43116x1@140.00;","A pickup's full print isn't what 2.9.10 kept: "+Selectors.OrderPrint(before,false));
                Check(looseBefore!=Selectors.OrderPrint(RoControls(new Ro {Name="ROBIN TESTFIELD"}),true,true)&&looseBefore!=Selectors.OrderPrint(RoControls(new Ro {Po="TTW0000002"}),true,true)&&looseBefore!=Selectors.OrderPrint(RoControls(new Ro {Postcode="2800"}),true,true),
                    "The loose print missed another name, PO# or postcode.");
                string stopped=NewAccount.LoosePrint+looseBefore;
                Check(NewAccount.SamePrint(stopped,null,Selectors.OrderPrint(after,true,true))&&!NewAccount.SamePrint(stopped,strictBefore,null),"A loose stop not compared loosely.");
                Check(NewAccount.SamePrint(strictBefore,strictBefore,null)&&!NewAccount.SamePrint(strictBefore,Selectors.OrderPrint(after,true),null)&&!NewAccount.SamePrint(strictBefore,null,looseBefore)&&!NewAccount.SamePrint(null,strictBefore,looseBefore),
                    "Every other stop no longer compared in full (or a missing print accepted).");
            });
            Case("New accounts (2.9.11): on by default, for an earlier installation's settings too; switched off it stays off",()=>{
                Check(new AppSettings().newAccounts,"New settings make no accounts.");
                Check(Wire.Read<AppSettings>("{\"directPresses\":true,\"ebayClose\":true}").newAccounts,"An earlier installation's settings make no accounts.");
                var off=new AppSettings();off.newAccounts=false;Check(!Wire.Read<AppSettings>(Wire.Json(off)).newAccounts,"Switched off, not kept.");
            });
            // 2.9.12: the account's state. Real place names and postcodes (public; the customers stay made-up).
            Case("New accounts (2.9.12): the state written in the address first, by code or full name, any case, extra spaces or dots; never replaced by the address list",()=>{
                foreach(var w in new[]{"NSW","nsw"," N.S.W. ","N S W","New South Wales","new  south   wales","NEW SOUTH WALES"}) Check(AuState.Code(w)=="NSW","Not NSW: \""+w+"\".");
                var named=new Dictionary<string,string>{{"Victoria","VIC"},{"vic","VIC"},{"Qld","QLD"},{"QUEENSLAND","QLD"},{"south australia","SA"},{"s.a.","SA"},{"Western Australia","WA"},{"W.A.","WA"},
                    {"Tasmania","TAS"},{"tas","TAS"},{"NT","NT"},{"Northern  Territory","NT"},{"act","ACT"},{"Australian Capital Territory","ACT"}};
                foreach(var n in named) Check(AuState.Code(n.Key)==n.Value,"\""+n.Key+"\" isn't "+n.Value+".");
                foreach(var w in new[]{"","XX","JBT","OT","AUSTRALIA","SYDNEY","NEW SOUTH","NSW 2044","VICTORIA PARK",null}) Check(AuState.Code(w)=="","Taken for a state: \""+w+"\".");
                var full=AuPlaces.Resolve("New South Wales","Tempe","2044");
                Check(full.State=="NSW"&&full.Source=="address"&&full.Why==null,"A full name written in the address isn't NSW from the address.");
                var kept=AuPlaces.Resolve("vic","Tempe","2044");
                Check(kept.State=="VIC"&&kept.Source=="address"&&kept.Why!=null&&kept.Why.Contains("kept"),"A written state replaced by the list (or the difference not noted).");
                var odd=AuPlaces.Resolve("XX","Tempe","2044");
                Check(odd.State==null&&odd.Why.Contains("isn't one of the eight"),"A written state that isn't one taken, or looked up over.");
                Check(AuPlaces.Resolve("NSW","Testville","2799").Why==null,"A place the list doesn't have noted against a written state.");
            });
            Case("New accounts (2.9.12): a missing state looked up by suburb AND postcode, used only when that suburb under that postcode is in one state",()=>{
                foreach(var s in new[]{"Tempe","  tempe ","TEMPE","St Peters","Saint Peters","ST. PETERS","Sydenham"}) {
                    var f=AuPlaces.Resolve("",s,"2044");
                    Check(f.State=="NSW"&&f.Source=="lookup"&&f.Why==null,"Not looked up as NSW: \""+s+"\".");
                }
                Check(AuPlaces.Resolve(null," O'Connor","2602").State=="ACT"&&AuPlaces.Resolve(null,"Mt Victoria","2786").State=="NSW"&&AuPlaces.Resolve(null,"Mount Victoria","2786").State=="NSW"
                    &&AuPlaces.Resolve(null,"North Sydney","2060").State=="NSW"&&AuPlaces.Resolve(null,"Nth Sydney","2060").State=="NSW"&&AuPlaces.Resolve(null,"Wagga-Wagga","2650").State=="NSW",
                    "A place written another way (apostrophe, Mt, Nth, a hyphen) not found.");
                // Postcodes shared by two states: the suburb decides.
                var shared=new[]{new[]{"Queanbeyan","2620","NSW"},new[]{"Hume","2620","ACT"},new[]{"Cobram","3644","VIC"},new[]{"Barooga","3644","NSW"},
                    new[]{"Yulara","0872","NT"},new[]{"Pukatja","0872","SA"},new[]{"Hall","2618","ACT"},new[]{"Wallaroo","2618","NSW"}};
                foreach(var s in shared) { var f=AuPlaces.Resolve("",s[0],s[1]);Check(f.State==s[2]&&f.Source=="lookup",s[0]+" "+s[1]+" isn't "+s[2]+" (got "+(f.State??"none: "+f.Why)+")."); }
                // In two states under one postcode: none.
                var two=AuPlaces.Resolve("","Texas","4385");
                Check(two.State==null&&two.Source==""&&two.Why.Contains("more than one state"),"A suburb and postcode in two states given one.");
                // Not found, or nothing to look up by: none, with why. Never from the postcode alone (2044 is all NSW).
                var why=new Dictionary<string,string[]>{{"the suburb isn't in the address list under that postcode",new[]{"Tempe","3044"}},{"the postcode isn't in the address list",new[]{"Tempe","0001"}},
                    {"no suburb to look it up by",new[]{"  ","2044"}},{"no postcode to look it up by",new[]{"Tempe",""}},{"the postcode isn't 4 digits",new[]{"Tempe","204"}}};
                foreach(var w in why) { var f=AuPlaces.Resolve("",w.Value[0],w.Value[1]);Check(f.State==null&&f.Why==w.Key,"\""+w.Value[0]+"\" \""+w.Value[1]+"\": "+(f.State??f.Why)); }
                foreach(var s in new[]{"Nowhere","Tempe NSW","Tempe 2044","Tempee"}) Check(AuPlaces.Resolve("",s,"2044").State==null,"Guessed for \""+s+"\" from the postcode.");
                // The account step's details with the state it found (everything else as the order has it).
                var c=Buyer();c.state="";c.suburb="Tempe";c.postcode="2044";
                var with=NewAccount.WithState(c,AuPlaces.Resolve(c.state,c.suburb,c.postcode).State);
                Check(NewAccount.Missing(with).Count==0&&with.state=="NSW"&&c.state==""&&with.name==c.name&&with.streetAddress==c.streetAddress&&with.address2==c.address2&&with.suburb==c.suburb
                    &&with.postcode==c.postcode&&with.phone==c.phone&&with.email==c.email,"The looked-up state not the only change (or the order's own changed).");
                c.suburb="Tempee";Check(NewAccount.Missing(NewAccount.WithState(c,AuPlaces.Resolve(c.state,c.suburb,c.postcode).State)).SequenceEqual(new[]{"state"}),"No state found, yet not missing.");
                Check(NewAccount.WithState(null,"NSW")==null,"No customer, yet a copy.");
            });
            Case("New accounts (2.9.12): the address list: every line read, the eight states only, each place as AuState.Place writes it, the postcodes shared by two states",()=>{
                var t=AuPlaces.Table;int places=0;   // each place with each of its states, as the list's lines count them
                foreach(var pc in t) {
                    Check(pc.Key.Length==4&&pc.Key.All(Char.IsDigit),"A postcode that isn't 4 digits: "+pc.Key);
                    foreach(var p in pc.Value) {
                        places+=p.Value.Count;
                        Check(p.Key.Length>0&&AuState.Place(p.Key)==p.Key,"A place not as AuState.Place writes it: "+p.Key);
                        Check(p.Value.Count>0&&p.Value.All(s=>AuState.Codes.Contains(s)),"Not one of the eight states: "+p.Key+" "+pc.Key);
                    }
                }
                Check(places==AuPlaceData.Places&&places>18000&&t.Count>3000,"The list read short: "+places+" places, "+t.Count+" postcodes.");
                Func<string,string> states=pc=>String.Join(",",t[pc].Values.SelectMany(v=>v).Distinct().OrderBy(s=>s).ToArray());
                Check(states("2620")=="ACT,NSW"&&states("3644")=="NSW,VIC"&&states("2618")=="ACT,NSW"&&states("0872").Contains("NT")&&states("0872").Contains("SA")&&states("2044")=="NSW",
                    "The shared postcodes aren't as Australia Post has them.");
                Check(AuState.Place("O\u2019Connor")=="OCONNOR"&&AuState.Place("Wagga-Wagga")=="WAGGA WAGGA"&&AuState.Place("Mount  Victoria")=="MT VICTORIA"&&AuState.Place("Saint Kilda East")=="ST KILDA EAST"
                    &&AuState.Place("South Yarra")=="STH YARRA"&&AuState.Place("Kangaroo Point & Bay")=="KANGAROO POINT AND BAY"&&AuState.Place(null)==""&&AuState.Place("  ,. ")=="","A place's name read another way than the list writes it.");
            });
            // 2.9.13: a missing state found when the order is received, before the checks that need one (deliveries, eBay).
            Case("Received states (2.9.13): a delivery's billing and delivery states, each by its own suburb and postcode, before the check that needs them; written ones kept",()=>{
                var o=Delivery();o.Validate(true);
                Check(o.customer.state=="NSW"&&o.customer.StateFrom=="lookup"&&o.shipping.state=="VIC"&&o.shipping.StateFrom=="lookup","Not each looked up by its own suburb and postcode: "+o.customer.state+"/"+o.shipping.state);
                o.Validate(true);
                Check(o.customer.state=="NSW"&&o.customer.StateFrom=="lookup"&&o.shipping.state=="VIC"&&o.shipping.StateFrom=="lookup","Checked again, no longer looked up.");
                o=Delivery();o.customer.suburb="Fitzroy";o.customer.postcode="3065";o.shipping.suburb="Tempe";o.shipping.postcode="2044";o.Validate(true);
                Check(o.customer.state=="VIC"&&o.shipping.state=="NSW","The billing state taken from the delivery address, or the other way round.");
                o=Delivery();o.customer.state=" nsw ";o.shipping.state="Victoria";o.Validate(true);
                Check(o.customer.state=="NSW"&&o.customer.StateFrom=="address"&&o.shipping.state=="VIC"&&o.shipping.StateFrom=="address","A written state (any case, or a full name) not taken as its code.");
                o=Delivery();o.customer.state="QLD";o.shipping.state="WA";o.Validate(true);
                Check(o.customer.state=="QLD"&&o.customer.StateFrom=="address"&&o.shipping.state=="WA"&&o.shipping.StateFrom=="address","A written state replaced by the address list.");
                o=Delivery();o.shipping.state="SA";o.Validate(true);
                Check(o.customer.state=="NSW"&&o.customer.StateFrom=="lookup"&&o.shipping.state=="SA"&&o.shipping.StateFrom=="address","One written and one missing: not each as it is.");
            });
            Case("Received states (2.9.13): a delivery whose missing state can't be found is refused as before, saying which address and why; a written one that isn't a state as before",()=>{
                var amb=Delivery();amb.shipping.suburb="Texas";amb.shipping.postcode="4385";
                string m=Refusal(()=>amb.Validate(true));
                Check(m==Order.InvalidState+" The delivery address has no state, and it couldn't be looked up: that suburb and postcode are in more than one state.","Two states: "+m);
                Check(amb.shipping.state==""&&amb.shipping.StateFrom==null,"A state put in for a suburb and postcode in two states.");
                var none=Delivery();none.customer.postcode="3044";
                m=Refusal(()=>none.Validate(true));
                Check(m==Order.InvalidState+" The billing address has no state, and it couldn't be looked up: the suburb isn't in the address list under that postcode.","Not found: "+m);
                var typo=Delivery();typo.customer.suburb="Tempee";
                Check((Refusal(()=>typo.Validate(true))??"").EndsWith("the suburb isn't in the address list under that postcode.",StringComparison.Ordinal)&&typo.customer.state=="","Guessed from the postcode alone (2044 is all NSW).");
                var shortPostcode=Delivery();shortPostcode.shipping.postcode="306";
                Check(Refusal(()=>shortPostcode.Validate(true))==Order.InvalidState+" The delivery address has no state, and it couldn't be looked up: the postcode isn't 4 digits.","A short postcode: not said.");
                var odd=Delivery();odd.shipping.state="JBT";
                Check(Refusal(()=>odd.Validate(true))==Order.InvalidState&&odd.shipping.state=="JBT","A written state that isn't one: not refused as before (or replaced).");
                var neither=Delivery();neither.customer.suburb="Texas";neither.customer.postcode="4385";neither.shipping.postcode="3044";
                Check((Refusal(()=>neither.Validate(true))??"").Contains("The billing address has no state"),"Neither found: the first not said.");
            });
            Case("Received states (2.9.13): a pickup's state isn't looked at when it is received; the account step finds it, and says where each state came from",()=>{
                var p=new Order {schema=1,createdUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture),orderId="TTW101",pickupDate="2026-11-18",pickupTime="10:30",comment="WEDNESDAY - ONLINE 10:30",
                    customer=new Customer {name="TEST CUSTOMER",phone="0400000000",streetAddress="1 TEST ROAD",suburb="Tempe",state="",postcode="2044"},totalCents=14000,
                    lines=new List<OrderLine> {new OrderLine {kind="product",sourceSku="W43116",code="W43116",description="TEST TYRE",quantity=1,unitCents=14000,totalCents=14000}}};
                p.Validate(true);
                Check(p.customer.state==""&&p.customer.StateFrom==null,"A pickup's state looked up when it was received.");
                var a=NewAccount.AccountState(p.customer);
                Check(a.State=="NSW"&&a.Source=="lookup","A pickup's missing state not looked up by the account step.");
                p.customer.state="NSW";Check(NewAccount.AccountState(p.customer).Source=="address","A pickup's written state not from the address.");
                var d=Delivery();d.Validate(true);
                a=NewAccount.AccountState(d.customer);
                Check(a.State=="NSW"&&a.Source=="lookup","Looked up when the delivery was received, yet the account step says "+a.Source+".");
                d=Delivery();d.customer.state="NSW";d.Validate(true);
                Check(NewAccount.AccountState(d.customer).Source=="address"&&NewAccount.AccountState(null).State==null,"A written one not from the address (or no customer given a state).");
                Check(NewAccount.StateFromWords("lookup").StartsWith("looked up from its suburb and postcode",StringComparison.Ordinal)&&NewAccount.StateFromWords("address")=="written in the address"&&NewAccount.StateFromWords("")=="not looked at"
                    &&Order.LookedUp("lookup").Contains("state looked up")&&Order.LookedUp("address")==""&&Order.LookedUp(null)=="","Where a state came from, in words.");
            });
            Case("Received states (2.9.13): the Tempe Orders page's copy read as the Online orders tab reads it; where a state came from is never sent, saved or taken from the sender",()=>{
                var sent=Delivery();sent.customer.state="QLD";
                string json=Wire.Json(sent);
                Check(json.IndexOf("StateFrom",StringComparison.OrdinalIgnoreCase)<0&&json.Contains("\"state\":\"\""),"Where a state came from is sent or saved: "+json);
                var read=PageOrder.Read(PageOrder.Prefix+json.Replace("\"state\":\"QLD\"","\"state\":\"QLD\",\"stateFrom\":\"lookup\"").Replace("\"state\":\"\"","\"state\":\"\",\"stateFrom\":\"address\""));
                Check(read.customer.state=="QLD"&&read.customer.StateFrom=="address"&&read.shipping.state=="VIC"&&read.shipping.StateFrom=="lookup","Taken from the sender, or not found: "+read.customer.StateFrom+"/"+read.shipping.StateFrom);
                var amb=Delivery();amb.shipping.suburb="Texas";amb.shipping.postcode="4385";
                Check((Refusal(()=>PageOrder.Read(PageOrder.Prefix+Wire.Json(amb)))??"").Contains("The delivery address has no state"),"The tab takes a delivery whose state can't be found.");
            });
            Case("Received states (2.9.13): an eBay order's missing state looked up by its suburb and postcode for every check and the entry; the order and its content hash stay as sent",()=>{
                var e=EbayTests.Sample("12-11111-11111");e.address.state="";e.address.suburb="Tempe";e.address.postcode="2044";
                string hash=e.ContentHash(),json=Wire.Json(e);
                e.Validate();
                Check(e.address.state==""&&e.ContentHash()==hash&&Wire.Json(e)==json,"The order changed by its check.");
                var claimed=Wire.Read<EbayOrder>(json);claimed.Validate();var entry=claimed.EngineOrder();   // the worker, as the receiver hands it over
                Check(entry.customer.state=="NSW"&&entry.shipping.state=="NSW"&&entry.customer.StateFrom=="lookup"&&entry.shipping.StateFrom=="lookup","Not looked up for the entry.");
                Check(NewAccount.AccountState(entry.customer).Source=="lookup","The account step doesn't say it was looked up.");
                var named=EbayTests.Sample();named.address.state="New South Wales";named.Validate();
                Check(named.EngineOrder().customer.state=="NSW"&&named.EngineOrder().customer.StateFrom=="address","A full name not taken as its code.");
                var kept=EbayTests.Sample();kept.address.suburb="Fitzroy";kept.address.postcode="3065";kept.Validate();
                Check(kept.EngineOrder().shipping.state=="NSW"&&kept.EngineOrder().shipping.StateFrom=="address","A written state replaced by the address list.");
                var amb=EbayTests.Sample();amb.address.state="";amb.address.suburb="Texas";amb.address.postcode="4385";
                Check(Refusal(()=>amb.Validate())=="The address has no state, and it couldn't be looked up from its suburb and postcode: that suburb and postcode are in more than one state. Enter this order by hand.","Two states: not refused, or not said.");
                var none=EbayTests.Sample();none.address.state="";
                Check((Refusal(()=>none.Validate())??"").Contains("couldn't be looked up from its suburb and postcode: the suburb isn't in the address list under that postcode."),"Not found: not refused, or not said.");
                var odd=EbayTests.Sample();odd.address.state="JBT";
                Check(Refusal(()=>odd.Validate())=="The state must be NSW, VIC, QLD, SA, WA, TAS, NT or ACT.","A written state that isn't one: not refused as before.");
                var bad=EbayTests.Sample();bad.address.state="\u0001";
                Check((Refusal(()=>bad.Validate())??"").Contains("control characters"),"Control characters in the state taken.");
            });
            Case("Received states (2.9.13): the receiver queues an eBay order with no state as sent (its state looked up), a second send is the same order, one whose state can't be found is refused",()=>{
                var q=new EbayQueue(null,s=>{});
                var e=EbayTests.Sample("13-11111-11111");e.address.state="";e.address.suburb="Tempe";e.address.postcode="2044";
                Check(q.Submit(e).status=="queued","Not queued.");
                var r=q.List()[0];
                Check(r.order.address.state==""&&r.hash==e.ContentHash(),"Not kept as sent.");
                var again=Wire.Copy(e);again.createdUtc=DateTime.UtcNow.AddSeconds(5).ToString("o",CultureInfo.InvariantCulture);
                Check(q.Submit(again).status=="queued"&&q.List().Count==1&&q.List()[0].hash==r.hash,"A second send made a second order.");
                var amb=EbayTests.Sample("14-11111-11111");amb.address.state="";amb.address.suburb="Texas";amb.address.postcode="4385";
                Check(Refusal(()=>q.Submit(amb))!=null&&q.List().Count==1,"One whose state can't be found queued.");
            });
            // 2.9.14: COSTAR's windows looked at once they are drawn (Tommy's diagnostics of 18 Nov 08:36).
            Case("New accounts (2.9.14): COSTAR's customer search looked at again while COSTAR is still drawing it (18 Nov 08:15: part-drawn at the first look, complete at the next)",()=>{
                int looks;string why;long ms;
                Func<List<ControlInfo>,NewAccountSearch> search=s=>NewAccountSearch.Read("Search ...",s);
                Check(search(SearchDrawing())==null,"The part-drawn search already read as COSTAR's (the test shows nothing).");
                var w=Watch(new List<List<ControlInfo>>{SearchDrawing(),Search()},search,out looks,out why,out ms);
                Check(w!=null&&w.AddNew.Handle==20&&looks==2&&why==null,"Not known once drawn (looks "+looks+", "+why+").");
                w=Watch(new List<List<ControlInfo>>{SearchDrawing(),SearchDrawing(),SearchDrawing(),Search()},search,out looks,out why,out ms);
                Check(w!=null&&looks==4,"Not known after a pause in the drawing shorter than "+WindowLooks.SettledMs+" ms.");
                Check(Watch(new List<List<ControlInfo>>{Search()},search,out looks,out why,out ms)!=null&&looks==1,"A search drawn at once not known at the first look.");
                // Never pressed on a window that isn't the search: one that stops changing, one that never settles, one that closes.
                var notes=new List<ControlInfo>{Mk(1,0,ST,13,72,991,19,"Notes"),Mk(2,0,BT,238,93,128,21,"&Close")};
                Check(Watch(new List<List<ControlInfo>>{notes},s=>NewAccountSearch.Read("Notes",s),out looks,out why,out ms)==null&&why=="it stayed the same for "+WindowLooks.SettledMs+" ms"&&ms<=200+WindowLooks.SettledMs+WindowLooks.PauseMs,
                    "A window that isn't the search: not given up once it stopped changing ("+why+", "+ms+" ms).");
                var changing=new List<List<ControlInfo>>();
                for(int n=0;n<100;n++) changing.Add(SearchDrawing().Concat(Enumerable.Range(0,n+1).Select(k=>Mk(200+k,0,ST,0,0,10,10,"x"))).ToList());   // a control more at each look
                Check(Watch(changing,search,out looks,out why,out ms)==null&&why=="not within 10000 ms","One still changing at the step's limit not given up ("+why+").");
                Check(Watch(new List<List<ControlInfo>>{SearchDrawing(),null},search,out looks,out why,out ms)==null&&why=="it closed or couldn't be read"&&looks==1,"A window that closed not given up ("+why+").");
                // What tells a window still being drawn from a settled one.
                var a=Search();var b=Search();
                Check(WindowLooks.Print(a)==WindowLooks.Print(b)&&WindowLooks.Print(SearchDrawing())!=WindowLooks.Print(a),"The same window read as changing, or a part-drawn one as the same.");
                b[1].Visible=false;Check(WindowLooks.Print(a)!=WindowLooks.Print(b),"A control shown or hidden not seen.");
                b=Search();b[2].Enabled=false;Check(WindowLooks.Print(a)!=WindowLooks.Print(b),"A control greyed not seen.");
                b=Search();b[2].Text="&Find";Check(WindowLooks.Print(a)!=WindowLooks.Print(b),"A caption changed not seen.");
                b=Search();b[2].Handle=99;Check(WindowLooks.Print(a)!=WindowLooks.Print(b),"A control put in another's place not seen.");
            });
            Case("New accounts (2.9.14): COSTAR's new-customer form looked at again until drawn; one that stays laid out differently is still only cancelled",()=>{
                int looks;string why;long ms;
                Func<List<ControlInfo>,NewAccountForm> form=s=>NewAccountForm.Read("Add new cash customer",s);
                var drawing=FormControls(new Form()).Where(c=>c.Handle<40).ToList();   // its top half: no phones, no OK or Cancel yet
                Check(form(drawing)==null&&NewAccountForm.CancelOnly(drawing)==null,"The part-drawn form already read (the test shows nothing).");
                var f=Watch(new List<List<ControlInfo>>{drawing,FormControls(new Form())},form,out looks,out why,out ms);
                Check(f!=null&&f.Ok.Handle==70&&f.Cancel.Handle==71&&looks==2,"The form not known once drawn.");
                var other=FormControls(new Form {NoCity=true});
                Check(Watch(new List<List<ControlInfo>>{drawing,other},form,out looks,out why,out ms)==null&&why.StartsWith("it stayed the same",StringComparison.Ordinal)&&NewAccountForm.CancelOnly(other).Handle==71,
                    "A form laid out differently, once drawn, not left to its Cancel alone ("+why+").");
            });
        }
        // 2.9.14: a window looked at as COSTAR draws it (WindowLooks.WhenComplete): seen[i] is what look i shows (then the last one
        // again; a null: the window closed), each look 150 ms after the one before on a made-up clock that starts 200 ms after
        // the window opened.
        static T Watch<T>(List<List<ControlInfo>> seen,Func<List<ControlInfo>,T> read,out int looks,out string why,out long ms) where T:class {
            int i=0;long t=200;List<ControlInfo> last;
            var found=WindowLooks.WhenComplete<T>(()=>seen[Math.Min(i++,seen.Count-1)],read,()=>t,()=>{t+=WindowLooks.PauseMs;},10000,out last,out looks,out why);
            ms=t;return found;
        }
        // COSTAR's customer search part-drawn, as the 18 Nov 08:15 run saw it 0.27 s after the magnifier: its words and some
        // boxes, a Close button, no Add new, Cancel or OK yet.
        static List<ControlInfo> SearchDrawing() {
            return Search(false).Where(c=>c.Handle!=4&&c.Handle!=5&&c.Handle!=1).Concat(new[]{Mk(30,0,BT,912,45,97,25,"Close")}).ToList();
        }
        static string Refusal(Action action) { try { action(); } catch(InvalidOperationException e) { return e.Message; } return null; }
        // A made-up delivery with no state on either address: billing in Tempe 2044 (NSW), delivery in Fitzroy 3065 (VIC).
        static Order Delivery() {
            return new Order {schema=2,type="delivery",createdUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture),orderId="TTW100",deliveryMethod="WITHIN AUSTRALIA",
                customer=new Customer {name="TEST CUSTOMER",phone="0400000000",streetAddress="1 TEST ROAD",suburb="Tempe",state="",postcode="2044"},
                shipping=new Shipping {name="TEST RECIPIENT",streetAddress="2 TEST ROAD",suburb="Fitzroy",state="",postcode="3065"},
                comment="DFE",freightCents=1000,totalCents=15000,
                lines=new List<OrderLine> {new OrderLine {kind="product",sourceSku="W43116",code="W43116",description="TEST TYRE",quantity=1,unitCents=14000,totalCents=14000}}};
        }
    }
}
