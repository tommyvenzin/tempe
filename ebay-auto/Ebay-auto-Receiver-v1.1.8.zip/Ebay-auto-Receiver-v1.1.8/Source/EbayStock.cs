// eBay stock review: Sydney's displayed Avail, after the item's quantity and price are committed.
// No stock is calculated or added back. A typed answer acknowledges one item and one reading.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace TempeCostar {
    public sealed class EbayStockDecision {
        public int line,quantity,available;
        public string sku,answer,atUtc;
    }
    internal static class EbayStock {
        internal const string Checking="low stock - currently checking";
        internal static string Kind(int available) { return available<0?"negative":available<=2?"low":"clear"; }
        internal static string Answer(int available,string text) {
            string s=(text??"").Trim().ToLowerInvariant();
            return Kind(available)=="negative"?(s=="yes"?s:null):Kind(available)=="low"&&(s=="ok"||s=="check")?s:null;
        }
        internal static bool Approved(IEnumerable<EbayStockDecision> saved,EbayLine line,int available) {
            return saved!=null&&saved.Any(x=>x!=null&&x.line==line.Line&&x.sku==line.Code&&x.quantity==line.Quantity&&
                x.available==available&&Answer(available,x.answer)!=null);
        }
        internal static string Comment(string original,IEnumerable<EbayStockDecision> saved) {
            string text=original??"";
            if(saved==null||!saved.Any(x=>x!=null&&x.answer=="check"&&Answer(x.available,x.answer)!=null)) return text;
            if(text.IndexOf(Checking,StringComparison.OrdinalIgnoreCase)>=0)return text;
            return text+(text.Length>0?" | ":"")+Checking;
        }
        // The stock pane must belong to this exact item row, not another expanded row or OtherBrs.
        // The pane shape is mapped on wholesale Orders; a Repair Order must prove that same shape at runtime.
        internal static WholesaleOrderReader.StockRead Read(List<ControlInfo> s,long handle,string code) {
            var grid=Selectors.ProductGrid(s);
            var rows=grid.Rows.Where(x=>x.Handle==handle&&Order.Norm(x.Value)==Order.Norm(code)).ToList();
            if(rows.Count!=1||grid.Rows.Count(x=>x.Parent==rows[0].Parent)!=1)
                return new WholesaleOrderReader.StockRead {Problem="the stock pane could not be tied to this item row"};
            return WholesaleOrderReader.Stock(s,rows[0].Parent,c=>c.TextState=="read"?c.Value:null);
        }
        internal static string Title(int available) { return available<0?"We're short on this one":"Stock's looking tight"; }
        internal static string Instructions(int available) {
            return available<0?
                "Give the customer a call or message them that we don't have it in stock.\r\n\r\nType yes to confirm you'll handle it, then I'll finish the order.":
                "Type ok to carry on.\r\n\r\nType check to carry on and add this to the comment:\r\n"+Checking;
        }
    }
    internal sealed class EbayStockPrompt : Form {
        readonly int available;
        readonly TextBox input;
        readonly Button go;
        readonly System.Windows.Forms.Timer stop;
        bool aborted;
        internal string Result { get;private set; }
        sealed class CostarOwner : IWin32Window {
            readonly IntPtr handle;
            internal CostarOwner(IntPtr value){handle=value;}
            public IntPtr Handle {get{return handle;}}
        }
        internal EbayStockPrompt(EbayLine line,int value,Func<bool> cancelled) {
            available=value;Text="Ebay-auto - stock check";ClientSize=new Size(490,315);
            Font=new Font("Segoe UI",10);BackColor=Color.White;FormBorderStyle=FormBorderStyle.FixedDialog;
            StartPosition=FormStartPosition.CenterParent;ShowInTaskbar=false;ControlBox=false;MaximizeBox=false;MinimizeBox=false;
            Controls.Add(new Label {Text=EbayStock.Title(value),Location=new Point(22,18),Size=new Size(445,32),
                Font=new Font("Segoe UI",15,FontStyle.Bold),ForeColor=value<0?Color.Firebrick:Color.FromArgb(142,87,0)});
            Controls.Add(new Label {Text=line.Code+"   |   Sydney Avail: "+value.ToString(CultureInfo.InvariantCulture)+"   |   Order qty: "+line.Quantity,
                Location=new Point(22,58),Size=new Size(445,38)});
            Controls.Add(new Label {Text=EbayStock.Instructions(value),Location=new Point(22,100),Size=new Size(445,112)});
            input=new TextBox {Location=new Point(22,225),Size=new Size(290,28),MaxLength=12};
            go=new Button {Text="Let's go",Location=new Point(326,223),Size=new Size(140,33),Enabled=false};
            Controls.Add(input);Controls.Add(go);AcceptButton=go;
            Controls.Add(new Label {Text="Waiting for your answer. Nothing continues until you type it.",
                Location=new Point(22,274),Size=new Size(445,25),ForeColor=Color.DimGray,Font=new Font("Segoe UI",9)});
            input.TextChanged+=delegate {go.Enabled=EbayStock.Answer(available,input.Text)!=null;};
            go.Click+=delegate {
                string answer=EbayStock.Answer(available,input.Text);if(answer==null)return;
                Result=answer;DialogResult=DialogResult.OK;Close();
            };
            Shown+=delegate {input.Focus();};
            stop=new System.Windows.Forms.Timer {Interval=200};
            stop.Tick+=delegate {
                bool end;try {end=cancelled();}catch(Exception){end=true;}
                if(end){aborted=true;Result=null;Close();}
            };
            stop.Start();
        }
        protected override void OnFormClosing(FormClosingEventArgs e) {
            // X/Alt+F4 cannot approve or dismiss the gate. Stop/shutdown ends the job, never approves it.
            if(e.CloseReason!=CloseReason.UserClosing&&e.CloseReason!=CloseReason.None){aborted=true;Result=null;}
            if(Result==null&&!aborted)e.Cancel=true;
            base.OnFormClosing(e);
        }
        protected override bool ProcessDialogKey(Keys keyData) {
            if(keyData==Keys.Escape)return true;
            return base.ProcessDialogKey(keyData);
        }
        protected override void Dispose(bool disposing) {if(disposing&&stop!=null)stop.Dispose();base.Dispose(disposing);}
        internal static string Ask(IntPtr owner,EbayLine line,int value,Func<bool> cancelled) {
            using(var form=new EbayStockPrompt(line,value,cancelled)) {
                form.ShowDialog(new CostarOwner(owner));
                if(form.Result==null)throw new OperationCanceledException("Stock check was not answered. The order is stopped, not approved.");
                return form.Result;
            }
        }
    }
}
