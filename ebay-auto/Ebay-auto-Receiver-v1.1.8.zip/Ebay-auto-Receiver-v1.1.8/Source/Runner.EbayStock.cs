using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;

namespace TempeCostar {
    internal sealed partial class Runner {
        internal List<EbayStockDecision> StockDecisions=new List<EbayStockDecision>();
        internal Action<EbayStockDecision> OnStockDecision;
        internal volatile string StockWaiting;

        int ReadEbayStock(EbayLine line,long handle) {
            Ready();var s=GridCurrent();var grid=Selectors.ProductGrid(s);var row=Row(s,handle,line.Code);
            // Select the item's description to expose its own stock pane; no quantity or price is changed.
            Focus(Selectors.Cell(s,row,grid.Description),true);
            var clock=Stopwatch.StartNew();int? previous=null;string problem="its stock pane was not shown";
            while(clock.ElapsedMilliseconds<6000) {
                Ready();var all=Current();
                try {
                    var found=EbayStock.Read(all,handle,line.Code);
                    if(found.Found&&found.Problem==null&&found.Available.HasValue&&!found.NonStocking) {
                        int value=found.Available.Value;
                        if(previous==value) {
                            Diag.EventRaw("ebay_stock_read","sku="+line.Code+" line="+line.Line+" qty="+line.Quantity+" Sydney Avail="+value);
                            return value;
                        }
                        previous=value;problem="its Avail value kept changing";
                    } else {
                        previous=null;problem=found.Problem??(found.NonStocking?"COSTAR marked this item NON-STOCKING":"its stock pane was not shown");
                    }
                } catch(InvalidOperationException e) {previous=null;problem=e.Message;}
                Pause(150);
            }
            Diag.EventRaw("ebay_stock_unreadable","sku="+line.Code+" line="+line.Line+": "+problem);
            try {Dump("stock-unreadable-controls",Current());}catch(Exception){}
            throw new InvalidOperationException("Couldn't read Sydney Avail for "+line.Code+": "+problem+". Stock check hasn't passed; the order is paused for inspection.");
        }
        void ApplyStockComment() {
            string expected=EbayStock.Comment(order.comment,StockDecisions);
            if(expected==order.comment)return;
            // Keep EBAY DFE and the user's other comment text; add the checking note only once.
            order.comment=expected;
            LeaveGrid("stock check comment");var h=HeaderNow();GuardCustomer(h);
            PutMapped(h.Comment,expected,"stock check comment",true);GuardCustomer(h);
            Diag.EventRaw("ebay_stock_comment","added low-stock checking note; existing comment kept");
        }
        void ValidateEbayStock(EbayLine line,long handle) {
            int available=ReadEbayStock(line,handle);
            for(int changed=0;changed<4;changed++) {
                if(EbayStock.Kind(available)=="clear")return;
                if(EbayStock.Approved(StockDecisions,line,available)) {
                    Diag.EventRaw("ebay_stock_ack_reused","sku="+line.Code+" line="+line.Line+" Avail="+available+"; same item, quantity and reading");
                    ApplyStockComment();return;
                }
                string before=SettledPrint();Order.Require(before!=null,"Couldn't record this Repair Order before the stock prompt. Entry stopped.");
                string answer;
                StockWaiting="Waiting for Seb: "+line.Code+" stock check (Sydney Avail "+available+")";
                Say(StockWaiting);Diag.EventRaw("ebay_stock_prompt","sku="+line.Code+" line="+line.Line+" Avail="+available+"; waiting for typed answer");
                try {
                    answer=EbayStockPrompt.Ask(root,line,available,()=>Cancel||process.HasExited||!Native.IsWindow(root));
                } finally {StockWaiting=null;}
                Check(false);Ready();
                Order.Require(before==SettledPrint(),"The Repair Order changed while the stock prompt was open. Entry stopped; check it before retrying.");
                Order.Require(EbayStock.Answer(available,answer)!=null,"The stock prompt has no valid typed answer. Entry stopped.");
                var decision=new EbayStockDecision {line=line.Line,sku=line.Code,quantity=line.Quantity,available=available,answer=answer,
                    atUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture)};
                // Save before proceeding; a failed journal write never silently approves stock.
                if(OnStockDecision!=null)OnStockDecision(decision);
                StockDecisions.Add(decision);
                Diag.EventRaw("ebay_stock_answer","sku="+line.Code+" line="+line.Line+" Avail="+available+" answer="+answer+
                    (answer=="yes"?"; Seb acknowledged customer contact; no message sent by helper":""));
                ApplyStockComment();
                int now=ReadEbayStock(line,handle);
                if(now==available)return;
                Diag.EventRaw("ebay_stock_changed","sku="+line.Code+" Avail changed from "+available+" to "+now+" while waiting; checking again");
                available=now;
            }
            throw new InvalidOperationException("Stock kept changing while Seb was answering. Entry stopped; check Sydney Avail before retrying.");
        }
    }
}
