// The entry engine (2.9.11): the new-customer account step. What COSTAR shows, and why each check is there, is in NewAccount.cs.
// Online orders (pickups and deliveries) and eBay orders call MaybeMakeAccount right after X is filled for a customer the phone
// lookup didn't find; phone jobs and Repair Orders changed from the phone never do. Every press is COSTAR's own button pressed
// directly (BM_CLICK posted, with its window in front); OK on the new-customer form at most once per order, ever.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace TempeCostar {
    // A stop after OK went on COSTAR's new-customer form and the account couldn't be confirmed (never wrapped again).
    internal sealed class NewAccountUnsureException : InvalidOperationException {
        internal NewAccountUnsureException(string message,Exception inner) : base(message,inner) { }
    }
    internal sealed partial class Runner {
        // What the account step came to, for the result and the diagnostics: "" (not looked at: the lookup found the customer,
        // an account was on the order, or it didn't end with Customer Not found), "made", "not made: ..." or "unsure: ...".
        internal string NewAccountResult="";
        // 2.9.12: where the account step's state came from ("address", "lookup", "none: why"), "" when not looked at.
        internal string NewAccountState="";
        // 2.9.13: where a delivery's (or an eBay order's) billing and delivery states came from when it was received: "address"
        // or "lookup" each; "" when not looked at then (a pickup). Never the states themselves.
        internal string BillingStateFrom="",DeliveryStateFrom="";
        // accountStep: the step's own windows (COSTAR's customer search, its new-customer form) may be up, so nothing else
        // answers or cancels a COSTAR window then (Check, AnswerPopup, RecoverCustomerUi, TryChooseFirstAccount).
        // accountUnsure: OK went and what followed couldn't be confirmed (the stop keeps the loose print: StopPrintNow).
        bool accountStep,accountUnsure;
        // The phone lookup ended with COSTAR's Customer Not found notice and nothing else (NewAccount.NoticeOnly).
        bool lookupNotFound,notFoundShown,branchesCancelled;
        const int AccountWindowMs=10000,AccountOkMs=20000;
        const string AccountMade="A new COSTAR customer account was made for this customer.";
        const string LeftForYou="COSTAR has a window open over the order, and an earlier attempt of this order pressed OK on COSTAR's new-customer form without the account being confirmed. Nothing was pressed on it: deal with it at the PC (and check this customer in COSTAR), then Retry (or finish the order by hand).";
        bool? leftUnsure;

        // Right after X is filled for a customer the lookup didn't find. True: an account was made, confirmed and taken on
        // (COSTAR's account number and its name kept); the caller then checks X again and fills Y. False: no account, the
        // order goes on as before (said why), or the step stopped the order (an exception).
        bool MaybeMakeAccount() {
            var h=HeaderNow();string account=ReadLive(h.Account);
            // 2.9.12: the state written in the address, else looked up by suburb and postcode (AuPlaces), else none.
            // 2.9.13: one looked up when the order was received (an online delivery, an eBay order) is a looked-up one (AccountState).
            var found=NewAccount.AccountState(order.customer);
            var missing=NewAccount.Missing(NewAccount.WithState(order.customer,found.State));
            string decision=NewAccount.Decide(NewAccount.On,Direct.On,lookupNotFound,account,order.orderId,missing,false);
            if(decision==NewAccount.Make) decision=NewAccount.Decide(NewAccount.On,Direct.On,lookupNotFound,account,order.orderId,missing,NewAccountLog.Tried(order.orderId));
            // A retry (of this Repair Order, or in a new one) after OK was pressed for this order: Account# confirmed blank on a
            // Repair Order that is ready, so the order goes on without an account, with a check by hand (COSTAR may hold the
            // customer already).
            else if(decision==NewAccount.NotNotice&&Order.Clean(account).Length==0&&Order.Clean(order.orderId).Length>0&&NewAccountLog.Tried(order.orderId)==true) decision=NewAccount.Tried;
            if(decision!=NewAccount.HasAccount&&decision!=NewAccount.NotNotice) NoteState(found);
            if(decision!=NewAccount.Make) { NotMade(decision.StartsWith("missing: ",StringComparison.Ordinal)&&found.State==null&&missing.Contains("state")?decision+"; the state: "+found.Why:decision);return false; }
            // A state looked up, or written as a name ("New South Wales"): its code into X before the magnifier (COSTAR's form
            // takes it from there), and the order's state from here on (X's checks and the final check).
            if(found.State!=Order.Clean(order.customer.state)) {
                PutMapped(h.State,found.State,found.Source=="lookup"?"state (looked up from the suburb and postcode)":"state");
                order.customer.state=found.State;
            }
            return MakeAccount();
        }
        // 2.9.13: where the order's billing and delivery states came from when it was received, for the diagnostics (the run's
        // environment, an event and review.json), once its checks have passed. Nothing for a pickup (looked at then only by
        // the account step, NoteState).
        void NoteAddressStates() {
            BillingStateFrom=order.customer==null?"":order.customer.StateFrom??"";
            DeliveryStateFrom=order.shipping==null?"":order.shipping.StateFrom??"";
            if(BillingStateFrom.Length==0 && DeliveryStateFrom.Length==0) return;
            Diag.SetEnv("billingState",BillingStateFrom);Diag.SetEnv("deliveryState",DeliveryStateFrom);
            Diag.EventRaw("address_states","billing: "+NewAccount.StateFromWords(BillingStateFrom)+"; delivery: "+NewAccount.StateFromWords(DeliveryStateFrom));
        }
        // 2.9.12: where the account's state came from, once the step is looked at: "address", "lookup" or "none: why".
        void NoteState(StateFound found) {
            NewAccountState=found.State!=null?found.Source:"none: "+found.Why;
            Diag.SetEnv("newAccountState",NewAccountState);
            Diag.EventRaw("new_account_state",found.State==null?"none: "+found.Why
                :found.Source=="lookup"?"looked up from the suburb and postcode in the address list ("+AuPlaceData.Source+")"
                :"from the customer's address"+(found.Why==null?"":"; "+found.Why));
        }
        // No account: the order goes on as before. Said (and recorded) by why, never with the customer's details. OK pressed for
        // this order before is a check by hand (a customer may be in COSTAR already).
        void NotMade(string why) {
            if(why==NewAccount.HasAccount||why==NewAccount.NotNotice) { Diag.EventRaw("new_account","not looked at: "+why);return; }
            NewAccountResult="not made: "+why;Diag.SetEnv("newAccount",NewAccountResult);Diag.EventRaw("new_account",NewAccountResult);
            if(why==NewAccount.Tried) {
                CheckLater("No COSTAR account was made for this new customer: an earlier attempt of this order went as far as OK on COSTAR's new-customer form, so the helper doesn't make one again. Check COSTAR for this customer before making one by hand.");
                return;
            }
            Say("No COSTAR account made for this new customer ("+why+"). Account# stays blank; the order goes on as before.");
        }
        // X as COSTAR shows it now.
        CustomerPanel Panel(FieldMap h) {
            return new CustomerPanel {Account=ReadLive(h.Account),Name=ReadLive(h.Name),Address=ReadLive(h.Address),Suburb=ReadLive(h.Suburb),
                State=ReadLive(h.State),Postcode=ReadLive(h.Postcode),Phone=ReadLive(h.Phone)};
        }
        // COSTAR's windows over this Repair Order now: visible, owned by it (directly or through another), its shadows and tips aside.
        List<IntPtr> Owned() {
            var list=new List<IntPtr>();
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) {
                if(w!=root&&Native.IsWindowVisible(w)&&Native.Pid(w)==pid&&!Decoration(w)&&OwnedByOrder(w)) list.Add(w);
                return list.Count<20;
            },IntPtr.Zero);
            return list;
        }
        // A COSTAR button pressed directly: BM_CLICK posted (it opens or closes a window), with its window in front and free
        // (BM_CLICK may go nowhere in a window that isn't the active one) and the button still there, visible and enabled.
        // False: nothing was sent.
        bool PressOn(ControlInfo c,IntPtr window,string label) {
            var h=new IntPtr(c.Handle);var clock=Stopwatch.StartNew();bool raised=false;
            while(Native.GetForegroundWindow()!=window&&clock.ElapsedMilliseconds<2500) {
                Check(false);
                if(!raised&&clock.ElapsedMilliseconds>500&&!Native.UserActiveWithin(2000)) { raised=true;Native.BringToFront(window); }
                Pause(50);
            }
            WaitIdle(2000);Check(false);
            bool ready=Native.GetForegroundWindow()==window&&Native.IsWindowEnabled(window)&&Native.IsWindow(h)&&Native.IsWindowVisible(h)&&Native.IsWindowEnabled(h)&&Native.GetAncestor(h,2)==window;
            bool sent=ready&&Direct.PressLater(h);
            if(sent) Diag.Pressed();
            Diag.EventRaw("new_account",label+(sent?" pressed":ready?": couldn't be pressed":": not pressed (its window wasn't in front and free)"));
            return sent;
        }
        // The window COSTAR opens over the order: in front and owned by it within ms (brought back once when another program took
        // the screen and nobody is at the PC). Zero: none opened.
        IntPtr OpenedOver(int ms,IntPtr except) {
            var clock=Stopwatch.StartNew();bool raised=false;
            while(clock.ElapsedMilliseconds<ms) {
                Check(false);
                var owned=Owned().Where(w=>w!=except).ToList();
                if(owned.Count>0) {
                    var front=Native.GetForegroundWindow();
                    if(owned.Contains(front)) return front;
                    if(!raised&&clock.ElapsedMilliseconds>1500&&!Native.UserActiveWithin(2000)) { raised=true;Native.BringToFront(owned[owned.Count-1]); }
                }
                Pause(50);
            }
            return IntPtr.Zero;
        }
        // A COSTAR window's controls once they have all been read (a window that has only just opened may still be drawing);
        // null when that didn't happen within 3 s.
        List<ControlInfo> Steady(IntPtr window) {
            var clock=Stopwatch.StartNew();
            while(clock.ElapsedMilliseconds<3000) {
                Check(false);
                if(!Native.IsWindow(window)||!Native.IsWindowVisible(window)) return null;
                var s=PopupSnapshot(window);
                if(s!=null&&!lastSnapshotBusy&&!s.Any(c=>c.TextState=="busy"||c.TextState=="read-failed-or-timed-out")) return s;
                Pause(100);
            }
            return null;
        }
        // 2.9.14: the window once COSTAR has finished drawing it, known by read (WindowLooks.WhenComplete: looked at again until
        // it is that window, stops changing without being it, or AccountWindowMs is up), or null; last: the last look. Said in
        // the diagnostics either way (looks, time, controls; never their words).
        T Complete<T>(IntPtr window,Func<string,List<ControlInfo>,T> read,string label,out List<ControlInfo> last) where T:class {
            var clock=Stopwatch.StartNew();int looks;string why;
            T found=WindowLooks.WhenComplete<T>(()=>Steady(window),s=>read(Native.Caption(window),s),()=>clock.ElapsedMilliseconds,()=>Pause(WindowLooks.PauseMs),AccountWindowMs,out last,out looks,out why);
            Diag.EventRaw("new_account",label+(found!=null?" known":" not known ("+why+")")+" at look "+looks+", "+clock.ElapsedMilliseconds+" ms, "+(last==null?0:last.Count)+" controls");
            return found;
        }
        // Stopped with nothing made, the window left as it is for a person (never a guess at its buttons).
        void LeaveIt(string what,IntPtr window) {
            try { if(window!=IntPtr.Zero) Diag.EventRaw("new_account","left for a person: "+Sanitize.Text(Native.Caption(window),40)); CaptureForegroundWindow("new account"); } catch(Exception) { }
            NewAccountResult="not made: "+what;Diag.SetEnv("newAccount",NewAccountResult);
            throw new InvalidOperationException("No COSTAR account was made for this new customer, and the order stopped: "+what+". Nothing more was pressed: close it at the PC, then Retry (or finish the order by hand).");
        }
        // Cancel on COSTAR's customer search or its new-customer form (nothing is made by it: 17 Nov, straight back to the
        // Repair Order), then the order in front and free with nothing of COSTAR's over it (a customer search back after the
        // form's Cancel is cancelled too, once). Stops when that doesn't happen.
        void CancelBack(ControlInfo cancel,IntPtr window,string label) {
            if(!PressOn(cancel,window,label+"'s Cancel")) LeaveIt(label+" is open and its Cancel couldn't be pressed",window);
            var clock=Stopwatch.StartNew();bool second=false;
            while(clock.ElapsedMilliseconds<AccountWindowMs) {
                Check(false);
                var owned=Owned();
                if(owned.Count==0&&Native.GetForegroundWindow()==root&&Native.IsWindowEnabled(root)) { Diag.EventRaw("new_account",label+" cancelled: back on the Repair Order");return; }
                if(!second&&owned.Count==1&&owned[0]!=window&&Native.GetForegroundWindow()==owned[0]) {
                    var s=Steady(owned[0]);var search=s==null?null:NewAccountSearch.Read(Native.Caption(owned[0]),s);
                    if(search!=null) { second=true;window=owned[0];label="COSTAR's customer search";if(!PressOn(search.Cancel,window,label+"'s Cancel")) LeaveIt(label+" is open and its Cancel couldn't be pressed",window);continue; }
                }
                Pause(50);
            }
            LeaveIt(label+" didn't close after its Cancel",Native.GetForegroundWindow());
        }
        static string Live(ControlInfo c) { string t;return Native.TryText(new IntPtr(c.Handle),out t)?Order.Clean(t):""; }
        static string LiveOrNull(ControlInfo c) { string t;return Native.TryText(new IntPtr(c.Handle),out t)?Order.Clean(t):null; }
        static bool? Chosen(ControlInfo c) { int role;bool on;if(!TickState(new IntPtr(c.Handle),out role,out on)||role!=45) return null;return on; }
        NewAccountValues FormValues(NewAccountForm f) {
            return new NewAccountValues {Last=Live(f.Last),First=Live(f.First),Address=Live(f.Address),City=Live(f.City),State=LiveOrNull(f.State),Postcode=Live(f.Postcode),
                Home=Live(f.Home),Mobile=Live(f.Mobile),Business=Live(f.Business),Fax=Live(f.Fax),PersonalFile=Chosen(f.PersonalFile)};
        }
        // A look at the Repair Order's customer panel (false while it is being redrawn or COSTAR is busy).
        bool HeaderLook(out FieldMap m,out List<ControlInfo> s) {
            m=null;s=null;
            try { s=Snapshot(root);if(lastSnapshotBusy) return false;m=Selectors.Header(s);string all=m.Account.Value+m.Name.Value+m.Phone.Value;return all!=null; }
            catch(InvalidOperationException) { return false; }
        }
        // Once OK went: AccountOkMs at most for the form to be gone, nothing of COSTAR's over the order, the order in front and
        // free, and Account# showing a number, read the same twice, with the same name's words and the same phone. Null: made
        // (account, name: COSTAR's; copied: Ship to holds the customer's name, COSTAR's copy); else what was seen last.
        string AfterOk(IntPtr form,CustomerPanel x,out string account,out string name,out bool copied) {
            account=null;name=null;copied=false;string seen="nothing changed";
            var clock=Stopwatch.StartNew();
            while(clock.ElapsedMilliseconds<AccountOkMs) {
                Check(false);
                var look=new AfterOkLook {AccountBefore=x.Account,NameBefore=x.Name,OrderPhone=order.customer.phone};
                look.FormUp=Native.IsWindow(form)&&Native.IsWindowVisible(form);
                look.OtherWindow=!look.FormUp&&Owned().Count>0;
                look.OrderFront=Native.GetForegroundWindow()==root;look.OrderEnabled=Native.IsWindowEnabled(root);
                if(look.FormUp||look.OtherWindow||!look.OrderFront||!look.OrderEnabled) { seen=NewAccount.Uncertain(look);Pause(100);continue; }
                FieldMap first,second;List<ControlInfo> s1,s2;
                if(!HeaderLook(out first,out s1)) { seen="the customer panel was still being redrawn";Pause(100);continue; }
                look.Account=first.Account.Value;
                if(look.Account.Length==0) { look.AccountAgain="";look.Name=first.Name.Value;look.Phone=first.Phone.Value;seen=NewAccount.Uncertain(look);Pause(150);continue; }
                Pause(400);
                if(Owned().Count>0||Native.GetForegroundWindow()!=root||!HeaderLook(out second,out s2)) { seen="the Repair Order wasn't settled";continue; }
                look.AccountAgain=second.Account.Value;look.Name=second.Name.Value;look.Phone=second.Phone.Value;
                seen=NewAccount.Uncertain(look);
                if(seen==null) {
                    account=look.AccountAgain;name=look.Name;
                    try { copied=NewAccount.SameWords(Selectors.Delivery(s2).Name.Value,name); } catch(InvalidOperationException) { }
                    return null;
                }
                Pause(150);
            }
            return seen;
        }
        string UnsureWords(string seen) {
            return "COSTAR may have made a customer account for this order: OK was pressed on COSTAR's new-customer form, then "+seen+
                ". Nothing more was pressed, and no attempt of this order makes an account again. Check COSTAR (this customer and this Repair Order): finish the order by hand, or Retry (a retry keeps an account that is on the Repair Order).";
        }
        // Whether an earlier attempt of this order pressed OK on COSTAR's new-customer form with no account confirmed
        // (NewAccount.LeftUnsure): read once per attempt, when a notice of COSTAR's is about to be answered (AnswerPopup).
        bool AccountLeftUnsure() {
            if(leftUnsure==null) leftUnsure=Order.Clean(order.orderId).Length>0&&NewAccount.LeftUnsure(NewAccountLog.State(order.orderId));
            return leftUnsure.Value;
        }
        // This attempt continues the Repair Order that an unconfirmed OK on COSTAR's new-customer form stopped in (that stop kept
        // the loose print).
        bool AfterUnsureStop { get { return OwnAttempt&&ResumePrint!=null&&ResumePrint.StartsWith(NewAccount.LoosePrint,StringComparison.Ordinal); } }
        // That Repair Order's X with Account# as COSTAR shows it, the same at two looks 400 ms apart with the order in front, free
        // and nothing of COSTAR's over it: an account there is kept, a blank Account# gone on with. Else (5 s) stopped, nothing typed.
        FieldMap SteadyAccount() {
            var clock=Stopwatch.StartNew();string last=null;
            while(clock.ElapsedMilliseconds<5000) {
                var h=HeaderNow();string now=Order.Clean(h.Account.Value);
                bool free=Owned().Count==0&&Native.GetForegroundWindow()==root&&Native.IsWindowEnabled(root);
                if(free&&last!=null&&now==last) {
                    Diag.EventRaw("new_account","retry after an unconfirmed OK: Account# "+(now.Length==0?"blank":"holds an account")+" at two looks");
                    return h;
                }
                last=free?now:null;Pause(400);
            }
            throw new InvalidOperationException("Account# on this Repair Order didn't read the same twice after the earlier attempt's OK on COSTAR's new-customer form. Nothing was typed: check this customer and the Repair Order at the PC, then Retry (or finish the order by hand).");
        }
        // The step itself (MaybeMakeAccount decided an account is wanted): X checked against the order, the magnifier, COSTAR's
        // customer search, its Add new, the new-customer form read and checked (Cancel when anything isn't as it must be), the
        // order marked (NewAccountLog), OK, and the account confirmed on the Repair Order.
        bool MakeAccount() {
            var wait=Diag.Wait("new_account");var clock=Stopwatch.StartNew();
            bool okSent=false;IntPtr form=IntPtr.Zero;
            try {
                Ready();var s=Current();var h=Selectors.Header(s);
                var x=Panel(h);
                var wrong=NewAccount.PanelProblems(x,order.customer);
                if(wrong.Count>0) { wait.Done("x differs");NotMade("the Repair Order's customer details aren't the order's: "+String.Join(", ",wrong.ToArray()));return false; }
                var magnifier=Selectors.AccountLookup(s,h);
                if(magnifier==null) { wait.Done("no magnifier");NotMade("the magnifier beside Account# wasn't found");return false; }
                if(Owned().Count>0) { wait.Done("window open");NotMade("a COSTAR window was already open over the order");return false; }
                Say("New customer, every detail given: making a COSTAR account (the magnifier beside Account#, Add new).");
                // From here the step's own windows may be up: nothing else answers or cancels a COSTAR window (see accountStep).
                accountStep=true;
                if(!PressOn(magnifier,root,"the magnifier beside Account#")) { wait.Done("magnifier not pressed");NotMade("the magnifier beside Account# couldn't be pressed");return false; }
                // COSTAR's customer search, over the order.
                IntPtr searchWindow=OpenedOver(AccountWindowMs,IntPtr.Zero);
                if(searchWindow==IntPtr.Zero) {
                    if(Owned().Count==0&&Native.IsWindowEnabled(root)) { wait.Done("no search window");NotMade("the magnifier didn't open COSTAR's customer search");return false; }
                    LeaveIt("COSTAR didn't open its customer search in front after the magnifier",Native.GetForegroundWindow());
                }
                // 2.9.14: once COSTAR has finished drawing it (18 Nov 08:15: looked at too soon, it wasn't complete yet).
                List<ControlInfo> searchControls;
                var search=Complete<NewAccountSearch>(searchWindow,NewAccountSearch.Read,"COSTAR's customer search",out searchControls);
                if(search==null) LeaveIt("the magnifier opened a COSTAR window that isn't its customer search (\""+Sanitize.Text(Native.Caption(searchWindow),40)+"\")",searchWindow);
                Diag.EventRaw("new_account","COSTAR's customer search in "+clock.ElapsedMilliseconds+" ms");
                if(!PressOn(search.AddNew,searchWindow,"Add new")) { wait.Done("add new not pressed");CancelBack(search.Cancel,searchWindow,"COSTAR's customer search");NotMade("Add new couldn't be pressed");return false; }
                // COSTAR's new-customer form (the customer search goes as it opens).
                form=OpenedOver(AccountWindowMs,searchWindow);
                if(form==IntPtr.Zero) {
                    if(Native.IsWindow(searchWindow)&&Native.IsWindowVisible(searchWindow)&&Native.GetForegroundWindow()==searchWindow) { wait.Done("no form");CancelBack(search.Cancel,searchWindow,"COSTAR's customer search");NotMade("Add new didn't open COSTAR's new-customer form");return false; }
                    LeaveIt("COSTAR's new-customer form didn't open in front after Add new",Native.GetForegroundWindow());
                }
                if(!NewAccountForm.IsTitle(Native.Caption(form))) LeaveIt("Add new opened a COSTAR window that isn't its new-customer form (\""+Sanitize.Text(Native.Caption(form),40)+"\")",form);
                List<ControlInfo> formControls;
                var f=Complete<NewAccountForm>(form,NewAccountForm.Read,"COSTAR's new-customer form",out formControls);
                if(f==null) {
                    var cancel=formControls==null?null:NewAccountForm.CancelOnly(formControls);
                    if(cancel==null) LeaveIt("COSTAR's new-customer form is laid out differently and its Cancel wasn't found",form);
                    wait.Done("form unfamiliar");CancelBack(cancel,form,"COSTAR's new-customer form");NotMade("COSTAR's new-customer form is laid out differently (cancelled)");return false;
                }
                Diag.EventRaw("new_account","COSTAR's new-customer form in "+clock.ElapsedMilliseconds+" ms");
                // Every required box filled from X, and X the order's: else Cancel, no account, the order goes on.
                var values=FormValues(f);
                var problems=NewAccount.FormProblems(values,x,order.customer);
                if(problems.Count>0) { wait.Done("form incomplete");CancelBack(f.Cancel,form,"COSTAR's new-customer form");NotMade("COSTAR's new-customer form: "+String.Join(", ",problems.ToArray())+" (cancelled)");return false; }
                // The last look before OK: nobody at the PC (3 s at most), the form still as read, in front and free.
                var quiet=Stopwatch.StartNew();
                while(Native.UserActiveWithin(1500)&&quiet.ElapsedMilliseconds<3000) Pause(100);
                if(Native.UserActiveWithin(1500)) { wait.Done("person at the PC");CancelBack(f.Cancel,form,"COSTAR's new-customer form");NotMade("someone was using the PC (cancelled)");return false; }
                if(FormValues(f).Print()!=values.Print()||Native.GetForegroundWindow()!=form||!Native.IsWindowEnabled(form)) { wait.Done("form changed");CancelBack(f.Cancel,form,"COSTAR's new-customer form");NotMade("COSTAR's new-customer form changed before OK (cancelled)");return false; }
                // Kept before the press: whatever comes of it, this order never gets OK pressed again.
                try { NewAccountLog.Record(order.orderId,"pressed"); }
                catch(Exception e) { wait.Done("not recorded");CancelBack(f.Cancel,form,"COSTAR's new-customer form");NotMade("the helper couldn't keep its record of accounts ("+e.GetType().Name+"; cancelled)");return false; }
                if(!PressOn(f.Ok,form,"OK on COSTAR's new-customer form")) {
                    // Nothing was sent (PressOn): kept as such, still never tried again for this order.
                    try { NewAccountLog.Record(order.orderId,"not sent"); } catch(Exception) { }
                    wait.Done("ok not pressed");CancelBack(f.Cancel,form,"COSTAR's new-customer form");NotMade("OK couldn't be pressed (cancelled; a retry won't try again)");return false;
                }
                okSent=true;
                string account,name;bool copied;
                string seen=AfterOk(form,x,out account,out name,out copied);
                if(seen!=null) {
                    accountUnsure=true;try { NewAccountLog.Record(order.orderId,"unsure"); } catch(Exception) { }
                    NewAccountResult="unsure: "+seen;Diag.SetEnv("newAccount",NewAccountResult);Diag.EventRaw("new_account",NewAccountResult+" ("+clock.ElapsedMilliseconds+" ms)");wait.Done("unsure");
                    CaptureForegroundWindow("new account: unsure");
                    throw new NewAccountUnsureException(UnsureWords(seen),null);
                }
                try { NewAccountLog.Record(order.orderId,"made"); } catch(Exception) { }
                verifiedCustomerAccount=account;verifiedCustomerName=name;headerCache=null;
                NewAccountResult="made";Diag.SetEnv("newAccount","made");
                Diag.EventRaw("new_account","made: Account# "+account.Length+" characters, in "+clock.ElapsedMilliseconds+" ms; Ship to "+(copied?"filled by COSTAR from the customer":"not filled by COSTAR"));
                Say("Made a COSTAR customer account for this new customer (its number is on the Repair Order). Now checking the customer panel and the delivery details.");
                if(!Notices.Contains(AccountMade)) Notices.Add(AccountMade);
                wait.Done("made");
                return true;
            } catch(NewAccountUnsureException) { throw; }
            catch(OperationCanceledException) {
                if(okSent) {
                    accountUnsure=true;try { NewAccountLog.Record(order.orderId,"unsure"); } catch(Exception) { }
                    NewAccountResult="unsure: stopped";Diag.SetEnv("newAccount",NewAccountResult);Diag.EventRaw("new_account","unsure: stop pressed after OK");
                    Say("Stopped right after OK on COSTAR's new-customer form: COSTAR may have made the account. No attempt of this order makes another one.");
                }
                throw;
            } catch(Exception e) {
                if(!okSent) throw;
                accountUnsure=true;try { NewAccountLog.Record(order.orderId,"unsure"); } catch(Exception) { }
                NewAccountResult="unsure: "+e.GetType().Name;Diag.SetEnv("newAccount",NewAccountResult);Diag.EventRaw("new_account","unsure: "+e.GetType().Name+": "+e.Message);
                throw new NewAccountUnsureException(UnsureWords("the helper stopped ("+e.Message+")"),e);
            } finally { accountStep=false;wait.End(); }
        }
    }
}
