// Ebay-auto 1.0.0: the worker, inside Seb's Remote Desktop session, beside COSTAR Sydney (Branch 1). It asks the
// receiver on Seb's physical PC for the next eBay order (its LAN address from the connection: "localhost" here would be
// the Remote Desktop server, not Seb's PC), enters it into a new Repair Order in the COSTAR of THIS Windows session only,
// and reports back. Everything the RDP helper's eBay tab did is here (Start / Stop eBay orders, Check Sydney layout, Close
// each Repair Order, Stop all with Ctrl+Alt+F10, Discord alerts, Import connection, direct presses, the long poll, Start
// with Windows, diagnostics). It waits, saying why, while COSTAR is busy, has a window of its own open, isn't on
// Work-in-Progress, or someone is using the session.
// 1.1.0: a compact window with tabs (Activity, Connection, Settings, Updates, More), the same functions; which COSTAR
// Sydney it uses (the earliest-started one when several are open: EbayAutoCostar.cs); one-click updates (the switch waits
// until no order is being entered and the receiver holds new ones, and comes back with eBay orders on or paused as before).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed class EbayAutoWorkerForm : EbayAutoForm {
        readonly string folder;WorkerSettings connection;
        readonly EntryCoordinator coordinator=new EntryCoordinator();
        EbayEngine ebay;
        readonly BoundedLog messages=new BoundedLog();
        readonly RichTextBox log=Ui.Log();
        readonly Label chip=Ui.Chip("STARTING",Ui.Muted),headline=Ui.BigText("Starting ...");
        readonly Label targetLine=new Label {AutoSize=true,Font=Ui.Base,ForeColor=Ui.Ink},jobLine=new Label {AutoSize=true,Font=Ui.Small,ForeColor=Ui.Ink},detailLine=new Label {AutoSize=true,Font=Ui.Small,ForeColor=Ui.Muted};
        Label connectionLine,heldLine,alertsLine;
        Button toggle,checkLayout,stopAll,import,paste,setAlerts,testAlerts,offAlerts,export,openFolder,addNote;
        CheckBox closeEach,direct,newAccounts,longPoll,autoStart;
        readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer {Interval=1000},exitWait=new System.Windows.Forms.Timer {Interval=250};
        volatile bool checking;bool hotkey,syncingAuto,exitAfterStop,exporting;int ticks,exitWaited;
        bool receiverDownSaid,noCostarSaid;DateTime noCostarSince=DateTime.MinValue,holdSince=DateTime.MinValue;readonly DateTime startedAt=DateTime.Now;
        // 1.1.0: what the version before this one was doing (after an update), applied once started.
        readonly EbayResumeState resumed;
        internal EbayAutoWorkerForm(WorkerSettings settings,string data,bool startVisible,EbayResumeState resume) : base(Product.WorkerMode,startVisible||settings==null||(resume!=null&&resume.shown)) {
            folder=data;connection=settings;resumed=resume;
            // 1.1.1: once per installation (an earlier version's settings included), "Close each Repair Order once it's in"
            // is turned off: each verified Repair Order is left open for Seb to check and close. Ticked again later: kept.
            bool closedBefore=AppSettings.Current.ebayClose;
            if(EbayFinish.LeaveOpenOnce(AppSettings.Current,Product.Version)) {
                AppSettings.Current.Save();
                Journey.Note("setting","","","close each Repair Order once it's in: off from "+Product.Version+" (was "+(closedBefore?"on":"off")+"): each verified Repair Order is left open for Seb to check and close; the worker reports \""+EbayFinish.EzNext+"\"");
                if(closedBefore) Append("From "+Product.Version+" each eBay order, once entered and verified, is left OPEN in COSTAR for you to check and close: the worker says \""+EbayFinish.EzNext+"\" and goes on with the next order in a new Repair Order. (Settings tab: tick Close each Repair Order to have them closed again.)");
            }
            Direct.On=AppSettings.Current.directPresses;NewAccount.On=AppSettings.Current.newAccounts;   // 1.1.2: new buyers' COSTAR accounts
            Alerts.Load(folder);
            Journey.Tap=delegate(string kind,string job,string attempt,string words) { if(kind=="waiting"||kind=="ready"||kind=="report_sent"||kind=="layout_check") return;Append("["+kind.Replace('_',' ')+"]"+(job.Length>0?" "+job:"")+" "+Sanitize.Text(words,300)); };
            if(settings!=null) MakeEngine(settings);
            BuildWindow();
            timer.Tick+=delegate{UpdateStatus();Tick();UpdateTick();};
            exitWait.Tick+=delegate {
                exitWaited+=250;
                if(ebay==null||!ebay.Busy) { exitWait.Stop();RequestExit();return; }
                if(exitWaited>=30000) { exitWait.Stop();exitAfterStop=false;Append("The order being entered hasn't stopped after 30 s: Exit again once it has (it is never cut off half way).");ShowFromTray(); }
            };
            FormClosed+=delegate{timer.Dispose();exitWait.Dispose();if(hotkey)Native.UnregisterHotKey(Handle,1);if(ebay!=null)ebay.Dispose();};
            var created=Handle;BeginInvoke(new Action(Started));
        }
        void MakeEngine(WorkerSettings settings) {
            ebay=new EbayEngine(settings,folder,Append,coordinator);
            ebay.Attention=delegate(string kind,string words) {
                try { BeginInvoke(new Action(delegate {
                    Balloon(kind=="handed_over"?"eBay order needs finishing by hand":kind=="stopped"?"eBay order stopped":"eBay order in COSTAR: check by hand",Sanitize.Text(words,240),kind=="stopped"?ToolTipIcon.Warning:ToolTipIcon.Info);
                })); } catch(InvalidOperationException) { }
            };
        }
        protected override void OnHandleCreated(EventArgs e) { base.OnHandleCreated(e);Native.WatchSession(Handle); }
        protected override void WndProc(ref Message m) {
            if(m.Msg==Native.SessionChangeMessage) Native.SessionEvent(m.WParam.ToInt32());
            if(m.Msg==0x312&&m.WParam.ToInt32()==1) StopAll();
            base.WndProc(ref m);
        }
        void Started() {
            hotkey=Native.RegisterHotKey(Handle,1,3,0x79);
            timer.Start();
            Append(Product.Name+" worker "+Product.Version+" in this Remote Desktop session (session "+LocalProcess.Session+").");
            if(ebay==null) { Append("No connection to the receiver yet. On Seb's PC open the receiver and click Copy connection (or Export worker connection), then here: Paste connection (or Import connection).");SetTray(TrayState.Problem,"no connection: import it");ShowFromTray(); }
            else {
                // After an update: eBay orders on or paused as they were (a pause by Stop all included).
                if(resumed!=null&&ebay.Enabled&&!resumed.enabled) ebay.Enabled=false;
                ebay.Connect();
                Append(ebay.Enabled?"eBay orders are on (they were on last time): they go into COSTAR Branch "+ebay.Branch+" (Sydney) by themselves.":"eBay orders are paused. Click Start eBay orders to take them from the receiver.");
            }
            if(resumed!=null) Journey.Note("update_completed","","","now "+Product.Version+" (was "+resumed.from+"): eBay orders "+(ebay!=null&&ebay.Enabled?"on":"paused")+", window "+(resumed.shown?"open":"hidden"));
            if(!hotkey) Append("The Ctrl+Alt+F10 shortcut isn't available (another program has it): use Stop all.");
            // Up: the version before (after an update) is told, every launcher now starts this one, Start with Windows too.
            EbayAutoProgram.Ready(Part);AutoStart.Refresh(Product.WorkerMode);
            UpdateStatus();
        }
        void Append(string text) { messages.Add(text); }
        void BuildWindow() {
            Compact(600,500,440,380);
            // The header: how it stands, which COSTAR, what it is doing.
            var head=new FlowLayoutPanel {Dock=DockStyle.Top,FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Padding=new Padding(S(10),S(8),S(10),S(4)),BackColor=Ui.Surface};
            var top=new FlowLayoutPanel {AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,FlowDirection=FlowDirection.LeftToRight,WrapContents=true,Margin=new Padding(0,0,0,S(4))};
            chip.Padding=new Padding(S(8),S(3),S(8),S(3));chip.Margin=new Padding(0,S(2),S(8),S(2));top.Controls.Add(chip);top.Controls.Add(headline);
            foreach(var l in new[]{targetLine,jobLine,detailLine}) l.Margin=new Padding(0,0,0,S(2));
            head.Controls.Add(top);head.Controls.Add(targetLine);head.Controls.Add(jobLine);head.Controls.Add(detailLine);
            Resize+=delegate { int w=Math.Max(S(200),ClientSize.Width-S(24));foreach(var l in new Control[]{targetLine,jobLine,detailLine,top}) l.MaximumSize=new Size(w,0);headline.MaximumSize=new Size(Math.Max(S(120),w-chip.Width-S(12)),0); };
            // Activity: on/off, Stop all, the layout check, and the log.
            toggle=Primary("Start eBay orders");stopAll=Danger("Stop all (Ctrl+Alt+F10)");checkLayout=Secondary("Check Sydney layout (types nothing)");
            heldLine=Note("");
            var activity=new TabPage("Activity") {BackColor=Ui.Canvas};
            var grid=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Padding=new Padding(S(8))};
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));grid.RowStyles.Add(new RowStyle(SizeType.Percent,100));
            var row=Buttons(toggle,stopAll,checkLayout);row.Dock=DockStyle.Fill;heldLine.Dock=DockStyle.Fill;
            grid.Controls.Add(row,0,0);grid.Controls.Add(heldLine,0,1);grid.Controls.Add(log,0,2);
            grid.Resize+=delegate { int w=Math.Max(S(160),grid.ClientSize.Width-grid.Padding.Horizontal);row.MaximumSize=new Size(w,0);heldLine.MaximumSize=new Size(w,0); };
            activity.Controls.Add(grid);Tabs.TabPages.Add(activity);
            // Connection: the receiver and how to give this worker its connection.
            var c=Page("Connection");
            connectionLine=Line("");import=Secondary("Import connection...");paste=Secondary("Paste connection");
            c.Controls.Add(Heading("The receiver (Seb's PC)"));c.Controls.Add(connectionLine);c.Controls.Add(Buttons(paste,import));
            c.Controls.Add(Note("On Seb's PC: open the Ebay-auto receiver (Pairing tab) and click Copy connection, then click Paste connection here (Remote Desktop passes the clipboard over). Or Export worker connection there and Import connection here (it offers to delete the file afterwards: it holds the worker's key)."));
            c.Controls.Add(Note("The worker reaches the receiver at Seb's PC's own network address (never localhost: inside Remote Desktop that is the Remote Desktop server)."));
            // Settings: the ticks and Discord.
            var s=Page("Settings");
            closeEach=TickBox("Close each Repair Order once it's in and verified (off: it is left open for you to check and close, and the worker says \"ez, next\")",AppSettings.Current.ebayClose);
            direct=TickBox("Press COSTAR's buttons, ticks, tabs and boxes directly, without moving the mouse (recommended)",AppSettings.Current.directPresses);
            // 1.1.2 (Tommy, 17 Nov): a new buyer's COSTAR customer account (NewAccount).
            newAccounts=TickBox("Make a COSTAR customer account for a new buyer (after Customer Not found, when the order has every detail COSTAR's form asks for)",AppSettings.Current.newAccounts);
            longPoll=TickBox("Hold the connection to the receiver open so orders start at once (recommended)",AppSettings.Current.longPoll);
            autoStart=TickBox("Start the worker when I sign in to Windows (in the notification area)",false);
            setAlerts=Secondary("Set Discord alerts...");testAlerts=Secondary("Send a test");offAlerts=Secondary("Turn alerts off");alertsLine=Note("");
            s.Controls.Add(closeEach);s.Controls.Add(direct);s.Controls.Add(newAccounts);
            s.Controls.Add(Note("New buyer (1.1.2): after COSTAR's Customer Not found, the magnifier beside Account#, Add new, every required box of COSTAR's new-customer form checked against the order, then OK, once per order; then Ship to. A detail missing: no account, the order goes on as before. Needs direct presses."));
            s.Controls.Add(longPoll);s.Controls.Add(autoStart);
            s.Controls.Add(Heading("Discord alerts"));s.Controls.Add(alertsLine);s.Controls.Add(Buttons(setAlerts,testAlerts,offAlerts));
            // Updates.
            BuildUpdatesPage();
            // More: diagnostics, a note for them, the data folder, and how it works.
            var m=Page("More");
            export=Secondary("Export diagnostics");addNote=Secondary("Add note");openFolder=Secondary("Open data folder");
            m.Controls.Add(Buttons(export,addNote,openFolder));
            m.Controls.Add(Note("Each eBay order goes into a NEW Repair Order in COSTAR Branch 1 (Sydney) open in this session: phone first, PO# = eBay order number, comment EBAY DFE, Ship to = buyer (Ship Via DFE), Rebill to EBAY + Card#, Written By and Salesperson SA, then the lines (item at the eBay price, F, M E, M BUY, M DFE), a final check; then it is left open in COSTAR for you to check and close (the worker says \"ez, next\" and goes on with the next order in a new Repair Order; Settings tab: Close each Repair Order to have them closed instead). An item COSTAR doesn't know: its Quick Item Add is cancelled (never Add item), the rest is entered where it is safe, and the order is left open for you to finish (handed over). It waits while you use this session. Leave COSTAR Sydney on Work-in-Progress."));
            m.Controls.Add(Note("Other COSTARs (other branches) can stay open. With more than one COSTAR Sydney open, the one started first is used and kept while it is open as Sydney; an order typed part-way only ever goes on in its own COSTAR and Repair Order."));
            m.Controls.Add(Note("Minimise or X hides this window: the worker keeps working in the notification area (double-click its icon to open it; right-click it for Exit)."));
            Controls.Add(Tabs);Controls.Add(head);
            toggle.Click+=delegate{Attempt(TrayToggle);};
            checkLayout.Click+=delegate{Attempt(CheckLayout);};
            stopAll.Click+=delegate{StopAll();};
            import.Click+=delegate{Attempt(ImportFile);};
            paste.Click+=delegate{Attempt(PasteConnection);};
            export.Click+=delegate{Attempt(ExportDiagnostics);};
            openFolder.Click+=delegate{Attempt(delegate{Directory.CreateDirectory(AppData.Home);Process.Start("explorer.exe","\""+AppData.Home+"\"");});};
            addNote.Click+=delegate{Attempt(AddNote);};
            setAlerts.Click+=delegate{Attempt(SetDiscordAlerts);};
            testAlerts.Click+=delegate{Attempt(TestDiscordAlerts);};
            offAlerts.Click+=delegate{Attempt(delegate{Alerts.Remove();Append("Discord alerts are off (the webhook was removed from this PC).");Journey.Note("alerts","","","off");ShowAlertsLine();});};
            closeEach.CheckedChanged+=delegate {
                AppSettings.Current.ebayClose=closeEach.Checked;AppSettings.Current.Save();Journey.Note("setting","","","close each Repair Order once it's in: "+(closeEach.Checked?"on":"off"));
                Append(closeEach.Checked?"Each eBay Repair Order is closed once it's in (left open when something needs checking by hand).":"Each eBay order, once verified, is left open in COSTAR for you to check and close (the worker says \"ez, next\").");
            };
            direct.CheckedChanged+=delegate{AppSettings.Current.directPresses=direct.Checked;AppSettings.Current.Save();Direct.On=direct.Checked;Journey.Note("setting","","","direct presses: "+(direct.Checked?"on":"off"));};
            newAccounts.CheckedChanged+=delegate {
                AppSettings.Current.newAccounts=newAccounts.Checked;AppSettings.Current.Save();NewAccount.On=newAccounts.Checked;Journey.Note("setting","","","new buyers' COSTAR accounts: "+(newAccounts.Checked?"on":"off"));
                Append(newAccounts.Checked?"A new buyer gets a COSTAR customer account again.":"New buyers are entered without a COSTAR account, as before 1.1.2.");
            };
            longPoll.CheckedChanged+=delegate{AppSettings.Current.longPoll=longPoll.Checked;AppSettings.Current.Save();Journey.Note("setting","","","long poll: "+(longPoll.Checked?"on":"off"));if(ebay!=null)ebay.Reconnect();};
            autoStart.Checked=AutoStart.On(Product.WorkerMode);
            autoStart.CheckedChanged+=delegate {
                if(syncingAuto) return;
                try { AutoStart.Set(Product.WorkerMode,autoStart.Checked);Journey.Note("autostart","","",autoStart.Checked?"on":"off");Append(autoStart.Checked?"The worker now starts when you sign in to Windows ("+Path.GetFileName(AutoStart.FileFor(Product.WorkerMode))+").":"The worker no longer starts with Windows."); }
                catch(Exception e) { Append("Start with Windows: "+e.Message);syncingAuto=true;try{autoStart.Checked=AutoStart.On(Product.WorkerMode);}finally{syncingAuto=false;} }
            };
            ShowAlertsLine();
        }
        // ---- Start / Pause, Stop all, layout check ----
        protected override string ToggleWords { get { return ebay!=null&&ebay.Enabled?"Pause eBay orders":"Start eBay orders"; } }
        protected override bool ToggleEnabled { get { return ebay!=null; } }
        protected override void TrayToggle() {
            Order.Require(ebay!=null,"The worker has no connection to the receiver yet: Paste connection or Import connection first.");
            if(ebay.Enabled) { ebay.Stop(true);Append("eBay orders paused. Orders sent from the eBay page wait on the receiver until you start again"+(ebay.Busy?" (the order being entered is stopped safely)":"")+"."); }
            else { ebay.Start();Append("eBay orders on: each one goes into a new Repair Order in COSTAR Branch "+ebay.Branch+" (Sydney) as soon as COSTAR is free and nobody is using this session."); }
            UpdateStatus();
        }
        void StopAll() {
            AppLog.Note("stop_pressed","stop all");
            if(ebay!=null&&ebay.Enabled) { ebay.Stop(false);Append("Stop all: eBay orders are paused"+(ebay.Busy?" and the order being entered stops safely":"")+". Click Start eBay orders to go on."); }
            else Append("Stop all: nothing was running.");
            UpdateStatus();
        }
        // On a thread of its own, like an entry (the window stays responsive); one at a time.
        void CheckLayout() {
            Order.Require(ebay!=null,"The worker has no connection to the receiver yet.");
            Order.Require(!checking&&!coordinator.Busy,"Wait for the current entry to finish first.");
            Order.Require(Updates.Now!=EbayAutoUpdater.Stage.Waiting&&Updates.Now!=EbayAutoUpdater.Stage.Switching,"An update is switching over: check the layout once it's done.");
            checking=true;Append("Checking COSTAR Sydney's Repair Order layout (nothing is typed) ...");UpdateStatus();
            var thread=new Thread(delegate() {
                string result;
                try { result=ebay.CheckLayout(); } catch(Exception e) { result="NOT CHECKED: "+e.Message; }
                finally { checking=false; }
                foreach(var line in result.Split('\n')) if(line.Trim().Length>0) Append("Layout: "+line.TrimEnd('\r'));
            });
            thread.IsBackground=true;thread.SetApartmentState(ApartmentState.STA);thread.Start();
        }
        // ---- the connection ----
        void ImportFile() {
            string file;
            using(var pick=new OpenFileDialog {Title="The receiver's worker-connection.json (Export worker connection on Seb's PC)",Filter="Connection file (worker-connection*.json)|worker-connection*.json|JSON files (*.json)|*.json",InitialDirectory=Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)}) {
                ShowFromTray();if(pick.ShowDialog(this)!=DialogResult.OK) return;
                file=pick.FileName;
            }
            Use(Wire.Read<WorkerSettings>(File.ReadAllText(file)),"file");
            if(Ask("Connection imported.\r\n\r\nThe file holds the worker's private key. Delete it now?\r\n\r\n"+file,"Import connection",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button1)==DialogResult.Yes) {
                try { File.Delete(file);Append("Deleted "+file+"."); } catch(Exception e) { Append("Couldn't delete it: "+e.Message); }
            }
        }
        void PasteConnection() {
            string text=Clipboard.ContainsText()?Clipboard.GetText():"";
            Order.Require(text.Trim().StartsWith("{",StringComparison.Ordinal),"The clipboard has no connection. On Seb's PC click Copy connection on the receiver first (Remote Desktop must pass the clipboard over; otherwise use Export worker connection and Import connection).");
            WorkerSettings c;
            try { c=Wire.Read<WorkerSettings>(text); } catch(Exception) { throw new InvalidOperationException("The clipboard doesn't hold a receiver connection (copy it again with Copy connection on the receiver)."); }
            Use(c,"clipboard");
            try { Clipboard.Clear(); } catch(Exception) { }
        }
        // Checked (a private LAN address, a key, the certificate's fingerprint), kept encrypted, used at once.
        // A connection the worker can use: the receiver's private LAN address (never localhost: inside Remote Desktop that is
        // the Remote Desktop server, not Seb's PC), a key, and the receiver's certificate fingerprint.
        void Use(WorkerSettings c,string from) {
            EbayAutoRules.WorkerConnection(c);
            Uri u=new Uri(c.baseUrl);
            PrivateFiles.Save(Path.Combine(folder,"settings.dat"),c);
            // A copy the launcher would import again at the next start (an older one there would undo this).
            string package=AutoStart.PackageFolder(Product.WorkerMode);
            foreach(string old in new[]{Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"worker-connection.json"),package==null?null:Path.Combine(package,"worker-connection.json")}) {
                try { if(old!=null&&File.Exists(old)) { File.Delete(old);Append("Removed an older copy of the connection file: "+old); } } catch(Exception e) { Append("Couldn't remove "+old+": "+e.Message); }
            }
            AppLog.Note("connection_imported",u.Host+":"+u.Port);Journey.Note("connection_imported","","","from the "+from+": receiver "+u.Host+":"+u.Port+" (key not recorded)");
            if(connection!=null&&ebay!=null) {
                connection.baseUrl=c.baseUrl;connection.token=c.token;connection.workerId=c.workerId;connection.certificateHash=c.certificateHash;
                ebay.Reconnect();Append("Connection imported (receiver "+u.Host+":"+u.Port+"). Connecting now.");
            } else {
                connection=c;MakeEngine(c);ebay.Connect();
                Append("Connection imported (receiver "+u.Host+":"+u.Port+"). Connecting now. Click Start eBay orders to take orders.");
            }
            UpdateStatus();
        }
        // ---- Discord ----
        void ShowAlertsLine() { Ui.SetText(alertsLine,Alerts.On?"On. A message goes to your channel when an order stops or needs finishing by hand, the receiver can't be reached for 5 minutes, or COSTAR Sydney isn't open.":"Off. Paste your channel's webhook with Set Discord alerts (it stays on this PC, encrypted, and is never shown again)."); }
        void SetDiscordAlerts() {
            ShowFromTray();
            using(var dialog=new Form {Text="Discord alerts",FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false,MinimizeBox=false,StartPosition=FormStartPosition.CenterParent,ClientSize=new Size(S(560),S(180)),Font=Font,ShowInTaskbar=false}) {
                var note=new Label {AutoSize=false,Location=new Point(S(14),S(12)),Size=new Size(S(530),S(58)),Text="In Discord: the channel's settings, Integrations, Webhooks, New Webhook, Copy Webhook URL. Paste it here. It is kept on this PC only (encrypted) and never shown again."};
                var box=new TextBox {Location=new Point(S(14),S(78)),Width=S(530),UseSystemPasswordChar=true};
                var ok=new Button {Text="Save",Location=new Point(S(364),S(124)),Size=new Size(S(85),S(36)),DialogResult=DialogResult.OK};
                var cancel=new Button {Text="Cancel",Location=new Point(S(459),S(124)),Size=new Size(S(85),S(36)),DialogResult=DialogResult.Cancel};
                dialog.Controls.Add(note);dialog.Controls.Add(box);dialog.Controls.Add(ok);dialog.Controls.Add(cancel);dialog.AcceptButton=ok;dialog.CancelButton=cancel;
                if(dialog.ShowDialog(this)!=DialogResult.OK) return;
                Alerts.Save(box.Text);box.Text="";
            }
            Append("Discord alerts are on.");Journey.Note("alerts","","","on (the webhook is not recorded)");ShowAlertsLine();
            if(Ask("Send a test message to the channel now?","Discord alerts",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button1)==DialogResult.Yes) TestDiscordAlerts();
        }
        void TestDiscordAlerts() {
            Order.Require(Alerts.On,"Discord alerts are off: Set Discord alerts first.");
            Append("Sending a test message to Discord ...");
            ThreadPool.QueueUserWorkItem(delegate {
                string error=Alerts.Test();
                try { BeginInvoke(new Action(delegate{Append(error==null?"Test message sent: check the Discord channel.":"The test message didn't go: "+error+".");})); } catch(InvalidOperationException) { }
            });
        }
        void AddNote() {
            ShowFromTray();
            using(var dialog=new Form {Text="Add a note to the diagnostics",FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false,MinimizeBox=false,StartPosition=FormStartPosition.CenterParent,ClientSize=new Size(S(560),S(160)),Font=Font,ShowInTaskbar=false}) {
                var note=new Label {AutoSize=false,Location=new Point(S(14),S(12)),Size=new Size(S(530),S(40)),Text="What happened (it goes into the diagnostics with the time; no customer details please):"};
                var box=new TextBox {Location=new Point(S(14),S(56)),Width=S(530),MaxLength=300};
                var ok=new Button {Text="Add",Location=new Point(S(364),S(100)),Size=new Size(S(85),S(36)),DialogResult=DialogResult.OK};
                var cancel=new Button {Text="Cancel",Location=new Point(S(459),S(100)),Size=new Size(S(85),S(36)),DialogResult=DialogResult.Cancel};
                dialog.Controls.Add(note);dialog.Controls.Add(box);dialog.Controls.Add(ok);dialog.Controls.Add(cancel);dialog.AcceptButton=ok;dialog.CancelButton=cancel;
                if(dialog.ShowDialog(this)!=DialogResult.OK||box.Text.Trim().Length==0) return;
                Journey.Note("note","","",box.Text.Trim());AppLog.Note("note",box.Text.Trim());Append("Note added to the diagnostics.");
            }
        }
        // ---- the window and the tray ----
        protected override string OtherPartVersion { get { return ebay==null?"":ebay.ReceiverVersion??""; } }
        void UpdateStatus() {
            if(IsDisposed) return;
            Ui.AppendColoured(log,messages.Drain());
            if(ebay==null) {
                Ui.SetChip(chip,"NO CONNECTION",Ui.Danger);Ui.SetText(headline,"Not connected to the receiver yet");
                Ui.SetText(connectionLine,"Not connected yet. On Seb's PC: open the Ebay-auto receiver, click Copy connection; then click Paste connection here (or Export worker connection there and Import connection here).");
                Ui.SetText(targetLine,"");Ui.SetText(jobLine,"");Ui.SetText(detailLine,"");Ui.SetText(heldLine,"");
                toggle.Enabled=false;checkLayout.Enabled=false;SetTray(TrayState.Problem,"no connection: import it");return;
            }
            int since=ebay.SecondsSinceContact;bool inTouch=since>=0&&since<30;
            var t=ebay.Target;string current=ebay.Current,job=ebay.CurrentJob;
            Ui.SetText(connectionLine,ebay.Connection+(since>=0?" ("+(since<=1?"just now":since+" s ago")+(ebay.RoundTripMs>=0?", "+ebay.RoundTripMs+" ms":"")+")":"")+(ebay.ReceiverVersion.Length>0?"  ·  receiver "+ebay.ReceiverVersion:"")+"  ·  "+(ebay.Enabled?"eBay orders ON":"eBay orders PAUSED"));
            string words=ebay.TargetWords;
            Ui.SetText(targetLine,t!=null&&words.Length>0?"Goes into "+words:"COSTAR Branch "+ebay.Branch+" (Sydney): not found in this session yet. Open it here and leave it on Work-in-Progress (other branches can stay open).");
            Ui.SetText(jobLine,current.Length>0?"Entering "+job+": "+current:ebay.LastLine.Length>0?"Last: "+ebay.LastLine:"No eBay order yet.");
            Ui.SetText(detailLine,ebay.ProtocolProblem??ebay.Detail);
            int held=ebay.HeldOpen;
            Ui.SetText(heldLine,held>0?held+" Repair Order(s) handed over for manual completion are still open in COSTAR Sydney (the receiver lists them): new orders never touch them.":"");
            toggle.Text=ebay.Enabled?"Pause eBay orders":"Start eBay orders";
            toggle.Enabled=true;checkLayout.Enabled=!ebay.Busy&&!checking&&!coordinator.Busy;
            bool waiting=ebay.Enabled&&!ebay.Busy&&!ebay.LastAvailable;
            if(!inTouch) { Ui.SetChip(chip,"OUT OF TOUCH",Ui.Danger);Ui.SetText(headline,"Can't reach the receiver on Seb's PC");SetTray(TrayState.Problem,"receiver out of touch"); }
            else if(ebay.ProtocolProblem!=null) { Ui.SetChip(chip,"UPDATE NEEDED",Ui.Danger);Ui.SetText(headline,"The receiver and this worker need the same protocol");SetTray(TrayState.Problem,"versions don't work together"); }
            else if(!ebay.Enabled) { Ui.SetChip(chip,"PAUSED",Ui.Warn);Ui.SetText(headline,"eBay orders are paused (they wait on the receiver)");SetTray(TrayState.Paused,"eBay orders paused"); }
            else if(ebay.Busy) { Ui.SetChip(chip,"ENTERING",Ui.Info);Ui.SetText(headline,"Entering an eBay order ("+job+")");SetTray(TrayState.Working,"entering "+job); }
            else if(ebay.Updating!=null) { Ui.SetChip(chip,"UPDATING",Ui.Info);Ui.SetText(headline,"Updating: new orders wait on the receiver");SetTray(TrayState.Working,"updating"); }
            else if(t==null) { Ui.SetChip(chip,"NO COSTAR",Ui.Warn);Ui.SetText(headline,"Waiting for COSTAR Sydney in this session");SetTray(TrayState.Attention,"COSTAR Sydney not found"); }
            else if(waiting) { Ui.SetChip(chip,"WAITING",Ui.Warn);Ui.SetText(headline,"Ready, waiting: "+Shorten(ebay.Detail,70));SetTray(TrayState.Attention,"waiting: "+ebay.Detail); }
            else { Ui.SetChip(chip,"READY",Ui.Success);Ui.SetText(headline,"Ready for the next eBay order");SetTray(TrayState.Ready,held>0?"ready ("+held+" handed over, open)":"ready"); }
        }
        static string Shorten(string s,int n) { s=s??"";return s.Length<=n?s:s.Substring(0,n-1)+"…"; }
        void Tick() {
            ticks++;
            if(ticks%5==0) { Alerts.Tick();PerfMonitor.Sample(); }
            if(ticks%30==0&&ebay!=null) { try { ebay.CheckHeld(); } catch(Exception) { } WatchForAlerts(DateTime.Now); }
            // 1.1.0: older builds of this program (from updates) are tidied away once, ten minutes after starting.
            if(ticks==600) TidyRuntimes();
        }
        // In shop hours only (as the RDP helper): the receiver out of touch for 5 minutes, COSTAR Sydney missing for 5.
        void WatchForAlerts(DateTime now) {
            if(!TempeOrderCheck.Text.InShopHours(now)) { noCostarSince=DateTime.MinValue;return; }
            int since=ebay.SecondsSinceContact;
            bool down=since>300||(since<0&&now-startedAt>TimeSpan.FromMinutes(5));
            if(down&&!receiverDownSaid) receiverDownSaid=Alerts.Raise("receiver_down","The Ebay-auto worker can't reach the receiver on Seb's PC (eBay orders wait there)",ebay.Connection);
            else if(!down&&since>=0&&since<60&&receiverDownSaid&&Alerts.Raise("receiver_back","The Ebay-auto worker reaches the receiver again","")) receiverDownSaid=false;
            if(ebay.Enabled&&ebay.Target==null) {
                if(noCostarSince==DateTime.MinValue) noCostarSince=now;
                else if(now-noCostarSince>TimeSpan.FromMinutes(5)&&!noCostarSaid) noCostarSaid=Alerts.Raise("no_costar_sydney","COSTAR Sydney isn't open in the Ebay-auto worker's Remote Desktop session",ebay.Detail+". eBay orders wait on the receiver.");
            } else {
                noCostarSince=DateTime.MinValue;
                if(noCostarSaid&&ebay.Target!=null&&Alerts.Raise("costar_sydney_back","COSTAR Sydney is open again for the Ebay-auto worker","")) noCostarSaid=false;
            }
        }
        // ---- diagnostics ----
        protected override void ExportDiagnostics() {
            Order.Require(!exporting,"Diagnostics are being put together already.");
            exporting=true;export.Enabled=false;export.Text="Putting it together ...";
            var engine=ebay;
            var thread=new Thread(delegate() {
                string path=null,error=null,note=null;
                try { path=EbayAutoDiagnostics.Save(Product.WorkerMode,EbayAutoDiagnostics.WorkerZip(engine,true,out note)); }
                catch(Exception e) { error=e.Message; }
                try {
                    BeginInvoke(new Action(delegate {
                        exporting=false;export.Enabled=true;export.Text="Export diagnostics";
                        if(error!=null) { Tell("Diagnostics could not be saved: "+error);return; }
                        Process.Start("explorer.exe","/select,\""+path+"\"");
                        Tell("Saved "+Path.GetFileName(path)+(note==null?" (with the receiver's logs).":".\r\n\r\nThe receiver's logs are NOT in it: "+note+". Export diagnostics on the receiver too (Seb's PC)."));
                    }));
                } catch(InvalidOperationException) { }
            });
            thread.IsBackground=true;thread.Start();
        }
        // ---- exit ----
        protected override bool ConfirmExit() {
            if(exitAfterStop) return true;
            if(ebay!=null&&ebay.Busy) {
                if(Ask("An eBay order is being entered right now.\r\n\r\nStop it safely and exit? It stops at a safe point (recorded, so Retry or Start again can deal with it on the receiver).","Exit "+Product.Name,MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2)!=DialogResult.Yes) return false;
                ebay.Stop(false);exitAfterStop=true;exitWaited=0;exitWait.Start();Append("Stopping the order being entered safely, then exiting ...");
                return false;
            }
            return Ask("Exit the Ebay-auto worker?\r\n\r\neBay orders wait on the receiver until it is started again (Start-Worker.cmd in this session, or sign in again if it starts with Windows).","Exit "+Product.Name,MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button2)==DialogResult.Yes;
        }
        protected override void Shutdown(string why) {
            Journey.Note("app_exit",ebay==null?"":ebay.CurrentJob,"",why+(ebay==null?": no connection":": eBay orders "+(ebay.Enabled?"on":"paused")+(ebay.Busy?", an order was being entered (stopped; it is reported when the worker starts again)":", nothing being entered")+", "+ebay.HeldOpen+" handed-over Repair Order(s) open"));
            timer.Stop();if(ebay!=null) ebay.Dispose();
        }
        // ---- the update's hooks ----
        // The switch waits until no order is being entered (never cut across), the layout check is done, and the receiver
        // has been told to hold new orders (its next poll), or it can't be reached (then it hands out nothing anyway).
        protected override string UpdateNotSafe() {
            if(checking) return "the layout check is running";
            if(exporting) return "diagnostics are being put together";
            if(coordinator.Busy) return (coordinator.Owner.Length>0?coordinator.Owner:"an entry")+" is using COSTAR";
            if(ebay==null) return null;
            if(ebay.Busy) return "an eBay order is being entered";
            if(holdSince==DateTime.MinValue) holdSince=DateTime.UtcNow;
            bool inTouch=ebay.SecondsSinceContact>=0&&ebay.SecondsSinceContact<30;
            if(!ebay.UpdateHeld&&inTouch&&DateTime.UtcNow-holdSince<TimeSpan.FromSeconds(20)) return "telling the receiver to hold new orders";
            return null;
        }
        protected override void UpdateHold() { var e=ebay;var r=Updates.Release;if(e!=null) e.Updating="Updating the Ebay-auto worker to "+(r==null?"a new version":r.version)+": new orders wait on the receiver (back in about a minute)."; }
        protected override void UpdateUnhold() { var e=ebay;if(e!=null) e.Updating=null;holdSince=DateTime.MinValue; }
        protected override EbayResumeState UpdateResume() { return new EbayResumeState {enabled=ebay!=null&&ebay.Enabled}; }
        protected override void UpdateStop() {
            Journey.Note("app_exit",ebay==null?"":ebay.CurrentJob,"","update: eBay orders "+(ebay!=null&&ebay.Enabled?"on":"paused")+", nothing being entered, "+(ebay==null?0:ebay.HeldOpen)+" handed-over Repair Order(s) open (all kept in the journal)");
            timer.Stop();if(hotkey) { Native.UnregisterHotKey(Handle,1);hotkey=false; }
            if(ebay!=null) ebay.Dispose();
        }
    }
}
