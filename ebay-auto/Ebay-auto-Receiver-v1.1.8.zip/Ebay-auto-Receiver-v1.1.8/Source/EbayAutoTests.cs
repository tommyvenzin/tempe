// Ebay-auto 1.0.0-1.1.1 self-tests: its own identity (folders, names, ports, its own update folder), the receiver that serves the eBay
// routes only, the queue's job ids and the handed-over state, the worker's refusals, the Quick Item Add rules and the
// hand-over words, the partial line check, the request ids, and the diagnostics (outcome counts, nothing of the buyer, the
// other part's logs said when missing). Source-level only: nothing here opens, clicks or types into COSTAR, and every
// order, buyer, phone and address is made up.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace TempeCostar {
    internal static class EbayAutoTests {
        static void Check(bool value,string message){if(!value)throw new InvalidOperationException(message);}
        static void Reject(Action action,string message){bool rejected=false;try{action();}catch(InvalidOperationException){rejected=true;}Check(rejected,message);}
        static readonly Regex JobForm=new Regex("^J-[BCDFGHJKLMNPQRSTVWXZ]{6}$"),AttemptForm=new Regex("^A-[BCDFGHJKLMNPQRSTVWXZ]{6}$");
        // Made-up buyer details: none of them may appear in anything the diagnostics keep.
        const string Buyer="Zelda Quokkafield",Phone="0499 111 222",Email="zq.test@example.invalid",Street="9 IMAGINARY LANE",Suburb="NOWHERESVILLE",User="quokka_buyer9";
        static EbayOrder Order2(string number="22-22222-22222") {
            var o=EbayTests.Sample(number);
            o.buyer=new EbayBuyer {name=Buyer,phone=Phone,email=Email,username=User};
            o.phones=new EbayPhones {contact=Phone,shipping="0488 333 444"};
            o.address=new EbayAddress {recipientName=Buyer,street=Street,street2="",suburb=Suburb,state="NSW",postcode="2799"};
            o.items=new List<EbayItem> {new EbayItem {sku="W43116X",itemId="111111111111",title="",quantity=4,unitCents=14000},new EbayItem {sku="T12345",itemId="222222222222",title="",quantity=1,unitCents=5000}};
            o.freightCents=1000;o.totalCents=4*14000+5000+1000;
            return o;
        }
        static ReceiverSettings Settings() { return new ReceiverSettings {address="10.9.8.7",port=Product.ReceiverPort,trustPort=Product.TrustPort,workerToken=new string('w',43),workerId="test-worker",ebayToken=new string('e',43),phoneToken=new string('p',43),webUrl=""}; }
        static HttpOutput Call(ReceiverApi api,string method,string path,string token,object body=null,string origin=null,Dictionary<string,string> extra=null) {
            var r=EbayTests.Request(method,path,token,origin,body);r.headers["host"]=api.Settings.address+":"+api.Settings.port;
            if(extra!=null) foreach(var kv in extra) r.headers[kv.Key]=kv.Value;
            return api.Handle(r);
        }
        static string Text(byte[] zip) {
            var b=new StringBuilder();
            using(var archive=new ZipArchive(new MemoryStream(zip),ZipArchiveMode.Read))
                foreach(var e in archive.Entries) {
                    b.Append("== ").Append(e.FullName).Append('\n');
                    using(var s=e.Open()) using(var m=new MemoryStream()) { s.CopyTo(m);byte[] bytes=m.ToArray();if(e.FullName.EndsWith(".zip",StringComparison.Ordinal)) b.Append(Text(bytes)); else b.Append(Encoding.UTF8.GetString(bytes)); }
                    b.Append('\n');
                }
            return b.ToString();
        }
        static void NoBuyer(string text,string what) {
            foreach(var x in new[]{Buyer,Phone,"0499111222","0488 333 444","0488333444",Email,Street,Suburb,User,"22-22222-22222",new string('w',43),new string('e',43),new string('p',43)})
                Check(text.IndexOf(x,StringComparison.OrdinalIgnoreCase)<0,what+" holds "+(x.Length>12?x.Substring(0,6)+"...":x));
        }
        static EbayReport Report(EbayReply claim,string status,int sequence,bool typed=false,string message=null,string remaining=null) {
            return new EbayReport {orderNumber=claim.order.orderNumber,lease=claim.lease,status=status,message=message??status,progress="",sequence=sequence,typed=typed,jobId=claim.jobId,attemptId=claim.attemptId,remaining=remaining};
        }
        static EbayHello Hello(EbayReport report=null,string working="",int sequence=1000) { return new EbayHello {workerId="test-worker",accepting=true,available=true,report=report,working=working,sequence=sequence,version=AutofillForm.Version}; }
        internal static void Cases(Action<string,Action> Case) {
            Case("Ebay-auto 1.1.8: its own folder, single-instance names, Startup files, diagnostics names and ports, never the Tempe helper's",()=>{
                Check(Product.Name=="Ebay-auto"&&Product.Version=="1.1.8"&&Product.Based=="2.9.14","Name and version.");
                Check(Path.GetFileName(Product.Home)=="EbayAuto"&&Product.Home.IndexOf("TempeMobileCostar",StringComparison.OrdinalIgnoreCase)<0&&Product.Home.IndexOf("TempeCostarAutofill",StringComparison.OrdinalIgnoreCase)<0,"Its own data folder.");
                Check(AppData.Home==Product.Home&&PrivateFiles.Home==Product.Home&&Updater.Home==Product.Home&&AppData.Diagnostics.StartsWith(Product.Home,StringComparison.OrdinalIgnoreCase)&&AppData.Reports.StartsWith(Product.Home,StringComparison.OrdinalIgnoreCase),"Settings, keys, queue, journal, logs and reports all under Ebay-auto's folder.");
                Check(Product.MutexPrefix.StartsWith(@"Global\EbayAuto_",StringComparison.Ordinal)&&!Product.MutexPrefix.Contains("TempeMobile"),"Its own single-instance names.");
                Check(Product.ShowEventName(Product.ReceiverMode)!=Product.ShowEventName(Product.WorkerMode)&&Product.ShowEventName(Product.WorkerMode).StartsWith(@"Local\EbayAuto_",StringComparison.Ordinal),"Each part its own show signal.");
                var tempe=new[]{8790,8791}.Concat(Enumerable.Range(8795,10)).ToList();
                Check(!tempe.Contains(Product.ReceiverPort)&&!tempe.Contains(Product.TrustPort)&&Product.TrustPort==Product.ReceiverPort+1,"Ports away from the Tempe desk (8790/8791) and Order Check (8795-8804); the certificate port is the next one.");
                Check(Updater.Current==new Version(1,1,8)&&EbayAutoUpdate.Current==new Version(1,1,8)&&AutofillForm.Version.StartsWith("1.1.8 - Ebay-auto",StringComparison.Ordinal),"Its own version (the update identity).");
                Check(Product.PackageName(Product.WorkerMode,new Version(1,2,3))=="Ebay-auto-Worker-v1.2.3"&&Product.Starter(Product.ReceiverMode)=="Start-Receiver.cmd"&&Product.ReadyEventName(Product.WorkerMode).StartsWith(@"Local\EbayAuto_",StringComparison.Ordinal),"Its own package names, launchers and update signal.");
                Check(Regex.IsMatch(Product.DiagnosticsPrefix+"Worker-Diagnostics-20261116-101010.zip","^"+Product.DiagnosticsPattern.Replace(".","\\.").Replace("*",".*")+"$")&&!Regex.IsMatch("Tempe-COSTAR-Diagnostics-20261116-101010.zip","^"+Product.DiagnosticsPattern.Replace(".","\\.").Replace("*",".*")+"$"),"Its own diagnostics ZIP names.");
                Check(CostarInputLock.Name==@"Local\TempeCostarAutofill_v01","The input lock is the Tempe helper's on purpose: the two never type into COSTAR at once in one session.");
                Check(EbayAutoRules.ReceiverSetup("192.168.5.20","8811")==8811,"A LAN address and its own port.");
                Reject(()=>EbayAutoRules.ReceiverSetup("127.0.0.1","8811"),"Never 127.0.0.1 (inside Remote Desktop that is the server, not Seb's PC).");
                Reject(()=>EbayAutoRules.ReceiverSetup("8.8.8.8","8811"),"Never a public address.");
                Reject(()=>EbayAutoRules.ReceiverSetup("192.168.5.20","8790"),"Never the Tempe desk's port.");
                Reject(()=>EbayAutoRules.ReceiverSetup("192.168.5.20","8794"),"Never a port whose certificate port is Order Check's.");
                string hash=new string('a',64);
                EbayAutoRules.WorkerConnection(new WorkerSettings {baseUrl="https://192.168.5.20:8811/",token=new string('w',40),workerId="x",certificateHash=hash});
                Reject(()=>EbayAutoRules.WorkerConnection(new WorkerSettings {baseUrl="https://127.0.0.1:8811/",token=new string('w',40),workerId="x",certificateHash=hash}),"The worker never takes localhost for Seb's PC.");
                Reject(()=>EbayAutoRules.WorkerConnection(new WorkerSettings {baseUrl="https://localhost:8811/",token=new string('w',40),workerId="x",certificateHash=hash}),"Nor by its name.");
                Reject(()=>EbayAutoRules.WorkerConnection(new WorkerSettings {baseUrl="https://192.168.5.20:8811/",token="short",workerId="x",certificateHash=hash}),"An incomplete connection is refused.");
            });
            Case("Ebay-auto receiver: the eBay routes only (no phone jobs, website or Repair Orders), each with its own key",()=>{
                var api=new ReceiverApi(Settings());var q=new EbayQueue(null,s=>{});api.UseEbay(q);
                Check(api.EbayOnly,"An eBay-only receiver.");
                foreach(var path in new[]{"/","/Fitment_Planner.html","/api/mobile/v1/health","/api/mobile/v1/jobs","/api/worker/v1/poll","/api/worker/v1/ro","/api/mobile/v1/ro/list"})
                    Check(Call(api,"GET",path,new string('p',43)).status==404&&Call(api,"GET",path,new string('w',43)).status==404,"Not served here: "+path);
                Check(Call(api,"GET","/api/ebay/v1/health",new string('e',43),null,EbayTests.Extension).status==200,"eBay health with the eBay key.");
                Check(Call(api,"GET","/api/ebay/v1/health",new string('w',43),null,EbayTests.Extension).status==401,"Not with the worker's key.");
                Check(Call(api,"GET","/api/ebay/v1/health",new string('e',43),null,"https://evil.example").status==403,"Only the extension's own pages (or no browser) may ask.");
                var poll=Call(api,"POST","/api/worker/v1/ebay",new string('w',43),Hello());
                Check(poll.status==200&&Call(api,"POST","/api/worker/v1/ebay",new string('e',43),Hello()).status==401,"The worker's poll with the worker key only.");
                var health=EbayTests.Body<Dictionary<string,object>>(Call(api,"GET","/api/ebay/v1/health",new string('e',43),null,EbayTests.Extension));
                Check((string)health["product"]=="Ebay-auto"&&(bool)health["helperConnected"],"Health says Ebay-auto, with the worker in touch.");
                api.Receiving=false;
                string w=api.EbayWaiting;Check(w.Contains("paused")&&w.IndexOf("Tommy",StringComparison.OrdinalIgnoreCase)<0&&w.IndexOf("desk",StringComparison.OrdinalIgnoreCase)<0,"Its own words: never Tommy's desk PC.");
                Check(Call(api,"POST","/api/ebay/v1/orders",new string('e',43),Order2(),EbayTests.Extension).status==400,"Paused: a new order is refused (and told why).");
                Check(api.HugeBody(ReceiverApi.EbayDiagnosticsPath,new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase){{"authorization","Bearer "+new string('w',43)}})&&
                    !api.HugeBody(ReceiverApi.EbayDiagnosticsPath,new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase){{"authorization","Bearer "+new string('e',43)}})&&
                    !api.HugeBody("/api/worker/v1/ebay",new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase){{"authorization","Bearer "+new string('w',43)}}),"Only the worker's diagnostics upload may be large.");
            });
            Case("Ebay-auto queue: a job id for good, an attempt id per claim, request ids kept, duplicate sends noted, nothing of the buyer in the notes",()=>{
                var notes=new List<string[]>();
                var api=new ReceiverApi(Settings());var q=new EbayQueue(null,s=>{});api.UseEbay(q);
                q.Noted=delegate(string kind,string job,string attempt,string detail){notes.Add(new[]{kind,job,attempt,detail});};
                var first=EbayTests.Body<EbayStatus>(Call(api,"POST","/api/ebay/v1/orders",new string('e',43),Order2(),EbayTests.Extension,new Dictionary<string,string>{{"x-request-id","R-BCDFGH"}}));
                Check(JobForm.IsMatch(first.jobId??""),"A job id: J- and six consonants.");
                var again=EbayTests.Body<EbayStatus>(Call(api,"POST","/api/ebay/v1/orders",new string('e',43),Order2(),EbayTests.Extension,new Dictionary<string,string>{{"x-request-id","R-KLMNPQ"}}));
                Check(again.jobId==first.jobId&&q.List().Count==1&&q.Waiting==1,"Send twice: the same order, nothing new queued.");
                Check(notes.Any(n=>n[0]=="received"&&n[1]==first.jobId&&n[3].Contains("R-BCDFGH")&&n[3].Contains("W43116X x4"))&&notes.Any(n=>n[0]=="duplicate_send"&&n[3].Contains("R-KLMNPQ")),"Received and the duplicate send are noted, each with its request id.");
                Check(ReceiverApi.ValidId("R-BCDFGH","R")!=null&&ReceiverApi.ValidId("R-ABCDEF","R")==null&&ReceiverApi.ValidId("R-bcdfgh","R")==null&&ReceiverApi.ValidId("J-BCDFGH","R")==null&&ReceiverApi.ValidId("R-BCDFGHJ","R")==null,"Only well-formed ids are kept.");
                var bad=Call(api,"POST","/api/ebay/v1/orders",new string('e',43),Order2(),EbayTests.Extension,new Dictionary<string,string>{{"x-request-id","<script>"}});
                Check(bad.status==200&&!notes.Any(n=>n[3].Contains("<script>")),"A malformed request id is ignored.");
                var claim=q.Poll(Hello());
                Check(claim.command=="enter"&&claim.jobId==first.jobId&&AttemptForm.IsMatch(claim.attemptId??""),"The claim carries the job and its own attempt id.");
                q.Poll(Hello(Report(claim,"entering",1001),claim.lease,1001));
                Check(notes.Any(n=>n[0]=="claimed"&&n[2]==claim.attemptId)&&notes.Any(n=>n[0]=="started"&&n[1]==first.jobId),"Claimed and started are noted with both ids.");
                q.Poll(Hello(Report(claim,"ready_for_review",1002,true,"In COSTAR Branch 1 (Sydney), entered and closed (it's in Work-in-Progress). CHECK BY HAND: COSTAR didn't close the Repair Order."),"",1002));
                Check(EbayQueue.Category(q.List()[0])=="check_by_hand"&&notes.Any(n=>n[0]=="completed"&&n[3].StartsWith("check_by_hand",StringComparison.Ordinal)),"CHECK BY HAND is never counted as completed without help.");
                foreach(var n in notes) NoBuyer(String.Join(" ",n),"A note");
                // Another order, entered and verified.
                q.Submit(Order2("33-33333-33333"));var c2=q.Poll(Hello());
                Check(c2.jobId!=first.jobId&&c2.attemptId!=claim.attemptId,"Each order its own job id, each claim its own attempt id.");
                q.Poll(Hello(Report(c2,"ready_for_review",1003,true,"In COSTAR Branch 1 (Sydney), entered and closed (it's in Work-in-Progress)."),"",1003));
                Check(EbayQueue.Category(q.List().First(r=>r.jobId==c2.jobId))=="verified","Entered and closed, nothing by hand: verified.");
                Reject(()=>q.MarkDone("22-22222-22222",true),"A finished order can't be marked done again.");
                var third=q.Submit(Order2("55-55555-55555"));q.MarkDone("55-55555-55555",true);
                Check(EbayQueue.Category(q.List().First(r=>r.jobId==third.jobId))=="marked_done"&&notes.Any(n=>n[0]=="mark_done"&&n[1]==third.jobId),"Marked done by hand is its own kind, and noted.");
                var kept=new EbayQueue(Wire.Copy(new EbayState {orders=new List<EbayReceipt>{new EbayReceipt {order=Order2("44-44444-44444"),status="queued",hash="h",receivedUtc="2026-11-16T00:00:00.0000000Z"}}}),s=>{});
                Check(JobForm.IsMatch(kept.List()[0].jobId??""),"A receipt kept without a job id gets one.");
            });
            Case("Ebay-auto queue: handed over: never retried (not by Retry, Send again or by itself), never hidden as finished; Start again, Mark done and Remove stay",()=>{
                var notes=new List<string>();var q=new EbayQueue(null,s=>{});q.Noted=delegate(string kind,string job,string attempt,string detail){notes.Add(kind);};
                q.Submit(Order2());var claim=q.Poll(Hello());
                q.Poll(Hello(Report(claim,"entering",1001,true),claim.lease,1001));
                q.Poll(Hello(Report(claim,"handed_over",1002,true,"NEEDS MANUAL COMPLETION in COSTAR Sydney ...","W43116X x4 $140.00 (line 1: not a COSTAR item); check the total $620.00; close it"),"",1002));
                var r=q.List()[0];
                Check(r.status=="handed_over"&&r.typed&&r.remaining.Contains("W43116X")&&r.handedOverUtc!=null&&EbayQueue.Category(r)=="handed_over","Handed over, with what is left.");
                var s1=q.Get("22-22222-22222");Check(s1.remaining.Contains("W43116X")&&s1.jobId==r.jobId,"The status says what is left (the extension shows it).");
                Check(q.Retry("22-22222-22222","the extension").status=="handed_over"&&notes.Contains("retry_refused"),"Retry and Send again leave it as it is.");
                Check(!EbayQueue.AutoRetryDue(q.List()[0],DateTime.UtcNow.AddMinutes(2)),"Never retried by itself.");
                q.HideFinished();Check(!q.List()[0].hidden,"Hide finished never hides an order that needs Seb.");
                Reject(()=>q.Hide("22-22222-22222"),"It can't be hidden as finished.");
                Check(q.Waiting==0&&q.Poll(Hello()).command=="wait","Released: it isn't waiting, and nothing more is handed out for it.");
                Check(q.Submit(Order2()).status=="handed_over","Sent again with the same details: the same order, as it is.");
                var changed=Order2();changed.items[1].quantity=2;changed.totalCents+=5000;
                Reject(()=>q.Submit(changed),"Sent again with other details: refused (CONFLICT).");
                var copy=Wire.Copy(q.List()[0]);
                var a=new EbayQueue(new EbayState {orders=new List<EbayReceipt>{Wire.Copy(copy)}},s=>{});
                Check(a.StartAgain("22-22222-22222").status=="queued"&&a.List()[0].fresh&&a.List()[0].startAgain&&a.List()[0].remaining==null,"Start again: a new Repair Order.");
                var b=new EbayQueue(new EbayState {orders=new List<EbayReceipt>{Wire.Copy(copy)}},s=>{});
                Check(b.MarkDone("22-22222-22222",true).status=="ready_for_review"&&b.List()[0].markedDone,"Mark done by hand.");
                var c=new EbayQueue(new EbayState {orders=new List<EbayReceipt>{Wire.Copy(copy)}},s=>{});
                var sameOrder=Order2();
                Check(c.List()[0].hash==sameOrder.ContentHash(),"Receipt copy changed its content: "+Wire.Json(c.List()[0].order)+" versus "+Wire.Json(sameOrder));
                Check(c.Remove("22-22222-22222",true).status=="removed","Remove.");
                // Removed and sent again: the worker refuses it (handed over before); a report without what is left keeps
                // what the receiver had.
                Check(c.Submit(sameOrder).status=="queued","Sent again after Remove: queued (typed before: never a new Repair Order).");
                var back=c.Poll(Hello());Check(back.command=="enter"&&!back.fresh,"Handed to the worker, which refuses it.");
                c.Poll(Hello(Report(back,"handed_over",1,true,"Not entered again: handed over before.",null),"",1));
                Check(c.List()[0].status=="handed_over"&&c.List()[0].remaining.Contains("W43116X"),"Handed over again, still saying what is left.");
            });
            Case("Ebay-auto worker: a handed-over order is never entered again (unless Start again), an attempt with an unknown item is never continued",()=>{
                string n="22-22222-22222";
                Check(EbayAttempts.Refusal(n,false,false,true,null,null,"Mon 16 Nov, 10:00").StartsWith("Not entered again",StringComparison.Ordinal),"Handed over before: refused (also after Remove and Send again).");
                Check(EbayAttempts.Refusal(n,true,false,false,null,null,"Mon 16 Nov, 10:00")!=null,"Sent as new after Remove: refused too.");
                Check(EbayAttempts.Refusal(n,true,true,true,null,null,"Mon 16 Nov, 10:00")==null,"Start again (a person checked COSTAR) is never refused.");
                var j=new EbayJournal();j.handedOver.Add(n+"|2026-11-16T00:00:00.0000000Z|J-BCDFGH");
                Check(EbayAttempts.HandedOver(j,n)=="2026-11-16T00:00:00.0000000Z"&&EbayAttempts.HandedOver(j,"22-22222-2222")==null&&EbayAttempts.HandedOver(null,n)==null,"Found by its exact number.");
                var a=new EbayAttempt {orderNumber=n,typed=true,stopPrint="x",unknown=true,unresolved="item W43116X (line 1)"};string why;
                Check(EbayAttempts.Decide(a,false,true,out why)==EbayAttempts.Refuse&&why.Contains("Mark done by hand")&&why.Contains("Start again"),"An attempt that left an item for Seb is never continued.");
                Check(EbayAttempts.Decide(a,true,true,out why)==EbayAttempts.Fresh,"Start again starts fresh.");
                var copy=Wire.Copy(new EbayJournal {handedOver=new List<string>{n+"|t|J-BCDFGH"},held=new List<EbayHeldRo>{new EbayHeldRo {jobId="J-BCDFGH",window=1234,processId=5}}});
                Check(copy.handedOver.Count==1&&copy.held[0].window==1234,"The hand-overs survive the journal's JSON.");
            });
            Case("Ebay-auto: Quick Item Add is recognised only by its title, owned by this order's Repair Order, one usable Cancel and one Add item",()=>{
                // The buttons of the 5 Nov capture.
                var seen=new List<string>{"Selling Prices","NonStocking?   ","Serialized?","Add item","Cancel"};
                Check(EbayHandoff.LooksLikeQuickItemAdd("Quick Item Add",true,seen,true),"The window of the 5 Nov capture.");
                Check(!EbayHandoff.LooksLikeQuickItemAdd("Quick Item Add",false,seen,true),"Never one owned by another Repair Order (or nobody's).");
                Check(EbayHandoff.LooksLikeQuickItemAdd(" Quick Item Add ",true,seen,true)&&!EbayHandoff.LooksLikeQuickItemAdd("Customer Not found",true,seen,true)&&!EbayHandoff.LooksLikeQuickItemAdd("Quick Item",true,seen,true)&&!EbayHandoff.LooksLikeQuickItemAdd("quick item add",true,seen,true),"Its title exactly (spaces aside).");
                Check(!EbayHandoff.LooksLikeQuickItemAdd("Quick Item Add",true,new List<string>{"Add item"},true),"Without Cancel: nothing to press.");
                Check(!EbayHandoff.LooksLikeQuickItemAdd("Quick Item Add",true,new List<string>{"Cancel"},true),"Without Add item: not the window it is taken for.");
                Check(!EbayHandoff.LooksLikeQuickItemAdd("Quick Item Add",true,new List<string>{"Add item","Cancel","&Cancel"},true),"Two Cancels: not guessed.");
                Check(!EbayHandoff.LooksLikeQuickItemAdd("Quick Item Add",true,seen,false),"A Cancel that can't be used is never pressed.");
                Check(EbayHandoff.LooksLikeQuickItemAdd("Quick Item Add",true,new List<string>{"&Add item","&Cancel"},true),"Accelerator marks are ignored.");
                // Whose code it asks about.
                Check(EbayHandoff.Whose(true,null,"W43116X")=="this"&&EbayHandoff.Whose(true,"W43116X","W43116X")=="this","This line's code went in: it is this line's item.");
                Check(EbayHandoff.Whose(true,"T12345","W43116X")=="earlier"&&EbayHandoff.Whose(false,null,"T12345")=="earlier"&&EbayHandoff.Whose(false,"T12345","T12345")=="earlier","Before this line's code went in, or about another code: the earlier one asked again (entry stops there).");
            });
            Case("Ebay-auto hand-over words: what is left, where it stopped, never the buyer, never \"entered and verified\"",()=>{
                var o=Order2();var plan=o.Plan();
                Check(plan.Select(l=>l.Code).SequenceEqual(new[]{"W43116X","T12345","F","M E","M E","M BUY","M DFE"}),"The plan of the made-up order.");
                var u=new EbayUnresolved {Line=1,Kind="product",Label=plan[0].Label,Sku="W43116X",Attempted="W43116X",Quantity=4,UnitCents=14000,Position=1,Count=2,Cancelled=true,Action="Cancel pressed; the window closed after 120 ms",After="line 1 still shows W43116X (no description, no quantity, no price)"};
                var unresolved=new List<EbayUnresolved>{u};
                string message,remaining;
                var done=new HashSet<int>(plan.Select(l=>l.Line));
                EbayHandoff.Words(plan,done,unresolved,null,null,"Checked: customer, PO#, comment, Ship to, Written By/Salesperson and the 6 entered line(s). COSTAR's total $60.00 is the eBay total $620.00 less the unresolved $560.00.",new List<string>(),o.totalCents,out message,out remaining);
                Check(message.StartsWith("NEEDS MANUAL COMPLETION",StringComparison.Ordinal)&&message.Contains("item W43116X x4 at $140.00 each (line 1)")&&message.Contains("cancelled, so nothing was added")&&message.Contains("still shows W43116X")&&message.Contains("Everything else is entered")&&message.Contains("Mark done by hand"),"All lines tried: what was left and what is on its line.");
                Check(message.IndexOf("verified",StringComparison.OrdinalIgnoreCase)<0&&message.IndexOf("ready for review",StringComparison.OrdinalIgnoreCase)<0,"Never reported as entered and verified.");
                Check(remaining.Contains("W43116X x4 $140.00 (line 1: not a COSTAR item)")&&remaining.Contains("check the total $620.00")&&remaining.Contains("close it"),"In short: "+remaining);
                var part=new HashSet<int>{1,3};
                EbayHandoff.Words(plan,part,unresolved,"freight $10.00 (F)","COSTAR asked about W43116X again when the helper moved on",null,new List<string>{"Terms shows NET, not 7INV."},o.totalCents,out message,out remaining);
                Check(message.Contains("Entry then stopped at freight $10.00 (F): COSTAR asked about W43116X again")&&message.Contains("Still to enter by hand: freight $10.00 (F), M E (eBay item 111111111111), M E (eBay item 222222222222), M BUY (the buyer's eBay username), M DFE")&&message.Contains("were not checked")&&message.Contains("CHECK BY HAND: Terms"),"Stopped part way: exactly where, and what is still to do: "+message);
                Check(remaining.Contains("stopped at freight")&&remaining.Contains("to enter: F $10.00, M E, M E, M BUY, M DFE"),"In short, stopped: "+remaining);
                NoBuyer(message+remaining,"The hand-over words");
                var notCancelled=new EbayUnresolved {Line=1,Kind="product",Sku="W43116X",Attempted="W43116X",Quantity=4,UnitCents=14000,Cancelled=false};
                Check(notCancelled.Text.Contains("left open over the Repair Order (nothing in it was pressed)"),"A Quick Item Add that couldn't be cancelled is said to be still open.");
                Check(u.Record.Contains("sku=W43116X")&&u.Record.Contains("item=1/2")&&u.Record.Contains("line=1")&&u.Record.Contains("qty=4")&&u.Record.Contains("action=Cancel pressed"),"The record for the diagnostics: "+u.Record);
            });
            Case("Ebay-auto partial line check: unresolved lines are looked at, never checked; every other line is checked as before; nothing extra",()=>{
                var o=EbayTests.Sample();o.buyer.username="TESTBUYER1";
                o.items.Add(new EbayItem {sku="T12345",itemId="333333333333",title="",quantity=2,unitCents=5000});o.totalCents+=10000;
                var plan=o.Plan();   // W43116 1, T12345 3, F 5, M E 7, M E 9, M BUY 11, M DFE 13
                var g=new Dictionary<int,string[]> {
                    {1,new[]{"W43116","","",""}},{3,new[]{"T12345","SOME TYRE","2","50.00"}},{5,new[]{"F","Freight","1","10.00"}},
                    {7,new[]{"M E","EBAY ITEM # 175288170173","",""}},{9,new[]{"M E","EBAY ITEM # 333333333333","",""}},{11,new[]{"M BUY","EBAY BUYER NAME: TESTBUYER1","",""}},{13,new[]{"M DFE","COSTAR'S OWN TEXT","",""}}};
                var notes=new List<string>();
                EbayCheck.Lines(EbayTests.Grid(g),plan,true,new HashSet<int>{1},notes);
                Check(notes.Count==1&&notes[0]=="line 1 shows W43116 (unresolved)","The unresolved line is described.");
                Reject(()=>EbayCheck.Lines(EbayTests.Grid(g),plan,true),"The full check still fails an order with an item missing.");
                var wrong=new Dictionary<int,string[]>(g);wrong[3]=new[]{"T12345","SOME TYRE","2","55.00"};
                Reject(()=>EbayCheck.Lines(EbayTests.Grid(wrong),plan,true,new HashSet<int>{1},new List<string>()),"A wrong price on another line still fails.");
                var extra=new Dictionary<int,string[]>(g);extra[2]=new[]{"LEVY","TYRE LEVY","1","2.00"};
                Reject(()=>EbayCheck.Lines(EbayTests.Grid(extra),plan,true,new HashSet<int>{1},new List<string>()),"A line nobody planned still fails.");
                var empty=new Dictionary<int,string[]>(g);empty.Remove(1);notes.Clear();
                EbayCheck.Lines(EbayTests.Grid(empty),plan,true,new HashSet<int>{1},notes);
                Check(notes[0]=="line 1 is empty (unresolved)","An unresolved line COSTAR emptied is said to be empty.");
                var packed=new Dictionary<int,string[]>();int n=1;foreach(var kv in g.OrderBy(k=>k.Key)) if(kv.Key!=1) packed[n++]=kv.Value;
                notes.Clear();EbayCheck.Lines(EbayTests.Grid(packed),plan,false,new HashSet<int>{1},notes);
                Check(notes[0].Contains("not on the Repair Order"),"One after another, the unresolved item missing: said.");
                var packedWith=new Dictionary<int,string[]>();n=1;foreach(var kv in g.OrderBy(k=>k.Key)) packedWith[n++]=kv.Value;
                notes.Clear();EbayCheck.Lines(EbayTests.Grid(packedWith),plan,false,new HashSet<int>{1},notes);
                Check(notes[0].Contains("on the next line"),"One after another, the unresolved code still there: said.");
                EbayCheck.Lines(EbayTests.Grid(EbayTests.Example()),EbayTests.Sample().Plan(),true,null,null);   // no lines left out: the full check, as before
            });
            Case("Ebay-auto diagnostics: one journey line per event, with its time zone, ids and product codes; numbers, emails and odd ids masked",()=>{
                string line=Journey.Line(new DateTimeOffset(2026,11,16,8,36,2,TimeSpan.FromHours(11)),"handed_over","J-BCDFGH","A-KLMNPQ","call 0499 111 222 or zq.test@example.invalid",new[]{"W43116X","not a code!"});
                var d=Wire.Read<Dictionary<string,object>>(line);
                Check((string)d["at"]=="2026-11-16T08:36:02.000+11:00","Local time with its UTC offset: "+d["at"]);
                Check((string)d["job"]=="J-BCDFGH"&&(string)d["attempt"]=="A-KLMNPQ"&&(string)d["event"]=="handed_over"&&((string)d["version"]).StartsWith(Product.Version,StringComparison.Ordinal),"The ids, the event and the version.");
                Check(!line.Contains("0499")&&!line.Contains("zq.test")&&line.Contains("[number]")&&line.Contains("[email]"),"Numbers and emails masked.");
                var codes=((System.Collections.IEnumerable)d["codes"]).Cast<object>().Select(x=>(string)x).ToList();Check(codes.Count==1&&codes[0]=="W43116X","Product codes kept as they are, nothing else.");
                var bad=Wire.Read<Dictionary<string,object>>(Journey.Line(DateTimeOffset.Now,"x","22-22222-22222","nope","",null));
                Check((string)bad["job"]==""&&(string)bad["attempt"]==""&&!bad.ContainsKey("codes"),"Only well-formed ids (never an eBay number).");
                Check(EbayDiag.Shape(Order2())=="2 item(s): W43116X x4 @ $140.00, T12345 x1 @ $50.00; freight $10.00; total $620.00; state as written","An order in words without the buyer.");
                NoBuyer(EbayDiag.Shape(Order2()),"An order's shape");
                // 1.1.4: where the state came from, never the state, suburb or postcode.
                var looked=Order2();looked.address.state="";looked.address.suburb="Tempe";looked.address.postcode="2044";
                string shape=EbayDiag.Shape(looked);
                Check(shape.EndsWith("; total $620.00; state looked up from the suburb and postcode",StringComparison.Ordinal)&&shape.IndexOf("NSW",StringComparison.Ordinal)<0&&shape.IndexOf("TEMPE",StringComparison.OrdinalIgnoreCase)<0&&shape.IndexOf("2044",StringComparison.Ordinal)<0,"A looked-up state in words: "+shape);
                looked.address.postcode="3044";
                Check(EbayDiag.Shape(looked).EndsWith("; no state found (the suburb isn't in the address list under that postcode)",StringComparison.Ordinal),"No state found, and why.");
                Check(EbayDiag.Outcome("In COSTAR Branch 1 (Sydney), entered and closed (it's in Work-in-Progress). CHECK BY HAND: Terms shows NET.")=="closed (in Work-in-Progress); CHECK BY HAND: Terms shows NET.","A finished order in short.");
            });
            Case("Ebay-auto diagnostics: the 16 Nov example: 20 completed but one needed CHECK BY HAND = 19 without help; hand-overs and stops apart",()=>{
                var runs=new List<RunReport>();
                for(int i=0;i<20;i++) runs.Add(new RunReport {Kind="ebay",Outcome="completed",ChecksByHand=i==7?1:0,StartedLocal="2026-11-16T08:00:00+11:00"});
                runs.Add(new RunReport {Kind="ebay",Outcome="handed_over",Category="unknown_item",Unresolved=new List<string>{"sku=W43116X"}});
                runs.Add(new RunReport {Kind="ebay",Outcome="stopped",Category="focus_stolen"});
                runs.Add(new RunReport {Kind="ebay",Outcome="cancelled"});
                runs.Add(new RunReport {Kind="ebay-layout-check",Outcome="completed"});
                Check(runs.Count(r=>EbayAutoDiagnostics.Outcome(r)=="verified"&&r.Kind=="ebay")==19&&EbayAutoDiagnostics.Outcome(runs[7])=="check_by_hand"&&EbayAutoDiagnostics.Outcome(runs[20])=="handed_over"&&EbayAutoDiagnostics.Outcome(runs[21])=="stopped","Each run its own kind.");
                string text=EbayAutoDiagnostics.RunCounts(runs,"TODAY");
                Check(text.Contains("Fully entered and verified (completed without help): 19")&&text.Contains("(CHECK BY HAND): 1")&&text.Contains("handed over: items unresolved, not verified): 1")&&text.Contains("Stopped / uncertain (needs a person: Retry, Start again or Mark done): 1")&&text.Contains("TODAY: 23 eBay run(s)"),"The counts: "+text);
                var receipts=new List<EbayReceipt>{
                    new EbayReceipt {order=Order2(),status="ready_for_review",message="In COSTAR ..., entered and closed."},new EbayReceipt {order=Order2(),status="ready_for_review",message="In COSTAR ... CHECK BY HAND: x"},
                    new EbayReceipt {order=Order2(),status="handed_over"},new EbayReceipt {order=Order2(),status="queued"},new EbayReceipt {order=Order2(),status="entering"},new EbayReceipt {order=Order2(),status="failed"},new EbayReceipt {order=Order2(),status="ready_for_review",markedDone=true}};
                string q=EbayAutoDiagnostics.QueueCounts(receipts,"NOW");
                Check(q.Contains("completed without help): 1")&&q.Contains("(CHECK BY HAND): 1")&&q.Contains("not verified): 1")&&q.Contains("Marked done by hand: 1")&&q.Contains("Waiting (queued or being entered): 2")&&q.Contains("Stopped / uncertain: 1"),"The receiver's counts: "+q);
            });
            Case("Ebay-auto diagnostics: the receiver's ZIP has its queue and summary without the buyer, keys or eBay numbers, and says when the worker's logs are missing",()=>{
                var api=new ReceiverApi(Settings());var q=new EbayQueue(null,s=>{});api.UseEbay(q);
                q.Submit(Order2());var claim=q.Poll(Hello());
                q.Poll(Hello(Report(claim,"handed_over",1001,true,"NEEDS MANUAL COMPLETION ... "+Buyer+" "+Phone+" "+Street,"W43116X x4 (line 1); "+User),"",1001));
                byte[] zip=EbayAutoDiagnostics.ReceiverZip(q,api,api.Settings,null,"the worker didn't send its logs within 20 s",true);
                string all=Text(zip);
                Check(all.Contains("== summary.txt")&&all.Contains("== queue.csv")&&all.Contains("== WORKER-LOGS-NOT-INCLUDED.txt")&&all.Contains("NOT included: the worker didn't send its logs within 20 s"),"The summary, the queue, and the worker's logs said to be missing.");
                Check(all.Contains(q.List()[0].jobId)&&all.Contains("W43116X")&&all.Contains("handed over"),"The job's id, its product codes and its state.");
                Check(all.Contains("Handed over: manual completion needed (items unresolved, not verified): 1"),"Counted as handed over.");
                NoBuyer(all,"The receiver's diagnostics");
                byte[] worker=EbayAutoDiagnostics.WorkerZip(null,false,out string_);
                byte[] both=EbayAutoDiagnostics.ReceiverZip(q,api,api.Settings,worker,null,true);
                string text=Text(both);
                Check(text.Contains("== worker/Ebay-auto-Worker-Diagnostics.zip")&&text.Contains("The worker's logs: included")&&!text.Contains("WORKER-LOGS-NOT-INCLUDED"),"With the worker's logs inside.");
                NoBuyer(text,"The joint diagnostics");
            });
            Case("Ebay-auto diagnostics: the worker's ZIP says when the receiver's logs can't be had",()=>{
                string note;byte[] zip=EbayAutoDiagnostics.WorkerZip(null,true,out note);
                string all=Text(zip);
                Check(all.Contains("== summary.txt")&&all.Contains("== runs.csv")&&all.Contains("== RECEIVER-LOGS-NOT-INCLUDED.txt")&&all.Contains("The receiver's logs: NOT included")&&note!=null&&note.Contains("receiver"),"The receiver's logs said to be missing, with why.");
                Check(all.Contains("completed without help"),"The outcome counts, in the user's words.");
            });
            Case("Ebay-auto diagnostics exchange: the receiver asks the worker over its poll; only that token's ZIP is taken; the worker can fetch the receiver's",()=>{
                var api=new ReceiverApi(Settings());var q=new EbayQueue(null,s=>{});api.UseEbay(q);
                Check(EbayTests.Body<EbayReply>(Call(api,"POST","/api/worker/v1/ebay",new string('w',43),Hello())).diagnostics==null,"Not asked: no token.");
                string token=api.AskWorkerDiagnostics(25);
                Check(ReceiverApi.ValidId(token,"D")!=null&&EbayTests.Body<EbayReply>(Call(api,"POST","/api/worker/v1/ebay",new string('w',43),Hello())).diagnostics==token,"Asked: every poll's reply carries the token.");
                byte[] zip;using(var m=new MemoryStream()){using(var a=new ZipArchive(m,ZipArchiveMode.Create,true)){var e=a.CreateEntry("summary.txt");using(var w=new StreamWriter(e.Open()))w.Write("worker");}zip=m.ToArray();}
                var wrong=EbayTests.Body<Dictionary<string,object>>(Call(api,"POST",ReceiverApi.EbayDiagnosticsPath,new string('w',43),new ReceiverApi.DiagnosticsUpload {token="D-BCDFGH",version="x",zip=Convert.ToBase64String(zip)}));
                string note,version;
                Check(!(bool)wrong["ok"]&&api.WorkerDiagnostics(token,out note,out version)==null,"Another token's ZIP is not taken.");
                Check(Call(api,"POST",ReceiverApi.EbayDiagnosticsPath,new string('e',43),new ReceiverApi.DiagnosticsUpload {token=token,zip=Convert.ToBase64String(zip)}).status==401,"Only with the worker key.");
                Check(Call(api,"POST",ReceiverApi.EbayDiagnosticsPath,new string('w',43),new ReceiverApi.DiagnosticsUpload {token=token,zip=Convert.ToBase64String(Encoding.UTF8.GetBytes("not a zip at all"))}).status==400,"Only a ZIP.");
                var ok=EbayTests.Body<Dictionary<string,object>>(Call(api,"POST",ReceiverApi.EbayDiagnosticsPath,new string('w',43),new ReceiverApi.DiagnosticsUpload {token=token,version="1.0.0 - Ebay-auto",zip=Convert.ToBase64String(zip)}));
                Check((bool)ok["ok"]&&api.WorkerDiagnostics(token,out note,out version).Length==zip.Length&&version.StartsWith("1.0.0",StringComparison.Ordinal),"The worker's ZIP is taken.");
                Check(EbayTests.Body<EbayReply>(Call(api,"POST","/api/worker/v1/ebay",new string('w',43),Hello())).diagnostics==null,"Once it has come, polls aren't asked again.");
                api.EndWorkerDiagnostics(token);Check(api.WorkerDiagnostics(token,out note,out version)==null,"Done: forgotten.");
                Check(Call(api,"GET",ReceiverApi.EbayDiagnosticsPath,new string('w',43)).status==400,"The receiver's own ZIP: not ready until the window sets it.");
                api.ReceiverBundle=delegate{return EbayAutoDiagnostics.ReceiverZip(q,api,api.Settings,null,null,false);};
                var got=EbayTests.Body<Dictionary<string,object>>(Call(api,"GET",ReceiverApi.EbayDiagnosticsPath,new string('w',43)));
                Check((string)got["component"]=="receiver"&&Text(Convert.FromBase64String((string)got["zip"])).Contains("== summary.txt"),"The worker can fetch the receiver's ZIP with its key.");
                Check(Call(api,"GET",ReceiverApi.EbayDiagnosticsPath,new string('e',43)).status==401,"Not with the eBay key.");
            });
            Cases11(Case);
            Cases111(Case);
            Cases116(Case);
        }
        static string string_;
        // The version a made-up update brings: the next one after this (so the tests hold for every version).
        static string N { get { var v=EbayAutoUpdate.Current;return v.Major+"."+v.Minor+"."+(v.Build+1); } }
        // ---- 1.1.0: COSTAR Sydney among several COSTARs, the protocol, updates, the windows ----
        static CostarSeen Seen(int pid,int branch,int startedMinute,string place) { return new CostarSeen {Pid=pid,Session=2,Branch=branch,Started=new DateTime(2026,11,17,8,0,0,DateTimeKind.Utc).AddMinutes(startedMinute).Ticks,MainWindow=pid*10L,Place=place,Title="COSTAR:  "+branch+" Tempe Tyres "+place}; }
        static Func<CostarSeen,bool> AliveIn(IList<CostarSeen> running) { return delegate(CostarSeen c) { return running.Any(r=>r.SameProcess(c)); }; }
        static void Wait(Func<bool> done,string what) { var clock=System.Diagnostics.Stopwatch.StartNew();while(!done()) { Check(clock.ElapsedMilliseconds<15000,"Timed out: "+what);System.Threading.Thread.Sleep(20); } }
        static string TempFolder() { string d=Path.Combine(Path.GetTempPath(),"ebayauto-test-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(d);return d; }
        // A made-up package of a part and version, zipped as GitHub serves it: change (before its file list is made) and
        // tamper (after) make bad ones.
        static byte[] Package(string part,string version,Action<string> change,Action<string> tamper) {
            string root=TempFolder();
            try {
                string top=Path.Combine(root,"Ebay-auto-"+part+"-v"+version);Directory.CreateDirectory(Path.Combine(top,"Source"));
                File.WriteAllText(Path.Combine(top,"VERSION.txt"),version+"\n");File.WriteAllText(Path.Combine(top,"PART.txt"),part+"\n");
                File.WriteAllText(Path.Combine(top,"Source","Product.cs"),"namespace TempeCostar { internal static class Product { internal const string Name=\"Ebay-auto\"; internal const string DataFolder=\"EbayAuto\"; } }");
                foreach(var n in new[]{"Build.ps1","Launch.ps1","Start-"+part+".cmd","Check-Build.cmd","SETUP.txt","README.md","CHANGES.md","FEATURES.md","VALIDATION.md","THIRD-PARTY-NOTICES.txt"}) File.WriteAllText(Path.Combine(top,n),"made up "+n);
                var random=new Random(part.Length*7+version.Length);var noise=new StringBuilder();for(int i=0;i<30000;i++) noise.Append((char)('a'+random.Next(26)));
                File.WriteAllText(Path.Combine(top,"Source","Noise.cs"),"// "+noise);
                if(change!=null) change(top);
                var files=Directory.GetFiles(top,"*",SearchOption.AllDirectories).Where(f=>Path.GetFileName(f)!="PACKAGE-SHA256.json").ToList();
                var manifest=files.ToDictionary(f=>f.Substring(top.Length+1).Replace('\\','/'),f=>Updater.Sha256(File.ReadAllBytes(f)));
                File.WriteAllText(Path.Combine(top,"PACKAGE-SHA256.json"),Wire.Json(manifest));
                if(tamper!=null) tamper(top);
                using(var m=new MemoryStream()) {
                    using(var z=new ZipArchive(m,ZipArchiveMode.Create,true))
                        foreach(var f in Directory.GetFiles(top,"*",SearchOption.AllDirectories)) {
                            var e=z.CreateEntry(Path.GetFileName(top)+"/"+f.Substring(top.Length+1).Replace('\\','/'));
                            using(var s=e.Open()) { var bytes=File.ReadAllBytes(f);s.Write(bytes,0,bytes.Length); }
                        }
                    return m.ToArray();
                }
            } finally { try { Directory.Delete(root,true); } catch(Exception) { } }
        }
        static EbayRelease ReleaseFor(string version,byte[] receiver,byte[] worker) {
            return new EbayRelease {product="Ebay-auto",version=version,name=version+" - made up",notes="made up",protocol=1,published="2026-11-17",
                receiver=new EbayPackageInfo {zip="Ebay-auto-Receiver-v"+version+".zip",sha256=Updater.Sha256(receiver),size=receiver.Length},
                worker=new EbayPackageInfo {zip="Ebay-auto-Worker-v"+version+".zip",sha256=Updater.Sha256(worker),size=worker.Length}};
        }
        // Runs a test with the update's folders, GitHub and build all its own (never the real ones), and puts them back.
        static void WithTestUpdates(Action<Dictionary<string,byte[]>> test) {
            string root=TempFolder();var oldRoot=EbayAutoUpdate.Root;var oldFetch=EbayAutoUpdate.Fetch;var oldFolder=EbayAutoUpdate.Folder;var oldBuild=EbayAutoUpdate.Build;
            var served=new Dictionary<string,byte[]>(StringComparer.Ordinal);
            try {
                EbayAutoUpdate.Root=root;EbayAutoUpdate.Folder="https://example.invalid/ebay-auto/";
                EbayAutoUpdate.Fetch=delegate(string url,long limit,Action<long,long> progress) {
                    byte[] b;Order.Require(served.TryGetValue(url.Split('?')[0],out b),"GitHub answered 404.");
                    Order.Require(b.Length<=limit,"The download is larger than expected; stopped.");
                    if(progress!=null) progress(b.Length,b.Length);
                    return b;
                };
                test(served);
            } finally {
                EbayAutoUpdate.Root=oldRoot;EbayAutoUpdate.Fetch=oldFetch;EbayAutoUpdate.Folder=oldFolder;EbayAutoUpdate.Build=oldBuild;
                try { Directory.Delete(root,true); } catch(Exception) { }
            }
        }
        // ---- 1.1.6: the Repair Order's number copied for Seb as "<number> DFE" ----
        const string RoSt="WindowsForms10.STATIC.app.0.1",RoEd="WindowsForms10.EDIT.app.0.1",RoBt="WindowsForms10.BUTTON.app.0.1";
        static ControlInfo RoMk(long h,long parent,string cls,int x,int y,int w,int hh,string text,int style,bool enabled=true) {
            return new ControlInfo {Handle=h,Parent=parent,Class=cls,Style=style,Visible=true,Enabled=enabled,Bounds=new[]{x,y,w,hh},RelativeBounds=new[]{x,y,w,hh},Text=text,TextState="read"};
        }
        // A made-up Repair Order laid out as the maps (28 Oct and 17 Nov Tempe, 3 Nov Sydney: lengths only in them, every word
        // and number here made up): the RepairOrder label [37,83,176,17], its read-only number box [214,82,170,20] (style
        // 0x560008C0, ES_READONLY) and Ne&xt # [388,81,97,21] (its words aren't read in a snapshot of the Repair Order), on the
        // main panel; the customer panel with PO# under its label.
        sealed class NumberedRo { internal string Number="01234567",Po="12-34567-89012",State="read";internal bool NextEnabled,NotReadOnly,SecondLabel,NoLabel; }
        static List<ControlInfo> RoWithNumber(NumberedRo r) {
            var s=new List<ControlInfo>();
            if(!r.NoLabel) s.Add(RoMk(1,1000,RoSt,37,83,176,17,"RepairOrder",0x5600000D));
            if(r.SecondLabel) s.Add(RoMk(6,1000,RoSt,37,600,176,17,"Repair Order",0x5600000D));
            var box=RoMk(2,1000,RoEd,214,82,170,20,r.Number,r.NotReadOnly?0x560100C0:0x560008C0);box.TextState=r.State;s.Add(box);
            var next=RoMk(3,1000,RoBt,388,81,97,21,null,r.NextEnabled?0x5600000B:0x5E00000B,r.NextEnabled);next.TextState="not-read";s.Add(next);
            s.Add(RoMk(4,1000,RoSt,706,85,51,13,"Comment",0x5600000D));s.Add(RoMk(5,1000,RoEd,782,82,265,20,"",0x560100C0));
            s.Add(RoMk(9001,100,RoSt,37,111,285,17,"Account#                        Name",0x5600000D));
            s.Add(RoMk(10,100,RoEd,37,128,122,20,"",0x560100C0));s.Add(RoMk(11,100,RoEd,158,128,226,20,"QUINN TESTBUYER",0x560100C0));
            s.Add(RoMk(12,100,RoEd,37,147,347,20,"7 MADEUP ROAD",0x560100C0));s.Add(RoMk(13,100,RoEd,37,166,347,20,"",0x560100C0));
            s.Add(RoMk(14,100,RoEd,37,185,208,20,"TESTVILLE",0x560100C0));s.Add(RoMk(15,100,RoEd,244,185,56,20,"NSW",0x560100C0));s.Add(RoMk(16,100,RoEd,299,185,85,20,"2799",0x560100C0));
            s.Add(RoMk(17,100,RoSt,37,250,148,15,"eMail",0x5600000D));s.Add(RoMk(18,100,RoSt,184,250,100,15,"Mobile Ph",0x5600000D));
            s.Add(RoMk(19,100,RoEd,37,265,148,20,"",0x560100C0));s.Add(RoMk(20,100,RoEd,184,265,100,20,"0400000009",0x560100C0));
            s.Add(RoMk(21,100,RoSt,274,295,109,15,"PO#",0x5600000D));s.Add(RoMk(22,100,RoEd,274,310,109,20,r.Po,0x560100C0));
            return s;
        }
        static RoNumberLook RoLook(NumberedRo r) { ControlInfo next;return RoNumber.Look(RoWithNumber(r),out next); }
        static RoNumberVerdict RoJudge(NumberedRo first,NumberedRo second,params string[] earlier) { return RoNumber.Judge(RoLook(first),RoLook(second),"12-34567-89012",new List<string>(earlier)); }
        internal static void Cases116(Action<string,Action> Case) {
            Case("Ebay-auto 1.1.6: the Repair Order's number found where every map has it (the read-only box beside RepairOrder, Next # beside it), kept as COSTAR shows it and copied as \"<number> DFE\", nothing else",()=>{
                var r=new NumberedRo();ControlInfo next;
                var look=RoNumber.Look(RoWithNumber(r),out next);
                Check(look.Box&&look.ReadOnly&&look.Read&&look.Text=="01234567"&&look.PoRead&&look.Po=="12-34567-89012","The number box beside the RepairOrder label, COSTAR's read-only box, read, with this order's PO#.");
                Check(look.BoxHandle==2&&look.NextFound&&look.NextHandle==3&&!look.NextEnabled&&RoLook(new NumberedRo {Number="",NextEnabled=true}).NextEnabled,"1.1.7: the box's window and Next # beside it (greyed with a number, enabled when blank, as in every map).");
                Check(next!=null&&next.Handle==3,"The button just right of it on its line: Next # (its words read by the runner).");
                var v=RoJudge(r,r);
                Check(v.Outcome=="ok"&&v.Number=="01234567"&&v.Why==null&&v.Shape=="8 digits, a leading zero","Read twice the same: kept as it is (leading zero).");
                string text=RoNumber.Text(v.Number);
                Check(text=="01234567 DFE"&&text.Length==12&&text.IndexOf('\n')<0&&text.IndexOf('\r')<0&&text.Split(' ').Length==2&&RoNumber.Text("00000001")=="00000001 DFE","Copied: the 8 digits as shown, one space, DFE; no label, no line break; leading zeros kept.");
                Check(RoJudge(new NumberedRo {Number=" 01234567 "},new NumberedRo {Number="01234567"}).Number=="01234567","Spaces around it aren't part of it.");
                foreach(var bad in new[]{"","   ",null,"1234567","123456789","0123456A","01234567 DFE"}) { string b=bad;Reject(()=>RoNumber.Text(b),"Never copied: \""+(b??"null")+"\"."); }
                Check(RoNumber.IsNextWords("Ne&xt #")&&RoNumber.IsNextWords("Next  #")&&!RoNumber.IsNextWords("Next")&&!RoNumber.IsNextWords("&Print")&&!RoNumber.IsNextWords(null),"Next # by COSTAR's words for it (Ne&xt #).");
                Check(RoNumber.NextShape(true,true,false)=="Next # beside it, greyed"&&RoNumber.NextShape(true,true,true)=="Next # beside it, enabled"&&RoNumber.NextShape(false,false,false)=="no button beside it"&&RoNumber.NextShape(true,false,true)=="the button beside it isn't Next #","Next #, as the diagnostics say it.");
                var far=RoWithNumber(r);far.First(c=>c.Handle==3).Bounds=new[]{460,81,97,21};
                Check(RoNumber.NextBeside(far,Runner.NumberBox(far))==null,"A button further along the line isn't taken for Next #.");
                var lower=RoWithNumber(r);lower.First(c=>c.Handle==3).Bounds=new[]{388,128,97,21};
                Check(RoNumber.NextBeside(lower,Runner.NumberBox(lower))==null,"Nor one on another line.");
            });
            Case("Ebay-auto 1.1.6: never copied: no number yet (Next # not pressed), not COSTAR's 8 digits, changed between the two looks, another PO#, unreadable, not its read-only box, no single RepairOrder label, or a number copied before",()=>{
                var blank=RoJudge(new NumberedRo {Number="",NextEnabled=true},new NumberedRo {Number="",NextEnabled=true});
                Check(blank.Outcome=="blank"&&blank.Number==null&&blank.Shape=="blank","No number yet: nothing copied (Next # isn't pressed in 1.1.6).");
                foreach(var odd in new[]{"1234567","123456789","0123456A","٠١٢٣٤٥٦٧","0123 4567"}) {
                    var v=RoJudge(new NumberedRo {Number=odd},new NumberedRo {Number=odd});
                    Check(v.Outcome=="not_8_digits"&&v.Number==null,"Not COSTAR's 8 digits (0-9): never copied: "+odd.Length+" characters.");
                }
                Check(RoJudge(new NumberedRo(),new NumberedRo {Number="01234568"}).Outcome=="changed","Two looks that differ: never copied.");
                Check(RoJudge(new NumberedRo {Number=""},new NumberedRo()).Outcome=="changed","A number that appeared between the two looks: not copied either.");
                Check(RoJudge(new NumberedRo {Po="12-34567-89099"},new NumberedRo {Po="12-34567-89099"}).Outcome=="po"&&RoJudge(new NumberedRo(),new NumberedRo {Po=""}).Outcome=="po","Not this order's PO# with it (either look): never copied.");
                Check(RoJudge(new NumberedRo {State="busy"},new NumberedRo()).Outcome=="unreadable"&&RoJudge(new NumberedRo(),new NumberedRo {State="skipped"}).Outcome=="unreadable","A look that couldn't read it: never copied.");
                Check(RoJudge(new NumberedRo {NotReadOnly=true},new NumberedRo {NotReadOnly=true}).Outcome=="not_number_box","A box that takes typing isn't COSTAR's number box.");
                Check(RoJudge(new NumberedRo {SecondLabel=true},new NumberedRo()).Outcome=="no_box"&&RoJudge(new NumberedRo {NoLabel=true},new NumberedRo {NoLabel=true}).Outcome=="no_box"&&RoNumber.Judge(null,null,"12-34567-89012",null).Outcome=="no_box","Two RepairOrder labels, or none: no number box.");
                var earlier=RoJudge(new NumberedRo(),new NumberedRo(),"07654321","01234567");
                Check(earlier.Outcome=="earlier_order"&&earlier.Number==null,"A number copied before: never copied again.");
                Check(RoJudge(new NumberedRo(),new NumberedRo(),"07654321").Outcome=="ok","Other numbers kept: not this one.");
                foreach(var o in new[]{"blank","not_8_digits","changed","po","unreadable","not_number_box","no_box","earlier_order","clipboard","skipped_checks","stopped","error","next_not_pressed","next_no_number","next_window"}) {
                    string w=RoNumber.Words(o,"why",false);
                    Check(w.StartsWith("Repair Order number not copied: why. ",StringComparison.Ordinal)&&w.Contains("DFE")&&w.IndexOf("01234567",StringComparison.Ordinal)<0&&w.IndexOf("taken off",StringComparison.Ordinal)<0,"Seb is told what to do ("+o+"): "+w);
                    Check(RoNumber.OutcomeWords(o)!=o&&RoNumber.OutcomeWords(o).Length>0,"The diagnostics' words for "+o+".");
                }
                Check(RoNumber.Words("blank",blank.Why,false)=="Repair Order number not copied: the Repair Order has no number yet. Press Next # on it, then copy its number followed by DFE.","No number yet: press Next #, then copy it by hand.");
                Check(RoNumber.Words("clipboard","the clipboard couldn't be set (x)",true).EndsWith(" (The previous order's number was taken off the clipboard.)",StringComparison.Ordinal),"Said when the previous order's number was taken off.");
            });
            Case("Ebay-auto 1.1.7: after Next # (pressed once): the box read until the number shows, 10 s at most; a window of COSTAR's over the Repair Order ends the wait at once; nothing pressed in the wait",()=>{
                long now=0;var pauses=new List<int>();int reads;string why;
                Func<string[],Func<string>> boxes=delegate(string[] seq) { int i=0;return delegate { return seq[Math.Min(i++,seq.Length-1)]; }; };
                string got=RoNumber.WaitForNumber(boxes(new[]{"","",null,"01234567"}),ms=>{pauses.Add(ms);now+=ms;},()=>now,()=>null,out reads,out why);
                Check(got=="01234567"&&reads==4&&why==null&&pauses.All(ms=>ms==RoNumber.PollMs)&&RoNumber.PollMs==150,"Blank, blank, unreadable, then the number: taken as COSTAR shows it, after 4 reads 150 ms apart.");
                now=0;pauses.Clear();
                got=RoNumber.WaitForNumber(boxes(new[]{""}),ms=>{pauses.Add(ms);now+=ms;},()=>now,()=>null,out reads,out why);
                Check(got==null&&why==RoNumber.NoNumberWhy&&now>=RoNumber.AppearMs&&now<RoNumber.AppearMs+RoNumber.PollMs+1&&RoNumber.AppearMs==10000,"Never filled: given up after 10 s, saying so ("+reads+" reads).");
                now=0;int looks=0;
                got=RoNumber.WaitForNumber(boxes(new[]{""}),ms=>{now+=ms;},()=>now,()=>++looks>=3?"a window of COSTAR's came over the Repair Order (nothing in it was answered)":null,out reads,out why);
                Check(got==null&&reads==3&&why.StartsWith("a window of COSTAR's",StringComparison.Ordinal),"A window over the Repair Order: the wait ends at once (never answered).");
                now=0;looks=0;
                got=RoNumber.WaitForNumber(boxes(new[]{"01234567"}),ms=>{now+=ms;},()=>now,()=>{looks++;return "a window of COSTAR's came over the Repair Order (nothing in it was answered)";},out reads,out why);
                Check(got==null&&reads==1&&looks==1&&why.StartsWith("a window of COSTAR's",StringComparison.Ordinal),"The number and a window appear in the same poll: the window takes precedence, never a successful number result.");
                Check(RoNumber.Words("next_no_number",RoNumber.NoNumberWhy,false)=="Repair Order number not copied: Next # was pressed once, but no number appeared in its box within 10 s. Check its number (press Next # once more only if it is still blank), then copy it followed by DFE.","No number after Next #: Seb told, never pressed again by the worker.");
                Check(RoNumber.Words("next_not_pressed","the Repair Order has no number yet and Next # couldn't be pressed (direct presses are off (worker, Settings tab))",false).EndsWith(" Press Next # on it, then copy its number followed by DFE.",StringComparison.Ordinal),"Next # not pressed (direct presses off, not there, greyed, a window over it): Seb presses it.");
                Check(RoNumber.Words("next_window","a window of COSTAR's came over the Repair Order (nothing in it was answered)",false).Contains("Check that window and the Repair Order"),"A window after Next #: Seb checks it.");
            });
            Case("Ebay-auto 1.1.6: the clipboard set and read back (3 tries at most, 250 ms apart); the previous order's text taken off only while the clipboard still holds exactly it",()=>{
                var sets=new List<string>();var pauses=new List<int>();int attempts;
                Check(RoClipboard.CopyChecked("01234567 DFE",t=>sets.Add(t),()=>sets.Last(),ms=>pauses.Add(ms),out attempts)==null&&attempts==1&&sets.Count==1&&pauses.Count==0,"Set and read back the same: copied at once.");
                sets.Clear();int calls=0;
                string why=RoClipboard.CopyChecked("01234567 DFE",t=>{calls++;if(calls==1) throw new System.Runtime.InteropServices.ExternalException("busy");sets.Add(t);},()=>sets.Count==0?null:sets.Last(),ms=>pauses.Add(ms),out attempts);
                Check(why==null&&attempts==2&&pauses.Count==1&&pauses[0]==250,"Busy once: tried again after 250 ms.");
                sets.Clear();pauses.Clear();
                why=RoClipboard.CopyChecked("01234567 DFE",t=>sets.Add(t),()=>"something Seb copied",ms=>pauses.Add(ms),out attempts);
                Check(why=="something else was read back (20 characters)"&&attempts==3&&sets.Count==3&&pauses.Count==2,"Never read back the same: given up after 3 tries, saying why (never the text).");
                why=RoClipboard.CopyChecked("01234567 DFE",t=>{},()=>null,ms=>{},out attempts);
                Check(why=="nothing was read back"&&attempts==3,"Nothing read back: not copied.");
                why=RoClipboard.CopyChecked("01234567 DFE",t=>{throw new System.Runtime.InteropServices.ExternalException("busy");},()=>"x",ms=>{},out attempts);
                Check(why=="the clipboard was busy (ExternalException)"&&attempts==3,"Busy every time: not copied, saying so.");
                why=RoClipboard.CopyChecked("01234567 DFE",t=>{throw new InvalidOperationException("odd");},()=>"x",ms=>{},out attempts);
                Check(why!=null&&why.StartsWith("InvalidOperationException",StringComparison.Ordinal),"Any other failure: not copied, with its kind.");
                Check(RoClipboard.StillThere("01234567 DFE","01234567 DFE")&&!RoClipboard.StillThere("01234567 DFE\r\n","01234567 DFE")&&!RoClipboard.StillThere("something Seb copied","01234567 DFE")&&!RoClipboard.StillThere(null,"01234567 DFE")&&!RoClipboard.StillThere("","")&&!RoClipboard.StillThere(null,null),"Taken off only while the clipboard holds exactly what was copied for the previous order.");
                Check(RoClipboard.Attempts==3&&RoClipboard.PauseMs==250&&RoClipboard.TimeoutMs<=10000,"At most 3 tries, then given up within 10 s.");
            });
            Case("Ebay-auto 1.1.6: the worker's journal: a number copied before is never copied again (an order entered again is in a new Repair Order: Start again), the last one copied is the one taken off the clipboard; 200 kept; an earlier journal has none",()=>{
                var at=new DateTime(2026,11,18,0,30,0,DateTimeKind.Utc);var kept=new List<EbayRoNumber>();
                Check(RoNumber.Earlier(kept).Count==0&&RoNumber.Earlier(null).Count==0&&RoNumber.LastText(kept)==null&&RoNumber.LastText(null)==null,"Nothing copied yet: nothing refused, nothing to take off.");
                RoNumber.Keep(kept,"11-11111-11111","J-BCDFGH","07654321",at);RoNumber.Keep(kept,"22-22222-22222","J-CDFGHJ","01234567",at.AddMinutes(2));
                var earlier=RoNumber.Earlier(kept);
                Check(earlier.Count==2&&earlier.Contains("07654321")&&earlier.Contains("01234567"),"Both earlier numbers refused for any order.");
                Check(RoNumber.LastText(kept)=="01234567 DFE","What was copied last: what may be taken off the clipboard.");
                RoNumber.Keep(kept,"22-22222-22222","J-CDFGHJ","01234568",at.AddMinutes(5));
                Check(kept.Count==3&&kept.Last().number=="01234568"&&kept.Last().orderNumber=="22-22222-22222"&&kept.Last().jobId=="J-CDFGHJ"&&kept.Last().atUtc=="2026-11-18T00:35:00.0000000Z"&&RoNumber.Earlier(kept).Contains("01234567"),"Start again (a new Repair Order): the new number kept too, newest last; the old one still refused.");
                Check(RoNumber.LastText(kept)=="01234568 DFE","The last one copied.");
                Reject(()=>RoNumber.Keep(kept,"44-44444-44444","J-DFGHJK","",at),"A blank is never kept.");Reject(()=>RoNumber.Keep(kept,"44-44444-44444","J-DFGHJK","1234",at),"Nor anything but 8 digits.");
                for(int i=0;i<250;i++) RoNumber.Keep(kept,"55-55555-"+i.ToString("00000",CultureInfo.InvariantCulture),"J-FGHJKL",(10000000+i).ToString(CultureInfo.InvariantCulture),at);
                Check(kept.Count==200&&kept.Last().number=="10000249"&&kept.First().number=="10000050","The last 200 kept, newest last.");
                var journal=Wire.Read<EbayJournal>(Wire.Json(new EbayJournal {roNumbers=kept.Take(3).ToList()}));
                Check(journal.roNumbers.Count==3&&journal.roNumbers[0].number=="10000050","The worker's journal keeps them.");
                Check(Wire.Read<EbayJournal>("{\"entered\":[]}").roNumbers!=null&&Wire.Read<EbayJournal>("{\"entered\":[]}").roNumbers.Count==0,"An earlier journal has none (empty, not missing).");
            });
            Case("Ebay-auto 1.1.6: \"ez, next\" only once the number is copied: a number not copied is a CHECK BY HAND note (no number in it); the diagnostics count copied and not copied by reason, with shapes, never digits",()=>{
                var none=new List<string>();
                Check(EbayFinish.Words("Branch 1 (SYDNEY)",false,true,none,none)=="ez, next","Copied (nothing to check): \"ez, next\", as in 1.1.1.");
                var check=new List<string>{RoNumber.Words("blank","the Repair Order has no number yet",false)};
                string words=EbayFinish.Words("Branch 1 (SYDNEY)",false,false,none,check);
                Check(words=="In COSTAR Branch 1 (SYDNEY), ready for review (Repair Order left open). CHECK BY HAND: Repair Order number not copied: the Repair Order has no number yet. Press Next # on it, then copy its number followed by DFE.","Not copied: CHECK BY HAND for Seb, never \"ez, next\".");
                Check(EbayDiag.Outcome(words).StartsWith("left open; CHECK BY HAND: Repair Order number not copied",StringComparison.Ordinal),"The diagnostics' words for it: "+EbayDiag.Outcome(words));
                Check(RoNumber.Shape("01234567")=="8 digits, a leading zero"&&RoNumber.Shape("12345678")=="8 digits"&&RoNumber.Shape("")=="blank"&&RoNumber.Shape("  ")=="blank"&&RoNumber.Shape(null)=="not read"&&RoNumber.Shape("123")=="3 digits"&&RoNumber.Shape("12AB")=="4 characters, not all digits","Shapes only.");
                foreach(var n in new[]{"01234567","12345678","123","12AB"}) Check(RoNumber.Shape(n).IndexOf(n,StringComparison.Ordinal)<0,"Never the digits: "+RoNumber.Shape(n));
                Func<string,RunReport> run=delegate(string outcome) { var r=new RunReport {Kind="ebay",Outcome="completed",StartedLocal="2026-11-18T10:30:00+11:00"};if(outcome!=null) r.Env["roNumber"]=outcome;return r; };
                var runs=new List<RunReport>{run("copied"),run("copied"),run("copied"),run("blank"),run("blank"),run("clipboard"),run(null)};
                string counts=EbayAutoDiagnostics.RoNumberCounts(runs,"TODAY");
                Check(counts.StartsWith("TODAY: 3 copied with DFE, 3 not copied\r\n",StringComparison.Ordinal)&&counts.Contains("  not copied, no number yet: 2\r\n")&&counts.Contains("  not copied, the clipboard couldn't be set: 1\r\n"),"Counted by reason: "+counts);
                Check(EbayAutoDiagnostics.RoNumberCounts(new List<RunReport>{run(null)},"X")=="X: 0 copied with DFE, 0 not copied\r\n","Runs before 1.1.6 (or closed ones): not counted.");
            });
        }
        // ---- 1.1.1: each verified Repair Order left open for Seb ("ez, next") ----
        internal static void Cases111(Action<string,Action> Case) {
            Case("Ebay-auto 1.1.1: an order entered and verified is left open on purpose and reported \"ez, next\"; with something to check by hand, or closed (ticked), the words are as before",()=>{
                var none=new List<string>();
                Check(EbayFinish.Words("Branch 1 (SYDNEY)",false,true,none,none)=="ez, next"&&EbayFinish.EzNext=="ez, next","Verified, left open on purpose: exactly \"ez, next\".");
                var notes=new List<string>{"COSTAR showed the customer's Notes before the order (OK pressed): see them in COSTAR if you need to."};
                Check(EbayFinish.Words("Branch 1 (SYDNEY)",false,true,notes,none)=="ez, next "+notes[0],"COSTAR's Notes seen on the way: still said after it (as before).");
                var checks=new List<string>{"Terms shows NET."};
                string withCheck=EbayFinish.Words("Branch 1 (SYDNEY)",false,true,none,checks);
                Check(withCheck=="In COSTAR Branch 1 (SYDNEY), ready for review (Repair Order left open). CHECK BY HAND: Terms shows NET.","Something to check by hand: CHECK BY HAND as before (never \"ez, next\").");
                Check(EbayFinish.Words("Branch 1 (SYDNEY)",true,false,none,none)=="In COSTAR Branch 1 (SYDNEY), entered and closed (it's in Work-in-Progress).","Close each Repair Order ticked again: closed, the words as before.");
                Check(EbayFinish.Words("Branch 1 (SYDNEY)",false,false,notes,checks)=="In COSTAR Branch 1 (SYDNEY), ready for review (Repair Order left open). "+notes[0]+" CHECK BY HAND: Terms shows NET.","Left open for a check: the words as before.");
                foreach(var w in new[]{EbayFinish.Words("Branch 1 (SYDNEY)",false,true,none,none),EbayFinish.Words("Branch 1 (SYDNEY)",false,true,notes,none)})
                    Check(w.IndexOf("CHECK BY HAND",StringComparison.Ordinal)<0&&w.IndexOf("NEEDS",StringComparison.Ordinal)<0&&w.IndexOf("close it by hand",StringComparison.OrdinalIgnoreCase)<0&&w.IndexOf("didn't close",StringComparison.OrdinalIgnoreCase)<0,"No warning, no NEEDS YOU, no failed-close words: "+w);
            });
            Case("Ebay-auto 1.1.1: \"ez, next\" on the receiver: verified (completed without help, never NEEDS YOU or stopped), the next order handed out at once, recorded as left open on purpose, tidied by Hide finished",()=>{
                var notes=new List<string>();var q=new EbayQueue(null,s=>{});q.Noted=delegate(string kind,string job,string attempt,string detail){notes.Add(kind+": "+detail);};
                q.Submit(Order2());q.Submit(Order2("33-33333-33333"));
                var claim=q.Poll(Hello());
                q.Poll(Hello(Report(claim,"entering",1001,true,"Entered Card#."),claim.lease,1001));
                var next=q.Poll(Hello(Report(claim,"ready_for_review",1002,true,EbayFinish.EzNext),"",1002));
                Check(next.command=="enter"&&next.order.orderNumber=="33-33333-33333","The job is released: the next order goes to the worker straight away (its own new Repair Order).");
                var done=q.List().First(o=>o.order.orderNumber=="22-22222-22222");
                Check(done.status=="ready_for_review"&&done.message=="ez, next"&&EbayQueue.Category(done)=="verified","In COSTAR, verified: \"ez, next\" on the receiver and the eBay page (never handed over, stopped or CHECK BY HAND).");
                Check(notes.Any(n=>n.StartsWith("completed: verified: verified, left open on purpose for Seb to check and close by hand",StringComparison.Ordinal)),"The journey: verified, left open on purpose.");
                Check(EbayDiag.Outcome("ez, next").StartsWith("verified, left open on purpose",StringComparison.Ordinal)&&EbayDiag.Outcome("In COSTAR Branch 1 (Sydney), entered and closed (it's in Work-in-Progress).")=="closed (in Work-in-Progress)","The diagnostics' words for each.");
                string counts=EbayAutoDiagnostics.QueueCounts(q.List(),"NOW");
                Check(counts.Contains("Fully entered and verified by the worker (completed without help): 1")&&counts.Contains("(CHECK BY HAND): 0")&&counts.Contains("not verified): 0")&&counts.Contains("Stopped / uncertain: 0"),"Counted as completed without help: "+counts);
                q.HideFinished();
                Check(q.List().First(o=>o.order.orderNumber=="22-22222-22222").hidden,"Hide finished tidies it away like any finished order.");
                var journal=Wire.Read<EbayJournal>(Wire.Json(new EbayJournal {leftOpen=new List<EbayHeldRo>{new EbayHeldRo {jobId="J-BCDFGH",window=4242,processId=7,processStart=99,atUtc="2026-11-17T00:00:00.0000000Z"}}}));
                Check(journal.leftOpen.Count==1&&journal.leftOpen[0].window==4242&&journal.leftOpen[0].closedUtc==null&&Wire.Read<EbayJournal>("{\"entered\":[]}").leftOpen!=null,"The worker's journal keeps the Repair Orders left open (an earlier journal has none: empty, not missing).");
            });
        }
        internal static void Cases11(Action<string,Action> Case) {
            Case("Ebay-auto 1.1.0 COSTAR Sydney: found among other branches; of several Sydney the earliest-started (not PID, window or foreground order), kept when another opens",()=>{
                var now=new DateTime(2026,11,17,9,0,0,DateTimeKind.Utc);string change;
                var tempe=Seen(100,11,0,"TEMPE");var penrith=Seen(200,7,1,"PENRITH");var syd=Seen(900,1,5,"SYDNEY");
                var scan=new List<CostarSeen>{tempe,penrith,syd};
                var c=new SydneyChoice(1);
                Check(c.Next(scan,AliveIn(scan),now,out change)==syd&&c.Waiting==null&&change.Contains("the only Sydney")&&change.Contains("PID 900"),"One Sydney with other branches open: Sydney.");
                // Two Sydney: the one started first has the higher PID and comes anywhere in the scan.
                var a=Seen(5000,1,10,"SYDNEY");var b=Seen(300,1,20,"SYDNEY");
                foreach(var order in new[]{new List<CostarSeen>{b,a,tempe},new List<CostarSeen>{tempe,a,b},new List<CostarSeen>{a,tempe,b}}) {
                    var d=new SydneyChoice(1);
                    Check(d.Next(order,AliveIn(order),now,out change)==a&&change.Contains("earliest-started of 2"),"Two Sydney: the earliest-started (PID 5000), whatever the order and the PIDs.");
                }
                var e=new SydneyChoice(1);var two=new List<CostarSeen>{a,b,tempe};e.Next(two,AliveIn(two),now,out change);
                // A third Sydney opens, the scan comes in another order (another window in front): nothing changes.
                var later=Seen(100000,1,30,"SYDNEY");var three=new List<CostarSeen>{later,b,tempe,a};
                Check(e.Next(three,AliveIn(three),now.AddSeconds(3),out change)==a&&change=="","Another Sydney opening, or another order of windows, changes nothing.");
                // A COSTAR started earlier (Tempe) is switched to Sydney: the choice stays (kept while it is valid).
                var tempeNowSydney=Seen(100,1,0,"SYDNEY");var four=new List<CostarSeen>{tempeNowSydney,a,b,later};
                Check(e.Next(four,AliveIn(four),now.AddSeconds(6),out change)==a&&change=="","An earlier-started COSTAR switched to Sydney doesn't take the choice over.");
                var oc=Seen(50,1,-30,"SYDNEY");oc.OrderCheck=true;var withOc=new List<CostarSeen>{oc,b};
                Check(new SydneyChoice(1).Next(withOc,AliveIn(withOc),now,out change)==b,"Never Order Check's COSTAR.");
                var none=new List<CostarSeen>{tempe,penrith};
                Check(new SydneyChoice(1).Next(none,AliveIn(none),now,out change)==null,"Only other branches open: no COSTAR (orders wait for Sydney).");
                string summary=EbayAutoCostar.Summary(two);
                Check(summary.Contains("Branch 1 (SYDNEY) PID 5000 started "+EbayAutoCostar.Time(a.Started))&&EbayAutoCostar.Time(a.Started).StartsWith("2026-11-",StringComparison.Ordinal)&&summary.Contains("Branch 11 (TEMPE)")&&summary.IndexOf("Tempe Tyres",StringComparison.Ordinal)<0,"The journey names branch, PID and start time, never a window title.");
                Check(EbayAutoCostar.Signature(two)==EbayAutoCostar.Signature(new List<CostarSeen>{tempe,b,a}),"The same COSTARs in another order are the same scan.");
            });
            Case("Ebay-auto 1.1.0 COSTAR Sydney: waits for a chosen one that can't be read or may be changing; closed, restarted (PID reused) or changed twice: the earliest-started remaining, for new orders",()=>{
                var now=new DateTime(2026,11,17,9,0,0,DateTimeKind.Utc);string change;
                var a=Seen(5000,1,10,"SYDNEY");var b=Seen(300,1,20,"SYDNEY");
                var c=new SydneyChoice(1);var both=new List<CostarSeen>{a,b};c.Next(both,AliveIn(both),now,out change);
                // Its title can't be read (busy, or a window of its own in front): not in the scan, but still running.
                var onlyB=new List<CostarSeen>{b};
                Check(c.Next(onlyB,AliveIn(both),now.AddSeconds(3),out change)==a&&c.Waiting!=null&&c.Waiting.Contains("waiting for it")&&change=="","Can't be read: kept; new orders wait (never the other Sydney).");
                // Another branch once: not yet a change; again within a second: still not; again a second or more after: changed.
                var aTempe=Seen(5000,11,10,"TEMPE");var seen=new List<CostarSeen>{aTempe,b};
                Check(c.Next(seen,AliveIn(both),now.AddSeconds(6),out change)==a&&c.Waiting.Contains("looking again"),"Another branch once: waiting, not yet a change.");
                Check(c.Next(seen,AliveIn(both),now.AddSeconds(6.5),out change)==a,"Twice within a second: still not.");
                Check(c.Next(seen,AliveIn(both),now.AddSeconds(7.5),out change)==b&&change.Contains("no longer Sydney")&&change.Contains("chose")&&c.Waiting==null,"Seen again a second later: changed; the earliest-started remaining Sydney, for new orders.");
                // Back on Sydney: it doesn't take the choice back.
                var aBack=Seen(5000,1,10,"SYDNEY");var again=new List<CostarSeen>{aBack,b};
                Check(c.Next(again,AliveIn(again),now.AddSeconds(10),out change)==b,"The first one back on Sydney doesn't take the choice back.");
                var onlyA=new List<CostarSeen>{aBack};
                Check(c.Next(onlyA,AliveIn(onlyA),now.AddSeconds(13),out change)==aBack&&change.Contains("closed"),"The chosen one closed: the earliest-started remaining.");
                var reused=Seen(5000,1,40,"SYDNEY");var restarted=new List<CostarSeen>{reused};
                Check(!reused.SameProcess(aBack),"The same PID with another start time is another COSTAR.");
                Check(c.Next(restarted,AliveIn(restarted),now.AddSeconds(16),out change)==reused&&change.Contains("restarted"),"Restarted with its PID reused: a new COSTAR, never taken for the old one.");
                Check(c.Next(new List<CostarSeen>(),AliveIn(new List<CostarSeen>()),now.AddSeconds(19),out change)==null&&change.Contains("no other COSTAR Sydney"),"None left: new orders wait for one.");
            });
            Case("Ebay-auto 1.1.0 protocol: a 1.0.0 part (no number) works with this one; a newer protocol gets no orders and both say which part to update; replies carry the receiver's version",()=>{
                Check(Product.Speaks(0)&&Product.Speaks(1)&&!Product.Speaks(2)&&Product.ProtocolOf(0)==1&&Product.Protocol==1,"1.0.0 sent no number: protocol 1, which this version speaks.");
                var api=new ReceiverApi(Settings());var q=new EbayQueue(null,s=>{});api.UseEbay(q);var notes=new List<string>();
                api.EbayRefused=delegate(string kind,string words){notes.Add(kind+": "+words);};
                q.Submit(Order2());
                var newer=Hello();newer.protocol=2;newer.version="9.0.0 - Ebay-auto";
                var r1=EbayTests.Body<EbayReply>(Call(api,"POST","/api/worker/v1/ebay",new string('w',43),newer));
                Check(r1.command=="wait"&&r1.protocol==Product.Protocol&&r1.version==AutofillForm.Version,"A worker speaking a newer protocol gets no order; the reply names this receiver's version and protocol.");
                Check(api.EbayWaiting.Contains("update the receiver")&&notes.Any(n=>n.StartsWith("protocol_mismatch",StringComparison.Ordinal)),"The eBay page and the journey say: update the receiver.");
                var old=Hello();old.protocol=0;
                var r2=EbayTests.Body<EbayReply>(Call(api,"POST","/api/worker/v1/ebay",new string('w',43),old));
                Check(r2.command=="enter"&&notes.Any(n=>n.StartsWith("protocol_ok",StringComparison.Ordinal)),"A 1.0.0 worker (no number): orders as before.");
                Check(Wire.Read<EbayReply>("{\"command\":\"wait\"}").protocol==0&&Product.Speaks(Wire.Read<EbayReply>("{\"command\":\"wait\"}").protocol),"A 1.0.0 receiver's reply (no number) is protocol 1.");
                // A worker updating itself (a receiver of its own: the claim above would be offered again until declined).
                var api2=new ReceiverApi(Settings());var q2=new EbayQueue(null,s=>{});api2.UseEbay(q2);q2.Submit(Order2("33-33333-33333"));
                var updating=Hello();updating.accepting=false;updating.detail="Updating the Ebay-auto worker to 1.1.1: new orders wait on the receiver (back in about a minute).";
                Check(EbayTests.Body<EbayReply>(Call(api2,"POST","/api/worker/v1/ebay",new string('w',43),updating)).command=="wait"&&api2.EbayWaiting.StartsWith("Updating the Ebay-auto worker",StringComparison.Ordinal),"A worker updating takes nothing; the eBay page says it is updating.");
                // The claim offered again to a worker that is updating: it declines it, and it is back in line (nothing typed).
                var offered=EbayTests.Body<EbayReply>(Call(api,"POST","/api/worker/v1/ebay",new string('w',43),updating));
                Check(offered.command=="enter","A claim not yet started is offered again ...");
                var declining=Hello();declining.accepting=false;declining.detail=updating.detail;declining.declined=offered.lease;declining.declineReason=updating.detail;
                Check(EbayTests.Body<EbayReply>(Call(api,"POST","/api/worker/v1/ebay",new string('w',43),declining)).command=="wait"&&q.List().Any(o=>o.status=="queued"&&o.order.orderNumber=="22-22222-22222"),"... declined by the updating worker, it waits in line on the receiver.");
            });
            Case("Ebay-auto 1.1.0 receiver update: while it waits for its safe point, orders from the extension are taken and kept, none goes to the worker, the eBay page says why; released, they go on",()=>{
                var api=new ReceiverApi(Settings());var q=new EbayQueue(null,s=>{});api.UseEbay(q);
                Check(EbayTests.Body<EbayReply>(Call(api,"POST","/api/worker/v1/ebay",new string('w',43),Hello())).command=="wait","Nothing queued yet.");
                api.EbayHolding="The Ebay-auto receiver is updating to 1.1.1: orders are kept here and go to COSTAR Sydney once it is back (about a minute).";
                var sent=EbayTests.Body<EbayStatus>(Call(api,"POST","/api/ebay/v1/orders",new string('e',43),Order2(),EbayTests.Extension));
                Check(sent.status=="queued"&&(sent.waiting??"").StartsWith("The Ebay-auto receiver is updating",StringComparison.Ordinal),"An order sent meanwhile is kept (queued); the extension is told why it waits.");
                Check(EbayTests.Body<EbayReply>(Call(api,"POST","/api/worker/v1/ebay",new string('w',43),Hello())).command=="wait"&&api.EbayAccepting,"The worker gets no order (while it still says it takes them).");
                api.EbayHolding=null;
                Check(EbayTests.Body<EbayReply>(Call(api,"POST","/api/worker/v1/ebay",new string('w',43),Hello())).command=="enter","Released (Cancel, or the switch didn't happen): it goes to the worker.");
            });
            Case("Ebay-auto 1.1.0 updates: Ebay-auto's own latest.json on its own GitHub folder, checked; never the Tempe helper's file or package",()=>{
                Check(Product.UpdateFolder=="https://tommyvenzin.github.io/tempe/ebay-auto/"&&EbayAutoUpdate.Folder==Product.UpdateFolder&&EbayAutoUpdate.Feed==Product.UpdateFolder+"latest.json"&&EbayAutoUpdate.FeedNow(DateTime.UtcNow).StartsWith(Product.UpdateFolder+"latest.json?now=",StringComparison.Ordinal),"Its own folder and file on GitHub, asked past the caches.");
                Check(Product.UpdateFolder.IndexOf("/helper/",StringComparison.Ordinal)<0&&Updater.Off,"Never the helper's folder; the Tempe helper's own updater stays off here.");
                var pr=Package("Receiver",N,null,null);var pw=Package("Worker",N,null,null);var rel=ReleaseFor(N,pr,pw);
                Check(pr.Length>10000&&pw.Length>10000,"Made-up packages of a realistic size.");
                Check(EbayAutoUpdate.Validate(rel,Product.WorkerMode).zip=="Ebay-auto-Worker-v"+N+".zip"&&EbayAutoUpdate.Validate(rel,Product.ReceiverMode).zip=="Ebay-auto-Receiver-v"+N+".zip","Each part its own package.");
                Reject(()=>EbayAutoUpdate.Validate(Wire.Read<EbayRelease>("{\"version\":\"2.9.10\",\"name\":\"2.9.10\",\"zip\":\"Tempe-COSTAR-Helper-v2.9.10.zip\",\"sha256\":\""+new string('a',64)+"\",\"size\":1107259}"),Product.WorkerMode),"The Tempe helper's latest.json (no product): refused.");
                var other=ReleaseFor(N,pr,pw);other.product="Tempe COSTAR Helper";Reject(()=>EbayAutoUpdate.Validate(other,Product.WorkerMode),"Another product: refused.");
                var swapped=ReleaseFor(N,pr,pw);swapped.worker=swapped.receiver;Reject(()=>EbayAutoUpdate.Validate(swapped,Product.WorkerMode),"The receiver's package for the worker: refused.");
                var tempeZip=ReleaseFor(N,pr,pw);tempeZip.worker.zip="Tempe-COSTAR-Helper-v"+N+".zip";Reject(()=>EbayAutoUpdate.Validate(tempeZip,Product.WorkerMode),"A Tempe helper ZIP name: refused.");
                var otherVersion=ReleaseFor(N,pr,pw);otherVersion.worker.zip="Ebay-auto-Worker-v0.9.9.zip";Reject(()=>EbayAutoUpdate.Validate(otherVersion,Product.WorkerMode),"A package of another version: refused.");
                var noPrint=ReleaseFor(N,pr,pw);noPrint.worker.sha256="";Reject(()=>EbayAutoUpdate.Validate(noPrint,Product.WorkerMode),"No fingerprint: refused.");
                var tiny=ReleaseFor(N,pr,pw);tiny.worker.size=500;Reject(()=>EbayAutoUpdate.Validate(tiny,Product.WorkerMode),"An odd size: refused.");
                var noWorker=ReleaseFor(N,pr,pw);noWorker.worker=null;Reject(()=>EbayAutoUpdate.Validate(noWorker,Product.WorkerMode),"No package for this part: refused.");
                Check(EbayAutoUpdate.Newer(rel)&&!EbayAutoUpdate.Newer(ReleaseFor(Product.Version,pr,pw))&&!EbayAutoUpdate.Newer(ReleaseFor("1.0.9",pr,pw)),"Only a newer version is offered.");
                Check(EbayAutoUpdate.ProtocolNote(rel,Product.WorkerMode)==null,"Same protocol: nothing to add.");
                var proto2=ReleaseFor("2.0.0",pr,pw);proto2.protocol=2;Check(EbayAutoUpdate.ProtocolNote(proto2,Product.WorkerMode).Contains("update the receiver"),"A new protocol: it says to update the other part too.");
            });
            Case("Ebay-auto 1.1.0 updates: downloaded, fingerprinted, unpacked and every file checked beside the running version; a bad download, the wrong part, version or product, or a Tempe package: nothing installed",()=>WithTestUpdates(served=>{
                var pw=Package("Worker",N,null,null);var pr=Package("Receiver",N,null,null);var rel=ReleaseFor(N,pr,pw);
                string url=EbayAutoUpdate.Folder+"Ebay-auto-Worker-v"+N+".zip";served[url]=pw;
                var said=new List<string>();
                string folder=EbayAutoUpdate.Install(rel,Product.WorkerMode,delegate(string w,int pct){said.Add(w);});
                Check(Directory.Exists(folder)&&Path.GetFileName(folder)=="Ebay-auto-Worker-v"+N&&Path.GetDirectoryName(folder)==EbayAutoUpdate.Packages&&said.Any(s=>s.StartsWith("Downloading",StringComparison.Ordinal))&&said.Any(s=>s.StartsWith("Checking",StringComparison.Ordinal)),"Downloaded, checked and unpacked beside the running version.");
                Check(Directory.GetDirectories(EbayAutoUpdate.Packages,"incoming-*").Length==0,"Nothing half-unpacked is left.");
                Check(EbayAutoUpdate.Install(rel,Product.WorkerMode,delegate{})==folder,"Installed before: used again once its files check out.");
                Directory.Delete(folder,true);
                var bad=(byte[])pw.Clone();bad[bad.Length/2]^=0x55;served[url]=bad;
                Reject(()=>EbayAutoUpdate.Install(rel,Product.WorkerMode,delegate{}),"A download that isn't what latest.json says (one byte changed): refused.");
                Check(!Directory.Exists(folder),"... and nothing is installed.");
                Action<byte[],string> refused=delegate(byte[] zip,string why) {
                    var r=ReleaseFor(N,pr,zip);served[url]=zip;
                    Reject(()=>EbayAutoUpdate.Install(r,Product.WorkerMode,delegate{}),why);
                    Check(!Directory.Exists(folder)&&Directory.GetDirectories(EbayAutoUpdate.Packages,"incoming-*").Length==0,why+": nothing installed or left.");
                };
                refused(Package("Receiver",N,null,null),"The receiver's package under the worker's name");
                refused(Package("Worker",N,top=>File.WriteAllText(Path.Combine(top,"PART.txt"),"Receiver\n"),null),"A package whose PART.txt says another part");
                refused(Package("Worker",N,top=>File.WriteAllText(Path.Combine(top,"VERSION.txt"),"0.9.9\n"),null),"A package whose VERSION.txt says another version");
                refused(Package("Worker",N,top=>File.WriteAllText(Path.Combine(top,"Source","Product.cs"),"internal const string Name=\"Tempe COSTAR Helper\";"),null),"Source that isn't Ebay-auto's");
                refused(Package("Worker",N,top=>File.WriteAllText(Path.Combine(top,"Start-RDP.cmd"),"tempe"),null),"A package with the Tempe helper's launchers");
                refused(Package("Worker",N,top=>File.Delete(Path.Combine(top,"Start-Worker.cmd")),null),"A package without its launcher");
                refused(Package("Worker",N,null,top=>File.AppendAllText(Path.Combine(top,"Launch.ps1"),"changed")),"A file changed after its list was made");
                var noise=new byte[20000];new Random(7).NextBytes(noise);
                byte[] escape;using(var m=new MemoryStream()) { using(var z=new ZipArchive(m,ZipArchiveMode.Create,true)) { var e=z.CreateEntry("../outside.txt");using(var s=e.Open()) s.Write(noise,0,noise.Length); } escape=m.ToArray(); }
                Check(escape.Length>10000,"(a realistic size, so it is the path that is refused)");
                refused(escape,"A ZIP entry that would land outside its folder");
            }));
            Case("Ebay-auto 1.1.0 updates: Update now builds before switching; a failed build keeps this version; the switch waits for a safe point (never cuts an entry) with new orders held, and Cancel takes them again",()=>WithTestUpdates(served=>{
                var pw=Package("Worker",N,null,null);var pr=Package("Receiver",N,null,null);var rel=ReleaseFor(N,pr,pw);
                served[EbayAutoUpdate.Folder+"latest.json"]=Encoding.UTF8.GetBytes(Wire.Json(rel));served[EbayAutoUpdate.Folder+"Ebay-auto-Worker-v"+N+".zip"]=pw;
                var u=new EbayAutoUpdater(Product.WorkerMode);var log=new List<string>();u.Note=delegate(string l){lock(log)log.Add(l);};
                int holds=0,unholds=0,switches=0;string notSafe="an eBay order is being entered";EbayRelease found=null;
                u.NotSafe=delegate{return notSafe;};u.Hold=delegate{holds++;};u.Unhold=delegate{unholds++;};u.Switcher=delegate{switches++;};u.Found=delegate(EbayRelease r){found=r;};
                u.Check(true);Wait(()=>u.Now==EbayAutoUpdater.Stage.Available,"the check");
                Check(u.Release.version==N&&found!=null&&found.version==N,"A newer version on GitHub is offered (and said once).");
                EbayAutoUpdate.Build=delegate(string f){return new EbayBuildOutcome {ok=false,error="made-up compiler error",startupLog=@"C:\made\up\startup.txt"};};
                u.Begin();Wait(()=>u.Now==EbayAutoUpdater.Stage.Failed,"the failed build");
                Check(u.Error.Contains("didn't build")&&u.Error.Contains("made-up compiler error")&&u.Error.Contains("still on "+Product.Version)&&holds==0&&switches==0,"A build that fails: nothing switched or held; it says why and that this version stays.");
                Check(EbayAutoUpdate.Pointed(Product.WorkerMode)==null,"A failed update moves no launcher.");
                u.Check(true);Wait(()=>u.Now==EbayAutoUpdater.Stage.Available,"the second check");
                EbayAutoUpdate.Build=delegate(string f){return new EbayBuildOutcome {ok=true,executable=Path.Combine(f,"EbayAuto.exe"),bin=f};};
                u.Begin();Wait(()=>u.Now==EbayAutoUpdater.Stage.Waiting,"the build");
                Check(holds==1,"Built and checked: new orders are held (they wait on the receiver).");
                for(int i=0;i<3;i++) u.Tick();
                Check(switches==0&&u.Words.Contains("waits")&&u.Words.Contains("being entered")&&u.Words.Contains("nothing is interrupted"),"While an order is being entered: it waits, saying why.");
                u.Cancel();Check(u.Now==EbayAutoUpdater.Stage.Available&&unholds==1,"Cancel: new orders are taken again; the update stays on offer.");
                u.Begin();Wait(()=>u.Now==EbayAutoUpdater.Stage.Waiting,"the build again");
                notSafe=null;u.Tick();
                Check(switches==1&&u.Now==EbayAutoUpdater.Stage.Switching,"At a safe point: it switches.");
                lock(log) Check(log.Any(l=>l.StartsWith("update_available",StringComparison.Ordinal))&&log.Any(l=>l.StartsWith("update_failed",StringComparison.Ordinal))&&log.Any(l=>l.StartsWith("update_built",StringComparison.Ordinal))&&log.Any(l=>l.StartsWith("update_waiting",StringComparison.Ordinal))&&log.Any(l=>l.StartsWith("update_cancelled",StringComparison.Ordinal)),"Every step is in the journey.");
                var nothing=new EbayAutoUpdater(Product.WorkerMode);served[EbayAutoUpdate.Folder+"latest.json"]=Encoding.UTF8.GetBytes(Wire.Json(ReleaseFor(Product.Version,pr,pw)));
                nothing.Check(true);Wait(()=>nothing.Now==EbayAutoUpdater.Stage.UpToDate,"the check with nothing newer");
                served.Remove(EbayAutoUpdate.Folder+"latest.json");var offline=new EbayAutoUpdater(Product.WorkerMode);
                offline.Check(true);Wait(()=>offline.Now==EbayAutoUpdater.Stage.Failed,"the check without GitHub");
                Check(offline.Error.StartsWith("Couldn't check for updates",StringComparison.Ordinal),"GitHub not reachable: said, nothing else happens.");
            }));
            Case("Ebay-auto 1.1.0 updates: the state before comes back once (fresh, this part only); a failure is kept for the version that starts again; the launchers' pointer never goes back to an older version",()=>WithTestUpdates(served=>{
                var now=DateTime.UtcNow;
                EbayAutoUpdate.SaveResume(new EbayResumeState {part=Product.WorkerMode,from=Product.Version,to=N,atUtc=now.ToString("o",CultureInfo.InvariantCulture),enabled=false,shown=true});
                Check(EbayAutoUpdate.TakeResume(Product.ReceiverMode,now)==null,"Another part's state isn't taken.");
                var s=EbayAutoUpdate.TakeResume(Product.WorkerMode,now);
                Check(s!=null&&!s.enabled&&s.shown&&s.from==Product.Version,"Its own: eBay orders paused and the window open, as they were.");
                Check(EbayAutoUpdate.TakeResume(Product.WorkerMode,now)==null,"Read once.");
                EbayAutoUpdate.SaveResume(new EbayResumeState {part=Product.ReceiverMode,atUtc=now.AddMinutes(-20).ToString("o",CultureInfo.InvariantCulture),receiving=false});
                Check(EbayAutoUpdate.TakeResume(Product.ReceiverMode,now)==null,"An old one (20 minutes) isn't taken.");
                EbayAutoUpdate.RecordFailure(new EbayUpdateFailure {part=Product.WorkerMode,from=Product.Version,to=N,why="it stopped while starting."});
                var f=EbayAutoUpdate.TakeFailure(Product.WorkerMode);Check(f!=null&&f.to==N&&EbayAutoUpdate.TakeFailure(Product.WorkerMode)==null,"The failure is kept for the version that starts again, once.");
                EbayAutoUpdate.RecordStartFailure(Product.WorkerMode,"made-up startup error");
                Check(EbayAutoUpdate.TakeStartFailure(Product.WorkerMode)=="made-up startup error"&&EbayAutoUpdate.TakeStartFailure(Product.WorkerMode)==null,"Why a new version didn't start reaches the version waiting for it.");
                Func<string,string> make=delegate(string v) { string d=Path.Combine(EbayAutoUpdate.Packages,"Ebay-auto-Worker-v"+v);Directory.CreateDirectory(d);File.WriteAllText(Path.Combine(d,"Launch.ps1"),"x");File.WriteAllText(Path.Combine(d,"VERSION.txt"),v+"\n");File.WriteAllText(Path.Combine(d,"PART.txt"),"Worker\n");return d; };
                string mine=make(Product.Version),newer=make(N);
                EbayAutoUpdate.PointAtMe(Product.WorkerMode,mine);
                Check(EbayAutoUpdate.Pointed(Product.WorkerMode)==mine&&EbayAutoUpdate.Pointed(Product.ReceiverMode)==null,"Up: every launcher of this part now starts this version (the other part's untouched).");
                File.WriteAllText(EbayAutoUpdate.PointerFile(Product.WorkerMode),newer);
                EbayAutoUpdate.PointAtMe(Product.WorkerMode,mine);
                Check(EbayAutoUpdate.Pointed(Product.WorkerMode)==newer,"Never back to an older version.");
                var start=EbayAutoUpdate.StartInfo(@"C:\x\EbayAuto.exe",@"C:\x",Product.WorkerMode,newer,4321,false,false);
                Check(start.Arguments=="--worker --after-update 4321"&&start.EnvironmentVariables["EBAYAUTO_PACKAGE"]==newer&&!start.UseShellExecute,"The new version starts in the same part, told which version waits for it, from its own package.");
                Check(EbayAutoUpdate.StartInfo(@"C:\x\EbayAuto.exe",@"C:\x",Product.ReceiverMode,null,4321,true,true).Arguments=="--receiver --restart-after 4321 --show","After a failed start: the same version again, its window open to say so.");
            }));
            Case("Ebay-auto 1.1.0 windows: compact, sized for the screen at 100-200 % scaling, placed by the clock; the layout check finds what doesn't fit",()=>{
                var frame=new System.Drawing.Size(16,39);
                foreach(var screen in new[]{new System.Drawing.Rectangle(0,0,1366,728),new System.Drawing.Rectangle(0,0,1920,1040),new System.Drawing.Rectangle(0,0,1280,680),new System.Drawing.Rectangle(0,0,2560,1400),new System.Drawing.Rectangle(-1920,0,1920,1040)})
                    foreach(var k in new[]{1f,1.25f,1.5f,1.75f,2f}) {
                        var s=EbayAutoLayout.Size(600,500,440,380,k,screen,frame);
                        var outer=new System.Drawing.Size(s[0]+frame.Width,s[1]+frame.Height);
                        var at=EbayAutoLayout.Place(outer,screen,k);
                        Check(s[2]<=s[0]&&s[3]<=s[1]&&at.X>=screen.Left&&at.Y>=screen.Top&&at.X+outer.Width<=screen.Right&&at.Y+outer.Height<=screen.Bottom,"Fits on "+screen.Width+"x"+screen.Height+" at "+(k*100)+" %.");
                        Check(at.X+outer.Width>=screen.Right-(int)Math.Round(24*k)&&at.Y+outer.Height>=screen.Bottom-(int)Math.Round(24*k),"By the clock (bottom right).");
                    }
                Check(EbayAutoLayout.Size(600,500,440,380,1f,new System.Drawing.Rectangle(0,0,1920,1040),frame)[0]==600,"At 100 % on a usual screen: 600 wide.");
                Check(EbayAutoLayout.Size(600,500,440,380,2f,new System.Drawing.Rectangle(0,0,1280,680),frame)[1]<=680-48-39,"Too tall for the screen: shrunk to it (the tabs scroll).");
                var boxes=new List<KeyValuePair<string,System.Drawing.Rectangle>>{new KeyValuePair<string,System.Drawing.Rectangle>("a",new System.Drawing.Rectangle(0,0,100,30)),new KeyValuePair<string,System.Drawing.Rectangle>("b",new System.Drawing.Rectangle(0,30,100,30))};
                Check(EbayAutoLayout.Problems(boxes,200).Count==0,"Side by side and touching: fine.");
                boxes.Add(new KeyValuePair<string,System.Drawing.Rectangle>("c",new System.Drawing.Rectangle(50,40,300,30)));
                var p=EbayAutoLayout.Problems(boxes,200);
                Check(p.Any(x=>x.StartsWith("c reaches",StringComparison.Ordinal))&&p.Any(x=>x=="b overlaps c"),"Past the page and overlapping: both said.");
            });
        }
    }
}
