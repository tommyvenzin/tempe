using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;

namespace TempeCostar {
    internal static class EbayStockTests {
        static void Check(bool yes,string why){if(!yes)throw new InvalidOperationException(why);}
        static EbayLine Line(){return EbayTests.Sample().Plan().First(x=>x.Kind=="product");}
        const string ST="WindowsForms10.STATIC.app.0.1",ED="WindowsForms10.EDIT.app.0.1",WN="WindowsForms10.Window.8.app.0.1";
        static void Pane(List<ControlInfo> s,long parent,long first,string mine,string others) {
            s.Add(EbayTests.Mk(first,parent,WN,39,395,900,130,"Frame1"));
            s.Add(EbayTests.Mk(first+1,first,WN,39,415,165,111,""));
            s.Add(EbayTests.Mk(first+2,first+1,ST,104,415,101,17,"ThisBr      OtherBrs"));
            s.Add(EbayTests.Mk(first+3,first+1,ST,39,467,66,17,"= Avail"));
            s.Add(EbayTests.Mk(first+4,first+1,ED,104,466,50,20,mine));
            s.Add(EbayTests.Mk(first+5,first+1,ED,153,466,50,20,others));
        }
        static List<ControlInfo> Screen(string available) {
            var s=EbayTests.Grid(new Dictionary<int,string[]> {
                {1,new[]{"W43116","TEST TYRE","4","140.00"}}, {3,new[]{"SECOND","OTHER TYRE","1","90.00"}}
            });
            Pane(s,500,50000,available,"100");Pane(s,502,60000,"90","200");return s;
        }
        internal static void Cases(Action<string,Action> Case) {
            Case("eBay stock: 0-2 inclusive needs ok/check; negatives need yes; above 2 is clear",()=>{
                foreach(int n in new[]{0,1,2}) {
                    Check(EbayStock.Kind(n)=="low"&&EbayStock.Answer(n,"ok")=="ok"&&EbayStock.Answer(n," CHECK ")=="check","Low-stock boundary wrong.");
                    foreach(string invalid in new[]{""," ","yes","no","skip","okay","ok check"})Check(EbayStock.Answer(n,invalid)==null,"Invalid low-stock answer allowed.");
                }
                foreach(int n in new[]{-1,-2,-200}) {
                    Check(EbayStock.Kind(n)=="negative"&&EbayStock.Answer(n," YES ")=="yes","Negative stock did not require yes.");
                    foreach(string invalid in new[]{"","ok","check","y","no"})Check(EbayStock.Answer(n,invalid)==null,"Negative stock bypassed.");
                }
                Check(EbayStock.Kind(3)=="clear"&&EbayStock.Kind(200)=="clear"&&EbayStock.Answer(3,"ok")==null,"Stock above 2 prompted.");
            });
            Case("eBay stock: exact item row and ThisBr column, never another item or OtherBrs",()=>{
                var s=Screen("2");var found=EbayStock.Read(s,1000,"W43116");
                Check(found.Found&&found.Available==2&&found.Problem==null,"Read another line or branch's stock.");
                Check(EbayStock.Read(s,1020,"SECOND").Available==90,"Second item did not use its own stock pane.");
                Check(EbayStock.Read(s,1000,"SECOND").Problem!=null,"Stale item handle accepted.");
                Check(EbayStock.Read(Screen("-3"),1000,"W43116").Available==-3,"Minus sign lost.");
                s.RemoveAll(c=>c.Handle>=50000&&c.Handle<60000);
                found=EbayStock.Read(s,1000,"W43116");Check(!found.Found&&!found.Available.HasValue,"Missing pane borrowed another line's availability.");
            });
            Case("eBay stock: unreadable, blank or ambiguous stock cannot pass",()=>{
                foreach(string value in new[]{"","?","lots","1000000"}) {
                    var found=EbayStock.Read(Screen(value),1000,"W43116");Check(found.Problem!=null&&!found.Available.HasValue,"Bad stock passed: "+value);
                }
                var s=Screen("3");s.Single(x=>x.Handle==50004).TextState="read-failed-or-timed-out";
                Check(EbayStock.Read(s,1000,"W43116").Problem!=null,"Unreadable value passed.");
                s=Screen("3");s.Add(EbayTests.Mk(50006,50001,ST,39,487,66,17,"= Avail"));
                Check(EbayStock.Read(s,1000,"W43116").Problem!=null,"Two Avail labels passed.");
                s=Screen("3");s.Single(x=>x.Handle==50002).Text="OtherBrs";
                Check(EbayStock.Read(s,1000,"W43116").Problem!=null,"Unknown branch column passed.");
            });
            Case("eBay stock: typed acknowledgement survives journal round trip but is tied to line, SKU, quantity and value",()=>{
                var line=Line();var entry=new EbayAttempt();entry.stockDecisions.Add(new EbayStockDecision {
                    line=line.Line,sku=line.Code,quantity=line.Quantity,available=2,answer="check",atUtc="2026-11-19T00:00:00Z"});
                var saved=Wire.Copy(entry).stockDecisions;
                Check(EbayStock.Approved(saved,line,2),"Retry lost the typed answer.");
                Check(!EbayStock.Approved(saved,line,1)&&!EbayStock.Approved(saved,line,-1),"Changed stock reused an old answer.");
                line.Quantity++;Check(!EbayStock.Approved(saved,line,2),"Changed quantity reused answer.");line.Quantity--;
                line.Line++;Check(!EbayStock.Approved(saved,line,2),"Another item line reused answer.");line.Line--;
                line.Code="OTHER";Check(!EbayStock.Approved(saved,line,2),"Another SKU reused answer.");
                Check(!EbayStock.Approved(null,Line(),2)&&!EbayStock.Approved(new List<EbayStockDecision>(),Line(),2),"No answer treated as approval.");
            });
            Case("eBay stock: check appends once and survives retry without removing EBAY DFE or other comment text",()=>{
                string original="EBAY DFE | existing note";
                var saved=new List<EbayStockDecision>{new EbayStockDecision {available=2,answer="check"}};
                string expected=original+" | "+EbayStock.Checking;
                Check(EbayStock.Comment(original,saved)==expected,"Existing comment lost.");
                Check(EbayStock.Comment(expected,saved)==expected,"Retry duplicated the note.");
                Check(EbayStock.Comment(expected.ToUpperInvariant(),saved)==expected.ToUpperInvariant(),"COSTAR capitalisation duplicated the note.");
                saved.Add(new EbayStockDecision {available=1,answer="ok"});Check(EbayStock.Comment(original,saved)==expected,"Later ok removed checking note.");
                foreach(string answer in new[]{"ok","yes",""}) {
                    var other=new[]{new EbayStockDecision {available=answer=="yes"?-1:2,answer=answer}};
                    Check(EbayStock.Comment(original,other)==original,"Non-check answer changed comment.");
                }
            });
            Case("eBay stock prompt: no default approval, Escape/X blocked, exact typed response enables Continue",()=>{
                using(var dialog=new EbayStockPrompt(Line(),2,()=>false)) {
                    Check(!dialog.ShowInTaskbar&&!dialog.ControlBox&&dialog.Result==null,"Prompt can be skipped by default.");
                    var input=(TextBox)typeof(EbayStockPrompt).GetField("input",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(dialog);
                    var go=(Button)typeof(EbayStockPrompt).GetField("go",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(dialog);
                    Check(!go.Enabled,"Blank input enabled Continue.");input.Text="yes";Check(!go.Enabled,"Wrong answer enabled Continue.");
                    var closing=new FormClosingEventArgs(CloseReason.UserClosing,false);
                    typeof(EbayStockPrompt).GetMethod("OnFormClosing",BindingFlags.NonPublic|BindingFlags.Instance).Invoke(dialog,new object[]{closing});
                    Check(closing.Cancel&&dialog.Result==null,"Closing approved or dismissed the prompt.");
                    bool escape=(bool)typeof(EbayStockPrompt).GetMethod("ProcessDialogKey",BindingFlags.NonPublic|BindingFlags.Instance).Invoke(dialog,new object[]{Keys.Escape});
                    Check(escape&&dialog.Result==null,"Escape bypassed the prompt.");
                    input.Text="check";Check(go.Enabled,"Typed check did not enable Continue.");
                }
                using(var dialog=new EbayStockPrompt(Line(),-1,()=>false)) {
                    var input=(TextBox)typeof(EbayStockPrompt).GetField("input",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(dialog);
                    var go=(Button)typeof(EbayStockPrompt).GetField("go",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(dialog);
                    input.Text="ok";Check(!go.Enabled,"Negative stock accepted ok.");input.Text="yes";Check(go.Enabled,"Negative stock rejected yes.");
                }
            });
        }
    }
}
