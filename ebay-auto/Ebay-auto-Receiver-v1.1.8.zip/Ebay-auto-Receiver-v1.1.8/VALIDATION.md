# Ebay-auto 1.1.8 validation - 19 November 2026

Built and tested locally on Windows. Receiver/worker 1.1.8; extension 1.5.2.

- C# 5 / .NET Framework 4.8 compilation: passed, 0 errors and 5 existing warnings.
- Application self-tests: 245 groups passed.
- Order Check self-tests: 16 groups passed, 0 failed.
- Extension payload tests: 11 groups passed.
- Extension parser/formatter tests: 14 groups passed.
- Syntax checks: all extension JavaScript files passed.

Coverage includes phone priority and bounded retries; separate Buyer/Ship to names; stock thresholds, required answers, line/branch binding, unreadable stock, journal/retry acknowledgement, comment preservation and an unshown Windows prompt's controls/close handling; stable duplicate hashing; and the shared address formatter with unit/slash notation and preserved suffixes/ranges/building details.

The packager builds fresh package folders with all current C# sources in Build.ps1, checks file hashes and source parity, and runs the real app updater verifier. Both packaged Build.ps1 scripts compile and self-test under isolated temporary app-data folders, without launching the receiver or worker. GitHub feed hashes/sizes and packaged source/extension bytes are checked. Results are included in package-checks.txt and package-updater-verification.txt.

No COSTAR window was opened or modified. No live order was sent, installed app changed, extension reloaded or release published.

Not run: full receiver/Chromium end-to-end replay, upgrade/handoff replay on an installed receiver/worker, live phone/name/address entry, stock pane on an eBay Repair Order, or visible modal interaction inside RDP. Stock reads reuse wholesale mapping and refuse unreadable/ambiguous results; live checks remain necessary.
