// 1) Turns the automatic copy panel on eBay order pages on or off, following the
//    "Open the panel automatically" tick box in the popup.
// 2) (1.4) Talks to the receiver for Send to COSTAR: pairing (address + PIN), sending an
//    order, and reading its status. Only this extension's own pages and its panel on eBay order
//    pages may ask; nothing else on the page can see the key.
//    1.5.0 (Ebay-auto): the receiver is the Ebay-auto receiver on this PC (Seb's), not Tommy's desk PC. Its address
//    takes a port (default 8811); its certificate download is on the next port. Each send and retry carries its own
//    request id (X-Request-Id), so one click can be followed through the receiver's and the worker's diagnostics.
const AUTO = {
  id: 'auto-panel',
  matches: ['https://*.ebay.com.au/mesh/ord/details*'],
  js: ['costar_send.js', 'ebay_order_console.js'],
  runAt: 'document_idle',
};

async function sync() {
  const { auto } = await chrome.storage.local.get({ auto: true });
  const regs = await chrome.scripting.getRegisteredContentScripts({ ids: [AUTO.id] });
  const on = regs.length > 0;
  if (auto && !on) await chrome.scripting.registerContentScripts([AUTO]);
  // An older version registered the panel without costar_send.js: bring it up to date.
  if (auto && on && JSON.stringify(regs[0].js || []) !== JSON.stringify(AUTO.js)) await chrome.scripting.updateContentScripts([{ id: AUTO.id, js: AUTO.js }]);
  if (!auto && on) await chrome.scripting.unregisterContentScripts({ ids: [AUTO.id] });
}

let queue = Promise.resolve();
const resync = () => {
  queue = queue.then(sync).catch(e => console.error("404 But It's Found:", e));
};

chrome.runtime.onInstalled.addListener(resync);
chrome.runtime.onStartup.addListener(resync);
chrome.storage.onChanged.addListener(changes => {
  if ('auto' in changes) resync();
});

// ---- Send to COSTAR (1.4) ----
// 1.5.0: the pairing with the Ebay-auto receiver has its own name, so the 1.4 pairing with Tommy's PC ('costarDesk') is
// never used (it is left as it was: going back to 1.4.3 still works). SWITCH: this PC's day of the first pairing with the
// Ebay-auto receiver when there was a 1.4 pairing (kept when the receiver is forgotten and paired again).
const DESK = 'ebayAutoReceiver'; // { receiver: "https://192.168.1.20:8811", key: "...", paired: "<ISO time>" }
const OLD_DESK = 'costarDesk', SWITCH = 'ebayAutoSwitch';
const NUMBER = /^\d{2}-\d{5}-\d{5}$/;
const ORDER_SCHEMA = 'tempe.ebay-order.v3'; // must equal CostarSend.SCHEMA (Tests/test-background.cjs checks both)
// 1.6.0 (20 Nov 2026): every order names its branch (Sydney Br1 or Tempe Br11, Seb's button) and how it was routed; a
// choice against the title suggestion, or with titles that couldn't be read, must carry Seb's confirmation.
const BRANCHES = [1, 11];
function routed(o) {
  const r = o.routing;
  if (!BRANCHES.includes(o.branch) || !r || typeof r !== 'object' || Array.isArray(r)) return false;
  return (r.suggested === 0 || r.suggested !== o.branch) ? r.confirmed === true : true;
}
const PORT = 8811; // 1.5.0: Ebay-auto's receiver (the Tempe desk was 8790: type its address with :8790)
const RECEIVER = 'the Ebay-auto receiver';

// "192.168.1.20", "https://192.168.1.20:8811/..." -> "https://192.168.1.20:8811"; null if not a
// shop-network (private) IPv4 address. 127.0.0.1 is allowed for testing on the same PC.
function receiverFor(text) {
  const t = String(text || '').trim().replace(/^https?:\/\//i, '').replace(/[/?#].*$/, '');
  const m = t.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})(?::(\d{1,5}))?$/);
  if (!m) return null;
  const b = m.slice(1, 5).map(Number);
  if (b.some(n => n > 255)) return null;
  const ok = b[0] === 10 || (b[0] === 192 && b[1] === 168) || (b[0] === 172 && b[1] >= 16 && b[1] <= 31) || (b[0] === 127 && b[1] === 0 && b[2] === 0 && b[3] === 1);
  if (!ok) return null;
  const port = m[5] ? Number(m[5]) : PORT;
  if (!(port >= 1 && port <= 65535)) return null;
  return `https://${b.join('.')}:${port}`;
}
const hostOf = receiver => new URL(receiver).hostname;
// The certificate download is on the receiver's next port (8812 for 8811; the Tempe desk's 8791 for 8790).
const trustUrl = receiver => `http://${hostOf(receiver)}:${(Number(new URL(receiver).port) || PORT) + 1}/trust.cer`;
// "R-" and six consonants, as the receiver and the worker name their own ids (the receiver ignores anything else).
function requestId() {
  const letters = 'BCDFGHJKLMNPQRSTVWXZ', bytes = new Uint8Array(6);
  crypto.getRandomValues(bytes);
  return 'R-' + Array.from(bytes, b => letters[b % letters.length]).join('');
}

function networkProblem(receiver, e, chromeSays) {
  const why = chromeSays ? ` (Chrome says: ${chromeSays})` : '';
  if (e && e.name === 'AbortError') return `${RECEIVER} (${new URL(receiver).host}) did not answer in time. Is it running (its icon in the notification area)?${why}`;
  return `Can't reach ${RECEIVER} securely at ${new URL(receiver).host}${why}. Check it is running (its icon in the notification area; Start-Receiver.cmd starts it), and that this PC trusts its certificate (Setup-Receiver does that on this PC; another PC: popup → Install the receiver's certificate, then restart Chrome).`;
}

// 1.4.1: Chrome's own OK for this extension to reach the receiver's address. 1.5.0: every address (also this PC's
// own) is allowed from allow.html.
const siteOf = receiver => `https://${hostOf(receiver)}/*`;
// 1.4.2: Chrome's own reason when a request to the receiver fails, for the message in the popup.
const netErrors = new Map(); // "host:port" -> { error, at }
chrome.webRequest.onErrorOccurred.addListener(d => {
  try { netErrors.set(new URL(d.url).host, { error: d.error, at: Date.now() }); } catch (e) { /* ignore */ }
}, { urls: ['https://*/*'] });
async function call(desk, method, path, body, timeoutMs, request) {
  let allowed = false;
  try { allowed = await chrome.permissions.contains({ origins: [siteOf(desk.receiver)] }); } catch (e) { allowed = false; }
  if (!allowed) throw new Error(`Chrome hasn't allowed this extension to reach ${RECEIVER} (${hostOf(desk.receiver)}) yet: click the 404 icon, then Connect, and click Allow in the tab that opens.`);
  const started = Date.now();
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs || 8000);
  const headers = {};
  if (desk.key) headers.Authorization = 'Bearer ' + desk.key;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (request) headers['X-Request-Id'] = request;
  try {
    const r = await fetch(desk.receiver + path, {
      method, headers, body: body === undefined ? undefined : JSON.stringify(body),
      signal: ctrl.signal, cache: 'no-store', credentials: 'omit', redirect: 'error',
    });
    const text = await r.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch (e) { data = null; }
    return { status: r.status, data };
  } catch (e) {
    // Chrome reports why (certificate, blocked, refused…) to webRequest just around the failure.
    await new Promise(r => setTimeout(r, 250));
    const seen = netErrors.get(new URL(desk.receiver).host);
    throw new Error(networkProblem(desk.receiver, e, seen && seen.at >= started - 100 ? seen.error : ''));
  } finally { clearTimeout(timer); }
}
const errorOf = (r, fallback) => (r.data && r.data.error) || fallback || `${RECEIVER} answered ${r.status}.`;
async function desk() { return (await chrome.storage.local.get({ [DESK]: null }))[DESK]; }
const localDay = t => `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`;

// Who may ask: this extension's popup (everything), its panel on an eBay order page (send/status).
function allowed(sender, type) {
  if (!sender || sender.id !== chrome.runtime.id) return false;
  const url = String(sender.url || '');
  const own = url.startsWith(chrome.runtime.getURL(''));
  if (own) return true;
  const ebay = /^https:\/\/([\w-]+\.)*ebay\.com\.au\//i.test(url);
  return ebay && ['costar-desk', 'costar-send', 'costar-status', 'costar-retry'].includes(type);
}

async function handle(msg) {
  switch (msg.type) {
    case 'costar-desk': {
      const s = await chrome.storage.local.get({ [DESK]: null, [OLD_DESK]: null, [SWITCH]: '' }), d = s[DESK];
      return { ok: true, paired: !!(d && d.key), receiver: d ? d.receiver : '', host: d ? new URL(d.receiver).host : '', trust: d ? trustUrl(d.receiver) : '',
        switchDay: s[SWITCH] || '', earlier: !!(s[OLD_DESK] && s[OLD_DESK].key) };
    }
    case 'costar-trust-url': {
      const receiver = receiverFor(msg.address);
      if (!receiver) return { ok: false, error: 'Type the address shown by Pair eBay PC on the Ebay-auto receiver, like 192.168.1.20:8811.' };
      return { ok: true, url: trustUrl(receiver) };
    }
    case 'costar-pair': {
      const receiver = receiverFor(msg.address);
      if (!receiver) return { ok: false, error: 'Type the address shown by Pair eBay PC on the Ebay-auto receiver, like 192.168.1.20:8811.' };
      const pin = String(msg.pin || '').replace(/\s+/g, '');
      if (!/^\d{6}$/.test(pin)) return { ok: false, error: 'Type the 6-digit PIN shown by Pair eBay PC on the Ebay-auto receiver.' };
      const r = await call({ receiver }, 'POST', '/api/ebay/v1/pair', { pin }, 10000);
      if (r.status !== 200 || !r.data || !r.data.key) return { ok: false, error: errorOf(r, 'Pairing failed.') };
      const was = await chrome.storage.local.get({ [OLD_DESK]: null, [SWITCH]: '' });
      const save = { [DESK]: { receiver, key: r.data.key, paired: new Date().toISOString() } };
      if (was[OLD_DESK] && was[OLD_DESK].key && !was[SWITCH]) save[SWITCH] = localDay(new Date());
      await chrome.storage.local.set(save);
      return { ok: true, receiver, host: new URL(receiver).host };
    }
    case 'costar-forget': {
      await chrome.storage.local.remove(DESK);
      return { ok: true };
    }
    case 'costar-health': {
      const d = await desk();
      if (!d || !d.key) return { ok: false, error: `Not paired with ${RECEIVER} yet.` };
      const r = await call(d, 'GET', '/api/ebay/v1/health');
      if (r.status !== 200 || !r.data) return { ok: false, error: errorOf(r) };
      return { ok: true, health: r.data, host: new URL(d.receiver).host };
    }
    case 'costar-send': {
      const d = await desk();
      if (!d || !d.key) return { ok: false, error: `Pair with ${RECEIVER} first: click the 404 extension icon.` };
      const o = msg.order;
      // The payload costar_send.js builds (its SCHEMA); 1.5.2/1.5.3 still checked for v1 here and refused every send.
      if (!o || o.schema !== ORDER_SCHEMA || !NUMBER.test(String(o.orderNumber || '')) || o.submissionId !== 'EBY-' + o.orderNumber || !routed(o)) return { ok: false, error: 'This order could not be prepared for COSTAR.' };
      // 1.6.0: an older receiver (1.1.8) only knows Sydney orders: ask first, and send nothing unless it takes v3.
      const h = await call(d, 'GET', '/api/ebay/v1/health', undefined, 8000);
      if (h.status !== 200 || !h.data) return { ok: false, error: errorOf(h) };
      if (h.data.orderSchema !== ORDER_SCHEMA) return { ok: false, error: `The Ebay-auto receiver (${h.data.version ? String(h.data.version).slice(0, 20) : 'an older version'}) can't take Sydney/Tempe orders yet: update both Ebay-auto parts to 1.1.9.` };
      const r = await call(d, 'POST', '/api/ebay/v1/orders', o, 10000, requestId());
      if (r.status !== 200 || !r.data) return { ok: false, error: errorOf(r), conflict: r.status === 409 };
      return { ok: true, status: r.data };
    }
    case 'costar-status': {
      const d = await desk();
      if (!d || !d.key) return { ok: false, paired: false };
      const n = String(msg.orderNumber || '');
      if (!NUMBER.test(n)) return { ok: false, error: 'No eBay order number.' };
      const r = await call(d, 'GET', '/api/ebay/v1/orders/' + n);
      if (r.status === 404) return { ok: true, known: false };
      if (r.status !== 200 || !r.data) return { ok: false, error: errorOf(r) };
      return { ok: true, known: true, status: r.data };
    }
    case 'costar-retry': {
      const d = await desk();
      if (!d || !d.key) return { ok: false, error: `Pair with ${RECEIVER} first: click the 404 extension icon.` };
      const n = String(msg.orderNumber || '');
      if (!NUMBER.test(n)) return { ok: false, error: 'No eBay order number.' };
      const r = await call(d, 'POST', '/api/ebay/v1/orders/' + n + '/retry', { orderNumber: n }, 8000, requestId());
      if (r.status !== 200 || !r.data) return { ok: false, error: errorOf(r) };
      return { ok: true, status: r.data };
    }
    default:
      return { ok: false, error: 'Unknown request.' };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string' || !msg.type.startsWith('costar-')) return false;
  if (!allowed(sender, msg.type)) { sendResponse({ ok: false, error: 'Not allowed.' }); return false; }
  handle(msg).then(sendResponse, e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
  return true; // answered asynchronously
});
