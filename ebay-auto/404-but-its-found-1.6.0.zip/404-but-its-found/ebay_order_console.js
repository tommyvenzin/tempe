// eBay order details -> click-to-copy panel (UPPERCASE, except the email)
// Use: open the order's "Order details" page, press F12 > Console, paste this, press Enter.
// A panel opens on the page: click any blue box, or press the key shown next to it, to copy that value.
// The whole block is also printed in the console and copied to the clipboard.
// (The "404 But It's Found" extension runs this same file for you on order pages; there the panel
// also has Send to COSTAR, which hands the order to the Ebay-auto receiver for COSTAR Sydney or
// COSTAR Tempe: 1.6.0, one button for each.)
(() => {
  const QUIET = !!(globalThis.chrome && chrome.runtime && chrome.runtime.id); // run by the extension
  const MON = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
  const pad = n => String(n).padStart(2, '0');
  const U = v => String(v || '').trim().toUpperCase();

  // +61 400 000 000 -> 0400000000
  const fmtPhone = raw => {
    let p = String(raw || '').replace(/[^\d+]/g, '');
    if (p.startsWith('+61')) p = '0' + p.slice(3);
    else if (p.startsWith('61') && p.length === 11) p = '0' + p.slice(2);
    return p.startsWith('00') ? p.slice(1) : p;
  };
  // 7 Oct 2026 -> 07/10/26
  const fmtDate = raw => {
    raw = String(raw || '');
    let m = raw.match(/(\d{1,2})\s+([a-z]{3})[a-z]*\.?,?\s+(\d{4})/i), d, mo, y;
    if (m) [, d, mo, y] = m;
    else if ((m = raw.match(/([a-z]{3})[a-z]*\.?\s+(\d{1,2}),?\s+(\d{4})/i))) [, mo, d, y] = m;
    if (!m || !MON[mo.toLowerCase()]) return raw.trim();
    return `${pad(d)}/${pad(MON[mo.toLowerCase()])}/${y.slice(2)}`;
  };
  // AU $1,300.00 -> 1300.00 ; Free -> 0.00
  const money = v => (/free/i.test(v) ? '0.00' : ((String(v || '').match(/\d[\d,]*(?:\.\d+)?/) || [''])[0]).replace(/,/g, ''));
  // "1,300.5" -> 130050 (Send to COSTAR's price check)
  const centsOf = v => { const m = String(v || '').replace(/,/g, '').match(/(\d+)(?:\.(\d{1,2}))?/); return m ? Number(m[1]) * 100 + (m[2] ? Number(m[2].padEnd(2, '0')) : 0) : 0; };
  // ---- street-type abbreviations -> full words (CRT -> COURT, RD -> ROAD, ST -> STREET ...) ----
  const TYPES = {};
  ('ACCESS accs|ALLEY ally|ALLEYWAY alwy|AMBLE ambl|APPROACH app|ARCADE arc|AVENUE ave av avn|BEACH bch|BEND bnd|' +
   'BOULEVARD bvd blvd bvde boul|BRIDGE bdge brdg|BROADWAY bdwy|BYPASS bypa byp|CAUSEWAY caus cswy|CENTRE ctr cntr|' +
   'CHASE ch|CIRCLE cir|CIRCUIT cct circ|CIRCUS crcs|CLOSE cl|COLONNADE clde|CONCOURSE con conc|CORNER cnr|CORSO cso|' +
   'COURT ct crt|COURTYARD ctyd|COVE cv|CRESCENT cres cr crs cresc|CREST crst|CROSS crss|CROSSING crsg|CUL-DE-SAC cds|' +
   'DEVIATION devn|DRIVE dr drv dve drve|DRIVEWAY drwy|ENTRANCE ent|ESPLANADE esp espl|ESTATE est|EXPRESSWAY exp expy|' +
   'EXTENSION extn|FAIRWAY fawy|FREEWAY fwy|FRONTAGE frtg|GARDEN gdn|GARDENS gdns|GATE gte|GLADE gld|GRANGE gra|' +
   'GREEN grn|GROVE gr gve grv|GULLY gly|HEIGHTS hts|HIGHWAY hwy hway|INTERCHANGE intg|JUNCTION jnc jct|LANDING ldg|' +
   'LANE ln|LANEWAY lnwy|LOOKOUT lkt|LOOP lp|MEANDER mndr|MOTORWAY mwy|OUTLOOK otlk|PARADE pde prde|PARK pk|' +
   'PARKLANDS pkld|PARKWAY pkwy pwy|PASSAGE psge|PATHWAY phwy|PLACE pl plc|PLAZA plz plza|POCKET pkt|POINT pnt|' +
   'PROMENADE prom|QUAY qy|RAMBLE rmbl|RANGE rnge|REACH rch|RESERVE res|RETREAT rtt rtrt|RIDGE rdge rdg|RISE rse|' +
   'RIVER rvr|ROAD rd|ROADS rds|ROADWAY rdwy|ROUND rnd|ROUTE rte|SIDING sdng|SLOPE slpe|SQUARE sq|STEPS stps|' +
   'STREET st str|STRIP strp|SUBWAY sbwy|TERRACE tce terr ter|TOLLWAY tlwy|TOWERS twrs|TRACK trk|TRAIL trl|' +
   'UNDERPASS upas|VIADUCT vdct|VIEW vw|VILLAS vlls|VISTA vsta|WALK wk wlk|WALKWAY wkwy|WAY wy|WHARF whrf')
    .split('|').forEach(g => { const [full, ...short] = g.split(' '); [full.toLowerCase(), ...short].forEach(s => { TYPES[s] = full; }); });
  const DIRS = { n: 'NORTH', s: 'SOUTH', e: 'EAST', w: 'WEST', nth: 'NORTH', sth: 'SOUTH', ne: 'NORTH EAST', nw: 'NORTH WEST',
    se: 'SOUTH EAST', sw: 'SOUTH WEST', north: 'NORTH', south: 'SOUTH', east: 'EAST', west: 'WEST', ext: 'EXTENSION', upr: 'UPPER', lwr: 'LOWER' };
  const WORDS = { mt: 'MOUNT', nth: 'NORTH', sth: 'SOUTH', upr: 'UPPER', lwr: 'LOWER', cnr: 'CORNER' }; // safe anywhere
  const bare = x => String(x || '').toLowerCase().replace(/\.+$/, '');
  const fullWords = s => String(s || '').split(/(\s+)/).map(x => WORDS[bare(x)] || x).join('');
  // Local formatting only, not address verification. Repair a leading number glued to a
  // street word when the line has a recognised street type. Keep single-letter number
  // suffixes, unit/range punctuation and ordinals. Mixed-case suffix joins (12BSmith)
  // and all-capital joins are ambiguous and stay as entered. Never split every
  // digit/letter boundary; this heuristic cannot prove a customer's intended address.
  const spaceStreetNumber = line => {
    const words = line.trim().split(/\s+/);
    let end = words.length - 1;
    if (end > 1 && DIRS[bare(words[end])] && TYPES[bare(words[end - 1])]) end--;
    if (end < 1 || !TYPES[bare(words[end])]) return line;
    return line.replace(/^((?:\d+[A-Za-z]?(?:-\d+[A-Za-z]?)?\/)?\d+(?:[A-Za-z]?-\d+)?)([A-Za-z]{3,})(?=\s)/,
      (joined, number, word) => /^(?:[a-z]{3,}|[A-Z][a-z]{2,})$/.test(word) ? number + ' ' + word : joined);
  };
  const streetNumber = '\\d+[a-z]?(?:\\s*[-\u2013]\\s*\\d+[a-z]?)?';
  const numberedStreet = new RegExp('^(' + streetNumber + ')(?:\\s*,\\s*|\\s+)(.+)$', 'i');
  const slashStreetComma = new RegExp('^(\\d+[a-z]?)\\s*/\\s*(' + streetNumber + ')\\s*,\\s*(.+)$', 'i');
  const unitOnly = /^unit\s+\d+[a-z]?\s*[.,]?\s*$/i;
  const isStreetTail = tail => {
    // Keep building/level instructions and multiple address segments intact.
    if (!/^[a-z0-9]/i.test(tail) || /[,/&]/.test(tail) || /^(unit|level|floor|building|po\s*box|locked\s*bag|parcel\s*locker)\b/i.test(tail)) return false;
    const words = tail.trim().split(/\s+/);
    let end = words.length - 1;
    if (end > 1 && DIRS[bare(words[end])] && TYPES[bare(words[end - 1])]) end--;
    return end > 0 && !!TYPES[bare(words[end])];
  };
  const compactNumber = number => number.replace(/\s+/g, '');
  const unitStreet = line => {
    const s = String(line || '').trim();
    const unit = s.match(/^unit\s+(\d+[a-z]?)(?:\s*[.,]\s*|\s+)(.+)$/i);
    if (unit) {
      const street = spaceStreetNumber(unit[2]).match(numberedStreet);
      if (street && isStreetTail(street[2])) return unit[1] + '/' + compactNumber(street[1]) + ' ' + street[2];
    }
    const slash = s.match(slashStreetComma);
    if (slash && isStreetTail(slash[3])) return slash[1] + '/' + compactNumber(slash[2]) + ' ' + slash[3];
    return s;
  };
  // only the street-type word at the end changes, so "14 St Kilda Rd" -> "14 ST KILDA ROAD" (that ST means Saint)
  const fullStreet = line => fullWords(unitStreet(line).split(/(\s*[,&]\s*)/).map(seg => {
    if (/^\s*[,&]\s*$/.test(seg)) return seg.includes(',') ? ', ' : ' & ';
    const w = spaceStreetNumber(seg.trim()).split(/\s+/);
    let i = w.length - 1;
    if (i > 1 && DIRS[bare(w[i])] && TYPES[bare(w[i - 1])]) { w[i] = DIRS[bare(w[i])]; i--; } // "Smith St N"
    if (i > 0 && TYPES[bare(w[i])]) w[i] = TYPES[bare(w[i])];
    return w.join(' ');
  }).join(''));
  // eBay may put "Unit 8." and the street on separate lines. Combine only that
  // explicit leading unit line when the same complete-address rule accepts it.
  const fullStreetLines = lines => {
    const raw = (lines || []).map(s => String(s || '').trim()).filter(Boolean);
    if (raw.length > 1 && unitOnly.test(raw[0])) {
      const joined = raw[0] + ' ' + raw[1], normal = unitStreet(joined);
      if (normal !== joined) raw.splice(0, 2, normal);
    }
    return raw.map(fullStreet);
  };

  // 1.4.3 (26 Oct): some buyers' state comes in full ("New South Wales", "Victoria"); COSTAR takes
  // the code (NSW, VIC ...), so the panel shows and sends the code. Same list as costar_send.js.
  const STATE_NAMES = { 'NEW SOUTH WALES': 'NSW', VICTORIA: 'VIC', QUEENSLAND: 'QLD', 'SOUTH AUSTRALIA': 'SA', 'WESTERN AUSTRALIA': 'WA',
    TASMANIA: 'TAS', 'NORTHERN TERRITORY': 'NT', 'AUSTRALIAN CAPITAL TERRITORY': 'ACT' };
  const stateCode = v => {
    const s = U(v).replace(/\s+/g, ' ');
    if (STATE_NAMES[s]) return STATE_NAMES[s];
    const short = s.replace(/[.\s]/g, '');
    return /^(NSW|VIC|QLD|SA|WA|TAS|NT|ACT)$/.test(short) ? short : s;
  };
  const STATE_WORDS = Object.keys(STATE_NAMES).map(n => n.replace(/ /g, '\\s+')).join('|');
  const CITY_LINE = new RegExp(`^(.+?),\\s*(${STATE_WORDS}|[a-z.]{2,6})\\s+(\\d{4})$`, 'i');

  // address lines -> street lines + "Dysart, QLD 4745" parts (drops the "ebay:..." code and the country)
  const splitAddress = lines => {
    const a = { street: [], city: '', state: '', postcode: '' };
    for (const l of lines) {
      const m = l.match(CITY_LINE);
      if (m) [, a.city, a.state, a.postcode] = m;
      else if (!/^(ebay:|australia$)/i.test(l)) a.street.push(l);
    }
    return a;
  };

  // ---- 1) the order data eBay embeds in the page ----
  const txt = n => {
    if (n == null || typeof n !== 'object') return typeof n === 'string' ? n : '';
    if (Array.isArray(n)) return n.length ? txt(n[0]) : '';
    if (Array.isArray(n.textSpans)) return n.textSpans.map(s => (s && s.text) || '').join('');
    for (const k of ['text', 'value', 'values', 'amount']) if (k in n) return txt(n[k]);
    return '';
  };
  const walk = function* (n) {
    if (Array.isArray(n)) for (const v of n) yield* walk(v);
    else if (n && typeof n === 'object') { yield n; for (const v of Object.values(n)) yield* walk(v); }
  };
  const objAt = (s, i) => { // parse the JSON object starting at s[i]
    for (let j = i, depth = 0, str = false; j < s.length; j++) {
      const c = s[j];
      if (str) { if (c === '\\') j++; else if (c === '"') str = false; }
      else if (c === '"') str = true;
      else if (c === '{' || c === '[') depth++;
      else if ((c === '}' || c === ']') && --depth === 0) {
        try { return JSON.parse(s.slice(i, j + 1)); } catch (e) { return null; }
      }
    }
    return null;
  };

  // Amounts that may be an item's price (1.4, Send to COSTAR): money in a card's price-like fields.
  // Only used for orders with several items, and only when exactly one reading adds up to the total.
  const priceCandidates = card => {
    const out = new Set();
    for (const n of walk(card)) {
      for (const [k, v] of Object.entries(n)) {
        if (!/price|amount|cost|total/i.test(k) || /ship|post|deliver|tax|fee|discount|count|qty|quantity/i.test(k)) continue;
        if (typeof v === 'number' && v > 0) { out.add(Math.round(v * 100)); continue; }
        if (v && typeof v === 'object' && typeof v.value === 'number' && v.value > 0) out.add(Math.round(v.value * 100));
        const m = txt(v).match(/\$\s?([\d,]+(?:\.\d{1,2})?)/);
        if (m && centsOf(m[1]) > 0) out.add(centsOf(m[1]));
      }
    }
    return [...out].slice(0, 12);
  };

  const fromPageData = () => {
    const mods = { OrderInfoModule: [], PaymentInfoModule: [], ShippingInfoModule: [], LineItemCard: [] };
    const re = new RegExp(`\\{\\s*"_type"\\s*:\\s*"(?:${Object.keys(mods).join('|')})"`, 'g'), seen = new Set();
    for (const sc of document.querySelectorAll('script:not([src])')) {
      const s = sc.textContent;
      for (const m of s.matchAll(re)) {
        const o = objAt(s, m.index), key = o && JSON.stringify(o);
        if (o && !seen.has(key)) { seen.add(key); mods[o._type].push(o); }
      }
    }
    const order = mods.OrderInfoModule[0];
    if (!order) return null;
    const paid = (mods.PaymentInfoModule[0] || {}).buyerPaid || {}, ship = mods.ShippingInfoModule[0] || {};

    // "Post to" block
    const r = { name: '', city: '', state: '', postcode: '' }, loose = [];
    for (const it of (ship.shippingAddress || {}).displayAddressItems || []) {
      const spans = it.textSpans || [], line = spans.map(s => s.text || '').join('').trim();
      const tpl = t => ((spans.find(s => s.template === t) || {}).text || '').trim();
      if (!line) continue;
      if (!r.name && spans.some(s => s.template === 'COPY_NAME')) r.name = line;
      else if (tpl('COPY_POSTAL_CODE') || tpl('COPY_CITY')) {
        r.city = tpl('COPY_CITY'); r.state = tpl('COPY_STATE'); r.postcode = tpl('COPY_POSTAL_CODE');
      } else if (!spans.some(s => s.template === 'COPY_COUNTRY')) loose.push(line);
    }
    if (!r.name) r.name = loose.shift() || '';
    const a = splitAddress(loose);
    r.street = a.street;
    if (!r.postcode) Object.assign(r, { city: a.city, state: a.state, postcode: a.postcode });

    const buyer = order.buyer || {}, contact = {};
    r.shippingName = r.name;
    r.name = txt(buyer.displayName).trim(); // Buyer section's real name, separate from recipient and username.
    for (const d of walk(buyer))
      if ('label' in d && 'value' in d) contact[txt(d.label).trim().toLowerCase()] = txt(d.value).trim();
    // eBay username, e.g. "scotbatte-0"
    r.user = String(((buyer.buyerModal || {}).input || {}).loginName
      || txt(buyer.loginName).replace(/\s*\(.*$/, '')).trim();

    r.postage = '';
    for (const d of walk(paid))
      if ('title' in d && 'total' in d && /^\s*(postage|shipping|delivery)/i.test(txt(d.title))) { r.postage = txt(d.total).trim(); break; }
    // Send to COSTAR: every line of what the buyer paid, so a discount, fee or tax is never missed
    r.paid = [];
    for (const d of walk(paid)) if (d !== paid && d && 'title' in d && 'total' in d && d.total !== paid.total) r.paid.push([txt(d.title).trim(), txt(d.total).trim()]);

    r.items = mods.LineItemCard.map(card => {
      const info = card.lineItemCardInfo || {}, extra = {};
      for (const d of (card.itemDetailsOverlay || {}).dataPoints || [])
        extra[txt(d.label).trim().toLowerCase()] = txt(d.value).trim();
      const spans = (info.displayCustomLabel || {}).textSpans || [];
      const sku = (spans.length > 1 ? spans.slice(1).map(s => s.text || '').join('')
        : txt(info.displayCustomLabel).replace(/^[^:]*:/, '')).trim() || extra['custom label (sku)'] || '';
      const id = (txt(info.displayItemId) || extra['item id'] || card.itemCardId || '').match(/\d{9,}/);
      const q = ((((card.quantity || {}).values || [])[0] || {}).textSpans || [])[0];
      const qty = ((q && q.text) || '').match(/^\s*(\d+)/) || (extra.quantity || '').match(/^\s*(\d+)/);
      return [sku, qty ? qty[1] : '', id ? id[0] : '', priceCandidates(card), id ? itemTitleFromPage(id[0]) : ''];
    });

    return Object.assign(r, {
      contactPhone: contact.phone || contact['phone number'] || contact['mobile phone'] || contact.mobile || '',
      shippingPhone: txt(ship.phone) || '', email: contact.email || '',
      order: txt(order.orderNumber), date: txt(order.dateSold) || txt(order.datePaid),
      total: txt((paid.total || {}).amount).trim(),
    });
  };

  // ---- 2) fallback: read the text shown on the page ----
  const fromText = t => {
    const L = t.split(/\r?\n|\r/).map(l => l.replace(/\s+/g, ' ').trim()).filter(Boolean);
    const at = re => L.findIndex(l => re.test(l));
    // value matching `val` after `label` on the same line, or on the next `win` lines
    const find = (label, val, from = 0, to = L.length, win = 2) => {
      for (let i = Math.max(from, 0); i < to; i++) {
        const m = L[i].match(label);
        if (!m) continue;
        for (const c of [L[i].slice(m[0].length), ...L.slice(i + 1, Math.min(i + 1 + win, to))]) {
          const v = c.match(val);
          if (v) return v[1];
        }
      }
      return '';
    };
    const DATE = /(\d{1,2}\s+[a-z]{3,9}\.?\s+\d{4})/i, PHONE = /(\+?\d[\d ()-]{6,}\d)/;
    const AMT = /((?:[A-Z]{2,3} ?)?\$ ?[\d,]+(?:\.\d{2})?|Free|FREE)/;
    const p = at(/^(?:Post|Ship) to\b/i), block = [];
    if (p >= 0) {
      const first = L[p].replace(/^(?:Post|Ship) to\b:?/i, '').trim();
      for (const l of [...(first ? [first] : []), ...L.slice(p + 1, p + 12)]) {
        if (/^(Phone|Buyer selected|Postage service|Tracking|Add tracking|Items?\b|Delivery|Get postage|More actions|\+?\d[\d ()-]{7,}$)/i.test(l)) break;
        if (!/^(Copy|Copied)\b/i.test(l)) block.push(l);
      }
    }
    const b = at(/^What your buyer paid/i);
    // Phone labels must stay inside their own section; never use the first phone on the whole page.
    const sectionPhone = start => {
      if (start < 0) return '';
      let end = L.length;
      for (let i = start + 1; i < L.length; i++) {
        if (/^(?:(?:Post|Ship) to\b|Shipping$|Buyer$|(?:Show |Hide )?Contact info(?:rmation)?\b|What your buyer paid\b|Order details$|Items?$|Buyer selected\b|Postage service\b|Tracking\b)/i.test(L[i])) { end = i; break; }
      }
      return find(/^(?:Phone(?: number)?|Mobile(?: phone)?)\b:?/i, PHONE, start, end);
    };
    const contactAt = at(/^(?:Show |Hide )?Contact info(?:rmation)?\b/i);
    const contactPhone = sectionPhone(contactAt >= 0 ? contactAt : at(/^Buyer:?$/i));
    const shippingPhone = sectionPhone(p);
    // Send to COSTAR, page text only: words in what the buyer paid that mean the prices can't be read safely
    const paidNote = [];
    if (b >= 0) for (let i = b + 1; i < Math.min(L.length, b + 14) && !/^Order total\b/i.test(L[i]); i++)
      if (/discount|coupon|promo|voucher|gift card|credit|refund|fee|tax|gst|adjust/i.test(L[i])) paidNote.push(L[i].slice(0, 40));
    const ids = L.map((l, k) => (/^Item ID\b/i.test(l) ? k : -1)).filter(k => k >= 0);
    // "Buyer" / "scott batten" / "scotbatte-0 (296)" - the username is the one-word line next to "(296)"
    const findUser = () => {
      for (let i0 = 0; i0 < L.length; i0++) {
        if (!/^Buyer\b:?(?!\s*(paid|selected))/i.test(L[i0])) continue;
        for (let i = i0 + 1; i < Math.min(i0 + 5, L.length); i++) {
          const m = L[i].match(/^([\w.*-]+)\s*(\(\s*[\d,]+\s*\))?$/);
          if (m && (m[2] || /^\(\s*[\d,]+\s*\)/.test(L[i + 1] || ''))) return m[1];
        }
      }
      return '';
    };
    const user = findUser();
    const findBuyerName = () => {
      if (!user) return '';
      const start = at(/^Buyer:?$/i);
      if (start < 0) return '';
      const names = [];
      for (let i = start + 1; i < Math.min(start + 6, L.length); i++) {
        const line = L[i];
        if (line === user || line.startsWith(user + ' (')) return names.length === 1 ? names[0] : '';
        if (/^(?:Show |Hide )?Contact info\b|^(?:Ship|Post) to\b|^Shipping$|^Phone\b|^Order\b|^\(/i.test(line)) break;
        if (!/^(?:Copy|Copied)$/i.test(line)) names.push(line);
      }
      return '';
    };
    return Object.assign(splitAddress(block.slice(1)), {
      paid: null, paidNote,
      name: findBuyerName(), shippingName: block[0] || '',
      order: (t.match(/\b(\d{2}-\d{5}-\d{5})\b/) || [])[1] || '',
      email: (t.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/) || [])[0] || '',
      date: find(/^Sold\b:?/i, DATE) || find(/^Buyer paid\b:?/i, DATE),
      contactPhone, shippingPhone,
      user,
      postage: find(/^(Postage|Shipping)\b:?/i, AMT, b, L.length, 1),
      total: find(/^Order total\b:?/i, AMT, b, L.length, 1),
      items: ids.map((k, n) => {
        let sku = '', title = '';
        for (let q = k; q >= Math.max(n ? ids[n - 1] + 1 : 0, k - 4); q--) {
          const m = L[q].match(/^Custom label \(SKU\):?\s*(.*)/i);
          if (m) {
            sku = m[1].trim() || (q + 1 < k && /^[A-Z0-9][A-Z0-9._-]*$/i.test(L[q + 1]) ? L[q + 1] : '');
            title = q > 0 ? L[q - 1] : '';
            break;
          }
        }
        const qty = find(/^Quantity\b:?/i, /^\s*(\d+)\b/, k, n + 1 < ids.length ? ids[n + 1] : L.length);
        // Send to COSTAR: amounts around this item (checked against the total before use)
        const cands = [], to = n + 1 < ids.length ? ids[n + 1] : Math.min(L.length, k + 12);
        for (let q = n ? ids[n - 1] + 1 : Math.max(0, k - 8); q < to; q++)
          for (const m of L[q].matchAll(/\$\s?([\d,]+(?:\.\d{2})?)/g)) if (centsOf(m[1]) > 0) cands.push(centsOf(m[1]));
        return [sku, qty, find(/^Item ID\b:?/i, /(\d{9,})/, k, k + 2), cands, title];
      }),
    });
  };

  // 1.5.3: use only the title belonging to this item ID, never another item's wheel wording.
  const itemTitleFromPage = id => {
    const titles = new Set();
    for (const link of document.querySelectorAll('a[href*="/itm/"]')) {
      const found = String(link.href || '').match(/\/itm\/(?:[^/?#]+\/)?(\d{9,15})(?:[/?#]|$)/);
      const title = String(link.textContent || '').replace(/\s+/g, ' ').trim();
      if (found && found[1] === id && title) titles.add(title);
    }
    return titles.size > 1 ? null : titles.size === 1 ? [...titles][0] : '';
  };
  const costarSku = (raw, title) => {
    const sku = U(raw), name = U(title);
    // A single numeric listing suffix on a wheel-only listing. Package and accessory codes keep their shape.
    if (!/\b(?:WHEELS?|RIMS?)\b/.test(name) ||
        /\b(?:PACKAGES?|TYRES?|TIRES?|NUTS?|BOLTS?|SPACERS?|ADAPT[EO]RS?|CAPS?|COVERS?|VALVES?|SENSORS?|TPMS|BEARINGS?|HUBS?|STUDS?|LOCKS?|REPAIRS?|STEERING|BALANCERS?|DECALS?|STICKERS?|TRIMS?|RINGS?|EMBLEMS?|TOOLS?|SOCKETS?|LUGS?|WEIGHTS?|STEMS?|HARDWARE|KITS?)\b/.test(name)) return sku;
    const match = sku.match(/^([A-Z0-9]+)-(\d+)$/);
    return match && /\d/.test(match[1]) ? match[1] : sku;
  };

  // ---- read the order ----
  const shown = document.body.innerText;
  let d = null;
  try { d = fromPageData(); } catch (e) { console.warn('Page data not readable, using page text instead.', e); }
  // only trust the embedded data if it's for the order on screen
  if (d && !(d.order && (shown.includes(d.order) || location.href.includes(d.order)))) d = null;
  let t = {};
  try { t = fromText(shown); } catch (e) { /* keep page data */ }
  if (!d) d = t;
  else {
    for (const k in t) if (!d[k] || !d[k].length) d[k] = t[k]; // fill any gaps from the page text
    for (const it of d.items || []) { // and the amounts shown next to each item
      const seen = (t.items || []).find(x => x[2] && x[2] === it[2]);
      if (seen && seen[3]) it[3] = [...new Set([...(it[3] || []), ...seen[3]])];
      if (seen && it[4] !== null && !it[4] && U(seen[0]) === U(it[0])) it[4] = seen[4] || '';
    }
  }
  d.phone = d.contactPhone || ''; // Contact info is always the main/copy phone.
  d.state = stateCode(d.state);
  if (!d.order) {
    if (!QUIET) console.warn('No eBay order found here. Open the order\'s "Order details" page and run this again.');
    return;
  }

  // ---- the lines: plain text, {copy, key} = copy box (click it or press its key), {kbd} = key label ----
  const KEYS = ['1', '2', '3', '4', '5', '6', 'q', 'w', 'a', 's', 'd', 'f', 'z'];
  const C = (v, key, label = true) => (v ? { copy: v, key, label } : '(not found)');
  const joinParts = (groups, sep) => groups.flatMap((g, i) => (i ? [sep, ...g] : g));
  const date = fmtDate(d.date), items = d.items || [], addr = [];
  const addAddr = (sep, v, key) => { if (v) addr.push(...(addr.length ? [sep] : []), C(U(v), key)); };
  fullStreetLines(d.street).forEach(s => addAddr(', ', s, '3'));
  addAddr(', ', fullWords(d.city), '4');
  addAddr(', ', d.state, '5');
  addAddr(d.state ? ' ' : ', ', d.postcode, '6');
  // everything in capitals except the email
  const lines = [
    [C(fmtPhone(d.phone), '1')],
    [C(U(d.name), '2')],
    addr.length ? addr : ['(not found)'],
    [C(String(d.email || '').trim(), 'q')],
    [C(U(d.order), 'w')],
    items.length ? joinParts(items.map(([sku, qty, id, prices, title]) => [sku ? C(costarSku(sku, title), 'a') : 'NO SKU', ` + ${qty || '?'}`]), ', ') : ['(not found)'],
    items.length ? joinParts(items.map(it => [C(it[2], 'd')]), ', ') : ['(not found)'],
[C(U(d.user), 's')],
    [{ kbd: 'f' }, 'FREIGHT $', C(money(d.postage), 'f', false)],
    [C(d.date ? `${U(d.order)} ${date}` : '', 'z')],
    [`TOTAL ${U(d.total) || '(not found)'}`],
  ];
  const plain = lines.map(parts => parts.map(p => (typeof p === 'string' ? p : p.copy || '')).join('')).join('\n');

  // ---- panel on the page ----
  const ID = 'ebay-order-copy-panel';
  const old = document.getElementById(ID);
  if (old) old.remove();
  const host = document.createElement('div');
  host.id = ID;
  host.style.cssText = 'position:fixed;top:12px;right:12px;z-index:2147483647';
  const root = host.attachShadow({ mode: 'open' });
  const el = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  };
  root.append(el('style', null, `
    :host { all: initial; }
    .panel { font: 14px/1.5 "Market Sans", Arial, sans-serif; color: #191919; background: #fff;
      border: 1px solid #c7c7c7; border-radius: 12px; box-shadow: 0 8px 28px rgba(0,0,0,.2);
      width: 480px; max-width: calc(100vw - 24px); max-height: calc(100vh - 24px); overflow: auto; }
    .head { display: flex; align-items: center; gap: 8px; padding: 10px 12px;
      border-bottom: 1px solid #e5e5e5; cursor: move; user-select: none; }
    .title { flex: 1; font-weight: 700; }
    button { font: inherit; cursor: pointer; }
    .btn { font-size: 13px; padding: 3px 12px; border: 1px solid #3665f3; border-radius: 16px;
      background: #fff; color: #3665f3; }
    .btn:hover { background: #f1f4ff; }
    .x { border-color: transparent; color: #555; font-size: 20px; line-height: 1; padding: 0 6px; }
    .body { padding: 8px 12px; }
    .line { padding: 3px 0; }
    .pair { display: inline-flex; align-items: baseline; max-width: 100%; }
    .chip { min-width: 0; padding: 0 6px; border: 1px solid #b5c8fb; border-radius: 6px; background: #eef2ff;
      color: #1d3fbf; overflow-wrap: anywhere; text-align: left; }
    .chip:hover { border-color: #3665f3; background: #dfe7ff; }
    .done, .done:hover { border-color: #1e8e3e; background: #e6f4ea; color: #0d652d; }
    kbd { display: inline-block; min-width: 12px; margin-right: 4px; padding: 0 4px; border: 1px solid #c7c7c7;
      border-bottom-width: 2px; border-radius: 4px; background: #f7f7f7; color: #555;
      font: 600 11px/16px Consolas, ui-monospace, monospace; text-align: center; vertical-align: 1px; }
    button:focus-visible { outline: 2px solid #3665f3; outline-offset: 1px; }
    .foot { padding: 8px 12px; border-top: 1px solid #e5e5e5; font-size: 12px; color: #707070; }
    .foot.ok { color: #1e8e3e; }
    .foot.bad { color: #d50b0b; }
    .send { display: grid; gap: 6px; padding: 10px 12px; border-top: 1px solid #e5e5e5; background: #fafbff; }
    .send .top { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .btn.primary { border-color: #3665f3; background: #3665f3; color: #fff; font-weight: 700; padding: 5px 16px; }
    .btn.primary:hover:not(:disabled) { background: #2a55d6; }
    .btn:disabled, .btn:disabled:hover { border-color: #c7c7c7; background: #e5e5e5; color: #707070; cursor: default; }
    .info { font-size: 12px; color: #444; }
    .state { font-size: 13px; padding: 6px 8px; border-radius: 6px; background: #f2f2f2; overflow-wrap: anywhere; }
    .state:empty { display: none; }
    .state.ok { background: #e6f4ea; color: #0d652d; }
    .state.wait { background: #eef2ff; color: #1d3fbf; }
    .state.work { background: #e0f2fe; color: #03507a; }
    .state.check { background: #fef3c7; color: #8a4b00; }
    .state.bad { background: #fde8e8; color: #b3261e; }
    [hidden] { display: none !important; }
    .choice { display: inline-flex; gap: 8px; flex-wrap: wrap; }
    .titles { color: #707070; overflow-wrap: anywhere; }
    .confirm { display: grid; gap: 6px; padding: 8px; border: 1px solid #f2c94c; border-radius: 6px; background: #fef3c7; }
    .question { font-size: 13px; color: #8a4b00; font-weight: 700; }`));
  const panel = el('div', 'panel'), head = el('div', 'head'), body = el('div', 'body');
  const status = el('div', 'foot', 'Click a blue box, or press its key, to copy it');
  const allBtn = el('button', 'btn', 'Copy all'), closeBtn = el('button', 'btn x', '×');
  closeBtn.title = 'Close';
  head.append(el('span', 'title', `Order ${U(d.order)}`), allBtn, closeBtn);

  const toClipboard = async v => {
    try { await navigator.clipboard.writeText(v); return true; } catch (e) {
      const ta = el('textarea');
      ta.value = v;
      ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
      root.append(ta);
      ta.select();
      let ok = false;
      try { ok = document.execCommand('copy'); } catch (e2) { /* not allowed */ }
      ta.remove();
      return ok;
    }
  };
  const doCopy = async (v, btn) => {
    const ok = await toClipboard(v);
    status.textContent = ok ? (btn === allBtn ? 'Copied all lines' : `Copied: ${v}`)
      : 'Could not copy - select the text and press Ctrl+C';
    status.className = `foot ${ok ? 'ok' : 'bad'}`;
    if (ok) { btn.classList.add('done'); setTimeout(() => btn.classList.remove('done'), 1200); }
  };

  const byKey = {}; // key -> its copy boxes (more than one when the order has several items)
  for (const parts of lines) {
    const row = el('div', 'line');
    for (const p of parts) {
      if (typeof p === 'string') { row.append(p); continue; }
      if (p.kbd) { row.append(el('kbd', null, p.kbd.toUpperCase())); continue; }
      const pair = el('span', 'pair'); // keeps the key label next to its box when the line wraps
      if (p.label) pair.append(el('kbd', null, p.key.toUpperCase()));
      const b = el('button', 'chip', p.copy);
      b.title = `Click or press ${p.key.toUpperCase()} to copy`;
      b.addEventListener('click', () => doCopy(p.copy, b));
      (byKey[p.key] = byKey[p.key] || []).push({ v: p.copy, b });
      pair.append(b);
      row.append(pair);
    }
    body.append(row);
  }
  allBtn.addEventListener('click', () => doCopy(plain, allBtn));
  for (const it of items) {
    const raw = U(it[0]), mapped = costarSku(it[0], it[4]);
    if (mapped !== raw) body.append(el('div', 'info', `Wheel SKU: ${raw} → ${mapped} for COSTAR`));
  }
  closeBtn.addEventListener('click', () => host.remove());

  // one key press = copy (not while typing in a box on the page; pressing again cycles through items)
  const turn = {};
  const onKey = e => {
    if (!host.isConnected) { window.removeEventListener('keydown', onKey, true); return; } // panel closed
    if (e.ctrlKey || e.altKey || e.metaKey || e.repeat) return;
    const k = String(e.key || '').toLowerCase();
    if (!KEYS.includes(k)) return;
    const t = e.composedPath()[0] || e.target;
    if (t && (t.isContentEditable || /^(input|textarea|select)$/i.test(t.tagName || ''))) return;
    e.preventDefault();
    e.stopPropagation();
    const list = byKey[k];
    if (!list) {
      status.textContent = `Nothing to copy for ${k.toUpperCase()} on this page`;
      status.className = 'foot bad';
      return;
    }
    turn[k] = ((turn[k] ?? -1) + 1) % list.length;
    doCopy(list[turn[k]].v, list[turn[k]].b);
  };
  window.addEventListener('keydown', onKey, true);
  head.addEventListener('pointerdown', e => { // drag the panel by its header
    if (e.target.closest('button')) return;
    const r = host.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top;
    const move = ev => Object.assign(host.style, { left: `${ev.clientX - dx}px`, top: `${ev.clientY - dy}px`, right: 'auto' });
    const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  });
  panel.append(head, body, status);

  // ---- Send to COSTAR (1.4, in the extension only): the order goes to the receiver (1.5.0: the Ebay-auto receiver on
  // this PC), whose worker enters it into a new Repair Order in COSTAR. The receiver never takes an order twice.
  // 1.6.0 (20 Nov 2026): two buttons, "Sydney — Branch 1" and "Tempe — Branch 11". The item titles suggest one (a whole
  // word wheel(s)/package(s) suggests Tempe; CostarSend.suggest), shown as the primary button with why. Seb still
  // chooses: the suggested one sends at once; the other one (or either, when the titles couldn't be read) asks in the
  // panel first, and Cancel sends nothing. Send again (retry) never carries a branch: the receiver keeps the original.
  const CS = globalThis.CostarSend;
  if (QUIET && CS && chrome.runtime && chrome.runtime.sendMessage) {
    const helpers = { U, fmtPhone, fmtDate, fullStreet, fullStreetLines, fullWords, money, costarSku };
    const sender = "404 But It's Found " + chrome.runtime.getManifest().version;
    const built = CS.build(d, helpers, sender), number = U(d.order);
    const sug = built.order ? built.suggestion : null;
    const box = el('div', 'send'), top = el('div', 'top'), sendBtn = el('button', 'btn primary', 'Send to COSTAR');
    const LABEL = { 1: 'Sydney — Branch 1', 11: 'Tempe — Branch 11' };
    const branchBtn = { 1: el('button', 'btn', LABEL[1]), 11: el('button', 'btn', LABEL[11]) };
    branchBtn[1].id = 'costar-send-1'; branchBtn[11].id = 'costar-send-11';
    const choice = el('span', 'choice');
    choice.append(branchBtn[1], branchBtn[11]);
    const info = el('span', 'info', built.order ? built.summary : ''), line = el('div', 'state', '');
    const why = el('div', 'info why', sug ? sug.text : ''), titles = el('div', 'info titles', '');
    // What the routing looked at: each item's own title (or that it wasn't read).
    if (built.order) titles.textContent = 'Titles: ' + built.order.items.map(it => `${it.sku}: ${it.title ? (it.title.length > 90 ? it.title.slice(0, 89) + '…' : it.title) : '(title not read)'}`).join(' | ');
    const ask1 = el('div', 'confirm'), askText = el('div', 'question', ''), askRow = el('div', 'top');
    const yesBtn = el('button', 'btn primary', 'Yes'), noBtn = el('button', 'btn', 'Cancel');
    yesBtn.id = 'costar-confirm'; noBtn.id = 'costar-cancel';
    askRow.append(yesBtn, noBtn); ask1.append(askText, askRow); ask1.hidden = true;
    sendBtn.id = 'costar-send'; sendBtn.hidden = true;
    top.append(choice, sendBtn, info); box.append(top, why, titles, ask1, line);
    panel.insertBefore(box, status);
    const ask = msg => new Promise(resolve => {
      try { chrome.runtime.sendMessage(msg, r => resolve(r || { ok: false, error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'No answer from the extension. Reload this page.' })); }
      catch (e) { resolve({ ok: false, error: 'The extension was updated: reload this page.' }); }
    });
    let polling = null, busy = false, anyway = false;
    const show = (tone, text) => { line.textContent = text; line.className = 'state ' + (tone || ''); };
    // The single status button (Checking…, Sent ✓, In COSTAR ✓, Send again …): the branch buttons are hidden behind it.
    const button = (label, action) => {
      choice.hidden = true; ask1.hidden = true; why.hidden = true; sendBtn.hidden = false;
      sendBtn.textContent = label; sendBtn.disabled = !action; sendBtn.onclick = action || null;
    };
    // The two branch buttons; on: they can be clicked (never while a send is in flight).
    const choose = on => {
      sendBtn.hidden = true; ask1.hidden = true; choice.hidden = false; why.hidden = !why.textContent;
      for (const b of [1, 11]) {
        const btn = branchBtn[b];
        btn.textContent = LABEL[b] + (anyway ? ' anyway' : '');
        btn.className = 'btn' + (sug && sug.suggested === b ? ' primary' : '');
        btn.disabled = !on || busy;
        btn.onclick = on ? () => pick(b) : null;
      }
    };
    const stopPolling = () => { if (polling) { clearInterval(polling); polling = null; } };
    const apply = s => {
      const v = CS.describe(s);
      show(v.tone, v.text);
      // A removed order may go again, in either branch (the receiver starts a new Repair Order): Seb chooses again.
      if (v.again && v.resend) { anyway = false; choose(true); }
      else if (v.again) button('Send again', retryOrder);
      else button(s.status === 'ready_for_review' ? 'In COSTAR ✓' : v.handed ? 'Needs you' : 'Sent ✓', null);
      if (s.status === 'queued' || s.status === 'entering') startPolling(); else stopPolling();
    };
    // A branch button: the suggested one sends at once, the other one (or unread titles) asks in the panel first.
    const pick = b => {
      if (busy) return;
      const v = CS.decide(sug, b);
      if (v.error) { show('bad', 'Not sent: ' + v.error); return; }
      if (!v.confirm) { sendOrder(b, false); return; }
      choice.hidden = true; ask1.hidden = false;
      askText.textContent = v.question;
      yesBtn.textContent = 'Yes, send to ' + CS.branchName(b);
      yesBtn.disabled = false; noBtn.disabled = false;
      yesBtn.onclick = () => { yesBtn.disabled = true; noBtn.disabled = true; sendOrder(b, true); };
      noBtn.onclick = () => choose(true); // nothing is sent
      yesBtn.focus();
    };
    const startPolling = () => {
      if (polling) return;
      const until = Date.now() + 20 * 60 * 1000;
      polling = setInterval(async () => {
        if (!host.isConnected || Date.now() > until) { stopPolling(); return; }
        const r = await ask({ type: 'costar-status', orderNumber: number });
        if (r.ok && r.known) apply(r.status);
      }, 3000);
    };
    async function sendOrder(b, confirmed) {
      if (busy) return;
      const now = CS.build(d, helpers, sender); // a fresh send time on every click
      if (!now.order) return;
      const o = CS.withBranch(now.order, b, confirmed);
      if (o.error) { show('bad', 'Not sent: ' + o.error); choose(true); return; }
      busy = true; choose(false); show('work', 'Sending to the Ebay-auto receiver for COSTAR ' + CS.branchName(b) + '…');
      let r;
      try { r = await ask({ type: 'costar-send', order: o }); } finally { busy = false; }
      if (!r.ok) { show('bad', 'Not sent: ' + r.error); choose(true); return; }
      apply(r.status);
    }
    async function retryOrder() {
      button('Sending…', null); show('work', 'Asking the Ebay-auto receiver to try again…');
      const r = await ask({ type: 'costar-retry', orderNumber: number });
      if (!r.ok) { show('bad', 'Not sent again: ' + r.error); button('Send again', retryOrder); return; }
      apply(r.status);
    }
    (async () => {
      if (!built.order) { choose(false); show('bad', "Can't send to COSTAR: " + built.problems.join('; ') + '. Enter it by hand.'); return; }
      const desk = await ask({ type: 'costar-desk' });
      if (!desk.ok || !desk.paired) { choose(false); show('wait', 'Pair with the Ebay-auto receiver first: click the 404 extension icon.'); return; }
      button('Checking…', null); show('wait', 'Checking the Ebay-auto receiver…');
      // A known order (the receiver has it) shows its status and no branch buttons, so it can't be created twice.
      const r = await ask({ type: 'costar-status', orderNumber: number });
      if (r.ok && r.known) { apply(r.status); return; }
      show(r.ok ? '' : 'bad', r.ok ? '' : r.error);
      // 1.5.0: from before this PC switched from Tommy's PC to the Ebay-auto receiver: it may be in COSTAR already
      // (Tommy's PC only ever sent to COSTAR Sydney).
      if (r.ok && CS.beforeSwitch(built.order.orderDate, desk.switchDay)) {
        show('check', `Dated on or before the switch to Ebay-auto (${desk.switchDay}): this order may already be in COSTAR Sydney from Tommy's PC. Check COSTAR first, and send it only if it isn't there.`);
        anyway = true;
      }
      choose(true);
    })();
  }
  root.append(panel);
  document.body.append(host);

  // ---- console + clipboard (only when pasted into the console) ----
  if (QUIET) return;
  console.log(plain);
  if (plain.includes('(not found)')) console.warn('Some values were not found on this page - see "(not found)".');
  console.log('%cPanel added to the page - click a blue box or press its key (click the page first).', 'color:#3665f3;font-weight:bold');
  try {
    copy(plain); // DevTools console helper
    console.log('%cAll lines copied to the clipboard too.', 'color:#1a7f37;font-weight:bold');
  } catch (e) { /* not run from the console - use "Copy all" in the panel */ }
})();
