# Ebay-auto 1.1.9 validation - 20 November 2026

Receiver and worker 1.1.9 (protocol 2, payload `tempe.ebay-order.v3`); extension 1.6.0. Built and tested locally on Windows 11 with Windows PowerShell 5.1, the .NET Framework 4.8 C# compiler and Node 24. These totals come from a fresh re-run on 20 November 2026, just before packaging.

## Automated results

| Suite | Result |
|---|---|
| C# 5 / .NET Framework 4.8 compile (`/langversion:5`) | passed: 0 errors, 5 existing warnings |
| Application self-tests (`EbayAuto.exe --self-test`, short TEMP) | 258 groups passed, no FAIL lines, exit code 0 |
| Order Check self-tests | 16 groups passed, 0 failed |
| Extension payload (`test-costar-send.cjs`) | 13 groups passed |
| Extension parser/formatter (`test-phone-parser.cjs`) | 20 groups passed |
| Extension background gate (`test-background.cjs`) | 9 groups passed |
| Sydney/Tempe routing (`test-routing.cjs`) | 8 groups passed |
| Release configuration (`test-release-config.cjs`, now also checks the Node packager) | 5 checks passed |
| JavaScript syntax (`node --check`, every `Extension/*.js` and `Tests/*.cjs`) | all passed |
| End-to-end (`e2e-branch.cjs`) | 20 scenarios passed |

Total: 349 automated groups and checks passed, 0 failed.

The end-to-end test runs the real extension panel in headless Chrome, then the real `background.js`, then the real receiver code in a test host, then a scripted worker. It covers both buttons, the confirmations, Cancel, double-send protection, the cross-branch CONFLICT, Remove-then-resend in the other branch, per-branch waiting, and a stored 1.1.8 (v2) receipt sent again for Sydney.

The self-tests cover:

- Routing rule parity between C# and JavaScript.
- Strict v3 validation: suggestion mismatch, missing confirmation and unknown branch are refused.
- A v2 send is refused with the update message; a stored v2 receipt is accepted as Sydney.
- The legacy canonical JSON and hash are byte-identical to 1.1.8, including the title-less resend of a 1.1.8 order.
- Branch conflicts in every receipt state.
- Poll picks only ready branches, oldest first, one order entering at a time across branches.
- Protocol 1 and protocol 2 mismatch messages.
- Health and status fields.
- The per-branch COSTAR choice: earliest start time, sticky while valid, busy keeps its choice, restart, never the other branch.
- The worker's branch-mismatch refusals, branch-named stock prompt text, and the per-branch "COSTAR not open" alerts.

The release packager (`Tests/package-release.cjs`) rebuilds both package folders, checks every file hash, source parity and ZIP bytes, runs the real updater verifier, and runs each packaged Build.ps1 in isolated temporary app data. It also installs the GitHub bundle through the one-click update code of both 1.1.9 and the published 1.1.8: the feed checks, size and SHA-256, the real ZIP extractor, layout and every file hash. That code reads the bundle's files instead of GitHub, and doesn't build, start or switch over anything. Its results are in `release/package-checks-1.1.9.txt`.

**Known intermittent test (existing since 1.1.0, not a 1.1.9 change).** In one of about eight self-test runs on 20 November, the case "Ebay-auto 1.1.0 updates: Update now builds before switching ..." failed once with "A newer version on GitHub is offered (and said once)". That run was the first packaged Receiver Build.ps1. The run after it, and four more runs, passed.

The cause is in the test's timing, not the product. `EbayAutoUpdater` sets the stage to Available inside its lock, then calls `Found` just after the lock is released (`EbayAutoUpdate.cs` around lines 279-284). The test checks `found` as soon as it sees Available, so on a busy PC the call can arrive a moment late. In the app, `Found` only shows the tray balloon. The source was left unchanged for this release. The fix would be for the test to wait for `found` too.

No COSTAR window was opened or modified. No real receiver or worker was launched. No live order was sent, no installed app or extension was changed, and nothing was published.

## NOT tested

- **COSTAR typing in Tempe (Br11).** It has never been run there: Rebill to EBAY, Ship Via DFE, the stock pane layout and ThisBr reading, Next # and the `<number> DFE` clipboard, and account creation in Br11 are all unverified in Tempe. The worker uses the same maps as Sydney.
- **Real Chrome extension install.** Loading the unpacked 1.6.0 extension, its permissions, pairing and the TLS connection to the real receiver were not tested. The e2e test uses plain HTTP to a test host.
- **The stock prompt inside Seb's Remote Desktop session.** It has not been shown there, for either branch.
- **Two real COSTAR instances per branch**, and Sydney and Tempe open together in one Remote Desktop session. The choice logic is tested only with simulated process lists.
- **A live update from 1.1.8.** The published 1.1.8 updater code was tested reading the 1.1.9 feed and installing both packages from the bundle's files. These were not tested: downloading from GitHub Pages, the build and switch-over on the shop PCs, the protocol 1 to 2 hand-over between real parts, and real queued 1.1.8 orders after the update. Simulated stored receipts were tested.
- **Window behaviour of the new branch lines.** The receiver and worker windows, tray and alerts with the new branch lines were not looked at on screen.

Watch the first live Tempe order from start to finish, and the first Sydney order after the update.
