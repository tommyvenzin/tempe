# Ebay-auto 1.1.9 - 20 November 2026

Receiver and worker 1.1.9, with 404 extension 1.6.0. Packaged and checked locally; not published yet.

## Patch notes (20 November 2026)

- **Sydney or Tempe per order.** Each eBay order goes into COSTAR Sydney (Br1) or COSTAR Tempe (Br11). Seb chooses with two buttons in the 404 extension 1.6.0 panel: "Sydney — Branch 1" and "Tempe — Branch 11". Both branches use the same receiver on Seb's PC and the same worker in his Remote Desktop session. (Tempe here is not Tommy's PC or the separate Tempe helper.)
- **Suggestion from the item titles.** Tempe is suggested when any item's own title has the whole word wheel, wheels, package or packages (any capitals). Otherwise Sydney is suggested. When a title can't be read reliably, nothing is suggested. Mixed orders stay one order. The panel shows the titles it looked at and why it suggests a branch.
- **Confirm in the panel.** Choosing against the suggestion, or choosing when titles couldn't be read, opens an in-panel question with "Yes, send to ..." and "Cancel". Cancel sends nothing. Both buttons are disabled while a send is in flight. An order the receiver already has shows its status and no send buttons.
- **Never moved between branches.** A second send for the other branch is refused with CONFLICT, even while the order is still queued. To change the branch, Remove the order on the receiver (only if nothing was typed), then send it again. The worker keeps one chosen COSTAR per branch (the earliest started instance), types only into the order's own branch, and never changes a COSTAR window's branch.
- **One order at a time across both branches.** An order waits, saying which branch it needs and why, when its COSTAR isn't open or ready. Meanwhile an order for the other branch can go first.
- **Branch named everywhere.** Statuses, the receiver window, the worker window, the stock prompt (for example `Tempe (Br11) ThisBr Avail: 2`), alerts and diagnostics name the order's branch. Package SKUs are never trimmed; the wheel SKU fix is unchanged.
- **Schema and duplicate-check fix.** The order payload is now `tempe.ebay-order.v3`: it adds `branch`, `routing` and each item's own `title`. Stored 1.1.8 (`v2`) orders keep their duplicate-order hashes. A 1.1.8 Sydney order sent again with the same details from extension 1.6.0 is recognised as the same order, not a CONFLICT: titles are left out of that comparison, as 1.1.8 never had them. A v2 send from an older extension is refused with a message to update.

## Installing this update

1. Finish any order currently being entered.
2. Update the receiver on Seb's PC **and** the worker in the Remote Desktop session to 1.1.9. Transport protocol 2 means **both parts must be updated**: a 1.1.8 part gets no orders from a 1.1.9 part, and the waiting message says which part to update.
3. Replace the contents of the existing unpacked extension folder with `404-but-its-found-1.6.0.zip`, then click Reload on its Chrome extensions card. Keep the same folder so pairing stays in place. Extension 1.6.0 won't send to a receiver older than 1.1.9.
4. Refresh the eBay page before sending another order.
5. For Tempe orders, also open COSTAR Tempe (Br11) in the worker's Remote Desktop session.

Old queued orders from 1.1.8 stay Sydney orders. They are never reclassified, and a 1.1.9 worker enters them in COSTAR Sydney (Br1).

## Existing behaviour retained

Everything else is unchanged:

- Each order starts from Work-in-Progress with Add New, as a new Repair Order.
- Billing X uses the Order/Buyer name. Delivery Y uses the Ship to recipient, phone and address.
- Phone lookup order: Contact info first, then Ship to, then back to Contact info. Account creation checks are unchanged.
- PO# is the order number. Comment is EBAY DFE (plus the stock note). Ship Via is DFE. Rebill to EBAY with Card# and the Terms 7INV check.
- Written By and Salesperson are SA. eBay prices and quantities are used; line plan products, F freight, M E per item, M BUY username and M DFE are unchanged.
- The stock thresholds are unchanged. The unknown-SKU hand-over is unchanged.
- Successful Repair Orders stay open. Next # and the "<number> DFE" clipboard text are unchanged, and the helper still says "ez, next".
- Unit/slash address formatting, one-click GitHub updates, tray icons, pairing and diagnostics are unchanged.

## Earlier releases

- **Extension 1.5.3 (19 November 2026):** wheel-only listings drop a single numeric SKU suffix (`903189096S-11897` becomes `903189096S`). This is included in 1.6.0.
- **1.1.8 (19 November 2026):** Contact info phone first with Ship to fallback; Order/Buyer name for billing and Ship to for delivery; stock check after quantity and price (above 2 continues, 0-2 needs `ok`/`check`, negative needs `yes`); `check` adds `low stock - currently checking`; uppercase unit/slash addresses; stable duplicate hashes; Repair Orders stay open.

Full history is in `CHANGES.md`. The published 1.1.8 and 1.5.3 ZIPs in `release/` are kept as they were.

## Bundle contents

- Receiver ZIP for Seb's PC and worker ZIP for the Remote Desktop session.
- Chrome extension ZIP `404-but-its-found-1.6.0.zip`.
- Source backup with tests.
- GitHub upload ZIP, whose `ebay-auto` folder is ready to copy over the repository's `ebay-auto` folder.

Packaging doesn't publish, install, reload Chrome or send an order.

## Validation and first live check

See `VALIDATION.md` for the exact automated totals and what has not been tested. COSTAR Tempe (Br11) has never been typed into by this helper. Watch the first live Tempe order from start to finish: Rebill EBAY, Ship Via DFE, the stock pane, Next # and any new account.

## Local development

- `Tests/run-local.ps1` compiles and tests without opening or typing into COSTAR. It needs PowerShell 7 for `Start-Process -Environment`; in Windows PowerShell 5.1, set TEMP/TMP to a short folder and run the same steps by hand.
- `node Tests/package-release.cjs` builds and verifies the release ZIPs without Python. `Tests/package-release.py` is the equivalent Python script.
- Packaging starts from the published 1.1.8 package folders in `release/`.
