// Ebay-auto 1.0.0 (16 Nov 2026): Seb's own eBay → COSTAR Sydney app, built from the Tempe COSTAR helper 2.9.10 (commit
// f77a254) and the 404 But It's Found extension 1.4.3. Everything that names this installation is here, so nothing it
// keeps (settings, queue, journals, keys, logs, Startup files, single-instance names) can meet the Tempe helper's.
// 1.1.0 (16 Nov 2026): one-click updates from its own folder on Tommy's GitHub page, COSTAR Sydney chosen by itself among
// several COSTARs (the earliest-started Sydney, kept while valid), compact windows that hide in the notification area.
// 1.1.1 (17 Nov 2026): each verified Repair Order is left open for Seb to check and close ("ez, next"); earlier
// installations' "Close each Repair Order" tick is turned off once.
// 1.1.2 (17 Nov 2026): a new buyer gets a COSTAR customer account (after Customer Not found, every detail COSTAR's form asks
// for given; once per order, ever), from the Tempe helper 2.9.11's shared code (NewAccount.cs, Runner.NewAccount.cs).
// 1.1.3 (18 Nov 2026): the account's state as the Tempe helper 2.9.12 takes it (AuStates.cs): the one written in the address
// first (eBay always gives one), else looked up by suburb and postcode; where it came from is in the diagnostics.
// 1.1.4 (18 Nov 2026): an eBay address with no state gets in: the state is looked up by its suburb and postcode before the
// receiver's and the worker's checks (the Tempe helper 2.9.13's EbayModel.cs), the order kept as sent; not found: refused,
// saying why (the 404 extension 1.5.1 sends such an order; 1.5.0 stopped it on the eBay page).
// 1.1.5 (18 Nov 2026): the account step looks at COSTAR's customer search and new-customer form again until COSTAR has
// finished drawing them (the Tempe helper 2.9.14's NewAccount.cs / Runner.NewAccount.cs: on 18 Nov 08:15 the search was
// judged part-drawn and the order stopped).
// 1.1.6 (18 Nov 2026): once an order is verified and its Repair Order left open, the Repair Order's number is copied to the
// clipboard as "<number> DFE" and read back before "ez, next" (EbayRoNumber.cs; Ebay-auto only, the Tempe helper unchanged).
// A Repair Order with no number yet is left for Seb (Next # is looked at, not pressed, until a map shows what it does).
// 1.1.7 (18 Nov 2026): a blank number box gets Next # pressed once (Tommy: no window opens, the box fills), then the number
// is copied as in 1.1.6. 1.1.6 was never uploaded: 1.1.7 has all of it.
using System;
using System.IO;

namespace TempeCostar {
    internal static class Product {
        internal const string Name="Ebay-auto";
        internal const string Version="1.1.7";
        // What the receiver and the worker say to each other (EbayHello / EbayReply). 1.0.0 sent no number: it is 1 too. A
        // part only works with another that speaks a protocol it knows (MinProtocol..Protocol); otherwise orders wait,
        // saying which part to update.
        internal const int Protocol=1,MinProtocol=1;
        internal static int ProtocolOf(int said) { return said<=0?1:said; }
        internal static bool Speaks(int said) { int p=ProtocolOf(said);return p>=MinProtocol&&p<=Protocol; }
        // The helper version the eBay code comes from.
        internal const string Based="2.9.14";
        // %LOCALAPPDATA%\EbayAuto: receiver\ and worker\ (settings, queue, journal: encrypted), diagnostics\, reports\,
        // settings.json, runtime\ (builds), startup-*.txt. The Tempe helper's is TempeMobileCostar: never read or written.
        internal const string DataFolder="EbayAuto";
        internal static string Home { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),DataFolder); } }
        // The two parts. Receiver: Seb's physical PC (the extension sends to it). Worker: inside Seb's Remote Desktop
        // session, beside COSTAR Sydney.
        internal const string ReceiverMode="Receiver",WorkerMode="Worker";
        // Default ports, away from the Tempe desk (8790/8791) and Order Check (8795-8804). Chosen in Setup-Receiver.
        internal const int ReceiverPort=8811,TrustPort=8812;
        // One of each part per Windows login (as the Tempe helper does for its own).
        internal const string MutexPrefix=@"Global\EbayAuto_";
        // Startup folder files ("Start with Windows").
        internal const string StartupPrefix="Ebay-auto - ";
        // Diagnostics ZIPs: Ebay-auto-Receiver-Diagnostics-<time>.zip, Ebay-auto-Worker-Diagnostics-<time>.zip.
        internal const string DiagnosticsPrefix="Ebay-auto-";
        internal const string DiagnosticsPattern="Ebay-auto-*-Diagnostics-*.zip";
        // The Tempe helper's own updater (Updater.cs, compiled in for the shared code) has no feed here: it never asks
        // anything. Ebay-auto's updater (EbayAutoUpdate.cs) asks only its own folder on Tommy's GitHub page (the tempe
        // repository's ebay-auto folder, served by GitHub Pages beside the helper's own folder, which it never reads).
        internal const string UpdateFeed="";
        internal const string UpdateFolder="https://tommyvenzin.github.io/tempe/ebay-auto/";
        // Packages: Ebay-auto-Receiver-v1.1.0.zip, Ebay-auto-Worker-v1.1.0.zip (one top folder of the same name).
        internal const string PackagePrefix="Ebay-auto-v";
        internal static string PackageName(string part,Version version) { return Name+"-"+part+"-v"+version.ToString(3); }
        // The launcher each part's package has.
        internal static string Starter(string part) { return "Start-"+part+".cmd"; }
        // What the messages call the two parts.
        internal const string ReceiverWords="the Ebay-auto receiver (Seb's PC)",WorkerWords="the Ebay-auto worker (in Remote Desktop)";
        internal static string Title { get { return Name+" "+Version; } }
        // The signal a second start of a part sets so the running one opens its window (per Windows session).
        internal static string ShowEventName(string part) { return @"Local\EbayAuto_Show_"+part; }
        // 1.1.0: set by a new version once it is up after an update (the version it replaces waits for it).
        internal static string ReadyEventName(string part) { return @"Local\EbayAuto_Ready_"+part; }
    }
    // The rules for where the two parts may talk (pure: the self-tests check them).
    internal static class EbayAutoRules {
        // The address and port the receiver may use: this PC's private LAN IPv4 address (never 127.0.0.1: inside Remote
        // Desktop that is the Remote Desktop server, not this PC), a port with the next one free for its certificate, away
        // from the Tempe helper's (desk 8790-8791, Order Check 8795-8804).
        internal static int ReceiverSetup(string address,string portText) {
            System.Net.IPAddress ip;
            Order.Require(System.Net.IPAddress.TryParse(address??"",out ip)&&ip.AddressFamily==System.Net.Sockets.AddressFamily.InterNetwork&&NetworkRules.Private(ip)&&!System.Net.IPAddress.IsLoopback(ip),"Use this PC's private LAN IPv4 address (not 127.0.0.1: the worker inside Remote Desktop must reach this PC over the network).");
            int port;Order.Require(Int32.TryParse(portText??"",out port)&&port>=1024&&port<=65534,"The receiver's port must be 1024 to 65534 (the next one is its certificate port).");
            Order.Require(!Tempe(port)&&!Tempe(port+1),"That port is the Tempe helper's (8790-8791, Order Check 8795-8804): choose another (8811 is Ebay-auto's own).");
            return port;
        }
        static bool Tempe(int port) { return port==8790||port==8791||(port>=8795&&port<=8804); }
        // A connection the worker can use: the receiver's private LAN address (never localhost: inside Remote Desktop that is
        // the Remote Desktop server, not Seb's PC), a key, and the receiver's certificate fingerprint.
        internal static void WorkerConnection(WorkerSettings c) {
            NetworkRules.Worker(c);
            Uri u=new Uri(c.baseUrl);System.Net.IPAddress ip;
            bool loopback=u.Host.Equals("localhost",StringComparison.OrdinalIgnoreCase)||(System.Net.IPAddress.TryParse(u.Host,out ip)&&System.Net.IPAddress.IsLoopback(ip));
            Order.Require(!loopback,"That connection names this PC itself ("+u.Host+"): the worker needs Seb's PC's LAN address. Run Setup-Receiver on Seb's PC (it picks its LAN address), then copy the connection again.");
        }
    }
}
