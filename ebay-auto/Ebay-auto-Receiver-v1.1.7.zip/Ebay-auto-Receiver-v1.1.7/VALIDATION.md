# Ebay-auto 1.1.7: what was tested, and how

## Windows pre-publication checks - 18 Nov 2026

After the original author supplied the packages, the publication review corrected the simultaneous number-and-popup result and added a final blocking-window check before clipboard copy. Both parts contain the same corrected source. The original author checks below describe the supplied build; they were not all repeated on this correction.

- Windows .NET Framework C# 5 compile: 0 errors, the same 5 warnings as the previously published build.
- Corrected build self-tests: 230 groups passed, plus all 16 Order Check groups; exit code 0.
- The number-and-popup regression is included in the existing 1.1.7 group. The final live-window guard was reviewed in code.
- Package hashes and all internal file hashes were regenerated and checked after the correction. Receiver and worker source match.
- Tests ran in isolated temporary storage. COSTAR was not opened or modified. Next # and clipboard transfer through Seb's Remote Desktop still require the first live check.

## Original author validation

The original author validation below ran in Claude's Linux sandbox (1.1.7, 1.1.6, 1.1.5, 1.1.4 and 1.1.3 on 18 Nov 2026, 1.1.2 and 1.1.1 on 17 Nov, 1.1.0 on 16 Nov), with made-up orders, made-up
COSTAR scans and made-up packages only (plus the real release files). **Nothing was run on Windows, inside Remote
Desktop, or against COSTAR, and no Windows window was ever shown.** These are automated tests of the code; the live
checks Seb's PCs still need are listed for each version.

Levels used here and in FEATURES.md:
- **S**: source level: the app's own self-tests (the same ones Build.ps1 runs on each PC before starting, and before an
  update is switched to).
- **E**: end-to-end here: the real 404 extension (1.5.0; 1.5.1 from 1.1.4) in Chromium (headless) on made-up eBay order pages, talking over
  TLS to the **real receiver code** (Tests/receiver_harness.ps1); the worker is **played by the test script** over the
  worker API, sending what the real worker sends. For updates: the **real update code** against the **real release
  files** served over HTTP the way GitHub Pages serves them (Tests/update_replay.ps1), and `Launch.ps1` itself under
  PowerShell 7.
- **C**: compiled and read only.
- **L**: needs live Windows / Remote Desktop / COSTAR: **not tested**.

## 1.1.7: Next # pressed once when the box is blank

Tommy, 18 Nov 12:09 / 12:12: no window opens, the box fills; order done -> press Next # -> copy the value + DFE. The rest is
1.1.6 (below; published earlier on 18 Nov).

| Run | What | Result |
|---|---|---|
| Compile | Roslyn at C# 5 against the five reference sets, Build.ps1's 64 files | 0 errors; the same 3 warnings, each set. CS0135/CS0136: nothing |
| Self-tests | 1.1.6's cases plus 1 group (after Next #: the box read until it fills; never filling within 10 s; a COSTAR window over the Repair Order ending the wait; the words for each); the look keeps the box's window and Next # (greyed with a number, enabled when blank, as the maps); the identity case now 1.1.7 | 226 pass, the same 4 Windows-only fails (1.1.6: 225; all still pass) |
| Mutations | 6 deliberate bugs in what 1.1.7 adds: a blank box taken for the number, the window check gone, a longer wait, the words for no number, Next #'s state or the box's window not kept. 1.1.6's rules are unchanged (its 26 were caught on 1.1.6) | 6 of 6 caught |
| Node | Tests/test-costar-send.cjs (the extension 1.5.1, unchanged) | 12 groups pass |
| End-to-end | 1.1.6's checks, V13 now with the worker's 1.1.7 words when no number comes after Next # (CHECK BY HAND, amber, never "ez, next"; the job released) | 82 checks pass |
| Update replay | The real 1.1.7 upload set over HTTP with 1.1.0's to 1.1.6's own code: each offers 1.1.7, downloads and checks both parts, the build stood in for, new orders held, switched at the safe point; the Tempe helper 2.9.14's files, a changed byte and the other part's package refused; Launch.ps1's hand-over and fallback. Run again with 1.1.7's code (nothing offered) | 28 checks pass, each of the eight |
| Scans | Both packages, the upload set and the source bundle: no tokens, webhooks, keys, pairing, connection or record files, no Tests in the packages or the upload set; only made-up order, phone, e-mail and Repair Order numbers; Tommy's example number nowhere; no number from the saved diagnostics in what 1.1.7 adds (the same 25 in the shared files from the Tempe helper) | clean |

| Asked | Tested here | Level | Not tested |
|---|---|---|---|
| Order done -> press Next # -> copy the number in the box + " DFE" | A blank box at both looks (S, 1.1.6); Next # pressed only if it is the button right beside the box with COSTAR's words "Ne&xt #", enabled, in this order's Repair Order, in front with no COSTAR window over it (read: `PressNextOnce`); then the copy as 1.1.6 | S, C | **L**: Next # on COSTAR Sydney |
| Never click it twice | One press, `nextPressed` set before it; nothing in the wait presses (read; the wait takes no press) | S, C | L |
| Wait for the number, read it back | `RoNumber.WaitForNumber` (mutation-checked): every 0.15 s, 10 s at most, stopped by a COSTAR window over the Repair Order; then two looks and `Judge` as 1.1.6 | S | L |
| Not obtained: tell Seb, log why | CHECK BY HAND words for not pressed / no number / a window (S); `ro_number_next` (read) | S, C | L |

## 1.1.6: the Repair Order's number on the clipboard (published earlier on 18 Nov; included in 1.1.7)

Asked by Tommy on 18 Nov (10:13). Ebay-auto only (`EbayRoNumber.cs` new; `Runner.EbayAuto.cs`, `Runner.Ebay.cs`,
`EbayWorker.cs`, `EbayAutoDiagnostics.cs`); the Tempe helper is unchanged.

| Run | What | Result |
|---|---|---|
| Compile | Roslyn at C# 5 against the five reference sets, Build.ps1's 64 files (`EbayRoNumber.cs` added) | 0 errors; the same 3 warnings, each set. CS0135/CS0136: nothing |
| Self-tests | 1.1.5's cases plus 5 new groups: the number box and Next # found on made-up controls laid out as the maps; every refusal; the clipboard set and read back (with stand-ins for the clipboard); the worker's journal; the words, shapes and counts. The identity case now 1.1.6 | 225 pass, the same 4 Windows-only fails (1.1.5: 220; all still pass) |
| Mutations | 26 deliberate bugs, run on the final code: each refusal taken out (changed, blank, copied before, PO#, read-only box, not read, the second look not checked), Unicode digits taken for 0-9, a line break after DFE, a number copied or kept unchecked, the digits in the shape, a box that takes typing taken for the number box, a button further along or on another line taken for Next #, Next #'s words without the &, the clipboard read back loosely, fewer tries, no pause between them, the "taken off" check loosened, the journal's refusals, last text, kept entries and limit, the words for no number yet, the summary's count | 26 of 26 caught |
| Node | Tests/test-costar-send.cjs (the extension 1.5.1, unchanged) | 12 groups pass |
| End-to-end | 1.1.5's 74 checks plus V13: the worker's real words (through the harness: `RoNumber.Judge`, `RoNumber.Words`, `EbayFinish.Words`) for a Repair Order with no number yet: CHECK BY HAND, amber on the eBay page, never "ez, next", the job released and the next order handed out at once; for a number copied: "ez, next", green; the receiver's journey: no 8-digit number | 82 checks pass |
| Update replay | The real 1.1.6 upload set over HTTP with 1.1.0's, 1.1.1's, 1.1.2's, 1.1.3's, 1.1.4's and 1.1.5's own code: each offers 1.1.6, downloads and checks both parts (81 and 79 files installed), the build stood in for, new orders held, switched at the safe point; the Tempe helper 2.9.14's files, a changed byte and the other part's package refused; Launch.ps1's hand-over and fallback. Run again with 1.1.6's code (nothing offered) | 28 checks pass, each of the seven |
| Scans | Both packages, the upload set, the source bundle and the extension ZIP: no tokens, webhooks, keys, pairing, connection or record files, no Tests in the packages or the upload set; only made-up order numbers, phones, e-mails and Repair Order numbers; Tommy's example number (10:13) nowhere; no number from the saved diagnostics in what 1.1.6 adds (the same 25 in the shared files from the Tempe helper as in 1.1.5) | clean |
| Maps | The 39 saved maps (28 Oct to 17 Nov) read again for the number box and Next # (shapes and positions only) | CHANGES.md 1.1.6, "What the maps show" |

| Asked | Tested here | Level | Not tested |
|---|---|---|---|
| Read the number in the box at the top of the CURRENT Repair Order; keep one that is there | `RoNumber.Look` / `Judge` (mutation-checked): the read-only box beside the one RepairOrder label, at two looks with the order's PO#, the same both times, 8 digits (0-9), kept as shown | S | **L**: COSTAR Sydney's box on real orders |
| Blank: press Next #, wait for the number, read it back, never press twice | **Not built**: no map shows what pressing Next # does (the capture below). A blank number: nothing copied, CHECK BY HAND (press Next #, then copy it); Next # found and its state recorded, never pressed | S | the capture |
| Copy the number, one space, DFE; leading zeros kept; nothing else | `RoNumber.Text`; `RoClipboard.CopyChecked` with stand-ins (set, read back exactly, 3 tries 250 ms apart) | S | **L**: the Windows clipboard inside Remote Desktop and on Seb's PC |
| Keep it open; "ez, next" once copied; the job released; the next order in its own new Repair Order | `EbayFinish.Words`; V13 | S, E | L |
| Not obtained: the reason logged, Seb told; never a blank or a previous order's number; the order never entered again | every refusal (mutation-checked); the previous order's text taken off only while the clipboard holds exactly it; numbers copied before refused (the journal, mutation-checked); the step never throws (read) | S, C | L |
| Diagnostics: the reads, Next #, the clipboard's success or failure | `ro_number`, `ro_number_copy`, `ro_number_clear`, `roNumber` (read); `RoNumberCounts` | S, C | L |

### Next # (answered by Tommy, 18 Nov 12:09)

1.1.6 asked for maps of Next # being pressed. Not needed: "it will not show any popup, just click and the box will be
filled with numbers". 1.1.7 presses it (above).

## 1.1.5: the account step waits for COSTAR's windows to be drawn

The same code as the Tempe helper 2.9.14 (its VALIDATION.md has the 18 Nov 08:15 diagnostics and the review): the
new-customer account step looked at COSTAR's customer search 0.2 s after the magnifier, while COSTAR was still drawing
it, and stopped. Now that window and the new-customer form are looked at again until drawn.

| Run | What | Result |
|---|---|---|
| Compile | Roslyn at C# 5 against the five reference sets, Build.ps1's 63 files | 0 errors; the same 3 warnings, each set. CS0135/CS0136: nothing |
| Self-tests | 1.1.4's cases plus the 2 window cases of 2.9.14; the identity case now 1.1.5 | 220 pass, the same 4 Windows-only fails (1.1.4: 218; all still pass) |
| Mutations | 7 deliberate bugs in the window wait, run through the Tempe helper 2.9.14's self-tests (the same files) | 7 of 7 caught |
| Node | Tests/test-costar-send.cjs (the extension 1.5.1, unchanged) | 12 groups pass |
| End-to-end | 1.1.4's 74 checks (the account step isn't reached: no COSTAR here) | 74 checks pass |
| Update replay | The real 1.1.5 upload set over HTTP with 1.1.0's, 1.1.1's, 1.1.2's, 1.1.3's and 1.1.4's own code: each offers 1.1.5, downloads and checks both parts, the build stood in for, new orders held, switched at the safe point; the Tempe helper 2.9.14's files, a changed byte and the other part's package refused; Launch.ps1's hand-over and fallback. Run again with 1.1.5's code (nothing offered) | 28 checks pass, each of the six |
| Scans | Both packages, the upload set, the source bundle and the extension ZIP: no tokens, webhooks, keys, pairing, connection or record files, no Tests in the packages or the upload set; only made-up order numbers, phones and e-mails; no number from the saved diagnostics (18 Nov 08:36 included) in what 1.1.5 adds | clean |

| Asked | Tested here | Level | Not tested |
|---|---|---|---|
| COSTAR's customer search and new-customer form looked at once drawn; nothing pressed on one that isn't recognised | `WindowLooks.WhenComplete` (mutation-checked): the 08:15 sequence (part-drawn, then complete), pauses in the drawing, a window that isn't the search (left once unchanged for 1.5 s), one still changing (10 s), one that closes | S | **L**: COSTAR Sydney's drawing times |
| When each window was known, in the diagnostics | `new_account` events (looks, ms, controls; never words) | C | L |

## 1.1.4: an eBay order with no state (not uploaded: part of 1.1.5)

The same code as the Tempe helper 2.9.13 (its VALIDATION.md has the paths and the review), with the 404 extension 1.5.1.
Before 1.1.4 an eBay order with no state never got as far as the lookup: the extension stopped it ("the state was not
found"), and the receiver and the worker refused it ("The state must be …"). Now the extension sends it, and every
check finds its state by suburb and postcode first; the order is kept exactly as sent.

| Run | What | Result |
|---|---|---|
| Compile | Roslyn at C# 5 against the five reference sets, Build.ps1's 63 files | 0 errors; the same 3 warnings, each set. CS0135/CS0136: nothing |
| Self-tests | 1.1.3's cases plus the 6 cases of 2.9.13 (deliveries, refusals, pickups, the page's copy, the eBay order's checks and entry, the receiver's queue); the identity case now 1.1.4; the diagnostics case with the state's source | 218 pass, the same 4 Windows-only fails (1.1.3: 212; all 212 still pass) |
| Mutations | 15 deliberate bugs in the shared code (through the Tempe helper 2.9.13's self-tests: the same files), 2 in Ebay-auto's diagnostics words, 2 in the extension | 19 of 19 caught |
| Node | Tests/test-costar-send.cjs: 1.1.3's 11 groups plus 1.5.1's no-state group | 12 groups pass |
| End-to-end | 1.1.3's 67 checks plus V12 (7): the real extension 1.5.1 and the real receiver code; the worker's own check and entry run on the claim as received (receiver_harness.ps1 CLAIM) | 74 checks pass |
| Update replay | The real 1.1.4 upload set over HTTP with 1.1.0's, 1.1.1's, 1.1.2's and 1.1.3's own code: each offers 1.1.4, downloads and checks both parts, the build stood in for, new orders held, switched at the safe point; the Tempe helper 2.9.13's files, a changed byte and the other part's package refused; Launch.ps1's hand-over and fallback. Run again with 1.1.4's code (nothing offered) | 28 checks pass, each of the five |
| Scans | Both packages, the upload set, the source bundle and the extension ZIP: no tokens, webhooks, keys, pairing, connection or record files, no Tests in the packages or the upload set; only made-up order numbers, phones and e-mails; no number from the saved diagnostics in what 1.1.4 adds (only the old ones in three shared helper files, as before) | clean |

| Asked | Tested here | Level | Not tested |
|---|---|---|---|
| Resolve a missing state before the checks that need it (the real sending and receiving paths) | V12: an order with no state on the page is sent by the extension, queued by the real receiver, and the worker's own check takes it; the entry fills billing and Ship to with the looked-up state | E, S | **L** |
| Never replace a supplied state; full names and abbreviations | `EbayOrder.AddressState`, `EngineOrder` (a written NSW with a VIC suburb stays NSW; "New South Wales" is NSW) | S (mutation-checked) | |
| Only an unambiguous match; never NSW or the store | Texas 4385 (two states) and a suburb not under its postcode: refused before queueing, the eBay page saying why (V12) | E, S (mutation-checked) | |
| Keep the order and its duplicate check as before | The receiver keeps the order as sent (no state), its content hash unchanged; a second Send is the same order | S (mutation-checked) | |
| Diagnostics: where the state came from | `received` and `claim_received` journey words, `send_invalid` with why; `billingState`, `deliveryState`, `address_states`, review.json; never the state, suburb or postcode (V12 checks the journey) | E, S, C | L |
| Everything else unchanged | 1.1.3's 212 self-tests and 67 end-to-end checks | S, E | |

## 1.1.3: the state for a new buyer's account (not uploaded: part of 1.1.4)

The same code as the Tempe helper 2.9.12 (its VALIDATION.md has the choice of the address list and the review). eBay
orders always carry a state written in the address (the extension requires one, unchanged), so for eBay the state is
always "from the customer's address"; the lookup is there for an order without one.

| Run | What | Result |
|---|---|---|
| Compile | Roslyn at C# 5 against the five reference sets, Build.ps1's 63 files (1.1.2: 61) | 0 errors; the same 3 warnings, each set. CS0135/CS0136: nothing |
| Self-tests | 1.1.2's cases plus the 3 state cases of 2.9.12; the identity case now 1.1.3 | 212 pass, the same 4 Windows-only fails (1.1.2: 209; all 209 still pass) |
| Mutations | 12 deliberate bugs in the state code, run through the Tempe helper 2.9.12's self-tests (the same files) | 12 of 12 caught |
| Node | Tests/test-costar-send.cjs (the extension, unchanged) | 11 groups pass |
| End-to-end | 1.1.2's 67 checks | 67 checks pass |
| Update replay | The real 1.1.3 upload set over HTTP with 1.1.0's, 1.1.1's and 1.1.2's own code: each offers 1.1.3, downloads and checks both parts, the build stood in for, new orders held, switched at the safe point; the Tempe helper 2.9.12's files, a changed byte and the other part's package refused; Launch.ps1's hand-over and fallback. Run again with 1.1.3's code (nothing offered) | 28 checks pass, each of the four |
| Scans | Both packages, the upload set and the source bundle: no tokens, webhooks, keys, pairing, connection or record files, no Tests in the packages or the upload set; only made-up order numbers, phones and e-mails; no number from the saved diagnostics in what 1.1.3 adds | clean |

| Asked | Tested here | Level | Not tested |
|---|---|---|---|
| The state written in the address first (code or full name, any case, extra spaces or dots), never replaced | `AuState.Code`, `AuPlaces.Resolve` (mutation-checked) | S | |
| Missing: looked up by suburb + postcode, one state only, never from the postcode alone, the store or COSTAR's default; none: no account, the order goes on | `AuPlaces.Resolve` over the address list (shared postcodes by suburb; a suburb in two states; not found) | S (mutation-checked) | **L** |
| Diagnostics: from the address or the lookup, or why none | `new_account_state`, `newAccountState`, review.json `NewAccountState` | C | L |
| The trigger and X → account → Y unchanged | `MaybeMakeAccount` decides as in 1.1.2 over the customer with that state | C, S | L |

## 1.1.2: a new buyer's COSTAR customer account

The same account code as the Tempe helper 2.9.11 (its VALIDATION.md has the review and the code-level detail). The
sequence was captured on Tempe on 17 Nov (10 maps, lengths only); the self-tests use those maps' geometry with made-up
words.

| Run | What | Result |
|---|---|---|
| Compile | Roslyn at C# 5 against the five reference sets (4.8 as Build.ps1 and as the .rsp, 4.6.2, 4.7.1, 4.7.2), Build.ps1's 61 files (1.1.1: 58) | 0 errors; the same 3 warnings, each set. The old compiler's one-meaning-per-name rule (CS0135/CS0136): nothing |
| Self-tests | 1.1.1's cases plus the 13 new-customer cases of 2.9.11; the identity case now 1.1.2 | 209 pass, the same 4 Windows-only fails (1.1.1: 196; all 196 still pass) |
| Mutations | 26 deliberate bugs in the account code, run through the Tempe helper 2.9.11's self-tests (the same files), and 5 of them again through Ebay-auto's own (the split by sorted words, the form taken for a list of accounts, the tick off by default, every record holding COSTAR's windows back, the phone not required) | 26 of 26 caught; 5 of 5 caught |
| Node | Tests/test-costar-send.cjs (the extension, unchanged) | 11 groups pass |
| End-to-end | 1.1.1's 67 checks (COSTAR isn't part of it: the worker is played by the script) | 67 checks pass |
| Update replay | The real 1.1.2 upload set over HTTP, run with **1.1.0's** and with **1.1.1's own code** (a fresh build of each from its commit): each offers 1.1.2, downloads and checks it (both parts), the build stood in for, new orders held, switched at the safe point; the Tempe helper 2.9.11's files, a changed byte and the other part's package refused; Launch.ps1's hand-over and fallback. Run again with 1.1.2's code (nothing offered) | 28 checks pass, each of the three |
| Scans | Both packages, the upload set and the source bundle: no tokens, webhooks, keys, pairing or connection files, no `new-accounts.dat`, no Tests in the packages or the upload set; eBay order numbers, phones and e-mails made-up only; no number from the saved diagnostics (28 Oct to 17 Nov) in what 1.1.2 adds (2.9.10's few historical ones in shared files, as before) | clean |

| Asked | Tested here | Level | Not tested |
|---|---|---|---|
| The trigger: Customer Not found and X's Account# blank, nothing else | `NewAccount.NoticeOnly` and `Decide` (a list of accounts, no account in any branch, a cancelled search or a recovery never qualify); the lookup records it (code read) | S (mutation-checked), C | **L** |
| Every mandatory detail, the phone included, before anything is opened | `NewAccount.Missing` (a name of two words, street, suburb, state, postcode, a phone of 8 digits) | S (mutation-checked) | |
| Every word of the name, repeats too; no split that loses or adds words | `Words` / `SplitKeeps` on the form's Last and First; X's name word for word before the magnifier; the same words in any order after OK | S (mutation-checked) | **COSTAR's own split: L** |
| X, the magnifier, Add new, the fields checked, OK, the account confirmed, then Y | `Runner.NewAccount.cs` and the hook in Runner.Ebay.cs; the magnifier, the customer search and the form found by label, parent and place in the 17 Nov maps' geometry (X's magnifier, never Ship to's) | S, C | **Every press in COSTAR Sydney: L** |
| COSTAR's defaults and ticks unchanged | Nothing on the form is typed, ticked or chosen: only OK (or Cancel) is pressed; a personal service file must already be chosen | S, C | L |
| A detail missing: no account, Account# blank, the order goes on; the form open: Cancel back | `NotMade` (said, recorded, no stop); `CancelBack` (Cancel, then the Repair Order in front with nothing over it) | S, C | **L** |
| After OK, the account confirmed | `NewAccount.Uncertain`: the form gone, nothing over the order, the order in front and free, Account# a number at two looks, the same name's words and phone | S (mutation-checked) | **L** |
| Unsure after OK: never again for that order; Retry keeps an account; blank only when confirmed blank and the Repair Order ready; a dialog left for Seb | `NewAccountLog` (pure parts), the loose stop print and `SamePrint`, `LeftUnsure` (mutation-checked); `SteadyAccount`, `AccountLeftUnsure` in Check and `AnswerPopup` (code read) | S, C | **An unsure stop and its retry: L** |
| X checked again keeping COSTAR's Account# and name; the order's details restored; then Y | `FillOnlineHeader(true,false)` (the existing-customer path: Account# and name kept, every other box put back where it differs), then `FillDelivery` | C | **L** |
| Phone jobs and Repair Order edits unchanged | not called there (Ebay-auto enters eBay orders only) | C | |
| Every feature and diagnostic kept | every 1.1.1 self-test and end-to-end check passes; `new_account` events, review.json `NewAccount`, the tick's journey note | S, E, C | |

### Not tested live (1.1.2)

1. A new buyer's order in COSTAR Sydney: the magnifier, Add new, the form, OK, the account number on the Repair Order;
   then Ship to with the eBay delivery details, Rebill to EBAY, Terms (7INV), every check, "ez, next".
2. In COSTAR afterwards: one customer for that phone, the name split into Last and First with every word, the address
   and phone as on the order, a personal service file.
3. A new buyer missing a detail (a one-word name, no postcode): no account, the order as in 1.1.1.
4. An existing buyer: as in 1.1.1 (no magnifier).
5. An unsure stop and its Retry, if one ever happens (look at COSTAR first).
6. The update itself: 1.1.1's Update now to 1.1.2 on both parts; the new tick on afterwards.

## 1.1.1: each verified Repair Order left open ("ez, next")

| Run | What | Result |
|---|---|---|
| Compile | Roslyn at C# 5 against the .NET Framework 4.8 reference assemblies, Build.ps1's 58 files | 0 errors; the same 3 warnings |
| Self-tests | 1.1.0's cases plus 2 new 1.1.1 cases; the settings case of 2.5.2 ("closed by default") replaced by 1.1.1's (left open by default, an earlier tick turned off once, ticked again kept) | 196 pass, the same 4 Windows-only fails (1.1.0: 194) |
| Mutations | 4 deliberate bugs: "ez, next" despite a CHECK BY HAND; the one-time switch applied again after Seb ticked it; the receiver's words for "ez, next" missing; closing back on by default | 4 of 4 caught |
| Node | Tests/test-costar-send.cjs (the extension, unchanged) | 11 groups pass |
| End-to-end | 1.1.0's 62 checks plus V11: two orders, the worker reporting "ez, next" | 67 checks pass |
| Update replay | The real 1.1.1 upload set over HTTP, run with **1.1.0's own code** (the version Seb has after the move): 1.1.0 offers 1.1.1, downloads and checks it (both parts), the build stood in for, new orders held, switched at the safe point; the Tempe helper's files, a changed byte and the other part's package refused; Launch.ps1's hand-over and fallback. Run again with 1.1.1's code (nothing offered) | 28 checks pass, each way |
| Scans | Everything added since 1.1.0: only made-up order numbers, no addresses, e-mails, keys, tokens or webhooks | clean |

| Asked | Tested here | Level | Not tested |
|---|---|---|---|
| Keep every entry and verification step | The entry code is unchanged; the steps that came before the close (out of the item lines, PO# and total checked again) still run, only the close is not sent (code read: Runner.Ebay.cs) | C | **In COSTAR: L** |
| Leave the verified Repair Order open, no automatic close | The close (WM_CLOSE) is only sent with "Close each Repair Order" ticked; unticked by default | C, S | **L** |
| Report "ez, next" | The worker's words are exactly "ez, next" for a verified order left open (COSTAR's Notes still said after it); with a CHECK BY HAND, or closed (ticked), as before. On the eBay page: "In COSTAR Sydney ✓ ez, next" (green) | S, E | |
| Release the job; the next order in its own new Repair Order | The receiver hands out the next order in the same reply as "ez, next" (its own job); the worker opens each order with Add new as before, beside any Repair Order already open (1.1.0's code, unchanged) | E, C | **Add new in COSTAR with the earlier Repair Order open: L** |
| Not an error or NEEDS YOU, no failed-close warning | Counted as "fully entered and verified (completed without help)"; never CHECK BY HAND, handed over or stopped; no warning words; Hide finished tidies it like any finished order | S, E | |
| Diagnostics: verified and intentionally left for manual closure | Worker journey "left open on purpose for Seb to check and close by hand"; run record `ebay_left_open`; receiver journey "verified, left open on purpose"; the journal keeps each such Repair Order and notes when it is closed by hand (`left_open_ro_closed`); the worker's diagnostics list them | S, E, C | The 30-second look in Windows: L |
| Applies to the existing installation after updating | New settings: off; settings of 1.0.0 / 1.1.0 with the tick on: turned off once on the first start of 1.1.1 (recorded, said in the worker's window); ticked again later: kept; kept in the settings file | S (mutation-checked) | L |
| Add new while an order is open (as now) | Unchanged code (OpenNew with Repair Orders already open, as 1.1.0 does for handed-over orders and when the tick was off) | C | **L** |

### Not tested live (1.1.1)

1. One order in COSTAR Sydney: "ez, next" on the eBay page, the Repair Order left open with every line in, nothing
   closed.
2. The next order while that Repair Order is open: Add new, its own new Repair Order, the open one untouched.
3. Seb closing an open one by hand: the worker's diagnostics then say "closed by hand" for it.
4. The update itself: 1.1.0's Update now to 1.1.1 on both parts (the tick off afterwards, eBay orders on or paused as
   before).

## 1.1.0 (16 Nov 2026)

### The runs (1.1.0)

| Run | What | Result |
|---|---|---|
| Compile | Roslyn at C# 5 against the .NET Framework 4.8 reference assemblies, the same 58 files and references as Build.ps1 (tools/compile_check.ps1) | 0 errors; the same 3 warnings as 2.9.10 and 1.0.0 (CS0028, CS0649 ×2) |
| Self-tests | MobileTests under .NET 8 with shims (tools/harness/run_tests.ps1): 1.0.0's cases plus 9 new 1.1.0 cases (2 renamed) | 194 pass, 4 fail. 1.0.0 gave 185 pass and the same 4 fails; all 185 still pass. The 4 need Windows (WinForms process identity, the WinForms progress log, SetAccessControl, user32). Order Check's 16 pass |
| Mutations | 8 deliberate bugs in the new code, each run through the self-tests: Sydney by PID instead of start time; a branch change taken on one look; an unreadable Sydney given up; the product check removed; the receiver's hold ignored; the safe-point wait skipped; any protocol accepted; the window frame left out of the size | 8 of 8 caught (each fails its 1.1.0 case; nothing else changes) |
| Node | Tests/test-costar-send.cjs: the extension (unchanged since 1.0.0) | 11 groups pass |
| End-to-end | Tests/e2e_ebay_auto.py: 1.0.0's 53 checks plus V10 (1.1.0): mixed versions and updates through the real receiver code | 62 checks pass |
| Update replay | Tests/update_replay.ps1: the real update code and the real GitHub upload set (`GitHub-upload-Ebay-auto-v1.1.0.zip`) on a local web server, the Tempe helper's 2.9.10 upload set beside it; then `Launch.ps1` with a stand-in for powershell.exe | 27 checks pass |
| Scans | Everything added since 1.0.0 (git diff): no order numbers but the made-up ones (`15-11111-11111`, `16-11111-11111`, `22-22222-22222`, `33-33333-33333`), no addresses but 127.0.0.1, no e-mails, phone numbers, keys, tokens or webhooks; URLs only the GitHub Pages folder, 127.0.0.1 and example.invalid. The packages hold no Tests, keys, connections, queues or journals (the packaging refuses them) | clean |

### Tommy's checks for 1.1.0

| # | Asked | Tested here | Level | Not tested |
|---|---|---|---|---|
| 1 | COSTAR Sydney with other branches open | Made-up scans: Sydney chosen beside Tempe and Penrith; other branches never chosen; only other branches open → no COSTAR, orders wait; Order Check's COSTAR never chosen; the journey names branch, PID and start time, never a title | S | **Real COSTAR windows and process start times in Seb's session: L** |
| 2 | Several Sydney: the earliest-started | Two Sydney in three scan orders, the earlier-started one with the higher PID: always the earliest-started | S (mutation-checked) | L |
| 3 | A new Sydney or another window in front changes nothing | A third Sydney opens and the scan order changes: kept; an earlier-started COSTAR switched to Sydney: kept; the same COSTARs in another order are the same scan | S | L |
| 4 | Busy / unreadable / a dialog: wait, don't switch | The chosen Sydney missing from a scan but still running: kept, new orders wait with the reason; another branch on one look, and twice within a second: still kept (waiting); only two looks a second or more apart change it. In the code: a failed busy/dialog/Work-in-Progress check only waits and looks again (never re-chooses) | S (mutation-checked), C | **COSTAR busy or with a dialog in Remote Desktop: L** |
| 5 | Closing the chosen one: the earliest remaining, for new work | Closed: the earliest-started remaining is chosen; none left: wait; a Sydney back on Sydney later doesn't take the choice back | S | L |
| 6 | Closing or restarting COSTAR during an entry: no redirect, recreate or duplicate | Same PID with another start time = a new COSTAR (never taken for the old one). In the code: the order being entered keeps its own COSTAR to the end; the Retry of an order typed part-way is sent back only to its own COSTAR process and Repair Order, and when that COSTAR is gone the Retry is refused (1.0.0's rule, its self-tests unchanged and passing); the receiver never hands out an order twice (E2E V2, V7) | S, C, E | **An entry with COSTAR closed or restarted underneath it: L** |
| 7 | Start hidden, minimise, X, reopen, Exit | The window sizes and places for 5 screens (incl. 1280×680 and a screen left of the main one) × 5 scalings (100–200 %): always inside the working area, by the clock; the layout rule (past the page, overlapping). In the code: hidden start, minimise (button and other ways) and X hide with no taskbar button, double-click/Open restore (and back on screen), Exit, boxes opening the window first | S, C | **All of it on Windows (no window was shown here): L** |
| 8 | An update keeps settings, pairing, queue, duplicate history and hand-overs | The update writes only its own `packages\` and `update\` folders (replay); the state a part was in comes back once, for that part only, and an old one is ignored; a 1.0.0 worker and a 1.1.0 receiver work together (E2E V10); the receiver restart test of 1.0.0 (all orders back, nothing twice, the hand-over kept) still passes (E2E V7) | S, E | **A real switch between two running versions on Windows: L** |
| 9 | An update waits during an entry | The switch waits while the part says it isn't safe (an order being entered), saying why, with new orders held; Cancel takes orders again; then switches at the safe point (S). The receiver holding: an order sent meanwhile is kept, the worker gets none, the eBay page says the receiver is updating, then the order goes in (E2E V10); a worker updating itself takes nothing and the page says so (E2E V10) | S (mutation-checked), E | L |
| 10 | A failed update leaves a working install and diagnostics | A failed build: nothing switched or held, the version and the launchers' pointer unchanged, the error in words; a failed start is recorded for the version that starts again (round trip); downloads refused before anything is installed: the Tempe helper's latest.json, its ZIP (as is, and re-wrapped in an Ebay-auto folder name), a changed byte, the other part's package, a download outside Ebay-auto's folder, a version that doesn't match; `Launch.ps1` setting aside an installed version that can't build and starting the newest earlier one | S, E | **The old version starting again by itself after a new one fails on Windows: L** |
| 11 | Normal orders and NEEDS YOU unchanged | The COSTAR entry code (Runner*.cs) and the extension are byte-for-byte as in 1.0.0, and the queue's rules too (EbayModel.cs only gained the version and protocol fields); all 1.0.0 self-tests and the 53 end-to-end checks (normal orders, duplicates, one at a time, NEEDS YOU hand-over, restart, diagnostics, cut-over) pass | S, E | Typing into COSTAR: L (as for 1.0.0) |

#### The update replay (Tests/update_replay.ps1), in short

The upload set holds only README.txt and `ebay-auto/` (latest.json and the two packages). latest.json read over HTTP
past the cache and accepted (Ebay-auto 1.1.0, protocol 1). Each part: downloaded with progress to 100 %, size and
SHA-256 matched, unpacked, every file checked, exactly the package's files installed (receiver 75, worker 73), PART.txt
right, its own launcher, no Tests; installed again: reused once it checks out; the launchers' pointer names it. Then
refused, with nothing installed: the Tempe helper's latest.json; its ZIP under the worker's name with a latest.json made
to match; its package re-wrapped in a folder named as Ebay-auto's; the worker package with one byte changed; the
receiver's package under the worker's name; a latest.json naming a download outside the folder; a latest.json whose
version doesn't match; a download from outside the folder (refused by the downloader). Then `Launch.ps1` of 1.1.0:
hands over to a newer installed worker, hidden; never to the other part's package or an older version; and sets aside a
pointed version that can't build (no Windows compiler here) for the newest earlier one.

### Not tested live (1.1.0: please check with Seb)

1. **The move from 1.0.0** (MIGRATE-FROM-1.0.0.txt) on both parts: both start, the receiver keeps its orders, the
   worker its connection, "Start ... when I sign in" starts 1.1.0 at the next sign-in, no console window stays open.
2. **Which Sydney**, inside Seb's Remote Desktop session: with other branches open, then with two Sydney (the one
   started first is used; the worker's window shows its PID and start time; opening another or bringing it to the front
   changes nothing; closing the one in use while nothing is entered moves new orders to the other).
3. **The windows**: start hidden; minimise and X leave no taskbar button; double-click the icon and Open bring the window
   back; every tab readable at Seb's scaling on both PCs; Exit.
4. **The first one-click update** (when Tommy uploads the next version): the balloon, Update now, the progress, the wait
   while an order is entered, the switch (about a minute), back as it was (running or paused, window), the order list,
   the duplicate history and the worker's connection kept.
5. GitHub Pages serving `https://tommyvenzin.github.io/tempe/ebay-auto/latest.json` after the upload.
6. Everything 1.0.0 listed as not tested live (Setup-Receiver, Chrome's Allow tab, an unknown-SKU order with Quick Item
   Add cancelled, the next order beside a handed-over Repair Order, Export diagnostics on both parts).

Suggested first live test: move both parts (MIGRATE-FROM-1.0.0.txt), send one normal order with Sydney and another
branch open, then open a second Sydney and send another; Export diagnostics on the worker and send the ZIP.

## 1.0.0 (for reference)

16 Nov 2026, same sandbox: compile 0 errors (3 warnings); self-tests 185 pass, 4 Windows-only; Node 11 groups;
end-to-end 53 checks (normal order, duplicate, one at a time, unknown SKU hand-over, the next order beside it, the
receiver restarted, diagnostics, Tommy's PC not needed, pairing, paused receiving, the cut-over). Not tested live: as
listed above in item 6.
