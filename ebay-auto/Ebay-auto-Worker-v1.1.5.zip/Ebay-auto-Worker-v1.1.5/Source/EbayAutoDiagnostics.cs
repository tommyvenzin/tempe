// Ebay-auto 1.0.0 diagnostics, on both parts. The journey log follows each order through the receiver and the worker by
// its jobId (never the eBay number), its attempt (attemptId) and the requests that moved it (requestId): received, queued,
// claimed, started, completed / handed over / stopped, waiting reasons when they change, Retry / Start again / Mark done /
// Remove, connection losses and restarts, the unknown-item evidence and stage timings. Export diagnostics puts a part's
// journey, day log and (worker) run records in one ZIP, with the other part's when it can be reached (and says so when it
// can't). Never in them: keys, tokens, the Discord webhook, card or payment details, the buyer's name, phone, email,
// address or username, the eBay order number, or the full entry reports (those stay on the PC, 30 days).
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace TempeCostar {
    // One line per event: at (local time with its UTC offset), component, version, event, job, attempt, detail (this
    // program's own words, numbers and emails masked as in the day log), codes (product codes only, unmasked).
    internal static class Journey {
        static readonly object gate=new object();
        static string component="app";
        internal static volatile bool Off;
        // Told every event (the window shows them in its log).
        internal static Action<string,string,string,string> Tap;
        internal static string Component { get { return component; } }
        internal static string Folder { get { return Path.Combine(AppData.Diagnostics,"journey"); } }
        internal static void Start(string name) { component=name??"app"; }
        internal static string FileFor(DateTime day) { return Path.Combine(Folder,component+"-"+day.ToString("yyyyMMdd",CultureInfo.InvariantCulture)+".jsonl"); }
        static readonly Regex Code=new Regex(@"^[A-Z0-9][A-Z0-9._-]{0,39}$");
        internal static string Line(DateTimeOffset at,string kind,string jobId,string attemptId,string detail,IEnumerable<string> codes) {
            var line=new Dictionary<string,object> {
                {"at",at.ToString("yyyy-MM-ddTHH:mm:ss.fffzzz",CultureInfo.InvariantCulture)},{"component",component},{"version",AutofillForm.Version},
                {"event",Sanitize.Text(kind??"",40)},{"job",ReceiverApi.ValidId(jobId,"J")??""},{"attempt",ReceiverApi.ValidId(attemptId,"A")??""},{"detail",Sanitize.Text(detail??"",1200)}
            };
            var kept=(codes??new string[0]).Where(c=>c!=null&&Code.IsMatch(c)).Distinct().Take(10).ToArray();
            if(kept.Length>0) line["codes"]=kept;
            return Wire.Json(line);
        }
        internal static void Note(string kind,string jobId,string attemptId,string detail,params string[] codes) {
            if(Off) return;
            try {
                string json=Line(DateTimeOffset.Now,kind,jobId,attemptId,detail,codes);
                lock(gate) { Directory.CreateDirectory(Folder);File.AppendAllText(FileFor(DateTime.Now),json+"\n",new UTF8Encoding(false)); }
            } catch { }
            var tap=Tap;if(tap!=null) { try { tap(kind,jobId??"",attemptId??"",detail??""); } catch { } }
        }
        // The journey files of the last days (newest last), read under the lock.
        internal static List<FileInfo> Files(int days) {
            try {
                var d=new DirectoryInfo(Folder);if(!d.Exists) return new List<FileInfo>();
                DateTime since=DateTime.UtcNow.AddDays(-days);
                return d.GetFiles("*.jsonl").Where(f=>f.LastWriteTimeUtc>=since).OrderBy(f=>f.Name,StringComparer.Ordinal).ToList();
            } catch { return new List<FileInfo>(); }
        }
        internal static List<string> Tail(int lines) {
            var all=new List<string>();
            foreach(var f in Files(2)) { try { lock(gate) all.AddRange(File.ReadAllLines(f.FullName).Where(l=>l.Trim().Length>0)); } catch { } }
            return all.Skip(Math.Max(0,all.Count-lines)).ToList();
        }
        internal static byte[] Read(FileInfo f) { lock(gate) return File.ReadAllBytes(f.FullName); }
    }

    // Words about an order without the buyer: its items' codes and amounts.
    internal static class EbayDiag {
        internal static string Shape(EbayOrder o) {
            if(o==null||o.items==null) return "(no order)";
            return o.items.Count+" item(s): "+String.Join(", ",o.items.Where(i=>i!=null).Select(i=>(i.sku??"?")+" x"+i.quantity+" @ "+EbayHandoff.Dollars(i.unitCents)).ToArray())+
                (o.freightCents>0?"; freight "+EbayHandoff.Dollars(o.freightCents):"; free postage")+"; total "+EbayHandoff.Dollars(o.totalCents)+StateWords(o);
        }
        // 1.1.4: where the buyer's state is from (EbayOrder.AddressState), never the state, suburb or postcode themselves.
        static string StateWords(EbayOrder o) {
            if(o.address==null) return "";
            StateFound found;
            try { found=o.AddressState(); } catch(Exception) { return "; state not checked"; }
            return found.State==null?"; no state found ("+found.Why+")":found.Source=="lookup"?"; state looked up from the suburb and postcode":"; state as written";
        }
        internal static IEnumerable<string> Codes(EbayOrder o) { return o==null||o.items==null?new string[0]:o.items.Where(i=>i!=null).Select(i=>i.sku); }
        // The worker's words for a finished order, in short.
        internal static string Outcome(string message) {
            string m=message??"";
            // 1.1.1: "ez, next": verified, and left open on purpose for Seb to check and close by hand (not a stop, not NEEDS YOU).
            string how=m.StartsWith(EbayFinish.EzNext,StringComparison.Ordinal)?"verified, left open on purpose for Seb to check and close by hand (\""+EbayFinish.EzNext+"\")":
                m.Contains("entered and closed")?"closed (in Work-in-Progress)":m.Contains("left open")?"left open":"";
            int check=m.IndexOf("CHECK BY HAND",StringComparison.Ordinal);
            return (how.Length>0?how:"entered")+(check>=0?"; "+Sanitize.Text(m.Substring(check),300):"");
        }
    }

    internal static class EbayAutoDiagnostics {
        // ---- what happened, in the user's words ----
        // A worker run's outcome: verified (entered and checked, nothing by hand), check_by_hand (entered and checked, a
        // CHECK BY HAND note: not "completed without help"), handed_over (items left for Seb: never verified), stopped,
        // cancelled (Stop pressed), probe (an open Repair Order checked, not an order).
        internal static string Outcome(RunReport r) {
            if(r==null) return "";
            if(r.Outcome=="completed") return r.ChecksByHand>0?"check_by_hand":"verified";
            if(r.Outcome=="handed_over") return "handed_over";
            if(r.Outcome=="cancelled") return "cancelled";
            if(DiagnosticsBundle.IsProbe(r)) return "probe";
            return "stopped";
        }
        static readonly string[] RunOrder={"verified","check_by_hand","handed_over","stopped","cancelled","probe"};
        static readonly Dictionary<string,string> RunWords=new Dictionary<string,string> {
            {"verified","Fully entered and verified (completed without help)"},
            {"check_by_hand","Entered and verified, manual work remaining (CHECK BY HAND)"},
            {"handed_over","Entered as far as possible, manual work remaining (handed over: items unresolved, not verified)"},
            {"stopped","Stopped / uncertain (needs a person: Retry, Start again or Mark done)"},
            {"cancelled","Stopped by a person (Stop, Stop all or Exit)"},
            {"probe","Checks of an earlier empty Repair Order (not orders)"}};
        internal static string RunCounts(IEnumerable<RunReport> runs,string title) {
            var list=runs.Where(r=>r!=null&&(r.Kind??"").StartsWith("ebay",StringComparison.Ordinal)&&r.Kind!="ebay-layout-check").ToList();
            var b=new StringBuilder(title+": "+list.Count(r=>Outcome(r)!="probe")+" eBay run(s)\r\n");
            foreach(var k in RunOrder) b.AppendLine("  "+RunWords[k]+": "+list.Count(r=>Outcome(r)==k));
            return b.ToString();
        }
        static readonly string[] QueueOrder={"verified","check_by_hand","handed_over","marked_done","waiting","stopped","removed"};
        static readonly Dictionary<string,string> QueueWords=new Dictionary<string,string> {
            {"verified","Fully entered and verified by the worker (completed without help)"},
            {"check_by_hand","Entered and verified, manual work remaining (CHECK BY HAND)"},
            {"handed_over","Handed over: manual completion needed (items unresolved, not verified)"},
            {"marked_done","Marked done by hand"},
            {"waiting","Waiting (queued or being entered)"},
            {"stopped","Stopped / uncertain"},
            {"removed","Removed"}};
        internal static string QueueCounts(IEnumerable<EbayReceipt> receipts,string title) {
            var list=receipts.Where(r=>r!=null).ToList();
            var b=new StringBuilder(title+": "+list.Count+" order(s)\r\n");
            foreach(var k in QueueOrder) b.AppendLine("  "+QueueWords[k]+": "+list.Count(r=>EbayQueue.Category(r)==k));
            return b.ToString();
        }
        static string Header(string part) {
            var now=DateTimeOffset.Now;
            return Product.Name+" "+part+" diagnostics\r\n"+
                "Version: "+AutofillForm.Version+" (eBay code from the Tempe COSTAR helper "+Product.Based+")\r\n"+
                "Made: "+now.ToString("ddd d MMM yyyy HH:mm:ss zzz",CultureInfo.InvariantCulture)+" ("+TimeZoneInfo.Local.Id+")\r\n"+
                "Windows: "+Environment.OSVersion.VersionString+", "+(Environment.Is64BitProcess?"64-bit":"32-bit")+Remote()+", Windows session "+SessionText()+"\r\n"+
                "Masked: no keys, tokens, webhook, card or payment details, buyer details or eBay order numbers. Orders are named by their job id (J-...), attempts A-..., requests R-...\r\n\r\n";
        }
        // The Windows session this part runs in (read through kernel32; "?" where it can't be read).
        static string SessionText() { try { return SessionNumber(); } catch(Exception) { return "?"; } }
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        static string SessionNumber() { return LocalProcess.Session.ToString(CultureInfo.InvariantCulture); }
        static string Remote() { try { return RemoteSession()?", Remote Desktop session":", not Remote Desktop"; } catch(Exception) { return ""; } }
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        static bool RemoteSession() { return System.Windows.Forms.SystemInformation.TerminalServerSession; }
        static void Text(ZipArchive zip,string name,string text) {
            var entry=zip.CreateEntry(name,CompressionLevel.Optimal);
            using(var w=new StreamWriter(entry.Open(),new UTF8Encoding(false))) w.Write(text);
        }
        static void Bytes(ZipArchive zip,string name,byte[] data) {
            var entry=zip.CreateEntry(name,CompressionLevel.Optimal);
            using(var s=entry.Open()) s.Write(data,0,data.Length);
        }
        static void Logs(ZipArchive zip,int days) {
            foreach(var f in Journey.Files(days)) { try { Bytes(zip,"journey/"+f.Name,Journey.Read(f)); } catch { } }
            try {
                var d=new DirectoryInfo(RunDiagnostics.Root);
                if(d.Exists) foreach(var f in d.GetFiles("events-*.jsonl").Where(x=>x.LastWriteTimeUtc>=DateTime.UtcNow.AddDays(-days)).OrderBy(x=>x.Name,StringComparer.Ordinal)) {
                    string[] lines=null;try { lines=File.ReadAllLines(f.FullName); } catch { }
                    if(lines!=null) Text(zip,"day-log/"+f.Name,String.Join("\n",lines)+"\n");
                }
            } catch { }
        }
        static string Csv(string v) { v=v??"";return v.IndexOfAny(new[]{',','"','\r','\n'})>=0?"\""+v.Replace("\"","\"\"")+"\"":v; }
        static string Local(string utc) {
            DateTime at;
            return DateTime.TryParse(utc??"",CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out at)?new DateTimeOffset(at.ToUniversalTime()).ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss zzz",CultureInfo.InvariantCulture):"";
        }
        // The receiver's queue, one line per order: ids, states, times, product codes and amounts. No buyer, no eBay number.
        internal static string QueueCsv(IEnumerable<EbayReceipt> receipts) {
            var b=new StringBuilder("job,attempt,status,category,received,updated,version,typed,claimedOnce,autoRetried,markedDone,hidden,items,codes,quantities,unitCents,freightCents,totalCents,message,remaining\r\n");
            foreach(var r in receipts.Where(x=>x!=null&&x.order!=null).OrderBy(x=>x.receivedUtc,StringComparer.Ordinal)) {
                var o=r.order;var items=o.items??new List<EbayItem>();
                b.AppendLine(String.Join(",",new[]{Csv(r.jobId),Csv(r.attemptId),Csv(r.status),Csv(EbayQueue.Category(r)),Csv(Local(r.receivedUtc)),Csv(Local(r.updatedUtc)),r.version.ToString(CultureInfo.InvariantCulture),
                    r.typed.ToString(),r.claimedOnce.ToString(),r.autoRetried.ToString(),r.markedDone.ToString(),r.hidden.ToString(),items.Count.ToString(CultureInfo.InvariantCulture),
                    Csv(String.Join(" ",items.Select(i=>i.sku??"").ToArray())),Csv(String.Join(" ",items.Select(i=>i.quantity.ToString(CultureInfo.InvariantCulture)).ToArray())),
                    Csv(String.Join(" ",items.Select(i=>i.unitCents.ToString(CultureInfo.InvariantCulture)).ToArray())),o.freightCents.ToString(CultureInfo.InvariantCulture),o.totalCents.ToString(CultureInfo.InvariantCulture),
                    Csv(Masked(r.message,o)),Csv(Masked(r.remaining,o))}));
            }
            return b.ToString();
        }
        // A message of the worker's with anything of the order's own that could name the buyer taken out (it has none by
        // design; this is the belt to that).
        internal static string Masked(string text,EbayOrder o) {
            string t=text??"";
            if(o!=null) {
                var words=new List<string>();
                if(o.buyer!=null) { words.Add(o.buyer.name);words.Add(o.buyer.username);words.Add(o.buyer.email);words.Add(o.buyer.phone); }
                if(o.address!=null) { words.Add(o.address.street);words.Add(o.address.street2);words.Add(o.address.suburb); }
                words.Add(o.orderNumber);
                foreach(var w in words.Where(x=>!String.IsNullOrWhiteSpace(x)&&x.Trim().Length>=3)) t=Regex.Replace(t,Regex.Escape(w.Trim()),"[removed]",RegexOptions.IgnoreCase);
            }
            return Sanitize.Text(t,600);
        }
        // ---- the receiver's ZIP ----
        // worker: the worker's own ZIP (null: not had, with why in workerNote; asked: whether it was asked for at all).
        internal static byte[] ReceiverZip(EbayQueue queue,ReceiverApi api,ReceiverSettings settings,byte[] worker,string workerNote,bool asked) {
            var receipts=queue==null?new List<EbayReceipt>():queue.List();
            using(var memory=new MemoryStream()) {
                using(var zip=new ZipArchive(memory,ZipArchiveMode.Create,true)) {
                    var b=new StringBuilder(Header("Receiver (Seb's PC)"));
                    b.AppendLine("Listening on: "+settings.address+":"+settings.port+" (certificate download on "+settings.trustPort+")");
                    b.AppendLine("Receiving: "+(api.Receiving?"on":"PAUSED"));
                    bool connected,on,ready;string detail;api.EbaySide(out connected,out on,out ready,out detail);
                    int since=api.SecondsSinceEbayWorker;
                    b.AppendLine("Worker: "+(connected?"in touch ("+since+" s ago)":since<0?"never in touch since the receiver started":"NOT in touch for "+since+" s")+(api.EbayWorkerVersion.Length>0?", version "+api.EbayWorkerVersion:""));
                    b.AppendLine("Worker says: "+(on?(ready?"ready for the next order":"waiting: "+detail):"eBay orders paused"+(detail.Length>0?" ("+detail+")":"")));
                    b.AppendLine("Waiting reason shown on the eBay page: "+api.EbayWaiting);
                    b.AppendLine("eBay PC pairing: "+(String.IsNullOrEmpty(settings.ebayToken)?"no key yet":"a key is set (not shown)")+(api.Pairing.Active?"; pairing open now":""));
                    b.AppendLine();
                    b.Append(QueueCounts(receipts,"ORDERS ON THE RECEIVER NOW"));
                    string today=DateTime.Now.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture);
                    b.Append(QueueCounts(receipts.Where(r=>Local(r.receivedUtc).StartsWith(today,StringComparison.Ordinal)),"RECEIVED TODAY"));
                    b.AppendLine();
                    b.AppendLine("Needing a person now:");
                    foreach(var r in receipts.Where(r=>r.status=="handed_over"||r.status=="failed").OrderBy(r=>r.updatedUtc,StringComparer.Ordinal))
                        b.AppendLine("  "+r.jobId+" "+r.status.Replace('_',' ')+" since "+Local(r.updatedUtc)+": "+Masked(r.status=="handed_over"&&!String.IsNullOrEmpty(r.remaining)?r.remaining:r.message,r.order));
                    b.AppendLine();
                    b.AppendLine("The worker's logs: "+(worker!=null?"included (worker/)":!asked?"not asked for":"NOT included: "+(workerNote??"no answer")));
                    b.AppendLine();
                    b.AppendLine("Last journey events:");
                    foreach(var l in Journey.Tail(60)) b.AppendLine("  "+l);
                    Text(zip,"summary.txt",b.ToString());
                    Text(zip,"queue.csv",QueueCsv(receipts));
                    Logs(zip,14);
                    if(worker!=null&&worker.Length>0) Bytes(zip,"worker/"+Product.DiagnosticsPrefix+"Worker-Diagnostics.zip",worker);
                    else if(asked) Text(zip,"WORKER-LOGS-NOT-INCLUDED.txt","The worker's logs are not in this ZIP: "+(workerNote??"it didn't answer in time")+".\r\nExport diagnostics on the worker (inside Remote Desktop: its tray icon, Export diagnostics): that ZIP has both parts' logs when the receiver can be reached.\r\n");
                }
                return memory.ToArray();
            }
        }
        // ---- the worker's ZIP ----
        // withReceiver: the receiver's ZIP inside it (asked for over the connection); note says what couldn't be had.
        internal static byte[] WorkerZip(EbayEngine engine,bool withReceiver,out string note) {
            note=null;
            int days=withReceiver?14:7,most=withReceiver?300:120;
            var folder=new DirectoryInfo(RunDiagnostics.Root);
            var files=folder.Exists?folder.GetFiles("*.json").Where(f=>f.LastWriteTimeUtc>=DateTime.UtcNow.AddDays(-days)).OrderByDescending(f=>f.LastWriteTimeUtc).Take(most).ToList():new List<FileInfo>();
            var reports=new List<RunReport>();
            foreach(var f in files) { try { reports.Add(Wire.Read<RunReport>(File.ReadAllText(f.FullName))); } catch { } }
            byte[] receiver=null;string receiverWhy=null;
            if(withReceiver) { receiver=engine==null?null:engine.ReceiverDiagnostics(out receiverWhy);if(engine==null) receiverWhy="the worker isn't connected to a receiver (no connection imported)"; }
            using(var memory=new MemoryStream()) {
                using(var zip=new ZipArchive(memory,ZipArchiveMode.Create,true)) {
                    var b=new StringBuilder(Header("Worker (inside Remote Desktop)"));
                    if(engine==null) b.AppendLine("No receiver connection imported yet.");
                    else {
                        int since=engine.SecondsSinceContact;
                        b.AppendLine("Receiver: "+engine.Connection+(since>=0?" (last contact "+since+" s ago"+(engine.RoundTripMs>=0?", "+engine.RoundTripMs+" ms":"")+")":""));
                        b.AppendLine("eBay orders: "+(engine.Enabled?"on":"PAUSED")+(engine.Busy?", entering one now ("+engine.CurrentJob+")":""));
                        var t=engine.Target;
                        b.AppendLine("COSTAR Sydney: "+(t==null?"not found in this session":"Branch "+t.Branch+", PID "+t.Pid+", session "+t.Session+" (this worker's session "+SessionText()+")"));
                        b.AppendLine("Now: "+Sanitize.Text(engine.Detail,300));
                        b.AppendLine("Handed-over Repair Orders still open in COSTAR: "+engine.HeldOpen);
                        b.AppendLine();
                        b.AppendLine("JOURNAL (ids and states only)");
                        b.Append(engine.JournalSummary());
                    }
                    b.AppendLine();
                    string today=DateTime.Now.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture);
                    b.Append(RunCounts(reports.Where(r=>(r.StartedLocal??"").StartsWith(today,StringComparison.Ordinal)),"TODAY"));
                    b.Append(RunCounts(reports,"THE LAST "+days+" DAYS"));
                    b.AppendLine("  (\"Completed without help\" counts only fully entered and verified orders: a CHECK BY HAND note, a hand-over or a stop needs a person.)");
                    b.AppendLine();
                    var checks=reports.Where(r=>Outcome(r)=="check_by_hand").SelectMany(r=>r.Events.Where(e=>e.Kind=="ebay_check").Select(e=>e.Detail)).GroupBy(x=>Sanitize.Text(x,120)).OrderByDescending(g=>g.Count()).Take(8).ToList();
                    if(checks.Count>0) { b.AppendLine("CHECK BY HAND reasons:");foreach(var g in checks) b.AppendLine("  "+g.Count()+" x "+g.Key); }
                    var unresolved=reports.Where(r=>r.Outcome=="handed_over").ToList();
                    if(unresolved.Count>0) {
                        b.AppendLine("HANDED OVER (items COSTAR doesn't know):");
                        foreach(var r in unresolved.OrderBy(r=>r.StartedLocal,StringComparer.Ordinal)) {
                            b.AppendLine("  "+(r.JobId??"")+" "+(r.StartedLocal??"")+" run "+r.RunId+": "+(r.StopMessage??""));
                            foreach(var u in r.Unresolved) b.AppendLine("    "+u);
                        }
                    }
                    var stops=reports.Where(r=>Outcome(r)=="stopped").ToList();
                    if(stops.Count>0) { b.AppendLine("STOPPED:");foreach(var r in stops.OrderBy(r=>r.StartedLocal,StringComparer.Ordinal).Take(40)) b.AppendLine("  "+(r.JobId??"")+" "+(r.StartedLocal??"")+" "+r.Category+" at "+(r.StopStage??"")+": "+(r.StopMessage??"")); }
                    b.AppendLine();
                    b.AppendLine("The receiver's logs: "+(!withReceiver?"not asked for (this ZIP was sent to the receiver)":receiver!=null?"included (receiver/)":"NOT included: "+(receiverWhy??"no answer")));
                    b.AppendLine();
                    b.AppendLine("Last journey events:");
                    foreach(var l in Journey.Tail(60)) b.AppendLine("  "+l);
                    Text(zip,"summary.txt",b.ToString());
                    Text(zip,"runs.csv",DiagnosticsBundle.Csv(reports)+Outcomes(reports));
                    foreach(var f in files) { try { zip.CreateEntryFromFile(f.FullName,"runs/"+f.Name,CompressionLevel.Optimal); } catch { } }
                    Logs(zip,days);
                    if(receiver!=null) Bytes(zip,"receiver/"+Product.DiagnosticsPrefix+"Receiver-Diagnostics.zip",receiver);
                    else if(withReceiver) Text(zip,"RECEIVER-LOGS-NOT-INCLUDED.txt","The receiver's logs are not in this ZIP: "+(receiverWhy??"no answer")+".\r\nExport diagnostics on the receiver (Seb's PC: its tray icon, Export diagnostics).\r\n");
                }
                if(withReceiver&&receiver==null) note="the receiver's logs couldn't be had: "+(receiverWhy??"no answer");
                return memory.ToArray();
            }
        }
        // runs.csv's last part: each run's outcome in the words above.
        static string Outcomes(List<RunReport> reports) {
            var b=new StringBuilder("\r\nRunId,Job,Attempt,Outcome,ChecksByHand,Unresolved\r\n");
            foreach(var r in reports) b.AppendLine(String.Join(",",new[]{Csv(r.RunId),Csv(r.JobId),Csv(r.AttemptId),Outcome(r),r.ChecksByHand.ToString(CultureInfo.InvariantCulture),Csv(String.Join(" | ",r.Unresolved.ToArray()))}));
            return b.ToString();
        }
        // Where an exported ZIP goes (kept 30 days, as the helper's).
        internal static string Save(string part,byte[] zip) {
            string target=Path.Combine(AppData.Home,Product.DiagnosticsPrefix+part+"-Diagnostics-"+DateTime.Now.ToString("yyyyMMdd-HHmmss",CultureInfo.InvariantCulture)+".zip");
            Directory.CreateDirectory(AppData.Home);File.WriteAllBytes(target,zip);
            Journey.Note("diagnostics_exported","","",Path.GetFileName(target)+", "+AppData.Bytes(zip.Length));
            return target;
        }
    }
}
