404 But It's Found 1.5.2 — 19 November 2026
Contact info is the main phone; Ship to is sent separately as a fallback.
Billing name comes from Order/Buyer; delivery name comes from Ship to.
Explicit unit addresses use slash notation, full street types and capitals.
Requires Ebay-auto receiver and worker 1.1.8. Reload the existing unpacked extension and refresh the eBay page.

404 But It's Found - Chrome extension (1.5.2, for Ebay-auto)
=============================================================

Install (once)
1. Unzip and keep the "404-but-its-found" folder somewhere it can stay (e.g. Documents).
2. In Chrome open chrome://extensions and turn on "Developer mode" (top right).
3. Click "Load unpacked" and choose the "404-but-its-found" folder.
4. Click the puzzle-piece icon in the toolbar and pin "404 But It's Found".
   (Edge works the same way at edge://extensions.)

Update to a new version (e.g. 1.5.1 -> 1.5.2)
- Extract the new zip into the same folder (replace the files), then open chrome://extensions
  and click the reload arrow on the "404 But It's Found" card. Reload any open eBay order pages.

Use
- Open an eBay order's "Order details" page: the copy panel opens by itself.
  Click a blue box, or press the key shown next to it, to copy that value (or "Copy all").
  Keys: 1 phone, 2 name, 3 street, 4 suburb, 5 state, 6 postcode, Q email, W order no.,
        A SKU, S username, D item ID, F freight, Z order no. + date.
  Everything is in capitals except the email, and street types are written in full
  (CRT -> COURT, RD -> ROAD, ST -> STREET ...). The state is always its short code (NSW, VIC,
  QLD, SA, WA, TAS, NT, ACT), also when eBay writes it in full ("New South Wales").
  1.5.1: when eBay shows no state, Send to COSTAR still sends the order, and Ebay-auto looks the
  state up by the suburb and postcode (see "Not sent" below if it can't).
  Keys don't fire while you're typing in a box on the page. Drag the panel by its title; x closes it.
- Click the extension icon: the console script is copied to your clipboard straight away.
  The popup can also show the panel again on the current page, and turn the
  automatic panel on or off.

Send to COSTAR (1.5.0: through Ebay-auto, on this PC)
The panel has a "Send to COSTAR" button. One click sends the order to the Ebay-auto receiver on
this PC. The Ebay-auto worker inside your Remote Desktop session then types it into a new Repair
Order in COSTAR Sydney by itself (customer, PO#, EBAY DFE, Ship to, Rebill to EBAY + Card#, the
tyre at the eBay price, freight, M E, M BUY, M DFE). Successful Repair Orders stay OPEN for Seb
to check and close manually. It reports "ez, next" and is ready for the next order.
If the Repair Order number is blank, Next # generates it; the clipboard gets that number + DFE.
Sydney's ThisBr Avail above 2 continues, 0-2 needs typed "ok" or "check", and negative stock
needs "yes" confirming Seb will contact the customer. "check" adds "low stock - currently
checking" to the comment. The prompt cannot be skipped; Stop still stops the order.
Tommy's PC is not used any more.

Pair with the Ebay-auto receiver (once; Setup-Receiver must have run on this PC first):
1. On the Ebay-auto receiver (its icon in the notification area -> Open): click "Pair eBay PC".
   It shows this PC's address with its port (like 192.168.1.20:8811) and a 6-digit PIN
   (works once, for 10 minutes).
2. Click the 404 extension icon. Under "Ebay-auto receiver", type the address (with :8811) and the
   PIN, then click Connect. Chrome asks for its OK to reach that address in a tab that opens:
   click Allow there (and in Chrome's box), then click the extension icon and Connect again.
   On this PC the receiver's certificate is already trusted (Setup-Receiver did it). Only for
   Chrome on ANOTHER PC: click "Install the receiver's certificate...", open the downloaded file ->
   Install Certificate -> Current User -> "Place all certificates in the following store" ->
   Browse -> "Trusted Root Certification Authorities" -> OK -> Next -> Finish -> Yes, then close
   Chrome completely and open it again.
3. The popup says "Connected" and whether the worker in Remote Desktop is in touch and ready.
   If it can't connect, the message ends with what Chrome says (e.g. net::ERR_...).
The 1.4 pairing with Tommy's PC is not used by 1.5.0 (it is left as it was, so going back to
1.4.3 would still work). Orders sold on or before the day you pair with Ebay-auto may already be
in COSTAR from Tommy's PC: for those the panel says so and the button reads "Send to COSTAR
anyway". Check COSTAR Sydney first, and send it only if it isn't there.

What the panel tells you after Send:
- Sent ✓ Waiting for COSTAR ...   It is on the Ebay-auto receiver and waits for its turn (the reason
                                  is shown, e.g. the worker in Remote Desktop is not running, COSTAR
                                  Sydney is not open there, or someone is using that session).
                                  Nothing to do.
- Being entered into COSTAR ...   The worker is typing it right now.
- In COSTAR Sydney ✓              Done. The order is in COSTAR Sydney (Work-in-Progress).
  (amber "CHECK BY HAND: ...")    Done, but one thing must be finished by hand (it says what).
- NEEDS YOU: ... (button "Needs you")
                                  An item's code (its SKU) isn't a COSTAR item, e.g. a wheel or a
                                  package. The worker cancelled COSTAR's Quick Item Add (nothing was
                                  added), entered what it safely could, and left the Repair Order
                                  OPEN in COSTAR Sydney. The panel says what is left to do. Finish it
                                  in COSTAR, close it, then click "Mark done by hand" on the receiver.
                                  It is never sent or retried again from the page.
- Stopped: ...                    The worker stopped safely and says why. "Send again" asks it to
                                  continue (in the same Repair Order if nothing in it changed); the
                                  receiver also has Start again in a new RO, Mark done by hand, Remove.
- Not sent: The address has no state ...
                                  eBay shows no state for this buyer, and the receiver couldn't look
                                  it up: that suburb isn't under that postcode in its Australian
                                  address list, or that suburb and postcode are in more than one
                                  state. It never guesses one. Enter that order by hand.
- Can't send to COSTAR: ...       Something needed is missing on the page (most often the item's
                                  custom label / SKU), or what the buyer paid has a discount, fee or
                                  tax line, so the tyre price can't be read safely. Enter that order
                                  by hand.
The same order can never go into COSTAR twice through Ebay-auto: a second click, or opening the
order again, just shows its status. Orders with more than 4 items, or several items whose prices
on the page don't add up to the total, are left for you to enter by hand.

If it says "Can't reach the Ebay-auto receiver": check the receiver is running (its icon in the
notification area; Start-Receiver.cmd starts it), that Setup-Receiver ran on this PC under this
Windows user (it trusts the receiver's certificate), and if Chrome asks about devices on your local
network, choose Allow.
