// Send to COSTAR (404 But It's Found 1.4): turns what the copy panel read on an eBay order page
// into the order the receiver takes (schema tempe.ebay-order.v1), or says what is missing.
// 1.5.0: the receiver is the Ebay-auto receiver on this PC; its worker inside Remote Desktop enters it into a new
// Repair Order in COSTAR Sydney. 1.5.1: an address with no state is sent; the receiver looks the state up (build).
// Pure functions: no page, storage or network access here.
(function (root) {
  'use strict';
  const SCHEMA = 'tempe.ebay-order.v2';
  const NUMBER = /^\d{2}-\d{5}-\d{5}$/;
  const STATES = /^(NSW|VIC|QLD|SA|WA|TAS|NT|ACT)$/;
  // 1.4.3 (Tommy, 26 Oct): eBay gives some buyers' state in full ("New South Wales", "Victoria");
  // COSTAR takes the code. Dots and spaces in a code ("N.S.W.") are dropped. Anything else stays as
  // it is, and is then "not found". The panel (ebay_order_console.js) keeps the same list.
  const STATE_NAMES = { 'NEW SOUTH WALES': 'NSW', VICTORIA: 'VIC', QUEENSLAND: 'QLD', 'SOUTH AUSTRALIA': 'SA', 'WESTERN AUSTRALIA': 'WA',
    TASMANIA: 'TAS', 'NORTHERN TERRITORY': 'NT', 'AUSTRALIAN CAPITAL TERRITORY': 'ACT' };
  function stateCode(v) {
    const s = String(v == null ? '' : v).toUpperCase().replace(/\s+/g, ' ').trim();
    if (STATE_NAMES[s]) return STATE_NAMES[s];
    const short = s.replace(/[.\s]/g, '');
    return STATES.test(short) ? short : s;
  }
  const SKU = /^[A-Z0-9][A-Z0-9._-]{0,39}$/;
  const RESERVED = /^(F|M|DET|WA|WAFR|SERVICES?|UNKNOWN|UNAVAILABLE)$/;
  const MAX_ITEMS = 4;

  // "150.00" / "1,300.5" / "AU $150.00" -> cents; "Free" -> 0; nothing -> null
  const cents = v => {
    const s = String(v == null ? '' : v);
    if (/^\s*free\s*$/i.test(s)) return 0;
    const m = s.replace(/,/g, '').match(/(\d+)(?:\.(\d{1,2}))?/);
    return m ? Number(m[1]) * 100 + (m[2] ? Number(m[2].padEnd(2, '0')) : 0) : null;
  };
  const dollars = c => (c < 0 ? '-$' : '$') + (Math.abs(c) / 100).toFixed(2);
  // As cents() but a minus sign or brackets make it negative ("-AU $5.00", "(AU $5.00)", "AU -$5.00").
  const signedCents = v => {
    const s = String(v == null ? '' : v).trim(), c = cents(s);
    return c == null ? null : (/^\(|^[-\u2212]|[-\u2212]\s*\$/.test(s) ? -c : c);
  };
  const SUBTOTAL = /^\s*(items?\s+)?sub-?total(\s*\([^)]*\))?\s*:?\s*$/i;
  const POSTAGE = /^\s*(postage|shipping|delivery|p\s*&\s*p)(\s+(and|&)\s+(handling|packaging|packing))?(\s*\([^)]*\))?\s*:?\s*$/i;
  const ORDER_TOTAL = /^\s*(order\s+)?total(\s*\([^)]*\))?\s*:?\s*$/i;
  const HEADING = /what\s+(your\s+)?buyer\s+paid/i;
  // What the buyer paid, line by line: the subtotal, the postage, and every other line that has
  // money on it (or an amount that can't be read).
  function payment(lines) {
    const out = { subtotal: null, postage: null, other: [] };
    for (const line of lines || []) {
      const title = String((line || [])[0] || '').trim(), text = String((line || [])[1] == null ? '' : line[1]).trim();
      const amount = signedCents(text);
      if (!title || ORDER_TOTAL.test(title) || HEADING.test(title)) continue;
      if (SUBTOTAL.test(title) && out.subtotal == null && amount != null) { out.subtotal = amount; continue; }
      if (POSTAGE.test(title) && out.postage == null && amount != null) { out.postage = amount; continue; }
      if (amount !== 0 && (amount != null || text)) out.other.push(title.slice(0, 40));
    }
    return out;
  }

  // Unit prices that add up to what the buyer paid for the goods (total minus postage).
  // One item: the goods amount split by its quantity. Several: the prices read off the page for
  // each item, used only when exactly one way of reading them adds up to the cent.
  function prices(items, totalCents, freightCents, fromSubtotal) {
    const goods = totalCents - freightCents;
    if (!(goods > 0)) return { error: 'the eBay total minus postage is not more than $0' };
    if (items.length === 1) {
      const it = items[0];
      if (goods % it.qty !== 0) return { error: `${dollars(goods)} does not split evenly into ${it.qty} items: enter this order by hand` };
      return { units: [goods / it.qty], source: fromSubtotal ? 'subtotal' : 'total minus postage' };
    }
    const options = items.map(it => {
      const set = new Set();
      for (const c of it.candidates || []) {
        if (!(c > 0)) continue;
        set.add(c);
        if (it.qty > 1 && c % it.qty === 0) set.add(c / it.qty);
      }
      return [...set];
    });
    const hits = new Map();
    const walk = (i, sum, picked) => {
      if (hits.size > 1 || sum > goods) return;
      if (i === items.length) { if (sum === goods) hits.set(picked.join(','), picked.slice()); return; }
      for (const u of options[i]) { picked.push(u); walk(i + 1, sum + u * items[i].qty, picked); picked.pop(); }
    };
    walk(0, 0, []);
    if (hits.size === 0) return { error: "the item prices on the page don't add up to the eBay total: enter this order by hand" };
    if (hits.size > 1) return { error: 'the item prices on the page can be read more than one way: enter this order by hand' };
    return { units: [...hits.values()][0], source: 'page prices' };
  }

  // d: what the panel read (phone, name, street[], city, state, postcode, email, order, date, user,
  // postage, total, paid [[title, amount]] or paidNote [words] from the page text, items
  // [[sku, qty, itemId, priceCandidates]]). h: the panel's own formatting helpers
  // (U, fmtPhone, fmtDate, fullStreet, optional fullStreetLines, fullWords, money), so both show exactly the same values.
  function build(d, h, sender) {
    const problems = [];
    const say = p => { if (!problems.includes(p)) problems.push(p); };
    const order = h.U(d.order);
    if (!NUMBER.test(order)) say('the eBay order number was not found');
    const date = h.fmtDate(d.date);
    if (!/^\d{2}\/\d{2}\/\d{2}$/.test(date)) say('the order date was not found');
    const phone = h.fmtPhone(d.contactPhone), shippingPhone = h.fmtPhone(d.shippingPhone);
    const validPhone = p => /^\+?[\d ()-]+$/.test(p) && /^\d{8,15}$/.test(p.replace(/\D/g, ''));
    if (!validPhone(phone)) say("the Contact info phone was not found; open Buyer > Show contact info and refresh the panel");
    if (shippingPhone && !validPhone(shippingPhone)) say("the Ship to phone doesn't look right");
    const name = h.U(d.name);
    if (!name || name.length > 200) say("the name in the Buyer section was not found");
    const recipientName = h.U(d.shippingName);
    if (!recipientName || recipientName.length > 200) say("the Ship to recipient name was not found");
    const streets = (h.fullStreetLines ? h.fullStreetLines(d.street) : (d.street || []).map(h.fullStreet)).map(h.U).filter(Boolean);
    if (!streets.length) say('the street was not found');
    const suburb = h.U(h.fullWords(d.city));
    if (!suburb) say('the suburb was not found');
    const state = stateCode(h.U(d.state));
    // 1.5.1 (18 Nov): no state on the eBay page: the order goes without one, and the Ebay-auto receiver looks it up by the
    // suburb and postcode (only when they are in exactly one state; otherwise it refuses the order, and this panel shows
    // why). A state that isn't one of the eight is still "not found" here.
    if (state && !STATES.test(state)) say('the state was not found');
    const postcode = String(d.postcode || '').trim();
    if (!/^\d{4}$/.test(postcode)) say('the postcode was not found');
    const email = String(d.email || '').trim();
    if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) say("the buyer's email doesn't look right");
    const username = h.U(d.user);
    if (!/^[A-Z0-9._*-]{1,64}$/.test(username)) say("the buyer's eBay username was not found");
    const items = (d.items || []).map(it => ({ sku: h.U(it[0]), qty: Number(it[1]), id: String(it[2] || ''), candidates: it[3] || [] }));
    if (!items.length) say('no items were found');
    if (items.length > MAX_ITEMS) say(`more than ${MAX_ITEMS} items: enter this order by hand`);
    const ids = new Set();
    for (const it of items) {
      if (!SKU.test(it.sku) || RESERVED.test(it.sku)) say(`item ${it.id || '?'} has no COSTAR item code (its eBay custom label / SKU)`);
      if (!(Number.isInteger(it.qty) && it.qty >= 1 && it.qty <= 20)) say(`the quantity of ${it.sku || 'an item'} was not found`);
      if (!/^\d{9,15}$/.test(it.id)) say('an eBay item number was not found');
      else if (ids.has(it.id)) say('the same eBay item is listed twice');
      ids.add(it.id);
    }
    // What the buyer paid. With a subtotal, subtotal + postage must equal the total: then nothing
    // else (a discount, fee or tax) changed what was paid for the items, whatever else is listed.
    // Without one, any other line with money on it, or such words on the page, stop the send.
    let freight = cents(h.money(d.postage)), subtotal = null, others = [];
    if (Array.isArray(d.paid) && d.paid.length) {
      const pay = payment(d.paid);
      if (pay.postage != null) freight = pay.postage;
      subtotal = pay.subtotal; others = pay.other;
    }
    if (subtotal == null) {
      if (others.length) say(`what the buyer paid includes "${others[0]}" (a discount, fee or tax?): enter this order by hand`);
      else if ((d.paidNote || []).length) say(`what the buyer paid mentions "${d.paidNote[0]}" (a discount, fee or tax?): enter this order by hand`);
    }
    if (freight == null) say('the postage amount was not found');
    else if (freight < 0) say('the postage amount is below $0: enter this order by hand');
    const total = cents(h.money(d.total));
    if (!(total > 0)) say('the order total was not found');
    if (!problems.length && subtotal != null && subtotal + freight !== total)
      say(`the subtotal ${dollars(subtotal)} and postage ${dollars(freight)} don't add up to the total ${dollars(total)} (a discount, fee or tax?): enter this order by hand`);
    let units = null, source = '';
    if (!problems.length) {
      const p = prices(items, total, freight, subtotal != null);
      if (p.error) say(p.error); else { units = p.units; source = p.source; }
    }
    if (problems.length) return { problems, order: null };
    const out = {
      schema: SCHEMA, submissionId: 'EBY-' + order, createdUtc: new Date().toISOString(), orderNumber: order, orderDate: date,
      priceSource: source, sentFrom: sender || '',
      buyer: { name, phone, email, username },
      phones: { contact: phone, shipping: shippingPhone },
      address: { recipientName, street: streets[0], street2: streets.slice(1).join(', '), suburb, state, postcode },
      items: items.map((it, i) => ({ sku: it.sku, itemId: it.id, title: '', quantity: it.qty, unitCents: units[i] })),
      freightCents: freight, totalCents: total,
    };
    return { problems: [], order: out, summary: summary(out) };
  }
  // "W43116 x1 @ $140.00 + freight $10.00 = $150.00"
  function summary(o) {
    return o.items.map(it => `${it.sku} x${it.quantity} @ ${dollars(it.unitCents)}`).join(', ') +
      (o.freightCents ? ` + freight ${dollars(o.freightCents)}` : ' + free postage') + ` = ${dollars(o.totalCents)}`;
  }
  // 1.5.0: this Chrome sent orders to Tommy's PC (1.4) before it was paired with the Ebay-auto receiver, and the new
  // receiver can't know those. An order dated on or before the day of that switch may already be in COSTAR, so the
  // panel asks before sending it (when the receiver doesn't know it). orderDate "dd/mm/yy" as build() makes it,
  // switchDay "YYYY-MM-DD" (this PC's day of the first pairing with the Ebay-auto receiver); no switch day: false.
  function beforeSwitch(orderDate, switchDay) {
    const o = String(orderDate || '').match(/^(\d{2})\/(\d{2})\/(\d{2})$/), s = String(switchDay || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!o || !s) return false;
    return 20000000 + Number(o[3]) * 10000 + Number(o[2]) * 100 + Number(o[1]) <= Number(s[1]) * 10000 + Number(s[2]) * 100 + Number(s[3]);
  }
  // What the receiver says about an order, for the panel: {tone: ok|wait|work|check|bad, text, again}. 1.5.0: an order
  // handed over (an item COSTAR doesn't know) is left open in COSTAR for a person: said, and never sent again from here.
  function describe(status) {
    const s = status || {};
    const msg = String(s.message || '').trim();
    switch (s.status) {
      case 'queued': return { tone: 'wait', text: 'Sent ✓ Waiting for COSTAR' + (s.waiting ? ': ' + s.waiting : '.') };
      case 'entering': return { tone: 'work', text: 'Being entered into COSTAR Sydney' + (s.progress || msg ? ': ' + (s.progress || msg) : '…') };
      case 'ready_for_review': return /CHECK BY HAND/.test(msg) ? { tone: 'check', text: 'In COSTAR Sydney ✓ but ' + msg.slice(msg.indexOf('CHECK BY HAND')) } : { tone: 'ok', text: 'In COSTAR Sydney ✓ ' + (msg || 'ready for review') };
      case 'handed_over': {
        const left = String(s.remaining || '').trim().replace(/[.\s]+$/, ''), why = msg.replace(/[.\s]+$/, '');
        return { tone: 'check', text: 'NEEDS YOU: in COSTAR Sydney but not finished, ' + (left ? 'left to do by hand: ' + left : (why || 'see the Ebay-auto receiver')) + '. Finish it in COSTAR, then Mark done by hand on the receiver.', handed: true };
      }
      case 'failed': return { tone: 'bad', text: 'Stopped: ' + (msg || 'see the Ebay-auto receiver'), again: true };
      case 'removed': return { tone: 'bad', text: 'Removed on the Ebay-auto receiver. Send it again if it should be entered.', again: true, resend: true };
      default: return { tone: 'wait', text: msg || 'Unknown status' };
    }
  }
  const api = { SCHEMA, NUMBER, MAX_ITEMS, cents, signedCents, payment, prices, build, summary, describe, stateCode, beforeSwitch };
  root.CostarSend = api;
  if (typeof module === 'object' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
