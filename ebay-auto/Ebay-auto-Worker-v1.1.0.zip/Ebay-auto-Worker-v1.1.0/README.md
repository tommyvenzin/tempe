# Ebay-auto 1.1.0

Seb's standalone eBay → COSTAR Sydney app, built from Tempe COSTAR Helper 2.9.10 (commit f77a254, its eBay
implementation) and 404 But It's Found 1.4.3. Tommy's PC is not part of it.

```
404 extension (Chrome, Seb's PC) → receiver (Seb's PC, :8811) → worker (Seb's Remote Desktop session) → COSTAR Sydney
```

1.1.0 adds one-click updates from Ebay-auto's own GitHub folder, finds COSTAR Sydney by itself among other COSTARs
(several Sydney: the earliest-started one, kept while valid), and has compact windows that hide fully in the
notification area.

- **SETUP.txt**: how to install and use it (Seb's PC steps, then inside-Remote-Desktop steps), updates, which Sydney.
- **MIGRATE-FROM-1.0.0.txt**: moving a running 1.0.0 to 1.1.0, once, by hand (1.0.0 can't update itself).
- **CHANGES.md**: what changed in 1.1.0 and 1.0.0, and the known limitations.
- **FEATURES.md**: every eBay feature of 2.9.10 / 1.4.3 and where it is now, plus the 1.1.0 additions.
- **VALIDATION.md**: what was tested here and how (and what was not tested live).

## What is in this folder

| Path | What |
|---|---|
| `Source/` | The C# source (C# 5, .NET Framework 4.x WinForms). The 2.9.10 files plus `EbayAuto*.cs` (program, receiver, worker, tray, diagnostics, tests; 1.1.0: `EbayAutoCostar.cs` which COSTAR Sydney, `EbayAutoUpdate.cs` updates), `Product.cs` (the app's identity: name, version, protocol, folder, ports, names, update folder) and `Runner.EbayAuto.cs` (unknown item / Quick Item Add / hand-over). `Program.cs` (the Tempe helper's entry point) is not part of it. |
| `Build.ps1` | Builds `EbayAuto.exe` on the PC with the Windows C# compiler into `%LOCALAPPDATA%\EbayAuto\runtime\<build id>\bin` and runs the self-tests (`-ReportTo <file>`: the outcome as JSON, for the updater). Nothing is downloaded. |
| `Launch.ps1` | Builds and starts one part: `-Mode Receiver` or `-Mode Worker` (`-Show` opens its window, `-Hidden` for Start with Windows). Hands over to a newer installed version of the same part (`packages\current-<part>.txt`); an installed version that can't build is set aside for the newest earlier one. |
| `Setup-Receiver.cmd/.ps1` | Seb's PC, once: certificate, firewall, receiver settings. |
| `Start-Receiver.cmd`, `Start-Worker.cmd` | Start a part (in the notification area; run again to open its window). |
| `Check-Build.cmd` | Build and self-tests only. |
| `Extension/404-but-its-found/` | The 404 extension 1.5.0 (unchanged in 1.1.0). |
| `Tests/` | Node tests for the extension, the receiver harness, the end-to-end test and (1.1.0) the update replay (not shipped in the packages, never uploaded to GitHub). |

The receiver package holds `Source`, `Build.ps1`, `Launch.ps1`, `Setup-Receiver.*`, `Start-Receiver.cmd`,
`Check-Build.cmd`, the docs, `VERSION.txt`, `PART.txt` (`Receiver`) and `PACKAGE-SHA256.json` (every file's SHA-256);
the worker package the same with `Start-Worker.cmd` instead of the receiver's scripts and `PART.txt` = `Worker`. Both
build the same `EbayAuto.exe`. Each ZIP has one top folder named like the ZIP (`Ebay-auto-Worker-v1.1.0`).

## Updates (1.1.0)

Ebay-auto's own release file is `https://tommyvenzin.github.io/tempe/ebay-auto/latest.json` (the tempe repository's
`ebay-auto` folder, beside the Tempe helper's `helper` folder, served by GitHub Pages):

```json
{ "product": "Ebay-auto", "version": "1.1.0", "name": "...", "notes": "...", "published": "2026-11-16", "protocol": 1,
  "receiver": { "zip": "Ebay-auto-Receiver-v1.1.0.zip", "sha256": "...", "size": 0 },
  "worker":   { "zip": "Ebay-auto-Worker-v1.1.0.zip",   "sha256": "...", "size": 0 } }
```

Each part reads only that file and downloads only from that folder; a file without `"product": "Ebay-auto"` (like the
Tempe helper's `helper/latest.json`) or a package that isn't Ebay-auto's for that part and version is refused. The
Tempe helper's own updater code is compiled in for the shared code but has no feed here. `UPLOAD-TO-GITHUB.txt` (with
each release) says how to publish one.

## Data (per Windows user, `%LOCALAPPDATA%\EbayAuto`)

- `receiver\settings.dat` (address, ports, certificate thumbprint, the eBay and worker keys; encrypted with DPAPI),
  `receiver\ebay.dat` (the queue, encrypted), `receiver\Ebay-auto-Root.cer` (the public root certificate).
- `worker\settings.dat` (the connection, encrypted), `worker\ebay-journal.dat` (attempts, entered, handed over,
  encrypted), `worker\alerts.dat` (the Discord webhook, encrypted), `settings.json` (the worker's ticks: close each
  Repair Order, direct presses, long poll, eBay orders on), run records and entry reports.
- `events-<part>-<day>.jsonl` (the journey), day logs, `Ebay-auto-<part>-Diagnostics-*.zip`, `startup-*.txt`.
- 1.1.0: `packages\Ebay-auto-<Part>-v<version>` (installed updates, the newest three of each part kept),
  `packages\current-receiver.txt` / `current-worker.txt` (the version every launcher hands over to), `update\` (what
  a version being replaced leaves for the new one: running/paused and window, or why a new version didn't start).

None of these files may be shared except the diagnostics ZIP (it leaves out buyer details, eBay order numbers, keys
and card details). Never share `worker-connection.json` or `settings.dat`.
