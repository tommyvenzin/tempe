# Ebay-auto: what changed, and known limitations

## 1.1.0 (16 Nov 2026)

Three improvements asked for after Seb's first use of 1.0.0; everything else is unchanged (order entry, the unknown-SKU
hand-over, duplicate protection, the queue, retries, diagnostics, the 404 extension 1.5.0).

### 1. COSTAR Sydney found by itself, with other COSTARs open (`EbayAutoCostar.cs`, `EbayWorker.cs`)

**What 1.0.0 did** (traced in its discovery, readiness and window-selection code): every 3 s `FindTarget` listed the
COSTAR main windows of the session by title, sorted by PID, kept those of Branch 1, and went on only when exactly one was
left: with two COSTAR Sydney open, every order waited ("close all but one"). Other branches were filtered out by their
titles, so they alone never stopped it. Just taking the first of several would not have been safe: the list was made
again every 3 s in PID order (not by when a COSTAR started), a Sydney whose title couldn't be read for a moment dropped
out of it, and any failed check on the chosen one (busy, a window over it, not on Work-in-Progress) cleared the choice,
so the next look could have picked the other Sydney. A Retry of an order typed part-way was checked against whichever
COSTAR was chosen at that time, not its own. COSTAR can also switch branch inside one running program (seen in the day
logs), so a title is not a fixed identity.

**Now:**
- Each COSTAR is known by its process: PID **and** Windows' start time for it (and its session). A restarted COSTAR is
  a new one even if Windows gives it the same PID. Order Check's COSTAR is never used.
- One Sydney open: that one. Several: the **earliest-started** (by the process start time, never PID order, window
  order or which is in front).
- The choice is **kept** while it is valid: another Sydney opening, the windows changing order, or an earlier-started
  COSTAR switching to Sydney change nothing.
- The chosen COSTAR busy, not answering, with a window of its own over it, off Work-in-Progress, or its title
  unreadable for a moment: new orders **wait** with the reason (on the eBay page and in the worker); nothing else is
  chosen meanwhile. A branch change counts only when it shows another branch on two looks at least a second apart.
- Closed, restarted or changed: the earliest-started Sydney still open is chosen, **for new orders only**. None open:
  orders wait for one.
- An order being entered stays in its COSTAR and Repair Order (as before). **The Retry of an order typed part-way goes
  back only into its own COSTAR process and Repair Order**, whichever Sydney is chosen for new orders; if that COSTAR
  closed or restarted, the Retry is refused as in 1.0.0 (check COSTAR, then Mark done by hand or Start again). It is
  never typed into another COSTAR.
- The worker's window shows the COSTAR in use (branch, PID, start time) and how many Sydney are open.
- Journey (diagnostics): `costar_scan` (every change in the COSTARs seen: branch, PID, start time, Order Check's
  marked), `costar_target` (every choice and why: the only one, the earliest-started of N, kept, closed, restarted,
  changed branch), `costar_pinned` (a Retry sent back to its own COSTAR), and the waiting reasons. Never a window title
  (it can name a customer).

### 2. One-click updates from GitHub (`EbayAutoUpdate.cs`, `EbayAutoTray.cs`, `EbayAutoProgram.cs`, `Launch.ps1`, `Build.ps1`)

- The same way as the Tempe helper (Tommy uploads, Seb clicks Update), from **Ebay-auto's own folder** in the same
  repository and GitHub page: `https://tommyvenzin.github.io/tempe/ebay-auto/latest.json`, beside the helper's `helper`
  folder. Its own `latest.json` (product "Ebay-auto", version, protocol, one package per part with SHA-256 and size)
  and packages (`Ebay-auto-Receiver-v<v>.zip`, `Ebay-auto-Worker-v<v>.zip`).
- **Never the Tempe helper**: a release file without `"product": "Ebay-auto"` is refused; only the two Ebay-auto package
  names are accepted; downloads only from that folder (no redirects); the unpacked package must be one folder named for
  this part and version, every file must match its `PACKAGE-SHA256.json`, `VERSION.txt` and `PART.txt` must say this
  version and part, its `Source\Product.cs` must be Ebay-auto's, and a package with the Tempe helper's launchers
  (`Start-RDP.cmd`, `Start-Desk.cmd`, `Setup-Desk.cmd`) is refused.
- **Each part updates itself** (Updates tab: Check for updates, Update now, Cancel update; tray: Update to X): this
  version and the one on GitHub with its notes, the other part's version, progress (download with a bar, checking,
  building, waiting, switching) and any failure in words. It checks a minute after starting and every 6 hours (a
  balloon once per new version).
- **Built before anything changes**: the new version is downloaded, checked and unpacked beside the running one
  (`%LOCALAPPDATA%\EbayAuto\packages`), then built and self-tested on the PC (hidden, below normal priority) while the
  running version keeps working. A version that doesn't build or pass is never switched to.
- **Waits for a safe point**: the worker switches only with no order being entered and the receiver told to hold new
  orders; the receiver only while the worker isn't entering one, holding new orders meanwhile (the extension's orders
  are still taken and kept). Held orders go into COSTAR straight after. Nothing is interrupted.
- **The switch**: the running version saves its state (receiving or paused, eBay orders on or paused, window open or
  hidden), lets go of its ports, poll, tray icon and single-instance lock, and starts the new version in the same part.
  The new one restores that state and, once up, says so; only then does the old one close, and every launcher and
  "Start ... when I sign in" now start the new one (`packages\current-<part>.txt`). If the new version doesn't say it
  is up within 90 s, or stops, it is closed and the old version starts again by itself, opens its window and says why
  (kept for diagnostics). If an installed version can't build on a later start, `Launch.ps1` sets it aside and starts
  the newest earlier version.
- Kept through an update (all in `%LOCALAPPDATA%\EbayAuto`, never touched): pairing, keys, certificate, settings, the
  queue, the duplicate history, the worker's journal and any result not yet acknowledged, diagnostics, Discord, Start
  with Windows. The newest three packages of each part stay on the PC; older builds are tidied ten minutes after a
  start (the two newest and the running one are kept).
- **Mixed versions**: the two parts say their version and a protocol number in every poll and reply (1.0.0 said none:
  it counts as 1, the same as 1.1.0, so 1.0.0 and 1.1.0 work together). A part that meets a protocol it doesn't know
  hands out or takes no orders, and both say which part to update; orders wait on the receiver, nothing is lost.
- **1.0.0 can't update itself** (it has no updater): MIGRATE-FROM-1.0.0.txt moves each part once by hand; after that,
  one click.
- Journey: `update_checked` / `update_available` / `update_started` / `update_installed` / `update_built` /
  `update_waiting` (and why) / `update_switching` / `update_handed_over` / `update_completed` (in the new version) /
  `update_failed` / `update_start_failed` / `update_cancelled`, `protocol_mismatch` / `protocol_ok`.

### 3. Compact windows, hidden properly in the notification area (`EbayAutoTray.cs`, `EbayAutoReceiver.cs`, `EbayAutoWorker.cs`)

- Both parts start hidden in the notification area (as before; the worker opens its window when it has no connection
  yet). **Minimise and X hide the window completely** (no taskbar button), also when minimised another way (Windows+M,
  the taskbar). Hidden, everything keeps running (queue, worker, timers, connection, diagnostics). Double-click the icon
  or Open brings it back (restored, on screen even if the screen got smaller meanwhile). Exit stays the only way to
  close a part, and is safe as before.
- **Compact windows with tabs**, sized from the screen and its scaling (100–200 %), by the clock: receiver about
  600×480 at 100 % (Orders, Pairing, Updates, More), worker about 600×500 (Activity, Connection, Settings, Updates,
  More); a status line at the top of each. Controls wrap and pages scroll on small screens. Every function of 1.0.0 is
  on a tab.
- Message boxes open the window first (never a box behind nothing). One tray icon per part (it is removed before an
  update's switch). The update's build and the Start with Windows launch run hidden; no launcher window stays on the
  taskbar. Windows' own notification-area settings are not changed.
- Journey: `layout_check` (each tab the first time it shows: scaling, window and screen size, and anything that doesn't
  fit).

### Known limitations (1.1.0)

- **Not tested live.** Nothing here ran on Windows, inside Remote Desktop, or with COSTAR (VALIDATION.md says exactly
  what was tested and how). Not tested live: choosing Sydney among real COSTAR processes, the tray and windows on
  Windows at the different scalings, the update's build and switch between two running programs on Windows, GitHub
  Pages serving `ebay-auto/latest.json`, Start with Windows after an update.
- **The first move to 1.1.0 is by hand** (1.0.0 has no updater).
- While the **receiver** switches (about a minute), the 404 extension can't reach it: an order sent then says so; Send
  again (nothing is entered twice). While the **worker** switches, orders wait on the receiver.
- An update waits for the order being entered to finish; held orders wait until the switch (about a minute). Cancel
  update ends the wait.
- **Which Sydney** can't be picked in the window: the earliest-started one is used. To move the worker to another
  Sydney, close the one in use while no order is being entered. "Earliest-started" is when the COSTAR program started,
  not when it was switched to Sydney.
- A Retry of an order typed part-way whose COSTAR was closed or restarted is refused (as in 1.0.0): check COSTAR.
- **Scaling** is read when a part starts: after changing Windows' display scaling (or reconnecting Remote Desktop at
  another scaling), Exit and start the part again for the best fit.
- Windows decides whether a new tray icon shows by the clock or in the arrow's overflow (it can be dragged out).
- Older Ebay-auto folders aren't removed by themselves; the old 1.0.0 folders can be deleted once both parts run 1.1.0.
- The limitations of 1.0.0 below still apply (keep the Remote Desktop session connected, the network, the cut-over,
  Windows policy, unknown items, wheel/package SKUs).

## 1.0.0 (16 Nov 2026)

Built from Tempe COSTAR Helper 2.9.10 (commit f77a254, its eBay implementation) and 404 But It's Found 1.4.3.
Every eBay feature of those two is kept (FEATURES.md lists each one and where it is now); nothing that isn't eBay is
started or shown.

### What changed

**One standalone app, two parts, Tommy's PC not used**
- `EbayAuto.exe` (built on each PC from `Source`, as the Tempe helper is) runs as the **receiver** on Seb's physical PC
  (Start-Receiver.cmd) or as the **worker** inside Seb's Remote Desktop session (Start-Worker.cmd).
- The flow is 404 extension → receiver (Seb's PC) → worker (Seb's RDP session) → COSTAR Sydney (Branch 1).
- The worker reaches the receiver at Seb's PC's real network address (it refuses localhost/127.0.0.1: inside Remote
  Desktop that is the Remote Desktop server). It only ever looks at COSTAR in its own Windows session.

**Kept apart from the Tempe helper**
- Own data folder `%LOCALAPPDATA%\EbayAuto` (settings, queue `ebay.dat`, journal `ebay-journal.dat`, keys, logs,
  diagnostics, build), own ports **8811/8812** (the Tempe desk's 8790/8791 and Order Check's 8795–8804 are refused),
  own single-instance names (`Global\EbayAuto_<part>_<user>`), own Start-with-Windows files (`Ebay-auto - Receiver.cmd`,
  `Ebay-auto - Worker.cmd`), own diagnostics names (`Ebay-auto-*`), own package names (`Ebay-auto-v*`).
- **No updater feed**: Ebay-auto never checks, downloads or installs updates (it can't reach the Tempe release feed).
- The one thing shared on purpose: COSTAR's input lock in a Windows session, so Ebay-auto and a Tempe helper in the
  same session never type into COSTAR at once.

**Receiver (Seb's PC)**
- Setup-Receiver.cmd: builds, picks this PC's LAN address, makes the receiver's own certificate (trusted for this
  Windows user; about 2 years, warned 30 days before), opens 8811–8812 in Windows Firewall for private addresses on
  Private/Domain networks only, sets the receiver up. Re-running it keeps the pairing keys and the list.
- Serves only the eBay routes (no phone jobs, website or Repair Orders). The extension pairs with a PIN as before.
- The eBay list as on the Tempe desk (Retry, Start again in a new RO, Mark done by hand, Remove, Hide finished, the one
  retry by itself), plus a Job column and the new **NEEDS YOU: finish by hand** state.
- Worker connection: Export worker connection (file) as before, and **Copy connection** (text for the Remote Desktop
  clipboard; taken off the clipboard after 2 minutes).

**Worker (inside Remote Desktop)**
- The 2.9.10 eBay engine and COSTAR entry, unchanged for a complete order: phone lookup and identity rules, header,
  Ship to, Rebill to EBAY + Card#, Written By/Salesperson, items at the eBay price, freight, memo lines, the final check,
  close to Work-in-Progress, retry in the same unchanged Repair Order, the journal and duplicate checks, Stop all.
- **Waits instead of stopping** when COSTAR Sydney doesn't answer or a COSTAR window is over it (the reason is shown on
  the eBay page), as before when someone is using the session.
- Paste connection (text), Import connection (file, offers to delete it), or worker-connection.json beside the launcher.

**Unknown item (an eBay SKU COSTAR doesn't know, e.g. a wheel or a package)** (Runner.EbayAuto.cs)
- No SKU conversion or guessing (wheel/package mapping is left for later).
- Recorded first: the SKU, the code typed, the item's position, quantity and price, and COSTAR's window (title, class,
  owner, buttons, stage).
- Only a window that is exactly COSTAR's **Quick Item Add** (that title, owned by this job's Repair Order, one usable
  Cancel and one Add item) is answered, with **Cancel**. **Add item is never pressed.** Anything else is left as it is and
  the order stops as in 2.9.10.
- After Cancel the worker looks at what is there (the Repair Order usable, no other COSTAR window, what the line holds).
  It never deletes or overwrites a line. If all is clear it carries on with the safe remaining steps (the other items,
  freight, memo lines); if anything is unclear, or COSTAR asks about the code again, it stops right there.
- Then it checks what it can (header, Ship to, every line it entered) but never reports the order verified: no
  balancing amounts, no moved prices, the total check stays on for every other order.
- The order is **handed over**: the Repair Order is left **open** (never closed), the job is released, and the receiver,
  the eBay panel ("NEEDS YOU …"), the tray and Discord say what is left to do by hand. It is never retried or continued
  by itself, nor by Retry or Send again; Start again (new RO), Mark done by hand and Remove stay. The duplicate check
  treats it as entered. The next order goes into its own new Repair Order and never touches the handed-over one (the
  worker also notes when that one is closed).

**Tray (both parts)**
- Start hidden in the notification area and work hidden; X hides; double-click or Open brings the window back;
  right-click: Open, Pause/Resume receiving or Pause/Start eBay orders, Export diagnostics, Exit. Exit asks, and the worker
  first stops an entry at a safe point (recorded for Retry/Start again). The icon's colour and words give the state;
  balloons for orders that need Seb, a stop, the worker out of touch for 5 minutes, the certificate running out.
- A second start of a part opens the running one's window.

**Diagnostics (both parts)**
- Export diagnostics on either part. The receiver's ZIP: summary, queue (no buyer details), the journey, the day log,
  and the worker's ZIP (asked over its poll) or a note saying why it isn't there. The worker's ZIP: summary, run
  records, outcome counts, the journey, the day log, and the receiver's ZIP or a note.
- A journey line per event with the time and time zone and the job (J-…), attempt (A-…) and request (R-…) ids:
  received, queued, claimed, started, completed, handed over, stopped, waiting reasons when they change, Retry / Start
  again / Mark done / Remove, unknown items with the SKU, code, position and quantity, the Quick Item Add window and what
  was done with it, what was found after Cancel, the handed-over Repair Order open/closed, connection interruptions and
  restarts, errors, stage timings.
- Counts keep apart: fully entered and verified (completed without help), entered and verified with CHECK BY HAND,
  handed over (manual completion needed, not verified), marked done by hand, waiting, stopped/uncertain. CHECK BY HAND
  is never counted as completed without help (the 16 Nov example: 20 completed, 19 without help).
- No buyer names, phones, addresses, emails, eBay order numbers, keys, tokens or card details.

**404 But It's Found 1.5.0**
- Sends to the Ebay-auto receiver: the address takes a port (default 8811), the certificate link uses port + 1, and
  Tommy's PC's address is no longer in the manifest.
- Its own pairing (stored apart from the 1.4 pairing with Tommy's PC, which is never used and left as it was).
- Each send and retry carries a request id (X-Request-Id) for the diagnostics.
- The panel's **NEEDS YOU** state (button "Needs you", never sent or retried from the page) with what is left.
- **Cut-over check**: an order sold on or before the day of the switch from Tommy's PC that the receiver doesn't know
  may already be in COSTAR: the panel says so and its button reads "Send to COSTAR anyway".

### Known limitations (1.0.0)

- **Not tested live.** Nothing here was run against COSTAR, in Remote Desktop, or on Windows. Not tested live: the
  Quick Item Add recognition and Cancel, what COSTAR shows after it, carrying on after an unknown item, the hand-over
  in COSTAR, the next order beside a handed-over Repair Order, the worker in an RDP session, the tray, Setup-Receiver
  (certificate, firewall), Chrome on Windows reaching the receiver (the Allow tab). VALIDATION.md says exactly what was
  tested and how.
- **What COSTAR does after Quick Item Add is cancelled is unknown.** The window's title and buttons come from a
  recorded run (5 Nov). If COSTAR keeps the unknown code in the line, or asks again when the line is left, the worker
  stops at that point and hands over with what is left (it never deletes the line); the first live unknown-item order
  may therefore stop earlier than "everything else entered". Please send its diagnostics.
- **Wheel and package SKUs are not mapped**: such orders are always handed over for Seb.
- **Keep the Remote Desktop session connected**, with its window open (behind other windows is fine). As in 2.9.10,
  a disconnected, locked or minimised session was not tested; Windows may stop the session's screen when the window is
  minimised, and then the worker can't type (if it must be minimised, IT can set
  `RemoteDesktop_SuppressWhenMinimized = 2` for Remote Desktop on Seb's PC, then test with one order).
- **The network**: the Remote Desktop server must reach Seb's PC at its LAN address on TCP 8811–8812. The firewall rule
  only allows private addresses on Private/Domain networks; a VPN or NAT path may need IT. Keep Seb's PC's address
  fixed (DHCP reservation); after a change run Setup-Receiver again, pair the extension again and give the worker a new
  connection. Seb's PC must be on, with the receiver running, for orders to be taken.
- **Cut-over**: Ebay-auto can't see what Tommy's PC entered. The extension asks before sending an order sold on or
  before the pairing day (that also asks once for older orders never sent). Turn **eBay orders off in the Tempe helper**
  once Ebay-auto works, and don't keep 1.4.3 paired with Tommy's PC on another browser, so only one system enters eBay
  orders.
- **Windows policy**: the launchers run PowerShell with `-ExecutionPolicy Bypass` and build an unsigned EbayAuto.exe in
  `%LOCALAPPDATA%`; AppLocker/WDAC on the Remote Desktop server could block that (then IT must allow it).
- The worker connection is a key: Windows clipboard history (if turned on) may keep a copy of Copy connection.
- Balloons depend on Windows notification settings (Focus assist can hide them); the icon colour and the windows always
  show the state.
- The receiver's list shows buyer names, on Seb's PC only (as the Tempe desk did).
