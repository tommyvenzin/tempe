# Ebay-auto 1.1.0: the eBay features of helper 2.9.10 and extension 1.4.3, and where each one is now

Taken from the 2.9.10 source (commit f77a254) and the 1.4.3 extension before anything was changed. Every row is kept
in Ebay-auto (1.0.0, and still in 1.1.0); the last column says where it lives now and how it was checked (see
VALIDATION.md for the runs). The 1.1.0 additions are at the end.

R = Ebay-auto Receiver (Seb's physical PC). W = Ebay-auto Worker (inside Seb's Remote Desktop session).
X = the 404 But It's Found extension (Chrome on Seb's physical PC).

Checked: S = self-test (source level, made-up data), E = end-to-end test here (real extension in Chromium, the real
receiver code over TLS, the worker side played by a script), C = compiled and inspected only, L = needs live COSTAR
(not tested here).

## The eBay PC's extension (1.4.3 → 1.5.0)

| ID | Feature | 2.9.10 / 1.4.3 | Ebay-auto | Checked |
|---|---|---|---|---|
| X1 | Copy panel on eBay order pages, opened automatically (tick box) | ebay_order_console.js, background.js | X, unchanged | E |
| X2 | Copy the console script, Show copy panel on this page | popup.js | X, unchanged | C |
| X3 | Send to COSTAR: the order built from the page (state code, eBay prices, postage, total must add up, discounts refused, SKU required, 1-4 items) | costar_send.js build() | X, unchanged | S, E |
| X4 | Panel status: waiting (with the reason), being entered (progress), in COSTAR ✓ / CHECK BY HAND, stopped (Send again = Retry), removed (Send again = send again) | costar_send.js describe() | X + new "needs manual completion" | S, E |
| X5 | Status followed every 3 s for 20 minutes; checked again when the page is opened | ebay_order_console.js | X, unchanged | E |
| X6 | Pairing with address + PIN, Chrome's host access (allow tab), certificate install link, Check again, Forget | popup.js, allow.js, background.js | X; the address takes a port (IP:8811); certificate link uses the receiver's own trust port; its own pairing (the 1.4 pairing with Tommy's PC is never used, left as it was) | E (the Allow tab itself: L) |
| X7 | Health in the popup (receiving, worker in touch, eBay on, ready, waiting) | popup.js | X, wording names the receiver | E |
| X8 | Only the extension's own pages and its panel on ebay.com.au may ask; the key stays in the extension | background.js allowed() | X, unchanged | E |
| X9 | (new) Cut-over: an order sold on or before the day of the switch from Tommy's PC, unknown to the receiver, asks first ("Send to COSTAR anyway") | - | X (costar_send.js beforeSwitch, the panel) | S, E |

## The receiver (Tommy's desk PC → Seb's physical PC)

| ID | Feature | 2.9.10 | Ebay-auto | Checked |
|---|---|---|---|---|
| D1 | HTTPS on the PC's LAN address with its own certificate; trust.cer on a second port | DeskForm, LocalServer, Setup-Desk | R (Setup-Receiver: own certificate, own ports 8811/8812; warned 30 days before the certificate runs out) | S, E (Setup-Receiver on Windows: L) |
| D2 | eBay key separate from everything else; 6-digit PIN pairing (10 min, 5 tries, one use); Reset eBay pairing | EbayPairing, EbayDesk | R | S, E |
| D3 | eBay routes only for the extension's origin; health, submit, status, retry | ReceiverApi.EbayRoute | R (and nothing but the eBay routes is served) | S, E |
| D4 | One receipt per eBay order number; same details = same order; changed before pickup replaces; after pickup CONFLICT; removed and sent again (new RO, or continues if typed) | EbayQueue.Submit | R | S, E |
| D5 | FIFO, leases, a lost claim comes back with the same lease, declines go back in line with the reason, "no longer entering" → stopped, reports acknowledged by sequence, 50 waiting at most, old finished pruned past 300 | EbayQueue.Poll | R | S, E |
| D6 | Queue kept on disk, encrypted (ebay.dat); unreadable → set aside, receiver still starts | EbayDesk.SetupEbay | R (its own folder) | S |
| D7 | eBay list: order, buyer, total, status, message, colours; Retry, Start again in a new RO, Mark done by hand, Remove (each confirmed), Hide finished | EbayDesk | R + Job column; the new "needs manual completion" state | C, S |
| D8 | Retried once by itself 60 s after a stop that typed nothing (within 30 min, worker in touch and on) | RunsByItself.RetryOnce | R | S |
| D9 | Tray message when the worker has been out of touch 5 minutes | DeskRunsTick | R (tray) | C |
| D10 | Receiving on/off | DeskForm | R (Pause / Resume receiving, also in the tray) | S, E |
| D11 | Export the worker connection (worker-connection.json) | DeskForm.ExportWorker | R + Copy connection (text, for the Remote Desktop clipboard; taken off it after 2 minutes) | S, C |
| D12 | Start with Windows | DeskRunsRow | R ("Ebay-auto - Receiver.cmd"; 1.1.0: hidden, follows updates) | S, E (Launch.ps1 hand-over) |

## The worker (the RDP helper's eBay side → inside Seb's Remote Desktop session)

| ID | Feature | 2.9.10 | Ebay-auto | Checked |
|---|---|---|---|---|
| W1 | Long-poll to the receiver, declines, acknowledgements, the journal (ebay-journal.dat, encrypted; unreadable → set aside) | EbayEngine | W | S, E (protocol) |
| W2 | Exactly one COSTAR Branch 1 in this Windows session, never Order Check's window, looked for again every 3 s | EbayEngine.FindTarget, CostarWindows.Choices | W (same session only, as before). 1.1.0: any number of COSTARs; of several Sydney the earliest-started, kept while valid (N1) | S, L |
| W3 | Waits: another entry, the old online helper, COSTAR Sydney missing or two open, not on Work-in-Progress, someone using the PC (3 s) | EbayEngine.Available | W + waits while COSTAR Sydney doesn't answer or a COSTAR window blocks it (instead of taking the order and stopping). 1.1.0: two Sydney open no longer wait (N1); the chosen one unreadable for a moment waits | S, L |
| W4 | Refusals before COSTAR is touched: bad order, entered before (unless Start again), typed before but sent as new, typed on the desk's word with no record | EbayAttempts.Refusal | W (+ handed over counts as entered) | S |
| W5 | Attempts: fresh / reuse an empty RO / resume an unchanged RO / refuse; recorded before the receiver hears; restart finds a lost attempt and reports it | EbayAttempts.Decide, EbayEngine | W (+ a lost attempt with an unknown item is reported as handed over) | S |
| W6 | Add New only on Work-in-Progress, cover waited out 1.5 s, one press, 30 s for the RO, a new RO beside any already open | CostarWindows.OpenNew | W, unchanged | L |
| W7 | Startup checks, Ship to tab first, resume only in the same unchanged RO, blank checks, an earlier empty RO that changed → a new RO once | Runner.RunEbay | W, unchanged | L |
| W8 | Customer by phone: account kept, Customer Not found dismissed, two accounts → first, all-branch search, Notes/memo answered, popup recovery | Runner.Customer.cs, Runner.Popups.cs | W, unchanged | L |
| W9 | Header (PO# = eBay number, comment EBAY DFE), Ship to (buyer, DFE), identity checks | Runner.Customer.cs | W, unchanged | L |
| W10 | Rebill to EBAY + Card# (tab, layout, locked boxes, the RO it stopped in, rebill name, a window after EBAY) | Runner.Ebay.cs FillRebill | W, unchanged | L |
| W11 | Written By and Salesperson SA (not found / locked / not kept → CHECK BY HAND) | FillStaff | W, unchanged | L |
| W12 | Lines spaced as the example RO: items at the eBay price, F, M E per item, M BUY, M DFE; note key press; resumed lines checked | Runner.Ebay.cs, Runner.Grid.cs | W + unknown item: Quick Item Add cancelled, the rest entered where safe | S (rules), L |
| W13 | Final check: header, Ship to, staff, Terms 7INV (CHECK BY HAND), the lines exactly, total = eBay total | VerifyEbay | W unchanged for a complete order; an order handed over is never reported verified | S (rules), L |
| W14 | Close after entry (setting, on by default): out of the lines, PO# and total checked, WM_CLOSE, nothing answered, CHECK BY HAND if it stays | CloseEntered | W, unchanged (never for an order handed over) | L |
| W15 | Reports: in COSTAR (closed / left open), Notes, CHECK BY HAND; entered list and report in one write | EbayEngine.Run | W + "handed over" with the unresolved items | S, E |
| W16 | Stops: report with typed flag, stop print, attempt saved; Discord at once or after 3 min; Stop all (Ctrl+Alt+F10) | EbayEngine.Run, Alerts | W | S, C |
| W17 | Check Sydney layout (types nothing) | EbayEngine.CheckLayout | W | C, L |
| W18 | Start / Stop eBay orders (kept); Stop all pauses (not kept) | EbayTab, DesktopUi.StopAll | W (also in the tray) | C |
| W19 | Close each Repair Order once it's in (tick box) | EbayTab | W | C |
| W20 | Discord alerts: webhook set / test / off, encrypted, rate limits, masked words; receiver unreachable for 5 minutes | Alerts, RunsByItself | W | S |
| W21 | Import the connection (file, or worker-connection.json beside the launcher) | RunsByItself.ImportConnection, Launch.ps1 | W + Paste connection (text) | S |
| W22 | Diagnostics: run records, day log, Save diagnostics ZIP; full entry reports kept locally 30 days | Diagnostics.cs | W + the receiver's logs in the same ZIP when it can be reached | S, E |
| W23 | Direct presses and long poll settings | Files & settings | W | C |
| W24 | Start with Windows | RunsByItselfCard | W ("Ebay-auto - Worker.cmd"; 1.1.0: hidden, follows updates) | S, E (Launch.ps1 hand-over) |
| W25 | One helper types into COSTAR at a time in a Windows session (input lock) | CostarInputLock | W, the same lock as the Tempe helper (they never type at once in one session) | C |

## Not part of Ebay-auto (not eBay features)

Phone jobs, online orders, the phone's Repair Orders, Order Check, the wholesale dry run, the Job Card website, the
time-saved boss report and the Tempe updater stay in the Tempe helper. Their code is compiled into EbayAuto.exe (the eBay
engine shares it) but nothing in Ebay-auto starts or shows them.

## Added in 1.1.0

Checked: S = self-test, E = end-to-end here (extension + real receiver code; for updates: the real update code against
the real release files served over HTTP, Tests/update_replay.ps1), C = compiled and read, L = needs Windows / Remote
Desktop / COSTAR (not tested here).

| ID | Feature | Where | Checked |
|---|---|---|---|
| N1 | COSTAR Sydney chosen by itself: other branches never in the way; of several Sydney the earliest-started (process start time, not PID, window order or foreground), kept while valid; busy / unreadable / a window over it: wait, never switch; another branch only after two looks a second apart; closed or restarted (PID reused counts as new): the earliest-started remaining, for new orders only; none: wait | W: EbayAutoCostar.cs (SydneyChoice, Scan), EbayEngine.FindTarget / Available / Ready | S (made-up scans), L |
| N2 | A Retry of an order typed part-way goes back only into its own COSTAR process and Repair Order (refused, as before, when that COSTAR closed or restarted); an order being entered is never moved | W: EbayEngine.Accept, PinnedTarget, Run | C, L |
| N3 | The COSTARs seen, the choice and every change, in the journey (branch, PID, start time; never a title); the COSTAR in use in the worker's window | W | S, C |
| N4 | One-click update of each part from Ebay-auto's own GitHub folder: check (by itself a minute after start and every 6 h; Check for updates), versions shown (this, GitHub, the other part), Update now, progress, Cancel update, failures in words | R, W: EbayAutoUpdate.cs (EbayAutoUpdater), Updates tab, tray | S, E (download, checks, install), L (the window) |
| N5 | Never the Tempe helper's release: product, part, package names, folder, one top folder, every file, VERSION/PART, Ebay-auto's source, no Tempe launchers | EbayAutoUpdate.Validate / Install / Verify | S, E (the helper's latest.json and ZIP, re-wrapped, a changed byte, the other part's package: refused) |
| N6 | Built and self-tested on the PC before the switch; a failed build never switched to | EbayAutoUpdate.Build (Build.ps1 -ReportTo) | S (stubbed build), E (the report), L (csc on Windows) |
| N7 | The switch at a safe point only (no entry; new orders held on the receiver; the receiver keeps taking orders), state kept (receiving/paused, eBay on/paused, window), the same part restarted, the old version back by itself if the new one doesn't start | EbayAutoUpdater.Tick / Switch / Fail, EbayAutoProgram (--after-update, --restart-after), the forms' hooks | S (hold, wait, cancel, resume, failure records), E (receiver hold, worker updating), L (two programs switching on Windows) |
| N8 | Launchers and Start with Windows hand over to the newest installed version of the same part; one that can't build is set aside for the newest earlier one | Launch.ps1, AutoStart.Script | E (Launch.ps1 under PowerShell 7 with a stand-in for powershell.exe), S (the Startup file) |
| N9 | Mixed versions: version and protocol in every poll and reply; 1.0.0 (no number) = protocol 1; an unknown protocol takes or hands out nothing and both say which part to update | LocalHttp.cs EbayWorkerPoll, EbayEngine.Loop, Product.Protocol | S, E |
| N10 | Compact windows with tabs, sized for the screen and scaling (100–200 %), by the clock; a status line on top | EbayAutoTray.cs (EbayAutoLayout), the forms | S (sizes and places at 5 screens × 5 scalings), L |
| N11 | Start hidden; minimise (any way) and X hide completely (no taskbar button); double-click / Open restores (on screen); Exit safe; one icon; boxes open the window first; launch windows hidden | EbayAutoForm | C, L |
| N12 | Layout check per tab in the journey (anything that doesn't fit at this scaling and size) | EbayAutoForm.CheckLayout | S (the rule), L |
