// Ebay-auto 1.0.0: one program, two parts. EbayAuto.exe --receiver on Seb's physical PC, --worker inside his Remote
// Desktop session; --init-receiver (Setup-Receiver.ps1) and --self-test (Build.ps1). Each part keeps its own folder under
// %LOCALAPPDATA%\EbayAuto (receiver\, worker\), its own single-instance name and its own show signal, and starts in the
// notification area (--show opens the window; it also opens when something must be set up first).
// 1.1.0: --after-update <pid>: started by the version before it (EbayAutoUpdater), which has let go of the single-instance
// lock and waits for this one to say it is up (Product.ReadyEventName). This one waits for the lock (60 s at most), and a
// start that fails is written down for that version (no message box) so it can start itself again.
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Threading;
using System.Windows.Forms;

namespace TempeCostar {
    internal static class EbayAutoProgram {
        // The single-instance lock of this part, held from the start until Exit (or until an update lets go of it).
        static Mutex instance;static bool owned;static string runningPart;
        internal static bool AfterUpdate;
        // On the window's thread (the program's first thread): lets go of the lock so the new version can take it.
        internal static void ReleaseInstance() { if(owned) { owned=false;try { instance.ReleaseMutex(); } catch(Exception) { } } }
        // Once the window is up: the version waiting after an update is told, and every launcher now hands over to this one.
        internal static void Ready(string part) {
            try { EventWaitHandle ready;if(EventWaitHandle.TryOpenExisting(Product.ReadyEventName(part),out ready)) using(ready) ready.Set(); } catch(Exception) { }
            string folder=AutoStart.PackageFolder(part);
            try { EbayAutoUpdate.PointAtMe(part,folder);EbayAutoUpdate.Prune(part,folder); } catch(Exception e) { AppLog.Note("update_pointer_failed",e.GetType().Name); }
        }
        [STAThread] static int Main(string[] args) {
            try {
                ServicePointManager.SecurityProtocol=SecurityProtocolType.Tls12;
                ServicePointManager.Expect100Continue=false;
                if(args.Length>0&&args[0]=="--self-test") {
                    AppLog.Off=true;Journey.Off=true;   // made-up data only: nothing of it in the logs
                    string result=MobileTests.Run();
                    string orderCheckReport=Path.Combine(Path.GetTempPath(),"EbayAuto-OrderCheck-selftest-"+Guid.NewGuid().ToString("N")+".txt");
                    int orderCheck=TempeOrderCheck.SelfTests.Run(orderCheckReport);
                    string orderCheckText=File.Exists(orderCheckReport)?File.ReadAllText(orderCheckReport):"Order Check self-tests wrote no report.";
                    try{File.Delete(orderCheckReport);}catch(IOException){}
                    File.WriteAllText(args[1],Product.Title+" self-tests\r\n"+result+Environment.NewLine+Environment.NewLine+orderCheckText);
                    return orderCheck==0?0:1;
                }
                try{System.Runtime.GCSettings.LatencyMode=System.Runtime.GCLatencyMode.SustainedLowLatency;}catch(Exception){}
                Native.SetProcessDPIAware();Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
                string mode=args.Length==0?"--receiver":args[0];
                bool show=args.Contains("--show");
                AfterUpdate=args.Contains("--after-update");bool restartAfter=args.Contains("--restart-after");
                if(mode=="--init-receiver") return InitReceiver(args);
                bool worker=mode=="--worker";
                Order.Require(worker||mode=="--receiver","Start Ebay-auto with Start-Receiver.cmd (Seb's PC) or Start-Worker.cmd (inside Remote Desktop).");
                string part=worker?Product.WorkerMode:Product.ReceiverMode;runningPart=part;
                string folder=Path.Combine(Product.Home,worker?"worker":"receiver");PrivateFiles.DirectoryReady(folder);
                AppLog.Start(worker?"worker":"receiver");Journey.Start(worker?"worker":"receiver");
                Updater.LaunchMode=part;
                bool created;string mutexName=Product.MutexPrefix+part+"_"+WindowsIdentity.GetCurrent().User.Value;
                using(instance=new Mutex(false,mutexName,out created)) {
                    try { owned=instance.WaitOne(AfterUpdate||restartAfter?60000:0); } catch(AbandonedMutexException) { owned=true; }
                    if(!owned) {
                        if(AfterUpdate) { EbayAutoUpdate.RecordStartFailure(part,"the version before it didn't let go of the "+part.ToLowerInvariant()+" within 60 s");return 1; }
                        // Already running for this Windows login: its window is opened instead.
                        try { using(var signal=EventWaitHandle.OpenExisting(EbayAutoForm.ShowEventName(part))) signal.Set(); }
                        catch(Exception) { MessageBox.Show("The Ebay-auto "+part.ToLowerInvariant()+" is already running (see its icon in the notification area).",Product.Name); }
                        return 0;
                    }
                    try {
                        // After an update: what the version before was doing (receiving / eBay orders, window), once.
                        var resume=AfterUpdate||restartAfter?EbayAutoUpdate.TakeResume(part,DateTime.UtcNow):null;
                        Journey.Note("app_start","","",part+" "+Product.Version+", Windows session "+LocalProcess.Session+(SystemInformation.TerminalServerSession?" (Remote Desktop)":"")+", "+Environment.OSVersion.VersionString+(show?", window shown":", in the notification area")+(AfterUpdate?", started by the update"+(resume==null?"":" from "+resume.from):"")+(restartAfter?", started again after an update that didn't start":""));
                        if(worker) {
                            string configPath=Path.Combine(folder,"settings.dat");
                            var settings=PrivateFiles.Load<WorkerSettings>(configPath);
                            // A worker-connection.json beside the program (Launch.ps1 copies it from the package folder) is
                            // imported once and then removed there.
                            string imported=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"worker-connection.json");
                            if(File.Exists(imported)) {
                                var c=Wire.Read<WorkerSettings>(File.ReadAllText(imported));EbayAutoRules.WorkerConnection(c);PrivateFiles.Save(configPath,c);settings=c;
                                try{File.Delete(imported);}catch(Exception){}
                                Journey.Note("connection_imported","","","from worker-connection.json beside the program (key not recorded)");
                            }
                            Application.Run(new EbayAutoWorkerForm(settings,folder,show,resume));
                        } else {
                            var settings=PrivateFiles.Load<ReceiverSettings>(Path.Combine(folder,"settings.dat"));
                            Order.Require(settings!=null,"Run Setup-Receiver.cmd first on this PC (it makes the receiver's certificate and picks its address and port).");
                            Application.Run(new EbayAutoReceiverForm(settings,folder,show,resume));
                        }
                    } finally { ReleaseInstance(); }
                }
                AppLog.Note("app_exit","normal");
                return 0;
            } catch(Exception e) {
                if(args.Length>1&&args[0]=="--self-test") { File.WriteAllText(args[1],e.ToString());return 1; }
                AppLog.Crash("startup",e);Journey.Note("crash","","",e.GetType().Name+": "+e.Message);
                // After an update the version before waits for this one: it is told why (and starts itself again).
                if(AfterUpdate&&runningPart!=null) { EbayAutoUpdate.RecordStartFailure(runningPart,e.GetType().Name+": "+e.Message);return 1; }
                MessageBox.Show(e.Message,Product.Name+" - stopped",MessageBoxButtons.OK,MessageBoxIcon.Error);return 1;
            }
        }
        // --init-receiver <LAN IPv4> <port> <certificate thumbprint> <root .cer>: the receiver's settings (keys made once and
        // kept when setup runs again, so the 404 extension and the worker keep their pairing unless the address changes).
        // The address and port the receiver may use: this PC's private LAN IPv4 address (never 127.0.0.1: inside Remote
        // Desktop that is the Remote Desktop server, not this PC), a port with the next one free for its certificate.
        static int InitReceiver(string[] args) {
            Order.Require(args.Length==5,"Setup arguments are incomplete.");
            int port=EbayAutoRules.ReceiverSetup(args[1],args[2]);
            string folder=Path.Combine(Product.Home,"receiver");PrivateFiles.DirectoryReady(folder);
            string configPath=Path.Combine(folder,"settings.dat");
            var settings=PrivateFiles.Load<ReceiverSettings>(configPath)??new ReceiverSettings {workerToken=Wire.Token(),workerId=Guid.NewGuid().ToString("N"),ebayToken=Wire.Token(),phoneToken=null,webUrl=""};
            if(String.IsNullOrEmpty(settings.workerToken)) settings.workerToken=Wire.Token();
            if(String.IsNullOrEmpty(settings.workerId)) settings.workerId=Guid.NewGuid().ToString("N");
            if(String.IsNullOrEmpty(settings.ebayToken)) settings.ebayToken=Wire.Token();
            settings.address=args[1];settings.port=port;settings.trustPort=port+1;settings.certificateThumbprint=args[3];
            string certificate=Path.Combine(folder,"Ebay-auto-Root.cer");if(!String.Equals(Path.GetFullPath(args[4]),certificate,StringComparison.OrdinalIgnoreCase))File.Copy(args[4],certificate,true);
            PrivateFiles.Save(configPath,settings);
            Journey.Start("receiver");Journey.Note("setup","","","receiver set up on "+settings.address+":"+settings.port+" (certificate port "+settings.trustPort+")");
            return 0;
        }
    }
}
