// 2.9.8 "Wholesale speed test" (Tommy, 15 Nov 2026 02:52: "Build the next version as one combined dry-run update with a
// way to compare the speed improvements ... the comparison should establish the results"). How the wholesale dry run
// works through orders is a preset (WholesaleSpeed): the 2.9.7 approach (the baseline, the default until a test picks
// another), each improvement on its own, all four together, and two ways of using COSTAR's own search (by order
// number; the list filtered to BUF). The speed test (WholesaleSpeedTest) runs the same orders through each preset in
// turn, in the wholesale helper's own session, and times every stage (WholesaleTimes, WholesalePassTimes); its report
// (SpeedReport) says what was measured, what wasn't, and which preset was fastest with the same results. Still a dry
// run throughout: orders are opened, read and closed; nothing is typed into them, sold or changed. Search words go
// only into the list's own search boxes (Tommy: "Entering search criteria is acceptable navigation during the dry run").
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace TempeCostar {
    // A way of working through orders. Public fields: kept in wholesale-settings.json (the key is what's kept).
    //  - directRow: the order's row read at the place the pass's list read found it (its number checked; anywhere
    //    else: the list read whole, as before), not the whole 351-row list twice.
    //  - readyChecks: after a tyre line's stock is read, after the lines are left, and right after the order is read,
    //    a check that nothing is over the order and COSTAR answers, instead of waiting for 1.5 s of quiet (the one
    //    after the order opens stays: Notes come late).
    //  - leanList: the list read for each row's Document # and Ship Via, and its dates and Comment only when BUF.
    //  - shortTimers: the box-still check 80 ms (150), the second stock read 100 ms after the first (200), the keyboard
    //    held out of the lines 150 ms (300).
    //  - byNumber: each order found by its number in the list's Document # search box (Search pressed for each).
    //  - bufFilter: the list searched with BUF in its Comment / Ship Via box (Ship Via is still checked on each order).
    public sealed class WholesaleSpeed {
        public string key="baseline";
        public bool directRow,readyChecks,leanList,shortTimers,byNumber,bufFilter;
        internal const int AfterOpenMs=1500;
        internal int AfterMs { get { return readyChecks?0:1500; } }
        internal int BoxStillMs { get { return shortTimers?80:150; } }
        internal int SettleMs { get { return shortTimers?100:200; } }
        internal int HoldMs { get { return shortTimers?150:300; } }
        internal static readonly string[] Keys={"baseline","direct","ready","lean","timers","all","all-number","all-buf"};
        internal static WholesaleSpeed Preset(string key) {
            var s=new WholesaleSpeed {key=key??"baseline"};
            switch(s.key) {
                case "direct": s.directRow=true;break;
                case "ready": s.readyChecks=true;break;
                case "lean": s.leanList=true;break;
                case "timers": s.shortTimers=true;break;
                case "all": s.directRow=s.readyChecks=s.leanList=s.shortTimers=true;break;
                case "all-number": s.byNumber=s.readyChecks=s.leanList=s.shortTimers=true;break;
                case "all-buf": s.directRow=s.readyChecks=s.leanList=s.shortTimers=s.bufFilter=true;break;
                default: s.key="baseline";break;
            }
            return s;
        }
        internal static WholesaleSpeed Baseline() { return Preset("baseline"); }
        internal string Name { get { return NameOf(key); } }
        internal static string NameOf(string key) {
            switch(key) {
                case "direct": return "Find the row directly";
                case "ready": return "Ready checks, not 1.5 s waits";
                case "lean": return "Read only the list columns needed";
                case "timers": return "Shorter stability timers";
                case "all": return "All four improvements";
                case "all-number": return "All four, search by order number";
                case "all-buf": return "All four, list filtered to BUF";
                default: return "2.9.7 approach (baseline)";
            }
        }
    }

    // One order's stages (ms; -1: not reached). search: its number searched for (byNumber); find: the list read for its
    // row and the row made the active one; open: Enter to the window showing; notes: COSTAR's Notes and memos answered
    // and the quiet waits before reading; read: the order read; stock: its tyre lines clicked and read; verify: the lines
    // left and the order read again; close: closing it; total: the whole look, from finding to closed.
    public sealed class WholesaleTimes {
        public long search,find=-1,open=-1,notes,read,stock,verify,close=-1,total;
        public int scans,rows,fallbacks,selectTries,lines,settleReads,changing,lateNotices,leaveTries,popups,firstPopupMs=-1;
        public bool hinted;
        internal static string S(long ms) { return ms<0?"-":(ms/100/10.0).ToString("0.0",CultureInfo.InvariantCulture); }
        internal long Find { get { return search+Math.Max(0,find); } }
        // For the day log (wholesale_times): numbers only.
        internal string Line(string doc) {
            return doc+": find "+S(Find)+" s ("+(search>0?"searched by number, ":"")+scans+" list read"+(scans==1?"":"s")+" of "+rows+" row"+(rows==1?"":"s")+(hinted?", at its known place":"")+(fallbacks>0?", read whole after all "+fallbacks+"x":"")+")"
                +", open "+S(open)+" s, notes "+S(notes)+" s"+(popups>0?" ("+popups+" answered, the first "+S(firstPopupMs)+" s after it showed)":"")
                +", read "+S(read)+" s, stock "+S(stock)+" s ("+lines+" line"+(lines==1?"":"s")+", "+settleReads+" read"+(settleReads==1?"":"s")+(changing>0?", "+changing+" changing":"")+")"
                +", verify "+S(verify)+" s"+(lateNotices>0?" ("+lateNotices+" notice"+(lateNotices==1?"":"s")+" after a click)":"")+(leaveTries>1?" ("+leaveTries+" tries to leave the lines)":"")+", close "+S(close)+" s, total "+S(total)+" s";
        }
    }
    // A pass's list (ms): quiet (waiting for nobody at the PC), listing (the list showing, its search boxes checked),
    // filter (BUF put in its search box, an order's number taken out), search (Search pressed until the list held still),
    // read (the list read), restore (the run's search words emptied at the end); total: the whole pass.
    // 2.9.10: recovered: more reads of the list it took to look complete (ListCheck); complete: the list was taken as
    // complete (false: the pass stopped before, or a file of 2.9.8 / 2.9.9).
    public sealed class WholesalePassTimes {
        public long quiet,listing,filter,search,read,restore,total;public int rows,buf,recovered;public bool lean,leanFellBack,filtered,complete;
        internal long Refresh { get { return filter+search+read; } }
        internal string Line() {
            Func<long,string> s=WholesaleTimes.S;
            return "quiet "+s(quiet)+", listing "+s(listing)+(filtered?", BUF filter "+s(filter):"")+", search "+s(search)+", read "+s(read)+" s ("+rows+" rows, "+buf+" BUF"+(lean?(leanFellBack?", read whole after all":", needed columns only"):"")+(recovered>0?", read "+recovered+" more time"+(recovered==1?"":"s")+" before it looked complete":"")+"), total "+s(total)+" s";
        }
    }

    // The list's own search boxes ("Advanced Search": Name/Contact, Document #, Cust PO #, Phone, Order Date, Written
    // By, Comment / Ship Via, Source; the 29 Oct maps, claude/13-Wholesale-Order-Notes.md): a box found by its label,
    // its words set with WM_SETTEXT (no keyboard: nothing reaches anything else) and read back.
    internal static class WholesaleSearchBox {
        internal const string DocumentLabel="DOCUMENT",CommentLabel="COMMENTSHIPVIA";
        internal sealed class Part { internal string Text;internal Native.Rect Rect;internal IntPtr Handle; }
        internal static string Letters(string s) { return new string((s??"").ToUpperInvariant().Where(Char.IsLetter).ToArray()); }
        // Pure: the box whose label (left of it on its row: middles within 10 px, the label ending at most 8 px past
        // the box's left) reads `label` in letters only ("Document #": DOCUMENT); zero unless exactly one.
        internal static IntPtr Pick(List<Part> labels,List<Part> boxes,string label) {
            IntPtr found=IntPtr.Zero;int n=0;
            foreach(var b in boxes) {
                int mid=(b.Rect.Top+b.Rect.Bottom)/2,gap=int.MaxValue;Part best=null;
                foreach(var x in labels) {
                    int g=Math.Abs((x.Rect.Top+x.Rect.Bottom)/2-mid);
                    if(g<=10&&x.Rect.Right<=b.Rect.Left+8&&g<gap&&(x.Text??"").Trim().Length>0) { gap=g;best=x; }
                }
                if(best!=null&&Letters(best.Text)==label) { found=b.Handle;n++; }
            }
            return n==1?found:IntPtr.Zero;
        }
        internal static IntPtr Find(TempeOrderCheck.WipHandles h,string label) {
            var labels=new List<Part>();var boxes=new List<Part>();
            foreach(IntPtr c in TempeOrderCheck.Win.Children(h.Pane)) {
                if(!Native.IsWindowVisible(c)) continue;
                string cls=Native.Class(c);
                bool edit=cls.IndexOf(".EDIT.",StringComparison.OrdinalIgnoreCase)>=0,stat=cls.IndexOf(".STATIC.",StringComparison.OrdinalIgnoreCase)>=0;
                if(!edit&&!stat) continue;
                Native.Rect r;if(!Native.GetWindowRect(c,out r)) continue;
                string t=null;if(stat&&!Native.TryText(c,out t)) continue;
                if(edit) boxes.Add(new Part {Rect=r,Handle=c});else labels.Add(new Part {Text=t,Rect=r,Handle=c});
            }
            return Pick(labels,boxes,label);
        }
        // Null: the box shows `text` now; else why not.
        internal static string Set(IntPtr box,string text) {
            if(box==IntPtr.Zero) return "the search box wasn't found";
            UIntPtr result;
            if(Native.WriteMessage(box,0x000C,UIntPtr.Zero,text??"",2,3000,out result)==IntPtr.Zero) return "COSTAR didn't take the search words";
            for(var t=Stopwatch.StartNew();t.ElapsedMilliseconds<2000;Thread.Sleep(50)) { string now;if(Native.TryText(box,out now)&&(now??"").Trim()==(text??"").Trim()) return null; }
            return "the search box didn't show the words";
        }
        internal static string Text(IntPtr box) { string t;return box!=IntPtr.Zero&&Native.TryText(box,out t)?t:null; }
        // 2.9.10: the search boxes as RoWip.KnownFilter describes them ("Document # = WO1234567") hold nothing but words in
        // the Document # box (OnlyDocument: before a search by number: empty, or the run's last number), or that order's
        // number alone (OnlyNumber: after it). Pure.
        internal static bool OnlyDocument(string filter) {
            if(filter==null) return false;if(filter.Length==0) return true;
            if(filter.IndexOf(", ",StringComparison.Ordinal)>=0) return false;
            int eq=filter.LastIndexOf(" = ",StringComparison.Ordinal);
            return eq>0&&Letters(filter.Substring(0,eq))==DocumentLabel;
        }
        internal static bool OnlyNumber(string filter,string doc) {
            if(!OnlyDocument(filter)||filter.Length==0) return false;
            int eq=filter.LastIndexOf(" = ",StringComparison.Ordinal);
            string want=Order.Norm(doc);
            return want.Length>0&&Order.Norm(filter.Substring(eq+3))==want;
        }
        // The list's search as COSTAR's boxes show it (RoWip.KnownFilter: "Comment / Ship Via = BUF") is the run's own BUF
        // filter alone. Pure.
        internal static bool OnlyBuf(string filter) {
            if(String.IsNullOrEmpty(filter)||filter.IndexOf(", ",StringComparison.Ordinal)>=0) return false;
            int eq=filter.LastIndexOf(" = ",StringComparison.Ordinal);
            return eq>0&&Letters(filter.Substring(0,eq))==CommentLabel&&filter.Substring(eq+3).Trim().ToUpperInvariant()=="BUF";
        }
    }

    // What the speed test keeps (Diagnostics\speed\speed-*.json, beside the report's words): numbers, order numbers,
    // the helper's tags and each tyre line's Sydney stock; never a customer's words, staff's Comment words or Notes.
    public sealed class SpeedOrderResult {
        // outcome: sell, flag, leave, skip (once opened), locked, not listed, not opened, left open, stopped, not reached.
        // extra: a test beyond the sample ("wrong place": its row looked for at a deliberately wrong place; "not on the
        // list": a made-up number; "not eligible": a listed order the rules leave alone, searched for by its number). fp:
        // a fingerprint of the order as read (its Terms, Comment and lines), to tell a real change apart.
        // 2.9.10: why: why it wasn't read, as a kind only ("not on the list", "staff's Comment", "open on another PC" ...;
        // never anyone's words); unread: what of it couldn't be read ("line 2's stock").
        public string doc="",outcome="",tags="",stock="",fp="",extra="",why="",unread="";
        public int tyres,wheels,others,unsure,notes,memos,problems;
        public WholesaleTimes times=new WholesaleTimes();
    }
    // durationMs: the pass from start to end; testsMs: the planned tests beside the orders and the run's search words
    // emptied at the end (left out of the "whole" time); missedBuf (the BUF filter): BUF orders listed in the whole list
    // before and after it that the filtered list didn't show (-1: not checked).
    // 2.9.10: again: a second try of the pass before it (that one stopped for COSTAR's list); evidence: what was seen when
    // it stopped for someone at the PC (Native.InputEvidence: numbers and kinds only).
    public sealed class SpeedArmResult {
        public string key="",name="",stopped="",evidence="";public long durationMs,testsMs;public int missedBuf=-1;public bool again;
        public WholesalePassTimes list=new WholesalePassTimes();
        public List<SpeedOrderResult> orders=new List<SpeedOrderResult>();
    }
    // 2.9.10 (schema 2): plan: the passes planned, in order; approach: the Approach checking used as the test began;
    // eligible: the BUF orders a pass would open then; scouted: the orders looked at first to find a broader sample (their
    // reads then: not compared with anything); evidence: what was seen at a stop for someone at the PC outside a pass.
    public sealed class SpeedTestFile {
        public int schema=2;public string version="",started="",finished="",best="",stopped="",approach="",evidence="";public int size,listed,buf,eligible;
        public List<string> sample=new List<string>(),plan=new List<string>();
        public List<SpeedArmResult> arms=new List<SpeedArmResult>();
        public List<SpeedOrderResult> scouted=new List<SpeedOrderResult>();
    }

    internal static class SpeedResults {
        // The orders of a test: the ones asked for first (if they're BUF orders a pass would open now), then the rest
        // spread over the list (every k-th of those, top to bottom), `size` in all, in the list's order. Pure.
        internal static List<string> Choose(IList<WholesaleRow> rows,string today,int size,IEnumerable<string> asked) {
            var open=rows.Where(r=>WholesaleRules.ShipViaBuf(r.ShipVia)&&WholesaleRules.Screen(r,today).Why==null).OrderBy(r=>r.Pos).ToList();
            var picked=new List<WholesaleRow>();
            foreach(var d in asked??new string[0]) { string n=Order.Norm(d);var r=open.FirstOrDefault(x=>x.Doc==n);if(r!=null&&!picked.Contains(r)&&picked.Count<size) picked.Add(r); }
            var rest=open.Where(r=>!picked.Contains(r)).ToList();int need=Math.Min(size-picked.Count,rest.Count);
            for(int i=0;i<need;i++) picked.Add(rest.ElementAt((int)((long)i*rest.Count/need)));
            return picked.OrderBy(r=>r.Pos).Select(r=>r.Doc).ToList();
        }
        // 2.9.10: 0 .. n-1 in an order spread over the list: the first, the middle, the quarters, the eighths ... (the first
        // few looked at come from all of it). Pure.
        internal static List<int> Spread(int n) {
            var order=new List<int>();if(n<=0) return order;
            var taken=new bool[n];int stride=1;while(stride<n) stride*=2;
            for(;stride>=1;stride/=2) for(int i=0;i<n;i+=stride) if(!taken[i]) { taken[i]=true;order.Add(i); }
            return order;
        }
        // 2.9.10 (Tommy, 15 Nov 10:43: "include a broader sample with multiple tyre lines and wheels where eligible ... Tell
        // me which cases the selected sample actually covers"): the cases a sample is chosen to cover, as a pass read them.
        internal static readonly string[] Cases={"wheels","3 or more tyre lines","2 tyre lines","no tyres or wheels","[stock]","[card]","Notes","a memo","can't-tell lines","1 tyre line","would sell"};
        internal static bool Has(SpeedOrderResult o,string c) {
            if(o==null) return false;
            switch(c) {
                case "wheels": return o.wheels>0;
                case "3 or more tyre lines": return o.tyres>=3;
                case "2 tyre lines": return o.tyres==2;
                case "no tyres or wheels": return o.tyres==0&&o.wheels==0&&o.others>0;
                case "[stock]": return (o.tags??"").Contains("[stock]");
                case "[card]": return (o.tags??"").Contains("[card]");
                case "Notes": return o.notes>0;
                case "a memo": return o.memos>0;
                case "can't-tell lines": return o.unsure>0;
                case "1 tyre line": return o.tyres==1;
                case "would sell": return o.outcome=="sell";
                default: return false;
            }
        }
        // How many of a case a sample wants (two of the everyday ones when it has room).
        internal static int Want(string c,int size) { return (c=="1 tyre line"||c=="would sell")&&size>=6?2:1; }
        // The cases these reads don't cover enough yet (the look for a broader sample stops once there are none). Pure.
        internal static List<string> StillMissing(IEnumerable<SpeedOrderResult> reads,int size) {
            var r=(reads??new SpeedOrderResult[0]).Where(SpeedReport.WasRead).ToList();
            return Cases.Where(c=>r.Count(o=>Has(o,c))<Want(c,size)).ToList();
        }
        // 2.9.10: the orders of a test (Tommy, 15 Nov 10:43): the ones asked for first (if they're BUF orders a pass would
        // open now: open); then, while a case is still missing, the order looked at first (known: as that look read it)
        // covering most of the cases still missing (the list's order on a tie); then the rest spread over the list, the
        // ones looked at first. In the list's order. missing: the cases none of the orders looked at had. Pure.
        internal static List<string> Broad(IList<WholesaleRow> open,IEnumerable<string> asked,IDictionary<string,SpeedOrderResult> known,int size,out List<string> missing) {
            var docs=open.OrderBy(r=>r.Pos).Select(r=>r.Doc).Distinct().ToList();var picked=new List<string>();
            Func<string,SpeedOrderResult> k=delegate(string d) { SpeedOrderResult o;return known!=null&&known.TryGetValue(d,out o)&&SpeedReport.WasRead(o)?o:null; };
            foreach(var d in asked??new string[0]) { string n=Order.Norm(d);if(docs.Contains(n)&&!picked.Contains(n)&&picked.Count<size) picked.Add(n); }
            while(picked.Count<size) {
                var need=Cases.Where(c=>picked.Count(d=>Has(k(d),c))<Want(c,size)).ToList();
                if(need.Count==0) break;
                string best=null;int most=0;
                foreach(var d in docs) {
                    if(picked.Contains(d)) continue;var o=k(d);if(o==null) continue;
                    int n=need.Count(c=>Has(o,c));if(n>most) { most=n;best=d; }
                }
                if(best==null) break;
                picked.Add(best);
            }
            var looked=docs.Where(d=>k(d)!=null).ToList();
            missing=Cases.Where(c=>!looked.Any(d=>Has(k(d),c))).ToList();
            var restLooked=looked.Where(d=>!picked.Contains(d)).ToList();var restOther=docs.Where(d=>!picked.Contains(d)&&k(d)==null).ToList();
            foreach(var group in new[]{restLooked,restOther}) foreach(int i in Spread(group.Count)) if(picked.Count<size) picked.Add(group[i]);
            var place=new Dictionary<string,int>(StringComparer.Ordinal);for(int i=0;i<docs.Count;i++) place[docs[i]]=i;
            return picked.OrderBy(d=>place[d]).ToList();
        }
        // 2.9.10: a listed order the rules leave alone, for the test of the search by number (it must be skipped, nothing
        // opened): a BUF one first (staff's Comment, a ShipDate after today, flagged ...: the rules' own reasons), else one
        // that isn't BUF; never one of the sample's; null: none. Pure.
        internal static string NotEligible(IList<WholesaleRow> rows,string today,ICollection<string> sample) {
            var free=rows.Where(r=>RoEdit.IsDoc(r.Doc)&&(sample==null||!sample.Contains(r.Doc))).OrderBy(r=>r.Pos).ToList();
            var buf=free.FirstOrDefault(r=>WholesaleRules.ShipViaBuf(r.ShipVia)&&WholesaleRules.Screen(r,today).Why!=null&&!WholesaleRules.Screen(r,today).Problem);
            if(buf!=null) return buf.Doc;
            var other=free.FirstOrDefault(r=>!WholesaleRules.ShipViaBuf(r.ShipVia));
            return other==null?null:other.Doc;
        }
        // The BUF orders a filtered pass (i) didn't show that the whole list showed in the nearest pass before it and the
        // nearest after it (so an order filled or added between them doesn't count); -1: no such passes either side. Pure.
        internal static int Missed(List<HashSet<string>> whole,List<HashSet<string>> filtered,int i) {
            if(i<0||i>=filtered.Count||filtered[i]==null) return -1;
            HashSet<string> before=null,after=null;
            for(int k=i-1;k>=0&&before==null;k--) if(k<whole.Count) before=whole[k];
            for(int k=i+1;k<whole.Count&&after==null;k++) after=whole[k];
            if(before==null||after==null) return -1;
            return before.Count(d=>after.Contains(d)&&!filtered[i].Contains(d));
        }
        internal static SpeedOrderResult From(WholesaleLook l) {
            var o=new SpeedOrderResult {doc=l.Row.Doc,extra=l.Extra??"",times=l.Times};
            var v=l.Verdict;
            if(l.Locked) o.outcome="locked";
            else if(v!=null) { o.outcome=v.Action;o.tags=WholesaleComment.TagText(v.Tags);o.problems=v.Problems.Count; }
            else if(l.LeftOpen!=null) o.outcome="left open";
            else if(l.Skip!=null) o.outcome=l.Skip.StartsWith("no longer on COSTAR's list",StringComparison.Ordinal)?"not listed":"not opened";
            else o.outcome=l.Opened?"stopped":"not reached";
            var items=l.Lines.Where(x=>!x.Note&&x.Item.Length>0).ToList();
            o.tyres=items.Count(x=>x.Kind=="tyre");o.wheels=items.Count(x=>x.Kind=="wheel");o.unsure=items.Count(x=>x.Kind=="unsure");
            o.others=items.Count-o.tyres-o.wheels-o.unsure;
            o.notes=l.NotesRead.Count;o.memos=l.Memos.Count;
            o.stock=String.Join(",",items.Where(x=>x.Kind=="tyre").Select(x=>x.Number.ToString(CultureInfo.InvariantCulture)+":"+(x.NonStocking?"NS":x.Available.HasValue?x.Available.Value.ToString(CultureInfo.InvariantCulture):"?")).ToArray());
            o.fp=l.Opened?Wire.Hash(Encoding.UTF8.GetBytes((l.Terms??"")+"|"+(l.OrderComment??"")+"|"+WholesaleRules.Print(items)+"|"+(l.Card==true?"card":l.Card==false?"no card":"?"))).Substring(0,12):"";
            o.why=l.Locked?"open on another PC":v!=null?"":l.LeftOpen!=null?"left open":l.Skip!=null?SkipKind(l.Skip):l.Opened?"stopped":"not reached";
            o.unread=String.Join(", ",items.Where(x=>x.Kind=="tyre"&&!x.NonStocking&&!x.Available.HasValue).Select(x=>"line "+x.Number.ToString(CultureInfo.InvariantCulture)+"'s stock").ToArray());
            if(v!=null&&v.Problems.Count>0&&o.unread.Length==0) o.unread=v.Problems.Count+" reading problem"+(v.Problems.Count==1?"":"s");
            return o;
        }
        // 2.9.10: what a skip was, as a kind only (never the order's or anyone's words). Pure.
        internal static string SkipKind(string skip) {
            string s=skip??"";
            Func<string,bool> has=delegate(string w) { return s.IndexOf(w,StringComparison.Ordinal)>=0; };
            if(s.StartsWith("no longer on COSTAR's list",StringComparison.Ordinal)) return "not on the list";
            if(has("isn't BUF")) return "not BUF";
            if(has("staff's Comment")||has("(staff's)")) return "staff's Comment";
            if(has("no helper flag")) return "go without a helper flag";
            if(has("after today")) return "ShipDate after today";
            if(has("ShipDate")&&has("can't be read")) return "ShipDate can't be read";
            if(has("flagged")) return "flagged, waiting for staff's go";
            if(has("previewed at")) return "previewed today";
            if(has("open on another PC")) return "open on another PC";
            if(has("tried again at")) return "waiting to be tried again";
            if(has("search by number only")) return "a test for the search by number only";
            return "skipped";
        }
    }

    // The report (pure: the self-tests check it). 2.9.10 (Tommy, 15 Nov 10:43): every approach's reads are compared with
    // one complete, valid 2.9.7 pass, the reference: the first, or, when it didn't complete, the last (said so). Each order
    // of each pass is one of: a match (read as the reference, or as the other 2.9.7 pass, read it); changed in COSTAR (the
    // two 2.9.7 passes read it differently, it left the list for the last one too, or it was open on another PC); a
    // difference (read otherwise, with nothing to show COSTAR changed: the approach isn't reliable); unread (part of it
    // couldn't be read, or a stop cut it short: never taken for a change of its stock); not on this pass's list (missing
    // when 2.9.7 listed it before and after); not reached. A planned test passed, FAILED, or wasn't reached (never a
    // failure). What wasn't tested is said: approaches not run, orders not reached.
    internal static class SpeedReport {
        internal static long Median(List<long> v) {
            if(v.Count==0) return -1;
            var s=v.OrderBy(x=>x).ToList();
            return s.Count%2==1?s[s.Count/2]:(s[s.Count/2-1]+s[s.Count/2])/2;
        }
        static string S(long ms) { return WholesaleTimes.S(ms); }
        static string Clock(long ms) { if(ms<0) return "-";long s=(ms+500)/1000;return (s/60).ToString(CultureInfo.InvariantCulture)+":"+(s%60).ToString("00",CultureInfo.InvariantCulture); }
        static readonly string[] Read={"sell","flag","leave","skip"};
        internal static bool WasRead(SpeedOrderResult o) { return o!=null&&Read.Contains(o.outcome); }
        // The orders that count for a preset's speed: from the sample (no extra test), opened and read through.
        internal static List<SpeedOrderResult> Counted(SpeedArmResult a) { return a.orders.Where(o=>o.extra.Length==0&&WasRead(o)).ToList(); }
        internal static long MedianMs(SpeedArmResult a) { return Median(Counted(a).Select(o=>o.times.total).ToList()); }
        internal static long SlowestMs(SpeedArmResult a) { var c=Counted(a);return c.Count==0?-1:c.Max(o=>o.times.total); }
        internal static long StageMs(SpeedArmResult a,Func<WholesaleTimes,long> stage) { return Median(Counted(a).Select(o=>Math.Max(0,stage(o.times))).ToList()); }
        internal static long WholeMs(SpeedArmResult a) { return Math.Max(0,a.durationMs-a.testsMs); }
        // Tries again on the orders of the sample: the row made the active one again, the lines left again, a stock
        // figure read again after it changed.
        internal static int Retries(SpeedArmResult a) { return a.orders.Where(o=>o.extra.Length==0).Sum(o=>Math.Max(0,o.times.selectTries-1)+Math.Max(0,o.times.leaveTries-1)+o.times.changing); }
        // Read the same: the same result (what it would do, its tags), stock, kinds of lines and fingerprint.
        internal static bool Same(SpeedOrderResult o,SpeedOrderResult b) {
            return o.outcome==b.outcome&&o.tags==b.tags&&o.stock==b.stock&&o.fp==b.fp&&o.tyres==b.tyres&&o.wheels==b.wheels&&o.others==b.others&&o.unsure==b.unsure;
        }
        internal static SpeedOrderResult Of(SpeedArmResult a,string doc) { return a==null?null:a.orders.FirstOrDefault(x=>x.extra.Length==0&&x.doc==doc); }
        // A 2.9.7 pass that completed: not stopped, at least one order read, and every order of the sample read or
        // accounted for (not on the list, not opened, open on another PC); none not reached, cut short or left open.
        internal static bool Valid(SpeedArmResult a) {
            return a!=null&&a.key=="baseline"&&a.stopped.Length==0&&Counted(a).Count>0&&a.orders.Where(o=>o.extra.Length==0).All(o=>o.outcome!="not reached"&&o.outcome!="stopped"&&o.outcome!="left open");
        }
        // The reference (Arm) and the other valid 2.9.7 pass (Other: for changes in COSTAR during the test), with what
        // the report says of them (Note). The first 2.9.7 passes are those before any other approach (two when the first
        // stopped for COSTAR's list and ran again); the last, those after every other approach.
        internal sealed class Reference { internal SpeedArmResult Arm,Other;internal bool Last;internal string Note=""; }
        static string Why(SpeedArmResult a) {
            if(a==null) return "not run";
            if(a.stopped.Length>0) return "stopped: "+Short(a.stopped);
            int n=a.orders.Count(o=>o.extra.Length==0&&(o.outcome=="not reached"||o.outcome=="stopped"||o.outcome=="left open"));
            return n>0?n+" order"+(n==1?"":"s")+" not read":"no order read";
        }
        static string Short(string s) { s=(s??"").Trim();int dot=s.IndexOf(". ",StringComparison.Ordinal);if(dot>0) s=s.Substring(0,dot+1);return s.Length>160?s.Substring(0,160)+"...":s; }
        internal static Reference RefOf(SpeedTestFile f) {
            int firstOther=f.arms.FindIndex(a=>a.key!="baseline"),lastOther=f.arms.FindLastIndex(a=>a.key!="baseline");
            var start=new List<SpeedArmResult>();var end=new List<SpeedArmResult>();
            for(int i=0;i<f.arms.Count;i++) { if(f.arms[i].key!="baseline") continue;if(firstOther<0||i<firstOther) start.Add(f.arms[i]);else if(i>lastOther) end.Add(f.arms[i]); }
            var s=start.FirstOrDefault(Valid);var e=end.FirstOrDefault(Valid);var r=new Reference();
            if(s!=null) {
                r.Arm=s;r.Other=e;
                r.Note="the first 2.9.7 pass"+(start.IndexOf(s)>0?" (run again after it "+Why(start[0])+")":"")+(e!=null?"; the last 2.9.7 pass too, to tell changes in COSTAR during the test apart":end.Count>0?"; the last 2.9.7 pass didn't complete ("+Why(end[end.Count-1])+"), so a difference can't be put down to a change in COSTAR":"; there's no last 2.9.7 pass (not reached), so a difference can't be put down to a change in COSTAR");
            } else if(e!=null) {
                r.Arm=e;r.Last=true;
                r.Note="the LAST 2.9.7 pass, as the first one didn't complete ("+(start.Count>0?Why(start[start.Count-1]):"not run")+"); with one 2.9.7 pass, a difference can't be put down to a change in COSTAR";
            } else r.Note="NONE: no 2.9.7 pass completed ("+(start.Count>0?"first: "+Why(start[start.Count-1]):"first: not run")+"; "+(end.Count>0?"last: "+Why(end[end.Count-1]):"last: not run")+"), so no approach's reads are compared with 2.9.7";
            return r;
        }
        // The 2.9.7 approach's median an order: the faster of its valid passes, so an approach isn't taken for faster
        // because COSTAR had warmed up by its turn.
        internal static long BaselineMs(SpeedTestFile f) {
            var r=RefOf(f);long m=r.Arm==null?-1:MedianMs(r.Arm),o=r.Other==null?-1:MedianMs(r.Other);
            return m<0?o:o<0?m:Math.Min(m,o);
        }
        // An order of a pass (o) against the reference's read (r) and the other valid 2.9.7 pass's (other): "" (the
        // reference didn't read it: not compared), "match", "changed", "difference", "unread", "not listed", "missing" or
        // "not reached" (above).
        internal static string Compare(SpeedOrderResult o,SpeedOrderResult r,SpeedOrderResult other) {
            if(!WasRead(r)) return "";
            if(o==null||o.outcome=="not reached") return "not reached";
            if(o.outcome=="locked") return "changed";
            if(o.outcome=="stopped"||o.outcome=="left open") return "unread";
            if(o.outcome=="not listed"||o.outcome=="not opened") return other==null?"not listed":WasRead(other)?"missing":"changed";
            if(Same(o,r)||(WasRead(other)&&Same(o,other))) return "match";
            if(Unread(o,r)) return "unread";
            if(WasRead(other)&&!Same(r,other)) return "changed";
            return "difference";
        }
        // Part of it couldn't be read where the reference read it: a tyre's stock not read ("?") where the reference has a
        // figure, or more reading problems. Never taken for a change of its stock.
        internal static bool Unread(SpeedOrderResult o,SpeedOrderResult r) {
            if(o.problems>r.problems) return true;
            var a=(o.stock??"").Split(',');var b=(r.stock??"").Split(',');
            if(a.Length!=b.Length) return false;
            for(int i=0;i<a.Length;i++) if(a[i].EndsWith(":?",StringComparison.Ordinal)&&!b[i].EndsWith(":?",StringComparison.Ordinal)) return true;
            return false;
        }
        internal static readonly string[] Kinds={"match","changed","difference","unread","not listed","missing","not reached"};
        // The orders of a pass by what they were against the reference (the reference against itself: its own reads are
        // the matches; the other 2.9.7 pass against the reference alone).
        internal static Dictionary<string,int> Tally(SpeedArmResult a,Reference rf) {
            var t=Kinds.ToDictionary(k=>k,k=>0,StringComparer.Ordinal);
            if(rf.Arm==null) return t;
            foreach(var b in rf.Arm.orders.Where(x=>x.extra.Length==0)) { string c=Against(a,b,rf);if(c.Length>0) t[c]++; }
            return t;
        }
        // One order of a pass against the reference's read of it (r): the reference's own reads are its matches; the other
        // 2.9.7 pass reading it otherwise, or not listing it, is a change in COSTAR (two 2.9.7 passes); any other pass by
        // Compare, with the other 2.9.7 pass's read.
        internal static string Against(SpeedArmResult a,SpeedOrderResult r,Reference rf) {
            var o=Of(a,r.doc);
            if(Object.ReferenceEquals(a,rf.Arm)) return WasRead(r)?"match":"";
            if(Object.ReferenceEquals(a,rf.Other)) { string c=Compare(o,r,null);return c=="difference"||c=="not listed"?"changed":c; }
            return Compare(o,r,Of(rf.Other,r.doc));
        }
        // A planned test beside the orders: "passed", "FAILED", "not reached" (the run stopped before it, or before its pass),
        // "not completed" (a stop cut it short, or the order was open on another PC).
        internal static string Test(SpeedArmResult a,SpeedOrderResult o) {
            if(o==null||o.outcome=="not reached") return "not reached";
            if(o.outcome=="stopped"||o.outcome=="left open"||o.outcome=="locked") return "not completed";
            if(o.extra=="wrong place") { var own=Of(a,o.doc);if(own==null||!WasRead(own)) return "not completed";return WasRead(o)&&o.times.fallbacks>0&&own.outcome==o.outcome&&own.tags==o.tags&&own.fp==o.fp?"passed":"FAILED"; }
            if(o.extra=="not on the list") return o.outcome=="not listed"&&o.times.open<0?"passed":"FAILED";
            if(o.extra=="not eligible") return o.outcome=="not opened"&&o.times.open<0?"passed":o.outcome=="not listed"?"not completed":"FAILED";
            return "passed";
        }
        // What each planned pass plans beside its orders (WholesaleSpeedTest): the tests not reached when it didn't run.
        internal static string[] Planned(string key) {
            switch(key) {
                case "direct": return new[]{"wrong place"};
                case "all": return new[]{"wrong place","not on the list"};
                case "all-number": return new[]{"not on the list","not eligible"};
                default: return new string[0];
            }
        }
        // "reliable" in this test: it ran through, every order of the sample compared, each a match or changed in COSTAR,
        // its planned tests passed and (filtered) no BUF order missed; "NOT reliable": a difference, a missing order, a
        // failed test or a BUF order the filter missed; else "not confirmed" (stopped, unread, not reached, a test not
        // reached, no reference).
        internal static string Verdict(SpeedArmResult a,SpeedTestFile f) {
            var rf=RefOf(f);var t=Tally(a,rf);
            var tests=a.orders.Where(o=>o.extra.Length>0).Select(o=>Test(a,o)).ToList();
            if(t["difference"]>0||t["missing"]>0||tests.Contains("FAILED")||(a.list.filtered&&a.missedBuf>0)) return "NOT reliable";
            int compared=Kinds.Sum(k=>t[k]);
            bool tested=Planned(a.key).All(x=>a.orders.Any(o=>o.extra==x))&&tests.All(x=>x=="passed");
            if(rf.Arm!=null&&a.stopped.Length==0&&compared>0&&t["match"]+t["changed"]==compared&&tested&&(!a.list.filtered||a.missedBuf==0)) return "reliable";
            return "not confirmed";
        }
        // The fastest approach reliable in this test and faster than 2.9.7 ("baseline": none). 2.9.10: "best-supported".
        internal static string Best(SpeedTestFile f) {
            var ok=f.arms.Where(a=>a.key!="baseline"&&Verdict(a,f)=="reliable").OrderBy(a=>MedianMs(a)).ThenBy(a=>WholeMs(a)).ToList();
            long b=BaselineMs(f);
            return ok.Count>0&&b>0&&MedianMs(ok[0])>=0&&MedianMs(ok[0])<b?ok[0].key:"baseline";
        }
        // 2.9.10: what the sample held, as the reference read it (Tommy: "Tell me which cases the selected sample actually
        // covers"); and what the orders looked at first didn't have.
        internal static string Covers(IList<SpeedOrderResult> reads) {
            var c=reads.Where(WasRead).ToList();
            Func<Func<SpeedOrderResult,bool>,int> n=delegate(Func<SpeedOrderResult,bool> p) { return c.Count(p); };
            return n(o=>o.tyres==0)+" with no tyre line, "+n(o=>o.tyres==1)+" with 1, "+n(o=>o.tyres==2)+" with 2, "+n(o=>o.tyres>=3)+" with 3 or more; wheels on "+n(o=>o.wheels>0)+"; no tyres or wheels (other items only) on "+n(o=>o.tyres==0&&o.wheels==0&&o.others>0)+"; other items beside tyres or wheels on "+n(o=>o.others>0&&(o.tyres>0||o.wheels>0))+"; can't-tell lines on "+n(o=>o.unsure>0)
                +"; Notes on "+n(o=>o.notes>0)+", a memo on "+n(o=>o.memos>0)
                +"; would sell "+n(o=>o.outcome=="sell")+", would flag "+n(o=>o.outcome=="flag")+" ([stock] "+n(o=>(o.tags??"").Contains("[stock]"))+", [card] "+n(o=>(o.tags??"").Contains("[card]"))+", [review] "+n(o=>(o.tags??"").Contains("[review]"))+", [items] "+n(o=>(o.tags??"").Contains("[items]"))+"), unchanged "+n(o=>o.outcome=="leave")+", skipped once opened "+n(o=>o.outcome=="skip");
        }
        static string Pad(string s,int n) { s=s??"";return s.Length>=n?s:s+new string(' ',n-s.Length); }
        internal static string Text(SpeedTestFile f) {
            var b=new StringBuilder();var rf=RefOf(f);
            b.AppendLine("WHOLESALE SPEED COMPARISON, "+f.started+" to "+f.finished+" (helper "+f.version+"). Dry run: orders opened, read and closed; nothing typed into them, sold or changed (search words go only into the list's own search boxes).");
            if(f.stopped.Length>0) b.AppendLine("STOPPED: "+f.stopped);
            var person=f.arms.LastOrDefault(a=>a.evidence.Length>0);
            if(person!=null) b.AppendLine("What was seen at the stop ("+person.name+"): "+person.evidence);
            else if(f.evidence.Length>0) b.AppendLine("What was seen at the stop: "+f.evidence);
            b.AppendLine("Orders: "+f.sample.Count+(f.sample.Count>0?" ("+String.Join(", ",f.sample.ToArray())+")":"")+(f.eligible>0?", chosen from "+f.eligible+" BUF orders a pass would open":"")+(f.buf>0?" (of "+f.buf+" BUF in a list of "+f.listed+")":"")+(f.scouted.Count>0?"; "+f.scouted.Count+" looked at first to find the cases":"")+".");
            b.AppendLine("Reference: "+rf.Note+".");
            if(rf.Arm!=null) {
                b.AppendLine("The sample, as the reference read it: "+Covers(Counted(rf.Arm))+".");
                var absent=SpeedResults.Cases.Where(c=>!Counted(rf.Arm).Any(o=>SpeedResults.Has(o,c))).ToList();
                if(absent.Count>0) b.AppendLine("Not in the sample: "+String.Join(", ",absent.Select(c=>c+(f.scouted.Count==0?"":f.scouted.Any(o=>WasRead(o)&&SpeedResults.Has(o,c))?" (an order looked at had it, but it read otherwise in the reference)":" (none of the "+f.scouted.Count+" orders looked at had it)")).ToArray())+".");
            }
            b.AppendLine();
            b.AppendLine("List: the list searched and read. Order: one order from finding it to closing it. Whole: the pass, without the planned tests beside the orders. Matched: orders read as the reference read them (or as the other 2.9.7 pass did), of those compared.");
            b.AppendLine(Pad("Approach",40)+Pad("List",9)+Pad("Order: median / slowest",25)+Pad("Whole",8)+Pad("vs 2.9.7",10)+Pad("Matched",10)+"In this test");
            long m0=BaselineMs(f);
            foreach(var a in f.arms) {
                long m=MedianMs(a);var t=Tally(a,rf);int compared=Kinds.Sum(k=>t[k]);
                string vs=m0>0&&m>=0?((m-m0)*100/m0).ToString("+0;-0;0",CultureInfo.InvariantCulture)+"%":"-";
                string verdict=a.key=="baseline"?(Object.ReferenceEquals(a,rf.Arm)?"the reference":Valid(a)?"2.9.7 again":"didn't complete"):Verdict(a,f);
                b.AppendLine(Pad(a.name,40)+Pad(S(a.list.Refresh)+" s",9)+Pad(S(m)+" / "+S(SlowestMs(a))+" s",25)+Pad(Clock(WholeMs(a)),8)+Pad(vs,10)+Pad(rf.Arm==null?"-":t["match"]+"/"+compared,10)+verdict+(a.stopped.Length>0?" (stopped)":""));
            }
            b.AppendLine();
            b.AppendLine("Each order against the reference (counts): changed in COSTAR: the two 2.9.7 passes differ, it left the list for the last one too, or it was open on another PC. Different: read otherwise with nothing to show COSTAR changed. Unread: part of it couldn't be read, or a stop cut it short (never taken for a stock change).");
            b.AppendLine(Pad("Approach",40)+Pad("Match",7)+Pad("Changed",9)+Pad("Different",11)+Pad("Unread",8)+Pad("Not listed",12)+Pad("Missing",9)+Pad("Not reached",13)+Pad("Retries",9)+Pad("Read whole",12)+"Locked");
            foreach(var a in f.arms) {
                var t=Tally(a,rf);
                int unplanned=a.orders.Where(o=>o.extra.Length==0).Sum(o=>o.times.fallbacks),planned=a.orders.Where(o=>o.extra.Length>0).Sum(o=>o.times.fallbacks);
                b.AppendLine(Pad(a.name,40)+Pad(t["match"].ToString(CultureInfo.InvariantCulture),7)+Pad(t["changed"].ToString(CultureInfo.InvariantCulture),9)+Pad(t["difference"].ToString(CultureInfo.InvariantCulture),11)+Pad(t["unread"].ToString(CultureInfo.InvariantCulture),8)+Pad(t["not listed"].ToString(CultureInfo.InvariantCulture),12)+Pad(t["missing"].ToString(CultureInfo.InvariantCulture),9)+Pad(t["not reached"].ToString(CultureInfo.InvariantCulture),13)+Pad(Retries(a).ToString(CultureInfo.InvariantCulture),9)+Pad(unplanned+(planned>0?" (+"+planned+" test)":""),12)+a.orders.Count(o=>o.outcome=="locked"));
            }
            b.AppendLine();
            b.AppendLine("Where an order's time goes (median, s):");
            b.AppendLine(Pad("Approach",40)+Pad("search",8)+Pad("find",7)+Pad("open",7)+Pad("notes",7)+Pad("read",7)+Pad("stock",7)+Pad("verify",8)+"close");
            foreach(var a in f.arms) b.AppendLine(Pad(a.name,40)+Pad(S(StageMs(a,x=>x.search)),8)+Pad(S(StageMs(a,x=>Math.Max(0,x.find))),7)+Pad(S(StageMs(a,x=>x.open)),7)+Pad(S(StageMs(a,x=>x.notes)),7)+Pad(S(StageMs(a,x=>x.read)),7)+Pad(S(StageMs(a,x=>x.stock)),7)+Pad(S(StageMs(a,x=>x.verify)),8)+S(StageMs(a,x=>x.close)));
            b.AppendLine();
            string best=Best(f);var ba=f.arms.FirstOrDefault(a=>a.key==best&&Verdict(a,f)=="reliable");
            if(best=="baseline"||ba==null) b.AppendLine("Best-supported by this test: none faster than 2.9.7 was reliable in it (see the verdicts above).");
            else b.AppendLine("Best-supported by this test: "+WholesaleSpeed.NameOf(best)+": "+S(MedianMs(ba))+" s an order (2.9.7: "+S(m0)+" s); the list in "+S(ba.list.Refresh)+" s"+(rf.Arm==null?"":" (2.9.7: "+S(rf.Arm.list.Refresh)+" s)")+"; every order compared read as the reference read it (or changed in COSTAR). "+Counted(ba).Count+" orders: a test of this sample, on this list, at this time.");
            if(f.approach.Length>0) {
                var used=f.arms.LastOrDefault(a=>a.key==WholesaleSpeed.Preset(f.approach).key);
                b.AppendLine("Approach checking used as the test began: "+WholesaleSpeed.NameOf(WholesaleSpeed.Preset(f.approach).key)+(used==null?" (not run in this test)":": "+S(MedianMs(used))+" s an order here; "+Verdict(used,f)+" in this test")+".");
            }
            if(f.arms.Any(a=>WholesaleSpeed.Preset(a.key).directRow)) b.AppendLine("Find the row directly (also in All four and All four, list filtered to BUF) looks for each order where the pass's list read put it. Nothing leaves the list in a dry run; in the live workflow an order leaves the list after Sell, then Cancel (confirmed by Tommy, 15 Nov), and the places read at the pass's start no longer hold. Its times here don't carry over to live.");
            if(rf.Arm!=null&&m0>0) {
                long sum=0;bool all=true;
                foreach(var k in new[]{"direct","ready","lean","timers"}) { var a=f.arms.FirstOrDefault(x=>x.key==k&&MedianMs(x)>=0);if(a==null) { all=false;continue; } sum+=m0-MedianMs(a); }
                var both=f.arms.FirstOrDefault(x=>x.key=="all"&&MedianMs(x)>=0);
                if(all&&both!=null) b.AppendLine("The four improvements on their own save "+S(sum)+" s an order between them; all four together "+S(m0-MedianMs(both))+" s ("+(m0-MedianMs(both)>=sum?"they add up":"they overlap: some of the same time")+"). The list (not an order's time): "+S(rf.Arm.list.Refresh)+" s with 2.9.7, "+S(both.list.Refresh)+" s with all four.");
            }
            if(rf.Arm!=null&&rf.Other!=null&&MedianMs(rf.Other)>=0&&MedianMs(rf.Arm)>0) { long first=MedianMs(rf.Last?rf.Other:rf.Arm),again=MedianMs(rf.Last?rf.Arm:rf.Other);b.AppendLine("The 2.9.7 approach first and again at the end: "+S(first)+" s and "+S(again)+" s an order: "+(Math.Abs(again-first)*10<=first?"COSTAR's speed held steady through the test.":"COSTAR's speed changed during the test: compare with care.")+" (2.9.7's figure above is the faster of the two.)"); }
            foreach(var a in f.arms.Where(x=>x.list.filtered)) b.AppendLine(a.missedBuf<0?"The BUF filter: not checked against the whole list (no whole list read before and after it).":a.missedBuf==0?"The BUF filter: the filtered list showed every BUF order the whole list showed before and after it ("+a.list.buf+" BUF).":"The BUF filter MISSED "+a.missedBuf+" BUF order"+(a.missedBuf==1?"":"s")+" that the whole list showed before and after it: NOT RELIABLE.");
            foreach(var a in f.arms.Where(x=>x.list.recovered>0)) b.AppendLine(a.name+": its list didn't look complete at first; it was waited for and read "+a.list.recovered+" more time"+(a.list.recovered==1?"":"s")+".");
            foreach(var a in f.arms.Where(x=>x.again)) b.AppendLine(a.name+": run again after the pass before it stopped for COSTAR's list.");
            b.AppendLine();
            // The planned tests beside the orders, by kind: passed, FAILED, not reached (also when their pass didn't run).
            var labels=new Dictionary<string,string>(StringComparer.Ordinal) {
                {"wrong place","A row looked for at a deliberately wrong place (a test of the fallback to reading the list in full; it doesn't reproduce an order leaving the list after Sell, then Cancel)"},
                {"not on the list","A made-up order number (not on the list: nothing must be opened)"},
                {"not eligible","A listed order the rules leave alone, searched for by its number (it must be skipped, nothing opened)"}};
            foreach(var kind in labels.Keys) {
                var results=new List<string>();
                foreach(var key in f.plan.Distinct().Where(k=>Planned(k).Contains(kind))) {
                    var runs=f.arms.Where(a=>a.key==key).ToList();
                    if(runs.Count==0) { results.Add(WholesaleSpeed.NameOf(key)+": not reached (the pass didn't run)");continue; }
                    foreach(var a in runs) { var o=a.orders.FirstOrDefault(x=>x.extra==kind);results.Add(a.name+": "+(o==null?(a.stopped.Length>0?"not reached":"not set up (no such order on the list)"):Test(a,o))); }
                }
                foreach(var a in f.arms.Where(x=>!f.plan.Contains(x.key)&&x.orders.Any(o=>o.extra==kind))) results.Add(a.name+": "+Test(a,a.orders.First(o=>o.extra==kind)));
                if(results.Count>0) b.AppendLine(labels[kind]+": "+String.Join("; ",results.ToArray())+".");
            }
            var every=f.arms.SelectMany(a=>a.orders).ToList();
            var popped=every.Where(o=>o.times.firstPopupMs>=0).ToList();int late=every.Sum(o=>o.times.lateNotices),changing=every.Sum(o=>o.times.changing),locked=every.Count(o=>o.outcome=="locked");
            if(popped.Count>0) b.AppendLine("Notes and memos: "+every.Sum(o=>o.times.popups)+" answered; an order's first came "+S(popped.Min(o=>(long)o.times.firstPopupMs))+" to "+S(popped.Max(o=>(long)o.times.firstPopupMs))+" s after it showed; "+(late==0?"none after a tyre line was clicked.":late+" after a tyre line was clicked (answered by the next check)."));
            b.AppendLine(changing==0?"Stock panels: no figure changed between two reads (none was caught still filling in).":"Stock panels: a figure changed between two reads "+changing+" time"+(changing==1?"":"s")+" (caught still filling in, read again): "+String.Join(", ",f.arms.Where(a=>a.orders.Sum(o=>o.times.changing)>0).Select(a=>a.name+" "+a.orders.Sum(o=>o.times.changing)).ToArray())+".");
            if(locked>0) b.AppendLine("Open on another PC: "+locked+" time"+(locked==1?"":"s")+" (skipped, as it should be).");
            var untested=new List<string>();
            if(locked==0) untested.Add("an order open on another PC (open one of the test's orders at another PC while a test runs to see it)");
            if(late==0) untested.Add("a Notes or memo coming after a tyre line was clicked");
            if(changing==0) untested.Add("a stock panel still filling in");
            if(popped.Count==0) untested.Add("Notes or a memo popping up");
            if(untested.Count>0) b.AppendLine("Not met in this test: "+String.Join("; ",untested.ToArray())+".");
            // What wasn't tested: passes not run, and orders a pass didn't reach or read.
            int steps=f.arms.Count(a=>!a.again);
            var notRun=new List<string>();
            for(int i=steps;i<f.plan.Count;i++) notRun.Add(WholesaleSpeed.NameOf(f.plan[i])+(f.plan[i]=="baseline"&&i>0?" (again, at the end)":""));
            if(notRun.Count>0) b.AppendLine("Not tested (the run ended first): "+String.Join("; ",notRun.ToArray())+".");
            foreach(var a in f.arms) {
                var sample=a.orders.Where(o=>o.extra.Length==0).ToList();
                var reached=sample.Where(o=>o.outcome=="not reached").Select(o=>o.doc).ToList();var cut=sample.Where(o=>o.outcome=="stopped"||o.outcome=="left open").Select(o=>o.doc+(o.unread.Length>0?" ("+o.unread+")":"")).ToList();
                var unreadParts=rf.Arm==null?new List<string>():sample.Where(o=>WasRead(o)&&WasRead(Of(rf.Arm,o.doc))&&Unread(o,Of(rf.Arm,o.doc))).Select(o=>o.doc+" ("+(o.unread.Length>0?o.unread:"a reading problem")+")").ToList();
                if(reached.Count+cut.Count+unreadParts.Count==0) continue;
                b.AppendLine("Partly tested: "+a.name+": "+Counted(a).Count+" of "+f.sample.Count+" orders read"+(reached.Count>0?"; not reached: "+String.Join(", ",reached.ToArray()):"")+(cut.Count>0?"; cut short by the stop: "+String.Join(", ",cut.ToArray()):"")+(unreadParts.Count>0?"; part not read: "+String.Join(", ",unreadParts.ToArray()):"")+".");
            }
            if(rf.Arm!=null) {
                var notes=new List<string>();
                foreach(var a in f.arms.Where(x=>!Object.ReferenceEquals(x,rf.Arm))) {
                    foreach(var bo in rf.Arm.orders.Where(x=>x.extra.Length==0)) {
                        var o=Of(a,bo.doc);string c=Against(a,bo,rf);
                        if(c=="changed") notes.Add(a.name+", "+bo.doc+": changed in COSTAR meanwhile ("+(o==null?"":o.outcome=="locked"?"open on another PC":o.outcome=="not listed"||o.outcome=="not opened"?(Object.ReferenceEquals(a,rf.Other)?"no longer on the list for this 2.9.7 pass":"gone from the list for the other 2.9.7 pass too"):"the two 2.9.7 passes read it differently")+")");
                        else if(c=="difference") notes.Add(a.name+", "+bo.doc+": read differently with nothing to show COSTAR changed ("+bo.outcome+" "+bo.tags+" stock "+bo.stock+", then "+o.outcome+" "+o.tags+" stock "+o.stock+"): NOT RELIABLE");
                        else if(c=="missing") notes.Add(a.name+", "+bo.doc+": not on its list though 2.9.7 listed it before and after: NOT RELIABLE");
                        else if(c=="not listed") notes.Add(a.name+", "+bo.doc+": not on its list ("+(o.why.Length>0?o.why:"skipped")+"; with one 2.9.7 pass, whether it left the list meanwhile can't be told)");
                    }
                }
                var refNot=rf.Arm.orders.Where(x=>x.extra.Length==0&&!WasRead(x)).Select(x=>x.doc+" ("+(x.why.Length>0?x.why:x.outcome)+")").ToList();
                if(refNot.Count>0) notes.Add("not compared (the reference didn't read them): "+String.Join(", ",refNot.ToArray()));
                b.AppendLine(notes.Count==0?"Results: every approach read every order it reached as the reference read it.":"Results: "+String.Join("; ",notes.ToArray())+".");
            }
            b.AppendLine();
            b.AppendLine("To go back at any time: Back to 2.9.7.");
            b.AppendLine("Not part of this test (it needs another Windows login or COSTAR session): two wholesale sessions checking the list side by side.");
            return b.ToString();
        }
    }

    // The speed test itself (on a thread of its own, in the wholesale helper's session; Cancel stops it after the order
    // in hand): the list read once to choose the orders; then, one after another, a pass over those orders with each
    // preset: the baseline first and again last (anything that changed with the time of day shows), the four
    // improvements one at a time, all four together, all four with COSTAR's search by order number, all four with the
    // list filtered to BUF. Planned tests beside the orders: a row looked for at a deliberately wrong place (it must be
    // read whole and the right order opened) with the direct row on its own and with all four; a made-up order number
    // (not on the list: nothing opened) with all four and with the search by number. What it keeps: nothing of the
    // normal checking (no previews, no Discord message per order), so it can be run again at once and doesn't change it.
    // 2.9.9: also on the RDP helper's Wholesale tab (Tommy, 15 Nov 08:33: "put Speed test and the Approach selector on the
    // Wholesale tab in my usual RDP helper"), in that session's COSTAR Sydney: there each pass goes back to Repair Order at
    // its end (stayOnList false), as the tab's own pass does. COSTAR is held for the whole comparison (one operation:
    // phone jobs, eBay and online orders wait for it to end, never come in between its passes); it waits up to a minute
    // for other work to finish first. StatusLine: where it is (the pass, its approach, the order in hand).
    // 2.9.10 (Tommy, 15 Nov 10:43 and 11:17): a broader sample, looked for first (Scout); the chosen approach (all four by
    // number) and the BUF filter right after the first 2.9.7 pass, so a test cut short still has them; a listed order the
    // rules leave alone searched for by its number (it must be skipped); each pass's list checked against the first
    // read (WholesaleOptions.Expect); a pass stopped for COSTAR's list run once more after 10 s, and the comparison ended
    // with the reason if that stops too.
    internal sealed class WholesaleSpeedTest {
        internal static readonly string[] Plan={"baseline","all-number","all-buf","all","direct","ready","lean","timers","baseline"};
        internal const string Ghost="ZZ0000000";
        // The look for a broader sample: 24 orders and 6 minutes at most.
        internal const int ScoutMost=24;internal const long ScoutMs=360000;
        readonly EntryCoordinator coordinator;readonly Action<string> say;readonly Func<string> session;readonly WholesaleDiscord discord;
        readonly int size;readonly List<string> asked;readonly bool stayOnList;readonly string approach;
        internal volatile bool Cancel;internal volatile bool Running=true;internal volatile string Status="Speed comparison: starting";
        readonly Stopwatch clock=new Stopwatch();
        internal const string Owner="The wholesale speed comparison";
        volatile WholesaleRun current;
        internal string ReportText="",ReportFile="",BestKey="";
        // Passes run (0: none), and orders looked at for a broader sample: neither, and it never got started.
        internal volatile int Passes,LookedAt;
        List<HashSet<string>> bufSeen,filteredSeen;
        internal WholesaleSpeedTest(EntryCoordinator entries,Action<string> progress,Func<string> sessionCheck,WholesaleDiscord channel,int orders,IEnumerable<string> include,bool stayOnTheList,string approachNow) {
            coordinator=entries;say=progress;session=sessionCheck;discord=channel;size=Math.Max(2,Math.Min(30,orders));asked=(include??new string[0]).Where(x=>!String.IsNullOrWhiteSpace(x)).ToList();stayOnList=stayOnTheList;approach=approachNow??"";
        }
        internal WholesaleRun Current { get { return current; } }
        // "Speed comparison pass 3 of 9 (Ready checks, not 1.5 s waits): order 4 of 10 (WO…). 12 min so far. …"
        internal string StatusLine {
            get {
                var r=current;bool running=Running;string p=r==null||!running?"":r.OrderProgress??"";
                long min=clock.ElapsedMilliseconds/60000;
                return Status+(p.Length>0?": "+p:"")+(Status.EndsWith(".",StringComparison.Ordinal)?"":".")+(running&&clock.IsRunning?" "+(min<1?"Under a minute":min+" min")+" so far. Leave the PC alone until it's done (Stop: after the order in hand).":"");
            }
        }
        // Stopped after the order in hand (closed as usual); no further approach is run.
        internal void Stop() { Cancel=true;var r=current;if(r!=null) r.Finish=true; }
        void Say(string words) { try { say(words); } catch(Exception) { } }
        // An order left open, someone at the PC, or the session gone: the test ends there (a person's turn).
        void Ends(WholesaleRun run) {
            Order.Require(run.LeftOpen==null,"Order "+run.LeftOpen+" was left open in COSTAR Sydney: close it there, then run the test again.");
            Order.Require(!run.Stopped.StartsWith("Someone ",StringComparison.Ordinal),run.Stopped);
            string gone=session==null?null:session();
            Order.Require(gone==null,gone??"");
            Order.Require(!Cancel,"Stopped.");
        }
        internal void Run() {
            var file=new SpeedTestFile {version=AutofillForm.Version,started=DateTime.Now.ToString("yyyy-MM-dd HH:mm",CultureInfo.InvariantCulture),approach=approach};
            file.plan.AddRange(Plan);
            // Each pass's BUF orders as its list showed them: the whole list's (null for a filtered pass), the filtered list's.
            bufSeen=new List<HashSet<string>>();filteredSeen=new List<HashSet<string>>();
            EntryLease lease=null;clock.Start();WholesaleRun last=null;
            try {
                AppLog.Note("wholesale_speed_start",size+" orders"+(stayOnList?"":", the RDP helper's tab"));
                // COSTAR Sydney held for the whole comparison: other work finishing first is waited for (a minute at most).
                Status="Speed comparison: waiting for COSTAR";
                var sydney=WholesaleRun.Sydney();
                for(var waited=Stopwatch.StartNew();lease==null;) {
                    lease=coordinator.TryBegin(Owner,sydney);
                    if(lease!=null) break;
                    Order.Require(!Cancel,"Stopped.");
                    string other=coordinator.Owner.Length>0?coordinator.Owner:"Other work";
                    Order.Require(waited.ElapsedMilliseconds<60000,other+" was still using COSTAR after a minute, so the comparison didn't start. Press Run speed comparison again once it's done.");
                    Status="Speed comparison: waiting for "+other+" to finish with COSTAR";
                    Thread.Sleep(500);
                }
                Status="Speed comparison: reading the list";Say(Status+" (once, to choose the orders).");
                var look=new WholesaleRun(coordinator,say,new WholesaleOptions {Speed=WholesaleSpeed.Baseline,ListOnly=true,StayOnList=stayOnList,Session=session,Lease=lease});
                current=look;last=look;look.Run();
                Order.Require(look.Stopped.Length==0,look.Stopped);
                Order.Require(!Cancel,"Stopped.");
                var rows=look.LastRows??new List<WholesaleRow>();string today=DateTime.Now.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture);
                file.listed=rows.Count;file.buf=rows.Count(r=>WholesaleRules.ShipViaBuf(r.ShipVia));
                var open=rows.Where(r=>WholesaleRules.ShipViaBuf(r.ShipVia)&&WholesaleRules.Screen(r,today).Why==null).OrderBy(r=>r.Pos).ToList();
                file.eligible=open.Count;
                Order.Require(open.Count>=2,"Fewer than 2 BUF orders a pass would open are on the list now: nothing to compare.");
                var known=Scout(open,lease,file,out last);
                List<string> missing;
                file.sample=SpeedResults.Broad(open,asked,known,size,out missing);file.size=file.sample.Count;
                Order.Require(file.sample.Count>=2,"Fewer than 2 orders to compare: nothing to compare.");
                Say("Speed comparison orders: "+String.Join(", ",file.sample.ToArray())+" (each approach checks these, in the list's order).");
                if(missing.Count>0) Say("Not found among the "+known.Count+" orders looked at: "+String.Join(", ",missing.ToArray())+".");
                var left=asked.Select(x=>Order.Norm(x)).Where(x=>!file.sample.Contains(x)).Distinct().ToList();
                if(left.Count>0) Say("Not in the test (not a BUF order a pass would open now, or more than "+size+" asked for): "+String.Join(", ",left.ToArray())+".");
                string notEligible=SpeedResults.NotEligible(rows,today,file.sample);
                for(int i=0;i<Plan.Length;i++) {
                    Order.Require(!Cancel,"Stopped.");
                    var speed=WholesaleSpeed.Preset(Plan[i]);
                    for(int attempt=1;attempt<=2;attempt++) {
                        Status="Speed comparison pass "+(i+1)+" of "+Plan.Length+" ("+speed.Name+(i==Plan.Length-1?", again":"")+(attempt>1?", tried again":"")+")";Say(Status+".");
                        var how=new WholesaleOptions {Speed=delegate { return speed; },Only=file.sample,StayOnList=stayOnList,RestoreList=true,Session=session,Lease=lease,
                            WrongPlace=speed.key=="direct"||speed.key=="all",Ghost=speed.key=="all"||speed.key=="all-number"?Ghost:null,NotEligible=speed.key=="all-number"?notEligible:null,
                            Expect=file.listed,ExpectBuf=file.buf};
                        var run=new WholesaleRun(coordinator,say,how);current=run;last=run;
                        var passClock=Stopwatch.StartNew();run.Run();
                        var arm=new SpeedArmResult {key=speed.key,name=speed.Name+(i==Plan.Length-1?" (again)":"")+(attempt>1?" (tried again)":""),stopped=run.Stopped,durationMs=passClock.ElapsedMilliseconds,list=run.PassTimes??new WholesalePassTimes(),evidence=run.PersonEvidence??"",again=attempt>1};
                        foreach(var l in run.Looks.Where(x=>x.Opened||x.Locked||x.Extra!=null||file.sample.Contains(x.Row.Doc))) arm.orders.Add(SpeedResults.From(l));
                        foreach(var d in file.sample.Where(d=>!arm.orders.Any(o=>o.extra.Length==0&&o.doc==d))) arm.orders.Add(new SpeedOrderResult {doc=d,outcome="not reached",why="not reached"});
                        arm.testsMs=arm.list.restore+arm.orders.Where(o=>o.extra.Length>0).Sum(o=>Math.Max(0,o.times.total));
                        file.arms.Add(arm);Passes=file.arms.Count;
                        // A list taken as complete counts for the BUF filter's check; one that wasn't, for neither side.
                        var listedBuf=run.LastRows??new List<WholesaleRow>();
                        var seen=new HashSet<string>(listedBuf.Where(r=>WholesaleRules.ShipViaBuf(r.ShipVia)).Select(r=>r.Doc),StringComparer.Ordinal);
                        bufSeen.Add(arm.list.complete&&!arm.list.filtered?seen:null);filteredSeen.Add(arm.list.complete&&arm.list.filtered?seen:null);
                        AppLog.Note("wholesale_speed_arm",speed.key+": "+arm.orders.Count+" orders, median "+WholesaleTimes.S(SpeedReport.MedianMs(arm))+" s, list "+WholesaleTimes.S(arm.list.Refresh)+" s"+(arm.stopped.Length>0?", stopped: "+RoText.ForLog(arm.stopped):""));
                        Ends(run);
                        // COSTAR's list not showing or not finishing loading: once more after 10 s; again: the comparison can't continue.
                        if(run.ListStop) {
                            Order.Require(attempt==1,"The comparison couldn't continue: pass "+(i+1)+" ("+speed.Name+") stopped twice for COSTAR's list. "+run.Stopped);
                            Say("Pass "+(i+1)+" stopped for COSTAR's list ("+run.Stopped+"). Trying it once more in 10 s.");
                            for(var w=Stopwatch.StartNew();w.ElapsedMilliseconds<10000&&!Cancel;) Thread.Sleep(100);
                            Order.Require(!Cancel,"Stopped.");
                            continue;
                        }
                        break;
                    }
                    for(var w=Stopwatch.StartNew();w.ElapsedMilliseconds<2000&&!Cancel;) Thread.Sleep(100);
                }
            } catch(Exception e) {
                file.stopped=e is OperationCanceledException?"Stopped.":e.Message;
                var r=last;if(r!=null&&r.PersonEvidence.Length>0&&!file.arms.Any(a=>a.evidence==r.PersonEvidence)) file.evidence=r.PersonEvidence;
                AppLog.Note("wholesale_speed_stopped",RoText.ForLog(file.stopped));
            } finally {
                if(lease!=null) lease.Dispose();
                clock.Stop();
                file.finished=DateTime.Now.ToString("HH:mm",CultureInfo.InvariantCulture);
                try {
                    for(int i=0;i<file.arms.Count&&i<filteredSeen.Count;i++) file.arms[i].missedBuf=SpeedResults.Missed(bufSeen,filteredSeen,i);
                    file.best=SpeedReport.Best(file);BestKey=file.arms.Count>0?file.best:"";
                    ReportText=SpeedReport.Text(file);
                    string folder=Path.Combine(RunDiagnostics.Root,"speed");Directory.CreateDirectory(folder);
                    string stamp=DateTime.Now.ToString("yyyyMMdd-HHmmss",CultureInfo.InvariantCulture);
                    File.WriteAllText(Path.Combine(folder,"speed-"+stamp+".json"),Wire.Json(file),new UTF8Encoding(false));
                    ReportFile=Path.Combine(folder,"speed-"+stamp+".txt");File.WriteAllText(ReportFile,ReportText,new UTF8Encoding(false));
                    AppLog.Note("wholesale_speed_done","best-supported "+file.best+(file.stopped.Length>0?", stopped":""));
                    if(discord!=null&&file.arms.Count>0) {
                        var ba=file.arms.FirstOrDefault(a=>a.key==file.best);
                        string m0=WholesaleTimes.S(SpeedReport.BaselineMs(file));
                        discord.Say("speed-"+stamp,"**DRY RUN** · Wholesale speed comparison "+(file.stopped.Length>0?"stopped early":"done")+" ("+file.sample.Count+" orders): "+(file.best=="baseline"||ba==null?"none faster than 2.9.7 was reliable in it (2.9.7: "+m0+" s an order).":"best-supported: "+WholesaleSpeed.NameOf(file.best)+", "+WholesaleTimes.S(SpeedReport.MedianMs(ba))+" s an order (2.9.7: "+m0+" s).")+" The report is in the wholesale helper.");
                    }
                } catch(Exception e) { AppLog.Note("wholesale_speed_report_failed",e.GetType().Name);if(ReportText.Length==0) ReportText="The speed comparison's report couldn't be made: "+e.Message; }
                Status=file.stopped.Length>0?(file.arms.Count==0&&file.scouted.Count==0?"The speed comparison couldn't start: ":"The speed comparison stopped: ")+file.stopped.TrimEnd('.')
                    :"Speed comparison done ("+(clock.ElapsedMilliseconds/60000)+" min). "+(BestKey.Length>0&&BestKey!="baseline"?"Best-supported in this test: "+WholesaleSpeed.NameOf(BestKey):"None faster than 2.9.7 was reliable in this test")+" (the report has the rest)";
                Running=false;
            }
        }
        // 2.9.10 (Tommy, 15 Nov 10:43: "include a broader sample with multiple tyre lines and wheels where eligible"): the
        // look for it. The BUF orders a pass would open, the ones asked for first, then spread over the list
        // (SpeedResults.Spread), opened and read with All four, search by order number (the dry run: closed again,
        // nothing changed) until every case is in (SpeedResults.StillMissing), or 24 orders, or 6 minutes. Their reads
        // (contents only) are kept in the file (scouted), not compared with anything. Returns them by order.
        Dictionary<string,SpeedOrderResult> Scout(List<WholesaleRow> open,EntryLease lease,SpeedTestFile file,out WholesaleRun run) {
            var order=new List<string>();
            foreach(var d in asked) { string n=Order.Norm(d);if(open.Any(r=>r.Doc==n)&&!order.Contains(n)) order.Add(n); }
            var rest=open.Select(r=>r.Doc).Where(d=>!order.Contains(d)).ToList();
            foreach(int i in SpeedResults.Spread(rest.Count)) order.Add(rest[i]);
            order=order.Take(ScoutMost).ToList();
            var reads=new Dictionary<string,SpeedOrderResult>(StringComparer.Ordinal);var watch=Stopwatch.StartNew();
            Status="Speed comparison: looking for a broader sample";Say(Status+" (several tyre lines, wheels, Notes, a memo ...): up to "+order.Count+" orders, "+(ScoutMs/60000)+" minutes at most, all four by number.");
            Func<WholesaleLook,bool> enough=delegate(WholesaleLook l) {
                if(l.Extra==null) { var o=SpeedResults.From(l);reads[o.doc]=o;file.scouted.Add(o);LookedAt=file.scouted.Count; }
                var still=SpeedResults.StillMissing(reads.Values,size);
                Status="Speed comparison: looking for a broader sample ("+reads.Count+" looked at; still to find: "+(still.Count==0?"none":String.Join(", ",still.ToArray()))+")";
                return still.Count==0||watch.ElapsedMilliseconds>=ScoutMs;
            };
            var how=new WholesaleOptions {Speed=delegate { return WholesaleSpeed.Preset("all-number"); },Only=order,KeepOrder=true,StayOnList=stayOnList,RestoreList=true,Session=session,Lease=lease,Expect=file.listed,ExpectBuf=file.buf,Enough=enough};
            run=new WholesaleRun(coordinator,say,how);current=run;run.Run();
            Ends(run);
            Order.Require(run.Stopped.Length==0,"The look for a broader sample stopped: "+run.Stopped);
            AppLog.Note("wholesale_speed_scout",reads.Count+" looked at; still missing: "+String.Join(", ",SpeedResults.StillMissing(reads.Values,size).ToArray()));
            return reads;
        }
    }
}
