// Self-tests for the wholesale dry run (2.9.0): which orders are opened, the rules (Terms, card details, tyres, the
// stock, what it would do), the list, the Order window, the customer's Notes and the left-hand menu read from
// made-up COSTAR screens. Never opens, clicks or types into COSTAR. Made-up customers, orders and test card numbers
// (the card makers' published test numbers).
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace TempeCostar {
    internal static class WholesaleTests {
        static void Check(bool value,string message){if(!value)throw new InvalidOperationException(message);}
        // A made-up accessibility object: role, name, value, state, action and children.
        sealed class Node : Accessibility.IAccessible {
            internal readonly int Role,State;internal readonly string Name,Value,Action;internal int Pressed;internal readonly List<Node> Kids=new List<Node>();
            // 2.9.2: a call COSTAR doesn't answer (its name, its value, how many children).
            internal bool FailName,FailValue,FailCount;internal int EmptyChild;
            // 2.9.8: once every child has been given out (a read of all of them), some given out from another place
            // (an accessibility server whose cells taken on their own aren't the ones it lists).
            internal Dictionary<int,int> Later;int served;
            internal Node(int role,string name,string value=null,string action="",int state=0) { Role=role;Name=name;Value=value;Action=action;State=state; }
            internal Node Add(params Node[] kids) { Kids.AddRange(kids);return this; }
            object Accessibility.IAccessible.accParent { get { return null; } }
            int Accessibility.IAccessible.accChildCount { get { if(FailCount) throw new InvalidOperationException("COSTAR didn't answer.");return Kids.Count; } }
            object Accessibility.IAccessible.get_accChild(object varChild) {
                int i=Convert.ToInt32(varChild,CultureInfo.InvariantCulture);
                int j;if(++served>Kids.Count&&Later!=null&&Later.TryGetValue(i,out j)) i=j;
                return i>=1&&i<=Kids.Count&&i!=EmptyChild?Kids[i-1]:null;
            }
            string Accessibility.IAccessible.get_accName(object varChild) { if(FailName) throw new InvalidOperationException("COSTAR didn't answer.");return Name; }
            string Accessibility.IAccessible.get_accValue(object varChild) { if(FailValue) throw new InvalidOperationException("COSTAR didn't answer.");return Value; }
            string Accessibility.IAccessible.get_accDescription(object varChild) { return ""; }
            object Accessibility.IAccessible.get_accRole(object varChild) { return Role; }
            object Accessibility.IAccessible.get_accState(object varChild) { return State; }
            string Accessibility.IAccessible.get_accHelp(object varChild) { return ""; }
            int Accessibility.IAccessible.get_accHelpTopic(out string pszHelpFile,object varChild) { pszHelpFile="";return 0; }
            string Accessibility.IAccessible.get_accKeyboardShortcut(object varChild) { return ""; }
            object Accessibility.IAccessible.accFocus { get { return null; } }
            object Accessibility.IAccessible.accSelection { get { return null; } }
            string Accessibility.IAccessible.get_accDefaultAction(object varChild) { return Action; }
            void Accessibility.IAccessible.accSelect(int flagsSelect,object varChild) { }
            void Accessibility.IAccessible.accLocation(out int pxLeft,out int pyTop,out int pcxWidth,out int pcyHeight,object varChild) { pxLeft=0;pyTop=0;pcxWidth=10;pcyHeight=10; }
            object Accessibility.IAccessible.accNavigate(int navDir,object varStart) { return null; }
            object Accessibility.IAccessible.accHitTest(int xLeft,int yTop) { return null; }
            void Accessibility.IAccessible.accDoDefaultAction(object varChild) { System.Threading.Interlocked.Increment(ref Pressed); }
            void Accessibility.IAccessible.set_accName(object varChild,string pszName) { }
            void Accessibility.IAccessible.set_accValue(object varChild,string pszValue) { }
        }
        static WholesaleRow Row(string doc,string ordered,string ship,string shipVia,string comment) { return new WholesaleRow {Doc=doc,OrderDate=ordered,ShipDate=ship,ShipVia=shipVia,Comment=comment,Name="TEST CUSTOMER"}; }
        const string ST="WindowsForms10.STATIC.app.0.1",ED="WindowsForms10.EDIT.app.0.1",WN="WindowsForms10.Window.8.app.0.1",SB="WindowsForms10.SCROLLBAR.app.0.1";
        static ControlInfo Mk(long h,long parent,string cls,int x,int y,int w,int hh,string text) {
            return new ControlInfo {Handle=h,Parent=parent,Class=cls,Visible=true,Enabled=true,Bounds=new[]{x,y,w,hh},RelativeBounds=new[]{x,y,w,hh},Text=text,TextState="read"};
        }
        // A box nothing can be typed into (ES_READONLY), as COSTAR's order number and a loaded line's item, words, size, list.
        static ControlInfo RO(ControlInfo c) { c.Style|=WholesaleOrderReader.ReadOnly;return c; }
        // A made-up wholesale Order window laid out as COSTAR's (the 29 and 30 Oct maps). lines[n] = item, description,
        // size, order qty, back order, ship qty ("NOTE" as the item: a note line). expanded: line 1 is open (its box
        // 160 px high, the lines under it 140 px lower).
        static List<ControlInfo> OrderWindow(string number,string terms,string comment,Dictionary<int,string[]> lines,bool notesMarker,bool moreLines,bool expanded) {
            var s=new List<ControlInfo>();long id=1000;
            s.Add(Mk(id++,100,ST,37,83,176,17,"Order"));s.Add(RO(Mk(id++,100,ED,214,82,150,20,number)));s.Add(Mk(id++,100,"WindowsForms10.BUTTON.app.0.1",388,81,60,22,"Ne&xt #"));
            s.Add(Mk(id++,100,ST,389,108,95,15,"Order Date"));s.Add(Mk(id++,100,ST,389,215,95,15,"Terms"));s.Add(Mk(id++,100,ED,389,230,72,20,terms));
            s.Add(Mk(id++,100,ST,389,250,95,15,"Salesperson"));s.Add(Mk(id++,100,ED,389,265,72,20,"TV"));
            s.Add(Mk(id++,100,ST,706,85,51,13,"Comment"));s.Add(Mk(id++,100,ED,782,82,265,20,comment));
            s.Add(Mk(id++,100,ST,274,295,109,15,"PO#"));s.Add(Mk(id++,100,ED,274,310,109,20,"TEST PO"));
            if(notesMarker) s.Add(Mk(id++,100,ST,818,107,74,14,"Notes"));
            foreach(var hd in new[]{Tuple.Create(38,"#"),Tuple.Create(61,"Item"),Tuple.Create(223,"Description"),Tuple.Create(497,"Size"),Tuple.Create(646,"Order Qty"),Tuple.Create(687,"Back order"),Tuple.Create(728,"Ship Qty/Hrs"),Tuple.Create(769,"List"),Tuple.Create(832,"Disc"),Tuple.Create(873,"Net"),Tuple.Create(936,"Tax")})
                s.Add(Mk(id++,200,ST,hd.Item1,341,40,27,hd.Item2));
            s.Add(Mk(id++,200,ST,497,354,70,13,"Complete?"));
            var bar=Mk(id++,200,SB,1030,370,17,475,"");bar.Enabled=moreLines;s.Add(bar);
            for(int n=1;n<=25;n++) {
                int y=370+19*(n-1)+(expanded&&n>1?140:0);long panel=300+n;
                s.Add(Mk(panel,200,WN,38,y,993,expanded&&n==1?160:20,""));   // the line's own panel (160 px high when open)
                s.Add(Mk(id++,panel,ST,36,y+1,27,19,n.ToString(CultureInfo.InvariantCulture)));
                string[] l;lines.TryGetValue(n,out l);
                s.Add(Mk(id++,panel,ED,63,y,163,20,l==null?"":l[0]));
                s.Add(Mk(id++,panel,ED,107,y,40,20,"03/11/2026"));   // the narrow box behind the item (a date)
                if(l==null) continue;
                if(l[0]=="NOTE") { s.Add(Mk(id++,panel,ED,225,y,806,160,l[1]));continue; }
                s.Add(RO(Mk(id++,panel,ED,225,y,275,expanded&&n==1?160:20,l[1])));s.Add(RO(Mk(id++,panel,ED,499,y,149,20,l[2])));
                s.Add(Mk(id++,panel,ED,648,y,42,20,l[3]));s.Add(Mk(id++,panel,ED,689,y,42,20,l[4]));s.Add(Mk(id++,panel,ED,730,y,42,20,l[5]));
                s.Add(RO(Mk(id++,panel,ED,771,y,64,20,"140.00")));s.Add(Mk(id++,panel,ED,875,y,64,20,"140.00"));
            }
            // The totals (the 3 Nov map: labels in one panel, the amounts under Tax Out, GST and Tax In).
            s.Add(Mk(id++,400,ST,701,847,56,15,"Tax Out"));s.Add(Mk(id++,400,ST,756,847,69,15,"GST"));s.Add(Mk(id++,400,ST,971,847,77,15,"Tax In"));
            s.Add(Mk(id++,400,ST,684,863,73,19,"381.82"));s.Add(Mk(id++,400,ST,753,863,73,19,"38.18"));s.Add(Mk(id++,400,ST,972,863,73,19,"420.00"));
            return s;
        }
        // The stock panel COSTAR shows under an open line (the 3 Nov maps): "Frame1" in the line's panel, holding the stock
        // panel (On hand / - Commit / = Avail / On Order down the left, "ThisBr      OtherBrs" over two columns of read-only
        // boxes) and, always, a "NON-STOCKING!" label under it (Tommy's 17:09 map: covered by the stock panel, which comes
        // first in Windows' order). nonStocking: an item COSTAR doesn't stock: no stock panel over the label, so it shows.
        // labelOnTop: the label above the stock panel (it shows over it).
        static void StockPanel(List<ControlInfo> s,long linePanel,int y,string thisAvail,string otherAvail,bool nonStocking,bool heading=true,bool twice=false,bool labelOnTop=false) {
            long frame=linePanel*100+1,stock=linePanel*100+2,id=linePanel*1000;int top=y+26;
            s.Add(Mk(frame,linePanel,WN,39,top,900,130,"Frame1"));
            if(labelOnTop) s.Add(Mk(id++,frame,ST,43,top+22,154,17,"NON-STOCKING!"));
            if(!nonStocking) {
                s.Add(Mk(stock,frame,WN,39,top+20,165,111,""));
                if(heading) s.Add(Mk(id++,stock,ST,104,top+20,101,17,"ThisBr      OtherBrs"));
                string[] rows={"On hand","- Commit","= Avail","On Order"};
                for(int i=0;i<rows.Length;i++) {
                    int ry=top+33+19*i;s.Add(Mk(id++,stock,ST,39,ry+1,66,17,rows[i]));
                    s.Add(Mk(id++,stock,ED,104,ry,50,20,rows[i]=="= Avail"?thisAvail:i==0?"9":"0"));s.Add(Mk(id++,stock,ED,153,ry,50,20,rows[i]=="= Avail"?otherAvail:"5"));
                }
                if(twice) s.Add(Mk(id++,stock,ST,39,top+120,66,17,"= Avail"));
            }
            s.Add(Mk(id++,frame,ED,474,top,234,20,"TEST SUPPLIER ITEM"));s.Add(Mk(id++,frame,ST,710,top+3,50,14,"Sup List"));
            if(!labelOnTop) s.Add(Mk(id++,frame,ST,43,top+22,154,17,"NON-STOCKING!"));
        }
        static Dictionary<int,string[]> Lines() {
            return new Dictionary<int,string[]> {
                {1,new[]{"W43116","WINRUN 265/70R16 112T MAXCLAW A/T","265/70R16","4","4",""}},
                {2,new[]{"FREIGHT","FREIGHT CHARGE","","1","1",""}},
                {3,new[]{"NOTE","TEST NOTE FOR THE MADE-UP ORDER","","","",""}}
            };
        }
        static WholesaleLook Look(string terms,List<bool?> notes,bool marker,params WholesaleLine[] lines) {
            var l=new WholesaleLook {Row=Row("WO9000001","01/11/2026","03/11/2026","BUFRIV",""),Opened=true,Terms=terms,NotesMarker=marker,OrderComment="WWW"};
            if(notes!=null) { l.NotesRead.AddRange(notes);l.NotesShown=notes.Count>0; }
            l.Lines.AddRange(lines);l.Card=WholesaleRules.CardFrom(l.NotesRead,marker);
            return l;
        }
        // A tyre line: Sydney's displayed ThisBr "= Avail" (null: not read) and its Order Qty (4 unless said).
        static WholesaleLine Tyre(int n,int? available,string qty="4") { return new WholesaleLine {Number=n,Item="W4311"+n,Description="WINRUN 265/70R16",Size="265/70R16",OrderQty=qty,Tyre=true,Kind="tyre",Available=available}; }
        static WholesaleLine Other(int n) { return new WholesaleLine {Number=n,Item="FREIGHT",Description="FREIGHT CHARGE",OrderQty="1",Kind="freight"}; }
        static WholesaleLine Line(int n,string item,string description,string kind,string qty="4") { return new WholesaleLine {Number=n,Item=item,Description=description,OrderQty=qty,Kind=kind}; }
        static WholesaleLine Wheel(int n,string qty="4") { return Line(n,"KG178"+n,"KING 17X8 ET35 6/139.7 BLACK","wheel",qty); }
        static WholesaleLook Commented(string comment,string terms,List<bool?> notes,params WholesaleLine[] lines) { var l=Look(terms,notes,false,lines);l.OrderComment=comment;l.Row.Comment=comment;return l; }
        internal static void Cases(Action<string,Action> Case) {
            Case("Wholesale (2.9.7): which orders are opened: BUF, the Comment (variants, the helper's tags, go), the ShipDate; oldest first",()=>{
                string today="2026-11-03";
                Func<string,string,WholesaleScreen> screen=(c,ship)=>WholesaleRules.Screen(Row("WO1","01/11/2026",ship,"BUFRIV",c),today);
                foreach(var via in new[]{"BUFRIV","BUFWEST","BUFF","bufnewc"," BUFGLBN"}) Check(WholesaleRules.Screen(Row("WO1","01/11/2026","03/11/2026",via,""),today).Why==null,"Ship Via "+via+" is BUF.");
                foreach(var via in new[]{"DXTDUB","SHOP","","XBUF"}) Check(WholesaleRules.Screen(Row("WO1","01/11/2026","03/11/2026",via,""),today).Why.Contains("isn't BUF"),"Ship Via \""+via+"\" isn't BUF.");
                // Tommy, 14 Nov: "Accept variations of the existing allowed comments".
                foreach(var c in new[]{"","WWW","www","BUF","BUFF","BUFFALO","WWW BUF","WWW BUFF","www  buffalo"," WWW ","BUFFALO WWW","WWW-BUFFALO","www.buffalo.","WWWBUFFALO","W.W.W BUFF","WW BUFFALO","wwww buff","BUFALO","BUFFALLO","BUFFLO","Www / Buf","buffalo, www"}) {
                    var s=screen(c,"03/11/2026");Check(s.Why==null&&s.Comment.Kind=="fresh","Comment \""+c+"\" is a new order ("+s.Why+").");
                }
                foreach(var c in new[]{"B/O","B/O BUFFALO","AWAITING TT","AWAITING TT BUFFALO","WAITING TT","GAT","NO STOCK NO ANSWER 3:27","AT 11","AT 3","2/11","coming from roselands","CHECK STOCK","WWW CHECK STOCK","NO CARD DETAILS","WWW 2","WEB","ONLINE","WWW ORDER","W/O","BUFFS","stock","(stock)"}) {
                    var s=screen(c,"03/11/2026");Check(s.Comment.Kind=="staff"&&s.Why.StartsWith("staff's Comment",StringComparison.Ordinal),"Comment \""+c+"\" is staff's ("+s.Why+").");
                }
                foreach(var c in new[]{"go","GO","WWW go","buffalo GO."}) { var s=screen(c,"03/11/2026");Check(s.Comment.Kind=="go-only"&&s.Why.Contains("no helper flag"),"Comment \""+c+"\": go without a helper flag does nothing."); }
                foreach(var c in new[]{"[stock]","WWW [STOCK]","[stock] [card]","[ review ]","[stock] GO TO ROSELANDS","WWW [items] AWAITING TT"}) { var s=screen(c,"03/11/2026");Check(s.Comment.Kind=="flagged"&&s.Why.Contains("waiting for staff's go"),"Comment \""+c+"\": flagged, waiting for go."); }
                foreach(var c in new[]{"[stock] go","WWW [stock] [card] go","[REVIEW] GO.","[card]go","WWW go [stock]","WWW BUFFALO [stock] CALLED CUST go"}) { var s=screen(c,"03/11/2026");Check(s.Why==null&&s.Comment.Kind=="go","Comment \""+c+"\": staff's go, opened."); }
                Check(screen("","04/11/2026").Why.Contains("after today"),"A ShipDate after today waits.");
                Check(screen("","03/11/2026").Why==null&&screen("","28/10/2026").Why==null&&screen("","").Why==null,"Today's, an earlier or an empty ShipDate: opened.");
                var bad=screen("","3rd Nov");Check(bad.Why.Contains("can't be read")&&bad.Problem,"An unreadable ShipDate isn't opened, and it's a reading problem.");
                Check(screen("AT 11","3rd Nov").Comment.Kind=="staff"&&!screen("AT 11","3rd Nov").Problem,"Staff's comment first: no reading problem said for it.");
                var order=WholesaleRules.Oldest(new[]{Row("WO3","02/11/2026","","BUFF",""),Row("WO4","","","BUFF",""),Row("WO1","30/10/2026","","BUFF",""),Row("WO2","30/10/2026","","BUFF",""),Row("WO0","??","","BUFF","")});
                Check(String.Join(",",order.Select(r=>r.Doc).ToArray())=="WO1,WO2,WO3,WO0,WO4","Oldest first, then by number, an empty or unreadable date last: "+String.Join(",",order.Select(r=>r.Doc).ToArray()));
            });
            Case("Wholesale (2.9.7): the Comment's tags and go read, and written back with the other words kept",()=>{
                var p=WholesaleComment.Parse("WWW [card] [STOCK] CALLED go");
                Check(p.Kind=="go"&&p.Go&&String.Join(",",p.Tags.ToArray())=="stock,card","Tags in the helper's order, any case; go last.");
                Check(WholesaleComment.Parse("AWAITING TT").Other=="AWAITING TT"&&WholesaleComment.Parse("WWW 2/11").Other=="2 11","The staff's words kept for the reason.");
                Check(WholesaleComment.TagText(new[]{"items","stock","review","card"})=="[stock] [card] [review] [items]"&&WholesaleComment.TagText(new string[0])=="","Tags written in one order, lower case.");
                Func<string,string[],bool,string> with=WholesaleComment.With;
                Check(with("WWW",new[]{"stock","card"},false)=="WWW [stock] [card]"&&with("",new[]{"stock"},false)=="[stock]"&&with("  WWW   BUFFALO ",new[]{"review"},false)=="WWW BUFFALO [review]","Tags go at the end.");
                Check(with("WWW [stock] [card] go",new[]{"card"},false)=="WWW [card]","Tommy's example: [stock] [card] go with the stock now there becomes [card].");
                Check(with("WWW [stock] [card] go",new[]{"card"},true)=="WWW [card] go","A go whose recheck couldn't be finished stays.");
                Check(with("WWW BUFFALO [stock] CALLED CUST go",new[]{"card"},false)=="WWW BUFFALO CALLED CUST [card]","Staff's words kept (Tommy: \"preserving other staff-written text\").");
                Check(with("[review] go",new string[0],false)==""&&with("WWW, go!",new[]{"stock"},false)=="WWW [stock]"&&with("WWW go [stock]",new[]{"stock"},false)=="WWW [stock]","go and its punctuation taken off; nothing left: empty.");
                Check(with("[stock] GO TO ROSELANDS",new[]{"stock"},false)=="GO TO ROSELANDS [stock]","A go that isn't the last word is staff's words.");
                Check(with("WWW [stock] go go",new[]{"stock"},false)=="WWW [stock]"&&with("[stock] (go)",new[]{"stock"},false)=="[stock]"&&with("WWW [stock] go go",new[]{"stock"},true)=="WWW [stock] go","Every go at the end taken off (one left would still be read as go), with its brackets.");
                Check(WholesaleComment.Same("  WWW   [stock] ")=="WWW [stock]","Spaces collapsed for the compare.");
                Check(WholesaleComment.SameMeaning("WWW [review] [card] go","www  [CARD] [review] GO")&&WholesaleComment.SameMeaning("[stock]","[STOCK]"),"The same tags in another order or case: no change.");
                Check(!WholesaleComment.SameMeaning("WWW [stock] go","WWW [stock]")&&!WholesaleComment.SameMeaning("WWW [stock]","WWW [stock] [card]")&&!WholesaleComment.SameMeaning("WWW [stock]","BUF [stock]"),"go taken off, a tag added, other words: a change.");
            });
            Case("Wholesale (2.9.7): what a line is: tyre, wheel, tube, freight or other (flaps, valves, nuts)",()=>{
                Func<string,string,string,string> kind=WholesaleRules.KindOf;
                foreach(var size in new[]{"205/55R16","245/45ZR18","225/45 R17","LT245/75R16","265/70-16","P225/60R16","31X10.50R15","33X12.50R20LT","7.50R16","7.00-16","195R15C","11R22.5","295/80R22.5","255/35 ZR19 96Y","225/45RF17"}) Check(kind("T1",size,"")=="tyre","\""+size+"\" is a tyre.");
                Check(kind("T1","","WINRUN 265/70R16 112T MAXCLAW A/T")=="tyre","A tyre by its description.");
                Check(kind("T1","7.50-16","7.50-16 12PR TUBE TYPE")=="tyre"&&kind("T1","","7.50-16 TUBE TT 14PR")=="tyre"&&kind("T1","","TUBELESS 205/55R16 91V")=="tyre","A tube-type or tubeless tyre is a tyre.");
                Check(kind("LT245","","LT245/75R16 120/116Q")=="tyre"&&kind("C195","","195R15C 106/104R")=="tyre","Load indexes aren't stud patterns.");
                Check(kind("T750","7.50-16","TUBE 7.50-16 TR15")=="tube"&&kind("TB","","INNER TUBE 7.00-16")=="tube"&&kind("TB","","TUBES 750-16")=="tube","Tubes aren't tyres (Tommy, 14 Nov).");
                Check(kind("FL","","FLAP 7.50-16")=="other"&&kind("RB","","RIM BAND 16 INCH")=="other","Flaps aren't tyres either.");
                Check(kind("W1","17X8.0","KING 17X8 ET35 6/139.7 BLACK")=="wheel"&&kind("SM9188555","","18X8.5 18X9.5 SIMMONS OM-1 HYPER DARK 5/120.65 P0")=="wheel"&&kind("ST","","STEEL 15X6 6X139.7")=="wheel"&&kind("W","","16 x 7 4/100")=="wheel","Wheels by a rim size or a stud pattern.");
                Check(kind("PK","","17X7.5 5/114.3 WITH 225/45R17 TYRES")=="wheel","A package (a wheel's size and a tyre's) is a wheel.");
                Check(kind("IND","","18X7-8 SOLID")=="tyre"&&kind("ATV","","25X8-12 ATV TYRE")=="tyre"&&kind("ATV","","22X11-10 4PR")=="tyre"&&kind("MOW","","4.00-8 WHEELBARROW TYRE")=="tyre"&&kind("MOW","","4.80/4.00-8 2PR")=="tyre"&&kind("MINI","","145/70-6 GO KART")=="tyre","ATV, mower, kart and industrial tyres are tyres (their stock checked).");
                Check(kind("T","","7.50-16 12PR TUBE-TYPE")=="tyre"&&kind("T","","8.25-16 TUBE/TYPE")=="tyre"&&kind("T","","195R14C 8PR SUIT COURIER")=="tyre","Tube-type tyres, a tyre for a courier van: tyres (the review).");
                Check(kind("T","","8.25R16 TYRE TUBE AND FLAP SET")=="unsure"&&kind("T","","TYRE TUBE & FLAP 7.50-16")=="unsure","A tyre with its tube and flap, or a tube and flap for it: can't tell (the review, round 3).");
                Check(kind("T","","ALLOY WHEEL 18 INCH GLOSS BLACK")=="unsure"&&kind("T","","SIMMONS RIM BLACK")=="unsure"&&kind("T","","TYRE")=="unsure"&&kind("T","","TRUCK TIRE RECAP")=="unsure","Named a tyre or a wheel with no size known: can't tell.");
                // The review, round 2: not tyres after all.
                foreach(var d in new[]{"TYRE TUBE 7.50-16 TR15","TUBE FOR 7.50-16 TYRE","INNER TUBE 7.00-16 TYRE","7.50-16 TUBE AND FLAP"}) Check(kind("T","",d)=="tube","\""+d+"\" is a tube.");
                Check(kind("T","","TYRE FLAP 7.50-16")=="other"&&kind("T","","7.50-16 TYRE W/TUBE & FLAP")=="unsure","A flap; a tyre with its tube and flap: can't tell.");
                // Round 3: tyres the tightening had lost, and accessories sold by a tyre's size.
                foreach(var d in new[]{"37X12.50-17LT MICKEY THOMPSON BAJA","33X12.50-16.5 BIAS","38X15.50-15 INTERCO","16.00-25 OTR","4.00-8 PUNCTURE PROOF","16X6.50-8 LOW PRESSURE","22X11-10 LOW PRESSURE ATV","90/90-21 MOTORCYCLE","110/80-19","18.4-34 TRACTOR","12.4-28","750-16 12PR"}) Check(kind("T","",d)=="tyre","\""+d+"\" is a tyre.");
                Check(kind("T","","4.80/4.00-8 MOUNTED ON RIM")=="unsure","A small tyre on its rim: can't tell (never sold so).");
                Check(kind("T","","SNOW CHAINS 205/55R16")=="other"&&kind("T","","SPARE TYRE COVER 31X10.50R15")=="other"&&kind("T","","TYRE LEVERS")=="other","Accessories by a tyre's size, levers: other.");
                Check(kind("T","","KING 6/139.7 BLACK W/ CENTRE CAP")=="wheel"&&kind("T","","LUG NUTS 5X114.3")=="other"&&kind("T","","STEEL WHEEL 16 INCH 6 STUD")=="wheel","A wheel with its cap; nuts by a stud pattern; a wheel by its studs.");
                foreach(var d in new[]{"WHEEL BOLT M14X1.5-28","LOCKING WHEEL BOLTS 14X1.5-28","WHEEL NUT 12X1.25-60DEG","SPACER 12X1.5-25MM"}) Check(kind("T","",d)=="other","\""+d+"\": a part, not a tyre.");
                foreach(var d in new[]{"17X9 -12 BLACK","20X10 -18 MATTE BLACK","15X7 -6 STEEL"}) Check(kind("T","",d)=="wheel","\""+d+"\": a wheel (its offset after a space).");
                Check(kind("T","","17X8.5-6 SATIN BLACK")=="unsure","A small tyre's size with a wheel's words: can't tell.");
                Check(kind("T","","SPACER 20MM 5X114.3")=="other"&&kind("T","","ADAPTOR 6X139.7 TO 5X150")=="other"&&kind("T","","WHEEL 5/114.3 BLACK W/ CAPS")=="wheel"&&kind("T","","SIMMONS V-TEC 20")=="unsure","A spacer's or adaptor's stud pattern: a part; a wheel's: a wheel; a Simmons line with no size: can't tell.");
                foreach(var d in new[]{"WHEEL TRIM 15 INCH","TYRE BAGS","RIM STRIP","SPARE WHEEL CARRIER","TYRE CHANGEOVER","TYRE STORAGE","WHEEL CHOCK","TYRE DEFLATOR"}) Check(kind("T","",d)=="other","\""+d+"\": other, not unsure.");
                foreach(var d in new[]{"MAG WHEEL 17","15 INCH STEEL WHEEL","TYRE"}) Check(kind("T","",d)=="unsure","\""+d+"\": can't tell.");
                Check(kind("T","","WHEEL NUTS X 20")=="other"&&kind("T","","WHEEL WEIGHTS 5G")=="other"&&kind("T","","LOCKING WHEEL BOLTS")=="other"&&kind("T","","TYRE REPAIR KIT")=="other"&&kind("T","","TYRE DISPOSAL LEVY")=="other","Parts and services for tyres and wheels: other.");
                Check(kind("NUT","","WHEEL NUT M12X1.5")=="other"&&kind("NUT","","WHEEL NUT 12X1.25 CONE")=="other"&&kind("VS","","VALVE STEM TR413")=="other","Nut threads and valves aren't wheels.");
                Check(kind("F","","")=="freight"&&kind("FRT","","FREIGHT CHARGE")=="freight"&&kind("DEL","","DELIVERY FEE")=="freight"&&kind("POST","","POSTAGE")=="freight","Freight.");
                Check(kind("X1","","")=="other"&&kind("CAP","","CENTRE CAP CHROME")=="other","Anything else is other.");
            });
            Case("Wholesale (2.9.7): every check run, the tags [stock] [card] [review] [items], Sell then Cancel, reading problems",()=>{
                foreach(var t in new[]{"30INV","1INV","7ST","COD","EOM","CASH","cash","14ST CUSTOMER"}) Check(Array.IndexOf(WholesaleRules.TermCodes,WholesaleRules.TermCode(t))>=0,"Terms "+t+" are COSTAR's.");
                Check(WholesaleRules.TermCode("")==""&&WholesaleRules.TermCode("  ")=="","Empty Terms.");
                // The card makers' test numbers, made-up words.
                Check(WholesaleRules.CardDetails(new[]{"PAY BY CARD 4111 1111 1111 1111 EXP 05/27 CVV 123"}),"Visa test number with its expiry.");
                Check(WholesaleRules.CardDetails(new[]{"MC 5555-5555-5555-4444 12/2028"}),"Mastercard test number, dashes, a four-digit year.");
                Check(WholesaleRules.CardDetails(new[]{"ACCOUNT CUSTOMER","AMEX 3782 822463 10005 EXPIRY 0726"}),"Amex test number (4-6-5) with its expiry, in the second note.");
                Check(!WholesaleRules.CardDetails(new[]{"AMEX 3782 822463 10005","EXPIRY 0726"}),"The number in one note and an expiry in another: not card details.");
                Check(!WholesaleRules.CardDetails(new[]{"4111 1111 1111 1112 EXP 05/27"})&&!WholesaleRules.CardDetails(new[]{"4111 1111 1111 1111"})&&!WholesaleRules.CardDetails(new[]{"CALLED 2/11/2026 PH 0412 345 678 SAYS PAY ON PICKUP"}),"A bad check digit, no expiry, a date and a phone: no card details.");
                Check(!WholesaleRules.CardDetails(new string[0])&&!WholesaleRules.CardDetails(null),"No notes, no card details.");
                Check(WholesaleRules.CardFrom(new List<bool?>(),false)==false&&WholesaleRules.CardFrom(new List<bool?>(),true)==null&&WholesaleRules.CardFrom(new List<bool?>{false,null},false)==null,"No Notes popped up: none, unless the order has notes all the same; any unreadable: can't tell.");
                Check(!WholesaleRules.Enough(3)&&WholesaleRules.Enough(4)&&WholesaleRules.Enough(5)&&!WholesaleRules.Enough(0)&&!WholesaleRules.Enough(-2),"Enough: Sydney's = Avail 4 or more (Tommy, 14 Nov), as displayed.");
                var none=new List<bool?>();var noCard=new List<bool?>{false};var withCard=new List<bool?>{true};var unread=new List<bool?>{null};
                Func<WholesaleLook,WholesaleVerdict> decide=WholesaleRules.Decide;
                Func<WholesaleVerdict,string> tags=v=>WholesaleComment.TagText(v.Tags);
                var sell=decide(Look("30INV",none,false,Tyre(1,12),Tyre(2,4),Other(3)));
                Check(sell.Action=="sell"&&sell.Problems.Count==0&&sell.Tags.Count==0,"Every tyre at 4 or more: Sell, then Cancel.");
                var low=decide(Look("30INV",none,false,Tyre(1,12),Tyre(2,3)));
                Check(low.Action=="flag"&&tags(low)=="[stock]"&&low.CommentAfter=="WWW [stock]"&&low.Why.Contains("line 2")&&low.Why.Contains("= Avail 3 in Sydney"),"A tyre at 3: [stock] ("+low.Why+").");
                Check(tags(decide(Look("30INV",none,false,Tyre(1,-2))))=="[stock]","A tyre below 0 in Sydney: [stock].");
                Check(decide(Look("30INV",none,false,Tyre(1,0,"4"))).Action=="flag","Nothing added back any more: 0 with 4 on this order is [stock].");
                var non=Tyre(1,null);non.NonStocking=true;var nv=decide(Look("30INV",none,false,non,Tyre(2,9)));
                Check(tags(nv)=="[stock]"&&nv.Why.Contains("NON-STOCKING"),"A NON-STOCKING tyre: [stock].");
                var both=decide(Look("CASH",noCard,false,Tyre(1,2)));
                Check(tags(both)=="[stock] [card]"&&both.CommentAfter=="WWW [stock] [card]","CASH without card details and short stock: both tags (Tommy, 14 Nov).");
                Check(decide(Look("CASH",withCard,false,Tyre(1,8))).Action=="sell","CASH with card details: on to the stock, and Sell.");
                Check(tags(decide(Look("CASH",none,false,Tyre(1,9))))=="[card]","CASH, no Notes at all: [card].");
                var unk=decide(Look("CASH",unread,false,Tyre(1,1)));
                Check(unk.Action=="flag"&&tags(unk)=="[stock]"&&unk.Problems.Count==1&&unk.Problems[0].Contains("Notes"),"Notes unreadable: card unknown (no [card]), the confirmed [stock] written, a reading problem ("+String.Join("; ",unk.Problems.ToArray())+").");
                var unkOk=decide(Look("CASH",unread,false,Tyre(1,9)));
                Check(unkOk.Action=="leave"&&unkOk.Tags.Count==0&&unkOk.Problems.Count==1,"Notes unreadable, stock fine: nothing to change, not sold, tried again.");
                Check(tags(decide(Look("30INV",none,false,Tyre(1,9),Wheel(2))))=="[review]","Wheels on the order: [review].");
                Check(tags(decide(Look("30INV",none,false,Line(1,"TB750","TUBE 7.50-16","tube"),Other(2))))=="[items]"&&tags(decide(Look("30INV",none,false,Line(1,"VS","VALVE STEM","other"))))=="[items]","Only tubes, freight, valves...: [items].");
                Check(decide(Look("30INV",none,false,Tyre(1,9),Line(2,"TB750","TUBE 7.50-16","tube"),Other(3),Line(4,"VS","VALVE","other"))).Action=="sell","Tyres with tubes, freight and valves: the tyres checked, then Sell.");
                Check(tags(decide(Look("CASH",noCard,false,Tyre(1,2),Wheel(2))))=="[stock] [card] [review]","Every problem shows together.");
                var un=decide(Look("30INV",none,false,Tyre(1,9),Line(2,"AW18","ALLOY WHEEL 18 INCH GLOSS BLACK","unsure")));
                Check(un.Action=="leave"&&un.Problems.Count==1&&un.Problems[0].Contains("can't tell")&&un.Tags.Count==0,"A line that can't be told: not sold, a reading problem ("+String.Join("; ",un.Problems.ToArray())+").");
                Check(tags(decide(Look("30INV",none,false,Tyre(1,2),Line(2,"AW18","ALLOY WHEEL","unsure"))))=="[stock]","... a short tyre beside it is still [stock].");
                var odd=Look("CC 4111 1111 1111 1111 EXP 05/27",none,false,Tyre(1,9));odd.Verdict=decide(odd);
                Check(!String.Join(" ",odd.Verdict.Problems.ToArray()).Contains("4111")&&!WholesaleDiscord.OrderText(odd,true).Contains("4111"),"Terms that aren't a code: never quoted (the review: they could hold anything).");
                foreach(var terms in new[]{"",null,"90DAYS"}) {
                    var v=decide(Look(terms,none,false,Tyre(1,9)));
                    Check(v.Action=="leave"&&v.Problems.Count==1&&v.Problems[0].Contains("Terms"),"Terms \""+(terms??"(unread)")+"\": a reading problem, not sold.");
                    Check(tags(decide(Look(terms,none,false,Tyre(1,1))))=="[stock]","... and a short tyre beside it is still [stock].");
                }
                var more=Look("30INV",none,false,Tyre(1,1));more.MoreLines=true;var mv=decide(more);
                Check(tags(mv)=="[stock]"&&mv.Problems.Count==1,"More than 25 lines: what's seen short is [stock]; the rest can't be read.");
                more=Look("30INV",none,false,Tyre(1,9));more.MoreLines=true;mv=decide(more);
                Check(mv.Action=="leave"&&mv.Problems.Count==1&&mv.Tags.Count==0,"More than 25 lines, the visible tyres fine: not sold, tried again.");
                var why=Tyre(1,null);why.StockWhy="the line didn't open";var wv=decide(Look("30INV",none,false,why,Tyre(2,9)));
                Check(wv.Action=="leave"&&wv.Problems.Count==1&&wv.Problems[0].Contains("didn't open"),"A tyre whose stock couldn't be read: a reading problem, and why.");
                Check(tags(decide(Look("30INV",none,false,Tyre(1,null),Tyre(2,1))))=="[stock]","A short tyre is [stock] even beside an unread one.");
                var noLines=decide(Look("7ST",none,false));Check(noLines.Action=="leave"&&noLines.Problems.Count==1,"No item lines read: a reading problem.");
                var lineProblem=Look("7ST",none,false,Tyre(1,9));lineProblem.Problem="line 2 couldn't be read";var lp=decide(lineProblem);
                Check(lp.Action=="leave"&&lp.Problems.Contains("line 2 couldn't be read"),"A line that couldn't be read: a reading problem.");
                var gone=Look("30INV",none,false,Tyre(1,9));gone.OrderComment=null;var gv=decide(gone);
                Check(gv.Action=="leave"&&gv.Problems[0].Contains("Comment"),"The order's Comment unreadable: nothing changed, a reading problem.");
                Check(decide(Commented("AT 11","30INV",none,Tyre(1,9))).Action=="skip"&&decide(Commented("[stock]","30INV",none,Tyre(1,9))).Action=="skip"&&decide(Commented("go","30INV",none,Tyre(1,9))).Action=="skip","Staff's words, a flag without go, or go alone on the order itself: skipped.");
                Check(decide(Commented("BUFFALO WWW","30INV",none,Tyre(1,9))).Action=="sell","A Comment variant: checked as new.");
                // go (Tommy, 14 Nov).
                var g1=decide(Commented("WWW [stock] [card] go","CASH",noCard,Tyre(1,6)));
                Check(g1.Action=="flag"&&g1.Go&&!g1.KeepGo&&g1.CommentAfter=="WWW [card]","Tommy's example: [stock] [card] go, now enough stock but no card details: [card].");
                var g2=decide(Commented("[review] go","30INV",none,Tyre(1,9),Wheel(2)));
                Check(g2.Action=="sell"&&g2.Approve.Contains("review"),"[review] go, everything else fine: Sell, then Cancel; the wheels approved.");
                var g3=decide(Commented("[review] [card] go","CASH",noCard,Tyre(1,9),Wheel(2)));
                Check(g3.Action=="flag"&&g3.CommentAfter=="[card]"&&g3.Approve.Contains("review"),"[review] [card] go, still no card details: [card], the wheels approved and kept.");
                var later=Commented("[card] go","CASH",withCard,Tyre(1,9),Wheel(2));later.Approval=new WholesaleApproval {Review=WholesaleRules.Print(new[]{Wheel(2)})};
                var g4=decide(later);
                Check(g4.Action=="sell"&&g4.Approve.Count==0&&g4.Why.Contains("approved"),"The next go: the wheels approved before (same lines) stay approved: Sell, then Cancel (Tommy: \"recognise the approval already given\").");
                var changedWheels=Commented("[card] go","CASH",withCard,Tyre(1,9),Wheel(2,"8"));changedWheels.Approval=new WholesaleApproval {Review=WholesaleRules.Print(new[]{Wheel(2)})};
                Check(tags(decide(changedWheels))=="[review]","Different wheels (another quantity): [review] again.");
                var notShown=Commented("[card] go","CASH",withCard,Tyre(1,9),Wheel(2));
                Check(tags(decide(notShown))=="[review]","Wheels that weren't flagged when go was written aren't approved by it.");
                var items=Commented("[items] go","7ST",none,Line(1,"TB750","TUBE 7.50-16","tube"));var iv=decide(items);
                Check(iv.Action=="sell"&&iv.Approve.Contains("items"),"[items] go: approved, Sell, then Cancel.");
                var half=decide(Commented("[stock] [card] go","CASH",unread,Tyre(1,9)));
                Check(half.Action=="flag"&&half.KeepGo&&half.CommentAfter=="[card] go"&&half.Approve.Count==0&&half.Problems.Count==1,"go, but the Notes can't be read: [card] kept as it was, [stock] off (enough now), go kept, nothing approved yet.");
                var halfReview=decide(Commented("[review] [card] go","CASH",unread,Tyre(1,9),Wheel(2)));
                Check(halfReview.Action=="leave"&&halfReview.KeepGo&&halfReview.Approve.Count==0&&tags(halfReview)=="[card] [review]","go on wheels, but the Notes can't be read: nothing approved yet, [review] and go stay for the next recheck ("+halfReview.CommentAfter+").");
                // A flagged order tried again for a reading problem of its own: tags only added, never sold.
                var retry=Commented("WWW [stock]","CASH",noCard,Tyre(1,9));retry.Retry=true;var rv=decide(retry);
                Check(rv.Action=="flag"&&rv.CommentAfter=="WWW [stock] [card]","Tried again: [card] added, [stock] kept (no go: not taken off).");
                var retryOk=Commented("WWW [STOCK]","30INV",none,Tyre(1,9));retryOk.Retry=true;var ro=decide(retryOk);
                Check(ro.Action=="leave"&&ro.Tags.Count==1,"Tried again, nothing new: left as it is (any case), never sold.");
                Check(decide(Commented("WWW [STOCK] go","30INV",none,Tyre(1,2))).CommentAfter=="WWW [stock]","go taken off, the tag as the helper writes it.");
                Check(WholesaleRules.Plain(sell).StartsWith("Would SELL",StringComparison.Ordinal)&&WholesaleRules.Plain(low).StartsWith("Would change the Comment \"WWW\" to \"WWW [stock]\"",StringComparison.Ordinal),"Plain words for the tab.");
                Check(WholesaleRules.Message("Someone used the COSTAR PC while Repair Order WO1 was being opened. COSTAR's Work-in-Progress list is covered.")=="Someone used the COSTAR PC while Order WO1 was being opened. COSTAR's wholesale list is covered.","The open's words for an Order.");
            });
            Case("Wholesale (2.9.7): the loop's plan: 06:00-18:00, waits 1/3/5/10 s, retries, 100 a pass, go first, previews kept",()=>{
                Check(!WholesalePlan.InHours(new DateTime(2026,11,15,5,59,0))&&WholesalePlan.InHours(new DateTime(2026,11,15,6,0,0))&&WholesalePlan.InHours(new DateTime(2026,11,15,17,59,59))&&!WholesalePlan.InHours(new DateTime(2026,11,15,18,0,0)),"06:00 to 18:00.");
                Check(WholesalePlan.NextOpen(new DateTime(2026,11,15,5,0,0))==new DateTime(2026,11,15,6,0,0)&&WholesalePlan.NextOpen(new DateTime(2026,11,15,18,30,0))==new DateTime(2026,11,16,6,0,0),"The next 06:00.");
                int step=-1;var waits=new List<int>();
                foreach(bool processed in new[]{false,true,false,false,false,false,true,false}) { step=WholesalePlan.Step(step,processed);waits.Add(WholesalePlan.WaitSeconds(step)); }
                Check(String.Join(",",waits.Select(x=>x.ToString()).ToArray())=="1,1,3,5,10,10,1,3","Waits 1, 3, 5, then 10 s; back to 1 s when an order is processed: "+String.Join(",",waits.Select(x=>x.ToString()).ToArray()));
                var now=new DateTime(2026,11,15,0,0,0,DateTimeKind.Utc);
                Check(WholesalePlan.RetryAt(true,now,now)==now.AddMinutes(2)&&WholesalePlan.RetryAt(false,now.AddMinutes(-59),now)==now.AddMinutes(5)&&WholesalePlan.RetryAt(false,now.AddMinutes(-61),now)==now.AddHours(1),"Locked 2 minutes; a reading problem 5 minutes, hourly after an hour.");
                Check(WholesalePlan.FromMs(WholesalePlan.ToMs(now))==now,"Times kept to the ms.");
                string today="2026-11-15";
                var rows=new List<WholesaleRow>{
                    Row("WO3","03/11/2026","","BUFF",""),Row("WO2","02/11/2026","","BUFF","WWW"),Row("WO1","05/11/2026","","BUFF","[stock] go"),Row("WO4","01/11/2026","","BUFF","[card]"),
                    Row("WO5","01/11/2026","","BUFF","B/O"),Row("WO6","01/11/2026","20/11/2026","BUFF",""),Row("WO7","01/11/2026","??","BUFF",""),Row("WO8","01/11/2026","","BUFF",""),
                    Row("WO9","01/11/2026","","BUFF",""),Row("WO10","01/11/2026","","BUFF","[review] go"),Row("WO11","01/11/2026","","BUFF",""),Row("WO12","04/11/2026","","BUFF",""),
                    Row("WO13","01/11/2026","","BUFF","[stock]"),Row("WO14","01/11/2026","","DXTDUB","")};
                var memos=new Dictionary<string,WholesaleMemo>();
                Func<WholesaleRow,string,long,WholesaleMemo> memo=(r,last,retry)=>new WholesaleMemo {doc=r.Doc,sig=WholesalePlan.Sig(r),last=last,day=today,at=WholesalePlan.ToMs(now),retryAt=retry,problems="its Terms couldn't be read"};
                long due=WholesalePlan.ToMs(now.AddMinutes(-1)),later=WholesalePlan.ToMs(now.AddMinutes(3));
                memos["WO8"]=memo(rows[7],"problem",due);memos["WO9"]=memo(rows[8],"problem",later);memos["WO10"]=memo(rows[9],"locked",later);
                memos["WO11"]=memo(rows[10],"sell",0);var old=memo(rows[11],"sell",0);old.day="2026-11-14";memos["WO12"]=old;memos["WO13"]=memo(rows[12],"problem",due);
                Func<string,WholesaleMemo> get=d=>{ WholesaleMemo m;return memos.TryGetValue(d,out m)?m:null; };
                var plan=WholesalePlan.Queue(rows,get,today,now,true,100);
                string open=String.Join(",",plan.Where(x=>x.Skip==null).Select(x=>x.Row.Doc+":"+x.Queue).ToArray());
                Check(open=="WO1:go,WO2:new,WO3:new,WO12:new,WO8:retry,WO13:retry","Go first, then new oldest first (yesterday's preview again), then retries due: "+open);
                Check(plan.First(x=>x.Row.Doc=="WO13").Retry&&!plan.First(x=>x.Row.Doc=="WO8").Retry,"A flagged order tried again is marked so (tags only added).");
                Func<string,string> skip=d=>plan.First(x=>x.Row.Doc==d).Skip??"";
                Check(skip("WO4").Contains("waiting for staff's go")&&skip("WO5").Contains("staff's Comment")&&skip("WO6").Contains("after today")&&skip("WO7").Contains("can't be read")&&plan.First(x=>x.Row.Doc=="WO7").ListProblem,"Flag waiting, staff's, future, unreadable ShipDate.");
                Check(skip("WO9").Contains("tried again at")&&skip("WO10").StartsWith("go: open on another PC",StringComparison.Ordinal)&&skip("WO11").StartsWith("previewed at",StringComparison.Ordinal),"Not due yet; the same go waiting for its try; previewed today, unchanged.");
                Check(plan.All(x=>x.Row.Doc!="WO14"),"Not BUF: not in the plan.");
                var two=WholesalePlan.Queue(rows,get,today,now,true,2);
                Check(two.Count(x=>x.Skip==null)==2&&two.First(x=>x.Row.Doc=="WO3").Skip.Contains("the next pass"),"At most `most` a pass; the rest: the next pass.");
                // The row changed (staff added go, or edited the Comment): looked at again at once.
                var changed=Row("WO11","01/11/2026","","BUFF","WWW");
                Check(WholesalePlan.Queue(new List<WholesaleRow>{changed},get,today,now,true,100)[0].Queue=="new","A previewed order whose row changed is looked at again.");
                Check(WholesalePlan.Queue(new List<WholesaleRow>{rows[10]},get,today,now,false,100)[0].Queue=="new","Not a dry run: no previews kept (the order's own Comment changes instead).");
                // What's kept after a look.
                var l=Look("30INV",new List<bool?>(),false,Tyre(1,9));l.Row=Row("WO20","01/11/2026","","BUFF","WWW");l.Terms=null;l.Verdict=WholesaleRules.Decide(l);
                var m1=WholesalePlan.After(null,l,today,now,true,l.Row.Comment);
                Check(m1.last=="problem"&&m1.firstProblem==WholesalePlan.ToMs(now)&&m1.retryAt==WholesalePlan.ToMs(now.AddMinutes(5))&&m1.problems.Contains("Terms"),"A reading problem: tried again in 5 minutes.");
                var m2=WholesalePlan.After(m1,l,today,now.AddMinutes(70),true,l.Row.Comment);
                Check(m2.firstProblem==m1.firstProblem&&m2.retryAt==WholesalePlan.ToMs(now.AddMinutes(130)),"The same problem an hour on: hourly.");
                l.Terms="30INV";l.Verdict=WholesaleRules.Decide(l);var m3=WholesalePlan.After(m2,l,today,now.AddMinutes(75),true,l.Row.Comment);
                Check(m3.last=="sell"&&m3.retryAt==0&&m3.problems=="","Cleared: no more tries.");
                var lk=Look("30INV",new List<bool?>(),false);lk.Row=Row("WO21","01/11/2026","","BUFF","");lk.Locked=true;
                var m4=WholesalePlan.After(null,lk,today,now,true,"");Check(m4.last=="locked"&&m4.retryAt==WholesalePlan.ToMs(now.AddMinutes(2)),"Locked: 2 minutes.");
                var ap=Commented("[review] go","30INV",new List<bool?>(),Tyre(1,9),Wheel(2));ap.Row.Doc="WO22";ap.Verdict=WholesaleRules.Decide(ap);
                Check(WholesalePlan.After(null,ap,today,now,true,"").review==null&&WholesalePlan.After(null,ap,today,now,false,"").review==WholesaleRules.Print(new[]{Wheel(2)}),"Approvals kept only when the comment was really written (not by the dry run).");
                // Followed for a reading problem or a lock: let go once it's off the list, or changed and not to be checked now.
                var fm=new WholesaleMemo {doc="WO30",sig=WholesalePlan.Sig(Row("WO30","01/11/2026","","BUFF","WWW")),last="problem"};
                Check(WholesalePlan.Dropped(fm,null,today).Contains("no longer on COSTAR's list"),"Off the list: let go.");
                Check(WholesalePlan.Dropped(fm,Row("WO30","01/11/2026","","BUFF","WWW"),today)==null,"The same row: still followed.");
                Check(WholesalePlan.Dropped(fm,Row("WO30","01/11/2026","","BUFF","WWW BUFFALO"),today)==null,"Changed, still to be checked: looked at as new (not let go here).");
                Check(WholesalePlan.Dropped(fm,Row("WO30","01/11/2026","","DXTDUB","WWW"),today).Contains("isn't BUF"),"Not BUF any more: let go.");
                string staffWhy=WholesalePlan.Dropped(fm,Row("WO30","01/11/2026","","BUFF","CALLED JOHN AT 11"),today);
                Check(staffWhy=="its Comment is staff's now (left for staff)","Staff's words now: let go, never quoting them ("+staffWhy+").");
                Check(WholesalePlan.Dropped(fm,Row("WO30","01/11/2026","20/11/2026","BUFF","WWW"),today)=="its ShipDate is after today now","A ShipDate after today now: let go.");
                Check(WholesalePlan.Dropped(fm,Row("WO30","01/11/2026","??","BUFF","WWW"),today)==null,"Its ShipDate unreadable now: said as that (still followed).");
                var flaggedMemo=new WholesaleMemo {doc="WO31",sig=WholesalePlan.Sig(Row("WO31","01/11/2026","","BUFF","WWW [stock]")),last="problem"};
                Check(WholesalePlan.Dropped(flaggedMemo,Row("WO31","01/11/2026","","BUFF","WWW [stock]"),today)==null,"Flagged by the helper, unchanged: still followed (tried again when due).");
                Check(WholesalePlan.Dropped(null,null,today)==null,"Nothing kept: nothing to let go.");
                // The review: a go previewed today (the dry run never takes it off) isn't opened every pass.
                var goRow=Row("WO40","01/11/2026","","BUFF","WWW [stock] go");
                var goMemo=new WholesaleMemo {doc="WO40",sig=WholesalePlan.Sig(goRow),last="flag",day=today,at=WholesalePlan.ToMs(now),why="x"};
                Func<string,WholesaleMemo> goGet=d=>d=="WO40"?goMemo:null;
                Check(WholesalePlan.Queue(new List<WholesaleRow>{goRow},goGet,today,now,true,100)[0].Skip.StartsWith("go: previewed at",StringComparison.Ordinal),"A go previewed today, row unchanged: not again today.");
                Check(WholesalePlan.Queue(new List<WholesaleRow>{goRow},goGet,today,now,false,100)[0].Queue=="go","... (a real run takes the go off, so it's always opened).");
                goMemo.day="2026-11-14";
                Check(WholesalePlan.Queue(new List<WholesaleRow>{goRow},goGet,today,now,true,100)[0].Queue=="go","... and opened again the next day.");
                // A lock keeps the problem it had; a flagged order is still tried again after it.
                var fl=Commented("WWW [stock]","CASH",new List<bool?>{null},Tyre(1,9));fl.Row=Row("WO41","01/11/2026","","BUFF","WWW [stock]");fl.Retry=true;fl.Verdict=WholesaleRules.Decide(fl);
                var p1=WholesalePlan.After(null,fl,today,now,true,fl.Row.Comment);
                var flk=Look("30INV",new List<bool?>(),false);flk.Row=fl.Row;flk.Locked=true;
                var p2=WholesalePlan.After(p1,flk,today,now.AddMinutes(6),true,fl.Row.Comment);
                Check(p1.last=="problem"&&p2.last=="locked"&&p2.problems==p1.problems&&p2.firstProblem==p1.firstProblem,"Locked: the problem it had kept.");
                Func<string,WholesaleMemo> flGet=d=>d=="WO41"?p2:null;
                var flPlan=WholesalePlan.Queue(new List<WholesaleRow>{fl.Row},flGet,today,now.AddMinutes(9),true,100)[0];
                Check(flPlan.Queue=="retry"&&flPlan.Retry,"A flagged order found locked while tried again for its problem: tried again after the 2 minutes (the review).");
                var p3=WholesalePlan.After(p2,fl,today,now.AddMinutes(9),true,fl.Row.Comment);
                Check(p3.last=="problem"&&p3.firstProblem==p1.firstProblem,"... its first problem time kept (hourly after an hour).");
                // Counts: a result the same as last time for the same row doesn't reset the waits (the dry run).
                var fr=Commented("WWW","CASH",new List<bool?>{null},Tyre(1,2));fr.Row=Row("WO42","01/11/2026","","BUFF","WWW");fr.Verdict=WholesaleRules.Decide(fr);
                var q1=WholesalePlan.After(null,fr,today,now,true,fr.Row.Comment);var q2=WholesalePlan.After(q1,fr,today,now.AddMinutes(6),true,fr.Row.Comment);
                Check(fr.Verdict.Action=="flag"&&fr.Verdict.Problems.Count==1&&q2.last=="problem","(a [stock] found beside unreadable Notes: would flag, tried again)");
                Check(WholesalePlan.Counts(null,q1,fr,true)&&!WholesalePlan.Counts(q1,q2,fr,true)&&WholesalePlan.Counts(q1,q2,fr,false),"The same result again: not new (the review); the first time, or a real run: processed.");
                Check(!WholesalePlan.Counts(p1,p3,fl,true),"Nothing new to show on a flagged order tried again: never.");
                Check(!WholesalePlan.Counts(null,null,flk,true),"Locked: never.");
                // The rest of a pass after the list was read again (the review: an order filled or changed meanwhile).
                var r1=Row("WO50","01/11/2026","","BUFF","WWW");var r2=Row("WO51","01/11/2026","","BUFF","WWW");var r3=Row("WO52","01/11/2026","","BUFF","WWW");var r4=Row("WO53","02/11/2026","","BUFF","[review] go");
                var left=WholesalePlan.Queue(new List<WholesaleRow>{r1,r2,r3},d=>null,today,now,true,100);
                var r2now=Row("WO51","01/11/2026","20/11/2026","BUFF","WWW");
                var again=WholesalePlan.Queue(new List<WholesaleRow>{r1,r2now,r4},d=>null,today,now,true,100);
                List<WholesaleLook> dropped;var rest=WholesalePlan.Rest(left,again,out dropped);
                Check(String.Join(",",rest.Select(x=>x.Row.Doc+":"+x.Queue).ToArray())=="WO53:go,WO50:new","A new go first, then what's still to open: "+String.Join(",",rest.Select(x=>x.Row.Doc+":"+x.Queue).ToArray()));
                Check(dropped.Count==2&&dropped.Any(x=>x.Row.Doc=="WO51"&&x.Skip.Contains("after today"))&&dropped.Any(x=>x.Row.Doc=="WO52"&&x.Skip.Contains("no longer on COSTAR's list")),"Another ShipDate now, or gone: not opened after all, with why.");
                Check(Object.ReferenceEquals(rest[1].Row,again.First(x=>x.Row.Doc=="WO50").Row),"Opened as listed now.");
                // An unreadable ShipDate followed as a problem (let go when its row changes or leaves the list).
                var lp=WholesalePlan.ListProblem(null,Row("WO60","01/11/2026","??","BUFF",""),today,now);
                Check(lp.last=="problem"&&lp.problems.Contains("ShipDate")&&WholesalePlan.Dropped(lp,Row("WO60","01/11/2026","??","BUFF",""),today)==null&&WholesalePlan.Dropped(lp,Row("WO60","01/11/2026","25/11/2026","BUFF",""),today)=="its ShipDate is after today now","An unreadable ShipDate: followed; let go when it changes.");
                Check(WholesalePlan.Queue(new List<WholesaleRow>{Row("WO60","01/11/2026","??","BUFF","WWW [stock]")},d=>d=="WO60"?WholesalePlan.ListProblem(null,Row("WO60","01/11/2026","??","BUFF","WWW [stock]"),today,now):null,today,now,true,100)[0].Skip!=null,"... never opened for it, even flagged.");
                Check(WholesalePlan.Processed(l)&&!WholesalePlan.Processed(lk)&&!WholesalePlan.Processed(Commented("AT 11","30INV",new List<bool?>()))&&!WholesalePlan.Processed(null),"Processed: sold or flagged (not skipped, locked or unread).");
            });
            Case("Wholesale (2.9.7): Discord's words: DRY RUN, the order's number and tags, no names or Comment words; message ids read",()=>{
                var s=Look("30INV",new List<bool?>(),false,Tyre(1,12));s.Verdict=WholesaleRules.Decide(s);
                string st=WholesaleDiscord.OrderText(s,true);
                Check(st=="**DRY RUN** · Order WO9000001 (BUFRIV, 30INV): would **Sell, then Cancel**","A sale ("+st+").");
                var f=Look("CASH",new List<bool?>{false},false,Tyre(1,2),Wheel(2));f.Verdict=WholesaleRules.Decide(f);
                string ft=WholesaleDiscord.OrderText(f,true);
                Check(ft.StartsWith("**DRY RUN** · Order WO9000001 (BUFRIV, CASH): would flag **[stock] [card] [review]**",StringComparison.Ordinal)&&ft.Contains("= Avail 2 in Sydney")&&!ft.Contains("TEST CUSTOMER")&&!ft.Contains("WWW"),"A flag: the tags and why, no customer name or Comment words ("+ft+").");
                var p=Look("CASH",new List<bool?>{null},false,Tyre(1,9));p.Verdict=WholesaleRules.Decide(p);
                string pt=WholesaleDiscord.OrderText(p,true);
                Check(pt.Contains("left as it is")&&pt.Contains("can't read:")&&pt.Contains("not sold"),"A reading problem: said ("+pt+").");
                var nc=Look("30INV",new List<bool?>(),false,Tyre(1,2));nc.OrderComment=null;nc.Verdict=WholesaleRules.Decide(nc);
                Check(WholesaleDiscord.OrderText(nc,true).Contains("found **[stock]**; left as it is"),"Its Comment unreadable: what was found, not what it shows (the review).");
                Check(WholesaleDiscord.Problem(pt)&&WholesaleDiscord.Problem(WholesaleDiscord.OrderText(new WholesaleLook {Row=Row("WO7","01/11/2026","??","BUFF",""),Skip="x",ListProblem=true},true))&&!WholesaleDiscord.Problem(st),"A message that says something can't be read is told apart.");
                Check(!WholesaleDiscord.OrderText(s,false).Contains("DRY RUN")&&WholesaleDiscord.OrderText(s,false).Contains("**sold**"),"Not a dry run: no DRY RUN.");
                var sk=Commented("AT 11","30INV",new List<bool?>());sk.Verdict=WholesaleRules.Decide(sk);var lk=Look("30INV",new List<bool?>(),false);lk.Locked=true;
                Check(WholesaleDiscord.OrderText(sk,true)==null&&WholesaleDiscord.OrderText(lk,true)==null&&WholesaleDiscord.OrderText(null,true)==null,"Skipped or open on another PC: nothing said.");
                var lp=new WholesaleLook {Row=Row("WO7","01/11/2026","??","BUFF",""),Skip="its ShipDate can't be read",ListProblem=true};
                Check(WholesaleDiscord.OrderText(lp,true).Contains("can't read its ShipDate"),"An unreadable ShipDate: said.");
                // A reading problem said before, then cleared with nothing else to say.
                var cs=Commented("AT 11","30INV",new List<bool?>());cs.Verdict=WholesaleRules.Decide(cs);
                string ct=WholesaleDiscord.Cleared(cs,true);
                Check(ct=="**DRY RUN** · Order WO9000001 (BUFRIV): can be read now · skipped: its Comment or Ship Via changed (the wholesale helper shows why)"&&!ct.Contains("AT 11"),"Cleared, skipped: no staff's words ("+ct+").");
                var cl=Commented("WWW [stock]","30INV",new List<bool?>(),Tyre(1,2));cl.Retry=true;cl.Verdict=WholesaleRules.Decide(cl);
                Check(cl.Verdict.Action=="leave"&&WholesaleDiscord.Cleared(cl,true).EndsWith("its Comment already shows **[stock]**",StringComparison.Ordinal),"Cleared, nothing to change.");
                Check(WholesaleDiscord.Cleared(p,true)==null&&WholesaleDiscord.Cleared(s,true)==null&&WholesaleDiscord.Cleared(lk,true)==null,"Still a problem, a sale, or locked: not a clearing.");
                Check(WholesaleDiscord.DroppedText("WO7","its Comment is staff's now (left for staff)",true)=="**DRY RUN** · Order WO7: no longer followed: its Comment is staff's now (left for staff)","Let go: said.");
                Check(WholesaleDiscord.MessageId("{\"id\":\"1234567890123456789\",\"type\":0,\"content\":\"x\"}")=="1234567890123456789"&&WholesaleDiscord.MessageId("{}")==null&&WholesaleDiscord.MessageId("not json")==null&&WholesaleDiscord.MessageId(null)==null,"A posted message's id.");
                Check(WholesaleDiscord.MessageId("{\"type\":0,\"channel_id\":\"3333333333333333333\",\"author\":{\"id\":\"1111111111111111111\",\"bot\":true},\"id\":\"2222222222222222222\",\"webhook_id\":\"1111111111111111111\"}")=="2222222222222222222","The message's own id, wherever it comes (not its author's or channel's).");
                Check(WholesaleDiscord.Clean("hi @everyone\r\nline")=="hi (at)everyone\nline"&&WholesaleDiscord.Clean(new string('x',2000)).Length==1903,"No mentions, one line break kept, 1,900 letters at most.");
            });
            Case("Wholesale (2.9.0): \"Orders yet to be filled\" read from a made-up list",()=>{
                string[] cols={"Order Date","ShipDate","Document #","Name","Comment","Phone","Written By","PO","PO Total","Ship Via","Source"};
                Func<string[],Node> row=delegate(string[] v) { var r=new Node(28,"row");for(int i=0;i<cols.Length;i++) r.Add(new Node(29,cols[i],v[i]));return r; };
                var head=new Node(28,"headings");foreach(var c in cols) head.Add(new Node(25,c));
                var table=new Node(24,"Table").Add(head,
                    row(new[]{"01/11/2026","03/11/2026","WO9000002","TEST CUSTOMER TWO","WWW","0400000002","WWW","TWW1","200.00","BUFRIV","MDX"}),
                    row(new[]{"30/10/2026","30/10/2026","WO9000001","TEST CUSTOMER","","0400000001","Web","","100.00","BUFF","Web Order"}),
                    row(new[]{"30/10/2026","","OR9000003","TEST CUSTOMER THREE","B/O","","TV","","","DXTDUB",""}),
                    row(new[]{"30/10/2026","30/10/2026","WO9000001","TEST CUSTOMER","","0400000001","Web","","100.00","BUFF","Web Order"}));
                var client=new Node(10,"ultraGrid1").Add(table);
                var rows=WholesaleList.Read(()=>client);
                Check(rows.Count==3,"Three orders (one listed twice): "+rows.Count);
                var a=rows.First(r=>r.Doc=="WO9000002");
                Check(a.OrderDate=="01/11/2026"&&a.ShipDate=="03/11/2026"&&a.Comment=="WWW"&&a.ShipVia=="BUFRIV"&&a.Name=="TEST CUSTOMER TWO"&&a.Po=="TWW1"&&a.PoTotal=="200.00"&&a.Source=="MDX"&&a.By=="WWW","The cells by their columns.");
                var hidden=new Node(10,"ultraGrid1").Add(new Node(24,"Table").Add(new Node(28,"row").Add(new Node(29,"Document #","WO1"),new Node(29,"Order Date","01/11/2026"),new Node(29,"ShipDate",""),new Node(29,"Comment",""),new Node(29,"Ship Via","HIDDEN",null,0x8000),new Node(29,"Ship Via","BUFRIV"),new Node(29,"ShipVia","OTHER"))));
                var shownVia=WholesaleList.Read(()=>hidden);
                Check(shownVia.Count==1&&shownVia[0].ShipVia=="BUFRIV","The shown Ship Via cell, by its exact name: "+(shownVia.Count>0?shownVia[0].ShipVia:"none"));
                var noVia=new Node(10,"ultraGrid1").Add(new Node(24,"Table").Add(new Node(28,"row").Add(new Node(29,"Document #","WO1"),new Node(29,"Order Date","01/11/2026"),new Node(29,"ShipDate",""),new Node(29,"Comment",""))));
                string error=null;try { WholesaleList.Read(()=>noVia); } catch(InvalidOperationException e) { error=e.Message; }
                Check(error!=null&&error.Contains("Ship Via"),"A list without its Ship Via column stops: "+error);
            });
            Case("Wholesale (2.9.8): the approaches and their timers; 2.9.10: all four by number unless another is picked",()=>{
                Check(WholesaleSpeed.Keys.Length==8&&WholesaleSpeed.Keys[0]=="baseline","Eight approaches, the 2.9.7 one first (Back to 2.9.7 picks it).");
                foreach(var k in WholesaleSpeed.Keys) Check(WholesaleSpeed.Preset(k).key==k&&WholesaleSpeed.NameOf(k).Length>0,"Approach "+k+" kept by its key.");
                var b=WholesaleSpeed.Preset("baseline");
                Check(!b.directRow&&!b.readyChecks&&!b.leanList&&!b.shortTimers&&!b.byNumber&&!b.bufFilter,"The baseline changes nothing.");
                Check(b.AfterMs==1500&&b.BoxStillMs==150&&b.SettleMs==200&&b.HoldMs==300&&WholesaleSpeed.AfterOpenMs==1500,"The baseline's waits are 2.9.7's: 1.5 s quiet, 150 ms still, 200 ms between stock reads, 300 ms held.");
                Check(WholesaleSpeed.Preset("ready").AfterMs==0&&WholesaleSpeed.Preset("ready").BoxStillMs==150,"Ready checks: no 1.5 s quiet after a click or once the order is read (the timers as before).");
                var t=WholesaleSpeed.Preset("timers");Check(t.BoxStillMs==80&&t.SettleMs==100&&t.HoldMs==150&&t.AfterMs==1500,"Shorter timers: 80, 100 and 150 ms (the quiet waits as before).");
                var all=WholesaleSpeed.Preset("all");Check(all.directRow&&all.readyChecks&&all.leanList&&all.shortTimers&&!all.byNumber&&!all.bufFilter,"All four together.");
                var num=WholesaleSpeed.Preset("all-number");Check(num.byNumber&&!num.directRow&&num.readyChecks&&num.leanList&&num.shortTimers&&!num.bufFilter,"Search by number in place of the known place.");
                var buf=WholesaleSpeed.Preset("all-buf");Check(buf.bufFilter&&buf.directRow&&buf.readyChecks&&buf.leanList&&buf.shortTimers&&!buf.byNumber,"All four with the list filtered to BUF.");
                foreach(var k in new[]{"direct","ready","lean","timers"}) { var p=WholesaleSpeed.Preset(k);Check((p.directRow?1:0)+(p.readyChecks?1:0)+(p.leanList?1:0)+(p.shortTimers?1:0)==1&&!p.byNumber&&!p.bufFilter,"Approach "+k+": one improvement on its own."); }
                Check(WholesaleSpeed.Preset("fastest").key=="baseline"&&WholesaleSpeed.Preset(null).key=="baseline"&&WholesaleSpeed.Baseline().key=="baseline","Anything unknown: the 2.9.7 approach.");
                Check(WholesaleSpeed.NameOf("baseline").Contains("2.9.7")&&WholesaleSpeed.NameOf("nonsense")==WholesaleSpeed.NameOf("baseline"),"The baseline named as 2.9.7's.");
                // 2.9.10: all four by number unless another is picked; a 2.9.7 file (no approach) is read as that, and set so once (Adopt).
                var old=Wire.Read<WholesaleSettings>("{\"loop\":true,\"autoUpdateTried\":\"\"}");
                Check(new WholesaleSettings().approach=="all-number"&&old.approach=="all-number"&&old.approachSet==""&&WholesaleSettingsFile.Adopt(old)&&!WholesaleSettingsFile.Adopt(old)&&old.approach=="all-number","A 2.9.7 settings file: all four, search by order number, set once.");
                var picked=new WholesaleSettings {approach="direct",approachSet=WholesaleSettingsFile.AdoptedIn};Check(!WholesaleSettingsFile.Adopt(picked)&&picked.approach=="direct","A choice made after it: kept.");
                Check(Wire.Read<WholesaleSettings>(Wire.Json(new WholesaleSettings {approach="all"})).approach=="all","The approach kept across restarts.");
                Check(WholesaleTimes.S(-1)=="-"&&WholesaleTimes.S(1234)=="1.2"&&WholesaleTimes.S(0)=="0.0","Seconds to a tenth.");
                var x=new WholesaleTimes {search=500,find=1500,open=1800,notes=1600,read=300,stock=2400,verify=900,close=700,total=9000,scans=1,rows=5,hinted=true,lines=2,settleReads=4,popups=1,firstPopupMs=1200};
                string line=x.Line("WO9000001");
                Check(line.StartsWith("WO9000001: find 2.0 s (searched by number, 1 list read of 5 rows, at its known place)",StringComparison.Ordinal)&&line.Contains("open 1.8")&&line.Contains("notes 1.6 s (1 answered, the first 1.2 s after it showed)")&&line.Contains("stock 2.4 s (2 lines, 4 reads)")&&line.EndsWith("total 9.0 s",StringComparison.Ordinal),"The day log's line: "+line);
                var pt=new WholesalePassTimes {quiet=100,listing=900,filter=50,search=2100,read=6400,total=60000,rows=351,buf=66,lean=true};
                Check(pt.Refresh==8550&&pt.Line().Contains("351 rows, 66 BUF, needed columns only"),"A pass's list times: "+pt.Line());
            });
            Case("Wholesale (2.9.8): the list read lean (each row's place, the columns needed; read whole when a cell isn't as the row read whole)",()=>{
                string[] cols={"Order Date","ShipDate","Document #","Name","Comment","Phone","Written By","PO","PO Total","Ship Via","Ship Via","Source"};
                Func<int,Node> row=delegate(int n) {
                    bool b=n%3==0;var r=new Node(28,"row");
                    string[] v={"0"+(1+n%9)+"/11/2026",n%4==0?"":"03/11/2026","WO90000"+n.ToString("00",CultureInfo.InvariantCulture),"TEST CUSTOMER "+n,b?"WWW":"B/O","0400000000","WWW","","",n%5==0?"HIDDEN":"",b?"BUFRIV":"DXTDUB","Web"};
                    for(int i=0;i<cols.Length;i++) r.Add(new Node(29,cols[i],v[i],"",i==9?0x8000:0));
                    return r;
                };
                Func<int,Node> list=delegate(int count) {
                    var head=new Node(28,"headings");foreach(var c in cols) head.Add(new Node(25,c));
                    var table=new Node(24,"Table").Add(head);for(int n=1;n<=count;n++) table.Add(row(n));
                    table.Add(row(3));   // the active row listed twice
                    return new Node(10,"ultraGrid1").Add(table);
                };
                var client=list(25);
                var whole=WholesaleList.Read(()=>client);var lean=WholesaleList.ReadLean(()=>client);
                Check(lean!=null&&lean.Count==25&&whole.Count==25,"Every order read, one listed twice once: "+(lean==null?"null":lean.Count.ToString(CultureInfo.InvariantCulture)));
                for(int i=0;i<whole.Count;i++) {
                    var a=whole[i];var l=lean[i];
                    Check(a.Doc==l.Doc&&a.Pos==l.Pos&&a.ShipVia==l.ShipVia,"Row "+a.Doc+": the same number, place and Ship Via (the shown one).");
                    bool isBuf=WholesaleRules.ShipViaBuf(a.ShipVia);
                    Check(!isBuf||(a.OrderDate==l.OrderDate&&a.ShipDate==l.ShipDate&&a.Comment==l.Comment),"BUF row "+a.Doc+": its dates and Comment too.");
                    Check(isBuf||(l.Comment==""&&l.OrderDate==""),"Another row's other columns aren't read: "+a.Doc);
                }
                Check(whole[0].Pos==2&&whole[0].Doc=="WO9000001"&&whole[24].Pos==26,"Places among the list's children (the headings first): "+whole[0].Pos+", "+whole[24].Pos);
                Check(whole.All(r=>r.ShipVia!="HIDDEN"),"The hidden Ship Via cell isn't the one read.");
                // A cell that can't be taken on its own on a row the lean read doesn't check whole: read whole after all.
                var broken=list(25);((Node)broken.Kids[0].Kids[5]).EmptyChild=11;
                Check(WholesaleList.ReadLean(()=>broken)==null,"A cell not taken on its own: null (the list is read whole).");
                Func<Node> swapped=delegate { var x=list(25);((Node)x.Kids[0].Kids[1]).Later=new Dictionary<int,int>{{11,10}};return x; };
                var sw1=swapped();var sw2=swapped();
                Check(WholesaleList.Read(()=>sw1).Count==25&&WholesaleList.ReadLean(()=>sw2)==null,"A cell taken on its own showing another cell of the same name (the hidden Ship Via): not as the row read whole, null.");
                var renamed=list(25);((Node)renamed.Kids[0].Kids[6]).Kids[10]=new Node(29,"Comment","BUFRIV");
                Check(WholesaleList.ReadLean(()=>renamed)==null,"A BUF row's Ship Via cell named otherwise: null.");
                var comment=list(25);((Node)comment.Kids[0].Kids[9]).Kids[4]=new Node(29,"Name","WWW");
                Check(WholesaleList.Read(()=>list(25)).First(x=>x.Doc=="WO9000009").Comment=="WWW"&&WholesaleList.ReadLean(()=>comment)==null,"A BUF row's Comment cell named otherwise (a row checked by names only): null.");
                // Something in the list that isn't a row (before the rows): the places still count every child (as COSTAR's
                // list gives them out one by one, for finding a row at its place).
                var extra=list(5);extra.Kids[0].Kids.Insert(0,new Node(3,"scroll bar"));
                var withExtra=WholesaleList.Read(()=>extra);var leanExtra=WholesaleList.ReadLean(()=>extra);
                Check(withExtra[0].Pos==3&&leanExtra!=null&&leanExtra[0].Pos==3&&withExtra[4].Pos==7,"Places count every child: "+withExtra[0].Pos);
                var hidden=new Node(10,"ultraGrid1").Add(new Node(24,"Table").Add(new Node(28,"row").Add(new Node(29,"Document #","WO1"),new Node(29,"Order Date","01/11/2026"),new Node(29,"ShipDate",""),new Node(29,"Comment","WWW"),new Node(29,"Ship Via","HIDDEN",null,0x8000),new Node(29,"Ship Via","BUFRIV"))));
                var one=WholesaleList.ReadLean(()=>hidden);
                Check(one!=null&&one.Count==1&&one[0].ShipVia=="BUFRIV"&&one[0].Comment=="WWW"&&one[0].Pos==1,"One row: the shown Ship Via, its Comment, place 1.");
                var noVia=new Node(10,"ultraGrid1").Add(new Node(24,"Table").Add(new Node(28,"row").Add(new Node(29,"Document #","WO1"),new Node(29,"Order Date","01/11/2026"),new Node(29,"ShipDate",""),new Node(29,"Comment",""))));
                string error=null;try { WholesaleList.ReadLean(()=>noVia); } catch(InvalidOperationException e) { error=e.Message; }
                Check(error!=null&&error.Contains("Ship Via"),"No Ship Via column: stops as the whole read does: "+error);
            });
            Case("Wholesale (2.9.8): an order's row found at its known place (or a place or two off); not there: the list is read whole",()=>{
                string[] cols={"Order Date","Document #","Name","Ship Via"};
                var head=new Node(28,"headings");foreach(var c in cols) head.Add(new Node(25,c));
                var table=new Node(24,"Table").Add(head);
                for(int n=1;n<=12;n++) { var r=new Node(28,"row","",n==6?"":"Activate");foreach(var c in cols) r.Add(new Node(29,c,c=="Document #"?"WO900000"+n.ToString("00",CultureInfo.InvariantCulture):"X"));table.Add(r); }
                var client=new Node(10,"ultraGrid1").Add(table);
                var box=new Native.Rect {Left=0,Top=0,Right=1000,Bottom=1000};
                Func<Accessibility.IAccessible> root=()=>client;
                // WO90000005 is the 6th child (the headings first).
                using(var s=WipScan.FromHint(root,box,"WO90000005",6)) {
                    Check(s!=null&&s.Hinted&&s.OneCell&&s.TargetLine.Doc=="WO90000005"&&s.TargetLine.Pos==6,"Found at its place.");
                    Check(s.Lines.Count==5&&s.Lines.Select(x=>x.Pos).SequenceEqual(new[]{4,5,6,7,8}),"With two rows either side: "+String.Join(",",s.Lines.Select(x=>x.Pos.ToString(CultureInfo.InvariantCulture)).ToArray()));
                    var listed=s.TargetRow();Check(listed!=null&&listed.doc=="WO90000005"&&listed.shipVia=="X","Its row's cells by their columns.");
                }
                using(var s=WipScan.FromHint(root,box,"WO90000005",7)) Check(s!=null&&s.TargetLine.Pos==6,"A place off (the list holding a row twice above it): found.");
                using(var s=WipScan.FromHint(root,box,"WO90000005",4)) Check(s!=null&&s.TargetLine.Pos==6,"Two places off: found.");
                Check(WipScan.FromHint(root,box,"WO90000005",10)==null,"Further off: not there (read whole).");
                Check(WipScan.FromHint(root,box,"WO90000099",6)==null,"Another order there: not there.");
                Check(WipScan.FromHint(root,box,"WO90000005",0)==null&&WipScan.FromHint(root,box,"WO90000005",99)==null,"No place, or past the list's end: not there.");
                using(var s=WipScan.FromHint(root,box,"WO90000001",1)) Check(s!=null&&s.TargetLine.Pos==2&&s.Lines.All(x=>x.Doc.StartsWith("WO",StringComparison.Ordinal)),"The headings at the place: the next row's columns, the row a place on.");
                var twice=new Node(10,"ultraGrid1").Add(new Node(24,"Table").Add(head));
                for(int n=1;n<=6;n++) { var r=new Node(28,"row");foreach(var c in cols) r.Add(new Node(29,c,c=="Document #"?(n==4?"WO90000003":"WO900000"+n.ToString("00",CultureInfo.InvariantCulture)):"X"));twice.Kids[0].Add(r); }
                using(var s=WipScan.FromHint(()=>twice,box,"WO90000003",4)) Check(s!=null&&s.TargetLine.Pos==4&&s.Lines.Count(x=>x.Doc=="WO90000003")==1,"The same order twice nearby: the one at its place only.");
                var renamed=new Node(10,"ultraGrid1").Add(new Node(24,"Table").Add(head));
                for(int n=1;n<=6;n++) { var r=new Node(28,"row");foreach(var c in cols) r.Add(new Node(29,c=="Document #"&&n==3?"Doc":c,c=="Document #"?"WO900000"+n.ToString("00",CultureInfo.InvariantCulture):"X"));renamed.Kids[0].Add(r); }
                Check(WipScan.FromHint(()=>renamed,box,"WO90000003",4)==null,"Its cell not named Document #: not taken.");
                var times=new RoOpenTimes {Hint=6,Hinted=true,ScanMs=200,Scans=1,Rows=5,OneCell=true,How="made the active row directly",RevealMs=900,WindowMs=1700,TotalMs=3000,Direct=true};
                Check(times.ToString().Contains("found at its known place")&&!times.ToString().Contains("read in full after all"),"The open's times say so: "+times);
                times.Hinted=false;times.Fallbacks=1;
                Check(times.ToString().Contains("not at its known place, read in full after all 1 time"),"And when it wasn't: "+times);
            });
            Case("Wholesale (2.9.8): the list's search boxes found by their labels; the run's own BUF filter told apart",()=>{
                Func<string,int,int,WholesaleSearchBox.Part> part=delegate(string text,int x,int y) { return new WholesaleSearchBox.Part {Text=text,Rect=new Native.Rect {Left=x,Top=y,Right=x+(text==null?160:120),Bottom=y+16},Handle=new IntPtr(1000+y)}; };
                string[] names={"Name/Contact","Document #","Cust PO #","Phone","Order Date","Written By","Comment / Ship Via","Source"};
                var labels=new List<WholesaleSearchBox.Part>();var boxes=new List<WholesaleSearchBox.Part>();
                for(int k=0;k<names.Length;k++) { labels.Add(part(names[k],300,108+18*k));boxes.Add(part(null,434,107+18*k)); }
                Check(WholesaleSearchBox.Pick(labels,boxes,WholesaleSearchBox.DocumentLabel)==new IntPtr(1000+125),"Document #'s box.");
                Check(WholesaleSearchBox.Pick(labels,boxes,WholesaleSearchBox.CommentLabel)==new IntPtr(1000+215),"Comment / Ship Via's box.");
                Check(WholesaleSearchBox.Pick(labels,boxes,"INVOICE")==IntPtr.Zero,"No such label: none.");
                labels.Add(part("Document #",300,252));boxes.Add(part(null,434,251));
                Check(WholesaleSearchBox.Pick(labels,boxes,WholesaleSearchBox.DocumentLabel)==IntPtr.Zero,"Two boxes with that label: none (nothing is typed).");
                var right=new List<WholesaleSearchBox.Part>{part("Document #",600,108)};var box=new List<WholesaleSearchBox.Part>{part(null,434,107)};
                Check(WholesaleSearchBox.Pick(right,box,WholesaleSearchBox.DocumentLabel)==IntPtr.Zero,"A label right of the box isn't its label.");
                Check(WholesaleSearchBox.Letters("Comment / Ship Via")=="COMMENTSHIPVIA"&&WholesaleSearchBox.Letters("Document #")=="DOCUMENT","Labels by their letters.");
                Check(WholesaleSearchBox.OnlyBuf("Comment / Ship Via = BUF")&&WholesaleSearchBox.OnlyBuf("Comment / Ship Via = buf ")&&WholesaleSearchBox.OnlyBuf("Comment/Ship Via = BUF"),"The run's own BUF filter.");
                foreach(var f in new[]{"Comment / Ship Via = BUFF","Comment / Ship Via = BUF, Document # = WO1","Document # = BUF","Name/Contact = BUF","Comment / Ship Via = WWW","",null}) Check(!WholesaleSearchBox.OnlyBuf(f),"Not the run's own BUF filter: \""+f+"\" (cleared as before).");
            });
            Case("Wholesale (2.9.8): the speed test's orders, its results compared with the baseline's, and its report",()=>{
                string today="2026-11-15";
                var rows=new List<WholesaleRow>();
                for(int n=1;n<=24;n++) rows.Add(new WholesaleRow {Doc="WO90000"+n.ToString("00",CultureInfo.InvariantCulture),OrderDate="10/11/2026",ShipDate="",ShipVia=n%2==0?"BUFRIV":"DXTDUB",Comment=n==4?"AT 11":"WWW",Pos=n+1});
                var picked=SpeedResults.Choose(rows,today,4,new[]{"wo9000016","WO9000003","WO9000004"});
                Check(picked.Count==4&&picked.Contains("WO9000016")&&!picked.Contains("WO9000003")&&!picked.Contains("WO9000004"),"Asked for first (a BUF order to open: not a non-BUF one or one with staff's Comment): "+String.Join(",",picked.ToArray()));
                Check(picked.SequenceEqual(picked.OrderBy(d=>rows.First(w=>w.Doc==d).Pos)),"In the list's order.");
                var spread=SpeedResults.Choose(rows,today,3,null);
                Check(spread.SequenceEqual(new[]{"WO9000002","WO9000010","WO9000018"}),"Spread from the top of the list down: "+String.Join(",",spread.ToArray()));
                Check(SpeedResults.Choose(rows,today,40,null).Count==11,"Never more than the orders a pass would open (11 here).");
                // A look's result: numbers only.
                var l=new WholesaleLook {Row=rows[1],Opened=true,Terms="CASH",OrderComment="WWW"};
                l.Lines.Add(new WholesaleLine {Number=1,Item="2055516",Kind="tyre",Tyre=true,Available=2});l.Lines.Add(new WholesaleLine {Number=2,Item="WHEEL1",Kind="wheel"});
                l.Lines.Add(new WholesaleLine {Number=3,Item="FREIGHT",Kind="freight"});l.Lines.Add(new WholesaleLine {Number=4,Item="KIT",Kind="unsure"});l.Lines.Add(new WholesaleLine {Number=5,Note=true,Item="NOTE"});
                l.NotesRead.Add(false);l.Memos.Add("Point-of-sale Memo: x");
                var v=new WholesaleVerdict {Action="flag"};v.Tags.Add("stock");v.Tags.Add("review");l.Verdict=v;
                var o=SpeedResults.From(l);
                Check(o.outcome=="flag"&&o.tags=="[stock] [review]"&&o.stock=="1:2"&&o.tyres==1&&o.wheels==1&&o.others==1&&o.unsure==1&&o.notes==1&&o.memos==1&&o.fp.Length==12,"What was found, as numbers: "+Wire.Json(o));
                string json=Wire.Json(o);Check(!json.Contains("WWW")&&!json.Contains("CASH")&&!json.Contains("Memo")&&!json.Contains("TEST"),"No words of the order or its customer kept.");
                var unread=new WholesaleLook {Row=rows[1],Opened=true,Terms="CASH",OrderComment="WWW CALLED JOHN"};unread.Lines.AddRange(l.Lines);
                string json2=Wire.Json(SpeedResults.From(unread));Check(!json2.Contains("JOHN")&&!json2.Contains("CASH")&&json2.Contains("\"outcome\":\"stopped\""),"Read but stopped before a verdict: still no words kept.");
                Check(SpeedResults.From(new WholesaleLook {Row=rows[1],Skip="no longer on COSTAR's list (filled, or changed since the list was read)"}).outcome=="not listed"&&SpeedResults.From(new WholesaleLook {Row=rows[1],Locked=true}).outcome=="locked"&&SpeedResults.From(new WholesaleLook {Row=rows[1],LeftOpen="unchanged"}).outcome=="left open"&&SpeedResults.From(new WholesaleLook {Row=rows[1],Opened=true}).outcome=="stopped","Not read: why.");
                // 2.9.10: compared with the reference 2.9.7 pass (r) and the other one (other).
                Func<string,string,string,SpeedOrderResult> r=delegate(string outcome,string stock,string fp) { return new SpeedOrderResult {doc="WO1",outcome=outcome,tags=outcome=="flag"?"[stock]":"",stock=stock,fp=fp,tyres=1}; };
                var b1=r("sell","1:6","A");
                Check(SpeedReport.Compare(r("sell","1:6","A"),b1,r("sell","1:6","A"))=="match","The same read: a match.");
                Check(SpeedReport.Compare(r("flag","1:2","A"),b1,r("sell","1:6","A"))=="difference","Read otherwise while both 2.9.7 passes agree: a difference (not reliable).");
                Check(SpeedReport.Compare(r("flag","1:2","A"),b1,r("flag","1:2","A"))=="match","As the other 2.9.7 pass read it (stock sold meanwhile): a match.");
                Check(SpeedReport.Compare(r("flag","1:3","A"),b1,r("flag","1:2","A"))=="changed","The 2.9.7 passes differ (COSTAR changed meanwhile): explained.");
                Check(SpeedReport.Compare(r("flag","1:2","A"),b1,null)=="difference"&&SpeedReport.Compare(r("flag","1:6","B"),b1,null)=="difference","With one 2.9.7 pass, any difference stays a difference (it can't be put down to COSTAR).");
                Check(SpeedReport.Compare(r("sell","1:?","A"),b1,null)=="unread"&&SpeedReport.Compare(r("leave","1:?","A"),b1,r("sell","1:6","A"))=="unread","A stock figure not read is unread, never a stock change.");
                var problem=r("leave","1:6","A");problem.problems=1;Check(SpeedReport.Compare(problem,b1,null)=="unread","More reading problems than the reference: unread.");
                Check(SpeedReport.Compare(r("locked","",""),b1,r("sell","1:6","A"))=="changed"&&SpeedReport.Compare(r("not listed","",""),b1,r("not listed","",""))=="changed","Open on another PC, or gone for the other 2.9.7 pass too: explained.");
                Check(SpeedReport.Compare(r("not listed","",""),b1,r("sell","1:6","A"))=="missing"&&SpeedReport.Compare(r("not listed","",""),b1,null)=="not listed","Not listed while 2.9.7 listed it before and after: missing; with one 2.9.7 pass: not listed (can't tell).");
                Check(SpeedReport.Compare(null,b1,null)=="not reached"&&SpeedReport.Compare(r("not reached","",""),b1,null)=="not reached"&&SpeedReport.Compare(r("stopped","",""),b1,null)=="unread"&&SpeedReport.Compare(r("left open","",""),b1,null)=="unread","Not reached; cut short by a stop: unread.");
                Check(SpeedReport.Compare(r("sell","1:6","A"),r("not listed","",""),null)=="","Not read by the reference: not compared.");
                Check(SpeedReport.Median(new List<long>{5,1,3})==3&&SpeedReport.Median(new List<long>{4,1,3,2})==2&&SpeedReport.Median(new List<long>())==-1,"Medians.");
                Check(SpeedResults.Missed(new List<HashSet<string>>{new HashSet<string>{"A","B","C"},null,new HashSet<string>{"A","B","D"}},new List<HashSet<string>>{null,new HashSet<string>{"A"},null},1)==1,"The BUF filter's missed order: listed whole before and after it, not filtered in.");
                Check(SpeedResults.Missed(new List<HashSet<string>>{new HashSet<string>{"A"},null},new List<HashSet<string>>{null,new HashSet<string>{"A"}},1)==-1,"No whole list after it: not checked.");
                // A made-up test: all four fastest and reliable; the BUF filter faster but missing an order; the number search reading one differently.
                Func<string,long[],SpeedArmResult> arm=delegate(string key,long[] ms) {
                    var a=new SpeedArmResult {key=key,name=WholesaleSpeed.NameOf(key),durationMs=ms.Sum()+30000};a.list.read=key=="baseline"?30000:8000;a.list.complete=true;
                    for(int i=0;i<ms.Length;i++) a.orders.Add(new SpeedOrderResult {doc="WO"+i,outcome="sell",stock="1:6",fp="F"+i,tyres=1,times=new WholesaleTimes {total=ms[i],find=ms[i]/4,open=1700,close=600}});
                    return a;
                };
                Action<SpeedArmResult,string> test=delegate(SpeedArmResult a,string kind) { a.orders.Add(new SpeedOrderResult {doc=kind=="wrong place"?"WO0":kind=="not on the list"?"ZZ0000000":"WO99",extra=kind,outcome=kind=="wrong place"?"sell":kind=="not on the list"?"not listed":"not opened",stock=kind=="wrong place"?"1:6":"",fp=kind=="wrong place"?"F0":"",tyres=kind=="wrong place"?1:0,times=new WholesaleTimes {total=kind=="wrong place"?25000:1000,fallbacks=kind=="wrong place"?1:0}}); };
                var f=new SpeedTestFile {version="2.9.10",started="2026-11-15 09:00",finished="09:40",listed=351,buf=66,eligible=30,approach="all-number"};
                f.plan.AddRange(WholesaleSpeedTest.Plan);f.sample.AddRange(new[]{"WO0","WO1","WO2"});
                f.arms.Add(arm("baseline",new long[]{19000,18000,20000}));
                var number=arm("all-number",new long[]{10000,9000,11000});number.orders[1].outcome="flag";number.orders[1].tags="[stock]";test(number,"not on the list");test(number,"not eligible");f.arms.Add(number);
                var filtered=arm("all-buf",new long[]{9000,8000,10000});filtered.list.filtered=true;filtered.missedBuf=1;f.arms.Add(filtered);
                var all=arm("all",new long[]{12000,11000,13000});test(all,"wrong place");test(all,"not on the list");all.testsMs=26000;f.arms.Add(all);
                var direct=arm("direct",new long[]{15000,14000,16000});test(direct,"wrong place");f.arms.Add(direct);
                f.arms.Add(arm("ready",new long[]{16000,15000,17000}));f.arms.Add(arm("lean",new long[]{19000,18000,20000}));f.arms.Add(arm("timers",new long[]{18000,17500,19000}));
                var again=arm("baseline",new long[]{19500,18500,20500});again.name+=" (again)";f.arms.Add(again);
                Check(SpeedReport.MedianMs(all)==12000&&SpeedReport.WholeMs(all)==all.durationMs-26000,"The planned tests beside the orders aren't counted.");
                Check(SpeedReport.Verdict(all,f)=="reliable"&&SpeedReport.Verdict(number,f)=="NOT reliable"&&SpeedReport.Verdict(filtered,f)=="NOT reliable"&&SpeedReport.Verdict(direct,f)=="reliable","Reliable: the same reads, the planned tests passed (and, filtered, every BUF order shown).");
                Check(SpeedReport.Best(f)=="all","The best-supported: all four (the faster two weren't reliable): "+SpeedReport.Best(f));
                string text=SpeedReport.Text(f);
                Check(text.Contains("Best-supported by this test: All four improvements: 12.0 s an order (2.9.7: 19.0 s)")&&text.Contains("save 8.0 s an order between them; all four together 7.0 s (they overlap")&&text.Contains("The BUF filter MISSED 1 BUF order")&&text.Contains("WO1: read differently with nothing to show COSTAR changed")&&text.Contains("NOT RELIABLE"),"The report says what was best-supported and what wasn't reliable:\n"+text);
                Check(text.Contains("Reference: the first 2.9.7 pass; the last 2.9.7 pass too")&&text.Contains("Approach checking used as the test began: All four, search by order number: 10.0 s an order here; NOT reliable in this test."),"The reference and the approach in use said:\n"+text);
                Check(text.Contains("A row looked for at a deliberately wrong place (a test of the fallback to reading the list in full; it doesn't reproduce an order leaving the list after Sell, then Cancel): All four improvements: passed; Find the row directly: passed.")&&text.Contains("A made-up order number (not on the list: nothing must be opened): All four, search by order number: passed; All four improvements: passed.")&&text.Contains("searched for by its number (it must be skipped, nothing opened): All four, search by order number: passed."),"The planned tests, labelled:\n"+text);
                Check(text.Contains("Find the row directly (also in All four and All four, list filtered to BUF) looks for each order where the pass's list read put it")&&text.Contains("confirmed by Tommy, 15 Nov"),"The direct row's limit for live said.");
                Check(text.Contains("Not met in this test: an order open on another PC")&&text.Contains("Back to 2.9.7")&&text.Contains("another Windows login")&&!text.Contains("Not tested (the run ended first)"),"What wasn't met, the way back, what needs another login; nothing untested.");
                Check(text.Contains("COSTAR's speed held steady")&&SpeedReport.BaselineMs(f)==19000,"The 2.9.7 pass again at the end compared; 2.9.7's figure the faster of the two.");
                foreach(var x in again.orders) x.times.total=11500;
                Check(SpeedReport.BaselineMs(f)==11500&&SpeedReport.Best(f)=="baseline"&&SpeedReport.Text(f).Contains("COSTAR's speed changed during the test"),"COSTAR faster by the last pass: nothing beats 2.9.7's faster pass (12.0 s against 11.5 s).");
                foreach(var x in again.orders) x.times.total=19500;
                var wrong=all.orders.First(y=>y.extra=="wrong place");
                wrong.fp="OTHER";Check(SpeedReport.Verdict(all,f)=="NOT reliable"&&SpeedReport.Test(all,wrong)=="FAILED","The wrong-place test reading another order: FAILED, not reliable.");wrong.fp="F0";
                wrong.times.fallbacks=0;Check(SpeedReport.Verdict(all,f)=="NOT reliable","The wrong-place test not read whole: not reliable.");wrong.times.fallbacks=1;
                wrong.outcome="not reached";Check(SpeedReport.Test(all,wrong)=="not reached"&&SpeedReport.Verdict(all,f)=="not confirmed","A planned test not reached: not a failure; the approach not confirmed.");wrong.outcome="sell";
                foreach(var a in f.arms.Where(x=>x.key!="baseline")) foreach(var x in a.orders) x.times.total=25000;
                Check(SpeedReport.Best(f)=="baseline"&&SpeedReport.Text(f).Contains("Best-supported by this test: none faster than 2.9.7 was reliable in it"),"Nothing faster: none best-supported.");
                var stopped=new SpeedTestFile {stopped="Stopped."};Check(SpeedReport.Best(stopped)=="baseline"&&SpeedReport.Text(stopped).Contains("STOPPED")&&SpeedReport.Text(stopped).Contains("Reference: NONE"),"A test stopped before anything ran: no reference, nothing best.");
            });
            Case("Wholesale (2.9.9): the comparison's orders each pass: the eligibility rules again, no previews; its order numbers, settings and summary",()=>{
                string today="2026-11-15";
                var rows=new List<WholesaleRow> {
                    new WholesaleRow {Doc="WO9000011",OrderDate="10/11/2026",ShipVia="BUFRIV",Comment="WWW",Pos=2},
                    new WholesaleRow {Doc="WO9000012",OrderDate="10/11/2026",ShipVia="BUFRIV",Comment="AT 11",Pos=3},
                    new WholesaleRow {Doc="WO9000013",OrderDate="10/11/2026",ShipVia="DXTDUB",Comment="WWW",Pos=4},
                    new WholesaleRow {Doc="WO9000014",OrderDate="10/11/2026",ShipVia="BUFF",Comment="WWW [stock]",Pos=5},
                    new WholesaleRow {Doc="WO9000015",OrderDate="10/11/2026",ShipVia="BUFF",Comment="",ShipDate="20/11/2026",Pos=6},
                    new WholesaleRow {Doc="WO9000016",OrderDate="10/11/2026",ShipVia="BUFF",Comment="BUFFALO",Pos=12},
                    new WholesaleRow {Doc="WO9000017",OrderDate="10/11/2026",ShipVia="BUFF",Comment="WWW [stock] go",Pos=9}};
                var only=new List<string>{"WO9000016","WO9000011","WO9000012","WO9000013","WO9000014","WO9000015","WO9000099","WO9000017"};
                var plan=WholesaleRun.Sample(rows,only,today,true,"ZZ0000000");
                Func<string,WholesaleLook> of=d=>plan.First(x=>x.Row.Doc==d&&x.Extra==null);
                Check(of("WO9000011").Skip==null&&of("WO9000016").Skip==null&&of("WO9000017").Skip==null,"Still eligible (new, staff's go): checked again in every pass, whatever was previewed.");
                Check(of("WO9000012").Skip.StartsWith("staff's Comment",StringComparison.Ordinal)&&of("WO9000014").Skip.Contains("waiting for staff's go")&&of("WO9000015").Skip.Contains("after today"),"No longer eligible by its row (staff's Comment, flagged, ShipDate after today): not opened, and why.");
                Check(of("WO9000013").Skip=="its Ship Via isn't BUF any more"&&of("WO9000099").Skip.StartsWith("no longer on COSTAR's list",StringComparison.Ordinal),"Not BUF, or gone from the list: not opened.");
                var opened=plan.Where(x=>x.Skip==null&&x.Extra==null).Select(x=>x.Row.Doc).ToArray();
                Check(opened.SequenceEqual(new[]{"WO9000011","WO9000017","WO9000016"}),"The orders checked in the list's order: "+String.Join(",",opened));
                var wrong=plan.Single(x=>x.Extra=="wrong place");var ghost=plan.Single(x=>x.Extra=="not on the list");
                Check(wrong.Row.Doc=="WO9000011"&&wrong.Row.Pos==12&&ghost.Row.Doc=="ZZ0000000"&&ghost.Row.Pos==2&&plan.Last()==ghost,"The planned tests last: the first looked for at the furthest one's place; the made-up number.");
                Check(WholesaleRun.Sample(rows,only,today,false,null).All(x=>x.Extra==null),"Without the planned tests: none.");
                Check(WholesaleRun.Sample(rows,new List<string>{"WO9000011","WO9000016"},today,true,"WO9000012").All(x=>x.Extra!="not on the list"),"A made-up number that is on the list isn't used.");
                var near=new List<WholesaleRow>{new WholesaleRow {Doc="WO1",ShipVia="BUFF",Comment="WWW",Pos=2},new WholesaleRow {Doc="WO2",ShipVia="BUFF",Comment="WWW",Pos=4}};
                Check(WholesaleRun.Sample(near,new List<string>{"WO1","WO2"},today,true,null).All(x=>x.Extra==null),"The furthest order within 3 places: no wrong-place test (it would be found nearby).");
                Check(SpeedComparisonUi.Numbers(" wo9000011, WO9000012;wo9000011  bad! ").SequenceEqual(new[]{"WO9000011","WO9000012"}),"Orders to include, as typed: "+String.Join(",",SpeedComparisonUi.Numbers(" wo9000011, WO9000012;wo9000011  bad! ").ToArray()));
                Check(SpeedComparisonUi.Numbers(String.Join(" ",Enumerable.Range(10,30).Select(n=>"WO90000"+n).ToArray())).Count==20&&SpeedComparisonUi.Numbers(null).Count==0,"At most 20; nothing typed: none.");
                string note=DiagnosticsBundle.SpeedNote("speed-20261115-091500.txt","WHOLESALE SPEED COMPARISON, 2026-11-15 09:15 to 09:47 (helper 2.9.10).\nOrders: 10\nReference: the first 2.9.7 pass.\n\nBest-supported by this test: All four improvements: 9.8 s an order\nApproach checking used as the test began: All four, search by order number: 10.4 s an order here; reliable in this test.\nNot tested (the run ended first): Shorter stability timers.\nResults: ...",2);
                Check(note.StartsWith("WHOLESALE SPEED COMPARISON (newest of 2 in speed/: speed-20261115-091500.txt)",StringComparison.Ordinal)&&note.Contains("  WHOLESALE SPEED COMPARISON, 2026-11-15")&&note.Contains("  Best-supported by this test: All four")&&note.Contains("  Reference: the first")&&note.Contains("  Approach checking used")&&note.Contains("  Not tested")&&!note.Contains("Orders: 10")&&!note.Contains("Results:"),"The summary's comparison lines: "+note);
                Check(DiagnosticsBundle.SpeedNote("old.txt","WHOLESALE SPEED TEST, 2026-11-15 (helper 2.9.9).\nBEST RELIABLE: All four improvements: 7.4 s",1).Contains("  BEST RELIABLE: All four"),"A 2.9.9 report's best line still carried.");
                Check(DiagnosticsBundle.SpeedNote("x.txt","WHOLESALE SPEED TEST ...\nSTOPPED: Someone used the PC.",1).Contains("  STOPPED: Someone used the PC."),"A stopped comparison says so in the summary.");
                string folder=System.IO.Path.Combine(System.IO.Path.GetTempPath(),"tempe-ws-settings-"+Guid.NewGuid().ToString("N"));System.IO.Directory.CreateDirectory(folder);
                try {
                    string file=System.IO.Path.Combine(folder,"wholesale-tab-settings.json");
                    Check(WholesaleSettingsFile.Load(file).approach=="all-number","No file yet: 2.9.10's approach (all four, search by order number).");
                    WholesaleSettingsFile.Save(file,new WholesaleSettings {approach="all-buf",approachSet=WholesaleSettingsFile.AdoptedIn});WholesaleSettingsFile.Save(file,new WholesaleSettings {approach="all",approachSet=WholesaleSettingsFile.AdoptedIn});
                    Check(WholesaleSettingsFile.Load(file).approach=="all"&&!System.IO.File.Exists(file+".tmp"),"A choice made in 2.9.10: kept, replaced in place.");
                    WholesaleSettingsFile.Save(file,new WholesaleSettings {approach="baseline"});
                    Check(WholesaleSettingsFile.Load(file).approach=="all-number"&&WholesaleSettingsFile.Load(file).approachSet==WholesaleSettingsFile.AdoptedIn,"A 2.9.9 file: all four by number, once, and saved so.");
                    var later=WholesaleSettingsFile.Load(file);later.approach="baseline";WholesaleSettingsFile.Save(file,later);
                    Check(WholesaleSettingsFile.Load(file).approach=="baseline","Back to 2.9.7 after that: kept.");
                    System.IO.File.WriteAllText(file,"{not json");
                    Check(WholesaleSettingsFile.Load(file).approach=="all-number","Unreadable: 2.9.10's approach.");
                } finally { try { System.IO.Directory.Delete(folder,true); } catch(System.IO.IOException) { } catch(UnauthorizedAccessException) { } }
            });
            Case("Wholesale (2.9.10): the report: the reference when the first 2.9.7 pass didn't complete, unread and not reached, what wasn't tested, the sample's cases",()=>{
                Func<string,SpeedArmResult> mk=delegate(string key) { var a=new SpeedArmResult {key=key,name=WholesaleSpeed.NameOf(key)};a.list.complete=true;a.list.read=8000;return a; };
                Func<string,string,string,int,int,int,long,SpeedOrderResult> o=delegate(string doc,string outcome,string stock,int tyres,int wheels,int notes,long ms) {
                    return new SpeedOrderResult {doc=doc,outcome=outcome,stock=stock,fp=outcome=="sell"||outcome=="flag"||outcome=="leave"?"F"+doc:"",tyres=tyres,wheels=wheels,notes=notes,tags=outcome=="flag"?"[review]":"",times=new WholesaleTimes {total=ms}};
                };
                // As on 15 Nov 09:31: the first 2.9.7 pass stopped at its list; every other pass, and the last 2.9.7 pass, through.
                var f=new SpeedTestFile {version="2.9.10",started="2026-11-15 09:31",finished="09:45",listed=354,buf=66,eligible=37,approach="all-number"};
                f.plan.AddRange(WholesaleSpeedTest.Plan);f.sample.AddRange(new[]{"WO1","WO2","WO3"});
                var first=mk("baseline");first.stopped="COSTAR Branch 1 (SYDNEY) isn't showing Orders yet to be filled. Leave it on Orders yet to be filled.";
                first.orders.Add(o("WO1","not listed","",0,0,0,0));first.orders.Add(o("WO2","not reached","",0,0,0,0));first.orders.Add(o("WO3","not reached","",0,0,0,0));
                f.arms.Add(first);
                foreach(var key in WholesaleSpeedTest.Plan.Skip(1)) {
                    var a=mk(key);long ms=key=="baseline"?18000:key=="all-number"?8300:key=="all-buf"?7400:key=="all"?7600:12000;
                    a.orders.Add(o("WO1","sell","1:8",1,0,1,ms));a.orders.Add(o("WO2","flag","1:36,2:4",2,1,0,ms));a.orders.Add(o("WO3","sell","1:38,2:9,3:12",3,0,0,ms));
                    if(key=="all-buf") { a.list.filtered=true;a.missedBuf=0; }
                    foreach(var x in SpeedReport.Planned(key)) a.orders.Add(new SpeedOrderResult {doc=x=="wrong place"?"WO1":x=="not on the list"?"ZZ0000000":"WO9",extra=x,outcome=x=="wrong place"?"sell":x=="not on the list"?"not listed":"not opened",stock=x=="wrong place"?"1:8":"",fp=x=="wrong place"?"FWO1":"",tyres=x=="wrong place"?1:0,notes=x=="wrong place"?1:0,times=new WholesaleTimes {total=9000,fallbacks=x=="wrong place"?1:0}});
                    if(key=="baseline") a.name+=" (again)";
                    f.arms.Add(a);
                }
                var rf=SpeedReport.RefOf(f);
                Check(rf.Arm==f.arms.Last()&&rf.Last&&rf.Other==null&&rf.Note.StartsWith("the LAST 2.9.7 pass, as the first one didn't complete (stopped: COSTAR Branch 1",StringComparison.Ordinal),"The first 2.9.7 pass stopped: the last one is the reference, and said so: "+rf.Note);
                Check(SpeedReport.Best(f)=="all-buf"&&SpeedReport.Verdict(f.arms[1],f)=="reliable","Compared with the last 2.9.7 pass: the fastest reliable is best-supported (2.9.9 said the 2.9.7 approach).");
                string text=SpeedReport.Text(f);
                Check(text.Contains("Reference: the LAST 2.9.7 pass")&&text.Contains("Best-supported by this test: All four, list filtered to BUF: 7.4 s an order (2.9.7: 18.0 s)"),"Said in the report:\n"+text);
                Check(text.Contains("The sample, as the reference read it: 0 with no tyre line, 1 with 1, 1 with 2, 1 with 3 or more; wheels on 1;")&&text.Contains("Notes on 1, a memo on 0"),"The sample's cases from the reference's reads:\n"+text);
                Check(text.Contains("Partly tested: 2.9.7 approach (baseline): 0 of 3 orders read; not reached: WO2, WO3."),"The first pass's orders not reached said:\n"+text);
                // As on 15 Nov 09:52: the first 2.9.7 pass through; all four by number stopped for someone at the PC, an order cut short.
                var g=new SpeedTestFile {version="2.9.10",started="2026-11-15 09:52",finished="10:04",listed=356,buf=66,eligible=37,approach="all-number",stopped="Order WO2 was left open in COSTAR Sydney: close it there, then run the test again."};
                g.plan.AddRange(WholesaleSpeedTest.Plan);g.sample.AddRange(new[]{"WO1","WO2","WO3"});
                var b0=mk("baseline");b0.orders.Add(o("WO1","sell","1:8",1,0,1,18000));b0.orders.Add(o("WO2","sell","1:38",1,0,0,18000));b0.orders.Add(o("WO3","sell","1:127",1,0,0,18000));g.arms.Add(b0);
                var nb=mk("all-number");nb.stopped="Someone used the COSTAR PC: Order # is open in COSTAR Sydney, unchanged: close it there.";
                nb.evidence="Windows' last key or mouse input in this session: 1.8 s before (not the helper's own). What caused the input can't be established from this.";
                nb.orders.Add(o("WO1","sell","1:8",1,0,1,8300));var cut=o("WO2","leave","1:?",1,0,0,8800);cut.problems=1;cut.unread="line 1's stock";nb.orders.Add(cut);
                nb.orders.Add(new SpeedOrderResult {doc="WO3",outcome="not reached",why="not reached"});nb.orders.Add(new SpeedOrderResult {doc="ZZ0000000",extra="not on the list",outcome="not reached"});g.arms.Add(nb);
                var rg=SpeedReport.RefOf(g);
                Check(SpeedReport.Against(nb,b0.orders[1],rg)=="unread"&&SpeedReport.Tally(nb,rg)["difference"]==0&&SpeedReport.Tally(nb,rg)["changed"]==0,"The order cut short, its stock not read: unread, neither a difference nor a change.");
                Check(SpeedReport.Test(nb,nb.orders[3])=="not reached"&&SpeedReport.Verdict(nb,g)=="not confirmed","The made-up number not reached: no failure; the approach not confirmed.");
                string t2=SpeedReport.Text(g);
                Check(t2.Contains("STOPPED: Order WO2 was left open")&&t2.Contains("What was seen at the stop (All four, search by order number): Windows' last key")&&t2.Contains("can't be established"),"The stop and what was seen:\n"+t2);
                Check(t2.Contains("Reference: the first 2.9.7 pass; there's no last 2.9.7 pass (not reached)"),"One 2.9.7 pass, said so:\n"+t2);
                Check(t2.Contains("Not tested (the run ended first): All four, list filtered to BUF; All four improvements; Find the row directly; Ready checks, not 1.5 s waits; Read only the list columns needed; Shorter stability timers; 2.9.7 approach (baseline) (again, at the end)."),"What wasn't tested:\n"+t2);
                Check(t2.Contains("Partly tested: All four, search by order number: 2 of 3 orders read; not reached: WO3; part not read: WO2 (line 1's stock)."),"The orders it didn't reach or read:\n"+t2);
                Check(t2.Contains("A made-up order number (not on the list: nothing must be opened): All four, search by order number: not reached; All four improvements: not reached (the pass didn't run).")&&!t2.Contains("NOT handled"),"Tests not reached, never failures:\n"+t2);
                // The first 2.9.7 pass stopped for COSTAR's list and run again: that try is the reference, said so; the plan's steps counted once.
                var m=new SpeedTestFile {version="2.9.10",started="2026-11-15 13:00",finished="13:20",stopped="Stopped."};m.plan.AddRange(WholesaleSpeedTest.Plan);m.sample.AddRange(new[]{"WO1","WO2"});
                var m0=mk("baseline");m0.stopped="COSTAR Sydney's wholesale list didn't finish loading within 60 s: it showed no table (2 more reads). Nothing was opened.";m0.orders.Add(o("WO1","not reached","",0,0,0,0));m0.orders.Add(o("WO2","not reached","",0,0,0,0));m.arms.Add(m0);
                var m1=mk("baseline");m1.again=true;m1.name+=" (tried again)";m1.orders.Add(o("WO1","sell","1:8",1,0,0,18000));m1.orders.Add(o("WO2","sell","1:38",1,0,0,18000));m.arms.Add(m1);
                var mn=mk("all-number");mn.orders.Add(o("WO1","sell","1:8",1,0,0,8000));mn.orders.Add(o("WO2","sell","1:38",1,0,0,8000));m.arms.Add(mn);
                var rm=SpeedReport.RefOf(m);string tm=SpeedReport.Text(m);
                Check(rm.Arm==m1&&!rm.Last&&rm.Note.StartsWith("the first 2.9.7 pass (run again after it stopped: COSTAR Sydney's wholesale list didn't finish loading",StringComparison.Ordinal),"A first 2.9.7 pass run again: that try is the reference: "+rm.Note);
                Check(tm.Contains("Not tested (the run ended first): All four, list filtered to BUF; All four improvements;")&&tm.Contains("2.9.7 approach (baseline) (tried again): run again after the pass before it stopped for COSTAR's list."),"The pass tried again counted as one step of the plan:\n"+tm);
                // Both 2.9.7 passes through, WO2's stock sold meanwhile: the last one's read is a change in COSTAR; a read like either, a match.
                var k=new SpeedTestFile {version="2.9.10",started="2026-11-15 12:00",finished="12:40"};k.plan.AddRange(new[]{"baseline","all-number","baseline"});k.sample.AddRange(new[]{"WO1","WO2"});
                var k0=mk("baseline");k0.orders.Add(o("WO1","sell","1:8",1,0,0,18000));k0.orders.Add(o("WO2","sell","1:38",1,0,0,18000));k.arms.Add(k0);
                var kn=mk("all-number");kn.orders.Add(o("WO1","sell","1:8",1,0,0,8000));kn.orders.Add(o("WO2","sell","1:36",1,0,0,8000));
                foreach(var x in SpeedReport.Planned("all-number")) kn.orders.Add(new SpeedOrderResult {doc=x=="not on the list"?"ZZ0000000":"WO9",extra=x,outcome=x=="not on the list"?"not listed":"not opened"});k.arms.Add(kn);
                var k1=mk("baseline");k1.name+=" (again)";k1.orders.Add(o("WO1","sell","1:8",1,0,0,18500));k1.orders.Add(o("WO2","sell","1:36",1,0,0,18500));k.arms.Add(k1);
                var rk=SpeedReport.RefOf(k);
                Check(rk.Arm==k0&&rk.Other==k1&&SpeedReport.Tally(k1,rk)["changed"]==1&&SpeedReport.Tally(k1,rk)["difference"]==0&&SpeedReport.Tally(kn,rk)["match"]==2&&SpeedReport.Verdict(kn,k)=="reliable","Stock sold between the 2.9.7 passes: a change in COSTAR, not a difference; the approach reading it as the last pass did: a match.");
                Check(SpeedReport.Text(k).Contains("2.9.7 approach (baseline) (again), WO2: changed in COSTAR meanwhile (the two 2.9.7 passes read it differently)"),"Said so:\n"+SpeedReport.Text(k));
                // No 2.9.7 pass through: nothing compared, nothing best.
                var h=new SpeedTestFile {version="2.9.10",started="2026-11-15 11:00",finished="11:02",stopped="Stopped."};h.plan.AddRange(WholesaleSpeedTest.Plan);h.sample.Add("WO1");
                var hb=mk("baseline");hb.stopped="Stopped.";hb.orders.Add(o("WO1","not reached","",0,0,0,0));h.arms.Add(hb);
                Check(SpeedReport.RefOf(h).Arm==null&&SpeedReport.Best(h)=="baseline"&&SpeedReport.Text(h).Contains("Reference: NONE: no 2.9.7 pass completed"),"No complete 2.9.7 pass: no reference, said so.");
                // A 2.9.7 pass that stopped after reading its orders, or that read none (each gone from the list): no reference either.
                var late=mk("baseline");late.stopped="Someone used the COSTAR PC: Order # is open in COSTAR Sydney, unchanged: close it there.";late.orders.Add(o("WO1","sell","1:8",1,0,0,18000));
                var gone=mk("baseline");gone.orders.Add(o("WO1","not listed","",0,0,0,0));
                Check(SpeedReport.Valid(k0)&&!SpeedReport.Valid(late)&&!SpeedReport.Valid(gone),"Stopped, even with its orders read; nothing read: not complete.");
                var lg=new SpeedTestFile {version="2.9.10",started="2026-11-15 14:00",finished="14:20"};lg.plan.AddRange(new[]{"baseline","all-number","baseline"});lg.sample.Add("WO1");
                lg.arms.Add(late);var ln=mk("all-number");ln.orders.Add(o("WO1","sell","1:8",1,0,0,8000));lg.arms.Add(ln);lg.arms.Add(gone);
                Check(SpeedReport.RefOf(lg).Arm==null&&SpeedReport.RefOf(lg).Note.Contains("first: stopped: Someone used the COSTAR PC")&&SpeedReport.RefOf(lg).Note.Contains("last: no order read"),"Said why: "+SpeedReport.RefOf(lg).Note);
            });
            Case("Wholesale (2.9.10): a broader sample: orders looked at first, the cases they cover, the order kept, a listed order the rules leave alone",()=>{
                Check(SpeedResults.Spread(8).SequenceEqual(new[]{0,4,2,6,1,3,5,7})&&SpeedResults.Spread(1).SequenceEqual(new[]{0})&&SpeedResults.Spread(0).Count==0&&SpeedResults.Spread(5).OrderBy(x=>x).SequenceEqual(Enumerable.Range(0,5)),"Spread over the list, every place once.");
                var open=new List<WholesaleRow>();for(int n=1;n<=12;n++) open.Add(new WholesaleRow {Doc="WO900000"+n.ToString("00",CultureInfo.InvariantCulture),ShipVia="BUFRIV",Comment="WWW",Pos=n+1});
                Func<string,int,int,int,int,int,string,SpeedOrderResult> read=delegate(string doc,int tyres,int wheels,int others,int notes,int memos,string tags) { return new SpeedOrderResult {doc=doc,outcome=tags.Length>0?"flag":"sell",tags=tags,tyres=tyres,wheels=wheels,others=others,notes=notes,memos=memos,stock="1:8",fp="F"}; };
                var known=new Dictionary<string,SpeedOrderResult> {
                    {"WO90000001",read("WO90000001",1,0,0,0,0,"")},{"WO90000002",read("WO90000002",1,0,0,1,0,"")},{"WO90000003",read("WO90000003",2,0,0,0,1,"")},
                    {"WO90000004",read("WO90000004",0,2,0,0,0,"[review]")},{"WO90000005",read("WO90000005",3,0,1,0,0,"[stock]")},{"WO90000006",read("WO90000006",0,0,2,0,0,"[items]")},{"WO90000007",read("WO90000007",1,0,0,0,0,"")}};
                List<string> missing;
                var picked=SpeedResults.Broad(open,new[]{"wo90000012"},known,8,out missing);
                Check(picked.Count==8&&picked.Contains("WO90000012")&&picked.Contains("WO90000004")&&picked.Contains("WO90000005")&&picked.Contains("WO90000003")&&picked.Contains("WO90000006")&&picked.Contains("WO90000002"),"Asked for first, then one for each case (wheels, 3 tyre lines, 2 with a memo, items only, Notes): "+String.Join(",",picked.ToArray()));
                Check(picked.SequenceEqual(picked.OrderBy(d=>open.First(r=>r.Doc==d).Pos)),"In the list's order.");
                Check(missing.Contains("[card]")&&missing.Contains("can't-tell lines")&&!missing.Contains("wheels"),"The cases none of the orders looked at had: "+String.Join(", ",missing.ToArray()));
                Check(SpeedResults.StillMissing(known.Values,8).SequenceEqual(new[]{"[card]","can't-tell lines"}),"Still to find: "+String.Join(", ",SpeedResults.StillMissing(known.Values,8).ToArray()));
                Check(SpeedResults.Broad(open,null,known,3,out missing).Count==3,"Never more than asked for.");
                var five=SpeedResults.Broad(open,new[]{"WO90000012"},known,5,out missing);
                Check(five.SequenceEqual(new[]{"WO90000002","WO90000003","WO90000004","WO90000005","WO90000012"}),"Fewer places than orders looked at: the ones covering most of the cases still missing (Notes; 2 tyre lines, a memo; 3 or more, [stock]; wheels), not just spread: "+String.Join(",",five.ToArray()));
                var none=SpeedResults.Broad(open,null,new Dictionary<string,SpeedOrderResult>(),4,out missing);
                Check(none.Count==4&&missing.Count==SpeedResults.Cases.Length,"Nothing looked at: spread over the list; every case missing.");
                var rows=new List<WholesaleRow>(open);rows.Add(new WholesaleRow {Doc="WO90000020",ShipVia="DXTDUB",Comment="WWW",Pos=20});rows.Add(new WholesaleRow {Doc="WO90000021",ShipVia="BUFF",Comment="AT 11",Pos=21});
                Check(SpeedResults.NotEligible(rows,"2026-11-15",picked)=="WO90000021"&&SpeedResults.NotEligible(rows.Where(r=>r.Doc!="WO90000021").ToList(),"2026-11-15",picked)=="WO90000020"&&SpeedResults.NotEligible(open,"2026-11-15",null)==null,"A BUF order with staff's Comment first, else one not BUF; none: none.");
                var plan=WholesaleRun.Sample(rows,new List<string>{"WO90000005","WO90000001"},"2026-11-15",false,null,true,"WO90000021");
                Check(plan.Where(x=>x.Extra==null&&x.Skip==null).Select(x=>x.Row.Doc).SequenceEqual(new[]{"WO90000005","WO90000001"}),"Kept in the order asked (the look for a broader sample).");
                var ne=plan.Single(x=>x.Extra=="not eligible");Check(ne.Row.Doc=="WO90000021"&&ne.Skip==null&&ne.Queue=="test","The listed order the rules leave alone: planned for the search by number (skipped there).");
                Check(WholesaleRun.Sample(rows,new List<string>{"WO90000005"},"2026-11-15",false,null,false,"WO90000001").All(x=>x.Extra!="not eligible"),"An eligible order is never that test.");
                Check(SpeedResults.SkipKind(WholesaleRun.NotListed)=="not on the list"&&SpeedResults.SkipKind("no longer to be opened as it is listed now: staff's Comment \"CALL JOHN\": left for staff")=="staff's Comment"&&SpeedResults.SkipKind("no longer to be opened as it is listed now: its Ship Via isn't BUF")=="not BUF"&&SpeedResults.SkipKind("ShipDate 20/11/2026 is after today: it waits until then")=="ShipDate after today"&&SpeedResults.SkipKind("flagged [stock]: waiting for staff's go")=="flagged, waiting for staff's go","Skips by kind, no words of the order.");
                var skipped=SpeedResults.From(new WholesaleLook {Row=rows.Last(),Skip="no longer to be opened as it is listed now: staff's Comment \"CALL JOHN\": left for staff"});
                Check(skipped.outcome=="not opened"&&skipped.why=="staff's Comment"&&!Wire.Json(skipped).Contains("JOHN"),"Kept as a kind only: "+Wire.Json(skipped));
                var cutShort=new WholesaleLook {Row=rows[0],Opened=true};cutShort.Lines.Add(new WholesaleLine {Number=2,Item="2055516",Kind="tyre",Tyre=true});var cv=new WholesaleVerdict {Action="leave"};cv.Problems.Add("line 2 (2055516): stock not read");cutShort.Verdict=cv;
                var cr=SpeedResults.From(cutShort);Check(cr.unread=="line 2's stock"&&cr.stock=="2:?"&&cr.problems==1,"What couldn't be read: "+Wire.Json(cr));
            });
            Case("Wholesale (2.9.10): the search by number's checks (the words, the exact number, the rules again), the list's readiness, what was seen at a stop",()=>{
                Check(WholesaleSearchBox.OnlyDocument("")&&WholesaleSearchBox.OnlyDocument("Document # = WO9000001")&&!WholesaleSearchBox.OnlyDocument("Document # = WO9000001, Name/Contact = SMITH")&&!WholesaleSearchBox.OnlyDocument("Name/Contact = SMITH")&&!WholesaleSearchBox.OnlyDocument("Comment / Ship Via = BUF")&&!WholesaleSearchBox.OnlyDocument(null)&&!WholesaleSearchBox.OnlyDocument("Document # = WO9000001, WO9000002"),"Before a search: nothing, or the run's own number alone (a \", \" in the words can't be told from another box's: not taken).");
                Check(WholesaleSearchBox.OnlyNumber("Document # = WO9000001","wo9000001")&&!WholesaleSearchBox.OnlyNumber("Document # = WO90000012","WO9000001")&&!WholesaleSearchBox.OnlyNumber("Document # = WO900000","WO9000001")&&!WholesaleSearchBox.OnlyNumber("","WO9000001")&&!WholesaleSearchBox.OnlyNumber("Document # = WO9000001, Comment / Ship Via = BUF","WO9000001"),"After it: that order's number exactly, alone.");
                var run=new WholesaleRun(null,delegate(string w) { },new WholesaleOptions {Only=new List<string>{"WO9000001"}});
                var planned=new WholesaleLook {Row=new WholesaleRow {Doc="WO9000001",ShipVia="BUFRIV",Comment="WWW",Pos=2},Queue="test"};
                Check(run.StillToOpen(planned,new WholesaleRow {Doc="WO9000001",ShipVia="BUFRIV",Comment="WWW",Pos=1})==null,"Still eligible as listed now: opened.");
                Check(run.StillToOpen(planned,new WholesaleRow {Doc="WO9000001",ShipVia="BUFRIV",Comment="CALL BEFORE",Pos=1}).Contains("staff's Comment")&&run.StillToOpen(planned,new WholesaleRow {Doc="WO9000001",ShipVia="DXTDUB",Comment="WWW",Pos=1}).Contains("isn't BUF")&&run.StillToOpen(planned,new WholesaleRow {Doc="WO9000001",ShipVia="BUFRIV",Comment="WWW",ShipDate="31/12/2099",Pos=1}).Contains("after today"),"Staff's Comment now, not BUF now, a ShipDate after today now: skipped, nothing opened.");
                Check(run.StillToOpen(new WholesaleLook {Row=planned.Row,Extra="not on the list"},new WholesaleRow {Doc="WO9000001",ShipVia="DXTDUB"})==null,"A planned test other than the rules' own: left as planned.");
                Check(run.StillToOpen(new WholesaleLook {Row=planned.Row,Extra="not eligible",Queue="test"},new WholesaleRow {Doc="WO9000001",ShipVia="BUFRIV",Comment="AT 11",Pos=1})!=null,"The test of a listed order the rules leave alone: skipped by the rules themselves.");
                var check=new WholesaleRun(null,delegate(string w) { },new WholesaleOptions());
                var queued=new WholesaleLook {Row=new WholesaleRow {Doc="WO9000002",ShipVia="BUFF",Comment="WWW",OrderDate="10/11/2026",Pos=3},Queue="new"};
                Check(check.StillToOpen(queued,queued.Row)==null&&check.StillToOpen(queued,new WholesaleRow {Doc="WO9000002",ShipVia="BUFF",Comment="WWW [stock]",OrderDate="10/11/2026",Pos=3}).Contains("waiting for staff's go"),"Checking's own rules (its queue): still to open; flagged since: skipped.");
                Check(WholesaleRun.ListCheck(355,355,355,354,354)==null&&WholesaleRun.ListCheck(357,357,357,356,0)==null&&WholesaleRun.ListCheck(355,357,357,354,354)==null,"Read through (a row or two filed or added meanwhile aside), held still, as many as the comparison's first read: complete.");
                Check(WholesaleRun.ListCheck(109,355,355,108,354)=="changed while it was read (109 rows read, 355 now)","Fewer read than the table holds now (as the 15 Nov 09:32 read): not complete.");
                Check(WholesaleRun.ListCheck(109,-1,-1,108,354)=="showed no table"&&WholesaleRun.ListCheck(200,200,260,199,354)=="kept changing (200 rows, then 260)","No table, or still filling: not complete.");
                Check(WholesaleRun.ListCheck(109,109,109,108,354)=="listed 108 orders (354 when the comparison began)"&&WholesaleRun.ListCheck(290,290,290,289,354)==null,"Far fewer than the comparison's first read (under 80 %): not complete; a few gone: complete.");
                Check(WholesaleRun.ListCheck(67,67,67,66,66)==null&&WholesaleRun.ListCheck(30,30,30,29,66)!=null,"Filtered to BUF: against the BUF orders first listed.");
                var bufRows=Enumerable.Range(1,66).Select(n=>new WholesaleRow {Doc="WO9"+n.ToString("000000",CultureInfo.InvariantCulture),ShipVia="BUFRIV"}).ToList();
                var mixed=bufRows.Concat(Enumerable.Range(1,290).Select(n=>new WholesaleRow {Doc="WO8"+n.ToString("000000",CultureInfo.InvariantCulture),ShipVia="DXTDUB"})).ToList();
                Check(WholesaleRun.ListCheck(67,67,67,bufRows,true,354,66)==null&&WholesaleRun.ListCheck(67,67,67,bufRows,false,354,66)!=null&&WholesaleRun.ListCheck(357,357,357,mixed,false,354,66)==null&&WholesaleRun.ListCheck(31,31,31,bufRows.Take(30).ToList(),true,354,66)!=null,"The filtered list against the BUF orders first listed, the whole one against all of them.");
                string ev=Native.EvidenceText(1800,false,6200,214,true,"another program (mstsc)",null,"none since 09:52");
                Check(ev.StartsWith("Windows' last key or mouse input in this session: 1.8 s before (not the helper's own; the helper's own last input was 6.2 s before)",StringComparison.Ordinal)&&ev.Contains("moved 214 px from where the helper last put it")&&ev.Contains("In front: another program (mstsc)")&&ev.Contains("connected and unlocked")&&ev.Contains("none since 09:52")&&ev.EndsWith("What caused the input can't be established from this.",StringComparison.Ordinal),"What was seen, in words: "+ev);
                string held=Native.EvidenceText(2400,false,-1,2,false,"COSTAR","this Windows session is locked or showing another desktop: unlock it","");
                Check(held.Contains("the helper hadn't sent any input since it started")&&held.Contains("where it was when the pass began")&&held.Contains("not watched")&&held.Contains("locked")&&held.Contains("can't be established"),"A pointer that didn't move, nothing watched: said, and still no cause: "+held);
                Check(Native.SessionChangeName(4)=="Remote Desktop disconnected"&&Native.SessionChangeName(3)=="Remote Desktop connected"&&Native.SessionChangeName(7)=="locked","Windows' session changes by name.");
                Check(Updater.Parse("2.9.10")>Updater.Parse("2.9.9"),"2.9.10 is newer than 2.9.9.");
            });
            Case("Wholesale (2.9.10): made-up lists with orders taken out above (not a COSTAR Sell, then Cancel): the row at its old place, the list read whole, never another order",()=>{
                string[] cols={"Order Date","Document #","Name","Ship Via"};
                Func<IList<int>,Node> list=delegate(IList<int> numbers) {
                    var head=new Node(28,"headings");foreach(var c in cols) head.Add(new Node(25,c));
                    var table=new Node(24,"Table").Add(head);
                    foreach(int n in numbers) { var r=new Node(28,"row","","Activate");foreach(var c in cols) r.Add(new Node(29,c,c=="Document #"?"WO900000"+n.ToString("00",CultureInfo.InvariantCulture):"X"));table.Add(r); }
                    return new Node(10,"ultraGrid1").Add(table);
                };
                var box=new Native.Rect {Left=0,Top=0,Right=1000,Bottom=1000};
                var all=Enumerable.Range(1,20).ToList();
                // WO90000012 was the 13th child (the headings first) when the pass read the list.
                for(int gone=0;gone<=4;gone++) {
                    var now=list(all.Where(n=>n>gone).ToList());Func<Accessibility.IAccessible> root=()=>now;
                    using(var s=WipScan.FromHint(root,box,"WO90000012",13)) {
                        if(gone<=2) Check(s!=null&&s.TargetLine.Doc=="WO90000012"&&s.TargetLine.Pos==13-gone,gone+" taken out above: found "+gone+" places up.");
                        else Check(s==null,gone+" taken out above: not at its old place or two either side (the list is then read whole).");
                    }
                    using(var w=WipScan.From(root,box,"WO90000012",false)) Check(w.TargetLine!=null&&w.TargetLine.Doc=="WO90000012"&&w.TargetLine.Pos==13-gone,"Read whole: found at its new place ("+gone+" taken out).");
                }
                var shifted=list(all.Where(n=>n>3).ToList());
                foreach(int p in new[]{10,11,12,13,14,15}) using(var s=WipScan.FromHint(()=>shifted,box,"WO90000012",p)) Check(s==null||s.TargetLine.Doc=="WO90000012","Never another order's row: place "+p);
                var removed=list(all.Where(n=>n!=12).ToList());
                using(var s=WipScan.FromHint(()=>removed,box,"WO90000012",13)) Check(s==null,"Gone from the list: not found at or near its place.");
                using(var w=WipScan.From(()=>removed,box,"WO90000012",false)) Check(w.Target<0,"Read whole: not listed.");
            });
            Case("Wholesale (2.9.0): the Order window read from made-up controls (number, Terms, Comment, lines, tyres)",()=>{
                Func<ControlInfo,string> text=c=>c.Text;
                var v=WholesaleOrderReader.Parse(OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false),text);
                Check(v.Problem==null,"Read without a problem: "+v.Problem);
                Check(v.Number=="WO9000001"&&v.Terms=="30INV"&&v.Comment=="WWW"&&!v.NotesMarker&&!v.MoreLines,"Number, Terms, Comment: "+v.Number+" "+v.Terms+" "+v.Comment);
                Check(v.Lines.Count==3,"Three lines (the empty ones skipped): "+v.Lines.Count);
                var tyre=v.Lines[0];Check(tyre.Number==1&&tyre.Item=="W43116"&&tyre.Size=="265/70R16"&&tyre.OrderQty=="4"&&tyre.BackOrder=="4"&&tyre.ShipQty==""&&tyre.Tyre&&!tyre.Note,"Line 1, the tyre: "+tyre.Item+" "+tyre.Size+" "+tyre.OrderQty);
                Check(!v.Lines[1].Tyre&&!v.Lines[1].Note&&v.Lines[1].Item=="FREIGHT","Line 2: freight, not a tyre.");
                Check(v.Lines[2].Note&&!v.Lines[2].Tyre&&v.Lines[2].Description=="","Line 3: a note line, its words not read.");
                var open=WholesaleOrderReader.Parse(OrderWindow("WO9000001","CASH","",Lines(),true,false,true),text);
                Check(open.Problem==null&&open.Lines.Count==3&&open.Lines[0].Tyre&&open.Lines[2].Note&&open.NotesMarker&&open.Terms=="CASH","Line 1 open (expanded), the others lower; the Notes marker seen.");
                Check(WholesaleOrderReader.Parse(OrderWindow("WO9000001","30INV","",Lines(),false,true,false),text).MoreLines,"The lines' scroll bar on: more lines than show.");
                var unread=WholesaleOrderReader.Parse(OrderWindow("WO9000001","30INV","",Lines(),false,false,false),c=>c.X==648?null:c.Text);
                Check(unread.Problem!=null&&unread.Problem.Contains("line 1"),"A box that can't be read: a problem ("+unread.Problem+").");
                var noTerms=WholesaleOrderReader.Parse(OrderWindow("WO9000001","30INV","",Lines(),false,false,false),c=>c.X==389&&c.Y==230?null:c.Text);
                Check(noTerms.Terms==null&&WholesaleRules.Decide(new WholesaleLook {Row=Row("WO9000001","","","BUFF",""),Terms=noTerms.Terms,OrderComment=""}).Why.Contains("Terms couldn't be read"),"Terms that can't be read: left alone.");
                var twoLabels=OrderWindow("WO9000001","30INV","",Lines(),false,false,false);twoLabels.Add(Mk(9000,100,ST,37,120,176,17,"Order"));twoLabels.Add(Mk(9001,100,ED,214,119,150,20,"WO9000002"));
                Check(WholesaleOrderReader.Number(twoLabels,text)==null,"Two \"Order\" labels: its number can't be told.");
                Check(WholesaleOrderReader.Number(OrderWindow("WO9000001","30INV","",Lines(),false,false,false),text)=="WO9000001"&&WholesaleOrderReader.Number(OrderWindow("WO9000001","30INV","",Lines(),false,false,false),c=>c.X==214?null:c.Text)==null,"The number on its own (null when its box can't be read).");
                var notOrder=OrderWindow("WO9000001","30INV","",Lines(),false,false,false).Where(c=>c.Text!="Order Qty").ToList();
                Check(WholesaleOrderReader.Parse(notOrder,text).Problem!=null,"No Order Qty heading (not a wholesale Order): a problem.");
            });
            Case("Wholesale (2.9.0): Sydney's stock on an opened tyre line (ThisBr = Avail; NON-STOCKING), from made-up screens laid out as the 3 Nov maps",()=>{
                Func<ControlInfo,string> text=c=>c.Text;
                Func<string,string,bool,List<ControlInfo>> win=delegate(string mine,string others,bool notStocked) { var s=OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false);StockPanel(s,301,370,mine,others,notStocked);return s; };
                Func<string,string,bool,bool,List<ControlInfo>> win2=delegate(string mine,string others,bool notStocked,bool onTopOfIt) { var s=OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false);StockPanel(s,301,370,mine,others,notStocked,true,false,onTopOfIt);return s; };
                var s1=win("12","40",false);
                var v=WholesaleOrderReader.Parse(s1,text);
                Check(v.Problem==null&&v.Lines.Count==3&&v.Lines[0].Panel==301&&v.Lines[0].Opens==s1.First(c=>c.Parent==301&&c.X==225).Handle,"The stock panel doesn't upset the lines; line 1 opens through its words.");
                var shut=WholesaleOrderReader.Parse(OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false),text);var opened=WholesaleOrderReader.Parse(OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,true),text);
                Check(!shut.Lines[0].Open&&opened.Lines[0].Open&&!opened.Lines[1].Open,"A line is open when its panel is at least twice its item box's height (160 against 20), else closed.");
                var r=WholesaleOrderReader.Stock(s1,301,text);
                Check(r.Found&&r.Available==12&&!r.NonStocking&&r.Problem==null,"ThisBr = Avail read (12, not OtherBrs' 40); the NON-STOCKING! label under the stock panel isn't taken (2.9.0 took it): "+r.Available+" "+r.Problem);
                var flag=s1.First(c=>c.Parent==30101&&c.Text=="NON-STOCKING!");
                Check(WholesaleOrderReader.Covered(s1,flag,301)&&!WholesaleOrderReader.Covered(s1,s1.First(c=>c.Text=="Sup List"),301),"The label is covered by the stock panel above it; Sup List isn't.");
                Check(WholesaleOrderReader.Covered(s1,Mk(9999,30101,ST,43,418,154,17,"NON-STOCKING!"),301),"A label that isn't in the read: taken as covered.");
                // The label one panel deeper, that panel under the stock panel: covered all the same.
                var nested=OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false);StockPanel(nested,301,370,"12","40",false);
                nested.Remove(nested.First(c=>c.Parent==30101&&c.Text=="NON-STOCKING!"));
                nested.Add(Mk(30109,30101,WN,39,416,200,40,""));nested.Add(Mk(30110,30109,ST,43,418,154,17,"NON-STOCKING!"));
                var nr=WholesaleOrderReader.Stock(nested,301,text);
                Check(nr.Available==12&&!nr.NonStocking&&nr.Problem==null,"A label in a panel under the stock panel: covered; Sydney's 12 read ("+nr.Problem+").");
                var unreadTop=WholesaleOrderReader.Stock(win2("12","40",false,true),301,c=>c.X==104&&c.Class==ED?null:c.Text);
                Check(unreadTop.Problem!=null&&!unreadTop.NonStocking,"NON-STOCKING! showing over a box that can't be read: a problem, never NON-STOCKING.");
                var onTop=WholesaleOrderReader.Stock(win2("12","40",false,true),301,text);
                Check(onTop.Problem!=null&&onTop.Problem.Contains("both")&&onTop.Available==null&&!onTop.NonStocking,"NON-STOCKING! showing over a number: a problem, neither taken.");
                var emptyTop=WholesaleOrderReader.Stock(win2("","",false,true),301,text);
                Check(emptyTop.Found&&emptyTop.NonStocking&&emptyTop.Problem==null,"NON-STOCKING! showing over empty boxes: not stocked.");
                Check(!WholesaleOrderReader.Stock(s1,302,text).Found,"Line 2 hasn't been open: no stock panel.");
                Check(WholesaleOrderReader.Stock(win("-1","0",false),301,text).Available==-1&&WholesaleOrderReader.Stock(win("4.00","0",false),301,text).Available==4&&WholesaleOrderReader.Stock(win("1,234","0",false),301,text).Available==1234&&WholesaleOrderReader.Stock(win("4.5","0",false),301,text).Available==4,"Negative, decimal and grouped numbers; a part one rounded down.");
                var non=WholesaleOrderReader.Stock(win("","",true),301,text);
                Check(non.Found&&non.NonStocking&&non.Available==null&&non.Problem==null,"NON-STOCKING!: empty boxes, not stocked.");
                Check(WholesaleOrderReader.Stock(win("","",false),301,text).Problem.Contains("empty")&&!WholesaleOrderReader.Stock(win("","",false),301,text).NonStocking&&WholesaleOrderReader.Stock(win("n/a","",false),301,text).Problem.Contains("reads"),"Empty (the label covered, as on the 14:45 map) or odd: a problem, not NON-STOCKING.");
                Check(WholesaleOrderReader.Stock(s1,301,c=>c.X==104&&c.Class==ED?null:c.Text).Problem.Contains("couldn't be read"),"A box that can't be read: a problem.");
                var noHead=OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false);StockPanel(noHead,301,370,"12","40",false,false);
                Check(WholesaleOrderReader.Stock(noHead,301,text).Problem.Contains("heading"),"No ThisBr heading: a problem (OtherBrs isn't taken for it).");
                var twice=OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false);StockPanel(twice,301,370,"12","40",false,true,true);
                Check(WholesaleOrderReader.Stock(twice,301,text).Problem.Contains("2 times"),"Two = Avail labels: a problem.");
                var bare=OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false);bare.Add(Mk(9001,301,WN,39,396,900,130,"Frame1"));bare.Add(Mk(9002,9001,ST,43,418,154,17,"NON-STOCKING!"));
                var alone=WholesaleOrderReader.Stock(bare,301,text);
                Check(alone.Found&&alone.NonStocking&&alone.Available==null,"NON-STOCKING! without its stock panel: not stocked, not \"didn't open\".");
                Check(WholesaleOrderReader.Stock(win("99999999999","0",false),301,text).Problem.Contains("too big"),"A number too big to be stock: a problem (not a crash).");
                var stray=win("12","40",false);stray.Add(Mk(9101,30101,ST,600,420,40,15,"Item"));stray.Add(Mk(9102,30101,ST,650,420,40,15,"Net"));
                var sv=WholesaleOrderReader.Parse(stray,text);
                Check(sv.Problem==null&&sv.Lines.Count==3&&WholesaleOrderReader.Changed(WholesaleOrderReader.Fingerprint(s1,text),WholesaleOrderReader.Fingerprint(stray,text))==null,"Words like Item or Net inside an opened line's panel aren't taken for the lines' headings.");
                var noBox=OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false);noBox.Remove(noBox.First(c=>c.X==214&&c.Y==82));
                Check(WholesaleOrderReader.Number(noBox,text)==null&&WholesaleOrderReader.NumberBox(noBox)==null,"No number box: no number (the Next # button beside it isn't taken).");
                var editable=OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false);editable.First(c=>c.Parent==302&&c.X==225).Style=0;
                var ev=WholesaleOrderReader.Parse(editable,text);
                Check(ev.Lines[1].Opens==0&&ev.Lines[0].Opens!=0,"A line whose words box can be typed into isn't opened (never its item box instead).");
                var nonLine=Tyre(1,null);nonLine.NonStocking=true;
                var nv=WholesaleRules.Decide(Look("30INV",new List<bool?>(),false,nonLine,Tyre(2,9)));
                Check(nv.Action=="flag"&&WholesaleComment.TagText(nv.Tags)=="[stock]"&&nv.Why.Contains("NON-STOCKING"),"A NON-STOCKING tyre: [stock] ("+nv.Why+").");
                var why=Tyre(1,null);why.StockWhy="the line didn't open";
                var wv=WholesaleRules.Decide(Look("30INV",new List<bool?>(),false,why,Tyre(2,9)));
                Check(wv.Action=="leave"&&wv.Problems.Count==1&&wv.Why.Contains("didn't open"),"A tyre whose stock couldn't be read: not sold, and why ("+wv.Why+").");
            });
            Case("Wholesale (2.9.0): the order read again after its tyre lines were opened: a line's box, the Comment, Terms or the totals changed, a box gone, a line new; the stock panels and a note's words left out",()=>{
                var asked=new List<ControlInfo>();
                Func<ControlInfo,string> text=c=>{ asked.Add(c);return c.Text; };
                var lines=Lines();lines[4]=new[]{"NOTE","TEST NOTE WORDS"};
                Func<List<ControlInfo>> win=()=>OrderWindow("WO9000001","30INV","WWW",lines,false,false,false);
                var s=win();var before=WholesaleOrderReader.Fingerprint(s,text);
                Check(before.ContainsKey("line 1 ORDER QTY")&&before.ContainsKey("line 1 DESCRIPTION")&&before.ContainsKey("line 1 NET")&&before.ContainsKey("line 1 box at 107")&&before.ContainsKey("line 25 ITEM")&&before["Comment"]=="WWW"&&before["Terms"]=="30INV"&&before["the order's number"]=="WO9000001"&&before["the totals at 972,863"]=="420.00","Lines by number and heading, the Comment, Terms, the number and the totals: "+String.Join(", ",before.Keys.Take(12).ToArray()));
                Check(!asked.Any(c=>c.W>=600)&&!before.Values.Contains("TEST NOTE WORDS"),"A note line's words aren't read.");
                var same=win();StockPanel(same,301,370,"12","40",false);StockPanel(same,302,389,"","",true);
                Check(WholesaleOrderReader.Changed(before,WholesaleOrderReader.Fingerprint(same,text))==null,"Stock panels shown under lines: nothing changed.");
                var shownBefore=win();StockPanel(shownBefore,301,370,"12","40",false);var shownAfter=win();StockPanel(shownAfter,301,370,"11","39",false);
                Check(WholesaleOrderReader.Changed(WholesaleOrderReader.Fingerprint(shownBefore,text),WholesaleOrderReader.Fingerprint(shownAfter,text))==null,"A stock panel there before and after with other numbers: the order didn't change.");
                var qty=win();qty.First(c=>c.Parent==301&&c.X==648).Text="5";
                Check(WholesaleOrderReader.Changed(before,WholesaleOrderReader.Fingerprint(qty,text))=="line 1 ORDER QTY","A line's Order Qty changed: said.");
                var net=win();net.First(c=>c.Parent==302&&c.X==875).Text="99.00";
                Check(WholesaleOrderReader.Changed(before,WholesaleOrderReader.Fingerprint(net,text))=="line 2 NET","A line's Net changed: said.");
                var comment=win();comment.First(c=>c.X==782&&c.Y==82).Text="WWW CHECK STOCK";
                Check(WholesaleOrderReader.Changed(before,WholesaleOrderReader.Fingerprint(comment,text))=="Comment","The Comment changed: said.");
                var total=win();total.First(c=>c.X==972&&c.Y==863).Text="430.00";
                Check(WholesaleOrderReader.Changed(before,WholesaleOrderReader.Fingerprint(total,text))=="the totals at 972,863","The totals changed: said.");
                var gone=win();gone.Remove(gone.First(c=>c.Parent==301&&c.X==499));
                Check(WholesaleOrderReader.Changed(before,WholesaleOrderReader.Fingerprint(gone,text))=="line 1 SIZE (gone)","A box gone: said.");
                var fewer=WholesaleOrderReader.Fingerprint(win().Where(c=>c.Parent!=325).ToList(),text);
                Check(WholesaleOrderReader.Changed(fewer,WholesaleOrderReader.Fingerprint(win(),text))=="line 25 box at 107 (new)","A line that wasn't there before: said.");
                var unread=WholesaleOrderReader.Fingerprint(win(),c=>c.Parent==302&&c.X==648?null:c.Text);
                Check(WholesaleOrderReader.Changed(before,unread)=="line 2 ORDER QTY","A box that couldn't be read: not taken as the same.");
            });
            Case("Wholesale (2.9.0): card details in a made-up Notes window (yes / no / can't tell), the words kept nowhere",()=>{
                Func<string[],Node> notes=delegate(string[] texts) {
                    var pane=new Node(16,"").Add(new Node(28,"Top Row").Add(new Node(25,"Top Left Header Cell"),new Node(25,"Note[Column Header]"),new Node(25,"[Column Header]"),new Node(25,"Date[Column Header]"),new Node(25,"Entered By[Column Header]")));
                    for(int i=0;i<texts.Length;i++) {
                        string n="Row"+i;var row=new Node(28,"x");var cell=new Node(29,"Note "+n,texts[i]);
                        // 2.9.2: "(value fails)", "(name fails)", "(row fails)": that call isn't answered; "(cell empty)": the row
                        // gives an empty object where its Note cell is.
                        cell.FailValue=texts[i]=="(value fails)";cell.FailName=texts[i]=="(name fails)";row.FailCount=texts[i]=="(row fails)";row.EmptyChild=texts[i]=="(cell empty)"?2:0;
                        pane.Add(row.Add(new Node(26,n),cell,new Node(29," "+n,""),new Node(29,"Date "+n,"02/11/2026"),new Node(29,"Entered By "+n,"TV")));
                    }
                    return new Node(9,"Notes").Add(new Node(1,""),new Node(10,"Notes").Add(new Node(9,"").Add(new Node(10,"").Add(new Node(22,"").Add(new Node(43,"New",null,"Press")),new Node(9,"").Add(new Node(10,"").Add(pane)))),new Node(9,"OK").Add(new Node(43,"OK",null,"Press"))));
                };
                Check(WholesaleNotes.Card(()=>notes(new[]{"ACCOUNT CUSTOMER","PAY BY CARD 5555 5555 5555 4444 EXP 12/28"}))==true,"Card details in the second note.");
                Check(WholesaleNotes.Card(()=>notes(new[]{"CALL BEFORE DISPATCH 0400 000 001"}))==false,"No card details.");
                Check(WholesaleNotes.Card(()=>notes(new string[0]))==null,"The Notes list with no rows yet (still being filled): can't tell, never \"no card details\".");
                Check(WholesaleNotes.Card(()=>new Node(9,"Notes").Add(new Node(10,"Notes")))==null,"No Note column found: can't tell.");
                // 2.9.2 (the review): read whole or not at all.
                Check(WholesaleNotes.Card(()=>notes(new[]{"CALL FIRST","(value fails)"}))==null,"A note whose words COSTAR doesn't give: can't tell, never \"no\".");
                Check(WholesaleNotes.Card(()=>notes(new[]{"CALL FIRST","(name fails)"}))==null&&WholesaleNotes.Card(()=>notes(new[]{"CALL FIRST","(row fails)"}))==null,"A cell's name, or a row's cells, COSTAR doesn't give: can't tell.");
                Check(WholesaleNotes.Card(()=>notes(new[]{"CALL FIRST","(cell empty)"}))==null,"A row giving an empty object where its Note cell is: can't tell, never \"no\" (the second review).");
                string card="PAY BY CARD 5555 5555 5555 4444 EXP 12/28";
                Check(WholesaleNotes.Card(()=>notes(Enumerable.Repeat("CALL FIRST",96).Concat(new[]{card}).ToArray()))==true&&WholesaleNotes.Card(()=>notes(Enumerable.Repeat("CALL FIRST",97).ToArray()))==false,"97 notes (599 objects here) read whole: the card in the last one found; none: no.");
                Check(WholesaleNotes.Card(()=>notes(Enumerable.Repeat("CALL FIRST",98).ToArray()))==null&&WholesaleNotes.Card(()=>notes(Enumerable.Repeat("CALL FIRST",97).Concat(new[]{card}).ToArray()))==null,"More objects than are read: can't tell, never \"no\" from the part read.");
                Func<int,Node> wide=delegate(int extra) { var t=notes(new[]{"CALL FIRST"});t.Add(Enumerable.Range(0,extra).Select(i=>new Node(42,"")).ToArray());return t; };
                Check(WholesaleNotes.Card(()=>wide(98))==false&&WholesaleNotes.Card(()=>wide(99))==null,"More than 100 under one object: can't tell.");
                Func<Node> framed=delegate { var t=notes(new[]{"CALL FIRST"});var menu=new Node(2,"System");menu.FailCount=true;var bar=new Node(3,"Vertical");bar.FailCount=true;bar.FailName=true;t.Add(menu,bar);return t; };
                Check(WholesaleNotes.Card(framed)==false,"Windows' frame parts (the system menu, a scroll bar) aren't opened: one that doesn't give its parts doesn't spoil the read.");
                Func<int,Node> deep=delegate(int levels) { Node t=notes(new[]{"CALL FIRST"});for(int i=0;i<levels;i++) t=new Node(9,"").Add(t);return t; };
                Check(WholesaleNotes.Card(()=>deep(7))==false&&WholesaleNotes.Card(()=>deep(8))==null,"Deeper than 16 levels: can't tell.");
                // "No" only from two reads that agree (COSTAR may still be adding notes).
                int reads=0,waits=0;bool answering=true;Func<bool> wait=delegate { waits++;return answering; };
                Func<string[][],Func<Accessibility.IAccessible>> seq=delegate(string[][] lists) { reads=0;waits=0;return delegate { var t=notes(lists[Math.Min(reads,lists.Length-1)]);reads++;return t; }; };
                Check(WholesaleNotes.Settled(seq(new[]{new[]{"CALL FIRST"},new[]{"CALL FIRST"}}),wait)==false&&reads==2&&waits==1,"No from two reads that agree (the wait between them).");
                Check(WholesaleNotes.Settled(seq(new[]{new[]{"CALL FIRST"},new[]{"CALL FIRST",card}}),wait)==true,"A note with card details added between the reads: yes.");
                Check(WholesaleNotes.Settled(seq(new[]{new[]{"CALL FIRST"},new[]{"CALL FIRST","ACCOUNT CUSTOMER"}}),wait)==null&&WholesaleNotes.Settled(seq(new[]{new[]{"CALL FIRST"},new[]{"CALL FIRST","(value fails)"}}),wait)==null,"More notes at the second read, or a second read that fails: can't tell, never \"no\".");
                Check(WholesaleNotes.Settled(seq(new[]{new[]{card}}),wait)==true&&reads==1&&waits==0&&WholesaleNotes.Settled(seq(new[]{new string[0]}),wait)==null&&reads==1&&waits==0,"Yes, or can't tell, at the first read: no second read.");
                answering=false;
                Check(WholesaleNotes.Settled(seq(new[]{new[]{"CALL FIRST"},new[]{"CALL FIRST"}}),wait)==null&&reads==1&&waits==1,"COSTAR not answering before the second read: can't tell, no second read.");
                answering=true;
                Check(WholesaleNotes.Agree(false,2,false,2)==false&&WholesaleNotes.Agree(false,2,false,1)==null&&WholesaleNotes.Agree(false,2,null,0)==null&&WholesaleNotes.Agree(false,2,true,3)==true&&WholesaleNotes.Agree(null,0,false,2)==null&&WholesaleNotes.Agree(true,1,false,1)==true,"Two reads compared.");
                Check(WholesaleNotes.Budget>=300&&WholesaleNotes.AgainMs>=200&&WholesaleNotes.AgainMs<=1000,"Room for the 4 Nov map's Notes (86 objects, 8 more a note) many times over; the second read within a second.");
            });
            Case("Wholesale (2.9.2): a window over the order not read in full yet is looked at again until 5 s after it was first seen (the customer's Notes right after a memo); one read in full that isn't the Notes or a memo stops the run at once",()=>{
                const string wf="WindowsForms10.Window.8.app.0.1";
                Check(WholesaleRules.NotReadYet(wf,new string[0],0,0)&&WholesaleRules.NotReadYet(wf,new[]{"?"},0,0)&&WholesaleRules.NotReadYet(wf,new[]{"OK","?"},0,0)&&WholesaleRules.NotReadYet(wf,null,0,0),"No button, or one greyed or its words unread: not read in full yet.");
                Check(!WholesaleRules.NotReadYet(wf,new[]{"OK"},0,0)&&!WholesaleRules.NotReadYet(wf,new[]{"Yes","No"},0,0),"Every button read: read in full (a Yes/No question stops the run at once).");
                Check(WholesaleRules.NotReadYet("#32770",new[]{"OK"},0,0)&&WholesaleRules.NotReadYet("#32770",new[]{"OK"},2,1)&&!WholesaleRules.NotReadYet("#32770",new[]{"OK"},2,0),"A message box with no words read, or some unread: not yet; every word read: read in full.");
                var u=new UnknownNotice();bool first;
                Check(!u.Stop(30,1000,true,out first)&&first,"First look at a window not read in full: looked at again (the day log says so once).");
                Check(!u.Stop(30,1000+UnknownNotice.UnknownMs-1,true,out first)&&!first&&u.Stop(30,1000+UnknownNotice.UnknownMs,true,out first),"Looked at again until 5 s after it was first seen, then the run stops.");
                Check(u.Stop(31,7000,false,out first)&&first,"A window read in full that the dry run doesn't answer: the run stops at once (as before 2.9.2).");
                Check(!u.Stop(32,0,true,out first)&&u.Stop(32,100,false,out first),"Not read in full, then read in full and not answerable: stops then.");
                var v=new UnknownNotice();
                Check(!v.Stop(30,0,true,out first)&&!v.Stop(40,100,true,out first)&&!v.Stop(30,4000,true,out first)&&!v.Stop(40,4100,true,out first)&&v.Stop(30,5000,true,out first)&&!v.Stop(40,5050,true,out first)&&v.Stop(40,5100,true,out first),"Two taking turns in front: each its own 5 s from when it was first seen.");
                v.Sweep(w=>w!=30);
                Check(v.Count==1&&!v.Stop(30,9000,true,out first)&&first,"One gone (closed or hidden) is forgotten: shown again, it is a new window.");
                Check(UnknownNotice.UnknownMs>=2000&&UnknownNotice.UnknownMs<=10000,"The wait is seconds, under the order's 20 s.");
            });
            Case("Wholesale (2.9.0): the left-hand menu's item found by name and pressed through accessibility; the Order windows told apart",()=>{
                Func<Node[]> items=()=>new[]{new Node(43,"Wholesale Order",null,"Press"),new Node(43,"Quotation",null,"Press"),new Node(43,"Repair Order",null,"Press"),new Node(43,"Invoice",null,"Press")};
                var outline=new Node(35,"").Add(new Node(64,"Order Entry",null,"Collapse"));outline.Add(items());
                var root=new Node(10,"COSTAR").Add(new Node(9,"").Add(new Node(10,"Advanced Search")),new Node(9,"").Add(outline));
                object child;string why;
                var found=CostarMenu.Find(root,"Wholesale Order",out child,out why) as Node;
                Check(found!=null&&child==null&&found.Name=="Wholesale Order","Wholesale Order found ("+why+").");
                Check(CostarMenu.Find(root,"repair order",out child,out why) is Node,"Repair Order found, any case.");
                Check(CostarMenu.Find(root,"Stock Take",out child,out why)==null&&why.Contains("isn't in"),"An item that isn't there: "+why);
                outline.Add(new Node(43,"Quotation",null,"Press"));
                Check(CostarMenu.Find(root,"Quotation",out child,out why)==null&&why.Contains("2 times"),"Twice: not pressed ("+why+").");
                Check(CostarMenu.Find(new Node(10,"COSTAR"),"Wholesale Order",out child,out why)==null&&why.Contains("wasn't found"),"No menu: "+why);
                var act=Direct.Act(delegate(out object c,out string w) { return CostarMenu.Find(root,"Wholesale Order",out c,out w); });
                Check(Direct.Went(act,5000,400)=="pressed"&&outline.Kids.OfType<Node>().Single(k=>k.Name=="Wholesale Order").Pressed==1&&outline.Kids.OfType<Node>().Where(k=>k.Name!="Wholesale Order").All(k=>k.Pressed==0),"Only Wholesale Order pressed.");
                Func<int,Node> tabs=delegate(int sel) { var list=new Node(60,"");string[] n={"Ship to","Rebill to","Contacts","Notes"};for(int i=0;i<n.Length;i++) list.Add(new Node(37,n[i],null,"Switch",i==sel?0x2:0));return new Node(9,"").Add(new Node(10,"").Add(list)); };
                Check(WholesaleOrderReader.SelectedTab(()=>tabs(0))=="Ship to"&&WholesaleOrderReader.SelectedTab(()=>tabs(3))=="Notes"&&WholesaleOrderReader.SelectedTab(()=>tabs(-1))==null,"The tab showing over the order's header.");
                var two=tabs(0);two.Kids[0].Kids[0].Add(new Node(37,"Notes",null,"Switch",0x2));
                Check(WholesaleOrderReader.SelectedTab(()=>two)==null,"Two tabs marked showing: can't tell.");
                var w1=RoListKind.Wholesale;var ro=RoListKind.Wip;
                Check(w1.IsWindow("Order  Branch 1  Tempe Tyres Sydney")&&w1.InBranch("Order  Branch 1  Tempe Tyres Sydney",1)&&!w1.InBranch("Order  Branch 1  Tempe Tyres Sydney",11),"An Order window of Branch 1.");
                foreach(var c in new[]{"RepairOrder  Branch 1  Tempe Tyres Sydney","Invoice  Branch 1  Tempe Tyres Sydney","Orders yet to be filled","OrderCheck","Notes",""}) Check(!w1.IsWindow(c),"\""+c+"\" isn't an Order window.");
                Check(ro.IsWindow("RepairOrder  Branch 11  Tempe Tyres Tempe")&&ro.InBranch("RepairOrder  Branch 11  Tempe Tyres Tempe",11)&&!ro.IsWindow("Order  Branch 1  Tempe Tyres Sydney"),"Repair Orders as before.");
                Check(ro.Title=="Work-in-Progress"&&ro.OrderCheckCopy&&w1.Title=="Orders yet to be filled"&&!w1.OrderCheckCopy,"The lists' titles.");
            });
        }
    }
}
