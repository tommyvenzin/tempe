// Ebay-auto 1.0.0: an eBay item whose SKU isn't a COSTAR item (a wheel or package SKU that doesn't match a COSTAR code).
// COSTAR then opens its "Quick Item Add" window over the Repair Order (5 Nov run: owned by the Repair Order, the Repair
// Order disabled, buttons Selling Prices, NonStocking?, Serialized?, Add item, Cancel). 2.9.10 stopped there with the window
// open. Here, only for a Quick Item Add recognised as such (its title, owned by THIS job's Repair Order, exactly one Cancel
// and one Add item), the helper presses its Cancel (never Add item), looks at what is left, records all of it, and goes on
// with the rest of the order where that is safe. The item is left for Seb: the order is "handed over" (never reported as
// entered and verified, never closed, never retried by itself). Anything unexpected after that ends entry where it is, with
// the exact point recorded and the order handed over all the same. No SKU is changed or guessed, no row is deleted or
// overwritten, no amount is made up, and the total check of a complete order is unchanged.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace TempeCostar {
    // One item (or line) left for Seb. Line: its planned line (1-based); Position/Count: which item of how many.
    internal sealed class EbayUnresolved {
        internal int Line,Position,Count,Quantity,UnitCents;
        internal string Kind,Label,Sku,Attempted,Popup,Action="not pressed yet",After;internal bool Cancelled;
        // For the person: what was left and what is on that line now.
        internal string Text {
            get {
                string what=Kind=="product"?"item "+Sku+" x"+Quantity+" at "+EbayHandoff.Dollars(UnitCents)+" each":Label;
                return "Not entered: "+what+" (line "+Line+"): COSTAR Sydney has no item "+Attempted+". "+
                    (Cancelled?"Its Quick Item Add was cancelled, so nothing was added"+(String.IsNullOrEmpty(After)?".":"; "+After+"."):"Its Quick Item Add is left open over the Repair Order (nothing in it was pressed).");
            }
        }
        // For the diagnostics: codes, positions and what happened (no customer details).
        internal string Record { get { return "sku="+Sku+" attempted="+Attempted+" item="+Position+"/"+Count+" line="+Line+" qty="+Quantity+" unitCents="+UnitCents+" popup=["+Popup+"] action="+Action+" after=["+After+"]"; } }
    }
    // The order was entered as far as it safely could and is left open for Seb (Message says what is left).
    internal sealed class EbayHandoffException : InvalidOperationException {
        internal EbayHandoffException(string message,Exception inner=null) : base(message,inner) { }
    }
    // The pure rules (the self-tests check them).
    internal static class EbayHandoff {
        internal const string QuickItemAddTitle="Quick Item Add";
        internal static string Dollars(int cents) { return "$"+(cents/100m).ToString("0.00",CultureInfo.InvariantCulture); }
        // A COSTAR window is taken for Quick Item Add only by all of: its exact title, owned by this job's Repair Order, one
        // usable Cancel and one Add item among its buttons. Anything else is never pressed.
        internal static bool LooksLikeQuickItemAdd(string title,bool ownedByThisOrder,IList<string> buttons,bool cancelEnabled) {
            if(!ownedByThisOrder||(title??"").Trim()!=QuickItemAddTitle||buttons==null) return false;
            int cancel=buttons.Count(b=>Norm(b)=="CANCEL"),add=buttons.Count(b=>Norm(b)=="ADD ITEM");
            return cancel==1&&add==1&&cancelEnabled;
        }
        static string Norm(string s) { return Order.Norm((s??"").Replace("&","")); }
        // Whose code a Quick Item Add is asking about. typedThisLine: this line's code went in before it appeared. shows: the
        // planned code its boxes show (null: none of them, or not readable). Returns "this" (this line's code: left for Seb,
        // entry goes on) or "earlier" (asked again about a code left on an earlier line, or unclear: entry stops there).
        internal static string Whose(bool typedThisLine,string shows,string thisCode) {
            if(!typedThisLine) return "earlier";
            if(shows==null||Norm(shows)==Norm(thisCode)) return "this";
            return "earlier";
        }
        // A planned line in words, for what is left to do (never the buyer's username: M BUY says what it is for).
        internal static string Describe(EbayLine l) {
            switch(l.Kind) {
                case "product": return "item "+l.Code+" x"+l.Quantity+" at "+Dollars(l.UnitCents);
                case "freight": return "freight "+Dollars(l.UnitCents)+" (F)";
                case "note": return l.Code=="M BUY"?"M BUY (the buyer's eBay username)":l.Label;
                default: return l.Code;
            }
        }
        // What is left, in words (message) and in short (remaining). done: the planned lines finished; point: where and why
        // entry stopped (null: it went to the end); check: what the last look found (null: no look).
        internal static void Words(List<EbayLine> plan,ICollection<int> done,List<EbayUnresolved> unresolved,string stoppedAt,string point,string check,IList<string> checks,int totalCents,out string message,out string remaining) {
            var unresolvedLines=new HashSet<int>(unresolved.Select(u=>u.Line));
            var todo=plan.Where(l=>!done.Contains(l.Line)&&!unresolvedLines.Contains(l.Line)).ToList();
            var b=new StringBuilder("NEEDS MANUAL COMPLETION in COSTAR Sydney (the Repair Order is left open, not closed). ");
            foreach(var u in unresolved) b.Append(u.Text).Append(' ');
            if(point!=null) b.Append("Entry then stopped at "+(stoppedAt??"the next step")+": "+point.TrimEnd('.')+". ");
            if(todo.Count>0) b.Append("Still to enter by hand: "+String.Join(", ",todo.Select(Describe).ToArray())+". ");
            else b.Append("Everything else is entered. ");
            if(!String.IsNullOrEmpty(check)) b.Append(check.TrimEnd()+" ");
            else b.Append("The lines and the total ("+Dollars(totalCents)+" on eBay) were not checked. ");
            if(checks!=null&&checks.Count>0) b.Append("CHECK BY HAND: "+String.Join(" ",checks.ToArray())+" ");
            b.Append("Once it's finished in COSTAR, close the Repair Order and click Mark done by hand on the receiver.");
            message=EbayText.Clean(b.ToString(),2000);
            var r=new List<string>();
            foreach(var u in unresolved) r.Add((u.Kind=="product"?u.Sku+" x"+u.Quantity+" "+Dollars(u.UnitCents):u.Label)+" (line "+u.Line+": not a COSTAR item"+(u.Cancelled?"":", Quick Item Add still open")+")");
            if(point!=null) r.Add("stopped at "+(stoppedAt??"the next step"));
            if(todo.Count>0) r.Add("to enter: "+String.Join(", ",todo.Select(l=>l.Kind=="product"?l.Code+" x"+l.Quantity:l.Kind=="freight"?"F "+Dollars(l.UnitCents):l.Code).ToArray()));
            r.Add("check the total "+Dollars(totalCents));
            r.Add("close it");
            remaining=EbayText.Clean(String.Join("; ",r.ToArray()),600);
        }
    }

    internal sealed partial class Runner {
        // Set by the Ebay-auto worker: an unknown item is handed over instead of stopping the order (see the top of this file).
        internal bool HandOffUnknownItems;
        internal readonly List<EbayUnresolved> Unresolved=new List<EbayUnresolved>();
        // Told as soon as an item is left unresolved (the worker records it in its journal before going on).
        internal Action<EbayUnresolved> OnUnknownItem;
        // The run ended handed over (all lines tried, or stopped after an unknown item): what Seb sees, and in short.
        internal bool HandedOver;internal string HandoffMessage="",HandoffRemaining="",HandoffPoint;
        // The row AddCode chose last (to look at a line after its Quick Item Add was cancelled), and the planned lines done.
        ControlInfo lastCodeRow;
        readonly HashSet<int> doneLines=new HashSet<int>();
        EbayLine currentLine;
        // AddCode for one planned line; 0 when its code was left for Seb (see Whose).
        long EbayAddCode(EbayLine l,List<EbayLine> plan,Func<long> add) {
            if(!HandOffUnknownItems) return add();
            int before=writes;lastCodeRow=null;
            try { return add(); }
            catch(OperationCanceledException) { throw; }
            catch(EbayHandoffException) { throw; }
            catch(InvalidOperationException e) {
                // COSTAR opens Quick Item Add a moment after the code is committed: looked for for up to 2 s.
                IntPtr dialog=WaitQuickItemAdd(2000);
                if(dialog==IntPtr.Zero) throw;
                string code=Order.EntryText(l.Kind=="freight"?"F":l.Code);
                string shows=QuickItemAddShows(dialog,plan);
                string whose=EbayHandoff.Whose(writes>before,shows,code);
                Diag.EventRaw("quick_item_add_seen","line="+l.Line+" stage="+Diag.StageName+" typedThisLine="+(writes>before)+" dialogShows="+(shows??"(none of the planned codes)")+" whose="+whose+" after: "+Sanitize.Text(e.Message,160));
                if(whose=="this") { UnknownItem(dialog,l,plan,code);return 0; }
                // A code left on an earlier line asked about again as the keyboard left it (or unclear): cancelled as well,
                // then entry stops here.
                string earlier=shows??(Unresolved.Count>0?Unresolved[Unresolved.Count-1].Attempted:"an item");
                string popup=DescribeQuickItemAdd(dialog);
                Diag.EventRaw("quick_item_add",popup+" for="+earlier+" (asked again)");
                CancelQuickItemAdd(dialog,earlier);
                string after;try { after=AfterCancel(l,false); } catch(EbayHandoffException h) { after=h.Message; }
                throw new EbayHandoffException("COSTAR asked about "+earlier+" again when the helper moved on to "+EbayHandoff.Describe(l)+" (its Quick Item Add was cancelled again; "+after+")",e);
            }
        }
        // Records the unknown item, cancels its Quick Item Add, looks at what is left; the order goes on.
        void UnknownItem(IntPtr dialog,EbayLine l,List<EbayLine> plan,string attempted) {
            var products=plan.Where(p=>p.Kind=="product").ToList();
            var u=new EbayUnresolved {Line=l.Line,Kind=l.Kind,Label=l.Label,Sku=l.Kind=="freight"?"F":l.Code,Attempted=attempted,Quantity=l.Quantity,UnitCents=l.UnitCents,
                Position=l.Kind=="product"?products.IndexOf(l)+1:0,Count=products.Count};
            u.Popup=DescribeQuickItemAdd(dialog);
            Diag.EventRaw("unknown_item","sku="+u.Sku+" attempted="+attempted+" item="+u.Position+"/"+u.Count+" line="+u.Line+" qty="+u.Quantity+" unitCents="+u.UnitCents+" stage="+Diag.StageName);
            Diag.EventRaw("quick_item_add",u.Popup+" for="+attempted);
            try { var controls=Snapshot(dialog);Dump("quick-item-add-controls",controls);Diag.Popup(dialog,controls); } catch(Exception) { }
            // Recorded before anything is pressed: a stop from here on is a hand-over that names this item.
            Unresolved.Add(u);
            var hook=OnUnknownItem;if(hook!=null) { try { hook(u); } catch(Exception) { } }
            try {
                u.Action=CancelQuickItemAdd(dialog,attempted);u.Cancelled=u.Action.StartsWith("Cancel pressed",StringComparison.Ordinal)||u.Action.StartsWith("closed by itself",StringComparison.Ordinal);
                u.After=AfterCancel(l,true);
            } catch(EbayHandoffException e) { if(!u.Cancelled) u.Action=e.Message;else u.After=e.Message;throw; }
            finally { Diag.AddUnresolved(u.Record); }
            Say("Item "+u.Sku+" isn't a COSTAR item in Sydney: its Quick Item Add was cancelled (nothing added) and it is left for Seb. Carrying on with the rest of the order.");
        }
        // The Quick Item Add over THIS job's Repair Order (see EbayHandoff.LooksLikeQuickItemAdd), or zero.
        IntPtr FindQuickItemAdd() {
            IntPtr front=Native.GetForegroundWindow();IntPtr cancel,add;string buttons;
            if(IsQuickItemAdd(front,out cancel,out add,out buttons)) return front;
            IntPtr found=IntPtr.Zero;
            Native.EnumWindows(delegate(IntPtr h,IntPtr unused) {
                if(Native.Pid(h)!=pid||!Native.IsWindowVisible(h)) return true;
                IntPtr c,a;string b;
                if(IsQuickItemAdd(h,out c,out a,out b)) { found=h;return false; }
                return true;
            },IntPtr.Zero);
            return found;
        }
        IntPtr WaitQuickItemAdd(int ms) {
            var timer=Stopwatch.StartNew();
            while(true) {
                IntPtr d=FindQuickItemAdd();
                if(d!=IntPtr.Zero||timer.ElapsedMilliseconds>=ms) return d;
                Thread.Sleep(50);
            }
        }
        bool OwnedByThisOrder(IntPtr w) {
            var current=w;
            for(int i=0;i<16&&current!=IntPtr.Zero;i++) { current=Native.GetWindow(current,4);if(current==root) return true; }   // GW_OWNER
            return false;
        }
        bool IsQuickItemAdd(IntPtr w,out IntPtr cancel,out IntPtr addItem,out string buttons) {
            cancel=IntPtr.Zero;addItem=IntPtr.Zero;buttons="";
            if(w==IntPtr.Zero||w==root||!Native.IsWindow(w)||!Native.IsWindowVisible(w)||Native.Pid(w)!=pid) return false;
            if(Native.Caption(w).Trim()!=EbayHandoff.QuickItemAddTitle) return false;
            bool owned=OwnedByThisOrder(w);
            var texts=new List<string>();var cancels=new List<IntPtr>();var adds=new List<IntPtr>();
            Native.EnumChildWindows(w,delegate(IntPtr h,IntPtr unused) {
                if(!Native.IsWindowVisible(h)||Native.Class(h).IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)<0) return true;
                string t;if(!Native.TryText(h,out t)) return true;
                texts.Add((t??"").Trim());
                string n=Order.Norm((t??"").Replace("&",""));
                if(n=="CANCEL") cancels.Add(h); else if(n=="ADD ITEM") adds.Add(h);
                return texts.Count<40;
            },IntPtr.Zero);
            buttons=String.Join("|",texts.Select(x=>Sanitize.Text(x,30)).Take(10).ToArray());
            bool usable=cancels.Count==1&&Native.IsWindowEnabled(cancels[0]);
            if(!EbayHandoff.LooksLikeQuickItemAdd(Native.Caption(w),owned,texts,usable)) return false;
            cancel=cancels[0];addItem=adds[0];return true;
        }
        // The window as recorded: its class, title, owner, the Repair Order's state, its buttons (no box contents).
        string DescribeQuickItemAdd(IntPtr dialog) {
            IntPtr cancel,add;string buttons;bool ok=IsQuickItemAdd(dialog,out cancel,out add,out buttons);
            return "class="+Native.Class(dialog)+" title="+Sanitize.Text(Native.Caption(dialog),40)+" ownedByThisRepairOrder="+OwnedByThisOrder(dialog)+
                " repairOrderEnabled="+Native.IsWindowEnabled(root)+" foreground="+(Native.GetForegroundWindow()==dialog)+" buttons=["+buttons+"] recognised="+ok;
        }
        // Which planned code the dialog's boxes show (it usually repeats the code it is asking about), or null.
        string QuickItemAddShows(IntPtr dialog,List<EbayLine> plan) {
            var codes=new HashSet<string>(plan.Select(p=>Order.Norm(Order.EntryText(p.Kind=="freight"?"F":p.Code))));
            string hit=null;
            try {
                Native.EnumChildWindows(dialog,delegate(IntPtr h,IntPtr unused) {
                    if(!Native.IsWindowVisible(h)||Native.Class(h).IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)<0) return true;
                    string t;if(!Native.TryText(h,out t)) return true;
                    string n=Order.Norm(t);
                    if(n.Length>0&&codes.Contains(n)) { hit=n;return false; }
                    return true;
                },IntPtr.Zero);
            } catch(Exception) { hit=null; }
            return hit;
        }
        // Cancel, pressed directly (its own click, BM_CLICK; never Add item), then the window must close within 3 s.
        string CancelQuickItemAdd(IntPtr dialog,string code) {
            IntPtr cancel,add;string buttons;
            if(!IsQuickItemAdd(dialog,out cancel,out add,out buttons)) {
                Diag.EventRaw("quick_item_add_cancel","not pressed: the window changed before Cancel ("+(Native.IsWindow(dialog)?"no longer recognised":"gone")+")");
                if(!Native.IsWindow(dialog)||!Native.IsWindowVisible(dialog)) return "closed by itself before Cancel was pressed";
                throw new EbayHandoffException("COSTAR's Quick Item Add for "+code+" changed before its Cancel could be pressed: it is left as it is");
            }
            // Only brought in front when nobody is using the PC (never taken from a person).
            if(Native.GetForegroundWindow()!=dialog&&!Native.UserActiveWithin(2000)) Native.BringToFront(dialog);
            UIntPtr pressed;Native.WriteMessage(cancel,0xF5,UIntPtr.Zero,null,3,1000,out pressed);Diag.Pressed();
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<3000&&Native.IsWindow(dialog)&&Native.IsWindowVisible(dialog)) Thread.Sleep(50);
            bool closed=!Native.IsWindow(dialog)||!Native.IsWindowVisible(dialog);
            Diag.EventRaw("quick_item_add_cancel",(closed?"closed ":"still open ")+timer.ElapsedMilliseconds+" ms after Cancel");
            if(!closed) throw new EbayHandoffException("COSTAR's Quick Item Add for "+code+" didn't close after its Cancel was pressed: it is left as it is (nothing else was pressed)");
            return "Cancel pressed; the window closed after "+timer.ElapsedMilliseconds+" ms";
        }
        // What is there once the window has gone: the Repair Order usable and in front, no other COSTAR window, and what the
        // line shows. Anything else ends entry here (handed over); nothing is pressed or typed.
        string AfterCancel(EbayLine l,bool ownLine) {
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<3000&&!Native.IsWindowEnabled(root)) Thread.Sleep(50);
            Thread.Sleep(150);
            IntPtr front=Native.GetForegroundWindow();bool enabled=Native.IsWindowEnabled(root);
            IntPtr other=OtherCostarWindow();
            // Another program came in front as the window closed and nobody is using the PC: this Repair Order is brought
            // back once (as Check does for any entry). Never taken from a person, never from a COSTAR window.
            if(front!=root&&enabled&&other==IntPtr.Zero&&(front==IntPtr.Zero||Native.Pid(front)!=pid)&&!Native.UserActiveWithin(2000)) {
                bool back=Native.BringToFront(root);Diag.EventRaw("after_cancel_front",back?"this Repair Order brought back in front":"couldn't bring it back in front");
                front=Native.GetForegroundWindow();
            }
            string line=ownLine?LineNow(l):"";
            string where=front==root?"this Repair Order":front==IntPtr.Zero?"no window":Native.Pid(front)==pid?"another COSTAR window":"another program";
            Diag.EventRaw("after_cancel","front="+where+" repairOrderEnabled="+enabled+(other!=IntPtr.Zero?" otherCostarWindow="+Native.Class(other)+" ownedByThisRepairOrder="+OwnedByThisOrder(other):"")+(line.Length>0?" "+line:""));
            if(other!=IntPtr.Zero) {
                try { if(!IsNotesWindow(other)&&!IsMemoWindow(other)&&!IsInUseWindow(other)) Diag.Popup(other,Snapshot(other)); } catch(Exception) { }
                throw new EbayHandoffException("after its Quick Item Add was cancelled COSTAR showed another window, which is left untouched");
            }
            if(!enabled) throw new EbayHandoffException("after its Quick Item Add was cancelled the Repair Order stayed unusable (disabled)");
            return line;
        }
        // A visible, enabled COSTAR window over the Repair Order that isn't the Repair Order or COSTAR's main window.
        IntPtr OtherCostarWindow() {
            IntPtr found=IntPtr.Zero;
            Native.EnumWindows(delegate(IntPtr h,IntPtr unused) {
                if(h==root||Native.Pid(h)!=pid||!Native.IsWindowVisible(h)||!Native.IsWindowEnabled(h)) return true;
                string title=Native.Caption(h);
                if(Branches.OfMain(title)!=0||title.StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase)) return true;
                if(OwnedByThisOrder(h)) { found=h;return false; }
                return true;
            },IntPtr.Zero);
            return found;
        }
        // What the line holds now, in the helper's words (its code, and whether a description, quantity or price is there).
        string LineNow(EbayLine l) {
            try {
                var row=lastCodeRow;if(row==null) return "line "+l.Line+" couldn't be found again";
                var s=GridCurrent();var g=Selectors.ProductGrid(s);
                var now=g.Rows.FirstOrDefault(r=>r.Handle==row.Handle);
                if(now==null) return "line "+l.Line+" is no longer where it was";
                string code=Order.Norm(now.Value);
                if(code.Length==0) return "line "+l.Line+" is empty again";
                string description=Order.Clean(Selectors.Cell(s,now,g.Description).Value),quantity=Order.Clean(Selectors.Cell(s,now,g.Quantity).Value);
                int net=Selectors.Cents(Selectors.Cell(s,now,g.Net));
                var parts=new List<string>();
                parts.Add(description.Length==0?"no description":"description \""+Sanitize.Text(description,40)+"\"");
                parts.Add(quantity.Length==0?"no quantity":"quantity "+Sanitize.Text(quantity,10));
                parts.Add(net==0?"no price":"price "+EbayHandoff.Dollars(net));
                return "line "+l.Line+" still shows "+code+" ("+String.Join(", ",parts.ToArray())+")";
            } catch(Exception e) { return "line "+l.Line+" couldn't be read ("+Sanitize.Text(e.Message,80)+")"; }
        }
        // The last look of an order with unresolved items: everything the full check looks at except the unresolved lines,
        // and the total compared with what the entered lines should make. Nothing is changed. Returns its words.
        string VerifyEbayPartial(List<ControlInfo> s,List<EbayLine> plan) {
            VerifyEbayHeader(s);
            var skip=new HashSet<int>(Unresolved.Select(u=>u.Line));var notes=new List<string>();
            EbayCheck.Lines(s,plan,spaced,skip,notes);
            int total=Selectors.Total(s);
            int unresolved=Unresolved.Sum(u=>u.Kind=="product"?u.Quantity*u.UnitCents:u.Kind=="freight"?u.UnitCents:0);
            int expected=ebay.totalCents-unresolved;
            Diag.EventRaw("partial_check","lines checked: "+(plan.Count-skip.Count)+" of "+plan.Count+"; "+String.Join("; ",notes.ToArray())+"; total "+(total==expected?"= eBay total less the unresolved":"differs from the eBay total less the unresolved"));
            return "Checked: customer, PO#, comment, Ship to, Written By/Salesperson and the "+(plan.Count-skip.Count)+" entered line(s). "+
                (total==expected?"COSTAR's total "+EbayHandoff.Dollars(total)+" is the eBay total "+EbayHandoff.Dollars(ebay.totalCents)+" less the unresolved "+EbayHandoff.Dollars(unresolved)+".":
                 "COSTAR's total is "+EbayHandoff.Dollars(total)+"; the entered lines should make "+EbayHandoff.Dollars(expected)+" (the eBay total "+EbayHandoff.Dollars(ebay.totalCents)+" less the unresolved "+EbayHandoff.Dollars(unresolved)+"): check it.");
        }
        // All lines tried, items left unresolved: the last look, then the order is handed over (left open, never closed).
        void FinishHandoff(List<EbayLine> plan) {
            Diag.BeginStage("Final check (partial) and hand-over");Stage("Partial check");
            string check;
            try { Ready();var final=Current();check=VerifyEbayPartial(final,plan);Dump("after-controls",final); }
            catch(OperationCanceledException) { throw; }
            catch(InvalidOperationException e) { check="The last check found: "+e.Message;Diag.EventRaw("partial_check","stopped: "+Sanitize.Text(e.Message,200)); }
            HandedOver=true;HandoffPoint=null;
            EbayHandoff.Words(plan,doneLines,Unresolved,null,null,check,Checks,ebay.totalCents,out HandoffMessage,out HandoffRemaining);
            try {
                File.WriteAllText(Path.Combine(Folder,"review.json"),json.Serialize(new{Kind="ebay-handed-over",OrderId=order.orderId,EbayTotalCents=order.totalCents,Branch=branch,Spaced=spaced,RebillFilled=rebillDone,Closed=false,
                    Unresolved=Unresolved.Select(u=>u.Record).ToArray(),Checks=Checks.ToArray(),Remaining=HandoffRemaining}),new UTF8Encoding(false));
            } catch(Exception e) { Diag.EventRaw("review_file",e.GetType().Name); }
            Say("HANDED OVER - eBay "+order.orderId+" needs manual completion in COSTAR Branch "+branch+": "+HandoffRemaining);
            Diag.ChecksByHand=Checks.Count;Diag.EndStage(true);Diag.HandedOver(null);
        }
        // A stop after an item was left unresolved (or while handling one): handed over at that point.
        void StopHandoff(List<EbayLine> plan,Exception error) {
            HandedOver=true;
            HandoffPoint=Sanitize.Text(error.Message,300);
            string at=currentLine==null?"the end of the order":EbayHandoff.Describe(currentLine);
            EbayHandoff.Words(plan??new List<EbayLine>(),doneLines,Unresolved,at,error is OperationCanceledException?"Stop was pressed (entry stopped safely)":error.Message,null,Checks,ebay==null?0:ebay.totalCents,out HandoffMessage,out HandoffRemaining);
            Diag.ChecksByHand=Checks.Count;Diag.HandedOver("stopped at "+at+": "+error.Message);
        }
    }
}
