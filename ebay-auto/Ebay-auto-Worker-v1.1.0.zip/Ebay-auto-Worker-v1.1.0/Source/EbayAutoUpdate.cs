// Ebay-auto 1.1.0: one-click updates, from Ebay-auto's OWN folder on Tommy's GitHub page (the tempe repository's
// ebay-auto folder, published by GitHub Pages: Product.UpdateFolder), never the Tempe helper's (helper/latest.json, read
// only by the Tempe helper's Updater, which is off here). The same way as the Tempe helper's (2.2.0-2.9.5), with more
// checks and a build before anything is switched:
//
//  1. latest.json (product "Ebay-auto", a version, the protocol, and one package per part with its SHA-256 and size) is
//     read past GitHub's caches (a query of its own) and checked: the right product, a package for this part with the
//     right name (Ebay-auto-Receiver-v<version>.zip / Ebay-auto-Worker-v<version>.zip), a fingerprint, a sane size.
//  2. Update now: the package is downloaded (progress shown), its size and SHA-256 must match latest.json; it is extracted
//     (no entry may escape its folder) beside this version under %LOCALAPPDATA%\EbayAuto\packages; its one top folder must
//     be named for this part and version, every file must match its own PACKAGE-SHA256.json, VERSION.txt and PART.txt must
//     say this version and part, and its Source must be Ebay-auto's (never the Tempe helper's).
//  3. It is built on this PC with its own Build.ps1 (compile and self-tests, hidden, below normal priority), still beside
//     the running version: a version that doesn't build or pass its self-tests is never switched to.
//  4. Only then, at a safe point (the worker: no order being entered and the receiver told to hold new ones; the receiver:
//     no order being entered by the worker), the running version saves what it was doing (receiving or paused, eBay orders
//     on or paused, window open or hidden), stops (ports, poll, tray icon, single-instance lock) and starts the new one,
//     which sets Product.ReadyEventName once it is up. Until then nothing else is changed: if the new version stops, or
//     isn't up within ReadyWait, it is closed and the running version starts again (the failure is said and kept).
//  5. The new version points current-<part>.txt at itself, so every launcher and "Start with Windows" hands over to it; the
//     previous package stays on this PC (the newest few are kept).
//
// Pairing, keys, certificate, settings, the queue, the journal (entered, handed over, an unacknowledged report),
// diagnostics and Start with Windows are all in %LOCALAPPDATA%\EbayAuto and are not touched by an update.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    // latest.json in Ebay-auto's GitHub folder.
    public sealed class EbayPackageInfo { public string zip,sha256;public long size; }
    public sealed class EbayRelease { public string product,version,name,notes,published;public int protocol;public EbayPackageInfo receiver,worker; }
    // What Build.ps1 -ReportTo writes.
    public sealed class EbayBuildOutcome { public bool ok;public string executable,bin,report,startupLog,error; }
    // What the version that updates saves for the one it starts (and what that one finds if it doesn't start).
    public sealed class EbayResumeState { public string part,from,to,atUtc;public bool receiving,enabled,shown; }
    public sealed class EbayUpdateFailure { public string part,from,to,atUtc,why,log; }

    internal static class EbayAutoUpdate {
        // The folder asked (tests point it at their own server; nothing else changes it).
        internal static string Folder=Product.UpdateFolder;
        internal static string Feed { get { return Folder+"latest.json"; } }
        // Pure: the feed with a query of its own (GitHub Pages and proxies keep latest.json for up to 10 minutes).
        internal static string FeedNow(DateTime utc) { return Feed+"?now="+utc.Ticks.ToString(CultureInfo.InvariantCulture); }
        internal static readonly Regex ZipName=new Regex(@"^Ebay-auto-(Receiver|Worker)-v(\d+\.\d+\.\d+)\.zip$");
        internal static readonly TimeSpan ReadyWait=TimeSpan.FromSeconds(90),BuildWait=TimeSpan.FromMinutes(15);
        internal const long MaxPackage=50L*1024*1024,MaxFeed=64*1024;
        // Where packages and the update's notes are kept (the self-tests use a folder of their own: never the real one).
        internal static string Root;
        internal static string Packages { get { return Path.Combine(Root??Product.Home,"packages"); } }
        internal static string Updates { get { return Path.Combine(Root??Product.Home,"update"); } }
        internal static Version Current { get { return Updater.Parse(Product.Version); } }
        // ---- latest.json ----
        // The package for this part, after every check (else an InvalidOperationException saying what was wrong).
        internal static EbayPackageInfo Validate(EbayRelease r,string part) {
            Order.Require(r!=null&&r.product==Product.Name,"That update file isn't Ebay-auto's (it names no product, or another one): nothing is installed from it.");
            Order.Require(Updater.Parse(r.version)>new Version(0,0,0),"Ebay-auto's update file has no version.");
            Order.Require(part==Product.ReceiverMode||part==Product.WorkerMode,"Unknown Ebay-auto part.");
            var p=part==Product.ReceiverMode?r.receiver:r.worker;
            Order.Require(p!=null,"Ebay-auto's update file has no "+part.ToLowerInvariant()+" package.");
            var m=ZipName.Match(p.zip??"");
            Order.Require(m.Success&&m.Groups[1].Value==part&&Updater.Parse(m.Groups[2].Value)==Updater.Parse(r.version),"Ebay-auto's update file names an unexpected "+part.ToLowerInvariant()+" download.");
            Order.Require(Regex.IsMatch(p.sha256??"","^[0-9a-fA-F]{64}$"),"Ebay-auto's update file has no valid fingerprint for the "+part.ToLowerInvariant()+".");
            Order.Require(p.size>10000&&p.size<MaxPackage,"Ebay-auto's update file gives an unexpected size for the "+part.ToLowerInvariant()+".");
            Order.Require(r.protocol>=0&&r.protocol<1000,"Ebay-auto's update file gives an unexpected protocol.");
            return p;
        }
        internal static bool Newer(EbayRelease r) { return r!=null&&Updater.Parse(r.version)>Current; }
        // Whether the new version still works with the other part as it is now (same protocol), in words, or null.
        internal static string ProtocolNote(EbayRelease r,string part) {
            if(r==null||Product.ProtocolOf(r.protocol)==Product.Protocol) return null;
            string other=part==Product.ReceiverMode?"worker (in Remote Desktop)":"receiver (Seb's PC)";
            return "Ebay-auto "+r.version+" speaks protocol "+Product.ProtocolOf(r.protocol)+" (this version "+Product.Protocol+"): update the "+other+" too; until both are updated, eBay orders wait (nothing is lost).";
        }
        // ---- downloads (tests replace Fetch) ----
        internal static Func<string,long,Action<long,long>,byte[]> Fetch=Download;
        static byte[] Download(string url,long limit,Action<long,long> progress) {
            Order.Require(url.StartsWith(Folder,StringComparison.Ordinal),"Updates come only from Ebay-auto's own folder on Tommy's GitHub page.");
            ServicePointManager.SecurityProtocol=ServicePointManager.SecurityProtocol|SecurityProtocolType.Tls12;
            var request=(HttpWebRequest)WebRequest.Create(url);
            request.Method="GET";request.Timeout=20000;request.ReadWriteTimeout=60000;request.AllowAutoRedirect=false;
            request.CachePolicy=new System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.NoCacheNoStore);
            using(var response=(HttpWebResponse)request.GetResponse())
            using(var stream=response.GetResponseStream())
            using(var buffer=new MemoryStream()) {
                Order.Require(response.StatusCode==HttpStatusCode.OK,"GitHub answered "+((int)response.StatusCode).ToString(CultureInfo.InvariantCulture)+".");
                var chunk=new byte[65536];int read;long total=response.ContentLength;
                while((read=stream.Read(chunk,0,chunk.Length))>0) {
                    buffer.Write(chunk,0,read);
                    Order.Require(buffer.Length<=limit,"The download is larger than expected; stopped.");
                    if(progress!=null) progress(buffer.Length,total>0?total:limit);
                }
                return buffer.ToArray();
            }
        }
        // latest.json as GitHub has it now (checked), or an exception.
        internal static EbayRelease ReadFeed(bool now) {
            byte[] bytes=Fetch(now?FeedNow(DateTime.UtcNow):Feed,MaxFeed,null);
            EbayRelease r;
            try { r=Wire.Read<EbayRelease>(Encoding.UTF8.GetString(bytes)); } catch(Exception) { throw new InvalidOperationException("Ebay-auto's update file on GitHub can't be read."); }
            Validate(r,Product.ReceiverMode);Validate(r,Product.WorkerMode);
            return r;
        }
        // ---- install ----
        // Downloads, checks and unpacks this part's package; returns its folder (beside the running version). Nothing is
        // switched over here.
        internal static string Install(EbayRelease r,string part,Action<string,int> say) {
            var p=Validate(r,part);var v=Updater.Parse(r.version);
            say("Downloading "+p.zip+" ...",0);
            byte[] zip=Fetch(Folder+p.zip,p.size,delegate(long got,long of){say("Downloading "+p.zip+" ...",(int)Math.Min(99,got*100/Math.Max(1,of)));});
            Order.Require(zip.LongLength==p.size&&Updater.Sha256(zip)==p.sha256.ToLowerInvariant(),"The download doesn't match its published fingerprint (size or SHA-256). Nothing was installed.");
            string name=Product.PackageName(part,v),target=Path.Combine(Packages,name);
            Directory.CreateDirectory(Packages);
            if(Directory.Exists(target)) {
                // Installed before (a retry): used again only when every file still checks out.
                try { Verify(target,part,v);say("Checking every file ...",100);return target; }
                catch(InvalidOperationException) { Directory.Delete(target,true); }
            }
            string temp=Path.Combine(Packages,"incoming-"+Guid.NewGuid().ToString("N"));
            try {
                say("Checking every file ...",100);
                Updater.Extract(zip,temp);
                var tops=Directory.GetDirectories(temp);var loose=Directory.GetFiles(temp);
                Order.Require(tops.Length==1&&loose.Length==0&&Path.GetFileName(tops[0])==name,"The update has an unexpected layout (one folder named "+name+" is expected). Nothing was installed.");
                Verify(tops[0],part,v);
                Directory.Move(tops[0],target);
            } finally {
                try { if(Directory.Exists(temp)) Directory.Delete(temp,true); } catch(IOException) { } catch(UnauthorizedAccessException) { }
            }
            return target;
        }
        // Every file against the package's own list, and that it is Ebay-auto's package for this part and version.
        internal static void Verify(string folder,string part,Version v) {
            Updater.VerifyManifest(folder);
            Order.Require(Updater.Parse(ReadFirst(Path.Combine(folder,"VERSION.txt")))==v,"The update's VERSION.txt doesn't say "+v.ToString(3)+". Nothing was switched over.");
            Order.Require(ReadFirst(Path.Combine(folder,"PART.txt"))==part,"The update isn't the "+part.ToLowerInvariant()+" package. Nothing was switched over.");
            string product=Path.Combine(folder,"Source","Product.cs");
            Order.Require(File.Exists(product),"The update has no Source\\Product.cs. Nothing was switched over.");
            string text=File.ReadAllText(product,Encoding.UTF8);
            Order.Require(text.Contains("internal const string Name=\""+Product.Name+"\";")&&text.Contains("internal const string DataFolder=\""+Product.DataFolder+"\";"),"The update's source isn't Ebay-auto's. Nothing was switched over.");
            foreach(string must in new[]{"Build.ps1","Launch.ps1",Product.Starter(part)}) Order.Require(File.Exists(Path.Combine(folder,must)),"The update has no "+must+". Nothing was switched over.");
            foreach(string tempe in new[]{"Start-RDP.cmd","Start-Desk.cmd","Setup-Desk.cmd"}) Order.Require(!File.Exists(Path.Combine(folder,tempe)),"The update looks like the Tempe helper's (it has "+tempe+"). Nothing was switched over.");
        }
        static string ReadFirst(string path) { try { return (File.ReadAllLines(path,Encoding.UTF8).FirstOrDefault()??"").Trim(); } catch(Exception) { return ""; } }
        // ---- build (tests replace Build) ----
        internal static Func<string,EbayBuildOutcome> Build=BuildWithPowerShell;
        static EbayBuildOutcome BuildWithPowerShell(string folder) {
            Directory.CreateDirectory(Updates);
            string report=Path.Combine(Updates,"build-"+Guid.NewGuid().ToString("N")+".json");
            string shell=Path.Combine(Environment.SystemDirectory,@"WindowsPowerShell\v1.0\powershell.exe");
            var start=new ProcessStartInfo(File.Exists(shell)?shell:"powershell.exe","-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File \""+Path.Combine(folder,"Build.ps1")+"\" -ReportTo \""+report+"\"") {UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=folder};
            try {
                using(var p=Process.Start(start)) {
                    try { p.PriorityClass=ProcessPriorityClass.BelowNormal; } catch(Exception) { }
                    if(!p.WaitForExit((int)BuildWait.TotalMilliseconds)) { try { p.Kill(); } catch(Exception) { } return new EbayBuildOutcome {ok=false,error="the build took longer than "+BuildWait.TotalMinutes+" minutes"}; }
                }
                if(!File.Exists(report)) return new EbayBuildOutcome {ok=false,error="the build said nothing (PowerShell may be blocked on this PC)"};
                var outcome=Wire.Read<EbayBuildOutcome>(File.ReadAllText(report,Encoding.UTF8))??new EbayBuildOutcome {ok=false,error="the build's report can't be read"};
                if(outcome.ok&&(String.IsNullOrEmpty(outcome.executable)||!File.Exists(outcome.executable))) { outcome.ok=false;outcome.error="the build gave no program"; }
                return outcome;
            } catch(Exception e) {
                return new EbayBuildOutcome {ok=false,error="the build couldn't run: "+e.Message};
            } finally { try { File.Delete(report); } catch(Exception) { } }
        }
        // ---- the pointer every launcher hands over to (one per part) ----
        internal static string PointerFile(string part) { return Path.Combine(Packages,"current-"+part.ToLowerInvariant()+".txt"); }
        internal static string Pointed(string part) {
            try { string p=ReadFirst(PointerFile(part));return p.Length>0&&File.Exists(Path.Combine(p,"Launch.ps1"))?p.TrimEnd('\\'):null; } catch(Exception) { return null; }
        }
        // Called by a version once it is up: the pointer names it, unless it names a newer one already.
        internal static void PointAtMe(string part,string folder) {
            if(String.IsNullOrEmpty(folder)||!File.Exists(Path.Combine(folder,"Launch.ps1"))) return;
            string now=Pointed(part);
            if(now!=null&&String.Equals(now,folder.TrimEnd('\\'),StringComparison.OrdinalIgnoreCase)) return;
            if(now!=null&&Updater.Parse(ReadFirst(Path.Combine(now,"VERSION.txt")))>Current) return;
            Directory.CreateDirectory(Packages);
            File.WriteAllText(PointerFile(part),folder.TrimEnd('\\'),new UTF8Encoding(false));
        }
        // The newest installed packages of this part are kept (the running one, the pointer's and the previous versions);
        // older ones are removed. Nothing in use is touched.
        internal static void Prune(string part,string running) {
            try {
                var mine=Directory.GetDirectories(Packages,Product.Name+"-"+part+"-v*").Select(d=>new {d,v=Updater.Parse(ReadFirst(Path.Combine(d,"VERSION.txt")))}).OrderByDescending(x=>x.v).ToList();
                string pointed=Pointed(part);
                foreach(var x in mine.Skip(3)) {
                    if(String.Equals(x.d.TrimEnd('\\'),(running??"").TrimEnd('\\'),StringComparison.OrdinalIgnoreCase)||String.Equals(x.d.TrimEnd('\\'),pointed??"",StringComparison.OrdinalIgnoreCase)) continue;
                    try { Directory.Delete(x.d,true); } catch(Exception) { }
                }
            } catch(Exception) { }
        }
        // ---- what the version that updates leaves for the next one ----
        static string ResumeFile(string part) { return Path.Combine(Updates,"resume-"+part.ToLowerInvariant()+".json"); }
        static string FailureFile(string part) { return Path.Combine(Updates,"failed-"+part.ToLowerInvariant()+".json"); }
        static string StartFailureFile(string part) { return Path.Combine(Updates,"start-failed-"+part.ToLowerInvariant()+".json"); }
        internal static void SaveResume(EbayResumeState s) { Directory.CreateDirectory(Updates);File.WriteAllText(ResumeFile(s.part),Wire.Json(s),new UTF8Encoding(false)); }
        // Read once (and removed); only a recent one, for this part, counts (15 minutes).
        internal static EbayResumeState TakeResume(string part,DateTime nowUtc) {
            string file=ResumeFile(part);
            try {
                if(!File.Exists(file)) return null;
                var s=Wire.Read<EbayResumeState>(File.ReadAllText(file,Encoding.UTF8));
                DateTime at;
                bool fresh=s!=null&&s.part==part&&DateTime.TryParse(s.atUtc,CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out at)&&nowUtc-at.ToUniversalTime()<TimeSpan.FromMinutes(15)&&nowUtc>=at.ToUniversalTime().AddMinutes(-1);
                return fresh?s:null;
            } catch(Exception) { return null; }
            finally { try { File.Delete(file); } catch(Exception) { } }
        }
        internal static void RecordFailure(EbayUpdateFailure f) { try { Directory.CreateDirectory(Updates);File.WriteAllText(FailureFile(f.part),Wire.Json(f),new UTF8Encoding(false)); } catch(Exception) { } }
        internal static EbayUpdateFailure TakeFailure(string part) {
            string file=FailureFile(part);
            try { return File.Exists(file)?Wire.Read<EbayUpdateFailure>(File.ReadAllText(file,Encoding.UTF8)):null; }
            catch(Exception) { return null; }
            finally { try { File.Delete(file); } catch(Exception) { } }
        }
        // A version started after an update that couldn't start says why here (the version waiting for it reads it).
        internal static void RecordStartFailure(string part,string why) { try { Directory.CreateDirectory(Updates);File.WriteAllText(StartFailureFile(part),Wire.Json(new EbayUpdateFailure {part=part,to=Product.Version,atUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture),why=why}),new UTF8Encoding(false)); } catch(Exception) { } }
        internal static string TakeStartFailure(string part) {
            string file=StartFailureFile(part);
            try { if(!File.Exists(file)) return null;var f=Wire.Read<EbayUpdateFailure>(File.ReadAllText(file,Encoding.UTF8));return f==null?null:f.why; }
            catch(Exception) { return null; }
            finally { try { File.Delete(file); } catch(Exception) { } }
        }
        // ---- starting a version (tests replace Start) ----
        internal static Func<ProcessStartInfo,Process> Start=delegate(ProcessStartInfo s) { return Process.Start(s); };
        // again: this version started again after the new one didn't start (--restart-after: it only waits for the lock).
        internal static ProcessStartInfo StartInfo(string exe,string bin,string part,string package,int waitFor,bool show,bool again) {
            var s=new ProcessStartInfo(exe,"--"+part.ToLowerInvariant()+(again?" --restart-after ":" --after-update ")+waitFor.ToString(CultureInfo.InvariantCulture)+(show?" --show":"")) {UseShellExecute=false,WorkingDirectory=bin};
            if(!String.IsNullOrEmpty(package)) s.EnvironmentVariables["EBAYAUTO_PACKAGE"]=package;
            return s;
        }
    }

    // The update steps for one part, as the window shows them. Its own thread does the slow work (check, download, build);
    // the window's timer calls Tick once a second, which switches over at a safe point (on the window's thread).
    internal sealed class EbayAutoUpdater {
        internal enum Stage { Idle, Checking, UpToDate, Available, Downloading, Building, Waiting, Switching, Failed }
        readonly string part;readonly object gate=new object();
        Stage stage=Stage.Idle;string words="",error="",lastWaitWords="";int percent=-1;EbayRelease release;string installed;EbayBuildOutcome built;
        DateTime checkedAt=DateTime.MinValue,waitingSince=DateTime.MinValue,lastAutoCheck=DateTime.MinValue;bool working;
        // The window's hooks. NotSafe: null when it may switch now, else why it waits. Hold: stop taking new work (Cancel
        // undoes it). Resume: what to restore in the new version. Stop: release ports, poll, tray icon and the single-
        // instance lock (on the window's thread). Exit: close this process for good. Note: a line for the log and journey.
        internal Func<string> NotSafe;internal Action Hold,Unhold;internal Func<EbayResumeState> Resume;internal Action Stop,Exit;internal Action<string> Note;
        // Told on the window's thread when a newer version is found the first time.
        internal Action<EbayRelease> Found;
        // The switch itself (the self-tests give their own: it starts processes and named signals).
        internal Action Switcher;
        internal EbayAutoUpdater(string part) { this.part=part; }
        internal Stage Now { get { lock(gate) return stage; } }
        internal EbayRelease Release { get { lock(gate) return release; } }
        internal string Words { get { lock(gate) return words; } }
        internal string Error { get { lock(gate) return error; } }
        internal int Percent { get { lock(gate) return percent; } }
        internal DateTime CheckedAt { get { lock(gate) return checkedAt; } }
        internal bool Busy { get { lock(gate) return working||stage==Stage.Waiting||stage==Stage.Switching; } }
        void Set(Stage s,string w,int p) { lock(gate) { stage=s;words=w??"";percent=p; } }
        // A failure kept from the last update that couldn't start (shown by the window once).
        internal void Failed(EbayUpdateFailure f) {
            if(f==null) return;
            Set(Stage.Failed,"",-1);lock(gate) error="The update to "+f.to+" didn't start: "+f.why+" You are still on "+Product.Version+"."+(String.IsNullOrEmpty(f.log)?"":" Its startup report: "+f.log);
        }
        // Checks GitHub (now: past its caches) on a thread of its own.
        internal void Check(bool now) {
            lock(gate) { if(working||stage==Stage.Waiting||stage==Stage.Switching) return;working=true;lastAutoCheck=DateTime.UtcNow; }
            Set(Stage.Checking,"Checking GitHub for a newer Ebay-auto ...",-1);
            ThreadPool.QueueUserWorkItem(delegate {
                EbayRelease r=null;string why=null;
                try { r=EbayAutoUpdate.ReadFeed(now); } catch(Exception e) { why=e.Message; }
                bool first=false;
                lock(gate) {
                    working=false;checkedAt=DateTime.Now;
                    if(why!=null) { stage=release!=null?Stage.Available:Stage.Failed;error="Couldn't check for updates: "+why;words="";percent=-1; }
                    else if(EbayAutoUpdate.Newer(r)) { first=release==null||release.version!=r.version;release=r;stage=Stage.Available;words="";error="";percent=-1; }
                    else { release=null;stage=Stage.UpToDate;words="";error="";percent=-1; }
                }
                Say(why!=null?"update_check_failed: "+why:EbayAutoUpdate.Newer(r)?"update_available: "+r.version+" on GitHub":"update_checked: "+(r==null?"?":r.version)+" on GitHub (this is "+Product.Version+")");
                if(first&&Found!=null) { try { Found(r); } catch(Exception) { } }
            });
        }
        // By itself: a minute after starting, then every 6 hours.
        internal void AutoCheck(DateTime startedUtc) {
            DateTime last;lock(gate) last=lastAutoCheck;
            if(DateTime.UtcNow-startedUtc<TimeSpan.FromMinutes(1)) return;
            if(last!=DateTime.MinValue&&DateTime.UtcNow-last<TimeSpan.FromHours(6)) return;
            Check(false);
        }
        // Update now: download, check and build on a thread of its own; the switch waits for a safe point (Tick).
        internal void Begin() {
            EbayRelease r;
            lock(gate) { if(working||stage==Stage.Waiting||stage==Stage.Switching) return;r=release;if(r==null) return;working=true; }
            Say("update_started: "+Product.Version+" -> "+r.version);
            ThreadPool.QueueUserWorkItem(delegate {
                try {
                    string folder=EbayAutoUpdate.Install(r,part,delegate(string w,int p){Set(Stage.Downloading,w,p);});
                    Say("update_installed: "+r.version+" unpacked and checked in "+Path.GetFileName(folder));
                    Set(Stage.Building,"Building "+r.version+" on this PC and running its self-tests (this version keeps working meanwhile) ...",-1);
                    var b=EbayAutoUpdate.Build(folder);
                    Order.Require(b!=null&&b.ok,"Ebay-auto "+r.version+" didn't build on this PC: "+(b==null?"no report":b.error)+(b!=null&&!String.IsNullOrEmpty(b.startupLog)?" (startup report: "+b.startupLog+")":"")+". You are still on "+Product.Version+".");
                    Say("update_built: "+r.version+" built and passed its self-tests ("+Path.GetFileName(Path.GetDirectoryName(b.bin??"")??"")+")");
                    lock(gate) { installed=folder;built=b; }
                    // New work is held BEFORE the wait for a safe point begins, so a safe point found at once has it held.
                    var hold=Hold;
                    try { if(hold!=null) hold(); } catch(Exception e) { Say("update_hold_failed: "+e.Message); }
                    lock(gate) { working=false;stage=Stage.Waiting;waitingSince=DateTime.UtcNow;words="Ready to switch to "+r.version+" ...";percent=-1;error=""; }
                } catch(Exception e) {
                    lock(gate) { working=false;stage=Stage.Failed;error=e.Message;words="";percent=-1; }
                    Say("update_failed: "+e.Message);
                }
            });
        }
        // Waiting for the safe point: back to "available" (new work is taken again).
        internal void Cancel() {
            lock(gate) { if(stage!=Stage.Waiting) return;stage=release!=null?Stage.Available:Stage.Idle;words="";lastWaitWords=""; }
            var unhold=Unhold;if(unhold!=null) unhold();
            Say("update_cancelled: the switch was cancelled while it waited (nothing changed)");
        }
        // Once a second, on the window's thread.
        internal void Tick() {
            Stage s;lock(gate) s=stage;
            if(s!=Stage.Waiting) return;
            string why=NotSafe==null?null:NotSafe();
            if(why!=null) {
                lock(gate) words="Update to "+release.version+" waits: "+why+" (nothing is interrupted).";
                if(why!=lastWaitWords) { lastWaitWords=why;Say("update_waiting: "+why); }
                return;
            }
            if(Switcher!=null) { lock(gate) { stage=Stage.Switching;words="Switching to "+release.version+" ...";percent=-1; } Switcher();return; }
            Switch();
        }
        // On the window's thread: save the state, stop, start the new version and wait for it to be up.
        void Switch() {
            EbayRelease r;string folder;EbayBuildOutcome b;
            lock(gate) { r=release;folder=installed;b=built;stage=Stage.Switching;words="Switching to "+r.version+" ...";percent=-1; }
            int me=Process.GetCurrentProcess().Id;
            var resume=Resume==null?new EbayResumeState():Resume();
            resume.part=part;resume.from=Product.Version;resume.to=r.version;resume.atUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture);
            EventWaitHandle ready=null;Process started=null;
            try {
                EbayAutoUpdate.SaveResume(resume);
                try { EbayAutoUpdate.TakeStartFailure(part); } catch(Exception) { }
                ready=new EventWaitHandle(false,EventResetMode.ManualReset,Product.ReadyEventName(part));ready.Reset();
                Say("update_switching: "+Product.Version+" -> "+r.version+" ("+(resume.shown?"window open":"in the notification area")+(part==Product.ReceiverMode?(resume.receiving?", receiving":", receiving paused"):(resume.enabled?", eBay orders on":", eBay orders paused"))+")");
                var stop=Stop;if(stop!=null) stop();
                started=EbayAutoUpdate.Start(EbayAutoUpdate.StartInfo(b.executable,b.bin,part,folder,me,false,false));
            } catch(Exception e) {
                if(ready!=null) ready.Dispose();
                Fail(r,"the new version couldn't be started: "+e.Message,b,started,resume);
                return;
            }
            var wait=new Thread(delegate() {
                bool up=false;string why=null;
                try {
                    var handles=new WaitHandle[]{ready};
                    var clock=Stopwatch.StartNew();
                    while(clock.Elapsed<EbayAutoUpdate.ReadyWait) {
                        if(ready.WaitOne(500)) { up=true;break; }
                        if(started!=null&&started.HasExited) { why=EbayAutoUpdate.TakeStartFailure(part)??"it stopped while starting (exit code "+started.ExitCode+")";break; }
                    }
                    if(!up&&why==null) why="it didn't say it was up within "+EbayAutoUpdate.ReadyWait.TotalSeconds+" s";
                } catch(Exception e) { why=e.Message; }
                finally { try { ready.Dispose(); } catch(Exception) { } }
                if(up) { Say("update_handed_over: "+r.version+" is up (PID "+(started==null?0:started.Id)+"); "+Product.Version+" closes");var exit=Exit;if(exit!=null) exit();return; }
                Fail(r,why,b,started,resume);
            });
            wait.IsBackground=true;wait.Start();
        }
        // The new version didn't start: it is closed (when still there), the failure is kept, and this version starts again.
        void Fail(EbayRelease r,string why,EbayBuildOutcome b,Process started,EbayResumeState resume) {
            try { if(started!=null&&!started.HasExited) { started.Kill();started.WaitForExit(10000); } } catch(Exception) { }
            // What this version was doing, for it to come back the same (the new one may have read it already).
            try { resume.atUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture);EbayAutoUpdate.SaveResume(resume); } catch(Exception) { }
            Say("update_start_failed: "+r.version+" "+why+"; "+Product.Version+" starts again");
            EbayAutoUpdate.RecordFailure(new EbayUpdateFailure {part=part,from=Product.Version,to=r.version,atUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture),why=why+".",log=b==null?null:b.startupLog});
            try {
                // This version again, in the same part, after this process has gone; its window opens to say what happened.
                var again=EbayAutoUpdate.StartInfo(Process.GetCurrentProcess().MainModule.FileName,AppDomain.CurrentDomain.BaseDirectory,part,Environment.GetEnvironmentVariable("EBAYAUTO_PACKAGE"),Process.GetCurrentProcess().Id,true,true);
                EbayAutoUpdate.Start(again);
            } catch(Exception e) { Say("update_restart_failed: "+e.Message+" (start "+Product.Starter(part)+" by hand)"); }
            var exit=Exit;if(exit!=null) exit();
        }
        void Say(string line) { var note=Note;if(note!=null) { try { note(line); } catch(Exception) { } } }
    }
}
