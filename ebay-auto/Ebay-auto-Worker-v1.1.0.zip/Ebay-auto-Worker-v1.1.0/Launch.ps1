param([ValidateSet('Receiver','Worker')][string]$Mode = 'Receiver', [switch]$Show, [switch]$Hidden, [switch]$NoHandOver)
# Ebay-auto: builds (Build.ps1, on this PC) and starts one part, in the notification area (-Show opens its window).
# Receiver: Seb's physical PC (Start-Receiver.cmd). Worker: inside Seb's Remote Desktop session (Start-Worker.cmd); a
# worker-connection.json beside this file is imported once by the worker (then removed from where it was copied to).
# 1.1.0: hands over to a newer installed version of the SAME part (%LOCALAPPDATA%\EbayAuto\packages\current-<part>.txt,
# written by a version once it is up after an update), so an older folder, shortcut or "Start ... when I sign in" starts
# the newest. An installed version that can't build or pass its self-tests here is set aside, and the newest earlier
# installed version of the part is started instead. -Hidden (Start with Windows): no window stays open; a failure is
# shown in a message box.
$ErrorActionPreference = 'Stop'
function Get-PackageVersion([string]$Folder) {
    try { return [version]((Get-Content -LiteralPath (Join-Path $Folder 'VERSION.txt') -ErrorAction Stop | Select-Object -First 1).Trim()) }
    catch { return [version]'0.0.0' }
}
function Get-PackagePart([string]$Folder) {
    try { return ((Get-Content -LiteralPath (Join-Path $Folder 'PART.txt') -ErrorAction Stop | Select-Object -First 1) + '').Trim() }
    catch { return '' }
}
function Show-Failure([string]$Text) {
    Write-Host $Text -ForegroundColor Red
    if ($Hidden) {
        try { Add-Type -AssemblyName System.Windows.Forms; [void][System.Windows.Forms.MessageBox]::Show($Text, ('Ebay-auto ' + $Mode.ToLowerInvariant())) } catch { }
    }
}
function Start-Package([string]$Folder) {
    $arguments = @('-NoLogo', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', (Join-Path $Folder 'Launch.ps1'), '-Mode', $Mode, '-NoHandOver')
    if ($Show) { $arguments += '-Show' }
    if ($Hidden) { $arguments += '-Hidden' }
    # Its own output goes to the screen (Out-Host), so only the exit code is returned.
    & powershell.exe @arguments | Out-Host
    return $LASTEXITCODE
}
$pointer = Join-Path $env:LOCALAPPDATA ('EbayAuto\packages\current-' + $Mode.ToLowerInvariant() + '.txt')
$here = (Resolve-Path -LiteralPath $PSScriptRoot).Path.TrimEnd('\')
if (-not $NoHandOver) {
    try {
        if (Test-Path -LiteralPath $pointer) {
            $target = ((Get-Content -LiteralPath $pointer | Select-Object -First 1) + '').Trim().TrimEnd('\')
            if ($target -and ($target -ne $here) -and (Test-Path -LiteralPath (Join-Path $target 'Launch.ps1')) -and
                ((Get-PackagePart $target) -eq $Mode) -and ((Get-PackageVersion $target) -gt (Get-PackageVersion $PSScriptRoot))) {
                Write-Host ('Starting the newer installed Ebay-auto ' + $Mode.ToLowerInvariant() + ': ' + $target)
                exit (Start-Package $target)
            }
        }
    } catch { }
}
$stage = 'Build and self-tests'
$runtime = $null
try {
    $runtime = & (Join-Path $PSScriptRoot 'Build.ps1') -PassThru
    if (!$runtime -or !(Test-Path -LiteralPath $runtime.Executable)) { throw 'Build did not provide an executable path.' }
    $exe = $runtime.Executable
    $arguments = @()
    if ($Mode -eq 'Worker') {
        $stage = 'Copy the supplied worker connection file'
        $connection = Join-Path $PSScriptRoot 'worker-connection.json'
        if (Test-Path -LiteralPath $connection) {
            Copy-Item -LiteralPath $connection -Destination (Join-Path $runtime.Bin 'worker-connection.json') -Force
            # It holds the worker's private key: once imported it is not kept in the package folder.
            Remove-Item -LiteralPath $connection -Force
            Write-Host 'worker-connection.json is imported now (and removed from this folder).'
        }
        $arguments += '--worker'
    } else {
        $arguments += '--receiver'
    }
    if ($Show) { $arguments += '--show' }
    $stage = 'Start the Ebay-auto ' + $Mode.ToLowerInvariant()
    # "Start ... when I sign in" and the update point at the folder it was started from.
    $env:EBAYAUTO_PACKAGE = $here
    Start-Process -FilePath $exe -WorkingDirectory $runtime.Bin -ArgumentList $arguments
    Write-Host ('Ebay-auto ' + $Mode.ToLowerInvariant() + ' started: see its icon in the notification area (the arrow by the clock).') -ForegroundColor Green
} catch {
    $message = 'Launch failed during "' + $stage + '": ' + $_.Exception.Message
    if ($runtime -and $runtime.StartupLog) {
        try { $message | Add-Content -LiteralPath $runtime.StartupLog -Encoding UTF8 } catch { }
        $message += [Environment]::NewLine + 'Startup report: ' + $runtime.StartupLog
    }
    # An installed update that can't build or pass its self-tests here must not stay the version every launcher hands over
    # to: its pointer is set aside, and the newest earlier installed version of this part is started instead.
    if ($stage -eq 'Build and self-tests') {
        try {
            if (Test-Path -LiteralPath $pointer) {
                $target = ((Get-Content -LiteralPath $pointer | Select-Object -First 1) + '').Trim().TrimEnd('\')
                if ($target -eq $here) {
                    Move-Item -LiteralPath $pointer -Destination ($pointer + '.failed') -Force
                    $mine = Get-PackageVersion $PSScriptRoot
                    $previous = @(Get-ChildItem -LiteralPath (Split-Path -Parent $pointer) -ErrorAction Stop |
                        Where-Object { $_.PSIsContainer -and $_.Name -like ('Ebay-auto-' + $Mode + '-v*') -and $_.FullName.TrimEnd('\') -ne $here -and
                            (Test-Path -LiteralPath (Join-Path $_.FullName 'Launch.ps1')) -and ((Get-PackagePart $_.FullName) -eq $Mode) -and
                            (Get-PackageVersion $_.FullName) -gt [version]'0.0.0' -and (Get-PackageVersion $_.FullName) -lt $mine } |
                        Sort-Object -Property @{ Expression = { Get-PackageVersion $_.FullName } } -Descending)
                    if ($previous.Count -gt 0) {
                        [IO.File]::WriteAllText($pointer, $previous[0].FullName)
                        $message += [Environment]::NewLine + [Environment]::NewLine + 'This version could not start on this PC, so it has been set aside: version ' + (Get-PackageVersion $previous[0].FullName) + ' starts instead.'
                        if ((Start-Package $previous[0].FullName) -eq 0) { Write-Host $message -ForegroundColor Yellow; exit 0 }
                    } else {
                        $message += [Environment]::NewLine + [Environment]::NewLine + 'This version could not start on this PC, so it has been set aside: start the earlier version from its own folder.'
                    }
                }
            }
        } catch { }
    }
    Show-Failure $message
    exit 1
}
