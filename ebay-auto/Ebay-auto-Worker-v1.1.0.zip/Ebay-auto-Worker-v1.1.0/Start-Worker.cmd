@echo off
setlocal
rem Ebay-auto worker (INSIDE Seb's Remote Desktop session, beside COSTAR Sydney): starts in the notification area. Run it again to open its window.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Launch.ps1" -Mode Worker
set "EbayAutoExit=%ERRORLEVEL%"
if not "%EbayAutoExit%"=="0" pause
exit /b %EbayAutoExit%
