# Validation — v2.9.18 — 26 November 2026

## Basis

- **The first try of 2.9.17 on the RDP PC (26 Nov, 13:08–13:11):** Tommy clicked Fill Buffalo page; "nothing happened". His screenshot: the helper (title 2.9.17) with Fill greyed and **Cancel** showing (a fill waiting) but no line under the status; the read was INCOMPLETE ("lines 26+ could not be read … at y=505"); Chrome with a blank Create Consignment page and the extension's button saying "Not set up: Failed to fetch" and "Buffalo page: not ready.". The diagnostics (13:11): 2.9.17 started 12:48 and 13:08, its link on port 8811 with extension 1.0.0 shipped (no copy problem logged); `buffalo_fill offered rows=0 rows_ready=no left=0 unresolved=2` at 13:08:56 and 13:10:37; nothing after either (2.9.17 didn't log how an offer ended).
- **What that shows:** (1) the line under the buttons ("Waiting … n s left", then why nothing was filled) was cut off: drawing the 2.9.17 card at the helper's usual 900 px reproduced the screenshot exactly, Sold wrapped to a second row and the Fill line below the card's edge; (2) the extension had no pair.json: it was loaded from the ZIP copy sent earlier that day, not the helper's folder (Chrome's fetch of a missing extension file fails outright, "Failed to fetch"); (3) 1.0.0's page check gave Chrome no result: in a real Chrome 158, 1.0.0 on a page whose own scripts make the check throw shows exactly "Buffalo page: not ready." What throws on the RDP's page is not known: on the live page in Chrome 158 on this PC (Tommy signed in; read only, nothing typed or changed), both 1.0.0's check and 1.0.1's 'look' found a settled, blank page. The page there runs jQuery 2.1.0 (the stand-in uses 1.12.4), with no content security policy and native Promises.
- 2.9.18 is 2.9.17 (as published, commit 5e1c2aa) plus these fixes. The read, the Buffalo rules, Copy and the fill's own steps are as 2.9.17.

## Changes

- **Source\InvoiceTab.cs:** the buttons in two rows that never wrap (`InvoiceUi.ButtonRows`); the top card built by `InvoiceUi.TopCard`, which keeps each wrapping label no wider than the card's inside (`FitLabels`, when the card's parent starts a layout and when the card's size changes), so the card is always measured at the width it is laid out at; the waiting line adds what the extension said in the last 20 s (`ExtensionSays`); `ExpiredWhy` (now static, with `ExpiredKind`): a version other than the shipped one, whenever seen → Reload; no contact since the click → install from the helper's folder, and a "Not set up" copy is to be removed; the extension's check of the page failed → use Copy Buffalo Details and send diagnostics; the page said why it couldn't take it → a new page; the day log gets `buffalo_ext_seen` (ext, chrome), `buffalo_ext_problem` (the extension's own words) when they change, and one `buffalo_fill` line when an offer ends (`expired why=<kind> ext chrome`, `done outcome boxes rows left=<count>`, `silent`): fixed words and counts, never a reason or a left box (they can name a suburb or an e-mail).
- **Source\InvoiceBuffalo.cs:** `BuffaloLink` keeps `SeenChrome` and `SeenProblem` from signed requests only (after the signature, time and nonce checks), cleaned by `Tidy` (one line of printable characters, ’ — … kept, clipped to 12 and 200); a poll clears the problem; `SeenVersion` is cleaned the same way.
- **BuffaloFill\** (Tempe Buffalo Fill **1.0.1**): fill.js's `tempeBuffalo` is no longer async: `look` answers at once and never throws (an error comes back as its words), `answer` reads the fill's answer left on the page, `fill` is wrapped so a throw before the writes is a refusal with the FILLING banner and mark taken away, and every error is turned into words without throwing (`said`); background.js decides "settled" from one look to the next (the same rows and moving boxes, nothing loading, for 1.5 s; the fill still runs its own 2.5 s check before any write), shows a failed check with Chrome's version on its button and tells the helper (a signed hello with `problem`, when it changes or every 15 s; a remembered port that no longer answers is forgotten and searched again), tells it why a page can't take a job, reads the fill's answer from the page if Chrome hands back nothing (every 0.5 s, up to 25 s), and says plainly when it has no pair.json and which folder to load instead. The popup shows Chrome's version.
- **Source\InvoiceTests.cs:** four 2.9.18 cases. **Source\OnlineTab.cs** (`AutofillForm.Version` "2.9.18 - Fill Buffalo page fixes"), **Build.ps1** (its two version messages), **VERSION.txt:** 2.9.18.

## Tests

- **Self-tests:** 256 + 16 groups pass (the four 2.9.18 cases: what the extension says, signed only, cleaned, clipped and cleared by a poll; the waiting and expired wording for each kind and the day log's end-of-offer words, with a made-up suburb and e-mail never in them; the top card laid out without a window at 826 and 846 px with a long INCOMPLETE status and the longest expired line, nothing cut off; the two button rows fit).
- **The card, drawn:** the 2.9.17 card at 880 and 900 px cuts the Fill line off (laid out with and without a window, the same numbers); 2.9.18's fits at both, and after wider-then-narrower and maximise-and-restore (in a real window).
- **E2e harness** (`Tests\Run-InvoiceE2e.ps1`, 3 Nov map, a made-up window): 111 passed, 0 failed.
- **The page, on the stand-in:** 42 scenarios pass in headless Chrome 158 (2.9.17's 34, and 8 new: look at once on a blank page, not blank, a request out, on hold, a check that throws (look answers with its words; 1.0.0's probe rejects); answer before and after a fill, only for its id; a check that throws after FILLING shows or from the start: refused, untouched, banner and mark gone).
- **The link, end to end on this PC** (background.js in Node against the real BuffaloLink): 35 of 35 (2.9.17's 19 adjusted to settle across ticks, and: no helper contact before 1.5 s settled; a failed check, no answer from Chrome and a page not blank each reach the helper with their words, once; the fill's answer read from the page when Chrome hands back nothing, and failed after 25 s when the page never says; no pair.json: the button names the folder, nothing searched or told; a stale remembered port forgotten and the helper told; the 10 s loading time per page).
- **In a real Chrome 158** (headless, its own temporary profile, the shipped files with only the page address and the test key changed, against the stand-in and the helper's real BuffaloLink): 1.0.1 fills (helper: filled, 6 boxes, 1 row; it learns Chrome 158); on a page whose scripts make the check throw, the button says "the page check failed (made-up page error) (Chrome 158)" and the helper gets the same, nothing taken or typed; without pair.json, the "no key" message; and 1.0.0 on that broken page shows "Buffalo page: not ready." (the RDP's line).
- **On the live Buffalo page** (Chrome on this PC, signed in by Tommy, read only): 1.0.1's look, run twice 1.6 s apart: settled, blank, the same rows, in front; nothing typed, picked or saved.
- **Not done:** no fill on the live Buffalo page, nor in the RDP's Chrome, yet; what makes the check fail there is still unknown (2.9.18 will say it on the extension's button, on the helper's line and in the day log). The read of that invoice was INCOMPLETE ("lines 26+ … at y=505"): not looked at here (it is the read's, not the fill's; a COSTAR map of that invoice is needed).

## Reviews before release

- **First review** (four reviewers: the extension's flow, page safety, the helper's C#, the diagnosis and the tests; a skeptic each): 11 findings, 3 upheld. Fixed: the Fill line could still be cut off by long lines wrapping onto more lines than the card measured (found twice; now `TopCard`/`FitLabels` and a self-test); a stale remembered port kept the extension's words from reaching the helper (now forgotten and searched again; told only once answered). Also taken from rejected ones as cheap improvements: the version advice first whenever another version was seen; a failed check points to Copy Buffalo Details and diagnostics, not another try; the day log says how each offer ended; the 10 s loading time per page; error text that can't throw.
- **Second review, of those fixes** (two reviewers: the helper's card and day log, the extension; a skeptic each): 4 findings, 1 upheld, 3 rejected (150% display scaling: the RDP runs at 96 DPI and that layout is as 2.9.17's; a version seen before a Reload: the advice still leads to a working fill; a navigation racing a page check: measured 0 in about 350 navigations in Chrome 158). Fixed: after maximise and restore (or a window made wider, then narrower), the card kept the height measured for the wider window and cut the Fill line off again, because the labels were fitted only once the card already had its new size. They are now fitted when the card's parent starts its layout, before the card is measured. Checked in a real window with the shipped `TopCard`: at 880 and 900 px, after 1700 or 1050 px and back, and after maximise and restore, nothing is cut off; review 1's version cut it off in each of those six cases. The self-test (laid out without a window) can't show this case, as it doesn't happen without one; the window check is in the scratch harness, not in the package.

# Validation — v2.9.17 — 26 November 2026

## Basis

- **The ask.** Tommy, 26 Nov: "copy to buffalo button will automatically copy paste all the info and pass it to the correct box on the opened buffalo page". His answers: the page is open in Chrome inside the RDP session (with COSTAR and the RDP helper); one click in the helper only; NOT READY: fill what is ready, leave the UNRESOLVED boxes and rows empty and highlighted.
- **The Buffalo page, looked at read only (26 Nov, signed in by Tommy):** `https://portal.transvirtual.com/Portal/Consignment/Create`. Its scripts (tv-detail.js and the page's inline set-up) were saved for reading only; nothing was typed, picked, saved or submitted there. The page's Description list (`#ConsignmentItemDescArray`, 486 characters, every size and weight 0) was read with one plain GET of the page. Receiver boxes: `ReceiverName`, `ReceiverAddress`, `ReceiverAddress2`, `ReceiverIdSuburb` (the id of an entry in Buffalo's suburb list, `GET /Portal/StandingData/SuburbAutocomplete?term=`), `ConsignmentReceiverEmail`, `ConsignmentReceiverContact`, `ConsignmentReceiverPhone`, `ReceiverReference`; items in the jqGrid `#GridItems` (Reference, Qty, Description, Total Weight(kgs)).
- 2.9.17 is 2.9.16 (as published, commit afcdbc3) plus this. The read and the Buffalo rules are as 2.9.16; the Buffalo text's first line and its ALL FILLED line are reworded (they said nothing was sent, which a fill makes untrue: the suburb's name goes to Buffalo's lookup and the details are typed into the page). The fill is built from the same read by the same rules, box by box. Copy Buffalo Details is as 2.9.16 (its "Nothing was sent to Buffalo." is about the copy, and stays true).

## Changes

- **Source\InvoiceBuffalo.cs** (new, under the invoice source guard): `BuffaloJobs.Build` (the job: each receiver box a value or UNRESOLVED as the Buffalo text has it, a value with < or > UNRESOLVED; the suburb with its state and postcode; the rows only when every line is counted (all or nothing, with the reason); never for a read with Ship to not showing, "press Read again", no number, a number with < or >, or refused); `BuffaloOutbox` (one job, offered 45 s, taken once, answered once, withdrawn by another read, Stop all or closing, "didn't answer" after 30 s; the "already sent" guard with how it ended, not set by a refusal); `BuffaloKey` (a 32-byte key kept with DPAPI, written to the extension's folder as pair.json); `BuffaloExtensionFiles` (copies the extension to `%LOCALAPPDATA%\TempeMobileCostar\BuffaloFill`, manifest last, pair.json kept); `BuffaloLink` (its own loopback server on 127.0.0.1:8811–8840, separate from Order Check; every /buffalo/ request signed with HMAC-SHA256 over the method, host and port, path, time, nonce and body hash (±60 s, never signed before this server started, each nonce once), and every answer to a signed request signed over the host and port, that request's nonce, the status and the body hash; /health, the preflight and refusals before the signature check are unsigned, and the extension takes an unsigned answer as no answer; at most 8 connections at once, each closed after 2.5 s; a job only to the extension version this helper ships, from a settled, blank page).
- **Source\InvoiceTab.cs:** **Fill Buffalo page** and **Cancel**, the status line (with why no page took it, and a problem copying the extension), the "already sent" question worded by how that time ended, the hint; another read, Stop and Stop all withdraw a waiting job; Stop all is clickable while one waits. **Source\DesktopUi.cs:** the link starts with the RDP helper and stops first when it closes; Stop all passes its reason (Stop all, or closing). **Source\InvoiceModel.cs:** the Buffalo text's first line "(the helper saves nothing in Buffalo)" and `AllFilled` "… then enter them in Buffalo (or click Fill Buffalo page) and Save it yourself (the helper never saves)."; `InvoicePreview.Done` and `LinesAddUp` internal; `InvoiceRead.ReadAgain`. **Source\InvoiceLive.cs:** sets ReadAgain with the two "press Read again" reasons.
- **BuffaloFill\** (new): the Chrome extension Tempe Buffalo Fill 1.0.0 (Manifest V3, Chrome 106+; permissions storage and scripting; hosts portal.transvirtual.com and 127.0.0.1). content.js only asks the background once a second while a Create Consignment page is visible and focused; background.js finds this user's helper (a signed hello on each port, backing off up to 30 s), checks the asking tab is still the one in front before it takes the job and before it fills, and runs fill.js in that page and document; fill.js checks the page is the page it knows (its libraries, boxes, grid columns and Description list), not on hold, blank and showing, shows FILLING, looks the suburb up in Buffalo's list, checks once more (blank, showing, nothing picked, nothing else changed) and then writes text only in one pass, reads everything back after the page settles, and puts a banner above the form; a refusal before the writes leaves the page as it was. It never clicks Save or submits.
- **Build.ps1:** InvoiceBuffalo.cs in the sources; the BuffaloFill folder required, in the fingerprint and copied with the build; the startup line and the incomplete-folder message say 2.9.17. **Source\InvoiceTests.cs:** nine 2.9.17 cases; the 2.9.16 Buffalo case follows the reworded lines. **Tests\InvoiceE2e.cs:** its guard check counts five Invoice*.cs files. **Source\OnlineTab.cs** (`AutofillForm.Version` "2.9.17 - Fill Buffalo page"), **VERSION.txt:** 2.9.17.

## Tests

- **Self-tests:** 252 + 16 groups pass (the nine 2.9.17 cases: the job against the Buffalo text box by box, with no SKU, price or account in it; UNRESOLVED and < > boxes; rows all or nothing; reads never filled, a number with < or > too; the outbox on a test clock, with the guard after refused, failed, silent and late answers; the link's signatures both ways against a published HMAC-SHA256 test value, wrong key, port, time, body, unsigned, a web page's Origin, Host, replay, take once, results; a request signed before the start refused, a ninth connection closed at once and an idle one at its deadline (wide margins: the self-tests gate the helper's start); a real socket; the key, pair.json and extension copy in a temp folder).
- **E2e harness** (`Tests\Run-InvoiceE2e.ps1` with the 3 Nov map; a made-up window, never COSTAR): 111 passed, 0 failed.
- **The page, on a stand-in (not Buffalo):** a local server serving a copy of the Create Consignment page that runs Buffalo's own tv-detail.js on public jQuery 1.12.4, jQuery UI 1.10.4, jqGrid 4.6.0 and typeahead 0.10.5 builds, with stand-in answers; fill.js loaded into it and called directly in the page's own world. 34 scenarios, all pass: all filled (new1 / new2 first rows, defaults first, slow defaults), NOT READY (left boxes outlined, no rows; typing or picking in a left box keeps NOT READY; a pick on a filled box adds the warning on top), two suburbs, logged out (HTML, redirect), error 500, bad JSON, odd shape, no answer in 8 s, markup in a value or stop shown as text only, not blank, page scripts changed, Description list with sizes, Weight column per item, account default receiver, account on hold, rows that don't add up, an address-book pick or id after the fill, Buffalo changing a box after the fill, a second fill, a pick or typing during the suburb lookup (refused, the person's entry kept), the keyboard in a Weight box before the fill or during the last wait, the tab stopping showing (before the fill or during the lookup), the e-mail token box (outlined where it shows; a typed address refuses).
- **The link, end to end on this PC:** the extension's real background.js (in Node, with a stand-in Chrome) against the helper's real BuffaloLink and BuffaloOutbox: another user's helper (another key) on the first port gives nothing and gets nothing; ours is found, the job taken once, filled in the asking tab's document, and the answer signed back; a newer extension in the folder reloads once and gets no job; a folder not updated: no reload loop, no job; the tab leaving the front during the probe (not taken) or after the take (refused, nothing filled, the helper told); the popup after the service worker stopped (connected, from a signed hello), after the helper closed (not connected, and says so) and with a dead remembered port (forgotten); the helper back after a "not reachable" line, or moved to another port (found again, and the line says so); the back-off kept after the popup. 19 of 19.
- **In a real Chrome, once (26 Nov):** a test copy of the extension (the shipped files; only the page address it works on, pointed at the stand-in, and pair.json with the test's key differ) loaded into a headless Chrome 158 on this PC with its own temporary profile (Chrome's debugging pipe, Extensions.loadUnpacked), against the stand-in page and the helper's real BuffaloLink: the content script ran, the background found the helper over the signed link, took the job, filled the page through chrome.scripting in the page's own world and answered: the helper got "filled" (6 receiver boxes, 1 row), the page showed ALL FILLED with the name, the suburb's id and display, and the row 4 SUV 60 kg with sizes 1 / 1 / 1; the form was never posted (the stand-in's log: the page's own loading requests, one suburb look-up, nothing else).
- **Not done:** no fill on the live Buffalo page and no Save of a filled page (TEST-PLAN 3 and 4 are the first). The extension has never been loaded in the RDP's Chrome, in a Chrome with a window, or from its real folder (TEST-PLAN 2 is the first); its popup has only run in the Node stand-in. Never with two Windows users at once.

## Reviews before release

- **First review** (five reviewers: Buffalo page safety against the portal's own script, the data rules, the link's security on a shared RDP server, C# robustness and the build, the extension's lifecycle; each finding tried by a skeptic): 20 findings, 19 upheld, 1 rejected (by design: the invoice's totals line among the stops on the banner). One important, fixed: typing in a box left for a person turned the NOT READY banner red and dropped its list (now only boxes the fill wrote are watched, and a NOT READY banner keeps its list with the warning on top). Fixed too: the page checked again right before the writes (a pick or typing during the suburb look-up refuses, untouched; the FILLING banner shows during the look-up), the keyboard taken out of the form first, ReceiverIdAddressPoint watched, an account on hold refused, the e-mail token box outlined where it shows, a refused fill no longer counted as filled, the invoice number's < or >, a request signed before the helper started refused, at most 8 connections each with a deadline, Stop all withdraws a waiting fill, a problem copying the extension shown, why no page took a job, the Buffalo text's two lines that said nothing was sent, the tab in front checked again before the take and the fill, the popup after the service worker stopped, the search back-off after the popup.
- **Second review, of those fixes** (three reviewers; a skeptic each): 9 findings, 8 upheld, 1 rejected (by design: Copy's "Nothing was sent to Buffalo." is about the copy). Fixed: the tab stopping showing during the fill's own probe or look-up (refused, untouched), a box clicked during the last wait, the popup's status checked by a signed hello every time, the "already sent" question worded by how that time ended, Stop all's and closing's own reasons, Stop all clickable while a fill waits; the docs said the Buffalo text was unchanged. A self-test with tight timings that could have stopped the helper starting on a busy PC was given wide margins.
- **Third review, of the second's fixes and of these notes against the code** (two reviewers; a skeptic each): 9 findings, 7 upheld, 2 rejected (Copy's line again; the day log's lines are counts only, as said). Fixed: the popup could show Connected over a stale "not reachable" line, or miss a helper back on another port (it now searches again and says what it finds). The notes corrected: the extension had never been loaded in Chrome (it now has, once, as above; never in the RDP's), a page that isn't blank never takes the job (the helper times out, the extension's button says why), an incomplete read is filled as NOT READY, a logged-out page is only noticed through the suburb look-up, what is signed, and that once a page has taken the job only the tab stopping showing stops it.

# Validation — v2.9.16 — 24 November 2026

## Basis

- **The ask.** Tommy, 24 Nov, after the Buffalo portal was looked at (read only; nothing created, edited or saved there): fill only Receiver Information (everything from Y; Address = the first line, Address 2 blank; phone mobile, then bus, then home; reference = the Repair Order number) and Consignment Items (reference = the Repair Order number; SUV over 215 wide, PASSENGER below, TRUCK R17.5 / R19.5 / R22.5, CARTON wheels and small boxes; weights 15 / 8 / 40 / 20 kg; one row per type). His answers: 215 is PASSENGER; "R9.5" meant R17.5; Description is Buffalo's drop-down; a small box is one carton per line.
- **Buffalo's Description list** (the Create Consignment page's item list, read 24 Nov): 4X4, AT, BALE, CARTON, Item, LIGHT TRUCK, Oversize Pallet, PALLET, PAS, SKID, SUV, TRACTOR (LRG / MED / SML), Trolley, TRUCK, Xtra Large Tractor. No PASSENGER: PAS is used. (Past bookings used 4X4 for 15 kg tyres; the rule's SUV is in the list, so SUV is used.)
- **The Repair Order number** is the invoice's own number: COSTAR's Repair Order numbers are 8 digits (07497644 on 22 Oct, 07450421 on 2 Oct in the project's records), the Invoice's number box holds 8 characters, and 40 of 40 Buffalo receiver references checked were 8 digits 0760xxxx. The "(Order WO...)" label is another number and isn't used.
- 2.9.16 is 2.9.15 (as published, commit f289a69) plus this. Only `InvoicePreview.Buffalo`, its new `BuffaloRules` and `InvoicePreview.Unresolved` changed (plus InvoiceLive.cs's made-up test text): the Buffalo box, what Copy copies, the end of the review (which repeats them) and the day log's `unresolved=` count (now the UNRESOLVED items as written, 0 when all is filled). The read, the status line, the log's other fields, Sold and the source guard are as 2.9.15. The helper's own Website copies are as in 2.9.15 (the iPhone app commit 7e4cd08 of 24 Nov changed the GitHub Pages copies, which need its app/ folder; the helper serves its own copies to the desk PC and Order Check).

## Changes

- **Source\InvoiceModel.cs:** new `BuffaloLine` (with `Fitting` and `Wheel` flags) and `BuffaloRules`: the types and weights; `TyreType` (a 17.5 / 19.5 / 22.5 truck rim, or the width in mm: never a load index such as 121R 10PR, a flotation size or a decimal-comma truck rim; two different sizes on a line: none); `NothingToSend` (every word a charge's, TYRE / WHEEL / TRUCK / 4X4 / a joining word, a Y / N / YES / NO / COMPLETE / DONE flag or a number, 1/2 included; a slash between letters splits, as in FIT/BAL; a width and aspect such as 265 70, a size written as one number such as 2055516, or a truck rim apart such as 11-22.5 isn't a charge); `Classify`, which takes `WholesaleRules.KindOf` (tyre / wheel / tube / other / unsure) and `WholesaleRules.Tyre`, then counts a line only on positive evidence: a tyre's line with no part's, service's, goods' or wheel's words, no set or count words, nothing joined on (WITH, +, &, ON, C/W, INC, PLUS, a spaced / ...; INC or C/W VALVE, M+S, M&S, W/L, ON/OFF, W/ KEVLAR, a model's or year's + are fine), not a credit / return / hire / quote / back order / later delivery, not a press-on or solid tyre, no ring or run-flat band named by a tyre size, one size; a wheel's line with no tyre, tyre size, package, part's (after its stud count and INC / WITH caps, rings, nuts), service's or goods' words, no set, count or joined words (a two-tone finish, an offset and a stud pattern are fine), no tyre's brand or tread, no lock, locking or side ring, not a press-on tyre (a three-part size, POB, PRESS ON, or SOLID with no stud pattern or WHEEL / RIM / ALLOY / MAG), and a rim size, wheel's word or finish; a small box's line with no service's (REPAIR beside a kit or plugs, and BALANCE beside weights, excepted), wheel's or tyre's (a single WHEEL / RIM / TYRE that says what the part is for excepted), package's, goods' words or tyre size, and not a lock, locking or side ring, a beadlock or run-flat ring, kit or insert, or any ring the small-box ring words don't name; a truck size KindOf doesn't read only when every other word is a truck tyre's; a plain charge; never a negative line. Everything else is UNRESOLVED with its reason; the qty rules. `InvoicePreview.Buffalo` rewritten (the receiver from Y with the state / postcode and Ship Via notes, rows per type, how each line was counted, the note lines pointed to by number (their words left out), a fitting, balancing or labour charge beside tyres or wheels as one UNRESOLVED (sent fitted?), the lines vs the invoice's Tax In total, UNRESOLVED counted as written, NOT READY ("1 item" / "n items") or `AllFilled`); `Unresolved` takes that count; `QtyLabel` and `WeightText` removed, `AllFilled` added. **Source\InvoiceLive.cs:** its made-up Buffalo text says "1 item unresolved".
- **Source\InvoiceTests.cs** (CRLF, as in 2.9.15): the 2.9.15 Buffalo case replaced by five 2.9.16 cases (the full text and the receiver; tyre types; each line's class, with the reviews' failing inputs; the lines vs the total, the notes and the count; Tommy's 4 SUV + 4 TRUCK example); the possible-freight, Ship Via and caller's-reason checks follow the new wording.
- **Source\OnlineTab.cs** (`AutofillForm.Version`), **Build.ps1** (the startup line and the incomplete-folder message), **VERSION.txt:** 2.9.16. **Tests\InvoiceE2e.cs:** its Buffalo checks follow the new text (and the note line pointer).

## Reviews before release (24 Nov 2026)

- **First review:** four reviewers (the classification rules; the text and receiver; release consistency and docs; safety and invention), each finding tried by one or two skeptics, then a completeness check: 30 findings, 25 upheld, plus 3. Fixed: wheel nuts, spacers and caps named by a stud pattern or with WHEEL counted as one CARTON per piece (24 nuts, 480 kg) and ALL FILLED; goods with a service's word (repair plugs, mounting paste, balancing beads, a balancer) dropped as nothing to send; fitting lines and sensors naming a tyre's size counted as tyres; wheel and tyre packages without a tyre size counted as wheels, and with no rim size counted as tyres; 9.5R17.5, 8R19.5, 11 R22.5 never TRUCK; 35X12.50R20 121R 10PR read as 121 mm (PAS); 295/80R22,5 as SUV; ALL FILLED when the lines didn't add up to the invoice total; flap + valve and rim band kit lines counted as cartons; no note for an empty Ship Via or a missing state / postcode; the count taken from the text (customer words could change it); the docs' "as 2.9.15" and UNRESOLVED list; TEST-PLAN pointing at 2.9.15's old Buffalo check; InvoiceTests.cs saved with LF (now CRLF again); a stale README hash in PACKAGE-SHA256.json (regenerated). Not upheld: tractor / OTR metric sizes going by width (the rule as given), the motorcycle wording (clarified anyway), the one-booking-per-shop note (seen in Buffalo).
- **Second review, of the fixes** (three reviewers: regressions over a corpus of 372 real-style lines, the fixed text, docs and tests with 37 mutation reverts; two skeptics each): 12 findings, all upheld. Fixed: the new truck-size path counted truck wheels, packages and repairs (STEEL WHEEL TO SUIT 11 R22.5) as TRUCK tyres with ALL FILLED; new charge words (REPLACEMENT ...) dropped goods such as REPLACEMENT AIR HOSE, and goods with an unlisted noun (BALANCING COMPOUND) were still dropped: nothing to send now needs every word to be a charge's; truck wheels and "10 STUD" / "ALLOY WHEELS SET" lines counted as one small box; FIT & BAL, TYRE REPAIR, REGROOVE with a tyre's size counted as tyres; plain wheels with "6 STUD" or "INC CENTRE CAPS" needlessly UNRESOLVED; lines adding up only to Tax Out taken as complete (the map's line totals include GST, so a GST-sized line could be missing); "has no state" said of a state not read; "1 items"; the docs' wheel-hardware wording; two self-test gaps (BEAD LUBE 285/75R16, TYRE REPLACEMENT).
- **Third review** (three reviewers: silent miscounts over the 372-line corpus plus 351 new lines, the text and its counter, docs and tests with 32 mutation reverts; two skeptics each): 16 findings, all upheld. Fixed: wheel and tyre packages naming the other part by brand (ROH 17X8 + BFG KO2, 265/70R17 BFG KO2 ON KING KAOS) or saying PACK / COMBO counted as one part only; set and pair words (SET OF 4, PAIR, X4, (4 PCS)) and two same-type sizes counted by COSTAR's qty 1; the truck-size path counting INFLATION, CASING CREDIT and other unlisted words as TRUCK (it now needs only truck tyre words, and only for sizes the wholesale rules don't read); credit, refund, hire, loan, customer-supplied and back-order lines counted; hub rings, spigots and PCD converters named by a stud pattern, and wheel services (powder coat, refurb), counted as wheels; the small-box service check narrowed by the second round (TPMS INSPECTION, WHEEL NUT DISCOUNT counted); balancing beads by tyre size counted as tyres once BEADS left the goods list (the plural is back); balance weights, programmable TPMS sensors and common charge phrasings (FITTED & BALANCED, LABOUR 0.5 HRS, MERCHANT FEE, a Y / N in Size / Complete?) needlessly UNRESOLVED; the suburb note naming only one of two gaps; ten mutation survivors (each now has a self-test); doc wording (TRUCK "nothing else", charge words, "1 item", an unread Email / Contact). A negative line is now UNRESOLVED too.
- **Fourth review** (three reviewers: silent miscounts over the earlier corpora plus 419 new lines and 19 whole invoices through the real reader, the text and its wiring, docs and tests with mutation reverts; two skeptics each): 17 findings, all upheld. Fixed: package joiners C/W, INC / INCL / INCLUDING, PLUS and a spaced / (and a tyre's brand on a wheel's line with no joiner) counted one part only; a part's word turned a size-less wheel, tyre or wheel-and-tyre kit (KING KAOS WHEEL + NUTS, 4X4 TYRE + VALVE, WHEEL & TYRE KIT) into one small box for the whole line; truck lock rings, side rings and run-flat inserts counted as one small box; press-on tyres (21X7X15) counted as wheels; count words 4@$250, 2PC, 4X, 4 OFF, QTY 4, a wheel's 2PR missed; DROP SHIP, DIRECT FROM SUPPLIER, ETA, TO COME, PRE ORDER, BO counted; needless UNRESOLVED on M&S, W/KEVLAR, PRIMACY 4+ XL, ON & OFF ROAD, GOLD WITH POLISHED LIP, a spaced 17 X 8, WELD RACING, NITROGEN CAPS; a credit in brackets or with CR counted (stopped only by the cross-check); wheels, tyres and a FIT & BAL line on one invoice (a fitted package) ending ALL FILLED; note lines not pointed to; three round-3 mutation survivors and other new guards without a self-test; TEST-PLAN step 6 and the docs' word lists not matching the code; 205/55R16 X4 called a possible package. A before/after run over all the reviews' corpora (1,933 lines) then caught and had fixed three of the new rules' own slips (KMC KM235 read as the tyre tread KM2; KO2 @ $250 EA read as a count; 2 X 17X8 read as a three-part size) and a few more needless UNRESOLVED (GRABBER X3, BMW X5, ENERGY SAVER+, MIXED SERVICE, FIT/BAL, MAG WHEEL NUTS). Left as UNRESOLVED (safe, needless): a nuts or spacer line whose Size box holds a stud pattern, a hubcap set, a PCD converter with a measure in mm. Not caught: a package or set written in words none of the lists know (README says so).
- **Fifth review, of the fourth round's fixes** (three reviewers: before/after over the 1,933 corpus lines plus about 290 new attack lines and 18 whole invoices on both builds, the text and its counter with 2,000- and 10,000-character descriptions, docs and tests with more mutation reverts; two skeptics each): 20 findings, all upheld, none a blocker. Fixed: the new + rule let a + glued to the word before it through (265/70R17 BFG KO2+ KING KAOS, (+ROH ASSAULT)) — + before a word joins again, and a model's or year's + (ENERGY SAVER+, SUV+, 2015+) is taken out first; FIT/BAL's slash split made TYRE 265/70/17 + FITTING and TRUCK TYRE 11/22.5 FITTED nothing to send (now only a slash between letters splits, and a spaced width and aspect isn't a charge); side rings named by a tyre size counted as tyres; MAG WHEELS NUTS INCLUDED counted as one small box; 17 X 4 read as a rim width, not a count; a split rim C/W LOCK RING counted as wheels (a lock or side ring on a wheel's line is now UNRESOLVED); a solid tyre with a metric size (200/50-10 SOLID) counted; flange nuts, beadlock bolts, a run-flat TPMS sensor, centre and poly rings, SUIT JEEP WRANGLER, MINI COOPER, Mickey Thompson wheels, TWO TONE, SIX SPOKE, FOUR SEASON, 2PC FORGED, +20 OFF, 6 X 139.7, * 92Y, PLUS TL / RUN FLAT, INC GST, SOLID BLACK and BLACK / BRUSHED FACE needlessly UNRESOLVED; LABOUR, TYRE CHANGEOVER and NITROGEN FILL beside wheels and tyres now ask whether they were sent fitted too; the plural note pointer, the fitting words, the tyre names, more not-sale words and the unspaced + had no self-test; the stale manifest; VALIDATION's Changes section. A run over the corpora after these fixes changed only solid forklift tyres (now UNRESOLVED) and LEVY 205 55 16 (now UNRESOLVED: a size beside a charge).
- **Sixth review, of the fifth round's fixes** (three reviewers: rounds 5 and 6 compared over the corpora, the fifth review's attack lines and new ones, whole invoices on both builds, long-description timing, docs and tests with more mutation reverts; two skeptics each): 22 findings upheld, 1 rejected, none a blocker. The fifth round's loosening had gone too far in places, now made exact: SOLID / POB beside a colour or STEEL counted press-on tyres as wheels (POB and PRESS ON are never a wheel's; SOLID only beside a stud pattern or WHEEL / RIM / ALLOY / MAG); the narrowed lock-ring rule let BEADLOCK KIT, RUN FLAT KIT and BEADLOCK BOLTS & RING through as one small box (BEADLOCK and RUN FLAT are rings again unless bolts, nuts or a TPMS sensor follow, and any ring the small-box ring words don't name, LOCKING RING included, is UNRESOLVED); dropping WRANGLER and MICKEY THOMPSON from the tyre names let WRANGLER DURATRAC and ATZ / MTZ P3 packages count as wheels (WRANGLER is back except after JEEP or SUIT, with DURATRAC, ATZ and MTZ); plural TYRES with valves (4X4 TYRES VALVES INCLUDED) and a size-less ALLOY or MAG with its centre rings counted as one small box; a run-flat band on a tyre's line counted as tyres; a count hidden by the new exceptions (4 X 199 after a stud pattern, *4EA, 4PC FORGED, 2015+YOKO, SAVER+KING). Also: INC. GST, LABOUR 1/2 HR, 12 X 4 and 13 X 5 trailer rims and WHEEL CENTRE RINGS no longer needlessly UNRESOLVED (SIX LUG, 1PC FORGED and a TPMS SENSOR SEAL RING were kept counted by the new rules and given self-tests; STUD left the number-word exception, where it did nothing); a tyre's size written as one number (TYRE 2055516 FITTED) isn't a charge; stale comments; self-tests for POB and PRESS ON on a tyre's line, the new tyre names, more width-and-aspect pairs, the narrow-rim rule, RUN-FLAT INSERT, the small-box ring words, RIM NUTS and a model's or year's + before a word. Over 2,432 corpus lines plus 3,284 of the sixth review's own lines, every change from round 5 is one of these.
- **Seventh review, of the sixth round's fixes** (three reviewers: rounds 6 and 7 compared over all the corpora and attack lines, whole invoices, long-description timing, docs and tests with more mutation reverts; two skeptics each): 22 findings upheld, none a blocker, most nits. Fixed: a count before a price that is also a PCD number (KING 17X8 6/139.7 BLACK 4 X 150, QTY 4 X 150) was still hidden — a stud pattern is now a real stud count and PCD pair (5/105, 5/118, 6/132, 8/180 added; 4/150 isn't one) and only the first on a wheel's line is taken out; README's 'before a price' and the sixth bullet's 'no longer needlessly UNRESOLVED' list were wrong (corrected); press-on tyres by the brand SOLIDEAL or a spaced three-part size (16 X 6 X 10.5); RUN FLAT TPMS INSERT, RUN FLAT SENSOR + INSERT, R/F KIT, BEADLOK KIT and a run-flat band on a wheel's line counted; SPLIT RING 20-22 counted as hub rings (a ring named by its bores now needs a hub ring's decimal bore); a split rim C/W RING counted as wheels; a size-less ALLOY or MAG joined by & / AND or with its size between still counted (the rule is now: a single ALLOY or MAG with something joined on and no part's word before it, so WHEEL NUT MAG C/W WASHER and LOCK NUTS ALLOY WITH KEY are small boxes again); WRANGLER as a vehicle (SUIT JK WRANGLER, WRANGLER JL, JEEP JL WRANGLER, WRANGLER/GLADIATOR) needlessly a package; HUB-CENTRIC, CENTRIC, SPACER and GROMMET rings needlessly UNRESOLVED; a loose ring now has its own reason; a steel wheel with SOLID CENTRE and a stud count needlessly UNRESOLVED; TRUCK TYRE 11-22.5 FITTED was nothing to send; the fitting question names all its words; test gaps (TYRON and BAND halves, each ALLOY joiner, TIRES, BEADLOCKS, RUN FLATS, 10PC FORGED, STEEL WHEEL 20 X 4, hub and spigot rings, BEADLOCK NUTS, 17X8 SOLID ALLOY BLACK). Over 7,176 corpus and attack lines (1,735 of them the seventh review's), every change from round 6 is one of these or a rare, safe UNRESOLVED (a stud pattern written twice, 13X4.5 X 4 STUD, BEADLOCK BOLT KIT).

## Checks run (24 Nov 2026, after the fixes)

- **Build.ps1's invoice guard** over Source\Invoice*.cs: 42 patterns, no hit (it caught a comment reading "sells (" while the fixes were made; reworded). **csc** (C# 5, Build.ps1's 58 files and arguments): exit 0.
- **Self-tests:** 243 + 16 groups passed, 0 failed (2.9.15: 239 + 16).
- **Mutation reverts** (each fix of the fourth to seventh rounds undone on its own, on copies of Source, compiled and self-tested): 45 of the fourth round's, 31 of the fifth's, 31 of the sixth's and 22 of the seventh's; every one is now caught by a self-test (those that weren't at first got self-tests: QTY 4, CROSSCLIMATE + XL and a bare RING in the fourth round, a centre ring with no bores in the fifth, POB on a wheel's line with a stud pattern in the sixth, a dashed HUB-RINGS in the seventh; LOCKING RING is caught now that a loose ring has its own reason, and SOLIDEAL's second listing, which did nothing, was dropped).
- **E2e harness** (`Tests\Run-InvoiceE2e.ps1` with the 3 Nov map; a made-up window, never COSTAR): 111 passed, 0 failed. (One run before it had 110 / 1: in the 60-line scenario the made-up window's recorder saw one event that wasn't a scroll among 44, with the PC in use; the scroll code is unchanged since 2.9.15, and the run straight after was clean.)
- **Not checked:** a live COSTAR invoice, and entering the result in Buffalo. Combining several invoices into one booking isn't done.

# Validation — v2.9.15 — 20 November 2026

## Basis

- **The ask.** The spec "Invoice read (dry run)" of 20 Nov 2026: read the COSTAR Invoice that staff have already opened, "so its information can prepare Buffalo (freight carrier) delivery labels". "This release: READ + PREPARE ONLY. Never sell, change status, save, type, book freight, submit to Buffalo or print." The only input ever allowed: scrolling the line grid's own scroll bar past 25 lines, and back. Sold exists only as a permanently disabled button.
- **Geometry:** the only Invoice ever mapped (3 Nov 14:47:35, "Invoice  Branch 1  Tempe Tyres Sydney", rect [423,20,1074,1040]; customer words masked in the map). Matched by labels and relative geometry, as the wholesale reader does, never by pixel constants alone.
- 2.9.15 is 2.9.14 (as published) plus the Invoice tab. No online, eBay, Repair Order or wholesale rule changed.

## Changes

- **Source\InvoiceModel.cs (new, pure):** `InvoiceField` / `InvoiceLine` / `InvoicePage` / `InvoiceRead`; `InvoiceReader` (the caption rule `^Invoice\s+Branch\s+(\d{1,3})\s+(.*)$`; identity, header, dates, X, Y and "other field" boxes by label-above-box; the lines by heading x, with the headingless line total, the hidden values, note lines, kinds product / freight (Item F) / possible-freight / note; `Page`, `Merge` by COSTAR's line numbers 1..N with identical duplicates only; totals by x with the unlabelled ones; the cross-check; freight's four states; `Fingerprint`); `InvoicePreview` (Review, Buffalo, Status, LogLine and all the wording); `InvoiceDryRun.SellingEnabled = false`.
- **Source\InvoiceLive.cs (new):** `IInvoiceScreen` (reads plus `ScrollGrid`) and its Win32 implementation (COSTAR's top-level windows by process, owned windows, a snapshot with every box's text, the selected tab by MSAA, `GetScrollInfo`, `GetGUIThreadInfo` for the keyboard focus, WM_VSCROLL by `SendMessageTimeoutW` to the grid panel); window finding with Expected invoice #; the paging driver (scroll, re-read, merge, stop at the maximum, scroll back, check page 1 again); the consistency fingerprint at start and end; locks (`EntryCoordinator.TryBeginRead` for the whole read; `CostarInputLock` and the RoOpenWatch quiet moment before every scroll; Stop between scrolls); `InvoiceRun` (Cancel / Running / Summary); `InvoiceScreenRules` (the allowed member list) and `InvoiceSourceGuard.Patterns`.
- **Source\InvoiceTab.cs (new):** the WorkerForm partial: the Invoice page (Ui.Card / Title / Hint / Row like WholesaleTab), the buttons, the preview and Buffalo boxes, the 1 s update; `InvoiceUi.SoldButton()` (disabled, no handler); `InvoiceClipboard` (ported from Ebay-auto's RoClipboard: STA, set, read back, 3 tries 250 ms apart, an 8 s limit after which nothing more is set).
- **Source\InvoiceTests.cs (new):** the Invoice self-test groups, registered in **Source\MobileTests.cs** next to WholesaleTests.
- **Source\DesktopUi.cs:** the Invoice page added last (after Wholesale) and built; the day-log tab name "invoice"; UpdateInvoiceTab in the timer; StopInvoice in Stop all; Stop all enabled while a read runs; the status chip "READING" for the invoice read.
- **Source\OnlineTab.cs:** `AutofillForm.Version` "2.9.15 - Invoice read (dry run)". **VERSION.txt:** 2.9.15.
- **Build.ps1:** 2.9.15 strings, the four new files in `$requiredSources` (58 files), and the Invoice source guard (42 patterns) before the compile.
- **README.md, TEST-PLAN.md, VALIDATION.md:** this section on top. **PACKAGE-SHA256.json:** regenerated for the 2.9.15 tree.
- **Tests\ (new, test-only, not in the package):** `Run-InvoiceE2e.ps1`, `FakeInvoice.cs` (a made-up Invoice window built from the 3 Nov map, with a recorder of every event it receives), `FakeInvoiceData.cs`, `InvoiceE2e.cs` (the harness).

## Review

A review of the first build found 16 problems; all 16 were fixed, none skipped:

1. The guard missed MSAA's default action and child selection (`DoDefault`, `SelectChild`, `accSelect`): added.
2. Generic SendMessage wrappers could carry another message: only the GetScrollInfo and ScrollMessage externs and the `SendMessageTimeoutW` entry point are allowed; ScrollMessage only with `WmVScroll` (= 0x0115); `SendNull` only with 0.
3. A using-alias or a press helper in another class could get round the guard: `using X=` banned; the classes that can press COSTAR allow-listed member by member (Native's reads, `Runner.Decoration`, `CostarWindows.IsCostar`, `WholesaleOrderReader.Beside/Snapshot/Tab`), every member of Msaa, Win, RoWip, RoEngine, the Wip classes, Costar, WholesaleRun, GridReader and Unattended banned, and reflection. Gap left: calls from InvoiceTab.cs to other WorkerForm methods (a partial class) can't be caught by a regex.
4. Scrolling didn't check COSTAR's keyboard focus: `IInvoiceScreen.KeyboardFocus` (read only); a box in the line list (or the grid) holding the keyboard, or a focus that can't be told, makes lines 26+ INCOMPLETE without a scroll. A focus elsewhere on the invoice doesn't block (narrowed on purpose: it isn't under the scroll).
5. A line-number label unread or not digits dropped its line silently: the screen now fails.
6. A disabled scroll bar with a leftover range made every invoice INCOMPLETE: disabled now means "everything fits" unless a number over 25 shows or line 25 is filled.
7. and 9. Freight said "none" while an Item wasn't read: now "Freight could not be read: the Item of line n could not be read ...".
8. Rebill to boxes were filed as header fields: boxes on tab pages not shown are skipped, with an observation.
10. A freight amount or zero was shown unqualified while lines were incomplete: an amount says "among the lines read only"; zero becomes unreadable.
11. An unreadable total showed as empty: now "not read".
12. An empty F line total said "not a number": now "is empty".
13. A failed Copy left the old "Copied" line: cleared first, "Not copied: <why>" on failure (UI code: no automated test).
14. The clipboard could still be set after the 8 s limit: a shared given-up flag stops it.
15. A COSTAR window title reached the day log through the paging reason: the log gets fixed words; the title is only shown.
16. The docs still described 2.9.14: this section.

## Checks performed here (no COSTAR here)

- **Compile:** Build.ps1's exact csc arguments (`/target:winexe /platform:anycpu /langversion:5 /codepage:65001`, the qr.js resource, the 10 references) over its 58 `$requiredSources`: exit 0, 0 errors, the same 3 warnings as 2.9.14 (CS0028 in MobileRunner.cs, CS0649 twice in Updater.cs).
- **Build.ps1's Invoice source guard** (its own block, run by PowerShell over Source): passes over InvoiceLive.cs, InvoiceModel.cs, InvoiceTab.cs and InvoiceTests.cs; 42 patterns, 0 hits.
- **--self-test:** 239 test groups passed + Order Check 16 groups passed, 0 failed (255 PASS lines, 0 FAIL). "No COSTAR window was opened or modified."
- **E2e harness** (`Tests\Run-InvoiceE2e.ps1` with the 3 Nov map; a made-up window, never COSTAR): **111 passed, 0 failed**, by scenario: 0 the recorder itself 2; 1 the map invoice 19 (read complete, every X / Y / header field, 2 lines with the 23 empty ones ignored, totals 298.18 / 29.82 / 328.00 add up, no freight, no scroll, the recorder saw nothing); 2 three lines (F, note) 12; 2b possible freight 5; 3 sixty lines 9 (lines 1..60 once each, freight on page 2, 13 scrolls over 3 pages, back at 0, only scroll events); 3b sixty lines left scrolled down 9; 3c 26 lines 4; 3d 60 lines left at the bottom 4; 3e exactly 25 lines 4; 4 broken paging 7 (INCOMPLETE, no duplicate, freight not claimed, scrolled back); 5 Rebill to tab 7; 6 owned pop-up 3; 6b invoice window disabled 2; 7 expected number 3; 8 changed mid-read 4 (INCOMPLETE "the invoice changed while it was read"); 9 read twice 4 (identical Review, Buffalo and status, for the map invoice and for 60 lines); 10 Copy Buffalo Details 2 (set and read back on STA, 56 lines); 11 Sold button 5 (disabled, 0 handlers, const false, IInvoiceScreen exactly the allowed list); 12 Build.ps1 guard 5 (Build.ps1's list equals `InvoiceSourceGuard.Patterns`, every planted forbidden call caught); cleanup 1 (no fake left running).
- **Version:** 2.9.15 in VERSION.txt, `AutofillForm.Version` and Build.ps1; the other "2.9.14"s in Source are history comments and test names.
- **PACKAGE-SHA256.json:** every file of the 2.9.15 tree except itself and the test-only Tests folder (2.9.14's package had no Tests folder), in 2.9.14's format (sorted, two-space indent, LF); each hash checked against its file.
- The helper ran only as `--self-test` and inside the e2e harness.
- **Package (23 Nov 2026):** `Tempe-COSTAR-Helper-v2.9.15.zip` is this tree minus the test-only Tests folder. Before upload it was extracted the way the updater does: every `PACKAGE-SHA256.json` hash matched, the four launchers were there, and the extracted Source compiled with Build.ps1's arguments and passed 239 + 16 self-test groups. A separate pre-upload review (regression, package and feed, release text) found no blocker; its documentation corrections are in this package.

## Not verified live (no COSTAR here)

- That a live COSTAR Invoice matches the 3 Nov map on the RDP PC (labels, the number box, the Ship to tab, the heading panel, the totals), and on other branches.
- **Paging past 25 lines:** WM_VSCROLL to the grid panel, COSTAR's reaction, the range of its disabled scroll bar, the scroll back. Never seen on a real COSTAR; only against the made-up window.
- The keyboard-focus check (`GetGUIThreadInfo`) and the quiet-moment watch against a real COSTAR and a person at the PC.
- The date panels' words (Order / Ship / Invoice Date): read only if COSTAR gives them, else "not read (date panel)".
- The selected tab told by MSAA on a real COSTAR (Ship to / Rebill to / Contacts / Notes), and real owned windows (an item lookup, a message) over an invoice.
- A real F line, a real note line, an invoice of more than 25 lines, two Invoices open in two COSTARs.
- That nothing changes in COSTAR (status still Open, no save prompt) after a live read.
- The clipboard copy on the RDP PC (over RDP's clipboard sharing) and the WinForms tab itself (the harness never builds the WorkerForm; the failed-Copy wording has no automated test).
- Every Buffalo rule listed as UNRESOLVED in the README: none is decided.

---

# Validation — v2.9.14 — 18 November 2026

## Basis

- **The ask.** 18 Nov 08:37, Tommy, with the 08:36 diagnostics: "check if it will clear this issue". The issue: at 08:15 on the RDP PC (2.9.11), a new customer's online delivery stopped in the account step: "No COSTAR account was made for this new customer, and the order stopped: the magnifier opened a COSTAR window that isn't its customer search ("Search ...")". Answer: 2.9.13 wouldn't clear it (it doesn't touch that step, and lets more orders reach it); 08:45: go on with the fix.
- **What the diagnostics show** (that run, masked): the magnifier pressed 6.694 s into the run; the step decided at 6.897 s, 0.20 s later. The window it saw then (6.961 s): 35 controls, 3 labels, buttons Close, Partners..., Outstanding only, Labor, Tires, Parts, Branches..., Print Results: no Add new, Cancel or OK, and not yet the words "Search for an Existing Customer". The same window at 7.138 s (0.44 s after the press): 58 controls, 10 labels, Add new among the buttons. The 17 Nov maps show it settled (Add new, Search, Cancel, OK greyed, Clear). Nothing was made in COSTAR: no Add new, no OK, nothing recorded in `new-accounts.dat`.
- 2.9.14 is 2.9.13 (e0b22b3, never uploaded) plus this fix. No wholesale rule changed.

## Changes

- **NewAccount.cs:** `WindowLooks` (pure): `Print` (one look at a window: each control's handle, kind, shown or not, usable or not, and its words) and `WhenComplete` (look again every 0.15 s until the window is known; give up only when it has stayed the same for 1.5 s without being known, at the step's limit for its windows (10 s), or when it closed or couldn't be read).
- **Runner.NewAccount.cs:** `Complete<T>` (`WhenComplete` over the step's own fully-read look, `Steady`), with a `new_account` event: known or not (and why), at which look, after how long, how many controls. Used for COSTAR's customer search after the magnifier and for its new-customer form after Add new. The form's title is still checked first, as before.
- Version 2.9.14 - New account window fix. Ebay-auto 1.1.5 has the same shared files.

## Review

- **Safety unchanged:** nothing is pressed on a window until the same readers as 2.9.11 recognise it (the search's words, one Add new, one Cancel, one OK; the form's title and every box). A window that isn't recognised is still left for a person. Only the moment of the decision moved, to after COSTAR has finished drawing.
- **The waits:** at 08:15 the window was complete within 0.44 s. 1.5 s without a change is far longer than COSTAR's drawing steps there; a window that keeps changing is given up at 10 s, the step's existing limit for its windows.
- **Elsewhere in the step:** after Cancel on the form, a customer search coming back was already looked at again in a loop (unchanged). A window's title is set when Windows creates it (the search's was there at the first look at 08:15), so the form's title check stays where it was.

## Checks performed here

- **Compile:** C# 5 against the five reference sets: 0 errors, the usual 3 warnings. The C# 5 scan: only lambdas flagged in the tests, and the old Runner.Online false hit, as before. The CS0135/CS0136 checker: nothing.
- **Self-tests:** 196 + the 4 that need Windows = 200. 2.9.13's 194 + 4 all still pass. Order Check 16/16. The 2 new groups:
  - COSTAR's customer search part-drawn as at 08:15 (no words, Add new, Cancel or OK; a Close button), then complete: known at the second look. A pause in the drawing shorter than 1.5 s: still known. Drawn at once: known at the first look. A window that isn't the search: given up once unchanged for 1.5 s. One still changing: given up at 10 s. One that closes: given up at once. What counts as a change: a control added, shown or hidden, greyed, renamed, or replaced.
  - COSTAR's new-customer form drawn in two steps: known at the second look. One laid out differently, once drawn: only its Cancel (as before).
- **Deliberate bugs, all caught:** 7 of 7: a decision at the first look, no settling, settling at once, shown/hidden not seen, words not seen, no time limit, the closed window's reason lost.
- **End-to-end** (they don't reach the account step: no COSTAR here): delivery states 15, the page's Auto 25, as before.
- **Clock** moved to 7 points: every group passes except the usual clean-up one at the 5 later points, as in every round.
- **Install replay** with the Updater the PCs run (2.6.0's install code) over 2.9.13, 2.9.12, 2.9.11, 2.9.10, 2.9.9 and 2.6.12: PASS (103 files each, every file matching PACKAGE-SHA256.json).
- **The upload set:** latest.json, the helper ZIP and `website/testrun.html` (the same file as the release's `OnlineOrders/Tempe-Orders-COSTAR.html`; unchanged since 2.9.13). No Tests folder; no tokens, webhooks, keys, pairing, connection or record files.
- **Scans:** the 18 historical report-number hits, as in earlier rounds, none in 2.9.14's lines. No order number from the dry runs or comparisons. Only made-up phones, e-mails, WO and eBay numbers. The 23 Oct example buyer: none. Its place names, which are public towns, appear only in the address list.

## Not verified here (no Windows or COSTAR here)

- How long COSTAR takes to draw its customer search and new-customer form on the RDP PC, every time: the next new customer's `new_account` events show it (looks, ms, controls).
- The rest of the account step live after Add new (the form, OK, the account on the Repair Order): not reached on 18 Nov.

---
# Validation — v2.9.13 — 18 November 2026 (not uploaded: part of 2.9.14)

## Basis

- **The ask.** 18 Nov 02:20, Tommy (2.9.12 and Ebay-auto 1.1.3 compiled on Windows, their self-tests passing): the missing-state fallback ran inside `MaybeMakeAccount`, after the order had passed the checks that need a state, so online deliveries (refused by the Tempe Orders page and `OrderModel.Validate`) and eBay orders (refused by `costar_send.js` and `EbayModel.Validate`) never reached it. Fix it across the real sending and receiving paths in both products: resolve a missing state before the checks that require it, with the existing suburb + postcode lookup, without simply removing validation. Full names and abbreviations recognised; a supplied state never replaced; billing and delivery each by their own suburb and postcode; only an unambiguous match, never NSW or the store; the delivery safeguards kept when an address still can't be resolved; pickups that can't qualify for an account go on without one; diagnostics say where each state came from. The account trigger, X → account → Y and everything else unchanged. Tests through the real page, extension and receiving checks, not only the lookup.
- 2.9.13 is 2.9.12 (d6fce74, never uploaded) plus this fix. No wholesale rule changed.

## Where a missing state was refused (before 2.9.13)

| Path | Sender | Receiving check | 2.9.12 |
|---|---|---|---|
| Online pickup | Tempe Orders page: no state needed | `Order.Validate`: no state needed | Reached the account step (its lookup) |
| Online delivery | `makeOrder`: both states required (Send to COSTAR stayed off) | `Order.Validate`: both states required | Never reached the helper |
| eBay | 404 extension `build()`: "the state was not found" | `EbayOrder.Validate` at the receiver, the RDP side and the entry | Never sent |

## Changes

- **OrderModel.cs:** `Order.ReceivedState` (one address's state on receipt: written → its code, never replaced; a written one that isn't a state is left as it is; none → `AuPlaces.Resolve` by that address's suburb and postcode; one already looked up stays `lookup` when checked again). `Validate`, for a delivery, finds the billing and the delivery state this way before its state check, puts each found state in, and records where it came from in `Customer.StateFrom` / `Shipping.StateFrom` (internal fields: never serialised, so never sent, saved or taken from a sender). Not found: refused with the old message plus which address and why. `PageOrder.Read` (the Online orders tab's own reading of the page's copy, moved out of the tab unchanged so the end-to-end test runs it). `Order.LookedUp` (the preview's words).
- **EbayModel.cs:** `EbayOrder.AddressState` (the same rules on the one address). `Validate` checks the state through it (a written one that isn't a state: the old message; none and not found: "The address has no state, and it couldn't be looked up …"). `EngineOrder` gives billing and Ship to that state and its source. The order itself is never changed, so the receiver keeps it as sent and its content hash (duplicate and changed-details checks) is as before.
- **NewAccount.cs / Runner.NewAccount.cs:** `NewAccount.AccountState` (the account step's state: a state looked up on receipt counts as `lookup`), `StateFromWords`, `Runner.NoteAddressStates` (`billingState`, `deliveryState` in the run's details, the `address_states` event, review.json `BillingStateFrom`/`DeliveryStateFrom`), called by `Runner.Run` and `RunEbay` after their checks.
- **OnlineTab.cs:** reads the clipboard through `PageOrder.Read`; the preview adds "(state looked up from the suburb and postcode)" after such an address.
- **The Tempe Orders page** (`transfer-core.js` and its copy in the page): a delivery address with no state is sent; a state that isn't one of the eight, or no street, suburb or postcode, still stops it.
- Version 2.9.13 - State lookup for deliveries and eBay. Ebay-auto 1.1.4 has the same shared files, and the 404 extension 1.5.1 sends an eBay order with no state.

## Review

- Reviewed here (no separate reviewer). Decided while building:
  - **Where the state is found:** at the receiving check itself (`Order.Validate`, `EbayOrder.Validate`), so every path that checks an order (the tab's clipboard reading, Fill, the entry engine; the eBay receiver, the RDP side's claim, the entry) finds the same state, before the check that needs it.
  - **eBay orders are never changed:** the receiver stores and hashes the order as sent. Writing the looked-up state into it, or adding a field, would change the hash of every order and break the duplicate check across the update. The state is worked out again wherever it is needed (the same list, the same answer).
  - **Where a state came from is never on the wire:** internal fields only, so a sender can't set it (tested with a sender that tries).
  - **Pickups are not looked up on receipt:** a pickup's billing state goes into X for every customer, so finding one on receipt would change X for existing customers. Its state stays the account step's (2.9.12).
  - **Mixed versions:** a 2.9.12-or-older helper refuses a delivery with no state from the 2.9.13 page, as before. A 1.1.3-or-older Ebay-auto worker refuses an eBay order with no state that a 1.1.4 receiver took. Update both parts together.

## Checks performed here

- **Compile:** C# 5 against the five reference sets: 0 errors, the usual 3 warnings. The C# 5 scan: only lambdas flagged in the tests and the old Runner.Online false hit, as before. The CS0135/CS0136 checker: nothing.
- **Self-tests:** 194 + the 4 that need Windows = 198. 2.9.12's 188 + 4 all still pass. Order Check 16/16. The 6 new groups:
  - a delivery's billing and delivery states, each by its own suburb and postcode (Tempe 2044 → NSW, Fitzroy 3065 → VIC, and swapped); checked again, still `lookup`; written ones (" nsw ", "Victoria", a QLD the list puts elsewhere) kept as their codes;
  - refusals: two states (Texas 4385), a suburb not under its postcode, a misspelt suburb (never the postcode's state), a 3-digit postcode, a written state that isn't one (the old message exactly), neither address found;
  - a pickup isn't looked up on receipt; the account step's state and its source for pickups, deliveries looked up on receipt and written ones; the words;
  - the page's copy through `PageOrder.Read` (the tab's own reading), where the state came from never in the JSON and never taken from a sender who sends it;
  - an eBay order: the order and its content hash unchanged by its check; the RDP side's check and the entry on the order as the receiver hands it over (looked up, the account step's source too); a full name; a written state kept; two states, not found, a written state that isn't one, control characters refused;
  - the receiver's queue: an order with no state queued as sent, a second send the same order, one that can't be found never queued.
- **Deliberate bugs, all caught:** 15 of 15 in the C#: a looked-up state no longer `lookup` when checked again, the delivery looked up by the billing address, a written state replaced, no reason on a refusal, NSW when not found, the eBay order changed by its check, the entry given the raw state, the source lost in the entry, the account step not knowing a state was looked up on receipt, an eBay order with no state found accepted, the tab's reading skipping the checks, an eBay written state that isn't one accepted, the preview's words gone, a written state not taken as its code, the diagnostics' words. 2 of 2 in the page (no state refused at the page again, in both copies; no state check at all).
- **Node:** the Tempe Orders page 17 (16 + a delivery with no state sent as it is; one that isn't a state, or no street, suburb or postcode, refused there). Job Card 59, Repair Orders 11, startup 9, the package check: all pass.
- **End-to-end, delivery states** (new; `page_order_harness.ps1`, `e2e_delivery_states.py`, kept outside the repository like the other end-to-end tests): the real Tempe Orders page in Chromium, a made-up website, orders found with the page's own search and sent with its Send to COSTAR button; the copy put through the helper's own reading (`PageOrder.Read`, then checked again as Fill and the entry engine check it). 15 checks:
  - the 2.9.12 page: Send to COSTAR stayed off for a delivery with no billing or delivery state ("COSTAR autofill unavailable: Check the … street, suburb, state and postcode");
  - the 2.9.13 page sends every order, a delivery with no state as it is;
  - the helper takes it: billing NSW from TEMPE 2044 and delivery VIC from FITZROY 3065, each `lookup`, still after Fill and the entry engine; the account step's source `lookup`; the preview's words;
  - TEXAS 4385 (two states) and TEMPE 3044 (not under it): refused with which address and why;
  - written states (codes, and "New South Wales" / "Victoria" on its own line): from the address, exactly as from the 2.9.12 page;
  - a pickup in TEXAS 4385: taken as before, no state; the account step finds none, so no account and the order goes on.
- **The page's Auto end-to-end** (pickups): 25 checks as before, each pickup with its state.
- **Clock** moved to 7 points: every group passes except the usual clean-up one at the 5 later points, as in every round.
- **Install replay** with the Updater the PCs run (2.6.0's install code) over 2.9.12, 2.9.11, 2.9.10, 2.9.9 and 2.6.12: PASS (103 files each, every file matching PACKAGE-SHA256.json).
- **The upload set:** latest.json, the helper ZIP and `website/testrun.html` (the same file as the release's `OnlineOrders/Tempe-Orders-COSTAR.html`). No Tests folder; no tokens, webhooks, keys, pairing, connection or record files.
- **Scans:** the 18 historical report-number hits, as in earlier rounds, none in 2.9.13's lines. No order number from the dry runs or comparisons. Only made-up phones, e-mails, WO and eBay numbers. The 23 Oct example buyer: none. Its place names, which are public towns, appear only in the address list.

## Not verified here (no Windows, COSTAR or website here)

- A real website delivery with no state on an address: how the website shows it, and the page reading it as "no state".
- A looked-up state typed into X's and Ship to's State, and COSTAR keeping it through the final checks.
- An eBay buyer with no state (see Ebay-auto 1.1.4).

---
# Validation — v2.9.12 — 18 November 2026 (not uploaded: part of 2.9.13)

## Basis

- **The ask.** 18 Nov 00:44, Tommy: keep the page change that passes a pickup's billing state; the state written in the customer's address first, by full name or abbreviation, ignoring case and extra spaces, reusing the existing wording recognition; missing: looked up by suburb + postcode in a reliable Australian address dataset and used only when it gives one state confidently; never from the postcode's first digit, the fitting store or COSTAR's default NSW; no match or ambiguous: no account, Account# blank, the order goes on; never overwrite a supplied state; every other mandatory-field check unchanged; diagnostics say whether the state came from the address or the lookup, and why a lookup failed; the trigger and X → account → Y kept, no empty-Y trigger; every order path (online pickups, deliveries, eBay) in both products.
- **What it builds on:** the 18 Nov 00:15 diagnostics (a new-customer pickup, `not made: missing: state`: the Tempe Orders page passed no state for pickups, and none of the 111 saved new-customer pickups had one) and the page fix of 18 Nov (ddf22af).
- **The address list.** Checked here: (a) Matthew Proctor's *Australian Postcodes* (GitHub, 18,559 rows, last major update 6 Sep 2025: Australia Post's localities and postcodes, community-maintained, "public domain" according to its compiler): chosen. (b) A G-NAF-derived list (postcodes-au, 2024): not used, because it gives every place under a postcode the first state it met, so the shared postcodes are wrong (Queanbeyan 2620 as ACT, Hall 2618 as NSW, Barooga 3644 as VIC). (c) Two ABS-based lists: not used (one postcode per suburb, or one suburb per postcode). G-NAF itself (data.gov.au) couldn't be downloaded here.
- 2.9.12 is 2.9.11 (9e8edd4) plus the page fix (ddf22af) plus these. No wholesale rule changed.

## Changes

- **AuStates.cs:** `AuState.Code` (the eight codes and full names; case, spaces and dots don't matter, as the eBay extension's `stateCode`); `AuState.Place` (a place's name as the list holds it: upper case, apostrophes gone, & as AND, other marks as spaces, Saint/Mount/North/South as ST/MT/NTH/STH); `AuPlaces` (the list, read once; `States(suburb, postcode)`; `Resolve`: a written state is taken as written (its code; one that isn't a state: none); none written: looked up only with a 4-digit postcode and a suburb, and only when that suburb under that postcode is in exactly one state; otherwise none, with why); `StateFound`.
- **AuPlaceData.cs**, generated by `Tests/make-au-places.py` from commit eda59e4: 18,490 places with their states under 3,175 postcodes. Removed rows (17) and two garbled rows (a locality holding another address) are left out.
- **The step:** `NewAccount.WithState`. `MaybeMakeAccount` resolves the state first, then decides as before over the customer with it. It records where the state came from once the step is looked at (`NoteState`). A looked-up state (or a full name's code) goes into X's State (`PutMapped`) and into the order before the magnifier. No state: "missing: state; the state: why".
- **Diagnostics:** `new_account_state` event, `newAccountState` in the run's details, `NewAccountState` in review.json (Runner.Online.cs, Runner.Ebay.cs).
- **The Tempe Orders page:**
  - `makeOrder`: pickups carry `billingAddress.state` (ddf22af).
  - `splitAddress`/`addressState`: the state only at the end of the suburb's line (a code or full name; dots, a comma before it, a trailing "Australia") or on a line of its own. The list's four places that end in a state's name (`PLACES_ENDING_IN_A_STATE`) are never split. Else, as before, a code anywhere.
  - A full name is no longer left in the suburb, and a state's name inside a place's name is no longer read as the state.
- THIRD-PARTY-NOTICES.txt: the list's source. Version 2.9.12 - State lookup for new accounts.

## Review

- Reviewed here (no separate reviewer). Found while building:
  - The G-NAF-derived list gets shared postcodes wrong (above), so it isn't used.
  - The community list's Removed rows and two garbled rows are left out.
  - The page's old reading took a state's name anywhere, so "VICTORIA PARK WA" and "VICTORIA POINT" were both read as VIC. Now a state counts only where it is written as the state.
  - A full state name at the end of the suburb's line stayed in the suburb. It is now taken off.
  - "MOUNT VICTORIA" and "PORT VICTORIA" would have been split as "MOUNT"/"PORT" + VIC by the new end-of-line rule. They never are now: the list has four such places, and the page names them all (checked against the list by its test).
  - A retry's "OK pressed before" result would have lost its check by hand if the state's reason were added to it. The reason is added only to a "missing" result.
- **Left as asked:** a written state that the list puts elsewhere is noted in the diagnostics only. It isn't stopped, because a supplied state is never overwritten.

## Checks performed here

- **Compile:** C# 5 against the five reference sets: 0 errors, the usual 3 warnings. The C# 5 scan passes on the new files. The CS0135/CS0136 checker finds nothing.
- **Self-tests:** 188 + the 4 that need Windows = 192. 2.9.11's 185 + 4 all still pass. Order Check 16/16. The 3 new groups:
  - the written state: codes and full names, case, spaces and dots, never replaced;
  - the lookup: other spellings, shared postcodes decided by suburb, a suburb in two states, not found, nothing to look up by, never from the postcode alone;
  - the list itself: every line, the eight states only, `Place` round trip, the shared postcodes.
- **Deliberate bugs, all caught:** 12 of 12 in the C#: postcode only, two states accepted, a written state replaced, full names not read, dots kept, the spellings dropped, apostrophes kept, a field lost in the copy, the 4-digit check gone, an unreadable written state looked up over, the postcode's single state used for a suburb not under it, a different listed state not noted. 9 of 9 in the page: full names at the end, the places ending in a state, the old reading first, the state on its own line, the country, the pickup's state (both copies), dots, the comma after the suburb.
- **Node:** the Tempe Orders page 16, including the page's own address functions run on the cases above, its places ending in a state checked against the helper's list, and the pickup's state. Job Card 59, Repair Orders 11, startup 9, Order Check's own: all pass.
- **The page's Auto end-to-end:** made-up website, the real Order Check server and the helper's page side: 25 checks, each pickup arriving with its state.
- **Clock** moved to 7 points: every group passes except the usual clean-up one at the 5 later points, as in every round.
- **Install replay** with the Updater the PCs run (2.6.0's install code) over 2.9.11, 2.9.10, 2.9.9 and 2.6.12: PASS (103 files each, every file matching PACKAGE-SHA256.json).
- **The upload set:** latest.json, the helper ZIP and `website/testrun.html` (the same file as the release's `OnlineOrders/Tempe-Orders-COSTAR.html`). No Tests folder; no tokens, webhooks, keys, pairing, connection or record files.
- **Scans:** the 18 historical report-number hits, as in earlier rounds, none in 2.9.12's lines. No order number from the dry runs or comparisons. Only made-up phones, e-mails, WO and eBay numbers. The 23 Oct example buyer: none. Its place names, which are public towns, appear only in the address list.

## Not verified here (no Windows, COSTAR or website here)

- The website's real billing address for a pickup: whether it shows the state, and in which form.
- A looked-up state typed into X's State, COSTAR's form taking it from there, and the account's State in COSTAR.
- How often a pickup has no state written, and suburbs the website spells another way than Australia Post.

---
# Validation — v2.9.11 — 17 November 2026

## Basis

- **The asks.** 17 Nov 14:13, Tommy: check whether generating an account number for a new customer is fully mapped (trigger: a new order, the phone entered, COSTAR's "Customer not found", X's Account# blank; the sequence X, magnifier, Add new, the mandatory fields checked, OK, the account confirmed, Y, continue), without implementing. 15:18, his decisions: every order-entry workflow of both the Tempe helper and Ebay-auto where every mandatory detail is there; the same trigger; a detail missing: no account, Account# blank, the order goes on as before (the form cancelled if open), never invented; COSTAR's defaults and ticks unchanged; the two rare no-account endings unchanged; missing details before creation told apart from an uncertain result after OK, never created again blindly. 15:25: build it in both; after an uncertain OK never again for that order, a retry keeps an account on the Repair Order, goes on with Account# blank only when it is confirmed blank and the Repair Order is ready, and leaves a dialog or uncertain state for him; X checked again after the account with COSTAR's Account# and name formatting kept and the order's details restored, then Y; every mandatory field including the phone; every word of the name, repeats too, no split that loses or adds words; phone jobs and edits of existing Repair Orders unchanged; every feature and diagnostic kept.
- **What it builds on:** the 17 Nov 14:43 diagnostics (10 maps of the sequence on Tempe, lengths only: Customer Not found; the magnifier's "Search for an Existing Customer" with nothing copied from X; Add new's "Add new cash customer" filled from X; Cancel straight back with nothing made; OK back to the Repair Order with Account#, Terms and Edit... filled and Y copied from X, Y's Account# blank) and the saved runs (269 of 271 new-customer runs went through Customer Not found; every completed new-customer pickup, delivery and eBay order had a name of two words or more, street, suburb, state and postcode). Project note `claude/37-New-Customer-Account-Mapping.md`.
- 2.9.11 is 2.9.10 (f77a254) plus these. No wholesale rule changed.

## Changes

- **NewAccount.cs (pure):** `Words` (every word, repeats kept), `SplitKeeps` (First + Last, or Last + First, exactly the name's words), `SameWords` (the same words in any order: COSTAR's name after OK); `Missing` (a name of two words, street, suburb, state, postcode, a phone of 8 digits); `NoticeOnly` (Customer Not found and nothing else: no account list, no "none in any branch", no recovery, no cancelled search); `Decide` (in this order: an account on the order, not Customer Not found, switched off, direct presses off, no order number, missing details, the record unreadable, OK pressed for the order before, make); `PanelProblems` (X against the order before the magnifier); `FormProblems` (the form's boxes against X and the order: the split, address, city, state, postcode, the phone in one of the four phone boxes, a personal service file chosen); `Uncertain` (after OK); `SamePrint` and the loose print mark; `LeftUnsure`; `NewAccountSearch` and `NewAccountForm` (read by label, parent and place; State/Province from the panel inside its drop-down; exactly one of each, the buttons enabled); `NewAccountLog` (`new-accounts.dat` through `PrivateFiles`: part of a SHA-256 of the order number, the state "pressed" / "unsure" / "made" / "not sent", the time; a year; the newest 5000; an unreadable file never written over).
- **Runner.NewAccount.cs:** `MaybeMakeAccount` (the decision, then the record), `MakeAccount` (X checked, the magnifier by `Selectors.AccountLookup`, the search, Add new, the form read and checked, nobody at the PC, the form read again, the record written, OK by `Direct.PressLater` with its window in front), `AfterOk` (20 s: the form gone, nothing over the order, the order in front and enabled, Account# a number at two looks 400 ms apart, the same name's words, the same phone), `CancelBack` (Cancel, then the order in front with nothing over it; a search that comes back cancelled once), `LeaveIt` (stops, nothing more pressed), the unsure stop (`NewAccountUnsureException`, the record "unsure", a picture of what's in front), and the retry pieces (`AccountLeftUnsure`, `AfterUnsureStop`, `SteadyAccount`).
- **The hooks:** Runner.Online.cs and Runner.Ebay.cs call `MaybeMakeAccount` after X for a customer the lookup didn't find; made: X again (`FillOnlineHeader(true,false)`: Account# and name kept, the rest put back, no second Time in pass), then Y as before. A resumed Repair Order after an unsure stop reads Account# with `SteadyAccount`. The stop print: `StopPrintNow` / `SameAsStop` (`Selectors.OrderPrint(…, loose)`: Account# "*", the name's words sorted, Ship Via "-", no Ship to). review.json: `NewAccount`.
- **Guards:** while the step runs (`accountStep`) nothing else answers or cancels a COSTAR window (Check's late-notice OK, `AnswerPopup`, `TryChooseFirstAccount`, `RecoverCustomerUi`); `AccountChooser` never takes the new-customer form for a list of accounts; `RecoverCustomerUi` and `TryChooseFirstAccount` leave the form alone by its title at any time. After an unsure mark ("pressed" or "unsure"), every later attempt of that order leaves COSTAR's windows over it for a person (`AnswerPopup` and Check stop with `LeftForYou`).
- **The lookup:** `LookupCustomer` records Customer Not found alone (`notFoundShown`, `branchesCancelled`, the recovery and search-cancel counts); nothing else in it changed.
- **Settings:** `AppSettings.newAccounts` (true; an older settings file without it: true), the tick and its hint on Files & settings, `NewAccount.On`, `setting_new_accounts` in the day log.
- Version 2.9.11 - New customer accounts.

## Review

- Reviewed here (no separate reviewer). Found while building: COSTAR's new-customer form would have been taken by the account chooser for a list of accounts (and its OK pressed) had a person opened it during a lookup → excluded, and nothing else answers or cancels it; the step's guard set before its first checks would have changed the wording of an unrelated early stop → set just before the magnifier; a retry after an unsure OK whose lookup no longer said Customer Not found, with Account# blank → the record decides (no account, a CHECK BY HAND); the second pass over X after an account would have run Time in again and could have added its check twice → not run again; on a retry after an unsure OK a COSTAR message left over the order would have been answered by the usual late-notice OK (2.6.11) → left for a person, the retry stops saying so; the loose print leaves Account# out, so a retry would have read it once → read the same twice with the Repair Order free; OK that couldn't be sent was kept as "pressed" → "not sent" (never tried again, but COSTAR's windows aren't held back for it).
- **Departures from the 17 Nov design note:** after OK, Y holding X's name is recorded (diagnostics), not required, and "Edit..." isn't read: the account number appearing, steady, with the form gone and the same name and phone is what decides; Y is filled with the order's own delivery details next anyway. A false "unsure" stops the order for a person, and its retry keeps the account.

## Checks performed here

- Compiled at C# 5 against the five reference sets: 0 errors, the usual 3 warnings. C# 5 scan: only lambdas flagged and the old Runner.Online false hit, as before. The old compiler's one-meaning-per-name rule (CS0135/CS0136) with the checker: nothing.
- Self-tests: 185 + the 4 that need Windows = 189 (2.9.10's 172 + 4, all still passing, and 13 new groups: the name's words and the split; the details from the order; the decision and its order; X against the order; the magnifier (never Ship to's, never a stray button); the customer search; the form read box by box and never taken for a list of accounts; the form's boxes against the order; after OK; the record; COSTAR's windows left for a person after an unsure mark; the retry's loose print, and 2.9.10's full print pinned; the setting's default); Order Check 16/16. The real geometry of the 17 Nov maps, with made-up words.
- 26 deliberate bugs in the new code (the split by sorted words, an empty First or Last allowed, the phone not required, a one-word name, the decision's order, the record ignored, the postcode not checked, an unread personal-file choice allowed, one look at Account#, the "none in any branch" ending allowed, the form taken for a list of accounts, the magnifier by place only, Account# in the loose print, the loose print compared strictly, the record kept for ever, the key not normalised, any phone accepted, the name's word order ignored before the magnifier, the name not compared after OK, the switch off by default, an account on the order ignored, State/Province from the wrong panel, "made" or "not sent" holding windows back, "pressed" not holding them back, the mark's missing state, an old mark counted): all 26 caught.
- Clock moved to 7 points (now, +15 h, +30 days, +1 year, the end of daylight saving, 2 days back, +3 years): every group passes but the clean-up one at the 5 later points, as in every round before (it compares file times with the moved clock).
- Node: Job Card 59, Orders page 12, Repair Orders 11, startup 9; Order Check's C# 5 scan, Discord 8, order rules 12, Firebase and GitHub sharing: all pass.
- Install replay with the Updater the PCs run (2.6.0's install code) over 2.9.10, 2.9.9, 2.9.8 and 2.6.12: PASS (101 files each, every file matching PACKAGE-SHA256.json). The upload set is latest.json and the helper ZIP; no Tests folder; no tokens, webhooks, keys, pairing, connection or record files (`new-accounts.dat` included); the 18 historical report-number hits as in earlier rounds, none in 2.9.11's lines (checked against every number in the saved diagnostics, 28 Oct to 17 Nov); no order number from the dry runs or comparisons; WO and eBay numbers, phones and e-mails only made-up ones.
- Ebay-auto 1.1.2 (the same account code) was built and tested beside it: its VALIDATION.md.

## Not verified here (no Windows or COSTAR here)

- The helper's own presses on the magnifier, Add new and OK (BM_CLICK with the window in front), and how long COSTAR takes to open each window.
- COSTAR Sydney (the maps are from Tempe; the same COSTAR 5.7.159.0 on the same server).
- The form's boxes read live (State/Province's inner panel, the personal service file's tick by MSAA), and the account after OK as the helper reads it (Account#, the name's formatting, the email).
- Terms after the account (and after Rebill to EBAY), Ship to on a pickup after COSTAR's copy, Ship Via SHOP and Customer Waiting on such a pickup.
- An unsure stop and its retry, a message after OK, `new-accounts.dat` on Windows (DPAPI).

---
# Validation — v2.9.10 — 15 November 2026

## Basis

- **The asks.** 15 Nov 10:43, Tommy (after the 10:13 diagnostics: four comparisons, two usable): compare against a complete, valid baseline, and say so when the final one is used because the first failed; separate matching results, actual differences, unread results and tests not reached (unread stock never a stock change, an unrun test never a failure); an incomplete starting list waited for and retried within a bounded time, the COSTAR screen and the list's readiness validated before going on, and the reason given when recovery fails; valid measurements from interrupted runs kept, with the approaches and orders left untested stated; All four described as the best-supported approach from those tests; the evidence for a PC-activity stop checked, and "can't be established" said rather than a cause guessed; a broader sample (several tyre lines, wheels) for the next comparison, both 2.9.7 passes and the BUF filter completed, and the cases the sample covers stated. 11:17: confirmed by Tommy: after Sell and then Cancel the order disappears from Wholesale Orders; option A: All four, search by order number for further dry runs and as the intended live lookup; each number search within the intended Sydney Wholesale Orders view, the exact order number verified, an order no longer eligible or present skipped, the checks after opening kept; a deliberately wrong row position may test the fallback but is labelled as not reproducing a Sell → Cancel removal; dry run only.
- **What it builds on:** the 10:13 diagnostics (09:31 run: the first 2.9.7 pass read 108 of 354 rows and stopped, so the report had no reference and said "best: 2.9.7"; 09:52 run: stopped in the by-number pass by Windows input that wasn't the helper's, WO… cut short and classed "changed in COSTAR", the made-up number "NOT handled"); the shrinking-list analysis (`claude/31-Shrinking-List-Lookup-Notes.md`: the direct row keeps the pass's places; with 3 or more orders gone above an order every later lookup reads the list in full until the 3-minute re-read).
- 2.9.10 is 2.9.9 (6247bf9) plus these. No wholesale rule changed.

## Changes

- **Approach:** `WholesaleSettings.approach` defaults to `all-number`; `approachSet` and `WholesaleSettingsFile.Adopt`: 2.9.10 sets All four, search by order number once (both helpers), logged; a later choice is kept.
- **Search by number (`WholesaleRun.SearchNumber`):** before the words go in, `ViewProblem` (the same COSTAR on Branch 1 by `CostarWindows.Main`, its main window enabled, on "Orders yet to be filled", the same list or the same list made again), "Include Filled Orders" unticked, the boxes empty or holding the run's own number alone (`WholesaleSearchBox.OnlyDocument`); the number set and read back; after Search, the boxes holding exactly that number (`OnlyNumber`); the row showing exactly that number; not shown, Search once more; still not, skipped as not listed. Shown: `StillToOpen`, the row as listed now through the pass's own rules (`Sample` for the comparison, `WholesalePlan.Queue` for checking): no longer to be opened, skipped (nothing opened; `wholesale_not_eligible`). The checks after opening are unchanged.
- **The list (`Refresh`, `ListGap`, `ListCheck`, `Recover`, `InView`):** a read counts the list's children it went through (`WholesaleList.Read/ReadLean(…, out children)`); taken when COSTAR Sydney shows the list, it shows a table (none yet: taken as still loading, `ReadComplete`), two table counts 0.5 s apart agree, the read went through all of it (`ListSlack` 2 either way) and, in the comparison, it isn't under 80 % of the first read (BUF orders against BUF orders when filtered); else waited for and read again for up to 60 s (Search pressed once more when it stays short), then `WholesaleListException` (nothing opened). Before each order `InView` (up to 20 s, nothing pressed).
- **The comparison (`WholesaleSpeedTest`):** `Scout` (up to 24 eligible orders, 6 minutes, all four by number, `KeepOrder`, stopping once `SpeedResults.StillMissing` is empty) and `SpeedResults.Broad` (asked orders first, then the looked-at order covering most missing cases, then spread); `Plan` = 2.9.7, all-number, all-buf, all, direct, ready, lean, timers, 2.9.7; the made-up number in all and all-number, the wrong place in direct and all, and a listed order the rules leave alone (`SpeedResults.NotEligible`) in all-number; a pass stopped for COSTAR's list run once more after 10 s (`again`), then the comparison ends with the reason; orders not reached recorded; a list not taken as complete never used for the BUF filter's check; `file.plan`, `approach`, `eligible`, `scouted`, `evidence` (schema 2).
- **The report (`SpeedReport`):** `RefOf` (the first complete 2.9.7 pass, or the last, with its note; none: nothing compared); `Compare`/`Against`/`Tally` (match, changed, difference, unread, not listed, missing, not reached; the other 2.9.7 pass's differences are changes in COSTAR); `Test` (passed, FAILED, not reached, not completed); `Verdict` (reliable, NOT reliable, not confirmed); `Best` ("best-supported"); `Covers` and the cases not found; the approach in use; the direct-row note for live; "Not tested" and "Partly tested"; what was seen at a stop.
- **Evidence (`Native.InputEvidence`, `EvidenceText`, `NotePointer`, `SessionEvent`):** at every someone-at-the-PC detection (the dry run's `Quiet` and close, RoWip's `Quiet` and Activate): Windows' last input against the helper's own, the pointer against where the helper last put it (or the pass's start), what's in front by kind, the session's state, the Remote Desktop changes from `WM_WTSSESSION_CHANGE` (both helper windows register); always "can't be established from this". A tyre line not clicked logs why (`wholesale_stock`).
- **Save diagnostics:** the summary keeps the report's reference, what was seen at a stop, best-supported, approach and not-tested lines.
- Version 2.9.10 - Search by number, list recovery, comparison report (dry run).

## Review

- Reviewed here (no separate reviewer). Found while building: comparing a read's children with the table's count exactly would stop every pass if COSTAR's list counted a child it doesn't hand out → a row or two either way allowed; a search-by-number result row was opened without the eligibility rules being applied again → `StillToOpen` with the pass's own rules (and a test order that must be skipped); the comparison's test of a listed order the rules leave alone would have been opened by an approach without the search → only ever searched for, never opened; a pass's list read that wasn't complete was still used as "the whole list before" for the BUF filter's check → only complete lists count; the other 2.9.7 pass's differences counted as an approach's differences → changes in COSTAR; a list showing no table yet stopped the pass at once instead of being waited for → taken as still loading (`ReadComplete`), waited for like a short one.

## Checks performed here

- Compiled at C# 5 against the five reference sets: 0 errors, the usual 3 warnings. C# 5 scan: only lambdas flagged in the tests (and the old Runner.Online false hit), as before. The old compiler's one-meaning-per-name rule (CS0135/CS0136) with the checker: nothing.
- Self-tests: 172 + the 4 that need Windows = 176; Order Check 16/16. Four new wholesale groups (the report's reference and categories with the 15 Nov 09:31 and 09:52 runs made up again, a retried 2.9.7 pass, both 2.9.7 passes differing; the broader sample; the search's checks, the list's readiness and the evidence's words; made-up lists with orders taken out above, labelled as not a COSTAR Sell → Cancel) and three updated (the approaches' default, the report, the settings and summary).
- 29 deliberate bugs in the new code (the list's checks, the search's words and exact number, the rules again, the reference, the categories, the tests' verdicts, the sample, the evidence's words, the approach set once): 25 caught at first; 3 got through (a ", " inside the Document # words, a 2.9.7 pass that stopped after reading its orders or read none taken as complete, the sample's case-covering step skipped) → tests added; one didn't apply (its text was there twice) → made exact. Then all 29 caught.
- Clock moved to 7 points (now, +15 h, +30 days, +1 year, the end of daylight saving, a Sunday afternoon, +3 years): every group passes but the clean-up one at the 6 moved points, as in every round before (it compares file times with the moved clock).
- Install replay with the Updater the PCs run (2.6.0's install code) over 2.9.9, 2.9.8, 2.9.7 and 2.6.12: PASS (98 files each, every file matching PACKAGE-SHA256.json). The upload set is latest.json and the helper ZIP; no Tests folder; no tokens, webhooks, keys, pairing or connection files; the 18 historical report-number hits as in earlier rounds, none in 2.9.10's lines; no order number from the dry runs or comparisons (3, 4, 14, 15 Nov: the only match was ZZ0000000, the comparison's own made-up number); WO numbers only made-up ones.

## Not verified here (no Windows or COSTAR here)

- Search by number in COSTAR with the new checks: the boxes' description before and after Search, the second search for an order not shown, the eligibility re-check on a real row (the next dry run and comparison, TEST-PLAN 2.9.10).
- The list's readiness against COSTAR's own grid: the table's count against the read's children (the slack of 2 is a guess), recovery when it's incomplete, the 20-second wait before an order.
- The look for a broader sample and the cases the list actually has.
- The evidence at a real stop: the pointer, what's in front, Windows' session messages over Remote Desktop.
- Anything of the live workflow: Sell, then Cancel; the order leaving the list (confirmed by Tommy, not seen by the helper); the number and the order's state checked again right before Sell.

---
# Validation — v2.9.9 — 15 November 2026

## Basis

- **The ask.** 15 Nov 08:33, Tommy (after the 08:23 diagnostics: four presses of the Wholesale tab found 0 to open, every eligible order previewed at 02:13–02:25): the speed comparison and the Approach selector on the RDP helper's Wholesale tab, a clearly labelled Run speed comparison button reusing the comparison engine, in his current Windows login and COSTAR session (the separate wholesale session still the plan); bypassing "previewed today" and earlier test records, the same orders every approach, the baseline first and last, run again at once, test progress apart from normal checking, the eligibility rules applied and branch and document identity verified; the whole comparison; the approach, pass and order progress shown; only one operation controlling COSTAR at a time; dry run only, every order closed; speed reported with correctness, failures and fallbacks; the `total 0.0 s` timing fixed; the report in Save diagnostics; any reason it can't start explained clearly.
- 2.9.9 is 2.9.8 (8cffa2c) plus these.

## Changes

- **The Wholesale tab (`WholesaleTab`):** Run speed comparison (the reasons it can't start checked first, on the window's thread, before anything is pressed: a comparison or a press already running, another job holding COSTAR (named), COSTAR Sydney not there or more than one, an Order or a Repair Order open in it, the session not connected or locked; then the dialog; a message for a reason found once under way), the Approach box and Back to 2.9.7 (`wholesale-tab-settings.json` in the worker folder; a press uses it, emptying its own search words at the end), the line and list following the comparison, Stop after the order in hand, the report window at the end; Stop all and the main window's busy state include the comparison.
- **The comparison (`WholesaleSpeedTest`):** COSTAR held for the whole of it (one lease, `WholesaleOptions.Lease`, from its first pass to its last; up to a minute's wait for work already under way); on the tab each pass ends back on Repair Order (`stayOnList` false), as a press does; `StatusLine` (the pass, its approach, the order in hand, the minutes so far); `Passes` (0: it couldn't start).
- **Each pass's orders (`WholesaleRun.Sample`, now pure):** the chosen orders, each checked again against the eligibility rules (`WholesaleRules.Screen`: staff's Comment, flagged, a ShipDate after today; also gone from the list, no longer BUF): not opened, with why; nothing kept from normal checking counts.
- **The pass (`WholesaleRun.Pass`):** a lease given by the caller is used and kept; `OrderProgress`; the run's own search words emptied before Repair Order is pressed after a stop too; the pass times logged once the total is known (2.9.8 logged them first: `total 0.0 s`).
- **Shared pieces (`SpeedComparisonUi`, `WholesaleSettingsFile`):** the dialog, the report window, the Approach box and the settings file, for the tab and the wholesale helper alike.
- **Save diagnostics:** the newest comparison's first, STOPPED and best-reliable lines at the top of summary.txt (`DiagnosticsBundle.SpeedNote`); speed/ as in 2.9.8.
- Version 2.9.9 - Speed comparison on the Wholesale tab (dry run).

## Review

- Reviewed here (no separate reviewer). Found while building: the comparison's passes each taking COSTAR for themselves would have let a phone job or an eBay order in between two passes, and the next pass would then have stopped ("… is using COSTAR") → one lease for the whole comparison; on the tab, staying on the wholesale list between passes would have left COSTAR Sydney off Repair Order for eBay orders after a stop → each pass ends back on Repair Order, as a press does; a stop with the comparison's search words still in the list's boxes went back to Repair Order without emptying them → emptied first; the comparison button greyed while other work held COSTAR, with no word why → it stays pressable and says why.

## Checks performed here

- Compiled at C# 5 against the five reference sets: 0 errors, the usual 3 warnings. C# 5 scan: only lambdas flagged in the tests, as before. The old compiler's one-meaning-per-name rule (CS0135/CS0136) with the checker: nothing.
- Self-tests: 168 + the 4 that need Windows = 172; Order Check 16/16; package and page tests pass. One new wholesale group: each pass's orders (still eligible: checked whatever was previewed; staff's Comment, flagged, a ShipDate after today, not BUF, gone: not opened, with why; the list's order; the planned tests last, none within 3 places, a made-up number only when it isn't on the list), the orders typed to include (as COSTAR lists them, once each, 20 at most), the summary's comparison lines (first, STOPPED, best reliable), the settings file (none: the 2.9.7 approach; kept and replaced in place; unreadable: the 2.9.7 approach).
- Mutations: 7 deliberate bugs in the new code, all caught (the eligibility rules not applied again; the orders not in the list's order; a number typed twice kept twice; the whole report in the summary; the settings never replaced; a made-up number used though it's on the list; a wrong-place test within 3 places). 2.9.8's 26 still apply to the code they tested.
- **The clock moved on:** the self-tests at 7 points (now, 15 hours, 30 days, a year, the April 2027 daylight-saving change, a Sunday, 1100 days): all pass at each, Order Check's 16 too, apart from the clean-up group (its files are made at the real time; it passes at the real time), as before.
- Package checks (launch scripts, self-test inclusion) and the page tests pass. Install replay with the Updater the PCs run over 2.9.8, 2.9.7, 2.9.6 and 2.6.12: PASS (98 files). Scans of everything that leaves: no tokens, keys, webhooks, pairing or connection files, no wholesale state, settings or Discord files; report numbers: only the 18 historical hits, none in 2.9.8's or 2.9.9's text or code (472 numbers from the reports and day logs, 15 Nov's two included); none of the dry runs' order numbers; only made-up phones, emails, eBay and wholesale order numbers.

## Not verified here (no Windows or COSTAR here)

- The comparison on the RDP PC's COSTAR Sydney, in Tommy's own session: that is the next step (TEST-PLAN 2.9.9).
- Phone jobs, eBay and online orders waiting for the comparison as they wait for a press (they ask COSTAR's gate again later; seen for a press since 2.9.0, not for half an hour).
- The tab's new row, the dialog and the report window on that screen.

---

# Validation — v2.9.8 — 15 November 2026

## Basis

- **The ask.** 15 Nov 02:52, Tommy: one combined dry-run update with a way to compare the speed improvements on his COSTAR, to choose the fastest reliable approach from measurements; all five proposals (the row found directly, its number checked, falling back when it moved; ready checks instead of repeated 1.5 s waits; only the list columns needed, BUF orders' extra fields; shorter stability timers; detailed stage timings); also search by order number and the list filtered to BUF ("Entering search criteria is acceptable navigation during the dry run"); Ship Via, branch and document identity still verified; a comparison mode measuring the baseline, each improvement, the combination and the search/filter alternatives over the same orders, sequentially in the wholesale session, with its own progress record; times for list refreshes, finding rows, opening, Notes/memos, stock reads, verification and closing, with medians, slowest, retries, stops and fallbacks; delayed popups, stock panels still loading, rows moving or disappearing and locked orders exercised; correctness checked beside speed, genuine changes accounted for; dry run only, every order closed; a concise report; an easy way back to the baseline; approaches needing another COSTAR session or Windows login named separately.
- **What it builds on** (the 15 Nov 02:25 diagnostics, 2.9.7, and the speed findings doc): 37 orders in 12 min 14 s; the list ready after 35.1 s; an order 18.4 s median (one tyre line), 20.3 s (two), 22.3 s (three), 14.1 s (none); 6.0 s of every order fixed 1.5 s quiet waits; a line click to its stock 1.88 s; no notice after a line click in 122 orders since 3 Nov. Estimated, not measured: the whole list read twice for each open (6–7.5 s), the list read itself (about 30 s).
- 2.9.8 is 2.9.7 (9577cf9) plus these.

## Changes

- **Approaches (`WholesaleSpeed`):** baseline (2.9.7), direct, ready, lean, timers, all, all-number, all-buf; kept in wholesale-settings.json (`approach`, default baseline); the loop asks for it at the start of every pass; the RDP helper's tab always uses the baseline.
- **The row found directly (`WipScan.FromHint`, `RoWip.Open(hint)`):** the columns from one row read whole, then the row at its place among the list's children, or a place or two either side, its Document # cell taken on its own and its name checked; the rows two places either side for the active / only-selected checks; anything else null → the whole list read as before (counted as a fallback). Every re-read in the open uses the place found; the mouse way reads the whole list first.
- **Ready checks (`Notices(quietMs)`):** 0 ms of quiet after the order is read, after a line's stock and after the lines are left (nothing over the order, enabled, COSTAR answering); 1.5 s after an order opens, whatever the approach.
- **The lean list (`WholesaleList.ReadLean`):** Document # and Ship Via for every row, the dates and Comment for BUF rows, each cell taken on its own; the Ship Via cell's name checked on every row, every cell's on BUF rows, the first 3 rows and every 10th; on those rows and the first BUF row the values compared with the row read whole; anything off → null → the whole read. Both reads now give each row's place (`Pos`), counting every child of the list.
- **Shorter timers:** box still 80 ms (150), stock reads 100 ms apart (200), lines left 150 ms (300).
- **Search by number / filtered to BUF (`WholesaleSearchBox`):** the list's search box found by its label (the same matching as the filter description), its words set with WM_SETTEXT and read back; nothing typed, no keys. By number: the order's number in Document #, Search, the list read (not shown → skipped without opening anything); the number emptied before any other Search and at the end of every pass. Filtered: BUF in Comment / Ship Via before Search, kept between passes while that's the approach (the pass's own filter isn't cleared as a person's would be). Ship Via still checked on every row and on the order's listed row; `RoWip.Open(ownFilter)` never clears the run's own words.
- **Timings (`WholesaleTimes`, `WholesalePassTimes`):** each order's search, find, open, Notes, read, stock, verify, close and total, with counts (list reads, rows, fallbacks, tries, lines, stock reads, figures that changed, late notices, tries to leave the lines, notices answered and when the first came); the day log's `wholesale_times` and `wholesale_pass_times`.
- **The speed test (`WholesaleSpeedTest`, `SpeedResults`, `SpeedReport`):** the list read once to choose the orders (named ones first, the rest spread down the list; only BUF orders a pass would open now); then 9 passes over them; no state, no Discord per order; a run's own search words emptied after each; stops on an order left open, someone at the PC or the session gone; the JSON and the report in Diagnostics\speed (numbers, order numbers, tags and stock figures only), a Discord summary, the report window.
- **The wholesale helper:** the Approach box, Back to 2.9.7, Speed test … (orders 4–20, orders to include), checking stopped after the order in hand for a test (`WholesaleRun.Finish`) and started again after it; Stop stops a test after the order in hand; no update during a test. Save diagnostics includes speed/ (30 days).

## The comparison plan

- 9 passes over the same orders, one after another: 2.9.7 approach; direct; ready; lean; timers; all four; all four by number; all four filtered to BUF; 2.9.7 approach again.
- It covers: each improvement on its own against 2.9.7; all four together, and whether they add up (the four savings summed against the combined saving); the search and filter alternatives, each differing from "all four" by one thing (by number instead of the row found directly; the filter added); COSTAR's own drift and genuine changes during the test (the 2.9.7 approach first and last).
- It doesn't cover: pairs or triples of improvements (the singles and the four together show whether they overlap); the search or the filter without the other improvements; timer values other than the two; more than one test day.
- Beside the orders: an order looked for at another order's place (direct; all four); a made-up order number (all four; by number); the filtered list against the whole list before and after it. Delayed notices, stock figures still filling in and orders open on another PC are measured whenever they happen (the report says which weren't met).

## Review

- Reviewed here line by line (no separate reviewer this round). Found and fixed while building:
  - Stopping checking for a test with Stop's own stop would have left the order in hand open, and the test's first pass would then refuse to start → `Finish`: checking ends after the order in hand, closed as usual; the test's Stop works the same way.
  - A search by number that finds nothing can leave COSTAR's list without a table: the open would have waited, searched again and stopped the whole run → the list is read after the search, and an order it doesn't show is skipped without opening anything.
  - An order not on a list filtered by the run's own words would have had COSTAR's Clear pressed (every box) → `ownFilter`: not listed is not listed.
  - A row found a place off its known place was looked for at the old place again on every re-read in the open → the place found is used.
  - The BUF filter found already in place (after a restart) had no box to empty at the end of a speed test pass → the box is looked up first.
  - The report: an order compared with one 2.9.7 pass only would have taken a stock figure read wrongly for a change in COSTAR → compared with both 2.9.7 passes; 2.9.7's figure is the faster of its two passes (COSTAR warming up during the test isn't credited to an approach); the card result in each order's fingerprint; a retries column; the whole pass without the planned tests.
  - Tests added when mutations got through: a cell taken on its own showing the hidden Ship Via cell; a BUF row's Comment cell named otherwise; something that isn't a row before the rows (places count every child); an order read but stopped before a verdict keeping no words.

## Checks performed here

- Compiled at C# 5 against the five reference sets: 0 errors, the usual 3 warnings. C# 5 scan: only lambdas flagged in the tests, as before. The old compiler's one-meaning-per-name rule (CS0135/CS0136) with the checker: nothing.
- Self-tests: 167 + the 4 that need Windows = 171; Order Check 16/16. Five new wholesale groups: the approaches and their timers (eight presets, each improvement on its own, unknown → the baseline, the settings kept across restarts, the day log's lines); the lean list against the whole read on a made-up 25-row list with a hidden Ship Via cell and a row listed twice (every row's number, place, Ship Via, a BUF row's dates and Comment; a cell not taken on its own, a cell taken on its own that isn't the listed one, a BUF row's cell named otherwise → read whole; places counting every child); the row at its known place (found, a place or two off, not found further off or with another order there, the headings at the place, the same order twice nearby, a cell not named Document #; the open's times); the search boxes by their labels (Document #, Comment / Ship Via; none for two or for a label right of the box) and the run's own BUF filter told from a person's; the speed test's orders, results and report (asked-for orders first and only BUF orders a pass would open, spread down the list; a look's result as numbers only; compared with both 2.9.7 passes: same, changed in COSTAR, unexplained, missing, locked and filled; medians; the BUF filter's missed orders; a made-up test where the two faster approaches aren't reliable and all four is best, the improvements overlapping, the planned tests, what wasn't met, the way back; nothing faster → the 2.9.7 approach; COSTAR faster by the last pass → nothing beats 2.9.7's faster pass).
- Mutations: 26 deliberate bugs, each run against the self-tests, all caught (a cell not taken on its own kept; no whole-row comparison; a BUF row's cells or the Ship Via cell not named; places counting rows only; the row only at its exact place; the same order twice taken; a cell not named Document # taken; any BUF-ish filter taken for the run's own; the first of two boxes; a label right of its box; the timers or the waits unchanged; by number also finding the row directly; staff's orders chosen; the filter's misses without the list after it; the comparison swapped; the last 2.9.7 pass ignored; a lock as missing; a filtered list trusted; the wrong-place test not read whole; the planned tests counted in the medians; a slower approach called best; 2.9.7's first pass only; the high median; the Comment's words kept).
- **The clock moved on:** the self-tests at 7 points (now, 15 hours, 30 days, a year, the April 2027 daylight-saving change, a Sunday, 1100 days): all pass at each, Order Check's 16 too, apart from the clean-up group (its files are made at the real time; it passes at the real time), as before.
- Package checks (launch scripts, self-test inclusion) and the page tests pass. Install replay with the Updater the PCs run over 2.9.7, 2.9.6, 2.9.5 and 2.6.12: PASS (98 files). Scans of everything that leaves: no tokens, keys, webhooks, pairing or connection files, no wholesale state, settings or Discord files; report numbers: only the 18 historical hits, none in 2.9.8's text or code (472 numbers from the reports and day logs, the 15 Nov one included, checked against it); none of the dry runs' order numbers (3, 4, 14 and 15 Nov); only made-up phones, emails, eBay and wholesale order numbers.

## Not verified here (no Windows or COSTAR here)

- The times themselves: that is what the speed test is for.
- COSTAR's list giving out a row's cells one at a time as it lists them (the lean read checks and falls back; `wholesale_list_lean` in the day log), and its children numbered as read (the row found directly; the report's "Read whole" column, `wholesale_times` "at its known place").
- COSTAR's search taking words set with WM_SETTEXT (if it doesn't, by number and filtered show the whole list: slower, not wrong; the report shows it), and the Comment / Ship Via box covering every BUF order (the test checks it).
- How often the Notes or a memo come later than the first 1.5 s with ready checks (the report counts late notices and differences).
- The Approach box, the speed test dialog and the report window on the RDP PC's screen.

---

# Validation — v2.9.7 — 15 November 2026

## Basis

- **The asks.** 14 Nov 20:49, Tommy: two RDP sessions with a dedicated role each, one staying in Wholesale Orders; explain the wholesale workflow back first. 21:37 (with the 14 Nov 21:31 diagnostics): why "someone's on it", and is it set to only check 30. 22:04, 22:23 and 23:59: the decisions (README 2.9.7): 100 a pass, checking again and again with waits of 1, 3, 5 and 10 s (reset when an order is processed, not by skipped or locked ones), later orders getting their turn; Comment variants and the real skip reason; Sydney's displayed "= Avail" 4 or more, no add-back, tyres only, tubes excluded; [stock] [card] [review] [items] together; go only on helper-flagged orders, approvals kept in the helper; reading problems (a confirmed [stock] still shown, [card] only from a reliable read, never sold while unresolved); Document Already Open skipped and tried again in 2 minutes, a reading problem in 5 minutes, hourly after an hour; 06:00–18:00; Discord one message per order, edited, DRY RUN; "Next build: Dry run only"; a dedicated Windows login, the RDP arrangement confirmed first.
- **The 14 Nov 21:31 run** (2.9.6): 30 orders opened (the cap), 25 would sell, 4 NO CARD DETAILS, 1 CHECK STOCK; "someone's on it" was the Comment rule (any Comment other than WWW / BUF … is staff's), not a lock.
- 2.9.7 is 2.9.6 (f5c720f) plus these.

## Changes

- **Rules (`WholesaleRules`, `WholesaleComment`, pure):** `Screen` (BUF; the Comment: fresh (WWW / BUF / BUFF / BUFFALO words in any order, punctuation, W W W, BUFFALLO-type spellings: `FreeWord`), flagged (the tags), go (flagged with go last), go-only, staff (with the real reason); the ShipDate; an unreadable ShipDate a reading problem). `KindOf`: freight, tube (TUBE/TUBES not followed by TYPE/TT), flap and rim band (other), wheel (a rim size 12–26 × 3–14 not followed by R or -, or a stud pattern 3–8 × 98–210), tyre, other. `Decide`: every check every time; card = ok / missing (Notes read whole, no card details, CASH) / unknown; stock short (NON-STOCKING or "= Avail" under 4) / unknown / ok; [review] for wheels, [items] for no tyres and no wheels; approvals by this go (finished rechecks only) or by the helper's record for the same lines (`Print`); tags: confirmed ones, a shown one whose condition couldn't be checked, and (a flagged order tried again) the ones shown; `KeepGo` when the recheck couldn't be finished; sell only with no problems, no tags and not a flagged retry; the Comment rewritten by `With` (tags and the last go off, staff's words kept, tags at the end), a change only when `SameMeaning` says so (tag order, case and spaces aren't changes).
- **The plan (`WholesalePlan`, pure):** `InHours`, `NextOpen`, `Step` / `WaitSeconds` (1, 3, 5, 10 s; `Processed`: would sell or flag), `RetryAt` (locked 2 min; a problem 5 min, hourly after an hour), `Sig` (Comment, ShipDate, Ship Via), `Queue` (go, then new oldest first, then retries due; flagged orders with their own problem tried again add-only; previewed today with the same row: not again; at most 100, the rest "the next pass"), `After` (what's kept; approvals only when really written), `Dropped` (an order followed for a problem or a lock let go when it leaves the list or changes and isn't to be checked now).
- **The state (`WholesaleState`):** wholesale-state.json beside the helper's files (atomic save; 30 days, approvals 90).
- **The loop (`WholesaleRun.RunLoop`):** hours; the session check (another Tempe helper in it, not connected, locked: waits, Discord after 10 minutes); a pass; the waits. Someone using the session pauses it until it's been left alone 2 minutes; anything else stops it with a Discord alert (a new message; edited when checking starts again). A pass: COSTAR Sydney on its wholesale list (Include Filled Orders unticked, any search cleared), Search, the plan, each order looked at as in 2.9.6 (Notes / memo OK, tyre lines clicked to read the stock, read again, closed only when unchanged), every 3 minutes the list read again (a new go to the front), 18:00 after the order in hand; it stays on the list.
- **Document Already Open** (`RoWip.InUse` now for Orders too, `InUseOver` once the order has shown): OK pressed, the order skipped (locked), its window closed only when COSTAR left it and nothing was read or clicked; an empty Order window left by COSTAR stops checking for a person.
- **Discord (`WholesaleDiscord`):** the webhook kept encrypted (wholesale-discord.dat), message ids and words kept (wholesale-discord.json, 30 days); one message per order, edited (PATCH; deleted: posted again), never the same words twice; one at a time, 1.5 s apart, Retry-After on 429; DRY RUN on every message; no customer names, card details, Notes words or staff's Comment words; a cleared problem and a let-go order said on their own message.
- **The wholesale helper (`WholesaleForm`, `--wholesale`, Start-Wholesale.cmd):** its own folder, mutex and settings; session line (session, login, Remote Desktop client; other Tempe helpers' sessions); refuses to check in a session another helper runs in; checking resumes after a restart (20 s) until Stop; Discord channel dialog (masked, never shown again; Send a test; Turn off); Save diagnostics; Update now; updates install by themselves outside 06:00–18:00 between passes (quiet 10 minutes, each version once), checking going on in the new version; Start with Windows (Wholesale).
- **The RDP helper's Wholesale tab:** the new rules, up to 100 a press, the shared list and detail (`WholesaleView`: each line's kind and stock, the Comment before and after, approvals kept, retry times), what was previewed kept (worker folder), back to Repair Order at the end.
- Launch.ps1 `-Mode Wholesale`; Updater restarts into Start-Wholesale.cmd; AutoStart "Wholesale"; Build.ps1's file list. Version 2.9.7 - Wholesale loop (dry run).

## Review

- **Round 1** (independent, of the first build): 2 High, 4 Medium, 11 Low, nits. Nothing in it typed into COSTAR or pressed anything beyond the dry run's presses. High, fixed: the dry run opened every order with go on every pass all day (it never takes a go off), resetting the waits each time → a go previewed today with the same row isn't opened again that day, and a result the same as last time for the same row doesn't count as processed (`Counts`). High, fixed: the 3-minute refresh kept stale orders, and an order filled meanwhile stopped the whole loop → `Rest` (the rest of the pass as the list is now, new go first, changed ones dropped with why) and `RoNotListedException` (that order skipped, the others go on; phone Repair Orders unchanged). Medium, fixed: the tab's restore ran after the lease and input lock were let go → inside the pass; a session lost during a pass stopped checking and kept false reading problems → checked before each order and after a look with problems, the loop waits for it; line kinds failing unsafe (TUBE-TYPE, a tyre with its tube and flap, SUIT COURIER, ATV and small sizes, wheels named without a size) → fixed, and "can't tell" lines are never sold; a flagged order found open on another PC lost its reading problem and was never tried again → kept. Low, fixed: a problem message not cleared after a lock; an unreadable ShipDate's message never let go; a Terms value quoted to Discord; the Remote Desktop client name read as ANSI; the order number lost in a stop alert; a failed automatic start shown in a message box on an unattended screen (now Discord once, tried every 5 minutes); changed values not shown; a gone window called left open; the update guard the wrong way round; COSTAR busy after Document Already Open stopping checking (now waited for 15 s); the message id taken from anywhere in Discord's answer. Nits fixed: "go go", "(go)", "found" for an unreadable Comment, ids kept when the same channel is set again, Process objects disposed. Left as it is: message ids pruned 30 days after their last send (a new message then); the tab's 100 per press (Tommy's number).
- **Round 2** (the fixes): no High; 1 Medium, 2 Low, nits. Medium, fixed: the new line rules took some tubes ("TYRE TUBE 7.50-16"), flaps, bolts and spacers ("M14X1.5-28") and wheels with a spaced offset ("17X9 -12") for tyres → a tyre with its tube or flap only when named a set (SET, KIT, AND, WITH, W/, &); small sizes without spaces, a width of 4 or more and a rim of 4 to 15; a spaced offset is a wheel's; a small size with a wheel's word is "can't tell"; the old x.xx-yy size no longer after an X (a bolt's thread). Low, fixed: service and accessory lines ("TYRE BAGS", "WHEEL TRIM", "TYRE CHANGEOVER" …) taken for "can't tell" → more part and service words; ChangedValues still not shown (only set on a stop) → shown outside the verdict. Nit fixed: "Tried again at ." for an unreadable ShipDate. Also from a probe of made-up lines here: spacers and adaptors (a stud pattern and a part's word) are parts; a Simmons line without a size is "can't tell".
- **Round 3** (the line rules): no High; 1 Medium, 2 Low, nits. Medium, fixed: the tightening lost some real tyres (bias flotation 37X12.50-17, OTR 16.00-25, small tyres described PUNCTURE PROOF or LOW PRESSURE) → a bias flotation size (first number 27 or more), rims to 25, and only hardware words (nut, bolt, stud, spacer, valve, cap …) make a small size a part's; motorcycle (90/90-21), tractor (18.4-34) and dotless (750-16) sizes added; accessories sold by a tyre's size (snow chains, a spare tyre's cover) and tyre levers are other. Low, fixed: a wheel with a stud pattern and its centre cap taken for a part → a wheel's finish or word keeps it a wheel; "TYRE TUBE & FLAP 7.50-16" taken for a tyre → a tube or flap with a tyre's size, TYRE and a set word is "can't tell". Nit fixed: "left open" said twice. Against the reviewer's 120 made-up lines (61 tyres, 16 wheels, 10 tubes and flaps, 33 other): no tyre taken for anything else and nothing else taken for a tyre; 7 come out "can't tell" (never sold): two tyres with their tube and flap, a tube-and-flap set, a small tyre on its rim, two wheels named without a size and a wheel whose size reads both ways.

## Checks performed here

- Compiled at C# 5 against the five reference sets: 0 errors, the usual 3 warnings. C# 5 scan: the new files pass (only lambdas flagged in the tests, as before). The old compiler's one-meaning-per-name rule (CS0135/CS0136), checked with the reviewer's checker: nothing.
- Self-tests: 162 + the 4 that need Windows = 166; Order Check 16/16. Six new wholesale groups: which orders are opened (BUF; 22 Comment variants new, 22 staff's, go, flagged; ShipDate; oldest first, by number); the Comment's tags, go and rewriting (staff's words kept, go off, every go, the same tags in another order not a change); each line's kind (115 descriptions: tyres of every size kind, tubes, flaps, wheels, parts, services, freight, can't tell); every check together (stock 3/4, NON-STOCKING, no add-back, [card] only from Notes read whole, [review], [items], tyres with other items, Terms, more than 25 lines, unread lines, go and approvals by record and by go, a go whose recheck can't finish, a flagged retry only adding); the loop's plan (hours, waits 1/3/5/10 s, retry times, the queue's order and cap, previews, go previews, locks keeping a problem, what's kept, letting go, the rest of a pass, an unreadable ShipDate, what counts as processed); Discord's words (DRY RUN, no names, Comment words or Terms values, cleared and let-go words, message ids from the top level, mentions and length).
- Mutations: 32 deliberate bugs, each run against the self-tests, all caught (4 not 3 or more; tubes as tyres; go kept; new before go; waits not reset; no DRY RUN; Notes unreadable taken for no card details; staff's words in Discord; a flagged retry selling; 19:00; an approval for other lines; go approving an unfinished recheck; no cap; never hourly; BUFFALLO refused; previews forgotten; tag order a change; the author's id; gone orders kept followed; staff's words in a cleared message; gone orders opened; go previewed again; a lock forgetting the problem; can't-tell lines sold; TUBE-TYPE; freight before a tyre size; every result counted; one go of two taken off; no bias flotation sizes; accessories as tyres; a tube set as a tyre; any part word making a small size a part's).
- **The clock moved on:** the self-tests at 7 points (now, 15 hours, 30 days, a year, the April 2027 daylight-saving change, a Sunday, 1100 days): all pass at each, Order Check's 16 too, apart from the clean-up group (its files are made at the real time; it passes at the real time), as for 2.9.6.
- Package checks (the new Start-Wholesale.cmd's launch script included). Install replay with the Updater the PCs run over 2.9.6, 2.9.5, 2.9.4 and 2.6.12: PASS (97 files). Scans of everything that leaves: no tokens, keys, webhooks, pairing or connection files, no wholesale state, settings or Discord files; report numbers: only the 18 historical hits, none in 2.9.7's text or code; none of the dry runs' order numbers (3, 4 and 14 Nov); only made-up phones, emails, eBay and wholesale order numbers.

## Not verified here (no Windows or COSTAR here)

- Two Remote Desktop connections with two logins giving two sessions on the RDP PC, and the session line and checks (TEST-PLAN 2.9.7 items 3 and 4); Start with Windows for the second login.
- The loop on COSTAR Sydney all day: staying on the wholesale list, Search every pass, the 3-minute refresh mid-pass, 18:00 and 06:00 (items 6, 13).
- COSTAR's "Document Already Open" over a wholesale Order (seen only for Repair Orders: 2.9.4), and what it leaves (item 10); watch `wholesale_in_use` and `wholesale_locked` in the day log.
- Discord editing a message (PATCH) and the wholesale channel's limits (items 5, 6).
- The line kinds on real orders' descriptions (item 7): the rules come from tyre and wheel size conventions and made-up lines, not from COSTAR's own item descriptions.
- A session that locks itself or is disconnected for being idle (item 14).

---

# Validation — v2.9.6 — 11 November 2026

## Basis

- **The asks.** 11 Nov 08:38, Tommy, with a screenshot of the phone's Repair Orders page ("A Repair Order is open in COSTAR Branch 11 (TEMPE) (RO …): it is online order TTW…'s, maybe waiting for review. Finish or close it at the PC first"): "Lets fix this one, this is silly, i should be able to use it or atleast force to use it while im not on my desk". 09:30: "also if its not on the correct branch, please change the branch".
- **Why the first happened.** Since 2.6.7 a phone request closes a Repair Order left open in COSTAR Tempe first (WM_CLOSE, after 3 s with nobody at the PC), but never one kept for a person: held (a phone job's waiting for review or set aside, the Online orders tab's last fill or an order stopped part way in: `HeldForReview`), or an online order's by its PO# (TTW…, also after a restart, when the tab no longer knows its Repair Orders). `RoWip.Open` needed no Repair Order window open at all, so with one of those open every phone request waited.
- **Why the second happened.** The phone's Repair Orders used the COSTAR the RDP helper is set to, and refused unless it was Tempe ("Select COSTAR Tempe in the RDP helper"). The day logs show the helper set to Sydney and back many times a day (6 Nov: 08:28 Sydney, 09:33 Tempe, 10:26 Sydney, 10:27 Tempe; 9 Nov: eight switches before 10:00).
- **Not closing them.** A first version closed a kept one once the PC had been left alone for 2 minutes. Its review (independent) found it unsafe: those Repair Orders are left open on purpose for a person (CHECK BY HAND, MANUAL COMPLETION REQUIRED, a note COSTAR hadn't taken yet, which WM_CLOSE could lose; after a restart, one half typed by hand), and 2 minutes says nothing of how long it had been open. It was dropped (Tommy told).
- **COSTAR's windows** (the saved maps, 28 Oct and 9 Nov): a Repair Order window is a top-level window of its own, owned by nothing, not maximised; COSTAR's main window (maximised) stays enabled while one is open; a COSTAR dialog over a Repair Order disables both. A new Repair Order's box beside the RepairOrder label (a read-only box) is empty (the maps of phone jobs being entered, 28 Oct 09:06 and 09:50); a saved one's holds its 8 figures; every Repair Order opened from Work-in-Progress in the saved run reports showed its number (733 of 733 identity checks). How COSTAR behaves with a second Repair Order opened beside one hasn't been seen yet (TEST-PLAN 2.9.6).
- 2.9.6 is 2.9.5 (15036d2) plus these.

## Changes

- **Who stays (`RoEngine`, pure):** `Stays` (held, or an online order's PO#, with COSTAR asking nothing on it and nobody at the PC); `FateOf` (Wait: COSTAR asking something on it, someone used the PC in the last 3 s, or one not held whose PO# wasn't read, never closed unread; Stay: kept for a person, left as it is; Close: closed first, as in 2.6.7); `RoPeek.Seen.NoNumber` (the number box found, read, and empty: a new Repair Order, never saved, so never in Work-in-Progress); `MayBe` (the one asked for by its number, leading zeros aside; a new one never is; one whose number wasn't read may be); `NumberKnown`, `NumberChanged`.
- **The first look (`LookFirst`, pure):** each open Repair Order in turn; the first that waits ends it (for a request, someone at the PC stops it: "someone used the PC just now. Nothing was closed or opened: try again when the PC is free", `StopWhy`); a kept one stays only when its number is known (read, or none shown), and never when it may be the one asked for (COSTAR has it open already): Free's look waits until it can tell, a request stops. Nothing is closed before the look is through.
- **`CloseFirst`** (Free's look): ready when each open one is closed first or stays ("… stays open as it is, and the phone's opens beside it"). **`CloseOpenFirst`** (right before the open): the look, read afresh; then the ones to close, each looked at again right before its WM_CLOSE. It fills `Beside` (what was closed, and the kept ones: windows, words, what was read).
- **`RoWip.Open`:** the kept Repair Orders may be shown (`OnlyKept`); any other shown Repair Order window still stops the open; the kept ones are put among the windows there before (never taken for the open's own). `KeptStill` stops the open (nothing more pressed, nothing closed) if a kept one closed, went or changed (`KeptThere`: the same window, of that COSTAR, shown, a Repair Order's): on every pass of `WaitForWindow` and right before the double click and both Enters; Document Already Open's OK isn't pressed, and its form isn't closed, after that. The last check right before the double click and each Enter now sits right before the press (CheckPoint and TopWindows before it). Everything else is as before: the main window brought in front, the row opened with Enter (the list holding the keyboard) or the double click (the list under the point), the new window checked by its number before anything is typed, and closed again at the end (its own window only).
- **The result (`BesideSaid`, `Said`, `CheckWords`):** what was closed first and the kept ones, each looked at again at the end (still there; its number read again with nobody at the PC): "Repair Order … (…) was left open in COSTAR … as it was (it may be behind COSTAR's main window)", or, if COSTAR closed or changed it, "CHECK AT THE PC: …" (in the phone's notes, so a read shows it and a save turns to a warning). A stop says it too; nothing is then taken for the request's own, closed or remembered as left open, until the window was known to be the Repair Order asked for. The CHANGED: result says what was closed first and kept (left out since 2.6.7).
- **COSTAR Tempe whichever is selected (`PickTempe`, pure; `TempeTarget`):** the COSTAR Tempe set in the helper while its program runs; else the one set last (`EntryCoordinator.LastSelected`) while still open; else the only one open; never Order Check's window. The helper's setting is never changed. `AwayHold` (pure): with another COSTAR set, the phone waits until the PC has been left alone 2 minutes (`EntryCoordinator.OnlineHoldMs`, as the Online orders tab's hold). `EntryCoordinator.TryBegin(owner, target, mobile)`: one entry at a time, held back as phone work is. A close from the phone goes to the COSTAR it was left open in (`LeftIn`). Discord: `no_costar_tempe` / `costar_tempe_back` (5 minutes in shop hours; only a look under 30 s old counts); the `no_costar` alert no longer counts the phone's Repair Orders.
- `Peeked` keeps a read only when the number is known. Day log: `ro_beside`, `ro_beside_changed`. The helper's Repair Orders texts say COSTAR Tempe. Phone jobs, eBay orders, the Online orders tab and the wholesale dry run are as before. Version 2.9.6 - Phone RO fix.

## Review

- **Round 1** (independent, of the first "open beside" version): 1 High, 2 Medium, 6 Low, nits. High, fixed: a new Repair Order kept for review (the usual case: phone jobs, online orders filled) shows no number, so every request was refused while Free said ready → `NoNumber`, `MayBe` by it, and Free's look waits while a kept one's number is unknown. Medium, fixed: nothing checked that the kept ones survived the open, yet the result said "as it was" → `KeptStill`, `BesideSaid` ("CHECK AT THE PC"). Medium, fixed: a kept window made again (or retitled) by COSTAR could be taken for the open's own, then closed by the stop → `KeptStill` before a new window is taken, and the stop takes nothing over. Low, fixed: a stop's words promised a wait; "behind COSTAR's main window"; the CHANGED: result; the last check right before each press; more tests. Low, left as it is: Search and Clear in the main window with a kept one open (TEST-PLAN 2.9.6 item 8). Not added: a PO# second guard (a new one can't be in Work-in-Progress; a duplicate saved earlier is another document); the reviewer agreed.
- **Round 2** (the fixes and the branch change): no High; 2 Medium, 8 Low, nits. Medium, fixed: the CHECK AT THE PC words didn't reach the phone after a read → in its notes. Medium, fixed (the reviewer's choice for a person at the PC): with the helper set to Sydney the phone could bring COSTAR Tempe in front, or close an ordinary Repair Order there, 3 s after someone's last key → the 2-minute wait. Low, fixed: the kept ones among the windows there before; the words before each close; the stop no longer drops the request's own window once it is known; a close from the phone in the COSTAR it was left in; a COSTAR Tempe picked that closed; a selected COSTAR Tempe that closed; the alerts; a read with its number unknown no longer kept. Nits, fixed: the last COSTAR Tempe set recorded as it's set; a Stopwatch; the texts; the advice's side effect (switching branch pauses mobile).
- **Round 3** (those fixes): no High or Medium. Low, fixed: an old look could send a false Discord alert after other work held Free back → only a look under 30 s old counts. Nits, fixed: CHECK AT THE PC no longer twice in a save's result; `Running` renamed `Alive`. Left as it is: a print that printed stays green with the warning in its notes (the page's print result; the website isn't part of this update); "the selected COSTAR" in CostarWindows.Main's words if COSTAR Tempe closes between the look and the run.
- Checked and correct (the reviews): every key and click goes to the phone's own Repair Order (foreground and focus checks, the runner's focus recovery only for another program, notices and Document Already Open only when owned by it, CloseRo its own window only); the open's checks before every click, wheel and key; Document Already Open's form must be new; new windows told apart from the ones there before; the one asked for refused before anything is closed; the ordinary ones closed as in 2.9.5, each read afresh right before; the wholesale dry run (`stay` null), phone jobs, eBay orders and the Online orders tab unchanged; the selection never changed; only RO numbers and online order numbers in the phone's words and the day log; C# 5 (the PC's csc /langversion:5).

## Checks performed here

- Compiled at C# 5 against the five reference sets: 0 errors, the usual 3 warnings. C# 5 scans: as 2.9.2.
- Self-tests: 158 + the 4 that need Windows = 162; Order Check 16/16. The new cases: who stays, each fate and its words, a new one's empty number box (and a box unread, other words, no label), the one asked for, the first look (a new one held for review stays for any request; a number unread: Free waits, a request stops; someone at the PC: a request stops, Free waits; the first that waits ends the look), only the kept ones as the open's, what the phone hears (ready; closed and left; CHECK AT THE PC; a request's words); COSTAR Tempe whichever is set (the one set, the one set last, the only one, one that closed, two and none chosen, never Order Check's), the 2-minute wait with another set, the lease in COSTAR Tempe with the helper still set to Sydney, held back as phone work, the COSTAR each branch was set in last.
- Mutations: 42 deliberate bugs, each made to the code as it stands and run against the self-tests, all caught: who stays (held, an online order's, COSTAR asking, someone at the PC), each fate (no blocker, no quiet, held ignored, one unread closed, the held words), the first look (the one asked for let through, the look going on past a wait, a number unknown let through, a request's words, a kept one closed), `MayBe` (leading zeros, unread, a new one taken for it), `NumberKnown`, `NumberChanged`, the empty number box (any box, never), `OnlyKept`, the words (maybe, the PO#, a new one, one or many, it was/they were, the kept ones, CHECK AT THE PC, `StopWhy`, `CheckWords`), and the branch: the one set taken whatever its branch or after it closed, Order Check's window, the one set last, the first of two, the 2-minute wait never or even with COSTAR Tempe set, the lease without the hold or in the selected COSTAR, the one set last not recorded.
- **The clock moved on** (as for 2.9.3): the self-tests at 7 points from now to 3 years ahead in Sydney time (15 hours, 30 days, a year, the April 2027 daylight-saving change, a Sunday, 1100 days): every group passes at each, Order Check's 16 too, apart from the clean-up group, which makes its files at the real time and passes at the real time.
- Package checks, the startup page checks, the Repair Orders page checks and Order Check's C# 5 scan pass. Install replay with the Updater the PCs run over 2.9.5, 2.9.4, 2.9.3 and 2.6.12: PASS (92 files). Scans of everything that leaves: no tokens, keys, pairing or connection files; report numbers (all reports, and every day log's Repair Order and online order numbers): only the historical hits, none in 2.9.6's text or code; none of the dry runs' order numbers; only made-up phones, emails, eBay and wholesale order numbers.

## Not verified here (no Windows or COSTAR here)

- COSTAR opening a second Repair Order from Work-in-Progress while one is open, and leaving the first one as it was; the CHECK AT THE PC words if it doesn't (TEST-PLAN 2.9.6 items 2 to 5).
- The phone's Repair Orders in COSTAR Tempe with the helper set to Sydney, after the 2 minutes (item 7).

---

# Validation — v2.9.5 — 9 November 2026

## Basis

- **The ask.** 9 Nov 13:40, Tommy: "can you please add "update" button so next time I uploaded to github i dont have to close and open the thing, and click update, and close open, you know what I mean?"
- **How updates went until now** (the day logs, 2 to 4 Nov): the helper looked for a new version when it started and every 6 hours (hourly after shop hours), so after an upload it was closed and opened to see it; the yellow line, Yes, then the restart into the new version by itself (about 45 s later, every time).
- 2.9.5 is 2.9.4 (15f2ff0) plus this.

## Changes

- **`Updater.CheckNow`:** latest.json fetched at once from the helper folder with a query of its own (`FeedNow`: `?now=<ticks>`), so GitHub Pages' and any proxy's cached copy (up to 10 minutes) isn't used; the same checks as ever (`Validate`, the helper folder only, no redirects). It says whether GitHub has a newer version, or why it couldn't be reached.
- **Update now** on the desk receiver (beside its chips) and on the RDP helper (top right): while it asks, "Checking GitHub ..."; a newer version → the yellow line's own way (the question with the version and its notes; the download, every file checked, the restart into it by itself), the newest on GitHub winning over one offered earlier; nothing newer, or GitHub not reached → said in a box. The desk receiver: an update installed by itself and waiting restarts at once (as the yellow line). The RDP helper: not while something is being entered (said in a box and the log; nothing stopped).
- The checks by themselves and the installs after shop hours are as they were. Version 2.9.5 - Update button.

## Checks performed here

- Compiled at C# 5 against the five reference sets: 0 errors, the usual 3 warnings. C# 5 scans: as 2.9.2.
- Self-tests: 156 + the 4 that need Windows = 160; Order Check 16/16. The new case: each check its own address in the helper folder; the button's words.
- Mutations: the feed without its query, the same query each time, the version left out of "the newest", "stopped for the update": all 4 caught.
- Package checks, the startup page checks and Order Check's C# 5 scan pass. Install replay with the Updater the PCs run over 2.9.4, 2.9.3, 2.9.2 and 2.6.12: PASS (92 files). Scans of everything that leaves: no tokens, keys, pairing or connection files; report numbers (all reports, and every day log's online order numbers): only the historical hits; none of the dry runs' order numbers; only made-up phones, emails, eBay and wholesale order numbers.

## Not verified here (no Windows here)

- The buttons themselves, and GitHub Pages answering the address with its query (it serves the file whatever the query: TEST-PLAN 2.9.5).

---

# Validation — v2.9.4 — 9 November 2026

## Basis

- **The ask.** 9 Nov 10:45, Tommy, with a diagnostics ZIP whose map (10:43) shows COSTAR's "Document Already Open" in front: "the mobile repair order will stop if document is open on another pc, can it tells me instead and automatically press ok? by pressing ok, it will go to the repair order screen so I can keep using it even though i cant go to that order".
- **It happened before.** The day logs of 6 Nov 11:33 and 8 Nov 13:10: a phone request waited 30 s (no Repair Order window showed: the form behind the window is titled "Branch 11  Tempe Tyres Tempe", without its "RepairOrder" yet), then stopped ("COSTAR's main window couldn't be brought in front"), and every request after it stopped at once until a person pressed OK.
- **The map.** A COSTAR window of its own (WinForms, not a message box), titled "Document Already Open", 400x170, owned by the Repair Order window being opened ("Branch 11  Tempe Tyres Tempe", disabled behind it, only its toolbar drawn yet), its words in two labels (82 and 69 letters, not shown in the map) and two buttons: OK (with the keyboard) and Retry.
- **Before 2.9.4.** The phone's open, change or print waited 30 s ("Another window is in front of the Repair Order") and stopped, leaving the window for a person.
- **The same report** showed the Tempe Orders page's orders paused since Fri 6 Nov 11:07 (two stops before Add new a minute apart, the second "The selected COSTAR is not ready to open a new order.", which wasn't taken for "nothing typed"), never resumed until Monday.
- 2.9.4 is 2.9.3 (3ab3f93) plus these.

## Changes

- **`DocumentInUse` (Runner.Popups.cs):** `Is` (pure: that title, a COSTAR form's class, exactly two buttons, OK and Retry, both usable), `Read` (its title first, then its OK and its words, labels top first), `Words` (one line, 300 letters), `Answer` (looked at again right before: the same window, the same OK, both usable; OK's BM_CLICK sent once; waited for while it closes), `Message` (the phone's words). `RoInUseException`: the message for the logs, COSTAR's words (`Said`) apart, for the phone only.
- **Where:** `RoWip.WaitForWindow` (the case seen: in front before a Repair Order window shows; Repair Orders only, so the wholesale dry run's Orders are as they were), its owner a Repair Order form of this branch (`FormOf`, with or without "RepairOrder") that the open made (not the main window, not among `RoOpenWatch.BeforeAll`); and `Runner.WaitForRo` (owned by a Repair Order window that has shown). Right before the press, the usual look (nobody at the PC, not stopped). OK pressed and closed: the request ends with `RoInUseException`; still showing after 6 s: a stop for a person (nothing more pressed); changed in between: nothing pressed, looked at again (said once).
- **After OK (`AfterInUse`):** the form COSTAR was opening it in, up to 5 s: gone (COSTAR closed it); another Document Already Open over it (a stop, never pressed); or left open, usable, nothing of COSTAR's over it for a second, and nobody at the PC since the open began: closed with its own close (WM_CLOSE; nothing was typed in it). Otherwise the phone hears that a window was left open.
- **`RoEngine`'s end of a request:** nothing was typed, so the Repair Order window the open made is closed as before (WM_CLOSE, only with nothing of COSTAR's open on it), or found gone. The phone hears "Repair Order … is open on another PC, so it can't be opened (changed, printed) from the phone until it's closed there. The helper pressed OK on COSTAR's "Document Already Open".", COSTAR's words, and that nothing was changed and COSTAR is ready for the next one (or that a window was left open). Not "Stopped:". COSTAR's words go to the phone only: the day log (`ro_<kind>_in_use`, `ro_in_use`), the helper's log and status line, Diag and the run's report (`CaptureForegroundWindow` no longer dumps that window) don't have them.
- **The page's orders:** `CostarWindows.OpenNew`'s refusals before Add new (`AlreadyOpen`, `AddNewBusy`, `AddNewUnknown`, `NotReady`) all end "Add new was not pressed." (`Unattended.NotEntered`: also eBay orders' and phone jobs' one retry). `OnlineInbox.MostTries` 2 → 5: a stop that typed nothing is tried again up to 5 tries in all, each later than the one before (`RetryDelay`: 1, 2, 4, then 8 minutes; all within the 25 minutes an order waits), then the pause as before. "Add new moved." (twice) says so too. `AutoCostar` waits while COSTAR's main window is disabled (a window of COSTAR's over Work-in-Progress).
- Version 2.9.4 - Open on another PC.

## Review

- **First review** (independent, of the first version): 1 Medium, 4 Low, nits. Medium, fixed: the case seen on site is the one before a Repair Order window shows (the form behind is titled without "RepairOrder"), and what COSTAR leaves after OK was never closed (the end of the request looks only for "RepairOrder" windows) → its owner identified and checked before the press, and closed after (`AfterInUse`). Low, fixed: COSTAR's words could reach the run's report (`CaptureForegroundWindow`) and the helper's log → kept out; no look for a person or Stop right before the press on that path → added; a note every 50 ms while OK isn't pressed → once; the page's retries could bring COSTAR in front every minute → 1, 2, 4, 8 minutes apart. Nits, fixed: the two "Add new moved." refusals, the words per kind (open, change, print), the status line, "tried once more", the 11:06/11:07 times, "a window of its own open", 6 s for the window to close.
- **Second review** (of those fixes): 1 High, 1 Medium, 4 Low, nits. High, fixed: after Document Already Open, the end of the request could still take a fresh "RepairOrder" window for the open's own and close it, even with a person at the PC (a Repair Order they opened in those seconds) → nothing more is taken over after Document Already Open, and a person seen by `AfterInUse` is noted. Medium, fixed: an order still being tried when its 25 minutes were up was let go, and the page's next copy started its tries again (it might never pause, and Discord wouldn't hear) → it stops for a person and the page's orders pause; and a test that all the waits fit in the 25 minutes. Low, fixed: the last look before the close (still usable, nothing of COSTAR's over it, not asked again, not stopped) right before WM_CLOSE; a question as it closes said as such ("asked": never answered), and "ready" only with COSTAR's main window usable again ("busy" otherwise); the open's own forms taken again right before each press (a person's form opening meanwhile never taken for the open's own) and only one new form; the person check before the press on the Runner path too. Nits, fixed: comments and the 2.8.1 group's title, the sum check, "Add new moved." as a named refusal tested with the others, the stop's words when a person stops the press, a note (no words) when the window is seen but not answered (its owner the main window, there before, or not a Repair Order form), TEST-PLAN: leave the RDP PC alone. Left as it is: it counts as "stopped" in the run's report (Runner path only).
- Checked and correct (both reviews): Retry never pressed; exactly OK and Retry, both usable, that title, a COSTAR form's class (never a message box), this COSTAR's process; the look again right before the press; nothing typed (presses aren't writes); the exception reaches the end of the request; COSTAR's words only in the phone's answer; the wholesale dry run unchanged; every refusal before Add new is before anything was pressed for that order; `NOT_ENTERED` (the phone page) and `Unattended.NotEntered` agree; tries counted on start, given back on Back; the main window disabled only under a COSTAR dialog in all the saved maps; C# 5.

## Checks performed here

- Compiled at C# 5 against the five reference sets: 0 errors, the usual 3 warnings. C# 5 scans: as 2.9.2.
- Self-tests: 155 + the 4 that need Windows = 159; Order Check 16/16. The new case: the mapped window (title trimmed, any case, buttons either way round), never a message box, another title, one, three or other buttons, a greyed or unread button; its words on one line, 300 letters; the message for the logs without COSTAR's words; the phone's words (not a stop; a window left open said); `PopupKind` never takes it for a notice; every refusal before Add new tried again. The 2.8.1 group: stops 2 to 4 before Add new tried again a minute later, nothing paused; the 5th pauses.
- Mutations: 27 deliberate bugs, each made to the code as it stands and run against the self-tests: `DocumentInUse.Is` for any title, any class, more buttons, OK alone, the title's case; its words unquoted or unlimited; the phone's words as a stop, without COSTAR's words, with them in the helper's log, a window left or COSTAR busy said as ready, every kind as "opened"; COSTAR's words in the logs' message; `FormOf` for any branch, or only with "RepairOrder"; `RetryDelay` always a minute, without its cap, a longer cap; `MostTries` 2 or 100, the count ignored; an order still being tried let go at 25 minutes, or stopped without the pause; the "Add new was not pressed" taken off three refusals. All 27 caught.
- Package checks, the startup page checks and Order Check's C# 5 scan pass. The clock moved on (Sydney time, as 2.9.3): now, 15 hours, 30 days, a year, 1100 days, the April daylight-saving change and a Sunday: every group passes (the clean-up group as before: its files keep the real time). Install replay with the Updater the PCs run over 2.9.3, 2.9.2, 2.8.1 and 2.6.12: PASS (92 files). Scans of everything that leaves: no tokens, keys, pairing or connection files; report numbers (now also the 9 Nov report's, and the online order numbers in every day log): only the historical hits; none of the dry runs' order numbers; only made-up phones, emails, eBay and wholesale order numbers.

## Not verified here (no Windows or COSTAR here)

- COSTAR's "Document Already Open" itself: its words, what OK leaves (Work-in-Progress, or an empty Repair Order window that the helper then closes), and the phone's message (TEST-PLAN 2.9.4).

---

# Validation — v2.9.3 — 9 November 2026

## Basis

- **The report.** 9 Nov 09:53, Tommy, with a screenshot of the phone's Repair Orders page ("Waiting: the Online orders tab is open on the RDP helper"): "This should never happen, it is mobile for a reason, how do we fix this".
- **Why it happened.** Since the first online orders (README: "Selecting the Online orders tab pauses new mobile dispatch"), `EntryCoordinator.MobilePaused` is true whenever the RDP helper's Online orders tab is the one showing, and everything from the phone waited on it: phone jobs (`Worker`: not accepting, no inject or close), phone Repair Orders (`RoWorker.Free`, `TryBegin(...,true)`) and mobile coming back on by itself at start (`WhyNotResume`). A helper started with Start-Online.cmd (`--online`) opens on that tab, an update starts it again the same way, and a click on the tab leaves it there, so the phone waited with nobody at the PC.
- 2.9.3 is 2.9.2 (4178ee9) plus this fix.

## Changes

- **`EntryCoordinator`:** `MobileHeld` = the Online tab showing (`MobilePaused`, still set by the tab) and someone using the PC: `Holds(ms)` is true when a person's last key or mouse input was less than `OnlineHoldMs` (2 minutes) ago, or can't be read (held, as before). `TryBegin(owner, mobile:true)` refuses only while held. `SinceInputMs` defaults to `Native.MsSinceInput`; tests give their own.
- **`Native`:** `OwnInput` (the last input is the helper's own: it has sent input since it started, and the last input came within 60 ms of its last send, compared as a difference), `ActiveWithin` (`UserActiveWithin` on it: unsigned, so right up to 49.7 days) and `SincePerson` (`MsSinceInput` on it). Right before each `SendInput` (`Sending`, in place of the four `LastSyntheticTick=` lines) the person's last input is kept when the last one is theirs, so after the helper's own typing `MsSinceInput` counts from the person's last key or click, not from nobody.
- **Every reader of the tab state for phone work** now reads `MobileHeld`: `Worker` (the detail the desk and phone see, accepting, inject/close, its poll interval), `RoWorker.Free` and its two refusals when the lease is refused, `RunsByItself.ResumeMobile` (retried every 30 s, so mobile comes back on once the PC has been left alone). The words: "someone is using the RDP PC, with the Online orders tab showing", and when it goes on. The helper's status lines say "held" only while it is.
- **The 2.8.1 self-test group** ("Tempe pickups by themselves") used a fixed 3 Nov 01:00 UTC for its made-up inbox. `OnlineInbox` lets go of finished orders 4 days after they last changed (`Keep`), by the real clock, after every change, so from 7 Nov the group's orders were dropped at once and it failed (NullReferenceException), on 2.9.2 as well. Build.ps1 stops a new build whose self-tests fail ("Self-tests failed. COSTAR was not changed."); 2.9.2 as installed doesn't run them again (same executable), but Check-Build.cmd would have failed, and a failed run removes the stamp, so the next start would have failed too. The group now uses the current time. A Repair Order test's "a date years away" (2030-01-01, inside the 400 days allowed from 27 Nov 2028) is now three years from today.
- Version 2.9.3 - Online tab fix.

## Review

- **One independent review** (of the first version: the 2-minute hold, the test's date), with the code's paths walked through for a person doing online orders by hand. Acted on:
  - **High, fixed:** the helper's own typing hid the person's last input (Windows keeps only the last one). After an online order sent by hand and typed with hands off, the hold ended with the typing; with "Close online orders that need no checking" (the default) COSTAR was free again, and a waiting phone job could take it while the person was still there (their next click elsewhere would stop it part way). Now the person's last input is kept under the helper's (`Sending`, `SincePerson`): the 2 minutes run from their click on Fill.
  - **Medium, fixed (there before 2.9.3 too):** with Windows up 24.9 to 49.7 days, `LastSyntheticTick`'s 0 made every key and mouse move the helper's own until it first typed (after each start, an update say): the waits for a quiet moment didn't wait, and in 2.9.3 the Online tab wouldn't have held anything. Nothing is the helper's own now before it has sent input (`OwnInput`).
  - **Low, fixed:** no input for more than 24.9 days read as "just now" (signed ticks): unsigned now, in both.
  - **Low, fixed:** the 2030 date in a Repair Order test (above).
  - **Nits, fixed:** the words say what the hold is (any key or mouse on the PC with the tab showing, not the tab itself); a refusal between `Free()` and `TryBegin` that is the hold says so (it said another entry was filling COSTAR); comments.
  - **Left as it is (Low):** with the PC left alone 2 minutes, the Online tab is as the Mobile jobs tab: a Repair Order a person opened by hand in COSTAR, empty or with no online or eBay order's PO#, may be closed by a phone Repair Order after its quiet seconds (2.6.7's rule), and Fill then opens a fresh one. Holding the phone while an order is loaded in the tab would put back the wait Tommy asked to remove.
- Checked and correct (the review): every reader of the tab state for phone work; the lease and `CostarInputLock` (entries never interleave); phone work starting only with COSTAR on Work-in-Progress and after its quiet seconds; Repair Orders it never closes (the last fill's or a stopped order's, a TTW PO#, COSTAR asking something); focus checked before each word and key; the lock (`SinceInputMs` takes no locks and sends no messages); C# 5; no other test tied to the date or the Sydney time of day.

## Checks performed here

- Compiled at C# 5 against the five reference sets: 0 errors, the usual 3 warnings. C# 5 scans: as 2.9.2.
- Self-tests: 154 + the 4 that need Windows = 158; Order Check 16/16. The hold's case: someone at the PC (held, mobile's lease refused, online's not), 1 ms short of 2 minutes (held), 2 minutes (not held, mobile's lease given), unknown (held), another tab (never held), the hold minutes not hours. The new case: the helper's own input (60 ms; nothing before it has sent any, also past 24.9 days; across the tick count's turn), a person within a few seconds past 24.9 days, no input for 24.9 days (nobody, long ago), the person's last input kept under the helper's own, never seen (unknown).
- **The clock moved on:** all self-tests run again with the wall clock moved (an `LD_PRELOAD` shim on `clock_gettime`/`gettimeofday`/`time`; the monotonic clock untouched) in Sydney time. First version: 60 points (every 5 hours for a week from now, then 8 days to 2 years ahead, Christmas, New Year's Eve and New Year's Day, both 2027 daylight-saving changes (the hour that comes twice, the hour that never comes), 29 Feb 2028, a month end, a Saturday and a Sunday). This version: 17 points: now, 5 and 15 hours on, then 8 days to 10 years ahead (among them 1000 and 1100 days, past 27 Nov 2028, when the old 2030 test date would have failed), New Year's Day, the April daylight-saving change and a Sunday. Every group passes at each, Order Check's 16 too, apart from the clean-up group, which makes its files at the real time (the shim moves the clock, not the files' times) and passes at the real time.
- Mutations: 22 deliberate bugs, each made to the code as it stands and run against the self-tests: `Holds` always, never, at exactly 2 minutes, unknown taken for nobody; `MobileHeld` without the tab, without the input, or either one; `TryBegin` without the input, without the tab, holding the online entry, or no hold at all; the hold made an hour, or 10 seconds; the 2.8.1 group's made-up inbox put 5 days back (the bug this fixes); `OwnInput` without "has sent", any earlier input taken for its own, 100 ms; `ActiveWithin` signed, or the helper's own counted; `SincePerson` with the helper's own taken for nobody (the review's High), never seen taken for nobody, signed. All 22 caught.
- Package checks, the startup page checks and Order Check's C# 5 scan pass. Install replay with the Updater the PCs run over 2.9.2, 2.9.1, 2.8.1 and 2.6.12: PASS (92 files). Scans of everything that leaves: no tokens, keys, pairing or connection files; report numbers: the same 18 historical hits; none of the order numbers in the dry runs' day logs; only made-up phones, emails, eBay and wholesale order numbers (the same lists as 2.9.2).

## Not verified here (no Windows or COSTAR here)

- `GetLastInputInfo` in the RDP session (a person's keys and mouse through Remote Desktop count as input there; the helper's own come within 60 ms of its send, as the day log has shown since 2.6.6), and the hold ending 2 minutes after the PC was last used (TEST-PLAN 2.9.3).

---

# Validation — v2.9.2 — 4 November 2026

## Basis

- **The report.** 4 Nov 02:14, Tommy, with a screenshot (COSTAR's Notes window over an Order; the helper's Wholesale tab: "Stopped: COSTAR showed a window over Order ... ("Notes") that the dry run doesn't answer") and a diagnostics ZIP: "Please fix this".
- **What the diagnostics showed.** The day log of 4 Nov: 2.9.1 installed 02:02; three runs, the first two stopped as the PC was used; the third went through 11 orders: 8 "sell" (each one's tyre line clicked open, Sydney's "= Avail" read, the line closed again once the keyboard left the lines, the order found unchanged; no NON-STOCKING) and 3 NO CARD DETAILS; on the 12th, the Point-of-sale Memo got OK at 02:09:18.6 and the run stopped on the customer's Notes 0.2 s later. The same order had gone through on 3 Nov 17:06 (memo, then the Notes 1.6 s later, both answered). The map of 02:09:46: the Notes window as always (title "Notes", WinForms, owned by the Order, one enabled OK). So the Notes were looked at while COSTAR was still making them: `Runner.PopupKind` needs exactly one enabled OK whose words read, and a button's words are read with a 100 ms limit (`Native.TryText`), so a COSTAR busy filling the Notes gives "?".
- 2.9.2 is 2.9.1 (d7c7a8d) plus this fix.

## Changes

- **`WholesaleRun.Notices` / `Answer` / `Look`:** a window over the order that can't be answered is looked at again every 100 ms while it isn't read in full (`WholesaleRules.NotReadYet`: no button, a button greyed or its words unread, a message box with words unread), until 5 s after it was first seen (`UnknownNotice`: each window its own time, forgotten when gone); one read in full that isn't the Notes or a memo stops the run at once, as before. Nothing is pressed in either. The Notes or a memo not read in full are looked at again too, never answered half read. The 20 s limit for an order's notices stays, with the waiting window's own words. Day log `wholesale_notice_wait` the first time a window is looked at again, `wholesale_notice_stop` when one stops the run: counts only (buttons, greyed or unread, a message's words read or not), never a word of the window.
- **Before an OK goes:** for the Notes, COSTAR must answer the window (WM_NULL, up to 2 s; else looked at again, nothing read or pressed); the window is looked at once more right before the press (still enabled, same kind, the same one OK) and Stop checked; otherwise looked at again, nothing pressed.
- **`WholesaleNotes`:** the Notes read whole or not at all: a call COSTAR doesn't answer, an empty object or fewer got than it has, more than 100 under one object, more than 600 in all or deeper than 16 levels, or no rows, is "can't tell" (2.9.1: what was read decided, and an empty list was "no card details"). Windows' frame parts (title bars, scroll bars, the system menu: `CostarMap.Frame`) aren't opened, as the map does. The 4 Nov map's Notes: 86 objects with one note, about 8 more a note, cells 11 levels below the window's client: room for about 65 notes. "No" only when a second read 0.5 s later, made only while COSTAR answers, agrees with as many notes (`Settled`); a note with card details there by the second read is yes.
- Tests: a new group (`NotReadYet`, `UnknownNotice`); the Notes group: calls not answered, an empty object, the limits, frame parts, two reads. Version 2.9.2 - Wholesale Notes fix.

## Review

- **First review** (independent, of the first version: the 5 s look-again and the empty list): 3 defects, 2 minor findings and 2 nits, all acted on. A part-filled Notes list could still give "no" → "no" only from two reads that agree. A note COSTAR doesn't give was read as an empty note, and a read cut short by the limits still decided → the Notes read whole or not at all. COSTAR not answering the Notes had no branch of its own, and nothing was looked at again before the press → both added. The 5 s also covered windows read in full → only those not read in full. One timer for all windows, nothing in the day log → each window its own time; `wholesale_notice_wait`.
- **Second review** (of those fixes): nothing presses what it shouldn't, or twice. 1 minor defect and 4 nits, fixed: an empty object from COSTAR, or a child's number put in for one that couldn't be got, was dropped without a word (WinForms then answers for the parent) → can't tell; counts logged on a stop too; the second read only while COSTAR answers (nothing waits on a COSTAR gone busy); a memo with words unread is looked at again, never answered; a test's wording. Left as they are: a customer with more than about 65 notes is "can't tell"; "fewer got than it has" can only happen with COSTAR's own accessibility, so it isn't exercised here.

## Checks performed here

- Compiled at C# 5 against the five reference sets: 0 errors, the usual 3 warnings.
- Self-tests: 153 + the 4 that need Windows = 157; Order Check 16/16.
- Mutations of this fix, each made to the code as it stands and run against the self-tests: the Notes reader and its two reads (18: a missing column or no rows taken for "no", the limits made larger or partial, failed calls, an empty object or a failed child let through, frame parts opened, the second read skipped, made while COSTAR is busy or compared loosely), `NotReadYet` (5), `UnknownNotice` (7: no wait, never stopping, a window read in full waiting, one clock for all, gone windows kept, every look a first, a wait of a minute) and the card rules again (8): 38 of 38 caught.
- Install replay with the Updater the PCs run over 2.9.1, 2.9.0, 2.8.1 and 2.6.12: PASS (92 files). Scans of everything that leaves: no tokens, keys, pairing or connection files; report numbers: the same 18 historical hits; none of the order numbers in the 3 and 4 Nov dry runs' day logs; only made-up phones, emails, eBay and wholesale order numbers. Package checks, the startup page checks and Order Check's C# 5 scan pass.

## Not verified here (no Windows or COSTAR here)

- The run past a memo followed by the Notes on COSTAR Sydney (TEST-PLAN 2.9.2); the Notes read through COSTAR's own accessibility.

---

# Validation — v2.9.1 — 3 November 2026

## Basis

- **The report.** 3 Nov 17:10, Tommy, with two diagnostics ZIPs after the first 2.9.0 dry runs: "please review on the non stocking clearly tyres are available, or am i reading the reports wrong? but dry run looks solid".
- **What the diagnostics showed.** The day log: 4 runs (the first three stopped as the list was read: the PC was used); the fourth looked at 18 orders: 3 CASH without card details (NO CARD DETAILS), and all 15 tyre lines read as NON-STOCKING (CHECK STOCK). Each of those lines was clicked once, closed again once the keyboard left the lines, and every order was read again and found unchanged (no `wholesale_order_changed`). Tommy's map of 17:09:50 (an Order with its tyre line open): the line's Frame1 holds the stock panel with Sydney's numbers in it (ThisBr "= Avail" 2 characters) and, under it, the "NON-STOCKING!" label: Frame1's children in Windows' order put the stock panel first (above), and it covers the label. The 3 Nov 14:45 map has the same label under the same panel, on a closed line whose boxes were empty: that was no NON-STOCKING item either.
- 2.9.1 is 2.9.0 (32dcab7) plus this fix.

## Changes

- **`WholesaleOrderReader.Stock`:** NON-STOCKING only when its label shows: not covered by anything above it in Windows' order, at its own level or any of its panels' up to the line's (`Covered`: a sibling before it in the snapshot, showing, over the label's middle; a label not in the read counts as covered). A number in ThisBr "= Avail" with NON-STOCKING! showing over it: a problem (neither taken); any problem is never taken for NON-STOCKING. An empty "= Avail" with the label covered: "is empty" (stock not checked).
- **`WholesaleOrderReader.Parse`:** a line is `Open` when its panel is at least twice its item box's height (20 against 20 closed, 160 open on the maps; by the boxes, so the PC's display scaling doesn't matter).
- **`WholesaleRun.ReadLine` / `ReadNow`:** a line's stock is read only while it's open (from the same read); a closed line is clicked open even when COSTAR kept a stock panel in it from before (it empties it when the line closes: the 14:45 map); a line opened meanwhile isn't clicked; a NON-STOCKING read is read again after the notices' wait (a stock panel that came late would cover the label), so only a lasting one counts; "its stock panel didn't show" for a line that was open already.
- Tests: the made-up stock panel now always holds the NON-STOCKING! label under it (as on the 17:09 map); NON-STOCKING items have no stock panel over the label; new: the label covered with Sydney's numbers (2.9.0's bug), covered with empty boxes, showing over a number (a problem), showing over empty boxes, which controls cover which. Version 2.9.1 - Wholesale stock fix.

## Review

Independent review of the fix (read-only): no blockers. Fixed after it: a NON-STOCKING read taken at once after the click (a stock panel coming late would make an in-stock tyre CHECK STOCK again) → read again after the notices' wait; a problem could still count as NON-STOCKING (an unreadable box under a showing label) → never; `Covered` looked only at the label's own siblings → up through its panels to the line's; a label not in the read counted as showing → covered; the line's height read after the snapshot and fixed at 25 px (display scaling) → from the same read, against the line's item box; the words for a line open already. Its last point, run here: the fixed reader replayed on the real 3 Nov maps (words removed; box contents as digits of their length): the 17:09 Order with its tyre line open: line 1 open, read through its read-only words box, Sydney's "= Avail" read, not NON-STOCKING; the same with the stock panel taken away: NON-STOCKING; the 14:45 Order (its line closed, boxes empty): line 1 closed (it would be clicked open first), not NON-STOCKING; the order's fingerprint: 61 line boxes and 10 totals on the real layout.

## Checks performed here

- Compiled at C# 5 against the five reference sets: 0 errors, the usual 3 warnings.
- Self-tests: 152 + the 4 that need Windows = 156; Order Check 16/16.
- Mutations: 104 of 104 deliberate bugs in the wholesale code caught by the self-tests, the 35 of the stock reader, the order's read and the compare re-run on this code; among them 2.9.0's own bug (the label taken whether covered or not), a cover that looks at controls under the label too, and a number taken with NON-STOCKING! showing.
- Install replay with the Updater the PCs run over 2.9.0, 2.8.1, 2.8.0 and 2.6.12: PASS (92 files). Scans of everything that leaves: no tokens, keys, pairing or connection files; report numbers: the same 18 historical hits as 2.9.0; none of the order numbers in the 3 Nov dry run's day log; only made-up phones, emails, eBay and wholesale order numbers. Package checks, the startup page checks and Order Check's C# 5 scan pass.

## Not verified here (no Windows or COSTAR here)

- The dry run on COSTAR Sydney with tyres in stock (sell verdicts), and a real NON-STOCKING item (what COSTAR shows for one hasn't been mapped: if the label shows over the stock panel with no numbers, it's read as NON-STOCKING; anything else: stock not checked) (TEST-PLAN 2.9.1).

---

# Validation — v2.9.0 — 3 November 2026

## Basis

- **The ask.** 29 Oct, Tommy: "ok this is now for wholesale order, we will do it slowly. do not release anything yet"; 2 Nov 20:47: "not yet, havent got the deal yet, but make it ready on the back end"; 3 Nov 12:48 the process: "open order, check terms, check notes, check stock, if everything ok, sell and cancel, if not ok, put on comments" (future ShipDates "leave it for now", "close equal to save", BUF / BUFF / WWW BUFFALO count); 14:51 the maps of an opened tyre line, of Sell's window and after Cancel ("for selling, I am doing it on repair order, interface will be the same"); 15:54: a NON-STOCKING tyre gets CHECK STOCK, an order's own tyres are "part of the commited" (so they're added back to "= Avail"), NO CARD DETAILS "yes please", and the dry run to try "once you are done with questions".
- The process as decided (30 Oct – 3 Nov): `claude/20-Wholesale-Order-Plan.md` in the project. Stage 1 is a dry run: it shows what the helper would do and changes nothing. Typing the comments (stage 2), Sell + Cancel (stage 3), the branch change and the Discord messages come later.
- 2.9.0 is 2.8.1 (7b1c068) plus this. Helper only.

## Changes

- **`Source/Wholesale.cs` (new).** `WholesaleRules` (pure): the orders opened (Ship Via starting BUF; Comment empty, WWW, BUF, BUFF, BUFFALO or WWW with one of those; ShipDate not after today in Sydney; oldest first, empty dates last; 30 a run); Terms (COSTAR's 14 codes; empty, unreadable or unknown → left alone); card details for CASH (in one note a Luhn-valid card number and an expiry; only yes / no / can't tell kept); tyres (a tyre size in Size or Description); the stock rule (ThisBr "= Avail" plus this order's Order Qty of that item, more than 4; NON-STOCKING short); the verdict (sell / CHECK STOCK / NO CARD DETAILS / leave / stock not checked, with why). `WholesaleList` (the "Orders yet to be filled" list through accessibility, exact column names), `WholesaleOrderReader` (the Order window: number, Terms, Comment, the Notes marker, the tab showing, lines by panel and headings; a line's stock panel; the order's fingerprint and what changed), `WholesaleNotes` (card details yes/no from the Notes window's grid; the words never kept), `CostarMenu` (the left-hand menu's item by name), `WholesaleRun` (the run: COSTAR Sydney on Branch 1, a quiet moment, the entry lease and input lock, Wholesale Order pressed through accessibility, Include Filled Orders unticked, a filter cleared, Search, the list read, each order opened with the Repair Order open routine for this list, its number checked at once, the customer's Notes and a Point-of-sale Memo answered with OK (anything else stops with nothing pressed), the order read, the stock read, the order closed with WM_CLOSE only when read through, unchanged, Stop not pressed and nobody at the PC; Repair Order pressed at the end and after a stop that wasn't a person's).
- **The stock read:** only when everything else is fine. The order's fingerprint first (every line's own boxes by number and heading, its number, Comment, Terms, the totals); each tyre line found again, its stock panel read as COSTAR shows it, else one click into its words box (read-only only; never the item box) with the order in front, COSTAR answering, nothing over the order, the box still for 150 ms and under the point, the line still not open, no double click, no key held, nobody at the PC and Stop not pressed; the panel read twice alike; then the order's number box clicked so COSTAR leaves the last line, notices answered, and the order read again: anything changed or a new COSTAR window → the run stops and leaves the order open for a person. Day log: `wholesale_line_click`, `wholesale_stock`, `wholesale_lines_left`, `wholesale_order_changed` (names of boxes, never their words).
- **`Source/WholesaleTab.cs` (new), `Source/DesktopUi.cs`:** the Wholesale tab (last): Check wholesale orders (dry run), Stop, the BUF orders and what the helper would do, an order's details (Terms, Comment, card details yes/no/can't tell, memos, lines with their stock); Stop all stops it.
- **`Source/RoWorker.cs`:** `RoListKind` (Work-in-Progress and "Orders yet to be filled"); `RoWip.Open` / `OpenDirect` / `WaitForWindow` / `AllOrders` / `Screen` take the list (Work-in-Progress exactly as before); `PressSearch` and `AllOrders` internal. `Source/OrderCheck.cs`: `WipScreen.Locate(main, title)`.
- **`Source/CostarMap.cs` (Map COSTAR screen):** a customer's words shown as labels are kept as their length only, in the controls and in accessibility alike, each part by itself and each with what the other hid: the labels right of "Customer" on its row (COSTAR's captions there such as Terms kept), a Point-of-sale Memo's words, and a label's words over 40 (2.8.1 kept the Cashier window's customer name, and a memo's words in the accessibility part).
- **Tests:** `Source/WholesaleTests.cs` (8 groups) and a map group in `Source/RoTests.cs`; `MobileTests.cs` runs them. `Build.ps1` lists the three new files. Version 2.9.0 - Wholesale dry run.

## Review

Independent reviews (each by someone who didn't write the code, read-only):

1. **First (of the dry run before the stock read):** blockers fixed: WM_CLOSE (which saves) sent without a nobody-at-the-PC check and after Stop; any one-OK message answered (now only the customer's Notes and a Point-of-sale Memo); the stop reason logged with COSTAR's words (now `RoText.ForLog`). Also fixed: the order's number checked only after the notices (now at once, before any notice is answered); Repair Order not pressed after a stop; the order's own Comment unused; prices and dates taken for card expiries; the Notes marker hidden when the Notes tab shows; a greyed pop-up answered; cleanup (the progress ended without the lease, an accessibility root not released, an order open after a failed open); hidden duplicate list columns; note lines' words kept; 265/70-16; empty dates first. The Repair Order path: no change.
2. **Second (of those fixes):** sound; fixed after it: quotes inside COSTAR's words in the stop message; a COSTAR busy while the number is first looked for; an Order window still being made (hidden) counts as open.
3. **Third (of the stock read and the map fix):** blocker fixed: nothing checked that opening the lines left the order unchanged before WM_CLOSE saved it → the order's fingerprint before any click, the number box clicked to leave the last line, the order read again, and left open if anything differs. Also fixed: the box clicked could be editable (the item box as a fallback) → the read-only words box only; a click while COSTAR is busy or the lines are moving → COSTAR answering, nothing over the order, the box still for 150 ms, the line still not open; a box given the keyboard directly (COSTAR's lines follow the mouse: the Repair Order notes) → a click only; the map could still keep the words when the controls' words weren't read → accessibility applies the rule by itself; an overflow on a huge number; a click on a line already open; a single read taken; "Memo" in any title; tall labels; NON-STOCKING! without "= Avail"; one line stopping the run; Stop not looked at right before the click. Its rule question went to Tommy: the order's own tyres are in COSTAR's Commit, so they're added back (15:54).
4. **Fourth (of those fixes):** no blockers; fixed after it: the last line could stay the open one through WM_CLOSE (WinForms validates the active box as the window closes) → the keyboard must stay on the order's number box for 300 ms (3 clicks at most, as the Repair Order code leaves its lines), else the order is left open; a stop after a click didn't say the lines had been clicked (the "couldn't be closed" words, the run's stop words, the tab) → it does; the number box could be a button → an EDIT showing the order's number, checked again right before the click; a new COSTAR window noticed only at the end → before every click; a panel already showing taken from one read → two reads alike; the "clicked" mark set only after the click → before it; the map hid a button with a hidden label's words (the Cashier's Cash) → only windows, labels and boxes; a message box label accessibility can't place, and other message boxes' words → every message box's labels are a length; a word like Item or Net inside an opened line's panel taken for a heading → the headings' own panel only. Noted, not code: what the compare can't see (header boxes other than the number, Comment and Terms; tick boxes; anything COSTAR doesn't show) → TEST-PLAN 3 asks for one order's History to be looked at after the first run.
5. **Fifth (the last look, of those fixes):** no blockers; every path that clicks a line ends with the order read again and found unchanged, or left open. Fixed after it: the Customer row stopped at COSTAR's first caption, so a contact's name or an account code after it was kept → every label on the row is hidden but COSTAR's captions and the terms' words (the label just after Terms); only windows, labels and boxes were masked, so a list or another control MSAA names after the customer's label kept the name → every object but COSTAR's own buttons, ticks, tabs, menus and headings; a label over 40 that accessibility can't place was kept outside message boxes → masked; a new COSTAR window before any click said the order "changed" → it says nothing was clicked (and the order is unchanged); the clicked words appended twice → once, the original error kept inside; the keyboard checked only before the last read → again right before the close (back in the lines: left open); the keyboard had to land on the number box itself → anywhere in the order outside its lines, and the failure says where it is (lines, another window, nowhere: never words); the last look before a click now also wants the order enabled with nothing over it; an order that opened as a failed open stopped shows on the tab. Left as risk (can't be seen from outside COSTAR): a box that defers its checks to the close; COSTAR's own close saving more than it shows → TEST-PLAN 3 (reopen orders, History) and the day log's `wholesale_lines_left`.

## Checks performed here

- Compiled at C# 5 against the five reference sets: 0 errors, the usual 3 warnings.
- Self-tests: 152 + the 4 that need Windows = 156; Order Check 16/16. New: 8 wholesale groups (which orders are opened; Terms, card details, tyres, the stock rule with this order's own tyres added back and what it would do; the list read; the Order window read; the stock panel (ThisBr, NON-STOCKING, numbers, a stray heading word, no number box); the order's fingerprint and what changed; the Notes window's card details; the left-hand menu, the list kinds and the selected tab) and a map group (the Cashier's Customer row up to Terms, a name in two labels, a message box's words placed or not, the words over 40, accessibility by itself and with the controls' words, only windows, labels and boxes repeating a label).
- Mutations: 97 of 97 deliberate bugs in the new code caught by the self-tests (the screening, Terms, card details, expiries, tyres, the stock rule and its add-back, the verdict's order, the list read, the Order window read, the stock panel, the fingerprint and the compare, the read-only line box, the heading row, the number box, the map's rules in both parts).
- Checked on the 3 Nov maps (lengths only printed, never words): the stock reader finds line 1's panel, NON-STOCKING and the ThisBr "= Avail" box; the line's words box and the order's number box are read-only (ES_READONLY); the headings share the lines' panel; the map rule hides the Cashier's name label and catches its accessibility echoes (the label, its window, and the box MSAA names after it).
- Install replay with the Updater the PCs run (2.6.0's code) over 2.8.1, 2.8.0, 2.7.0 and 2.6.12: PASS (92 files). Scans of everything that leaves (the upload set and the release ZIP): no tokens, keys, pairing or connection files; report numbers: the same 18 historical hits as 2.8.1 (the 3 Nov diagnostics' numbers added to the list); only made-up phones, emails, eBay and wholesale order numbers. Package checks (scripts, launchers, self-test inclusion), the startup page checks and Order Check's C# 5 scan pass.

## Not verified here (no Windows or COSTAR here)

- The dry run on COSTAR Sydney: the left-hand menu's press, the list read, orders opened, the customer's Notes and memos answered, an order's lines read, a tyre line clicked open and its stock panel read, the order read again and closed, Repair Order at the end; Stop and someone at the PC part way; the map of the Cashier window and of a memo (TEST-PLAN 2.9.0).

---

# Validation — v2.8.1 — 3 November 2026

## Basis

- **The ask.** 2 Nov (planned with 2.8.0): online orders should come in by themselves, without the Online orders tab and the clipboard. 2 Nov 22:55, Tommy: "are you automating all or just the one for tempe?"; 3 Nov 09:01: "alright now, Tempe pickups only."; 09:31: "tempe tyres is open 7 days btw"; 11:02: "Monday to Friday : 08:00 - 17:00, Saturday : 08:00 - 16:00, Sunday : 09:00 - 14:00".
- How it worked: the Tempe Orders page (`testrun.html` on GitHub, in Chrome on the RDP PC, reading the website through the "Tom does it all" extension) lists today's / tomorrow's pickups for a store, checks them against COSTAR through Order Check (`127.0.0.1:8795`), and sends one with **Send to COSTAR** or **Make it** through the clipboard to the helper's Online orders tab (Fill automatically needs that tab showing, and pauses mobile meanwhile).
- 2.8.1 is 2.8.0 (3b5366a) plus this; the page is the live `testrun.html` (the same bytes as 2.8.0's `OnlineOrders/Tempe-Orders-COSTAR.html`) plus this.

## Changes

- **The page (`OnlineOrders/Tempe-Orders-COSTAR.html`, uploaded as `testrun.html`):** an **Auto** switch (remembered in Chrome). A round every 3 minutes (also when switched on, and 5 s after loading when paired), only with the helper it was paired with (`TempeAuto.pairedHelper`: the Order Check whose `/health` names the pairing): outside shop hours (`TempeAuto.inShopHours`: Mon-Fri 7:00-18:30, Sat 7:00-17:30, Sun 8:00-15:30, Sydney) or with Auto off it only checks in (saying whether Auto is on); in shop hours it asks that Order Check for a read (`POST /refresh`) and waits up to a minute for a new one (`freshWip`; none: the round sends nothing and says it waits for the next read; Order Check stopped or 15 minutes without a read: an error), stops if COSTAR's list is filtered, reads the website's order list, takes the Tempe pickups for today and tomorrow (`TempeAuto.autoDays`; `autoCandidates`, not a delivery method naming a delivery), checks each against the read and the helper's entered list (`TempeAuto.costarMatch`: in / maybe / missing; rows sent from this page by hand stay with the Online orders tab), asks the helper what it knows of the missing ones (`POST /online/status`, which is also the page's heartbeat and carries its error, its Auto switch and the held-back "maybe" orders), and sends the ones the helper doesn't know (at most 8 a round): details from the website without stock (`fetchOrderData(order, false)`, split out of `loadOrderDetails`), `TempeCostar.makeOrder`, schema 1 only, the website's delivery method added, `POST /online/order` with `Authorization: Bearer <key>`. A 401 forgets the pairing and turns Auto off. The list shows the helper's record of each (`TempeAuto.helperView`; Make it for a stopped or held one); Make it and Make all missing skip what the helper has (`helperHasIt`); Send to COSTAR marks the row sent. Pairing: **Auto** without a pairing (or with its helper gone) asks for the 6-digit code and tries the helpers showing one (`POST /online/pair`), keeping the key and the pairing's id.
- **`OnlineOrders/auto-core.js` (new, inlined in the page as `transfer-core.js` is):** the pure rules (`sydneyParts`, `inShopHours`, `addDays`, `autoDays`, `autoCandidates`, `costarMatch` (moved from the page; the helper's `MatchIn` is the same), `autoPlan`, `helperView`, `helperHasIt`, `pairedHelper`, `pairingHelpers`, `readPairing`).
- **`Source/OnlineAuto.cs` (new):** `OnlineInbox`: `Refusal` (Tempe pickups only: not a delivery or a delivery method naming one, schema 1 with a Tempe store named, no package), `Hold` (a Tempe COSTAR selected, not Order Check's), `Offer` (in line once; a known one keeps its record), `Step` (the next order to start, or why not: the Online orders tab free, not sent by hand or entered before, a Tempe COSTAR selected, no other entry, that COSTAR ready, a read begun after the order came and the last entry ended, then in COSTAR → `in_costar`, a job with the same amount → `held`; an `AutoWait` with Soon for passing reasons), `Expire` (25 minutes, every tick), `Next`, `Started`, `Back` (couldn't start: back in 30 s, the try not counted), `Known`, `TakenByHand`, `Finished` (entered / in_costar / stopped; a stop that typed nothing and is `Unattended.Retryable` is tried once more a minute later; any other, or a second, pauses the page's orders), `Resume`, `Status`, `HeldUntold` / `MarkTold`, the key (hash only) and the pairing's id. Records kept 4 days in `online-auto.dat` (DPAPI; a failed save is tried again, never thrown); orders in memory only; after a restart one still waiting is dropped (the page sends it again) and one being entered becomes stopped and pauses. `OnlinePage.Handle`: POST only; `/online/pair` (`EbayPairing`: 10 minutes, 5 tries, once; answers the key and the pairing's id), `/online/status` (Bearer key; records the contact, the page's error masked by `Sanitize.Text` and since when, its Auto switch, up to 50 held-back orders), `/online/order` (Bearer key; 409 when switched off; `Order.Validate(true)`; `Offer`).
- **`Source/OrderCheck.cs`:** `Hosting.Online`; `Route` passes `/online/*` (after the existing Host and Origin checks, and only from `https://tommyvenzin.github.io`) to it; the preflight allows `Authorization`; reason phrases for 400/401/409/503. `Hosting.Refresh` (a read now), `Hosting.AutoPair` / `AutoPairing` (in `/health`); `Store` keeps `readFrom` (when a read began, after the hold check) and `searched` (Search pressed for it), and each job's online order numbers (`Text.TtwIds`, in `state.json`), serving those no longer listed as `left`. Order Check self-test: no helper → 404; the helper answers with its own code; another site, `null`, an extension or no Origin → 403; the preflight allows the key; `/health` names the pairing; a read says when it began.
- **`Source/MobileRunner.cs`:** `OrderCheckLink.FreshIn` (a read that began after a time, with Search pressed, within 10 minutes, a PO# column, not filtered; its kind: soon, old, stuck or fix) and `MatchIn` (the page's rules, the jobs that left Work-in-Progress, and for the same amount the same customer or a walk-in). `CostarSession.cs`: `EntryCoordinator.LastReleasedUtc`. `Diagnostics.cs`: `EnteredOrders` (30 days, a past day read once, under the log's lock: `AppLog.DayLines`), `When`.
- **`Source/OnlineTab.cs`:** `AutoTick` (from the main window every second; `Expire` and `Flush` each time, `Step` every 3 s with this tab's state (`LocalWait`), the orders sent by hand this session, the entered ones, the coordinator, `AutoCostar` (the old helper closed, COSTAR on Work-in-Progress and still the one picked, 3 s quiet) and Order Check's latest read; never throws) → `ShowOrder`, `Started`, `StartEntry`. `StartEntry` for a page order: never "start when free", a fresh Repair Order, the default options. The entry thread notes `typed` (writes or a verified resume) and `inCostar` (Order Check listed it); the completion tells the inbox (`Finished`, guarded) and says a retry or the pause; Discord hears a stop unless it's retried, already in COSTAR, a Stop pressed, or a pause (the page watch says that one); a synchronous refusal puts it back (`Back`). Loading or queueing an order by hand marks it (`sentByHand`, `TakenByHand`). A line under the order (paired or not, last check-in, waiting and why, paused) and **Resume orders from the page**. `HasWork` counts the page's orders (no update meanwhile). Version 2.8.1 - Tempe pickups by themselves.
- **`Source/RunsByItself.cs`, `Source/DesktopUi.cs`:** the inbox at start (`online-auto.dat`); `OnlinePage` wired; Order Check's server given `OnlinePage.Handle`, the pairing's id and whether a code shows; the Online form made at start (`EnsureOnline`) so the page's orders go in whichever tab shows; `AutoTick` every second; the tick "Enter the Tempe pickups the Tempe Orders page sends by itself" (`AppSettings.onlineAuto`, on) and **Pair the Tempe Orders page...** (needs Order Check on; a MessageBox with the code); no-COSTAR alert counts the page's waiting orders; `WatchPagePause` (any hour: the pause, tried until Discord takes it, every hour in shop hours while it lasts) and `WatchOrdersPage` (shop hours, once paired): the page quiet 15 minutes (20 after start), its trouble for 15 minutes, its Auto off, orders waiting 10 minutes for something a person must sort out (again each hour or when the reason changes), the orders held back (the page's and the helper's) in one message; each said only once Discord took it.
- **Open 7 days, Tommy's hours (3 Nov 09:31: "tempe tyres is open 7 days"; 11:02: "Monday to Friday : 08:00 - 17:00, Saturday : 08:00 - 16:00, Sunday : 09:00 - 14:00"):** shop hours (`Text.InShopHours`: Order Check's reading, the self-update's "not in shop hours", the helper's Discord alerts and the page watch; `TempeAuto.inShopHours` for Auto; `Website/discord.js` for the board's problem posts) run from an hour before opening to an hour and a half after closing, as 7:00-18:30 did around the weekday hours: Mon-Fri 7:00-18:30 (as before), Sat 7:00-17:30, Sun 8:00-15:30 (Sunday was closed). The watch's "first 5 minutes of the day" follow each day's start. Customer Waiting's "next shop day" is tomorrow, also when it's a Sunday (`Order.NextShopDay`; was Monday after a Saturday). Texts say the hours. Tests: Order Check's hours (each day's first and last minute), the update (Sunday 11:00 not due, Sunday 21:00 due), Customer Waiting on a Saturday (Sunday 08:30 ticked), the page's hours, `Tests/OrderCheck/test-discord.cjs` (Sunday 7:59 / 10:00 / 15:31, Saturday 17:30 / 17:31, Tuesday 18:30). `Website/discord.js`'s header example now uses made-up names and numbers.
- `Build.ps1` lists `OnlineAuto.cs`; `VERSION.txt` 2.8.1; `Tests/test-orders-page.cjs` (new).

## Review

First independent review (of the code as it stood at 09:34, open 7 days included):

1. **Blocker, fixed: an order typed twice when a send by hand overlapped Auto.** Make it at 10:00:10 started TTW1 on the Online orders tab; the round that had read COSTAR at 10:00:08 sent TTW1 too; when the manual entry ended, the inbox started TTW1 again, checked against the 10:00:08 read (under 10 minutes old, so "fresh"). Now: (a) `OnlineInbox.Step` checks the order only against a read of COSTAR that **began** after the order arrived and after the last entry ended (`Store` records `readFrom`, taken after Order Check's hold check; `EntryCoordinator.LastReleasedUtc`), and asks Order Check for that read (`Hosting.Refresh`, every 20 s at most); (b) an order loaded or queued by hand this session (`sentByHand`, whatever came of it), entered in this session (`queue.WasEntered`) or in the day log (`EnteredOrders.When`) is never entered by itself (`by_hand` / `in_costar`); (c) the clipboard path marks an order the inbox holds `by_hand` (`TakenByHand`); (d) the page leaves rows it sent by hand ("sent") to the Online orders tab, and Make it / Make all missing skip what the helper has; (e) `startWhenFree` is never set for the page's orders (one that finds COSTAR taken goes back in line) and clears when an entry starts or an order is loaded.
2. **High, fixed: the helper's last check was PO# only, and the page could decide on a read up to 5 minutes old.** `OrderCheckLink.MatchIn` applies the page's rules on the helper's own fresh read: its number as a job's PO# or in a comment → `in_costar`; a job with the same amount (2% or $1) that isn't another online order → `held` for a person (no pause; Discord once). The page sends nothing without a read made during its round (it says it waits for Order Check's next read).
3. **High, fixed: Auto started where the other unattended work waits.** Before an order starts: no other entry, the old online-order helper closed, the selected COSTAR still the one picked and on Work-in-Progress (`CostarWindows.WhyNotOnWip`), nobody using the PC for 3 s (as the eBay orders). The page's orders always get a fresh Repair Order (an open one, maybe a person's, is never reused) and the default options (no payment typed for an earlier order, the fitting note, DET first as set).
4. **High, fixed: Auto could stop without telling anyone.** Every reason the Online orders tab holds the page's orders now says so (an order loaded by hand, its copied orders' line or its pause, a branch question); `AutoWait.Soon` tells passing reasons (an entry under way, someone at the PC, Order Check's next read) from ones a person must sort out, and Discord hears of the latter after 10 minutes (again each hour, or when the reason changes; not "no COSTAR", which has its own alert). A pause is said at any hour, tried again until Discord takes it, and repeated every hour in shop hours; the page reports its Auto switch, and "Auto is off" goes to Discord once; after a restart an order that was being entered pauses the page's orders.
5. **Medium, fixed: false alarms.** The page accepts any new read (not only state "ok"); with none in a minute (Order Check waits while the helper types) it skips the round quietly; Order Check stopped (its COSTAR closed, paused) or a read over 15 minutes old is an error. The page's errors reach Discord after 15 minutes of them. Jobs with another TTW as their PO# don't count as "same amount". Orders held back go in one message.
6. **Medium, fixed: who can reach `/online/*`.** Only `Origin: https://tommyvenzin.github.io` (not `null`, file pages, other extensions, or no Origin). Pairing gives the page a pairing id as well as its key; Order Check's `/health` shows the id (`autoPair`) and whether a code is showing (`autoPairing`), so the page talks only to its own helper (other Windows sessions' helpers on the RDP server get neither its key nor its orders) and pairs only with one showing a code. Not done: signing requests instead of sending the key (loopback only; another process able to listen there could do more already).
7. **Low, fixed:** a failed save of `online-auto.dat` no longer throws (memory counts; saved again every 30 s); `AutoTick` and the inbox calls in the completion can't throw out of the timer or callback; a failed start clears the loaded order.
8. **Low, fixed: "pickups only".** The page sends the website's delivery method with each order; the helper (and the page's pick) refuse one that names a delivery (Australia, deliver, partner, freight, courier, postage, shipping, eBay) and a pickup that names no store.
9. **Low, fixed:** orders still waiting are let go after 25 minutes every tick, also while paused or switched off.

Checked and correct (the review): store and branch rules on both sides; the inbox (idempotent per order, records kept encrypted 4 days, no retyping after a restart); retries (once, untyped and retryable only); outcomes and alerts; one entry at a time across mobile, eBay, Repair Orders, the map and updates; the HTTP side (Host and Origin, preflight, 64 KB, 400 on bad JSON, 256-bit key kept as a hash and compared in constant time, nothing logged); threads and C# 5; the page's escaping, timeouts and one round at a time.

Second independent review (of the fixes above; 143 + 4 Windows-only self-tests, Order Check 16/16 and the page's checks re-run there):

1. **High, fixed: an order whose Repair Order has left Work-in-Progress was entered again.** A pickup entered on Friday (by hand or with Send to COSTAR), fitted and invoiced this morning was no longer in the list, nor in the helper's two days of log, so Auto entered it again (a deleted, cancelled one too). Order Check now remembers the online order numbers each job carried (its PO#, a TTW number or seven digits in its comment: `Text.TtwIds`, kept in `state.json` with the job for its 30 days) and serves the jobs no longer listed as `left`; the page's `costarMatch` and the helper's `MatchIn` count one there as in COSTAR ("no longer in Work-in-Progress: invoiced or deleted"). The helper's own log is looked through for 30 days (`EnteredOrders.When`, a past day read once). Only for jobs Order Check has seen since the update (TEST-PLAN 6a).
2. **High, fixed: an order loaded by hand that won't be filled held the page's orders for good, and the alert said to Fill it** (one already entered, refused at the branch question, or too old to fill). The Online orders tab has a **Clear** button; an order loaded there that was already entered, or loaded over 30 minutes ago, is put away by itself for the page's orders; the wait says "fill it, or click Clear".
3. **Medium, fixed: the overlap with a send by hand was closed only once the Online orders tab had read the clipboard** (with Runs by itself the Mobile jobs tab shows), and the page's "sent" marks were lost on a reload, a day switch or a failed check, or missed during a round. Send to COSTAR and Make it now tell the paired helper (`POST /online/hand`: `TakenByHand`, and `Offer` keeps a later copy as by hand) and keep the mark in the tab for a day (sessionStorage); a round looks at the marks again before each send.
4. **Medium, fixed: a "fresh" read may be an old search.** Order Check says whether Search was pressed for a read (`searched`); the helper and the page refuse a read without it ("tick Press Search before each read").
5. **Medium, fixed: the same-amount hold would catch about half of all orders** (46% of amounts on the test fixture). The helper holds an order only for a job with the same amount whose customer shares a word of the name with it, or a walk-in's (no name, WALK, CASH, COUNTER, ONLINE, INTERNET, CUSTOMER); the page, whose list has no names, sends a "maybe" to the helper to decide.
6. **Medium, fixed: orders Auto couldn't make were skipped quietly every round.** They go to the helper in the page's status (`skipped`: no COSTAR code, a discount, a package, another store, the helper's refusal; not the website's own trouble) and to Discord once, in one message.
7. **Medium, fixed: a page order entered with CHECK BY HAND was silent.** The inbox records an entered order left open (`open`), Discord hears of those in one message (phone jobs wait while one is open), and the page shows the helper's words.
8. **Medium-Low, fixed: Stop all and Ctrl+Alt+F10 didn't stop Auto.** They pause the page's orders until Resume (`OnlineInbox.Pause`).
9. **Low, fixed:** the page forgets the helper's record of an order the helper no longer has (so Make it isn't refused for it); a "maybe" row and a by-hand one offer Make it (by hand isn't "with the helper"); the day log is read under its lock (`AppLog.DayLines`); an old read is asked for too (not only a due one), and Order Check's own words are said whenever it isn't reading normally; the order from the page is marked before it is shown (a failure there can't leave it looking loaded by hand); and only one helper on the RDP server takes the page's orders (`AutoRole`, a machine-wide mutex held by the window's thread while Auto takes them).

Checked and correct (the second review): `readFrom` taken after the hold and rounded down; the wait for a read begun after both the arrival and the last entry; the asks every 20 s at most; ByHand, EnteredBefore, TakenByHand and "start when free"; `MatchIn` equal to the page's rule; `AutoCostar`, the fresh Repair Order and the default options; every way through `Step` saying why, each "soon" one with a limit; the pause alerts; the restart; the origin check, preflight, pairing id and 401; the delivery words, an empty store refused, `Expire` every tick, failed saves; locks (one re-entrant lock for the inbox, OnlinePage's fields locked, no lock-order inversions); the timer and completion guarded; C# 5; the page's inline copy.

Third independent review (of the second round's fixes, with Tommy's hours; 143 + 4 Windows-only, Order Check 16/16 and the page's 12 re-run there): nothing blocking — no remaining way to type an order twice, type an invoiced or deleted one again, or type into the wrong COSTAR or Repair Order. Fixed from its list:

1. **Medium: an order sent by hand and never filled was left out for a day.** A mark from the page (Send to COSTAR, Make it) now only holds the order 10 minutes for the Online orders tab (`OnlineInbox.MarkFromPage`, `Next`; the page's own mark lasts as long); once the tab loads or queues it, it is a person's (`by_hand`); if nobody did, Auto enters it after all, checked against COSTAR as any other. An order put away unfilled (Clear, too old) is released to Auto (`Released`).
2. **Low-Medium: the page's side could stall without an alert.** A round that only waited for Order Check's read sends no error (the page's trouble keeps its time); five such rounds in a row (a quarter of an hour) are an error; an order whose website details can't be read three rounds running goes to the "couldn't send" list (Discord).
3. **Low:** `Started` says whether it started (an order sent by hand between `Next` and `Started` isn't started); a failure showing it stops that order for a person instead of blocking the line.
4. **Low:** a job's remembered order numbers are replaced on every read while it is listed (a corrected number replaces the old one), and seven digits in a comment are remembered only where the comment speaks of an order (ONLINE, ORDER, WEB, INTERNET, PAID, PICK UP, COLLECT, TTW, #) and they don't end a number written in groups (a phone number) — `WEB1730962` included.
5. **Low (personal data):** as 4: phone numbers, licence numbers and other seven-digit numbers aren't kept in `state.json`.
6. **Low:** an unreadable `online-auto.dat` starts the page's orders paused, saying so (Discord), instead of quietly unpaired.
7. **Low:** the RDP server's one helper for the page's orders lets go after 15 minutes without the page checking in (nothing waiting), and the wait says to untick it in the other helper.
8. **Low:** two tabs of the page share the Auto switch (the browser's storage event), so Discord doesn't hear "Auto is off" over and over.
9. **Low:** closing the helper during an entry no longer saves a "Stop all was pressed" pause (the order being entered pauses by itself, with its own words).
10. **Low:** reads asked for by the page or the helper don't override a person's Pause in Order Check (`Poller.RequestRead(false)`).
11. **Low:** the words when Search wasn't pressed quote Order Check; two-letter surnames (LI, NG) count in the same-customer rule, titles (MR, MS, DR...) don't; an unexpected error claiming the machine-wide lock is noted once.
12. **Open (Tommy):** whether cancelled orders stay in the website's order list for today and tomorrow (Auto would enter them); asked.


## Checks performed here

- Compiled at C# 5 against the five reference sets: 0 errors, the usual 3 warnings.
- Self-tests: 143 + the 4 that need Windows = 147; Order Check 16/16 (its server-routes group now carries `/online/`, the GitHub-only origin, `/health`'s pairing, `readFrom` and `searched`, the jobs' order numbers kept and served as `left`, a corrected number, Pause respected; its hours group each day's hours). New helper group: the page's orders (Tempe pickups only, once, the next, a retry of a stop that typed nothing a minute later, a second stop pausing, kept across a restart, a stop after typing not retried, entered, after a restart one entering becomes stopped and pauses, 25-minute expiry also while paused, back without counting, by hand (from the tab, from the page: 10 minutes, then Auto), released, started once, held and left open told once, Stop all's pause, a failed save, status, the key and the pairing's id), Order Check's freshness (begun after, soon / old / stuck / fix, Search pressed), the match (PO#, comment, a job that left Work-in-Progress, same amount for the same customer or a walk-in, not another customer's or another TTW, two-letter names, titles), the step in a made-up world (each reason in turn, a read asked for, in COSTAR, held, entered before, by hand), and the HTTP side (unpaired 401, no code 403, pairing once with its id, status with the page's trouble, its Auto switch and the orders it couldn't send, /online/hand, an order taken once, another store or delivery wording 400, a wrong key 401, not JSON 400, switched off 409, POST only).
- Mutations: 79 of 79 deliberate bugs in the new C# caught by the self-tests (the page's hand marks waiting 10 minutes and not for ever, put away unfilled released, started once, the page's trouble kept through a round that only waited, two-letter names and titles, a corrected number replacing the old one, order words and grouped phone numbers, Pause respected; Tempe pickups only: a delivery, another store, a package, delivery wording, no store; once only; the retry rules and the pause; a restart; expiry; the key; pairing and its id; the step: this tab, sent by hand, entered before, another entry, COSTAR not ready, a read begun before the order or before the last entry, the read asked for too often or not when old, in COSTAR, held; by hand from the page (remembered, a later copy kept as by hand), its order number only; a failed save; Stop all's pause; entered but left open; the page's error time, Auto switch and orders it couldn't send; Order Check's freshness, its stopped state, filter, PO# column and Search pressed; the match: comment, amount, another TTW, a number inside a longer one, a job that left Work-in-Progress, another customer's job, a walk-in; Order Check's routes, the GitHub-only origin, the preflight, `/health`'s pairing, `readFrom`, `searched`, the jobs' order numbers (from a comment, kept across a restart, only for jobs no longer listed); the hours: Sunday closed again, Saturday as a weekday, Sunday opening early or closing late, the hour before and the hour and a half after; Monday after Saturday).
- The page: 12 checks (inline copies equal their files, every inline script compiles, Auto's elements and addresses, Sydney time, the shop hours of each day, the days: today and tomorrow, Saturday → Sunday, month and year ends, Tempe pickups only (not delivery wording), the COSTAR check (PO#, comment, the helper's list, same amount, not another TTW, a job that left Work-in-Progress), the plan (a same-amount one goes to the helper, sent by hand left alone), the helper's record (held, by hand, left open, Make it), Make it never for what the helper has, the paired helper among several and the kept pairing); 33 of 33 mutations of its rules caught, and 4 of 4 of the board's hours (`discord.js`).
- End to end (Chromium; the page as `https://tommyvenzin.github.io/tempe/testrun.html`; a stand-in extension with made-up website pages; the REAL Order Check server and the helper's page side and step from a harness build, an order it starts 'entered' at once): 24 checks: pairing with the code typed with a space, the key, the pairing's id and Auto kept, `/health` naming the pairing (the code used up), one round sending exactly the four Tempe pickups for today and tomorrow not in COSTAR (not the one in COSTAR, the one whose job was invoiced since, the other store's, the delivery, the later day's), each with the website's delivery method, the helper holding the walk-in's same-amount one and entering the rest (another customer's same-amount one too), one at a time each on a read begun after the one before ended, the key in a header, details read only for those sent, no stock look-ups, the list showing the helper's record and the invoiced one as in COSTAR, Make it refusing an order the helper has, a second round sending nothing and naming the held one with its job, Auto off remembered, sending nothing and told to the helper, a wrong key refused (401) with Auto off and the pairing forgotten, no script errors. It also showed Chrome's Local Network Access permission is needed for the page to reach `127.0.0.1` (granted in the test; on the RDP PC already allowed for the COSTAR check, or asked once).
- Node: Repair Orders page 11, Job Card 59, startup 9, package check, Tempe Orders page 12, Order Check (C# 5 scan, Discord 8 with each day's hours, order rules 12, Firebase, GitHub share). Repair Orders end to end: 111.
- Install replay with the Updater the PCs run (2.6.0's code) over 2.8.0, 2.7.0 (the background test build), 2.6.12 and 2.6.2: PASS (89 files). Scans of everything that leaves (the upload set and the release ZIP): no tokens, keys, pairing or connection files; report numbers: the same 18 historical hits as 2.8.0; only made-up phones, emails and eBay numbers; `website/testrun.html` and `website/discord.js` equal the release's copies. The live `testrun.html` and `discord.js` on GitHub were 2.8.0's bytes (nothing of Tommy's is replaced).

## Not verified here (no Windows, COSTAR or the real website here)

- An order from the page going into COSTAR by itself on the RDP PC (the Online form made at start, AutoTick, the existing entry path); Discord messages; the pairing MessageBox; Chrome keeping the page awake in its own window; the real website's pages through the extension (the parsers are unchanged; only the stock look-up is skipped for Auto) (TEST-PLAN 2.8.1).

---

# Validation — v2.8.0 — 2 November 2026

## Basis

- **The ask.** Tommy, 2 Nov 20:37: "Is it automatic? yes, mostly, but I want it to be working by itself instead of doing things manually ... I just want it to be atleast 60-80% automatic. What do you think we should make next?" Proposed: 1. unattended running (start with Windows, mobile back on by itself, online orders without the tab, updates outside shop hours, one retry, Discord when a person is needed, Import connection); 2. review only what needs a look; 3. online orders on their own; 4. wholesale; 5. eBay; 6. a helper login of its own.
- 20:47: "1. Good idea, we can start releasing it but remember: Please put SHOP on online orders but dont tick customer waiting unless if it is for 14:00 - 16:00"; "2. please elaborate further, give me examples"; "3. yes"; "4. not yet, havent got the deal yet, but make it ready on the back end"; "5. ... make it able to store everything at once so when it's idle it can process all the ebay orders"; "6. not yet".
- 20:58: "1. 16:00 count, and make the 08:00 - 09:00 am for tomorrow aswell"; "2. we will make a new one" (a new Discord channel for the alerts); "3. yes" (review by exception in 2.8.x, with a switch).
- 22:00: "Every pick up that is collect in store get shop, if it has delivery address it is DFE".
- The same afternoon: Setup-Desk.cmd was run again on the desk PC, so the RDP helper refused the desk ("Could not establish trust relationship"), and the new connection file had to go into the one folder the helper reads it from (Fix-Desk-Connection.cmd).
- 2.8.0 is 2.6.12 (b7597ed, the same code as 2.6.11) plus these. 2.8.0, not 2.7.x: the RDP PC has the 2.7.0 background test build. Online orders arriving by themselves (3), wholesale (4) and eBay's send-all (5) come after this.

## Changes

- **Online deliveries** (`OrderModel.cs` `Order.ForEntry`, called from `OnlineTab.ShowOrder` for every order loaded): Ship Via `DeliveryShipVia` = DFE whatever the Tempe Orders page read from the website, and (2.6.11's rule, moved here) Shipping Instructions empty; typed into the delivery panel and checked at the end as before.
- **Online pickups** (`Runner.Online.cs`, `OrderModel.cs`): `SetShipViaShop(true)` (every customer, every store; not done, or COSTAR not keeping it, is a CHECK BY HAND item, never a stop). After the final check, Customer Waiting (`OrderWindowBack` + `TickCustomerWaiting`, as phone jobs) only when `Order.WaitingSlot(pickupDate, pickupTime, today)`: today 14:00-16:00 or `NextShopDay` (Sunday skipped) 08:00-09:00, both ends included; not ticked is a CHECK BY HAND item; deliveries unchanged. `SetTimeIn`: the box not found, or the booking time not kept, is a CHECK BY HAND item too (eBay orders never reach it: no booking time), and so is Time in differing from the booking time at the final check.
- **Online orders closed when clean:** `runner.CloseWhenEntered=AppSettings.onlineCloseClean` (default on) and, after the final check and Customer Waiting, `CloseEntered(total)` (eBay's: nothing if any CHECK BY HAND item; out of the grid, PO# and total re-checked, and now the Customer Waiting box this order ticked read again (`waitingBox`; COSTAR takes a tick in when the box is left), WM_CLOSE, nothing answered; a check stays open) unless the order needs manual completion. The tab says "in COSTAR and closed" and no longer holds the window.
- **`Unattended.cs` (new):** the rules (pure): `NotEntered` (the phone's NOT_ENTERED words), `Retryable` (those, but not words beginning "Stopped": a person's Stop all, the helper closing, a stop needing an update), `RetryDue` (once, 60 s after, within 30 min), `UpdateDue` (outside shop hours, not busy, nobody for 10 min, hourly, a version restarted into by itself once: `triedBefore`), `WhyNotResume` (wanted, was on, no stopped job, the Online tab not showing, the selected COSTAR's branch is the one mobile was last started in; unknown branch: no). `AutoStart`: the Startup-folder .cmd, plain ASCII: the helper's own folder's Launch.ps1 when the folder is `Plain` (it hands over to a newer installed version itself), else, or when that folder has gone, `packages\current.txt`'s found at run time; a failed start pauses so it can be read; rewritten at each start. `Alerts`: the webhook (`Normal`), encrypted in alerts.dat, `Allowed` (15 min per kind, 12 per hour), `Raise` (background, never throws; says whether it went), `JobStopped` / `JobStarted` / `Tick` (a retryable stop is said only if not started again in 3 min), `Compose` (title kept, detail masked by `Sanitize.Text`, no mentions), `Test` (run off the window's thread).
- **`RunsByItself.cs` (new), RDP helper:** the Runs by itself card (four ticks, Discord buttons, Import connection); `ResumeMobile` 20 s after start and then every 30 s until mobile is on or isn't to come back (said only when the reason changes); `RememberMobile` on a person's Start, and on Stop all from its button or Ctrl+Alt+F10 only (not when the helper closes or Windows shuts down); a quiet look for COSTAR every minute while none is selected (`RefreshTargets(true)`: said and logged only when what it finds changes); the alert watch every 30 s in shop hours (desk 5 min; no COSTAR open and selected 5 min, a selected COSTAR whose program has closed counting as none (`CostarAlive`); mobile not back 10 min after it could have been (not for the Online tab or no COSTAR); not before 7:05; eBay orders need no selected COSTAR; each "said" only once Discord took it); the automatic update when due (busy includes `online.HasWork`, a phone job stopped part way (`CanRelease`) and a retryable stop of the last 3 minutes (`Alerts.Waiting`)); an hourly check after hours; after an automatic update, "updated itself to ... and is running" (`update_done`). The quiet COSTAR look takes only the branch used last or mobile's. Stop all is enabled while mobile waits to come back. A phone job stopped with mobile switched off or the helper closing isn't sent to Discord (`Worker.cs`).
- **The RDP helper's update** (`WorkerForm.InstallUpdate`): COSTAR is held for it (`coordinator.TryBeginRead("Updating the helper")`, `updateLease`) from the download to the restart, so no entry starts meanwhile, and closing for the restart (FormClosing) doesn't stop anything; every failure releases it (`EndUpdate`). Automatic: `autoUpdateTried` saved just before the restart (a failed download is tried again the next hour); Discord hears once per version that it's updating, or that it failed.
- **Desk PC** (`RunsByItself.cs`, `DesktopUi.cs`): Start with Windows and updates ticks; `RetryOnce` through `JobQueue.AutoRetry` / `EbayQueue.AutoRetry`, only while the RDP helper is in touch and taking that work: the stop time (`Receipt.stoppedUtc`, stamped when a job becomes failed; an eBay order's `updatedUtc`) and the retry (`autoRetried`) are in the queue files, so a restart neither repeats nor loses it; an eBay order that typed something is never retried. A tray balloon when the RDP helper is out of touch 5 min. The automatic update: `deskAutoUpdateTried` (saved just before the restart), no message boxes (the yellow line and the day log say what happened), and the restart waits until no phone job or eBay order is being entered (`DeskEntering`, with the RDP helper in touch), outside shop hours, with nobody at the PC (`installedUpdate`, each 10 s); the yellow line says it is installed and a click restarts at once.
- **`Launch.ps1`:** sets `TEMPE_PACKAGE`; an update that fails to build or pass its self-tests is set aside as before and now the version before it is started again (`-NoHandOver`).
- **Connection:** `NetworkRules.Unreachable` (TrustFailure → "the desk PC's certificate isn't the one this helper was given ... Import connection"); engines' `Reconnect`; `ImportConnection` (picked file → `NetworkRules.Worker` → settings.dat → the shared settings updated in place → reconnect; older copies in the bin folder and the package folder removed; the picked file deleted if asked).
- **Alerts wired:** phone job stops (`Worker.cs`), eBay stops and refusals (`EbayWorker.cs`), online stops (`OnlineTab.cs`, not a Stop pressed).
- `AppSettings`: resumeMobile, mobileOn, mobileBranch, autoUpdate, onlineCloseClean, autoUpdateTried, deskAutoUpdateTried. Version 2.8.0 - Runs by itself; `Build.ps1` lists the two new files.

## Review

Two independent reviews (read and traced by hand; nothing run).

The first, of the first draft, found:
1. **Blocker:** an automatic update checked "nothing being entered" only before its download; an entry starting meanwhile was stopped part way by the close (FormClosing's Stop all), which also switched mobile's come-back off. Fixed: COSTAR is held for the update (`updateLease`) from the download to the restart; FormClosing doesn't stop anything while it is; every failure releases it.
2. The desk's one retry was kept in memory only (a desk restart retried again, or lost the stop time) and spent its one chance while the RDP helper was away: now in the queue files (`stoppedUtc`, `autoRetried`), only while the RDP helper is in touch and taking that work.
3. A version that failed to start would be installed again every hour, the desk's automatic update showed message boxes, and after a failed update the helper stayed down: once per version (`autoUpdateTried`), no boxes, and Launch.ps1 starts the version before it.
4. An online order was closed with SHOP or Time in not taken, or with Customer Waiting not kept: those are CHECK BY HAND items now, and Customer Waiting is read again before closing.
5. A selected COSTAR that had closed was never alerted, and after a start with Windows before COSTAR was opened, nothing picked COSTAR later and mobile never came back: `CostarAlive`, a quiet look every minute, the come-back tried every 30 s.
6. An update dropped an online order loaded or waiting in the tab (`online.HasWork`).
7. The start-up file's quoting (a folder in PowerShell quotes inside cmd quotes) and non-ASCII folders: rewritten (the folder in cmd quotes; plain ASCII).
8. Mobile's "on" was forgotten when the helper closed during an entry or Windows shut down (Stop all inside FormClosing): remembered off only for a person's Stop all (button, Ctrl+Alt+F10).
9. Send a test posted on the window's thread (up to 15 s frozen): in the background.
10. TEST-PLAN step 9 used Stop to make an alert (a Stop never alerts): reworded.

The second, of the fixes (no blockers; fixes 1, 2, 6-9 confirmed correct), found:
1. A message held back by the limits (15 minutes per kind) still counted as said, so "COSTAR is back" could be the last word while it stayed down: `Raise` says whether it went; the watch tries again until it does.
2. A helper that opens on the Online orders tab (Online mode) turned mobile "on" while it was paused there: the come-back waits while that tab shows (`WhyNotResume`'s new reason; no Discord message for it).
3. Time in wrong at the final check was only a note, and the order was then closed: a CHECK BY HAND item.
4. A person's Stop all while a phone job waited to close a Repair Order left open ("Stopped before ... Add new was not pressed") would be retried by the desk and sent to Discord: a stop whose words begin "Stopped" is never retried (`Unattended.Retryable`), and the RDP helper doesn't alert a stop made with mobile switched off or the helper closing.
5. Stop all was greyed while mobile waited to come back: enabled then.
6. The once-per-version mark was spent before the download, so a brief download failure meant never by itself: set just before the restart (a download that failed is tried again the next hour; Discord hears once per version).
7. The desk's delayed restart could happen at 8:30 with someone at the desk, its message was overwritten within a second, and a click did nothing: it restarts only outside shop hours with nobody at the PC, the yellow line says the update is installed, and a click restarts at once.
8. A stop that typed nothing just before an update: the restart could come before the desk's retry and leave mobile off: the update waits while such a stop may be retried (`Alerts.Waiting`) or a phone job is stopped part way (`CanRelease`).
9. Start with Windows refused folders with accents, and updates live under the Windows user's folder: such a folder isn't written in the file; it starts the newest installed version found at run time.
10. Ship Via SHOP that COSTAR didn't keep stopped a fully typed online pickup: a CHECK BY HAND item (as for phone jobs).
11. The quiet look took "the only COSTAR open", e.g. COSTAR Sydney opened first: it takes only the branch used last or mobile's.
12. Suggested: after an update installs itself, Discord hears it is running (so silence means a look is needed): done (`update_done`).
- Also, while this was reviewed: Tommy, 22:00, "if it has delivery address it is DFE" (`Order.ForEntry`), and the made-up webhooks in the self-tests are put together at run time (no webhook-shaped text in the source for scanners).

## Checks performed here

- Compiled at C# 5 against the five reference sets: 0 errors, the usual 3 warnings.
- Self-tests: 142 + the 4 that need Windows = 146; Order Check 16/16. New: the Runs by itself case (retry rule, update rule incl. once per version, resume rule incl. unknown branch, start-up file incl. ASCII only and the folder first, webhook form, alert limits, what goes to Discord, the certificate message, a delivery's Ship Via DFE); the desk's one retry of a phone job and of an eBay order (a minute after, once, kept across a restart, not a typed or an old stop); the Customer Waiting times (today, next shop day, Saturday to Monday, ends, other days, bad dates) in the Time in group.
- Mutations: 23 of 23 caught (a wider today window, any later day, Sunday not skipped, a second retry, a retry after typing, updates in shop hours, updates while entering, a version tried again, resume in another branch, resume over a stopped job, no gap between alerts, any webhook host, a % or an accent in the start-up file, an unmasked stop, the plain trust message, the desk retrying a phone job twice, the stop time not kept, an eBay order retried after typing or twice, a delivery's Ship Via left as the website's, a person's stop retried, mobile turned on while the Online tab shows).
- Node: Repair Orders page 11, Job Card 59, startup 9, package check.
- End to end (Repair Orders page, the desk receiver's code, a simulated RDP helper): 111 checks passed (unchanged by 2.8.0; run on the 2.8.0 build).
- (install replay and scans: at release)

## Not verified here (no Windows or COSTAR here)

- The Startup-folder file starting the helper at sign-in; the in-place reconnect after Import connection; a Discord message arriving; the tray balloon; an update installing itself after hours and the helper restarting into it (and the previous version starting after a failed one); mobile coming back on after start and once COSTAR is opened; the quiet COSTAR look; Customer Waiting read again and the close on a real online order (TEST-PLAN 2.8.0).

---

# Validation — v2.6.12 — 2 November 2026

## Basis

- **The ask.** Tommy, 2 Nov 13:48: "please release the 2.6.12, you dont have to patch anything, I just want to make sure no corrupt files". Earlier that day `Setup-Desk.cmd` had been run again on the desk PC by accident (a new desk certificate), and the RDP helper said "Could not establish trust relationship for the SSL/TLS secure channel".

## Changes

- None to the helper or the website: 2.6.12 is 2.6.11 (a7042a5) with its version number changed (`VERSION.txt`, `OnlineTab.Version` "2.6.12 - Clean copy of 2.6.11", the two version words in `Build.ps1`), and the README / TEST-PLAN / VALIDATION entries.
- What the update does with it (Updater, unchanged since 2.6.0): the ZIP is downloaded, its size and SHA-256 checked against `latest.json`, every file checked against `PACKAGE-SHA256.json`, the package placed in a new folder under `%LOCALAPPDATA%\TempeMobileCostar\packages`, and the helper built there from those files. Settings, the phone pairing, the queue and the RDP helper's saved connection are kept apart from the helper's files and stay as they are.
- Not changed by any update: the RDP helper trusts the desk PC's certificate it was given in `worker-connection.json`. After `Setup-Desk.cmd` makes a new certificate, the desk's **Export RDP connection** has to be imported again (README 2.6.12, Install 3).

## Checks performed here

- Compiled at C# 5 against the five reference sets: 0 errors, the usual 3 warnings.
- Self-tests: 139 + the 4 that need Windows = 143; Order Check 16/16. Node: Repair Orders page 11, Job Card 59, startup 9, package check.
- (install replay and scans: at release)

---

# Validation — v2.6.11 — 2 November 2026

## Basis

- **The ask.** Tommy, 2 Nov 10:25: "check on the current version and check if anything is not optimal or not optimal enough, and make it optimal", and four changes: "apply those pop up skips on all the orders"; "add clear filter on the repair order html so I can go back to check all current order in case if I leave my pc with something filtered out"; "If I want it to be ordered, then instead of only putting SHOP on the comment, also tick customer waiting, otherwise tyres will never left warehouse"; "remove delivery instruction when autofilling online order".
- **The pop-ups** (Tommy's screenshots, 2 Nov 10:07, an account customer's Repair Order): the customer's **Notes** window over the blank Repair Order (New / Colour / Delete, the notes, OK), then a message box **"Point-of-sale Memo!"** with words and OK; "it cant be ignored, we have to press OK"; "Some customer have more than 1 pop up, so make sure both are cleared". The Notes hold card details.
- **Where they stopped the helper (2.6.10):** `Runner.WaitForRo` (the phone's Repair Orders) waited 30 s for the Repair Order to be in front and enabled, then stopped ("Another window is in front of the Repair Order"); the customer lookup (`LookupCustomer`, `CustomerFormReady`) went to `RecoverCustomerUi` after 750 ms, which cancels a window with Escape / Close and stops after a few tries.
- **"Clear filter" (the PC's):** 2 Nov 09:50 and 10:10 two phone opens stopped with "isn't in COSTAR's Work-in-Progress list (finished, or filtered out?)" on a 2-row and an 8-row list: a Cust/Contact search left in COSTAR's own Work-in-Progress boxes (Tommy's 10:07 screenshot). "In case if I leave my pc with something filtered out" is that filter; the phone's own search is cleared as well (Show all).
- **SHOP without Customer Waiting:** the Order tick on the Repair Orders page and phone jobs already set Ship Via SHOP, Customer Waiting and Date In today; the page's **SHOP** button beside Ship Via set Ship Via alone. On phone jobs, Customer Waiting is ticked last, after the print: 2 Nov 08:02 (diagnostics 10:52) the Job Card printed in 13.6 s and then `PressTick` found the Repair Order not in front ("COSTAR isn't in front with Customer Waiting free to change"), 1.1 s in; 29 Oct 11:34 the person had clicked COSTAR's main window, the print was held back (`user_active`) and Customer Waiting stopped with "COSTAR lost focus" (`foreground_lost`). Both were left to tick by hand: the orders had SHOP but no Customer Waiting, which is what Tommy saw.
- **Not optimal, from the diagnostics of 30 Oct:** "Add new is covered by another window" on an eBay order 0.13 s after COSTAR Sydney was asked forward while Windows was still switching to its desktop (30 Oct 08:14; 26 Oct 08:20, 08:21, 09:42; 16 Oct twice for online orders), each going in on Retry.
- 2.6.11 is 2.6.10 (f6db388) plus these.

## Changes

- **`Runner.Popups.cs` (new):** `PopupKind(title, class, buttons, words)` (pure): one button whose text is OK, then "notes" (title Notes, a WinForms window), "memo" (a `#32770` message box titled Point-of-sale Memo…), "notice" (another `#32770` with one OK), else null; words with NOT FOUND are null (the lookup's own Customer Not found). `MemoWords`: every number of 3 digits or more (with spaces, dashes, slashes or dots between: a card number with its expiry and code, a phone, an amount), and emails, taken out; 160 letters. `AnswerPopup(front)`: only a visible window of COSTAR's process that isn't the Repair Order and is owned (through the owner chain) by this run's Repair Order window; its buttons and, for a message box, its words read; nothing else read (the Notes grid is never touched); `Direct.Press` (BM_CLICK) on the OK, up to 2 s for the window to go; never pressed twice (a window still showing is waited for, 6 s from the press in all, then the run stops); at most 6 per run; event `popup_ok` with the kind and title only; the Notes → `Notices` ("COSTAR showed the customer's Notes before the order (OK pressed)…"), a memo → `Checks` (CHECK BY HAND) with its masked words.
- **Where it's used:** `WaitForRo` when the front isn't the Repair Order (then on); `LookupCustomer` and `CustomerFormReady` after the Customer Not found check and before `TryChooseFirstAccount` / `RecoverCustomerUi`; `RecoverCustomerUi` first. **Results:** phone jobs (`Worker.cs`) say the Notices with READY FOR REVIEW; the phone's Repair Orders (`RoWorker.cs`) put them (and, for a read, the Checks) in the report's notes; eBay (`EbayWorker.cs`) puts them before CHECK BY HAND; online orders show Checks as before.
- **COSTAR's filter:** `RoAsk.clear` / `RoRequest.Clear` / `RoTask.clear` (a clear is a fresh read; it joins a list read waiting); `WipHandles.Clear` (the one BUTTON reading CLEAR); `RoWip.ClearFilter` (its accessibility Press on a thread of its own, then up to 3 s for `FilterText` to read empty); `PressSearch` through the same `PressButton`; `ReadList(t, search, clear, …)` clears first when asked, with a note (cleared / wasn't filtered / couldn't be cleared); `RunList` skips Order Check's copy for a clear and says when nothing was cleared because a Repair Order was open; `RoWip.Open` clears a filter when the row isn't listed (Clear, Search, looked for again; `times.FilterCleared`; day log `ro_filter_cleared`). The page: `pcFilterOf(list)` reads the helper's "Work-in-Progress is filtered (…)" note; `#pcFilter` with `#clearPcFilter` → `ask("list", …, fresh, clear)`.
- **Repair Orders page:** `#clearFilter` chip ("Show all") (hidden unless a search or Today / This week narrows the list), `setFilter`, "No Repair Order matches. Clear filter shows them all."; the SHOP button sets Ship Via SHOP, Customer Waiting yes and Date In today where `cannot` allows; `?v=20261102-ro5`.
- **`Runner.OrderWindowBack(label)`** (MobileRunner.cs): before Ship Via SHOP and before Customer Waiting: until the Repair Order is in front and enabled, up to `OrderBackMs` (20 s): when nobody has used the PC for `OrderQuietMs` (3 s) and the window is enabled, `BringToFront`; else wait; past the time, stops with why (the part is then "by hand", as before). Event `order_window_back` when it had to.
- **`CostarWindows.OpenNew`:** a covered Add new with no Repair Order open is looked at again every 50 ms for up to `AddNewCoverMs` (1.5 s); day log `add_new_covered` (clear after / still covered after … ms, by which program); the refusal names the program (`CoverOwner`: the process name, never a title) and says nothing was pressed.
- **`OnlineTab.ShowOrder`:** a delivery order's `shipping.instructions` is set to "" (typed as empty into Shipping Instructions, as a new Repair Order has it; the final check expects "").
- Version 2.6.11 - Notices answered, SHOP orders; `Runner.Popups.cs` in `Build.ps1`'s source list.

## Review

An independent review of the first draft (read and traced by hand; nothing run). Found sound: the owner chain and recognition (a window of another order, of COSTAR's main window or of another program is never pressed; the button pressed is enumerated from the very window; a question with choices returns null); every wait bounded; a dead handle; nothing of the Notes read or logged by the answer path; the Stop semantics of `OrderWindowBack` (the same exception types as before); `Checks`/`Notices` consumers; the online blanking against the final check, duplicates and resumes; the page's hidden chips and `locked()`; C# 5. Its findings, fixed:
1. **Blocker:** `AnswerPopup` refused any window in `originalWindows` (COSTAR's windows from before the run). The phone's Repair Orders make their Runner after `RoWip.Open` returns, by when the Notes are already showing: so they'd have been "original" and the request would have stopped after 30 s as in 2.6.10. Now the owner chain alone decides.
2. A read's notes (a memo's words) never reached the phone: shown now with the Repair Order (a "warn" alert with OK).
3. The covered-Add-new refusal didn't say "Add new was not pressed", so the Job Card sheet would have said part of it may be in COSTAR: it does now; the cover's owner is looked up only when covered; a Stop in the wait says Stopped.
4. A message box whose words couldn't be read (COSTAR busy) counted as a notice; it could be Customer Not found, which the lookup must see itself: null now.
5. A Notes window that couldn't be answered fell to the account-chooser path (which dumps the window's controls and clicks a row) and to the stop-time dump: `IsNotesWindow` keeps it out of both; the recovery stops with its own words.
6. The lookup snapshotted the popup before answering it: answered first now, and a Notes window is never snapshotted.
7. A greyed OK counted; an OK COSTAR didn't answer was pressed again next time round: a greyed button isn't OK; an unanswered OK stops the run ("nothing more was pressed"); the wait uses `Pause` (a Stop is seen).
8. A second notice arriving while the Repair Order was being read, or a late memo after the lookup, stopped the run: `WaitForRo` looks at the front again after its snapshot; `Check(true)` answers a notice once while the customer is being entered.
10. The Online orders tab's finish line didn't say the Notes were answered: it does (Notices before Checks).
12. The phone's Repair Orders listed notices answered before the change was typed, and "(check by hand)" showed for the Notes sentence alone: notes built after the edit; "(check by hand)" only for checks.
14. `OrderWindowBack` brought the window forward every 350 ms for up to 20 s: 5 times at most now; "Repair Date today" waits for the window too.
- Accepted, not changed: a memo's words go to Checks, so an eBay order for a customer with a Point-of-sale Memo is entered and left open for review (the memo is for the person); `Direct.On` isn't honoured for the OK press (a BM_CLICK sent, as the Customer Not found OK is).
- Its reading of "clear filter" (COSTAR's own boxes, not the phone's): built (above); and, added here: the filter is never cleared while someone is using the PC (a quiet moment of 3 s waited for, up to 10 s), the note then says so.

## Second review

A second independent review of the changed code (read and traced by hand). Found sound: the owner chain, the kinds, the bounded waits, `OrderWindowBack`'s Stop semantics, the online blanking, C# 5. Its findings, fixed:
1. The day log took the filter's words (`ro_filter_cleared … : Cust/Contact = …`), and the open's stop messages carried them into the day log (`RoText.ForLog` masks quoted words only) and the run report: the day log has the boxes' names only (`FilterBoxes`); the stops name the boxes; the words go to the phone only (the progress line, the list's note, the result's notes).
2. A clear joined a list read already being done, which wouldn't clear: it joins only a list read still waiting, or one already clearing; otherwise it is a read of its own, handed out after (the desk hands one task at a time).
3. A search box that didn't answer read as empty, so "wasn't filtered" could be said of a filtered list, and a clear could count as done: `FilterTextKnown` (null when a box couldn't be read), `KnownFilter` (looked at again for up to 2 s); unknown is said as unknown; a clear is done only when the boxes read empty.
4. The open's Clear didn't look for a person at the PC first: `Quiet` before, and again right before the press (`ClearFilter`'s `ready`).
5./6. The clear branches ran without a Clear button, and the list's clear without Search to follow: both looked for; the note or stop says which button wasn't found.
7. A Clear COSTAR didn't answer within 5 s was taken as "not cleared" though it might still go: it stops, nothing more pressed (as Search).
8. The phone offered the clear to a desk or helper before 2.6.11, which would just read the list again: the helper says it clears (`RoHello.clears`, as `print`), the desk passes it on (`helper.clears` with GET /ro/list); the page offers the button only then, else says to clear it at the PC or update both.
9. The open's result didn't say the filter had been cleared to find the Repair Order: it does (the result's notes).
10. A clear could be answered with Order Check's 15-minute copy (nothing cleared): never; it fails with why.
11. The notices weren't shown when COSTAR left the Repair Order open: shown with that alert.
12. The Online orders tab put the Notes under CHECK BY HAND and "(check by hand)": on their own line; "(check by hand)" for checks only.
13. The page cut the filter's words at their first bracket: up to the bracket before "; " or the end.
14. An OK still showing after its wait was pressed again on the next look: the window is remembered and waited for (6 s from the press in all), never pressed twice; then the run stops.
- Added here: `ButtonName` (a greyed or unread button is "?") made pure, so the greyed-OK rule is tested.

## Third review

A third independent review of the second review's fixes (read and traced by hand). Nothing blocking. Its findings, fixed:
1. A notice whose OK went was recognised again by reading it: with COSTAR busy closing it, its OK could read as "?", and the customer lookup's recovery could then send Escape / Close over it (and dump a memo into the run's files). Now such a notice is known by its window alone (`PressedNotices`), looked at before anything is read: waited for (6 s from the press), never pressed again, never cancelled. `AnswerPopup` returns true while it waits, so no caller goes on to cancel it; `Check` waits for it too.
2. A notice that took more than 2–3 s to close lost its words (a memo's CHECK BY HAND): what COSTAR showed is noted as its OK goes.
3. Only the last pressed window was remembered, and never forgotten: every pressed one is remembered and forgotten once gone (hidden or closed), so one shown again later is a new notice.
4. While opening, the wait for a quiet moment before Clear didn't stop the open when someone used the PC (a Repair Order a person opened meanwhile could then be taken for the helper's): the open's own check runs on every pass of the wait, and again before the Search that follows the clear.
5. "The filter was cleared" was lost when the Repair Order had changed, or the open stopped after the clear: said with those too (in the phone's words, never the day log). On a change or a print, the Notes answered and the filter cleared now go with the result's words rather than under "Check by hand" (which would have turned every save for a customer with Notes yellow).
6. A Clear that didn't empty the boxes was put down to "someone may be using the PC": each reason is said as it is; the list's last look waits for a box that doesn't answer (2 s) before saying the list may be filtered.
7. The day log's box names were parsed back out of the words (a search holding ", X = " would have put X in the day log): they come from COSTAR's own labels now (`Describe(…, out boxes)`), tested.
- Accepted, not changed: a clear queued for a helper that turns out not to clear is read as a plain list (the page then says to clear it at the PC).
- Added here: a Point-of-sale Memo is never dumped into the run's files (as the Notes), whatever stops the run; a memo's words lose every number of 3 digits or more (until now a card's expiry and code could stay); the tests' memo words and card number are made up (the public test card number), and the page's filter example is "Cust/Contact = SAMPLE".

## Checks performed here

- Compiled at C# 5 against .NET 4.8 (build references and the build's response file), 4.6.2, 4.7.1 and 4.7.2 reference assemblies: 0 errors, the usual 3 warnings.
- Self-tests (harness): **139** groups pass + the 4 that need Windows (as before) = **143**; Order Check 16/16. New: the notices' kinds (Notes by title and class, a memo, a notice, a question with choices, no button, Customer Not found, the Repair Order, nulls, a greyed OK), a memo's words masked and cut short, the waits bounded; the desk queue's clear (joins a list read waiting and makes it fresh; waits as its own read behind one being done; travels in the task; an older desk's task reads as no clear); the helper's clears flag reaching the phone; pressed notices (waited for, a stop after 6 s, two at once, forgotten once gone); a clear joining a read already clearing; Order Check: the boxes' names from the labels only.
- Mutations (16 of 16 killed): any buttons taken, Notes of any class, a notice of any class, Customer Not found taken, a message box with no words taken, a greyed OK taken, card numbers kept, a wait of an hour for the window, a minute's wait on a covered Add new, a clear joining a list read being done, the clear offered for a helper that doesn't say it clears, a pressed notice forgotten (pressed again), one waited for for ever, every pressed one forgotten at each look, the day log's box names taken from the words, a memo's expiry and code kept.
- Node: Repair Orders page 11 (1 new: the filter note read, with brackets, unknown not offered), Job Card 59, startup 9, package check. End-to-end (real desk receiver code, Chromium at phone size, a simulated RDP helper): Repair Orders **111** checks (new: Show all hidden, shown with a search and its words, clearing the search and picking All, shown for Today and cleared; SHOP setting all three; COSTAR's filter said with its box; with a helper that doesn't say it clears, no button and what to do; then the clear asked of the helper as a clear and a fresh read, the list whole again and the note; the notices shown with a read, and with a read COSTAR left open).
- (install replay and scans: at release)

## Not verified here (no Windows or COSTAR here)

- The Notes window and the memo closing on their OK (BM_CLICK), the Repair Order then loading; two in a row; what the lookup does when the account's Notes come as the account loads. TEST-PLAN 2.6.11 steps 2–5.
- The 20 s wait and the bring-forward before Customer Waiting (step 8); Add new's cover clearing within 1.5 s on a desktop switch (step 10).
- COSTAR's Clear button through accessibility and the boxes reading empty after it; the list after Search (step 6).
---

# Validation — v2.6.10 — 29 October 2026

## Basis

- **The ask.** Tommy, 29 Oct 21:45: "at the moment if i want to add new order through phone or check and order through phone if there is any repair order open that is connected to that costar it will not do anything and need to wait for me to manually close right? or has it been patched?" — told: checking or changing an order from the phone closes it first since 2.6.7; a new order from the phone still waits. 21:47: "ok we fix that one first, release new version to patch that, please note that the ebay hasnt been tested, I need to test it in the morning".
- **So:** 2.6.10 is 2.6.9 (1f23de6) plus this one change. The Background test (2.7.0, the untested eBay work) is a separate test build and isn't in it.
- **Why a new job waited (2.6.9):** `WorkerEngine.Loop` told the desk it wasn't available while `CostarWindows.Available` found a Repair Order window open in the selected COSTAR ("A Repair Order is open in the selected COSTAR"); the desk hands out a new job only to an available helper (`JobQueue.Poll`), and `CostarWindows.OpenNew` refuses with a Repair Order open.

## Changes

- **`WorkerEngine.Loop`:** when the reason is an open Repair Order, `CloseFirst(target)` decides (a failure there is said as the reason, never as "Desk PC not reachable"): every Repair Order open in the selected COSTAR may be closed first → available, "COSTAR … ready: Repair Order … is open there and will be closed first"; else not available, with why ("A Repair Order is open in COSTAR Tempe: …").
- **`WorkerEngine.Run`:** for a job about to press Add New (`cp.window==0`, after the uncertain-Add-New check), `CloseOpenFirst` before `OpenNew`: not in Order Check's COSTAR, else the job stops with nothing closed; each open Repair Order looked at again right before its close (held, COSTAR asking, nobody at the PC, its PO#, and Work-in-Progress: `WhyNotOnWip`); someone using the PC, or COSTAR not answering the look at its PO#, waited for up to `CloseWaitSeconds` (60 s in all, said once: "Waiting for a quiet moment to close a Repair Order left open …"); then the progress "Closing Repair Order …, which was open in COSTAR …, before entering …" and `RoEngine.CloseWindow` (WM_CLOSE only while nothing of COSTAR's is open on it; 8 s). A reason that holds it (held, COSTAR asking, an online or eBay order's PO#), a wait that runs out, another list, or a close that doesn't happen stops the job before Add New, with its own words, what was already closed ("Closed RO … first (open in COSTAR …). …"), "Add new was not pressed (nothing was opened or typed for this job)" and Retry. A stop at Add New itself after a close says the close too. The result says "Closed RO … first (open in COSTAR …)". A job retried in its own Repair Order (`cp.window!=0`) and the "close" command close nothing.
- **Never in Order Check's own COSTAR** (`OrderCheckLink.IsWipWindow`, as the phone's Repair Orders): there a new job waits as in 2.6.9.
- **The rules (`WorkerEngine.KeepOpen`):** held for a person, each with its own words (`HeldWhy`): the job's own window (waiting for review → "press Next Order on the desk PC"; stopped there → Retry, Release or start it again), the Repair Orders a job was started again from (new `WorkerJournal.setAside`, recorded by `StartAgain`; held while the job isn't in yet — not ready for review or closed, not released by hand — and the window still exists in that COSTAR: `SetAsideWindows`), the Online orders tab's (`HeldWindows`), the eBay engine's unfinished attempts (new `EbayEngine.HeldWindows`); then `RoEngine.KeepOpen` (2.6.7: COSTAR asking something on it, someone used the PC in 3 s, PO# unread, PO# an online order's); and a PO# in the eBay order number form (should COSTAR Sydney be the selected COSTAR).
- **`RoEngine` (the phone's Repair Orders):** `CloseWindow` made internal (unchanged); new `ForgetLeftOpen(window)`: a Repair Order they left open, closed first by a new job, is no longer listed as left open (`WorkerEngine.ClosedFirst`, wired in `WorkerForm`). Their held windows now include `SetAsideWindows` (a small change to 2.6.7: they never close the Repair Order a phone job was started again from either, while that job isn't in).
- Day log `mobile_close_first` (the RO number or "a Repair Order", closed / still open, the job's reference), as 2.6.7's `ro_close_first`.
- Version: 2.6.10 - Open RO closed for new jobs.

## Review

An independent review of the change (read and traced by hand). Found nothing in: every other flow as in 2.6.9 (the phone's Repair Orders, eBay and online orders, the desk); the "close" command, a resumed job (`cp.window≠0`) and an uncertain Add New never reach `CloseOpenFirst`; Pinad mode and a stopped or ready job (also after a restart) keep their own window through the journal; other COSTARs untouched (`Orders` by process); thread safety and failure paths (the peek cache's own lock, nothing escaping the availability check, `cp.opening` untouched, the lease and input lock released); C# 5. Its findings, fixed:
1. After "Start this job again" (a fresh checkpoint, window 0) with the old window still open, Retry (handed out whatever `available` says) would have closed the job's own partly typed Repair Order and entered the job again in a new one (2.6.9 refused at Add New). Now `StartAgain` records the set-aside checkpoint and its window is held for the job's new start, with words that say to close (and delete) it first.
2. `CloseOpenFirst` didn't check Work-in-Progress first (the phone's Repair Orders do): with COSTAR on another list a Repair Order would have been closed for nothing. Now checked; Order Check's own COSTAR is skipped too (the Loop and `CloseOpenFirst`).
3. The minute's wait restarted for each open Repair Order, and one unanswered look ended it at once; now one budget in all, and an unanswered look is tried again within it.
4. Words: after the wait ran out it said the Repair Order "will be closed once nobody has used the PC for 3 s" (it won't; the job stopped): now its own words; the held reasons say what to do (Next Order for a phone job waiting for review); the result now names the Repair Order closed.

## Second review

A second independent review traced those fixes (all hold: the rollback in `StartAgain`, older journals without `setAside`, `Accept`/`Forget` dropping it only when it can't matter, Retry handed out regardless of `available`, the single wait budget, the phone reading "Closed RO … first" as a note, no C# 6, no lock nesting) and found nothing at blocker level. Its findings, fixed:
1. Work-in-Progress was looked at once, before the wait (up to 60 s): COSTAR switched to another list meanwhile would have had its Repair Order closed for a job that then couldn't press Add New. Now looked at right before each close.
2. A stop after a Repair Order was closed (Add New refused, or a second Repair Order kept open) didn't say so. Now it does (the phone's Repair Orders already did).
3. The phone's Repair Orders held only the job's own window, 0 after "Start this job again": a Repair Order request from the phone could still have closed the set-aside, partly typed Repair Order, and Retry would then have entered the job in a second one (since 2.6.7). Now they hold it too.
4. The set-aside Repair Order stayed held after the job was released by hand or closed, with words ("delete it … then Retry") wrong by then. Now held only while the job isn't in yet.
5. Words: the wait's line no longer says "nobody using the PC for 3 s" (it also waits for COSTAR to answer a look); the eBay engine's held windows are its unfinished attempts (an entered eBay order's Repair Order waiting for review is kept by its PO#), said as "the Repair Order an eBay order stopped in".
6. A local named like a field (`busy`) renamed (`inUse`).

After it (here): the stop words before Add New now say "Add new was not pressed", the words the phone's progress sheet already reads as not entered (2.6.8's refusals), so the sheet says "Not entered in COSTAR" rather than "Part of it may be in COSTAR" when it didn't see the job start. Text only.

Left as they are (as in 2.6.7 or 2.6.9, or the desk's and the website's code, unchanged here): the phone's Repair Orders can still offer "Close it" for a Repair Order closed first meanwhile (it then says it was already closed or not left open); the desk tells a retried job that stopped before Add New "carries on … in its own Repair Order"; the phone's sheet says "Stopped part way" for any stop once it has seen the job start (its words then say Add new was not pressed); the phone's Repair Orders say a set-aside Repair Order is "a phone job's or an online order's, waiting for review" (2.6.7's words).

## Checks performed here

- Compiled at C# 5 against .NET 4.8 (build references and the build's response file), 4.6.2, 4.7.1 and 4.7.2 reference assemblies: 0 errors, the usual 3 warnings.
- Self-tests (harness, on the final code): **138** groups pass + the 4 that need Windows (as before) = **142**; Order Check 16/16. New: the rules for a new phone job (closed first; held with its words, asked, busy, online, eBay, unread kept; only the eBay number form counts; the phone's Repair Orders' rules as in 2.6.7; a started job waits a while, never for ever; the set-aside Repair Order kept in the journal, older journals read without it).
- Mutations (7 of 7 killed, again after the second review's fixes): the eBay rule removed, the PO# not trimmed, held ignored, 2.6.7's rules not applied, a wait of an hour, no wait, the set-aside Repair Order not kept in the journal.
- Install replayed with the Updater code the PCs run (unchanged since 2.6.0), from 2.6.9, 2.6.8 and 2.6.2: 2.6.10 offered over each (a two-digit patch number). The upload set (no website files) was scanned for secrets and customer data, including the 28 and 29 Oct reports' Repair Order, document and online order numbers.

## Not verified here (no Windows or COSTAR here)

- The close itself and COSTAR keeping the closed Repair Order in Work-in-Progress (as 2.6.7, same close); the waits and messages on the phone and the desk (TEST-PLAN 2.6.10).

---

# Validation — v2.6.9 — 29 October 2026

## Basis

- **The ask.** Tommy, 29 Oct 12:02, with the report of 11:57 (helper 2.6.8): "check with the error, and fix it", and "with the jobcard/fitment planner page, can you please add a progress when you submit to costar just like the repair order page".
- **The error (run 11:34:07, a phone job, 12 steps):** step 9/12 "Quantity for 430332" stopped with "COSTAR did not focus the expected field".
  - 6777 ms: the tyre line loaded (`item_load` 150 ms). 7041 ms: step 9 began; the helper clicked into the line's Qty box and wrote the quantity.
  - 7230 ms `focus_lost before Tab`: Qty [730,369] → Disc [834,369] on the same line, "the last key or mouse move 31 ms ago, 47 ms after the helper's own" (the helper's own click: COSTAR moved the keyboard by itself).
  - 7237 ms `focus_again`: clicked again. 9260 ms `focus_failed`: for 2 s the keyboard stayed in Disc.
- **Its retry (11:34:26, from checkpoint 8/12):** completed. `repair_date` "box not found": the Repair Date under its label is a COSTAR panel (`WindowsForms10.Window…`, [389,123,95,21] on every 28 Oct map), not an EDIT, combo box or date picker, so `RoSelectors.DateIn` finds nothing.
- **Not errors in that retry:** the Job Card print and Customer Waiting were skipped because someone used the PC just then (`user_active` 94 ms before Print), as designed; `ro_number` not read beside the label on a new Repair Order (the print form is then checked by its owner window). The 37 "desk connection drops" were the desk PC off overnight (01:05–05:18, logged every 100 failed polls); one blip at 10:50 recovered.

## Changes

- **`Runner.Focus`:** `AddCode` sets `loadedAt` when an item line has loaded (not DET, not a blank-description line). The next `Focus` within `LoadWindowMs` (4 s) first calls `LoadSettle`: `SettleKeyboard` waits for COSTAR to answer (`WaitIdle`), then for the focused control to stay the same for `StableAfterLoad` (350 ms counted from the load, at least 120 ms), at most `LoadSettleMs` (1.5 s). If it settles in the wanted box, nothing is clicked. This runs before the "already focused" shortcut, so a box COSTAR is about to leave isn't taken. Event `load_settle`.
- **Item-line boxes (`grid`) go through `IntoLineBox`:** one click (`ClickInto`: 2 s for the keyboard, event `click_not_taken`); right after a load (and always in `FocusAgain`) the keyboard must then stay in the box for `LineHoldMs` (250 ms) with COSTAR answering (`Stays`, event `line_box_left`); otherwise `BackAlongLine`, and the keyboard must stay there too. A failure stops as before ("COSTAR did not focus the expected field"), now with `focus_failed` saying where the keyboard was. Other boxes keep 2.6.6's path.
- **`BackAlongLine`:** each round waits for COSTAR to answer first, then looks where the keyboard is: already in the box → done; not in a box further along the same line (same parent, to the right, level within 3 px: `FurtherAlong`) → no key; someone used the PC in 3 s → no key. Then Shift+Tab is sent at once with `Native.ChordNow` (refuses, sending nothing, while a modifier is held; `Chord` would wait up to 3 s). A second Shift+Tab only after the first visibly moved the keyboard one box back (a box such as List can sit between); one not taken ends it. Events `shift_tab`. Nothing is typed.
- **`Runner.FocusAgain`** (Tab after a written grid box whose focus left before Tab; same entry rules as 2.6.6: the box shows exactly what was written, nobody used the PC in 3 s): `SettleKeyboard(300, 1500)` first; if it isn't back in the box, `IntoLineBox` with the person check right before the click (`ClickTarget(c, unlessPerson)`, event `click_skipped`); then as before: COSTAR idle, 250 ms, the box must hold the keyboard and show what was written, `EM_SETMODIFY` again, Tab.
- **`RoSelectors.DatePanel`:** the one visible, non-static `WindowsForms10.Window…` control in the label's own panel right under the single Repair Date / Date In label. **`CostarDate`:** `RoRead.ParseDate`, then `dd-MMM-yyyy`, `d-MMM-yyyy`, `dd-MMM-yy`, `d-MMM-yy`, `dd.MM.yyyy`, `yyyyMMdd`, `ddMMyyyy` (invariant culture), only within 20 years of today.
- **`MobileRunner.RepairDateToday`:** when `DateIn` finds no box, `DatePanel` and `ReadCostarDate` (read only: the panel's accessibility value, else its first child's, both read on a thread of their own with at most 2 s for COSTAR to answer (`AccessibleValues`; Stop still works meanwhile), else its window text). Today → "Repair Date is today."; another day → "Repair Date isn't today (…): set it to today by hand."; unread → "make sure it is today". Event `repair_date` with how it was read. Never typed into. `CostarDate` reads "Sept" as "Sep".
- **Desk receiver:** `JobStatus.waiting` (null unless queued). `JobQueue.Ahead(id)` (under the queue lock) mirrors `Poll`'s rules: the current job (being entered; stopped; ready for review → Next Order, or being closed when `nextRequested`, or Pinad mode closing it when the first pending job can go), else the first earlier pending job (stopped, awaiting approval, or a count). `ReceiverApi.JobWaiting`: desk stopped receiving → RDP helper not in touch (15 s) → phone jobs off (its words) → the current job queued again by Retry ("carries on in its own Repair Order (leave that open in COSTAR)": `Poll` hands it back whether or not COSTAR is free) → `Ahead` → COSTAR not free (its words) → next in line. Set on `POST /jobs`, `GET /jobs/{id}`, `POST /jobs/{id}/retry`. Older phones and RDP helpers ignore the field (JavaScriptSerializer skips unknown members).
- **Job Card page** (`Fitment_Planner.html` / `.js`, `jobcard-shared.js`; query `?v=20261029-progress`):
  - a `<dialog id="submitSheet" class="jobcard-progress-sheet">` (not `jobcard-dialog`), its CSS inline in the page: steps sent / queued / working / done, the words under each, a step bar, the result, actions;
  - `progressView(sub, live)` (pure, in `jobcard-shared.js`) decides what it shows; the reducer keeps `waiting` (also on an answer with the same version), the last step count `step` and how far it got `reached`. A stop counts as part way (typing step red, "Part of it may be in COSTAR: check it there") unless this phone saw nothing typed *and* the words say nothing went in (`NOT_ENTERED`: "Not entered …", the choices, "Add new was not pressed", "before any fields were entered"). "Closed on the desk PC" marks only Sent;
  - opened by SUBMIT TO COSTAR (once the submission is saved), Retry, and **Show progress**; Close/Done only close it; Retry on the sheet is the existing `retrySubmission`; New job is the existing `newJob` (it asks first);
  - polls every 1.5 s while it is open and the order isn't settled (3 s otherwise);
  - opening and drawing it can't get in the way of sending (each in its own try/catch); the result is made again only when it changes; Show progress shows only with a `jobcard-shared.js` that has the sheet;
  - the COSTAR status box shows the waiting reason too.
- Version: 2.6.9 - Job Card progress. Includes 2.6.8 and 2.6.7.

## Replayed on the recorded maps

`RoSelectors.DatePanel` on every recorded window from 28–29 Oct (harness build, the maps' parents, classes, words and positions): the 9 Repair Order maps (four windows, 28 Oct 09:05–10:09) → the panel at [389,123,95,21] each time; the 2 wholesale Order maps (29 Oct 01:08, 01:10) → none (no Repair Date label). The date itself is masked in the maps ([number]), so reading it is checked only on the PC.

## Review

An independent review of the first draft found nothing that could type into the wrong box, press Save, Sell or Print, or wait without a limit. Its findings, and what was done:

1. **Shift+Tab on a stale look** (medium): the keyboard was looked at, then COSTAR waited for and a held modifier waited for (up to 3 s), then the key; a second press didn't check the first had gone; a keyboard already back counted as a failure. Fixed (`BackAlongLine` above, `Native.ChordNow`).
2. **The 11:34 stop could still happen** (medium): `Focus` had no fallback when its own click didn't take after `LoadSettle` (the 11:34 case exactly), and a click counted as taken on one look although COSTAR moved the keyboard on within 50 ms. Fixed: `IntoLineBox` for both paths, with `Stays`.
3. **`FocusAgain`'s "nobody at the PC" look up to 7 s old by the click** (low–medium). Fixed: looked at right before the click (`ClickTarget(c, unlessPerson)`).
4. **The phone said "Not finished in COSTAR" when part of it may be in** (when it didn't see the typing). Fixed: part way unless the words say nothing went in.
5. **After Retry of the stopped current job the desk gave COSTAR's "A Repair Order is open" as the reason** (its own Repair Order), which could lead someone to close it. Fixed: `IsCurrent` → "carries on in its own Repair Order (leave that open in COSTAR)".
6. **Minor:** the sheet opening could stop a send or leave `sending` stuck (fixed: try/catch); the date read's accessibility calls had no time limit (fixed: a thread, 2 s); "Sept" (fixed); the result rebuilt every poll (fixed); Show progress with an old `jobcard-shared.js` (fixed: hidden). It also confirmed: no lock nesting, older readers ignore `waiting`, `Ahead` matches `Poll`, the equal-version branch is saved and keeps the submit check, no double submission, all text via `textContent`.

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **137 of 141** helper groups and 16 of 16 Order Check; the same 4 Windows-only groups fail here by design. New groups:
  - "A phone job waiting in the queue says why": through the real routes (`POST /jobs`, `GET /jobs/{id}`, retry): COSTAR busy, phone jobs off, the desk stopped, not in touch, next in line; one being entered; ready for review (Next Order, 2 ahead, Pinad mode, Next pressed); one that stopped (current, and before being handed over); a retried current job (and that `Poll` does hand it back with COSTAR busy); awaiting approval (1 and 2 ahead, and itself); the plain count; Pinad mode with an earlier stopped job (built from a saved queue: no close, that job said);
  - "A phone job's quantity after its line loads": `StableAfterLoad`, the constants, `FurtherAlong` on the 11:34 boxes;
  - "Repair Date": `DatePanel` on a made-up layout like the maps (Date In too; two boxes, hidden, no label, two labels, another panel's box, a button), `CostarDate` in nine formats, spaces, "Sept", another day, and eight things that aren't dates.
- **22 C# mutations, each failing the self-tests** (two survived the first draft's tests; both tests were added): `Ahead` ignoring the current job, counting wrong, dropping the stopped and awaiting-approval holds, Pinad always closing, counting later jobs; `JobWaiting` without the in-touch check, with the queue last, for any status, not on Retry, without the retried-current case; `FurtherAlong` either side or any line; no 120 ms floor; a short settle; `DatePanel` any parent, any class, any height, first of several; `CostarDate` any year, fewer formats, no "Sept".
- **15 page mutations, each failing the page tests:** the same-version waiting, the kept step, `reached`, waiting for any status, offline, bad step counts, checks as notes, no Retry on the sheet, no Show progress, no sheet on submit, the card's queued text, always part way, never part way unseen, the result rebuilt every poll.
- Replayed on the recorded maps (above).
- Node: Job Card 59 (12 new), startup 9, Repair Orders 10. End-to-end on this build (real desk receiver code, Chromium at phone size, a simulated RDP helper): Job Card 28 (9 new: the sheet from submit to ready, the step bar at 8 of 12, Close and Show progress, the waiting reason from the RDP helper's words, the stop with Retry on the sheet, the retry followed to ready), Repair Orders 96.

## Not verified here (no Windows or COSTAR here)

- **COSTAR's own move after a line loads:** whether the settle catches it before the click (then `load_settle` shows "… move(s) by COSTAR"), or whether the click itself triggers it (then `FocusAgain` → `shift_tab` "back with Shift+Tab"). TEST-PLAN 2.6.9 step 6.
- **Shift+Tab's order on a COSTAR line:** expected Disc → (List?) → Qty. If it goes anywhere else the helper stops there, as before, without typing.
- **The focus sequences themselves** (`LoadSettle`, `IntoLineBox`, `Stays`, `BackAlongLine`): they call Windows directly, so only their arithmetic (`StableAfterLoad`, `FurtherAlong`, the constants) is self-tested here; the run report's events show each step on the PC.
- **The Repair Date panel's accessibility value** (11 characters in the 28 Oct map, likely "29 Oct 2026"). TEST-PLAN step 7.
- **The sheet on Tommy's phone** (dialog support: iOS Safari 15.4+, current Android Chrome; without it the page works as before, without the sheet).

---

# Validation — v2.6.8 — 29 October 2026

## Basis

- **Found in the report of 29 Oct, 01:18** (helper 2.6.6). Tommy sent it with "study this, wholesale order". Three read-only maps (01:05, 01:08, 01:10) show COSTAR Sydney (Branch 1) on **"Orders yet to be filled"**, the wholesale orders list, with a wholesale Order open.
- **The list title.** The main window shows one list at a time. Its title label sits at [208,67], where Work-in-Progress shows "Work-in-Progress", and it's the first STATIC in EnumChildWindows order. Both lists have their own **Add new** in the same place ([210,88]).
- **What Add new does there.** On "Orders yet to be filled" it starts that list's document, a wholesale Order ("Order  Branch 1 …"), not a Repair Order.
- **The gap.** `CostarWindows.OpenNew` (online orders, phone jobs, eBay orders) found the one Add new on the main window and pressed it, without checking which list was showing. "Leave the selected COSTAR on Work-in-Progress" was only advice in the texts.
  - **What would have happened:** an eBay order arriving with COSTAR Sydney on that list would have started an empty wholesale Order, waited 30 s for a RepairOrder window, stopped ("Add New did not appear") and left the Order open. A retry would have opened another one.
  - **Typing was never at risk:** the helper only works in windows titled RepairOrder, and its line code needs the "Qty or Hrs" heading, which an Order doesn't have.

## Changes

- **`CostarWindows.Showing(main)`:**
  - first asks COSTAR a no-op message (WM_NULL, 250 ms). A COSTAR that doesn't answer is asked nothing more and reads as "" (each label read could otherwise wait 0.1–0.5 s);
  - null when `TempeOrderCheck.WipScreen.Locate` finds Work-in-Progress (the same look Order Check and the phone's Repair Orders use);
  - otherwise the list's title from `ListTitle`, or "" when it couldn't be read.
- **`ListTitle(main)` / `Title`:**
  - the title is the topmost *wide* visible STATIC (at least `TitleWidth` = 400 px; the title spans the list, 1713 px on the PC; the search labels are 235 px at most), the leftmost when level;
  - each label is read with `Native.TryText` (100 ms), and the first one that doesn't answer ends the look with "", so a lower label is never taken for the title;
  - no wide label, or an empty one on top, gives "";
  - words that aren't COSTAR's short words (`TitleWords`: 1–40 characters, letters first, then letters, digits, spaces and `'&/().,-`) give `UnnamedList`: still another list, with no words repeated.
- **`OtherList(showing)`:** another list's title (or `UnnamedList`) was read, not "Work-in-Progress".
- **`NotOnWip(costar, showing)`:** what is said in each case:
  - another list: "COSTAR … is showing "…" (or: another list), not Work-in-Progress (Add new there doesn't start a Repair Order). Put it back on Work-in-Progress";
  - "Work-in-Progress" named but not found: "… Work-in-Progress list isn't ready yet";
  - nothing read: "… isn't answering: which list it shows couldn't be read (it must show Work-in-Progress)".
- **`OpenNew`:**
  - before looking for Add new, another list refuses at once;
  - nothing readable, or Work-in-Progress still loading, is looked at again every 250 ms for up to `WipWaitMs` (15 s, about as long as the helper's other waits for a busy COSTAR), then refused;
  - Stop is honoured ("Stopped before Add new. Nothing was pressed.");
  - right before `beforeClick` and the press:
    - a last look refuses when another list's title is read;
    - the Add new found earlier must still be showing and enabled, and for a mouse click still the window under the point. These are read without any text, so a busy COSTAR can't slip past them.
  - Each refusal goes in the day log (`add_new_refused`) and throws "… Add new was not pressed.".
- **`WhyNotOnWip(target)`** (for the waits):
  - non-null when another list, or Work-in-Progress named but not found, was read;
  - null when COSTAR is too busy to say. That case isn't held back here, as before 2.6.8; `OpenNew`'s own look waits for it.
- **`CostarWindows.Available`** (phone jobs in `Worker`, phone Repair Orders in `RoEngine.Free`): `WhyNotOnWip` first, then open Repair Orders as before. The "A Repair Order is open …" text is unchanged, so 2.6.7's close-first still recognises it.
- **`RoEngine.Run`:** `WhyNotOnWip` right before `CloseOpenFirst`, so a Repair Order is never closed first for an open that can't happen ("… Nothing was closed or opened."). `Free`'s answer can be up to 3 s old.
- **`EbayEngine.Available`:**
  - checks `WhyNotOnWip` after finding COSTAR Sydney. An eBay order is declined back to the desk's queue with the reason, and goes in once the list is back;
  - if COSTAR closed or changed since the last look, the eBay engine looks for COSTAR Sydney again at once and says so.
- **End-of-day report:** `add_new_refused` is counted under THINGS TO LOOK AT, with the last reason. These refusals come before a run starts, so no run report holds them.
- **`StopCategory`:** `not_on_wip` for the texts, kept for any run that ends on one (none does today).
- **Test data:** the 2.6.7 test used a real online order number; it now uses the made-up TTW0000414.
- Version: 2.6.8 - Add new on WIP only. Includes 2.6.7.

## Replayed on the recorded maps

The check (Order Check's `WipScreen.Locate` and the new `ListTitle` / `OtherList`) was simulated on the maps' recorded controls (parents, classes, words, positions):
- **28 Oct 09:04**, COSTAR Sydney and both COSTAR Tempe windows on Work-in-Progress: found (the `ultraGrid1` list, one Search button). Title "Work-in-Progress", not another list. So eBay orders still go in.
- **28 Oct 09:50**, COSTAR Tempe with a Repair Order open: found.
- **29 Oct 01:05, 01:08, 01:10**, COSTAR Sydney on "Orders yet to be filled": not found. Title "Orders yet to be filled", another list, so Add new is refused at once.

## Review

An independent review of the first draft (commit 0082461) found **nothing critical or important**. In the default setup it found no way for Add new to be pressed while another list shows, and no way for a steady Work-in-Progress screen to be refused all the time. Its minor findings, and what was done:

1. **A lower label could be taken for the title** when the title's read timed out but a search label answered. Fixed: the first unanswered read ends the look, and the title must be the topmost *wide* label.
2. **"`not_on_wip` in the end-of-day report" was never recorded:** refusals come before a run report exists. Fixed: the end-of-day report counts `add_new_refused` from the day log; the README says so.
3. **The last look let an unreadable screen through to a mouse click** (Direct off, a list switched during the activation while still loading). Fixed: the Add new found earlier must still be showing and enabled, and for a click still the window under the point.
4. **A phone job handed out from an answer up to 3 s old can stop instead of waiting** if the list changes in between. Kept: nothing is pressed, the job says why, and Retry works (`beforeClick` hasn't run). The README says so. eBay orders recheck when they're claimed and go back in the queue.
5. **A refusal could take much longer than 3 s** while COSTAR is busy but not yet counted as hung. Fixed: the 250 ms WM_NULL look reads nothing from a COSTAR that doesn't answer. The wait for a busy COSTAR is now a deliberate 15 s.
6. **Privacy: `TitleWords` checks a label's shape, not where it comes from.** Hardened: only the topmost wide label counts, and odd words read as "another list". The mapped lists' titles are COSTAR's own words.
7. **First use of `Locate` on COSTAR Sydney.** Replayed on the recorded maps (below): Sydney's Work-in-Progress is found. README check step 2 shows it on the PC, and step 4 sends one real eBay order.
8. **Close-first could close a Repair Order before an open that then fails** (a nit). Fixed: `RoEngine.Run` checks `WhyNotOnWip` before `CloseOpenFirst`.
9. **Nits:** the eBay panel showed the desk's wording for a COSTAR that had just closed (fixed: it looks again at once); `TitleWords` ran twice per label (gone).

The reviewer also noted that the draft's "busy counts as ready" for the waits would let a Locate mismatch on Sydney fail every eBay order. Fixed: Work-in-Progress named but not found now holds work back with "isn't ready yet". Only "can't be read" isn't held back.

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **134 of 138** helper groups and 16 of 16 Order Check. The same 4 Windows-only groups fail here by design.
  - New group "Add new only on Work-in-Progress (2.6.8)":
    - the title (topmost wide label, leftmost when level, none or empty on top);
    - `TitleWords`, and words that aren't plain becoming "another list" without being repeated;
    - `OtherList`, the three texts, and the stop's kind;
    - never the open-Repair-Order wait text.
- 12 mutations, each of which fails the self-tests:
  - Work-in-Progress taken for another list;
  - long titles;
  - any characters;
  - rightmost; bottommost;
  - the unread text dropped;
  - the category dropped;
  - "another list" not another list;
  - an empty top label skipped;
  - a narrow title width;
  - a short wait;
  - odd words repeated.
- Replayed on the recorded maps (above).
- End-to-end on this build: Repair Orders 96, Job Card 19. Node tests: startup 9, Job Card 47, Repair Orders 10.
- Install replayed with the Updater code the PCs run, from "2.6.6 - Item lines clicked". The upload set was scanned for secrets and customer data, including the 28 and 29 Oct reports' Repair Order, document and online order numbers.

## Not verified here (no Windows or COSTAR here)

- **The checks on the real PC:** `WipScreen.Locate` and `ListTitle` on the live COSTAR Sydney and Tempe windows, and the WM_NULL look. README check steps 1–4 cover them.
- **The button check before the press:** whether another list hides Work-in-Progress's Add new (`IsWindowVisible` false). If it doesn't, the title look still refuses.

---

# Validation — v2.6.7 — 28 October 2026

## Basis

- **The ask.** Tommy, 28 Oct 15:11: "if I'm trying to access it through phone but the pc is opening a repair order, close that repair order so I can access it on the phone".
  - Before 2.6.7, a phone request waited while any Repair Order was open in COSTAR Tempe. The helper said "A Repair Order is open … close it (or finish the phone job waiting for review) first".
  - The phone offered a close only for the Repair Order that same phone had left open.
- 15:34: "change all idle time to 3 seconds", "by all I mean when its waiting for costar to be ready".
- **What an open Repair Order in COSTAR Tempe can be:**
  - one the Repair Order helper left open after a stop (its journal's `leftOpen`);
  - one COSTAR opened late, after an open had stopped (13:38 on 28 Oct);
  - one a person opened at the PC;
  - a phone job's, waiting for review (`WorkerEngine`'s checkpoint window);
  - an online order's, left for review or stopped in. The Online orders tab tracks these in `lastFilledWindow` and `stoppedIn`, which are lost on a restart; their PO# is TTW….

## Changes

- **`RoEngine.Free`:** when the only thing in the way is open Repair Order windows in COSTAR Tempe, `CloseFirst` decides. The helper then reports "ready: Repair Order … is open there and will be closed first", and the desk hands out the request. Otherwise it waits and the phone is told why.
- **`KeepOpen`** (what stays open, first reason first):
  1. held for review (`HeldForReview`: the phone job's pinned window, and the Online orders tab's windows);
  2. COSTAR asking something on it (`Runner.CloseBlocker`);
  3. someone used the PC in the last `CloseQuietSeconds` (3 s);
  4. its PO# couldn't be read;
  5. its PO# is an online order number (`^TTW\d{4,}$`).
  - The first three need no reading of the window.
- **`RoPeek.Read`:**
  - asks WM_NULL first (250 ms) and reads nothing when it isn't answered;
  - reads the words of the STATIC labels only, and stops at the first failed read;
  - then reads only the box beside the "RepairOrder" label (`Runner.NumberBox`) and the box under "PO#" (`Selectors.Under`).
  - Kept a minute per window; a failed read is tried again. Nothing read is logged, except an online order number in the phone's message.
- **`CloseOpenFirst`** runs right before `RoWip.Open` for open, change and print requests.
  - Each open Repair Order is looked at again: nothing held, nothing asked, nobody at the PC, PO# read.
  - The phone is told at once: "Closing Repair Order …, which was open in COSTAR Tempe, before opening Repair Order …".
  - Then `CloseWindow` runs: the `CloseBlocker` guard, WM_CLOSE, and a wait of up to 8 s. One that doesn't close stops the request, and nothing is answered.
  - The day log gets `ro_close_first`. `leftOpen` is cleared when it was that window.
  - The result starts with "Closed RO … first (it was open in COSTAR Tempe)."
- **`HeldForReview`** is set by the RDP helper's window, from `WorkerEngine.PinnedWindow` and `AutofillForm.HeldWindows`. When it's null, nothing is closed (as in 2.6.6).
- **Waits for a quiet PC:** `RoEngine.QuietSeconds` and `EbayEngine.QuietSeconds` are 3 s (10 s before); `CloseQuietSeconds` is 3 s. The checks during an open or a print (`RoWip.Quiet`, Print's last look) are unchanged.
- Version: 2.6.7 - Open RO closed first.

## Review

The independent review agent started on the first draft (`ebae527`) didn't report back: the session restarted while it ran. A self-review of the final diff covered the questions it was given:

- **What can be closed.**
  - Held for review: a phone job's pinned window, the Online orders tab's windows, and any PO# that is an online order number (for after a restart). These stay open, and so does one with a COSTAR question on it.
  - One the helper left open after a stopped change is closed (its typed words stay in it; the README says to open it on the phone to check).
  - A person's Repair Order is closed after 3 s without input, as Tommy chose.
- **Races.**
  - `Free` (its 3 s cache) only lets the desk hand the request out. `CloseOpenFirst` looks at every window again right before closing it.
  - The loop doesn't call `Free` while a request runs. `peeked` and `leftOpen` change only under the engine's gate, and `HeldForReview` is called outside it.
- **COSTAR's load.**
  - `RoPeek` reads nothing without an answer to WM_NULL within 250 ms, stops at the first failed read, and reads labels plus two boxes.
  - It reads only when nothing is held or asked and nobody is at the PC, and each read is kept a minute.
- **Phone and desk.**
  - The new waiting texts still start with "A Repair Order is open in COSTAR Tempe". The phone's offer to close the one it left open still works (a `close` request), and no website change is needed.
- **Fixed in this pass:** the Work-in-Progress search rule's comment had ended up above `RoPeek`; it's back in place.

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **133 of 137** helper groups and 16 of 16 Order Check. The same 4 Windows-only groups fail here by design.
  - New group "A Repair Order left open in COSTAR closed first for the phone (2.6.7)":
    - what stays open and why, first reason first;
    - an online order's PO# in either case, and only a real one;
    - a PO# that couldn't be read;
    - the number and PO# read from a made-up Repair Order, with the label missing, the PO# missing, and a box that isn't a number.
- Mutations, each of which fails the self-tests:
  - held closed;
  - an online order's closed;
  - an unread PO# closed;
  - closed while someone uses the PC;
  - any text taken as the number;
  - and five of the earlier ones.
- End-to-end on this build: Repair Orders 96, Job Card 19. Node tests: startup 9, Job Card 47, Repair Orders 10.
- Install replayed with the Updater code the PCs run, from 2.6.6. The upload set was scanned for secrets and customer data.

## Not verified here (no Windows or COSTAR here)

- **WM_CLOSE on a Repair Order a person opened.** COSTAR keeps it in Work-in-Progress; the helper's own closes have done that since 2.6.0. Check TEST-PLAN 2.6.7, step 2.
- **`RoPeek` on the real window:** whether the RepairOrder label and the PO# box are found. The `ro_close_first` lines should name the Repair Order.
- **The 3 s waits on the real PC.**

---

# Validation — v2.6.6 — 28 October 2026

## Basis

- Diagnostics of 28 Oct 14:05 (2.6.5 installed at 12:44). Seven Repair Order runs on 2.6.5; six completed.
- **The stop that 2.6.5 caused.** The run at 13:28, a car change with a print, stopped at stage "Car" with "The field lost focus before validation." Its events:
  - REGO NO note: `memo_focus` ok in 62 ms (2.6.5's direct try). Written, key pressed and taken back, Tab, read back ok.
  - ODOMETER note: `memo_focus` ok in 57 ms (direct). Written; "A" and Backspace taken, the note box checked as holding the keyboard before each.
  - Then `CommitField` found the keyboard elsewhere before Tab. No `direct_slow`, no `direct_fallback`, and nobody was marked at the PC.
- **History of the click.** Before 2.6.5, all 317 `memo_focus` waits were "ok" on the first try with the mouse, with no retries; 408 note read-backs were ok; no note commit ever lost the keyboard. 2.6.5's direct try reached 2 note lines and lost 1.
- **The item grid moves the keyboard by itself.** This was already known from earlier runs:
  - `leave_grid` needed three tries 8 times after notes;
  - 10 Oct: a click closes the line that had the keyboard, and the lines below it move up (RequireLineStill).
- **Other stops in the same report:**
  - "COSTAR did not accept customer phone": 3 on 28 Oct (2.6.2 and 2.6.4), 8 in all since 12 Oct. Every one came 1.54–1.65 s into the stage: a click, then WM_SETTEXT's 1.5 s limit running out, with COSTAR busy for 1.6–1.9 s (the probe). Writes 0. In runs that went through, WM_SETTEXT on the phone took up to 1.46 s.
  - "The field lost focus before validation" after an item loaded, with the mouse: 28 Oct 08:16 (the freight charge, 2.6.2), 25 Oct (an eBay quantity), 14 Oct (a quantity), 6 Oct (a phone job's quantity). Each came 0.1–0.2 s after the item finished loading. In two of them the grid's labels moved while it loaded (`grid_read_plan_reset`).
- **Not changed (they work as designed):**
  - 13:06 and 13:10: a document from Order Check's copy wasn't in COSTAR Tempe's Work-in-Progress list (15 rows showing at 13:06; 126 at 13:10, every cell read). Nothing was opened.
  - 13:38: "Someone used the COSTAR PC", 12 s into an open while COSTAR was still opening the Repair Order. 2.6.6 logs what was seen.
  - 13:49 (twice): COSTAR wasn't showing Work-in-Progress.
  - 12:45: seven day-log lines from the update's own self-tests (made-up lists). 2.6.6 mutes them.

## Changes

- **Item lines clicked (Runner):**
  - `Focus(c, grid)` and `Put(…, grid)`: a box of the item lines is clicked; 2.6.4's path is unchanged (ClickTarget, then up to 2 s for the box to have the keyboard).
  - Call sites:
    - `AddCode` and `RequireLineStill` (the item code);
    - `FinishLine` (quantity through `PutQuantity`, net price);
    - `FinishFreight` (quantity, list price);
    - `RoCell` (a line's quantity or price);
    - `RoAddItem` (a new item's quantity and price);
    - `RoRemove` (the item code, before Delete).
  - `FocusMemo` is 2.6.4's code again, identical by diff apart from a comment.
- **Leaving the item lines is a click (`ClickOnly`):**
  - A box gets the keyboard directly only when it isn't under the item lines' panel (`gridPanel`, which GridCurrent reads, the panel itself included) and the keyboard isn't in that panel now. Otherwise it's clicked, and `direct_skipped` says why ("a box of the item lines" / "leaving the item lines").
  - It's decided after `WaitIdle` and the box's checks, right before the press.
  - With no box holding the keyboard after this run has clicked into the item lines, it clicks.
  - If no read of the item lines has found the panel yet, the panel is looked for once per run (a phone job resumed with the keyboard still in a line from before).
  - Applies in `FocusDirect`, `FocusOrClick` and `PressTick` (Customer Waiting on the Repair Order).
  - So `LeaveGrid`, DET's leave (`LeaveForDetNotes`), and the first box at the top, Ship Via, Date In or Customer Waiting after line work are clicked, as in 2.6.4. Moves from one box at the top to another stay direct.
- **Words given time (WriteFocused):**
  - WM_SETTEXT may take 5 s (it was 1.5 s), and so may EM_SETMODIFY (it was 0.5 s).
  - On a time-out (ERROR_TIMEOUT), COSTAR is waited for (up to 8 s idle) and the box read. Words that are there count as taken (`write_late`).
  - Otherwise the stop says "COSTAR didn't confirm … within 13 s (it may still take it)".
  - A box that doesn't have the keyboard before its words now stops as "lost focus before its words went in" (`focus_failed`), no longer as "read-only or protected". A note that loses it before its key press is `focus_failed` too (it was "other").
- **Clicked once more (CommitField, FocusAgain):**
  - Applies to a quantity, price or note box of the item lines, when the keyboard isn't on it at Tab.
  - Conditions: the same box (CheckTarget), still showing exactly what was written (Order.Clean), COSTAR's Repair Order in front (Check), and nobody at the PC in the last 3 s.
  - Then `Focus(c, grid)` clicks it and COSTAR is waited for: idle, then 250 ms that the box must hold the keyboard through. The keyboard and the words are checked again, EM_SETMODIFY is sent again, and Tab follows.
  - A note line gets its key press again (`PressAtEnd`) before Tab, because COSTAR keeps a note only after one (25 Oct).
  - It happens once; a second loss stops as before. Not used for item codes (COSTAR looks those up on Tab) or for the boxes at the top.
- **Diagnostics:**
  - `Holds(h, step)` in WriteFocused, CommitField, PressAtEnd, KeyInto, RoKey and CursorAtEnd: a `focus_lost` event with the box that should have had the keyboard and the one that did (kind, handle, place: no words), COSTAR in front or not, someone at the PC or not, and the last input (`LastInputSeen`).
  - When an open stops for someone at the PC: `ro_user_active` in the day log (Quiet, and Activate's last look).
  - When a print stops for someone at the PC: `user_active` in the run (its first look, each click's look, Print's last look).
  - `LastInputSeen` never throws.
- `AppLog.Off` is set by `--self-test`; `AppLog.Skipped` counts the notes left out.
- Version: 2.6.6 - Item lines clicked.

## Review

An independent review of the drafts (`bb4f6c7`, `4f337b0`) found nothing that types into the wrong box or loses an order, and no remaining path where a box of the item lines gets the keyboard directly. What was done with each finding:

1. **The click before Tab on a note line had no key press after it.** Reading the words back doesn't prove COSTAR keeps them (25 Oct). A note clicked again now gets its key press again (`PressAtEnd`) before Tab.
2. **Leaving the item lines was still a direct press.**
   - PO# given the keyboard directly in `LeaveGrid` and `LeaveForDetNotes` could hold it while COSTAR never left its line. `LeaveGrid` would accept that, and DET's notes would wait 12 s and stop.
   - The same applied to the first box at the top after line work.
   - Fixed with `ClickOnly`: every move out of the item lines is a click.
3. **Two keyboard checks didn't log where the keyboard went** (`WriteFocused`, `CursorAtEnd`), and one called a lost keyboard "read-only". Both now use `Holds`, with their own wording.
4. **The self-test read the live day log**, which could fail on a sharing violation and block an update, and it didn't test the `--self-test` wiring. It now checks the wiring and a counter, and reads no files.
5. **The "someone at the PC" logs were incomplete.** `LastInputSeen` was added to `focus_lost` and to Activate's refusal, and the print path's refusals now log it too.
6. **Rough edges in the slower write:** EM_SETMODIFY got 5 s as well, and the 13 s stop says COSTAR may still take the words. A Stop can now wait up to 5 s inside a write.
7. **Docs.**

### Second review (`7b9b4d8`)

No blocking problems, and nothing worse than 2.6.4 for online orders, eBay orders or phone jobs in a way it could show. Done:

1. **`ClickOnly` could choose direct in edge cases:**
   - it was decided before COSTAR was idle;
   - no box holding the keyboard;
   - the grid panel itself holding it;
   - the panel not known yet, on a resumed phone job.
   It's now decided after `WaitIdle` and the box's checks. The panel itself counts, the panel is looked for once per run, and with no keyboard owner after line work it clicks.
2. **`FocusAgain` didn't wait for COSTAR to settle.** It now waits for COSTAR to go idle, then 250 ms, and the box must hold the keyboard through that before the key press or Tab.
3. **Comments; two stop wordings mapped to `focus_failed`.**

Its answers:
- The helper never leaves the keyboard in the item lines without having read them (`gridPanel` set).
- Nothing leaves the lines with an edit pending except through `ClickOnly`. Print, Add New, the print form and the line menu are unchanged from 2.6.4 there.
- `LeaveGrid` clicks on every try while the keyboard is in the lines.

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **132 of 136** helper groups and 16 of 16 Order Check. The same 4 Windows-only groups fail here by design.
  - New group "The day log (2.6.6)":
    - the `--self-test` run has the day log off;
    - a note while off is left out (`AppLog.Skipped`);
    - the new stop wordings fall into the right categories.
- Mutations, each of which fails the self-tests:
  - the 12 of 2.6.5;
  - the day log left on in the self-tests;
  - the new stop category removed.
- End-to-end on this build: Repair Orders 96, Job Card 19. Node tests: startup 9, Job Card 47, Repair Orders 10.
- `FocusMemo` compared with 2.6.4 by diff: identical apart from comments.
- Install replayed with the Updater code the PCs run, from 2.6.5. The upload set was scanned for secrets and customer data, including the Repair Order and document numbers of the 28 Oct report.

## Not verified here (no Windows or COSTAR here)

- **The click path into the item lines** is 2.6.4's, unchanged. Its record on COSTAR is the real PC's history: 317 note lines, and the item lines of every order before 2.6.5. The first car change on 2.6.6 is the check (TEST-PLAN 2.6.6, step 2).
- **New behaviour that runs only on Windows and COSTAR:**
  - leaving the item lines by a click (`direct_skipped` "leaving the item lines");
  - the 5 s write and the late read (`write_late`);
  - the click before Tab (`focus_again`; for a note, close and reopen to check it was kept: TEST-PLAN 2.6.6, step 8).
- **The flows that haven't run on 2.6.5 or 2.6.6 yet** (online orders, eBay orders, phone jobs) are the supervised checks in TEST-PLAN 2.6.6.

---

# Validation — v2.6.5 — 28 October 2026

## Basis

- Tommy, 28 Oct 08:29: "it's working, but it looks like its clicking instead of like native, how can I help to make it better? do you want to map it first?". 10:09: the 2.6.4 maps of seven screens arrived; they are saved as `claude/10-COSTAR-Map-Notes.md` and `claude/10-COSTAR-Map-Data-2026-10-28.txt`. 10:28: "full gas no brakes sir".
- What the maps showed (2.6.4):
  - COSTAR 5.7 is WinForms. Its buttons and tick boxes are owner-drawn BUTTON windows. They take BM_CLICK, which the helper has used for Search, Cancel and Yes since 2.x.
  - The Repair Order's toolbar is a ToolStrip. Its buttons exist only for accessibility (Back, Close, New, Print Alt+P, Sell Alt+L next to it, Schedule, Delete, PIN, History, Branch, E-Mail, Inspections), each with the action "Press".
  - Customer Waiting and the print form's ticks are tick boxes ("Check" / "Uncheck").
  - Ship to / Rebill to / Contacts / Notes are a SysTabControl32 ("Switch").
  - Work-in-Progress and the search results are Infragistics UltraGrid. Every row offers "Activate" except the active row (the one Enter opens), which is marked focused only while the grid has the keyboard. No row was selected when the maps were taken.
  - The line menu has Delete, Delete (Lost Sale), Select Line, Cut Line(s), Paste Line(s) and Deselect Line(s).
- Where 2.6.4 used the mouse:
  - the click into each box, in every kind of order (`covered` 18 times in the last runs);
  - Customer Waiting; Print; the print form's ticks and OK / Cancel;
  - eBay's tabs (`tab_switch` "click" 86 times);
  - Add New;
  - Work-in-Progress (wheel, click, double click);
  - the line menu (right click, then a click on Delete);
  - the customer list's row (after accessibility's selection, rarely).

## Changes

- **`Direct` (new, Direct.cs):**
  - `On`: setting `directPresses`, default on.
  - `Focus(h, ms, cancelled)`: Windows' SetFocus from COSTAR's own input queue, joined for that moment (AttachThreadInput, on a thread of its own). The wait ends at `ms` or at a Stop.
  - `Press(h)`: BM_CLICK sent, with SendMessageTimeout 1.5 s. Returns 1 when answered, 0 when not yet answered (it may still go), -1 when not sent.
  - `AfterPress`: what follows a tick press.
    - "done": the tick shows what's wanted.
    - "click": COSTAR answered and the tick reads unchanged, so one real click may follow.
    - "leave": unanswered or unreadable, so nothing more is pressed.
  - `PressLater(h)`: BM_CLICK posted.
  - `ShowTab(strip, i)`: TCM_SETCURFOCUS, which tells COSTAR the same as a click on the tab.
  - `Act(find, gate)` / `Went`: an accessibility default action, found and made on a thread of its own.
    - States are looking / pressed / given up. A press given up is never made late; a failed press is never followed by another.
    - `gate` is the last look, taken on that thread right before the press. If it says no, nothing is pressed and the reason is kept in its own field (`Refused`), so a time limit running out at the same moment can't write over it.
- **Boxes (Runner):**
  - `Focus`: `FocusDirect` gives the keyboard directly (3 s at most, ends at a Stop) and checks for 0.8 s that the box has it. Otherwise one click, with 2.6.4's checks.
  - `FocusOrClick` (leaving the item lines on tries 1–2; a note line's first try): the keyboard given directly with a 0.6 s wait at most. Like a click, it doesn't wait for COSTAR to finish with the box it leaves; the caller then looks where the keyboard is.
    - Leaving the item lines clicks from try 3.
    - A note line gets one direct try, then 2.6.4's three tries with the mouse.
  - Words still go in with WM_SETTEXT. Tab, Enter, Escape, Delete and the note's letter stay real keys.
  - As before, the cursor is put and checked at the end of the text before any key that could change it (the note's letter, Delete).
- **Customer Waiting and the print form's ticks (`PressTick`):**
  1. COSTAR must be in front and enabled, and the box must still be the same box (process, visible, enabled, window, parent, class), as the click checked. On the print form, nobody may be at the PC.
  2. The box gets the keyboard first, as a click gives it. The value is then taken in when the box is left, or when OK validates it.
  3. BM_CLICK, then the tick is read back (`AfterPress`).
  - Customer Waiting is then checked for 3 s as before. On the print form, "leave" cancels the form.
- **Print (`PressPrint`):**
  - A Print button window gets BM_CLICK posted.
  - COSTAR's drawn toolbar: the object at Print's place (where the click aims) is pressed through accessibility on its own thread. It must be named Print, with a button role, and not greyed.
  - Last look, right before the press: the Repair Order in front and enabled, and nobody at the PC for 1.5 s. If it says no (`Refused`), nothing is pressed and the helper stops, saying why.
  - Not found within 5 s: given up (never pressed late), then one click as before.
  - A press that went is never followed by a click. One that failed stops as "may have printed".
  - If the print form isn't open within 15 s while COSTAR is still on the press: "may have printed", so a phone retry can't print twice.
  - Every "may have printed" reaches the phone as that, never as "not printed … Print it at the PC". This also fixes 2.6.2's wording for a print form that closed at the PC before it came in front.
- **The print form's OK and Cancel:** BM_CLICK posted. `printOk` is set before, as for the click. A click only if the post failed and the button is still there under the point.
- **Work-in-Progress (`RoWip.OpenDirect`, `SelectForEnter`):**
  1. The row is selected through accessibility.
  2. Its "Activate" is pressed, but only while the row offers it: a selection can already make it the active row, which offers nothing to press. The row is looked up afresh among the list's children and must still be that Repair Order. The press is on its own thread, with a last look right before it: COSTAR's main window in front and enabled, nobody at the PC for 1.5 s.
     - If the last look says no, the open stops there, as for any step with someone at the PC. Someone at the PC is marked, so a window that opens meanwhile is never taken for the helper's.
  3. The list gets the keyboard directly.
  4. A read with new objects must show, with the list holding the keyboard:
     - the row is still that Repair Order;
     - it is COSTAR's active row: marked focused, or the only row offering no "Activate" while the others offer it;
     - it is the only selected or focused row.
  5. The same is looked at once more right before Enter, which goes with 2.6.1's checks.
  - Nothing opened: the 2.6.1 way.
  - This path no longer passes on `selected`. The opened Repair Order must match by its number, or by its name, comment, PO# and total all as listed.
- **eBay tabs:** TCM_SETCURFOCUS on the tab's place, checked by the page showing. The tab count is asked only on this path. Then the click, then Ctrl+Tab, as before.
- **Add New:** BM_CLICK (as when an open order covered it), never followed by a click.
- **Customer Not found:** its one button (OK) gets BM_CLICK. Escape follows only when COSTAR answered and the notice stayed; an unanswered OK stops.
- **Not changed:**
  - Taking a Repair Order line out works as in 2.6.4: the Delete key, then the right-click menu. The setting doesn't touch it. The review below showed that the menu's Delete may act on lines selected before.
  - The customer list's row.
  - The 2.6.1 mouse way in Work-in-Progress, now the fallback.
- **Desk window:** Files & settings has "Press COSTAR's buttons, ticks, tabs and boxes directly" (ticked). Off means 2.6.4 everywhere. Each press decision reads the setting once, so nothing is pressed directly and then clicked because the setting was switched in between.
- **Diagnostics:**
  - `Presses` is counted per stage.
  - Events: `direct_fallback`, `direct_slow`, `print_press`, `ro_open_direct`.
  - `ro_open_ok` says "row made the active row directly … opened without the mouse (Enter)"; `tab_switch` says "direct".
  - `memo_focus` says "ok" when the first try (the direct one) took.

## Review

An independent review of the first draft found 5 important and 7 minor items. Nothing was pressed twice. What was done with each:

1. **Accessibility presses fired seconds after their last check.** `Act` now takes its last look on the press thread right before the press. Print is pressed at its place (no search of the window). The last look is: in front and free, nobody at the PC.
2. **The line menu's Delete was new destructive behaviour, and which line it acts on was unverified.** Reverted: the line menu works exactly as in 2.6.4.
3. **The line menu with the setting off didn't behave as in 2.6.4.** Fixed by the same revert.
4. **BM_CLICK on a tick box isn't a click, and nobody had checked that COSTAR keeps it.** The box now gets the keyboard first. Two first checks at the PC are in TEST-PLAN: Customer Waiting kept after close and reopen, and one supervised Job Card print.
5. **Enter opens the active row, not the selected one.** The row is now made the active one and required to be it, and the only selected one. This is checked again right before Enter, and `selected` isn't passed on.
6. **A failed tick read led to a second press.** Now no second press ("leave"). PressTick also makes the click's in-front, enabled and identity checks.
7. **The setting was read several times in one operation.** Now read once per operation.
8. **Slow focus.**
   - Focus changes end at a Stop.
   - The tries that loop wait 0.6 s.
   - The note line keeps all three mouse tries.
   - Select-all on the first direct focus is harmless: words go in with WM_SETTEXT, and the cursor is put and checked at the end before any key.
   - Still possible: a focus change that COSTAR holds up with a message of its own completes once the message is answered. The keyboard then goes to that box; nothing is typed.
9. **A press still waiting to land was reported "not printed".** Now "may have printed".
10. **A late menu.** Gone with the revert.
11. **Small things:**
    - `DefaultAction` removed, along with the now-unused `FindOne` and `OpenMenu`.
    - A late finder can't overwrite the reason.
    - Seconds are shown with one decimal.
    - The tab count is asked only when the tab is shown directly.
    - Each press's wait handle is left to the garbage collector: a handful a day, and its thread may still set it.
12. **Test gaps.** The made-up list now keeps selected and active apart. New tests:
    - Activate ignored; another row active (marked, and told only by its action); nothing tells which row is active.
    - The last look saying no; the list sorted again before Activate.
    - The press's last look taken once, after the finding.
    - What follows a tick pressed directly.

### Second review (of the fixes)

No critical or important findings, and no path that prints twice, opens or types into the wrong Repair Order, or toggles a tick twice. Its four minor items are done:

1. **The last look's no before Activate went on to the mouse way**, which only stopped at its next look. It now stops the open at once, and someone at the PC is marked.
2. **Two new "may have printed" cases reached the phone as "not printed … Print it at the PC".** Now "may have printed … check the printer".
3. **A 5 s limit running out could write over the last look's reason**, turning a stop into a click (still safe, because the click looks again). The reason is now kept in its own field, and the time limit never replaces a reason already given.
4. **Logs and docs:** the note line's day log counts the direct try as the first try; this page's wording on the setting.

Its note on things that can't be checked here: if the selection already makes the row active, the row offers no "Activate", and pressing it might fail and send every open the mouse way. The press is now skipped when the row offers nothing.

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **131 of 135** helper groups and 16 of 16 Order Check. The same 4 Windows-only groups fail here by design.
  - New group "Direct presses (2.6.5)": a Repair Order opened from a made-up Work-in-Progress list with no click and no wheel. The made-up list keeps selected and active apart, as COSTAR's does.
  - The open goes to the mouse way when:
    - the list won't keep the keyboard;
    - another row stays selected or active;
    - nothing tells which row is active;
    - the list was sorted again before Activate.
  - The open stops when the last look before Activate sees someone at the PC, or COSTAR's main window not in front and free.
  - A selection that already makes the row the active one: no Activate pressed, then Enter.
  - Accessibility presses: never made late, never twice, never past a last look that says no; a failed press is "failed".
  - What follows a tick pressed directly.
- 12 mutations of the new code, each of which fails the self-tests:
  - a press made late;
  - a failed press taken as pressed;
  - the last look ignored;
  - an unanswered tick press followed by a click;
  - another selected row allowed;
  - the active row not required;
  - no Activate;
  - other rows' actions not read;
  - a fresh row of another Repair Order accepted;
  - the list not given the keyboard;
  - Activate pressed on a row that is already active;
  - the last look's no not stopping the open.
- End-to-end on this build: Repair Orders 96, Job Card 19. Node tests: startup 9, Job Card 47, Repair Orders 10.
- Install replayed with the Updater code the PCs run, from 2.6.4. The upload set was scanned for secrets and customer data.

## Not verified here (no Windows or COSTAR here)

- Everything that talks to COSTAR directly runs only on Windows:
  - SetFocus through joined input;
  - BM_CLICK on COSTAR's tick boxes and buttons;
  - the toolbar's Print through accessibility;
  - TCM_SETCURFOCUS;
  - the Work-in-Progress row's Activate and Enter.
- Whether COSTAR keeps a tick pressed directly is the first check at the PC (TEST-PLAN 2.6.5, steps 2–3): Customer Waiting after close and reopen, and the print form printing only the Job Card.
- Every path checks its result. Where a second try can't do harm, it falls back to the 2.6.4 mouse way. The switch turns it all off.

---

# Validation — v2.6.4 — 28 October 2026

## Basis

- Tommy, 28 Oct 09:09, with the diagnostics ZIP holding five 2.6.3 maps (09:04–09:08): "I dont know if this reads the repair order screen".
- What the maps showed. **Repair Order window:** Windows' view complete (about 300 controls: the Arrived / EstComplete / Parts Req. / In Shop / CustWaiting / Completed owner-drawn buttons, TaxIn, Check stock..., Next #, National / Rebill Accounts..., the Ship to / Rebill to / Contacts / Notes tabs, a "Toolbar" panel, 25 line panels with their boxes and a button each). Accessibility cut at 2,500 objects, 2,321 of them hidden: 2,046 were child windows' title, menu and scroll bars, size grips and their buttons; the toolbar and the lines were never reached. **The line's right-click menu** (a WinForms menu window): 11 items, each "Press". **Maps 2–4:** no COSTAR window in front (5 s too short over Remote Desktop); no map has the print form or the customer search window. **Every map** read all three COSTARs in the session (Tempe twice, Sydney): about 26 s each.

## Changes

- **`CostarMap` walk:** the state is asked first; an object below the window with STATE_SYSTEM_INVISIBLE is counted (`accessibleHidden`), not kept, and nothing under it is asked. Windows' frame parts that show (title bar, scroll bar, size grip, scroll thumb, the "System" menu bar) are kept with `frame: true` but not opened. The first-8-and-last-2 sample applies only to real lists (table, list, outline); other containers are read whole (≤ 2,000 children). Per window: 5,000 kept / 20,000 asked objects, 40 s; per map 100 s.
- **Which windows:** the COSTAR process of the window in front (else of the one on top) is read, up to 12 of its windows; other COSTARs' windows (and this one's past 12) are listed only (`listedOnly`: caption, class, place). Schema `tempe.costar-map.v2` (`costar`, `listedOnly`, `frame`, `accessibleHidden`, `accessibleFrames`, `accessibleMs`).
- **Reader's page (`.txt`):** the same line many times once, counted ("(x30)"); a list's rows, cells and items counted under it, its headings in one line; frame parts and the everyday states "can take the keyboard" / "selectable" left out (the `.json` keeps everything).
- **RDP helper window:** countdown 10 s; **Ctrl+Alt+F9** (`RegisterHotKey` id 2, MOD_NOREPEAT where Windows has it; a log line if another program has it) maps at once and ends a countdown; refused while an entry fills COSTAR (`TryBeginRead`) or a map runs; a sound when saved (Asterisk) or not taken / failed (Exclamation); the watchdog lets entries go on after 2.5 minutes; the hint under the Mobile jobs log mentions Ctrl+Alt+F9.

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **130 of 134** helper groups + 16 of 16 Order Check (the same 4 Windows-only groups fail here by design). New: a made-up Repair Order window as accessibility shows it (124 boxes, each with hidden title, menu and scroll bars and a grip; a tab page behind another; the toolbar last): the toolbar reached within 2.6.3's budget; each hidden part asked its state only, nothing under it asked; the title bar, system menu and grip kept but not opened; nothing pressed, selected or changed; box values as their length; the reader's page (toolbar buttons with keys and states, tabs, the same button once and counted, no frame parts or everyday states, another COSTAR listed); which windows are read and listed. The 2.6.3 map test now also checks the headings line and the counted rows and cells.
- 8 mutations of the new code (hidden parts read, role asked before the state, frame parts opened, every container sampled, other COSTARs read, repeats not counted, everyday states shown, frame parts on the page): each one fails the self-tests.
- Replayed on Tommy's 09:08 map: of the 2,500 objects 2.6.3 read in the Repair Order window, 2.6.4 keeps 100 and asks 301 hidden ones a single question (the other 2,099 are under them), so the same budget now goes on through the window.
- Node tests (startup 9, Job Card 47, Repair Orders 10); install replayed with the Updater code the PCs run; the upload set scanned for secrets and customer data.

## Not verified here (no Windows or COSTAR here)

- The map on the real COSTAR: whether COSTAR's "Toolbar" shows its buttons to accessibility (a WinForms ToolStrip does, each with "Press"); how long a map takes now; the hotkey and the sounds on the RDP PC.

---

# Validation — v2.6.3 — 28 October 2026

## Basis

- Tommy, 28 Oct 08:29, after the first 2.6.2 prints: "it's working, but it looks like its clicking instead of like native, how can I help to make it better? do you want to map it first?"; 08:31: "tell me which other process are still manual, so we can map all together"; 08:34: "go" (to the Map button: read only, 5 s to bring the screen up, six screens).
- Still done with the real mouse or keyboard (the list sent to Tommy): the click into each box and the Tab after it (every kind of order; the words themselves go in with WM_SETTEXT), clicks and keys in the lines grid, Add New, the customer search window's first account, Customer Waiting, Print / the print form's ticks / OK, eBay's Ship to / Rebill tabs, the Work-in-Progress open (wheel, a click, the double click, Enter), taking a line out (a click on its code and Delete, or the right-click menu). Already direct: the words in boxes, every read, the Search buttons, Cancel in COSTAR's popups, Yes on "delete this line?", closing a Repair Order, all of Order Check.

## Changes

- **`CostarMap` (new, CostarMap.cs):** every visible COSTAR window (processes named COSTAR; tooltips, shadows and IME windows aside; at most 12; the one in front first). A window that doesn't answer WM_NULL within 0.5 s isn't read. Per window: its class, caption (cleaned), owner, whether it's in front or in a menu loop, the control with the keyboard; **Windows' view** (EnumChildWindows, ≤ 2000): class, kind from class and style (button, tick box, radio, group, drawn button, text box, password / read-only box, drop-down, label, tabs, toolbar, list, tree, menu, COSTAR panel), id, style, place, enabled, COSTAR's words (labels, buttons; ≤ 40 characters, cleaned) or the length of a box's text, BM_GETCHECK for tick boxes, and "press / tick (BM_CLICK)" where a button window takes it; words stop for the rest of a window that doesn't answer a read within 90 ms; **accessibility's view** (OBJID_WINDOW, depth ≤ 14, ≤ 2500 objects and 25 s a window, 90 s in all): role, name (COSTAR's own words kept; rows, cells, list items, text boxes and anything inside a table or list except its headings: their length only; emails and long numbers masked), value (length only), state in words, default action, keyboard shortcut, place, children; a list of more than 40 has its first 8 and last 2 read and its size said. Only getters are called: nothing is clicked, typed, focused, selected or set.
- **Output:** `diagnostics\maps\map-<time>.json` and a reader's page `map-<time>.txt` (per window: Windows' controls by kind, what can be pressed or ticked directly, accessibility objects with an action or keys, lists with their size and headings). **Save diagnostics** adds the last 14 days of maps (`maps/`); kept 180 days.
- **RDP helper window:** **Map COSTAR screen** under Add note; "Map in N s ..." for 5 s; then the map holds COSTAR (`EntryCoordinator.TryBeginRead`: no entry starts meanwhile; others wait with "The map (reading COSTAR) is filling COSTAR") on a background thread; the header says MAPPING, "Read only: nothing is clicked or typed"; the log says what was saved. Greyed while an entry runs. If COSTAR doesn't answer the map for 2 minutes, entries go on again (the map may still finish).

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **129 of 133** helper groups + 16 of 16 Order Check (the same 4 Windows-only groups fail here by design). New: the map's words (kept / length only / masked), kinds by class and style, states in words; the made-up Work-in-Progress list (130 rows) read through the same accessibility calls: a sample (first 8 and last 2 rows), its size and headings said, no customer name, Repair Order number or PO# in the map, nothing selected, clicked, scrolled or focused; the reader's page; the budget.
- The 2.6.2 end-to-end tests (Repair Orders 96, Job Card 19) on this build; node tests.
- Install replayed with the 2.6.2 Updater code; the upload set scanned for secrets and customer data (release script).

## Not verified here (no Windows or COSTAR here)

- The map on the real COSTAR (how long it takes; whether COSTAR's controls answer accessibility as expected). It only reads, and stops waiting after 2 minutes.

---

# Validation — v2.6.2 — 28 October 2026

## Basis

- Tommy, 27 Oct 16:24, with three screenshots (the Repair Order window, COSTAR's print form as it opens, and as he wants it): "Step to print: 1. click print on the top left 2. that form will appear, by default the invoice will be light up, but we need to adjust 3. tick print job card and untick invoice, qty stay 1, and to can be left oki, if its not possible, then keep it to default, it will also work. Step to order: 1. on ship via type in SHOP 2. and tick on CustWaiting 3. make sure date is today. … I need you to allow these options to be done while doing the order on mobile or check order from mobile, so instead of ordering straightaway for mobile order I want both options to be showing up after I click on submit to costar, I want it to give me options to tick those 2 before going ahead".
- 17:45: "I cant deploy it now, but you can start working on it". His answers: the choices on the Job Card (after SUBMIT TO COSTAR) and on Repair Orders (when saving, and a print with nothing changed); both ticked to start with.
- 2.6.1 was not uploaded yet: 2.6.2 includes it.

## Changes

- **Printing (`Runner.Print.cs`, new):** `PrintJobCard(number, beforeOk)` never throws; its `PrintResult` says what happened in words, and whether it **printed** (OK went and the form closed), **may have printed** (OK went, or the form went some other way, but the end can't be told: never said as "not printed") or was **stopped**. Before Print: nothing of COSTAR's open on the Repair Order (`CloseBlocker`), nobody at the PC for 2 s, the Repair Order in front and enabled. **Print** found by its words only: one visible, enabled push button window (accessibility role 43) "Print" on the Repair Order, else one accessible push/drop-down/split button named Print inside its rectangle (not unavailable); nobody at the PC for 1.5 s (`Quiet`); for a window button, the window under the point must be it; for a drawn toolbar, accessibility must name Print at the point. **The print form:** a new COSTAR window titled "Print RepairOrder …" that holds still 300 ms, in front and enabled, for this Repair Order (its number in the title when known, else owned by the Repair Order's window); another form is cancelled unread; a COSTAR message instead of (or with) it is quoted and never answered; 15 s at most (a form that never came in front is said, and cancelled when it can be). **Its rows** (`PrintForm.Read`): the Print, eMail and Qty headings; a row for each tick box (MSAA role 44) under Print, its one eMail box on the same line, its name the first label right of the eMail column, its quantity the one edit box under Qty (a number box's own edit box, else the one readable box there), required for the Job Card; every tick box under eMail in a row; exactly one Job Card row; one OK. **Before OK** (`PrintForm.Wrong`, after setting and reading again): the Job Card ticked to print, every other document unticked, every eMail unticked, the Job Card's quantity read and 1. One real click a box, only when it isn't as wanted, then read back (3 s); a greyed box, a window opening, or a box that doesn't change stops it. Anything not as expected before OK: **Cancel** (the form's own Cancel button, by its layout or by its words; the form brought in front only when nobody is using the PC and no COSTAR message is) and "Job Card not printed: …"; a form that can't be cancelled is left for a person and said; a form that went without the helper's Cancel "may have printed". **OK:** once its click may have gone, nothing more is clicked. **After OK:** up to 30 s for the form to close; a COSTAR message meanwhile (with or after the form) is quoted, never answered, and the end is "may have printed".
- **Phone jobs (`MobileRunner`):** `MobileJob.options {order, printJobCard}` (no options: ordered, not printed, as 2.5.3). After the final check: if ordering, Ship Via SHOP and Repair Date today (`RepairDateToday`: read; typed only in an edit/combo box when not today); if printing, the Job Card (`MobileCheckpoint.print`: `started` just before OK or when it may have printed, `done` after; a resumed job never prints again); if ordering, Customer Waiting last (not after a Stop during the print; then COSTAR isn't brought in front either). None of it stops the job (the report dump included); `JobNotes` go with READY FOR REVIEW (`OrderNote`, the print's words). The RO's number for the form check is read beside its RepairOrder label (`ShownNumber`, ≥ 4 digits) or left out.
- **Repair Orders (`RoWorker`, `RoModel`):** kind `print` (open, read, print, close; nothing typed; a second print of the same Repair Order joins the first; surely not printed → `failed`, may have printed → `done` with those words; not done at all within 2 minutes of one that went); `RoEdit.print` (after the change is in and checked, before the close; part of the content hash; not a change alone). `RoAttempt.printing` just before OK (a helper closed after it says "may have printed"); after a Stop in the print the Repair Order isn't closed; an error after the print keeps its words. The desk's time-out and restart words for prints say "may have printed".
- **Versions out of step:** hellos say what the RDP helper does (`WorkerHello.jobOptions`, `RoHello.print`); health has `jobOptions` and `roPrint`, `/ro/list` `helper.print`. The desk never hands (or hands again) a print, or a job whose choices an older helper would ignore, to a helper that doesn't say it does them: it fails with nothing done and says why.
- **Job Card page:** SUBMIT TO COSTAR → `choices` dialog (Order, Print the Job Card; both ticked; Cancel) with a 2.6.2 RDP helper, else the old Confirm; health checked again before sending (changed meanwhile: nothing sent). The submitted card says what was chosen. RETRY can be scrolled clear of the SUBMIT bar on phones (`jobcard-bottom-space` 56 px; the page's own bottom padding is 22 px on phones).
- **Repair Orders page:** review with Order and Print ticks (both ticked each time); Order fills only what isn't so (not your own changes, not boxes the phone can't change); with nothing changed **Order / print…**; print-only requests; a save only from the open review (Try again opens it); sheet words for printing (**Check the printer** for "may have printed"); a print that joined another follows its ID; a print the desk forgot is offered only as a new print; `canPrint` follows the desk at once (a print refused because the helper doesn't print turns it off). Page assets `?v=20261027-ro4` / `-choices`.

## Independent review, round 1 (28 Oct)

A separate agent reviewed the first version (it also ran the page script against a stub to confirm finding 1). All eight are fixed:

1. **High: "Try again" after a failed save sent Order and Print without the review.** The review's ticks are page-wide and start ticked; after a reload (or another Repair Order's review) Try again sent Ship Via SHOP, Customer Waiting, today and a print the person had unticked. **Fixed:** a save goes only from the open review; Try again opens the review (as soon as the Repair Order is read). E2E: a save with both unticked, the page reloaded while it runs, it fails with nothing typed → Try again shows the review, nothing sent by itself.
2. **High: a print that may have gone could be said "not printed"** (a COSTAR message after OK with the form still showing, the form open 30 s after OK, the helper closing after OK, the desk's 90 s / restart time-outs). **Fixed:** `PrintResult {Printed, Maybe, Stopped}`; `Maybe` once OK was clicked (or the form went some other way); the Repair Order attempt notes `printing` just before OK (a restart says "may have printed"); the desk's time-out words for prints say so; a print-only request that may have printed ends `done`, never "not printed"; the phone shows **Check the printer**. E2E for both a print alone and a change with print.
3. **Medium: a window after the new Repair Date step stopped an entered phone job** (the report dump read the Repair Order and threw). **Fixed:** the dump can't stop the job.
4. **Medium: the print form was left open when its layout couldn't be read.** **Fixed:** Cancel is then found by its words (the form brought in front first, not while a COSTAR message is); a message shown with the form is quoted, nothing pressed; a form that never comes in front within 15 s is said (and cancelled when it can be).
5. **Medium-low: the Job Card's quantity was not checked when its box wasn't identified.** **Fixed:** the Qty column and the Job Card's quantity box are required (an edit box, a number box's own edit box, or one readable box) and it must read 1; else nothing is printed.
6. **Low-medium: a tick box or radio button captioned Print could be taken for Print.** **Fixed:** accessibility roles 44/45 are never Print.
7. **Low: a Stop during the print was swallowed** and the Repair Order closed anyway. **Fixed:** after a Stop nothing more is done; the Repair Order is left open and said.
8. **Low: a print that joined another phone's print lost track after a reload.** **Fixed:** the phone follows the joined request's ID. E2E: another phone's print waiting, this phone joins, reload → followed to "Job Card printed", one Job Card.

## Independent review, round 2 (28 Oct)

A second agent reviewed the round-1 fixes and the whole print path again (reading; compiled it). It found the round-1 fixes 1, 3, 5 and 8 holding, 2, 4, 6 and 7 holding in part, and nine more points. Fixed:

1. **Medium-high: the print form (or the Repair Order) could be brought in front under someone's hands** — the new cancel-by-words path, and the Repair Order before Print after a person took the screen. **Fixed:** nothing is brought in front unless nobody has used the PC for 2 s; otherwise the form is left and said.
2. **Medium: "printed" after OK when COSTAR then showed a message** (e.g. a printer that isn't there): **now "may have printed"** (a phone job keeps it as possibly printed: no second print on a Retry).
3. **Low-medium: OK counted as clicked, then the click itself failed** and the form was cancelled with "not printed" words under a "printed" headline. **Fixed:** once OK may have gone nothing more is clicked and the words are "may have printed"; any unknown end is worded so (safety net).
4. **Low-medium: a form that closed at the PC (not by the helper) was said "cancelled / not printed".** **Fixed:** the helper's own Cancel is told from a form that went some other way: "the print form closed at the PC, not by the helper … may have printed".
5. **Low-medium (plausible): desk restart during a print, then Print again → two Job Cards.** **Fixed:** a print alone of a Repair Order whose Job Card went (or may have gone) less than 2 minutes before isn't done; the phone says why.
6. **Low: a Stop during a phone job's print** went on to Customer Waiting and brought COSTAR in front. **Fixed:** after a Stop there, nothing more is clicked or brought forward; the job is READY FOR REVIEW with what wasn't done.
7. **Low: Print matched any button window captioned Print whose role wasn't a tick box** (a group, an unreadable role). **Fixed:** only a push button (role 43).
8. **Low: the print's outcome was lost when an error came after it** (journal save), and a report dump error before OK left the form open unsaid. **Fixed:** the error path adds the print's words (or "may have printed" once OK was noted); the dump can't stop the print; any error before OK cancels the form.
9. **Low: accessibility objects read for tick boxes weren't released** (about 100 a print): released now. A request handed to the RDP helper but not taken yet is not handed again to one that no longer prints / does the choices (as for waiting ones). An unreadable quantity is said as such ("couldn't be read").

Not changed: the phone job prints its Job Card before Customer Waiting is ticked (ticking it may make COSTAR open a window, which would stop the print); if the printed Job Card should show Customer Waiting, the order can be swapped once the first jobs show what COSTAR does. Accessibility calls into COSTAR have no time-out of their own (as everywhere in the helper).

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **128 of 132** helper groups + 16 of 16 Order Check; the same 4 Windows-only groups fail here by design. New: the print form read from its labels and tick boxes as on 27 Oct, and what must be on it before OK (COSTAR's default Invoice, other documents, eMail, quantity 2 / empty / unreadable, ticks that can't be read; forms with two Job Card rows, none, no eMail or Qty column, a stray eMail box, no OK, boxes accessibility doesn't call tick boxes, no quantity box; a number box and a quantity shown as words); the print form's title and number; the number beside the RepairOrder label; the phone's choices through validation, JSON, the desk's health and hand-over and a 409 for other choices; Repair Orders print requests, joining, the fingerprint; helpers that don't print / don't do the choices (waiting and handed-over requests and jobs).
- Mutation checks: with any one of these taken out a self-test fails — the desk's print guard, the desk's choices guard, the eMail check, one Job Card row, the stray eMail box check, the quantity check, the title check, print joining.
- Phone end to end, Repair Orders (`e2e_ro.py`: the real desk receiver code over TLS, a simulated RDP helper that prints, the page in headless Chromium 390×844): **96 checks**, incl. Order / print with no change, Save and print, print alone (Order unticked or nothing left to order), both unticked, your own Ship Via kept, not printed, may have printed (alone and with a change), a print the desk forgot (Print again is a new print), a helper that stops printing after the phone looked (refused at the desk, the offer gone at once), no print offered, Try again through the review after a reload, a print joining another phone's and followed after a reload; the 2.6.0/2.6.1 checks with Order and Print ticked by default. Round-2 (2.6.0) duplicate-change scenarios A–E with Order ticked: none reproduces.
- Phone end to end, Job Card (`e2e_jobcard.py`: the real Fitment Planner page, the real desk code in Pinad mode, a simulated RDP helper's job side): **19 checks** — the two ticks, Cancel, Order unticked, both ticked, an older RDP helper (Confirm as before, no choices sent), the helper changing version while the choices are on the screen (nothing sent) and after the job was sent (stopped at the desk, said; Retry with a 2.6.2 helper enters it with its choices), RETRY reachable above the SUBMIT bar.
- Node: Repair Orders page 10, check-package, job card 47, startup 9.
- Install replayed with 2.6.0's Updater code; the upload set scanned for secrets and customer data (release script).

## Not verified here (no Windows or COSTAR here)

- COSTAR's real Print button (a button window of its own, or drawn into the toolbar), the print form's controls (labels for Print / Qty / eMail and the document names; tick boxes that accessibility calls tick boxes; the quantity box's kind), its title with the number, and what COSTAR does after OK. The helper refuses and says why when they aren't as expected (the report has `print-form-controls`, `print_form_rows`, `print_button`).
- Whether COSTAR prints a phone job's new Repair Order without asking to save it first (if it asks: not answered, said; the job is still ready for review).
- Whether ticking Customer Waiting after the print opens a window; whether the Job Card shows Customer Waiting.
- The Repair Date box of a new phone Repair Order (normally today already: then nothing is typed).
- Self-tests on Windows (.NET Framework): if a group fails there, the update is set aside and the version before starts again (send the startup report).

---

# Validation — v2.6.1 — 27 October 2026

## Basis

- Tommy, 27 Oct 13:39, with the RDP helper's report from 13:33: "it is working, but remember, I am a speed demon, and this is taking forever, like, unacceptable".
- The report (2.6.0, six Repair Order runs that afternoon): opens took 17.5, 17.0, 145.9 and 133.4 s, two saves (a car change each) 137.6 and 137.2 s. Inside those, the Repair Order itself took 2.3–4.0 s (reading it about 0.5 s, COSTAR's close 0.6–1.0 s after its own 1 s of work, the change and its check 1–2 s). The rest, 15 s to 2½ minutes, went before the Repair Order window appeared: finding its row in COSTAR Tempe's Work-in-Progress (about 130 rows). 2.6.0 pressed Search, then read every cell of every row through accessibility (about 4 s a look), again after selecting the row, after each of up to 14 scroll steps of at most 10 notches, just before the double click, and once more after it. Two opens were stopped by someone using the PC during those minutes; one by a list showing no table.
- 16:26: "dont worry about the print and the order for now, finish the speed update first" (printing the Job Card and the shop-order options are a later update).

## Changes

- **`WipScan` (new, RoWorker.cs):** one look at the list for one open: only each row's Document # cell is read (the row's own child, its name checked on the first 3 rows, every 10th and the wanted one; every cell, as 2.6.0, when that doesn't hold), the cells are kept, so where the rows are after a scroll is one call a row. Duplicates (the active row listed twice) are one line, at the place shown. Rows without a place, or placed above the bottom of the column headings (when the list says where they are), are out of view. Released when the open ends.
- **`WipScroll` and `RoWip.Reveal`:** nothing when the row is in view; else it is selected through accessibility (the list may scroll to it); else the wheel, turned only while the list itself has the keyboard (one click on a row in view gives it, at most twice; else it stops, saying what has the keyboard). One notch first, to measure how many rows a notch moves; then turns of up to 20 notches worked out to bring the row to the middle, never closer than a row to the list's end (as seen), and a single notch for the rest. **Every turn is accounted for:** the list must move by exactly notches × rows-per-notch (a single notch: any move up to its rows, as it comes whole or not at all) and then hold still for 150 ms before anything else; if it moves less within 0.8 s + 0.15 s a notch (and 1.5 s of stillness), once more with new objects, or otherwise, it stops and opens nothing. 40 turns or 30 s at most.
- **`RoWip.Aim`:** after the row is in view, first what takes time (COSTAR in front, its windows looked at, the double-click time waited out), then the last looks: when the list moved or was searched, read again with new objects and watched holding still for 200 ms; the row at its place among the list's children looked at with new objects (`FreshCheck`: still this Repair Order, at the same place; else read again once); its place read twice 150 ms apart.
- **`RoWip.Open`:** Search only when needed (`WipSearch`: the list shows nothing or not this Repair Order, Order Check's read from the last 3 minutes doesn't have it, or there's no such read and no Search in that COSTAR for 10 minutes; a filtered read proves nothing); not found after a Search: read once more with every cell. Just before the double click: no key held, nobody at the PC, COSTAR in front, the list under the point, and what accessibility finds at the point (`AccessibleObjectFromPoint`) not another Repair Order (`CheckPoint`; "can't tell" lets the looks before stand). If the double click opens nothing: the list read again, the wanted row the only selected or focused one, the list itself holding the keyboard, then Enter.
- **Identity (`Runner.OtherNumberShown`):** another number in the box beside the RepairOrder label stops it ("COSTAR opened Repair Order …, not …. Nothing was changed.").
- **Day log:** every open, change and stop says where the time went (`list read …, no Search / Search …, row in view / brought into view with N wheel turns … (N notches), at the point: this one / can't tell, COSTAR opened it in …, … in all`); the run report has the same line (`ro_wip`). `ro_wip_keyboard` when the list won't take the keyboard.
- **Shown as soon as read:** after reading (open) and after the final check (edit) the helper sends a `working` report with the Repair Order, then closes it. The phone shows it at once ("COSTAR is closing it…" in the save bar; "In COSTAR and checked" on the save sheet, with COSTAR's notes and **Done**).
- **List:** answered from Order Check's own copy when at most 3 minutes old (30 s for ↻, the phone's `fresh`), else read from COSTAR Tempe as before. Desk: `RoAsk.fresh` / `RoTask.fresh`; a fresh ask makes a waiting list read fresh; an older list never replaces a newer one (`RoQueue.Older`).
- **Phone:** status asked every 0.4 s for the first 10 s (0.9 s to 30 s, then 1.5 s). A Repair Order a read or save left open is marked (`tempe:ro-left:v1:<doc>`, 24 h); while the helper waits because a Repair Order is open, the phone names the one it left open and offers **Close RO … in COSTAR** (any open, not only that one's); the mark goes once it is closed, even if the sheet was closed first. Page assets `?v=20261027-ro3`.
- `Msaa.All`: accessibility's children call only for COM objects (COSTAR's); the self-tests' made-up list and a missing library take them one by one. `Msaa.FromPoint`, `Native.WheelStepsNow` (at most 60 single notches in one SendInput, none for 0), `Native.DoubleClickMs`; `WipSearch` on a monotonic clock.

## Independent review, round 1 (27 Oct)

A separate agent reviewed the first version and modelled COSTAR working through the wheel notches at its own pace.

1. **Medium-high: the list could be taken as settled while COSTAR was still working through queued notches** (8 of 280 opens in its model landed on another row). Fixed in round 1 by whole-list stillness; replaced in round 2 by accounted turns (below). Its model against the final code: **280 opens, 0 wrong rows, 0 stops** (average 1.6 s).
2. **Medium: skipping Search** lost a list showing no table and a row still listed for a Repair Order finished meanwhile: now `WipSearch` (above).
3. **Medium-low: the keyboard check** took a box inside the list as the list: now the list's own window must have the keyboard, waited for up to 1 s after the click.
4. **Medium-low (phone):** COSTAR's notes with the early "checked"; the left-open mark and the close offer.
5. **Low:** older lists, ↻ during a read, Order Check's filter in the note. 6. **Low:** sampled cell names. 7. **Low:** no wheel event for 0 notches; a second click waits out the double-click time.

## Independent review, round 2 (27 Oct)

A second agent reviewed the round-1 fixes, added a "burst" wheel (4 notches 12 ms apart, then a pause, COSTAR answering accessibility meanwhile) and mutated the code to see which tests notice.

1. **Medium-high: pauses partway through the notches still sent the double click to the wrong row** (gaps of 700 ms: 2 of 6 opens; 1000 ms: 3 of 6), because a new turn was worked out from a read taken while earlier notches were still on their way. **Fixed:** accounted turns (each turn must move the list by exactly its notches before anything else), turns kept a row short of the list's end, single notches whole. Its burst model against the final code, gaps 100–1400 ms, both kinds of list end: **84 opens, 74 right, 0 wrong, 10 stopped** (all 10 at 1400 ms).
2. **Medium: the tests passed for the wrong reason** (each guard alone was enough for every model the tests had). **Fixed:** the tests now have the burst wheel and assert "may stop, never another row"; with the accounting taken out they fail (row 120 instead of 102), as they do without `FreshCheck` (a list sorted again: row 51 instead of 50), without the headings check (a double click behind the headings), without the end margin, and without `CheckPoint`. The 150 ms stillness after a turn, Aim's 200 ms watch and its second look 150 ms later stay as defence in depth: no model here needs them on top of the accounting, so taking one out alone isn't noticed.
3. **Medium-low: the last look wasn't the last thing before the click** (COSTAR brought in front, its windows listed, the phone told, the double-click time waited out came after it). **Fixed:** all of that now comes before the last looks.
4. **Low-medium: a row in view was never looked at with new objects.** **Fixed:** `FreshCheck` (new objects at its place) on every path, and `CheckPoint` at the click point.
5. **Low: the Enter fallback checked less.** **Fixed:** read again, the wanted row the only selected or focused one, the list's own window holding the keyboard.
6. **Low: the identity check could accept a Repair Order showing another number** (two new $0.00 Repair Orders for one account). **Fixed:** `OtherNumberShown`.
7. **Stops on the real PC (they stop rather than misclick):** the exact keyboard test (kept: a box inside the list could take the wheel; the stop now says what has the keyboard), long turns on a slow COSTAR (now 0.8 s + 0.15 s a notch + 1.5 s of stillness, once more with new objects), failing reads (one odd place no longer moves the scroll row: the middle of all rows in view), the wall clock (now monotonic).
8. **Phone, low:** the offer named a Repair Order as if it were the open one (now: "a Repair Order is open … your phone left RO … open there"), the mark stayed if the sheet was closed first (cleared now), opening another Repair Order got no offer (now it does).

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **125 of 129** helper groups + 16 of 16 Order Check; the same 4 Windows-only groups fail here by design. Repair Order groups take about 9 s.
- Mutation checks (above): accounting, `FreshCheck`, headings, end margin and `CheckPoint` each fail a test when taken out.
- Phone end to end (`e2e_ro.py`: real desk receiver code over TLS, simulated RDP helper, the page in headless Chromium 390×844): **56 checks** pass, incl. the early snapshot, the left-open offer for the same and for another Repair Order, the close clearing the mark. Round-2 (2.6.0) duplicate-change scenarios A–E: none reproduces. Node: Repair Orders page 10, check-package, job card 43, startup 9.
- Both reviewers' models rerun against the final code (above).
- Install replayed with 2.6.0's updater code and the upload set scanned for secrets and customer data (release script).

## Not verified here (no Windows or COSTAR here)

- How COSTAR's grid answers on the real PC: a row's own child as its Document # cell, places of rows out of view, the column headings' place, rows per wheel notch, whether selecting a row scrolls the list, which window has the keyboard after the click on a row, and whether `AccessibleObjectFromPoint` names the cell under the mouse (the day log says `at the point: this one` or `can't tell`).
- The real times: expected about 3 s for a row in view and 4–6 s for one far down, of which COSTAR's own open about 2 s. The first reports will tell.
- The Repair Order window's RepairOrder label and the box beside it (from Tommy's screenshot, not read on the PC yet).
- Self-tests on Windows (.NET Framework): the made-up list runs there for the first time; if a group fails, the update is set aside and 2.6.0 starts again (send the startup report).

---

# Validation — v2.6.0 — 27 October 2026

## Basis

- Tommy, 27 Oct: "Next project is to be able to add new and open the repair order and also edit it through the phone, but with better UI UX interface, run it."
- His answers the same day: any Repair Order in Tempe's Work-in-Progress (a searchable list); change the customer details, the car and notes, products and quantities, prices, Ship Via (SHOP), Date In / Repair Date and Customer Waiting; straight in (no approval on the desk); closed again afterwards; COSTAR opens a Repair Order with a double-click on its Work-in-Progress row, or the row selected and Enter; a line is taken out with a click on its item code (not the description) and Delete, or the line's right-click menu → Delete. A new Repair Order starts on the Job Card as before.

## Changes

- **Phone page** `Website/Repair_Orders.html`, `repair-orders.js`, `repair-orders.css` (new): list (search, All / Today / This week, the helper's state), one Repair Order in four sections (Customer, Car, Lines, Job) with a save bar counting the changes, an add sheet (common codes M FB, WA, WAFR; M codes take no quantity or price), a review sheet (before → after for every change) and a progress sheet (sent → waiting → typing → checked and closed). Rules mirror the helper's. Unsaved changes are kept per Repair Order for 24 hours; a read is reused for 2 minutes. After a part-way stop: **Close it in COSTAR** / **Read it again**; after "COSTAR's copy changed": COSTAR's copy with the phone's changes on top. Customer words are only ever set as text (no HTML from data). `costar-client.js`: `roList`, `roAsk`, `roStatus` (404 → null). Links on `index.html` and `Fitment_Planner.html`.
- **Desk** `LocalHttp.cs`: `/api/mobile/v1/ro/list`, `/ro/requests`, `/ro/requests/{id}`, health fields, the helper's long-poll `/api/worker/v1/ro`; a request body up to 1 MB only for that poll with the worker key (decided from the path as the routes read it, before the body is read; 64 KB for everything else, as before). `RoModel.cs` `RoQueue` (in memory; one list read and one open per Repair Order at a time, one change or close per Repair Order, 20 waiting at most, 10 minutes to be taken, 90 s of helper silence, finished ones kept 3 hours). `RoDesk.cs` (new) + `DesktopUi.cs`: **Repair Orders** tab and **RO** chip.
- **RDP helper** `RoWorker.cs` (new): `RoWip` reads the Work-in-Progress grid through accessibility (as Order Check does), finds the row (Search, then the wheel to bring it into view), opens it with a double-click on a cell of that row, or the row selected and Enter, and waits for the Repair Order window; any other window stops it. `RoEngine`: the long-poll, when it may run (as eBay orders: switched on, nothing else typing, Online orders tab closed, Tempe selected and on Work-in-Progress with no Repair Order open, 10 s without input), list / open / edit / close, the journal `ro-journal.dat` (DPAPI) with the Repair Order left open.
- `Runner.Ro.cs` (new): the Repair Order read (`RoRead.Build`, every box, Ship Via, Date In, Customer Waiting, the filled lines with kinds, DET's three notes, fingerprint), its identity (its number shown on it, or its name, comment and PO# as in Work-in-Progress with the row selected or the same total), the change (`EditRo`: `RoEdit.Validate` against the read, every box found first, then the changes in a fixed order, each read back), line removal (`RoRemove`: click on the item code, cursor after its last letter, Delete; else the right-click menu's one Delete item; a confirmation about deleting answered Yes, any other question stops), the final check (`LeaveGrid`, read again, `RoExpect.Check`: asked boxes hold the asked values, other boxes unchanged, old lines in order with the asked changes, new lines present, nothing else) and `CloseRo` (WM_CLOSE, as Next Order).
- `Runner.Customer.cs`: Customer Waiting split into find / read / set (phone jobs unchanged). `Native.cs`: accessibility value and state, mouse double click, right click and wheel. `RoTab.cs` (new): the RDP helper's card on the Mobile jobs tab (`AppSettings.roOn`, default on).
- `RoTests.cs` (new): 9 self-test groups (reading and fingerprint; Date In formats; the change rules; the after-check incl. a line that only lost its code and the total; the questions answered, the RO number and the day log; the desk queue; the phone routes; the held poll; body sizes). `Tests/test-repair-orders.cjs` (new, Node): the page's draft on a newer read and its box rules.

## Independent review, round 1 (27 Oct)

A separate agent reviewed the new code (it reproduced the first item in a browser). What it found and what was done:

1. **High — a change could go in twice.** When the phone lost sight of a save it had sent (back, reload, a slow answer), it kept the draft and could send it again on the next read, with new lines added twice. Now a save is written down with its request ID before it is sent and followed by that ID wherever the phone goes; a reload, going back or "Lost contact → Check again" only ever asks about that ID (the same ID sent again returns its status); another save of that Repair Order waits until it ends; the result applies to that Repair Order whatever is on screen. A draft's new lines are kept on a newer read only when no save of it may have gone in part way, or COSTAR read just now still holds exactly what the draft was made on; otherwise they are left out and the phone says so. End to end: back during a save, a reload during a save, a lost answer, a part-way stop with a new line: each change in COSTAR once.
2. **High — "Nothing was changed" after typing** when the Repair Order window had gone. Now "typed" means a write was tried (counted before it goes), and the message says the Repair Order was closed while the helper was typing.
3. **A draft's line change could move to another line** after "COSTAR's copy changed". Line changes now carry what their line held (code, words, quantity, price) and follow it; one that doesn't fit exactly one line is left out and said. The review names a line to take out by its words.
4. **Right-click fallback.** Now only COSTAR's own line menu (Windows' menu window, or one that says it is a menu; not a text box's Cut / Copy / Paste menu) with exactly one enabled Delete item, clicked only while the menu is still under the point; Escape only while Windows says a menu has the keyboard (else the menu is left for a person); any other window after the right click stops. A line that only lost its code (words or price left) stops at once, and the final check fails on one; the total must stay the same when nothing priced was asked.
5. **A slow answer for one Repair Order could land on another's screen.** Every answer is checked against the Repair Order on screen.
6. **"Already changed" could miss a step that typed and then stopped.** Each step is listed as soon as it may have typed ("typed, not checked" until checked).
7. **Dialogs answered while opening.** Nothing is pressed in a COSTAR message box any more; it is read for the phone and left for a person. COSTAR's "Customer Not found" notice after a new mobile number is still dismissed, exactly as on every phone job.
8. **WM_CLOSE over a COSTAR question.** Every close (after a read, a stop, a change, from the phone) only when the Repair Order is enabled and owns no visible COSTAR window; otherwise it is left open and said.
9. **The delete question was matched loosely.** Now a box the Repair Order owns, exactly Yes and No, words about deleting this line, and none about saving, printing, invoicing, paying, closing, stock, special or back orders, all lines or the customer.
10. **A done save that didn't close** now says "In COSTAR, not closed yet" (it may be asking something at the PC), not "Saved".
11. **The RO number anywhere counted** (a comment naming another RO). Now only a label or a read-only box outside the customer boxes and the item lines.
12. **Opening from Work-in-Progress.** Real input on the PC is checked before every click, scroll and key while opening (the helper's own don't count), the click goes on the Document # cell, Enter only with no Shift/Ctrl/Alt held, no Repair Order window being built (hidden ones count) and COSTAR idle 3 s; a Repair Order window that appeared during a stopped open is closed only when nobody used the PC and it is the only one.
13. Phone rules now match the helper's (lengths, no tabs, 25 lines, locked boxes).
14. No customer words in the day log (COSTAR's words, account numbers and long numbers left out).
15. 1 MB bodies only for the keyed Repair Order poll (see Desk).
16. A Repair Order the helper had open when it was closed or restarted is remembered as left open (the phone can close it); a stopped open's window is no longer lost.
17. Closing from the phone first checks that it is still that window in that COSTAR and that nothing is open on it. 18. The list read presses Search only with no Repair Order open right now. 19. Repair Orders run only when the selected COSTAR is Tempe (Branch 11). Repair Orders stay on by default after the update (nothing happens until a phone asks). 20. Smaller page fixes (box limits set anew per Repair Order, no stale progress).

## Independent review, round 2 (27 Oct)

A second agent checked the fixes. Round 1's fixes held except where noted here; it reproduced five more ways the phone could still put a change in twice or on the wrong line, all now fixed and re-run with its own scripts (none reproduces):

1. **The draft now remembers the fingerprint its save was sent from** (replacing a flag that later reads could move or clear). Its new lines and lines taken out are kept on a newer read only while COSTAR, read just then, still has exactly that fingerprint (nothing of the save can be in), or when that same save is known to have typed nothing with the desk holding that one request throughout. The mark is cleared only by the save that set it, or by a fresh read with no save open (what is left is then only "set this to that"). So: a save the phone never saw end and only comes back to hours later (its record expired), a desk restart during a save ("Check again" now asks the desk first; "Send it again" marks the save as resent), a read that lands while a save is open, and a save sent again at once after a part-way stop: each puts its lines in once.
2. **Lines that look the same:** a line change remembers which of the identical lines it was and follows it only while there are still exactly as many of them; otherwise it is left out and said. Lines taken out are left out too when a save may have gone in part way.
3. **Editing waits while a save is open** (the form and Undo all are locked: what was sent is what goes in).
4. **The "delete this line?" answer** now needs the whole question to be one of a short list of wordings about one line ("Delete this line?", "Are you sure you want to delete this item?", "Remove the selected row?", "Delete line 3?", "This line will be deleted. Continue?" …), singular, with exactly Yes and No; plurals, linked lines, lines on order, received or reserved stop.
5. **Clicks go at once after their last check:** the menu's Delete, the right click, and the clicks, wheel, double click and Enter that open a row first wait for any held Shift/Ctrl/Alt, then look, then act with no further wait.
6. A menu's shadow window (and tooltips) no longer count as another window. A line taken out whose line changed in COSTAR is said, not dropped quietly.

## Checks performed here

- Compiled at C# 5 against .NET Framework 4.6.2, 4.7.1, 4.7.2 and 4.8 reference assemblies: **0 errors**, the 3 known warnings.
- Self-tests: **122 of 126** + **16 of 16** (the same 4 Windows-only groups fail here). Node tests of the helper (package check incl. the new page's script references, job card 43, startup 9, Repair Orders page 10, Order Check).
- End to end: this build's desk receiver code over TLS on 127.0.0.1, a simulated RDP helper on the worker route, the phone page in headless Chromium at 390×844: **43 checks** (pairing, waiting with the helper offline, list order, search and filters, open, letter limits, validation, change count, draft kept after reload, review, the exact change sent, the page after saving, "COSTAR's copy changed", a line taken out after COSTAR's lines moved, a part-way stop with a new line (the steps ticked up to where it stopped) then the close and a new read, the same draft saved again at once after a part-way stop, the account rule, the 2-minute reuse, back during a save, a reload during a save, a lost answer then Check again, a slow answer for another Repair Order, M codes, no script errors). Screens checked by eye.
- Two independent reviews by separate agents (above); round 2's five browser scenarios re-run after the fixes: none reproduces.
- Install replayed with 2.5.3's Updater code; secret and customer-data scan clean.

## Not verified here

- Everything in COSTAR (Windows only), TEST-PLAN 2.6.0: reading the Work-in-Progress grid with a cell per column caption; the double-click and Enter that open a row; whether the Repair Order shows its number (otherwise the identity check uses name, comment, PO# and the selected row); the Date In box (a text box, a drop-down or a calendar: a calendar is left for COSTAR); the Delete key and the right-click menu on an item code, and any question COSTAR asks; Customer Waiting on Repair Orders not made by the helper.
- The page on real phones (iPhone safe area, the date picker).

---

# Validation — v2.5.3 — 26 October 2026

## Basis

- Tommy, 26 Oct: "Pretty happy with the mobile jobs now, please make it so it will automatically put SHOP on the ship via and tick customer waiting. Also for the mobile website, make a button to switch easily to the job card section."
- Order Check already asks for both ("Put SHOP", "Tick Customer Waiting").

## Changes

- `Runner.Customer.cs` `SetShipViaShop(always)`: phone jobs pass `always` (SHOP for every customer); online pickups keep the customer-number rule.
- `TickCustomerWaiting`: the Repair Order's BUTTON-class controls are read for their caption ("Customer Waiting", "Cust. Waiting", a few words at most); failing that, a caption-less box beside such a label. Exactly one, or nothing is done. Its accessibility role must be a check box (44); its checked state is read (STATE_SYSTEM_CHECKED); already ticked, locked or unreadable → a log line, nothing clicked. Otherwise one real click on the box (COSTAR in front, the box where it was, nothing over it), then up to 3 s for the tick; a COSTAR window opening is left alone. Never fatal. Diagnostics `customer_waiting` (with the buttons' captions when not found; no customer data).
- `MobileRunner.cs`: after the final check, Ship Via SHOP, the report dump, then Customer Waiting (last; a Stop there leaves it by hand); stage count includes both.
- Website (also on GitHub): `index.html` Job Card button (phones, ≤768 px, where the page links are in the menu) with the card's product count; `F_alt_tab.js` `refreshJobCardSwitch` (on load, after Add Tyre, on any card change via the shared store, back from the Job Card); `allaround.css` button style, room under the results, toasts above the button. Script and style version tags `20261026-jc1`.

## Checks performed here

- Compiled at C# 5 against .NET Framework 4.6.2, 4.7.1, 4.7.2 and 4.8 reference assemblies: **0 errors**, the 3 known warnings.
- Self-tests: **113 of 117** + **16 of 16** (the same 4 Windows-only groups fail here). Node tests of the helper (package check incl. website script references, job card 43, startup 9, Order Check).
- F Alt Tab in Chromium at 390×844 (phone) and 1280×900: the button shows on the phone only, links to the Job Card, shows the count after Add Tyre and after a change in another tab, and sits below the toast; no page errors.
- Install replayed with 2.5.2's Updater code; secret and customer-data scan clean.

## Not verified here

- Customer Waiting in COSTAR (Windows only): its caption, that accessibility reports it as a check box with its tick, and that one click ticks it (TEST-PLAN 2.5.3). Whatever COSTAR does when it's ticked (a picking slip) happens as when it's ticked by hand.
- The button on real phones (iPhone safe area).

---

# Validation — v2.5.2 — 26 October 2026

## Basis

- Tommy, 26 Oct: 2.5.1 works ("working nicely now"); for eBay, press Close after the input.
- 25 Oct: after the desk updated itself to 2.5.1 it said "Receiver could not start: Only one usage of each socket address…": the old receiver still held its port (the restart waits 3 s; the desk gave up at once). Ending the old TempeMobile.exe and starting again fixed it.

## Changes

- `Runner.Ebay.cs` `CloseEntered` (after the final check, when `CloseWhenEntered`): nothing if a CHECK BY HAND note exists; otherwise `LeaveGrid("before closing")` (PO# clicked, text checked unchanged, as for DET) so COSTAR commits the last line; COSTAR in front and enabled, PO# = this order, total unchanged since the final check; then `WM_CLOSE` to the Repair Order, as `CloseMobile` does for Next Order, and up to 8 s for the window to go. Never throws: a window still open, Stop, or anything unexpected becomes a CHECK BY HAND note ("close it by hand"); nothing COSTAR asks is answered. Nothing after it can turn the entered order into a stopped one (review.json written in a try).
- `EbayWorker.cs`: passes `AppSettings.ebayClose` (new, default on, also for settings saved before 2.5.2); report "entered and closed (it's in Work-in-Progress)"; last line "(closed)". `EbayTab.cs`: tick box **Close each Repair Order once it's in**, saved at once; hint updated.
- `LocalHttp.cs` `LocalServer.TryStart`: false (listener reset) while the address is in use. `DesktopUi.cs` `StartReceiver`: tries both listeners, then every second for up to 60 s while either port is taken ("Waiting for port N … (the old receiver may still be closing)", chip STARTING); then the error names the port and says to end the other TempeMobile.exe. A start failure shows NOT RECEIVING (it stayed green before).
- Self-test: the close setting is on by default, also when read from older settings, and stays off once unticked.

## Checks performed here

- Compiled at C# 5 against .NET Framework 4.6.2, 4.7.1, 4.7.2 and 4.8 reference assemblies: **0 errors**, the 3 known warnings.
- Self-tests: **112 of 116** + **16 of 16** (the same 4 Windows-only groups fail here). Node tests of the helper; extension 7 Node groups; end to end **20 checks** against this build's desk code.
- Install replayed with 2.5.1's Updater code; secret and customer-data scan clean.

## Not verified here

- The close in COSTAR (Windows only): that clicking PO# commits the last line (M DFE) before the close, and that COSTAR closes an eBay Repair Order without asking (TEST-PLAN 2.5.2). Next Order closes phone jobs the same way.
- The port wait on the desk PC (only seen after an update).

---

# Validation — v2.5.1 — 25 October 2026

## Basis

- Tommy, 25 Oct: the eBay orders go in "perfectly", but after closing and reopening a Repair Order the note lines (EBAY ITEM #, EBAY BUYER NAME, DET's notes, M C) are back to COSTAR's own text. By hand he types "A" after the words, leaves the line, comes back and deletes it, and then it is kept. His test the same day: words pasted in, then A and Backspace in one go, then leaving the line: kept.
- 25 Oct pairing: the desk's `Tempe-Mobile-Root.cer` was the root of a second Setup-Desk run (20261019) while its HTTPS certificate was signed by the first one (20261014), so the eBay PC trusted the wrong root (`net::ERR_CERT_AUTHORITY_INVALID`). Fixed by hand that day (the right root exported over the file).
- Tommy, 25 Oct: no GitHub key in updates.

## Changes

- `Runner.Grid.cs`: `WriteNote` = the words put in as before (WM_SETTEXT, read back, EM_SETMODIFY, no Tab), then `PressAtEnd`: the cursor to the end (EM_SETSEL) and confirmed there with nothing selected (EM_GETSEL, COSTAR in front, the line focused); VK A; wait until the line reads the words plus one letter; the cursor confirmed at the end again; Backspace; wait until it reads the words exactly; then Tab as before. `RoomForKey`: before the line is touched, EM_GETLIMITTEXT; a note that leaves no room for one more letter stops with the counts. Diagnostics `note_room` and `note_keyed` hold labels and counts only, never the words.
- Every note write uses it: `Memo` (DET's notes, `M C`, `M PC`, phone note steps), eBay `NoteText` (`M E`, `M BUY`) and the phone job's Additional notes. A note that already shows our words is confirmed again: in `Memo` unless it is COSTAR's bare "NAME:" (empty value), in `NoteText` on a resumed line, and in a resumed phone job (below).
- `LocalHttp.cs` `TrustRoot.Of`: builds the chain of the desk's HTTPS certificate (no revocation check, unknown root allowed) and returns its self-signed top as a public-only certificate, or nothing (no issuer found, or a signature that doesn't verify). `DesktopUi.cs`: `/trust.cer` and the phone pairing page use it, looked up once; `Tempe-Mobile-Root.cer` only when it finds nothing.
- New self-tests: two made-up roots and a certificate signed by the first (fixed bytes): without the first, nothing; with it, the first (public only). A phone note stopped during its key press is recognised; nothing else is.
- Release: the `Tests` folder is no longer in the ZIP (its only token-like text is a made-up placeholder in a sharing test; nothing on the PCs uses the folder).

## Checks performed here

- **Independent review** (a separate agent, code reading plus its own compiles and probe tests): nothing that breaks every order; message packing, the limit logic and the focus checks correct. Findings, all addressed:
  - a Stop (Ctrl+Alt+F10) or a held modifier around the A could leave the letter in the note, or send the key to another window after an Alt+Tab: each key now goes only after the modifiers are released, then COSTAR in front, the run not stopped and the line focused are checked just before it (`KeyInto`, `Native.KeyNow` never waits); from the A until it is taken back a Stop waits (`keyInFlight` in `Check`); any failure after the A says an extra letter may be at the end;
  - phone jobs: a resumed note step that already showed its words was accepted without the key press, and words plus the key's letter were refused as "partly applied": both are now written and confirmed again (`MobileProof.AfterWithKeyLetter`, new self-test);
  - a note longer than COSTAR's line would have stopped orders that 2.5.0 finished: it now goes in as before with a CHECK BY HAND note (eBay) or log line;
  - the new self-test used `CertificateRequest`, which needs .NET 4.7.2: it now uses fixed made-up certificates (public parts only, unique names), the missing-root case first; the build compiles against 4.6.2, 4.7.1, 4.7.2 and 4.8 again;
  - the note text is read with retries, COSTAR is waited for before each key, and each key has 8 s, as Tab does;
  - TEST-PLAN: ODOMETER on a phone job, and the stop check on all three kinds of order.
- **Review round 2** (the same agent, the fix round only, with its own compiles and harness run): every finding fixed; nothing new above low. The low ones, also done:
  - a note COSTAR may not keep was only a log line on phone jobs and online orders: it is now in the runner's CHECK list, added to the phone job's READY FOR REVIEW message on the desk, to the online "Finished … (check by hand)" line, and repeated at the end of the run log;
  - the extra-letter hint could appear when no key had gone: a modifier is now checked before the key counts as in flight, and a modifier that goes down while COSTAR is checked is waited for again (3 tries) instead of stopping with the letter in;
  - an unanswered line-length question is asked once more after COSTAR is idle.
- Compiled at C# 5 against .NET Framework 4.6.2, 4.7.1, 4.7.2 and 4.8 reference assemblies (both reference sets each): **0 errors**, the 3 known warnings.
- Self-tests: **111 of 115** + **16 of 16** (the same 4 Windows-only groups fail here), after each round. Probe: the certificate lookup never returns a root with the same name but another key, even next to the right one.
- Node tests of the helper (check-package, job card 43, startup 9, Order Check). Extension 1.4.2 unchanged: 7 Node groups and the end-to-end run against this build's desk code: **20 checks**.

## Not verified here

- The key press in COSTAR itself (Windows only): the first eBay and online orders, closed and reopened (TEST-PLAN 2.5.1).
- COSTAR's note-line limit (logged as `note_room`).

---

# Validation — v2.5.0 — 23 October 2026

## Basis

- Tommy, 23 Oct 15:20: his friend enters the eBay orders by copying them one value at a time from the "404 But It's Found" extension; Tommy wants one click on the eBay PC to send the order to his PC and the helper to type it into COSTAR. His rules: Sydney branch (Branch 1); the comment always stops at `EBAY DFE`; `M DFE` only (the consignment number is someone else's job); Rebill to `EBAY` (COSTAR then fills EBAY PAYMENTS, "PLEASE USE ORDER NUMBER AS CARD#" and Terms 7INV); Written By and Salesperson `SA`; entered straight away; the eBay sale price on the tyre line. Example RO 07497644 and the extension's copy-all output.
- The friend's PC is in the shop on the same network, so the desk receiver (HTTPS 8790) is the path, with its own eBay key.

## Changes

- **Desk receiver:** `EbayQueue` (`ebay.dat`, DPAPI): one receipt per eBay order number, content hash without the send time, replace-before-pickup, 409 after, leases, reports applied once per sequence, Retry / Start again / Mark done / Remove, prune past 300. API `/api/ebay/v1` (pair, health, orders, status, retry) with its own key; the extension's origin (`chrome-extension://` + 32 letters) is allowed on the eBay routes only. PIN pairing (6 digits, 10 minutes, 5 tries, one use). Worker route `/api/worker/v1/ebay` (held poll, ack). New tab **eBay orders** and an EBAY chip. An unreadable `ebay.dat` is set aside and the desk starts with an empty eBay list.
- **RDP helper:** `EbayEngine` (journal `ebay-journal.dat`: attempts, orders entered, report with sequence): finds the one Branch 1 COSTAR, waits for 10 s without input and for any online or mobile entry, takes the coordinator lease for that target, refuses an order it already entered unless the desk says **Start again**. `Runner.RunEbay`: header, Ship to, Rebill to (MSAA page tab; Ctrl+Tab only inside a SysTabControl32), Written By / Salesperson SA, spaced lines (items, F, M E per item, M BUY, M DFE), notes written and read back, final check. Layout surprises that are safe to leave become "CHECK BY HAND" notes. New tab **eBay** with **Check Sydney layout (types nothing)**. Online auto-fill that was blocked by an eBay entry starts by itself afterwards. Time saved counts eBay orders.
- **Website/** refreshed from the live repo (Order Check 1.6.4); this release changes nothing in it.
- **Extension 1.4** (not in the helper ZIP): `costar_send.js` (order builder and status words), `background.js` (pairing, send, status, retry; eBay pages may only ask for those), the panel's Send row, the popup's pairing section.

## Checks performed here

- Compiled at C# 5 against .NET Framework 4.8 reference assemblies (both reference sets): **0 errors**, the 3 known warnings.
- Self-tests: **109 of 113** + **16 of 16** (the same 4 Windows-only groups as 2.4.2 fail here). 17 new eBay groups.
- Node tests: check-package, job card (43), startup (9), Order Check (C# 5 scan, Discord 8, order rules 12, Firebase share, GitHub share).
- Extension: 7 Node groups; end to end **20 checks**: the real extension in Chromium against the real desk receiver code from this build over TLS on 127.0.0.1, with the RDP helper played over the worker API (pairing, wrong PIN, send, wait reason, claim, buyer/address/item/freight/total as on the page, progress, CHECK note, reopened page, two items, Send again = Retry, missing SKU, a discount line, origins). Made-up buyers and order numbers only.
- **Independent review, round 1** (a separate agent, code reading): 4 high, 8 medium, 5 lower, 2 security and 2 extension findings, all addressed:
  - a partly typed order removed and sent again is never entered in a new RO (the desk keeps `typed`; the helper refuses `fresh` for a typed attempt and "typed" orders it has no record of; only Start again passes, and it retires the `entered` record);
  - a retry continues in its own unchanged RO when the stop came before PO# (same-customer start); a new RO only replaces an earlier EMPTY one;
  - the helper says which order it is entering (`working`): an order it no longer enters is set to stopped, never left "being entered"; the attempt is recorded before the desk hears of it; `entered` and the ready report are one write; a claim it can't start is declined back into line with the reason;
  - the quiet moment and the other tabs are checked again when an order arrives;
  - stops while Rebill to shows keep the print from just before it; a retry clicks Ship to first; a tab that won't open must leave Ship to showing; no COSTAR window is handled on its own before the customer step;
  - email check only when the eBay order has one; locked or unkept Written By / Salesperson / Rebill boxes become CHECK BY HAND notes; Written By and Salesperson are part of the retry comparison; Rebill to and Card# in the RO it stopped in are never overwritten;
  - an online order loaded for a manual Fill no longer holds eBay orders up; auto-fill only while its tab shows;
  - details are fixed once the helper has had an order; worker words are cleaned on both sides, never refused; the 401 from an older desk is explained; extra COSTAR lines are named in the stop;
  - one normalised path for the origin rule, the key and the route; the desk's own pages can't use the eBay routes;
  - the extension refuses any payment line other than subtotal and postage (discount, fee, tax) and checks subtotal + postage = total; Chrome's Local Network Access: extension pages and workers are not blocked (checked against a 13 Oct 2026 report on Chrome 155); the "can't reach" message now mentions Chrome's local-network question.
- **Independent review, round 2** (a new agent, the fix round only; it compiled and ran the self-tests and probe tests of its own): every round-1 finding fixed or fixed in the safe direction; no new way for a normal first order to fail. New findings, all addressed:
  - a late, older poll could mark an order being typed as stopped (then Start again could enter it twice): the helper now says `working` from the moment it takes an order, and sends its report counter (`sequence`); the desk only stops orders whose last report is not newer than that, and counts them as possibly typed;
  - refusals now report typed when the helper knows it was; a claim handed back again after an early stop is never started twice (`lastStartedLease`);
  - unconfirmed claims come back to a switched-off helper, which hands them back (never stuck); details stay changeable until the helper's first report; "Waiting:" said once;
  - an attempt records `touched` just before its first write: a close before that keeps the earlier stop print and doesn't count as typed; a retry switches back to Ship to from any tab;
  - an online line that won't start by itself (an order loaded) no longer holds eBay orders;
  - the extension: subtotal + postage = total decides (a heading or note line can't block every order; label variants like "Items subtotal", "Postage & packaging"); without a subtotal, any other money line or an unreadable amount stops the send, and so do discount words on the page.
- Re-run after round 2: C# 5 compile 0 errors (both reference sets); self-tests **109 of 113** + **16 of 16**; extension 7 Node groups; end to end **20 checks**; Node tests of the helper pass.
- Install replayed with 2.4.2's Updater code; secret and customer-data scan clean.

## Not verified here

- Anything typed into COSTAR Sydney: the Rebill to tab and its boxes, the Written By / Salesperson boxes, COSTAR's default texts for M E / M BUY / M DFE, Branch 1's new Repair Order. First run: **Check Sydney layout (types nothing)** on a new, empty Sydney RO, then one real order watched from start to finish.
- Pairing on the real eBay PC (certificate install, the desk's LAN address) and the eBay pages with several items.

---

# Validation — v2.4.2 — 19 October 2026

## Basis

- Tommy, 10:47: "the phone job card is still stuck on the last order". `jobcard-shared.js` refused `new` unless the submission was `ready_for_review`; the desk's queue had been reset by hand the night before, so the phone's `getJob` got 404, the page showed "The PC no longer reports this submission", Retry failed, and New job stayed disabled. The 2.4.0 desk's `removed` status would also have been rejected as "unsupported job status".

## Changes (Website only, plus the version)

- `jobcard-shared.js`: `STATUSES` + `removed`; `settled(sub)` (ready_for_review, removed, failed or gone); operation `gone` (set when the PC answers unknown, never while awaiting ack); `new` allowed when settled; a `removed` card ignores later statuses like a reviewed one.
- `Fitment_Planner.js`: poll marks the card gone instead of only showing a message; status names; Retry hidden when gone; New job enabled when settled; the confirm text says a stopped order stays on the desk PC.
- `Fitment_Planner.html` and `Tests/test-startup.cjs`: script version tag `20261019-newjob`, so phones fetch the new scripts.
- `Tests/test-jobcard.cjs`: four new checks (failed → new; gone → new; removed settled and sticky; gone ignored before ack). 43 checks.

## Checks performed here

- Compiled at C# 5: 0 errors, 3 known warnings (the C# is unchanged apart from the version). Self-tests 92 of 96 + 16 of 16. Node tests pass.
- Install replayed with 2.4.1's, 2.4.0's and 2.3.2's Updater code; secret and customer-data scan clean.

---

# Validation — v2.4.1 — 19 October 2026

## Basis

- Tommy's screenshot of both 2.4.0 windows (08:25): the desk said RDP HELPER OFFLINE while the helper was open with mobile off; the COSTAR list text was cut off; "No order loaded." sat under a finished order's details; the Online tab's hint line ran off the right edge; the desk's bottom hint was cut off by the window height.

## Changes

- `WorkerEngine.Connect()` starts the poll loop; `WorkerForm.Shown` calls it, `Start()` calls it too. With `Enabled=false` the hello carries `accepting=false`, `available=false` and `waitMs=0` (no hold), so the desk sees the helper in touch and `Accept` is never reached (it also re-checks `Enabled` under the gate). Reports in the journal reach the desk on the first poll.
- `AppLog.PollError`: every 100th failure after the first.
- COSTAR list: `Format` event shows `Label · PID` when closed; the drop-down shows `ToString()`.
- Online tab: `lastFinished` line, grey preview after an order; widths 770.
- Desk: `Size` 860×900, `MinimumSize` 840×760; website row on one line; shorter hint.
- Wording: "Desk PC connected / not reachable", "Mobile off on the RDP helper (jobs wait in the queue)".

## Checks performed here

- Compiled at C# 5 against .NET 4.8: **0 errors**, 3 known warnings. Self-tests: **92 of 96** + **16 of 16** (the 4 Windows-only groups as before). Node tests pass.
- Install replayed with 2.4.0's and 2.3.2's Updater code; secret and customer-data scan clean.

## Not verified here

- The windows themselves (second look is Tommy's).

---

# Validation — v2.4.0 — 19 October 2026

## Basis

- Tommy, 19 Oct 00:45: full permission to rebuild; "recheck everything, more efficient, modern UI/UX, better file management, faster connection, faster process". And the live problem that night: mobile job MJC-…9366 failed on every Retry with "This mobile job belongs to another COSTAR instance", and the queue had no way out short of renaming `journal.dat` / `queue.dat`.
- Code reading of every file (Worker, MobileModel, LocalHttp, DesktopUi, Updater, Diagnostics, ResourceBudget, Program, the Runner, OrderModel, MobileRunner) for stuck states, fixed waits and UI-thread work. Four parallel audit agents were started as well; they were cut off by an interruption, so the findings here are from the direct reading plus the review rounds below.

## What stays

The entry engine (snapshots, the busy gate, lines by count, identity before typing, customer lookup, account list, all-branch search, resume rules, final checks) is 2.3.2's, moved file by file and unchanged in behaviour apart from the stage hook (`Runner.OnStage`).

## Changes

- **Stuck states** (`Worker.cs`, `MobileModel.cs`, `DesktopUi.cs`):
  - `WorkerJournal.releasedByHand`. `WorkerEngine.Release()` sets it and reports `ready_for_review` ("Released: finished by hand …"); the later `close` command reports `closed` without touching COSTAR. Any desk version accepts this sequence (checked against `JobQueue.Poll`: the report is applied by sequence, Next Order asks for close, the close ack closes the receipt).
  - `WorkerEngine.StartAgain()`: backup of the journal, fresh checkpoint (`MobileRecovery.FreshCheckpoint` now accepts any consistent failed job; `CanReset` still means "unstarted"). Retry on the desk then opens a new Repair Order. Replaces `ResetUnstarted`.
  - `Run()`: the instance check names the two buttons; when the pinned COSTAR process is gone, mobile is switched off so the same failure doesn't repeat on every Retry.
  - Desk: `JobQueue.MarkDone(id)` (ready_for_review + closed, current slot cleared) and `Remove(id)` (waiting or failed only; status `removed`, hidden). `Poll` answers a report about an unknown or closed job with command `forget`; the 2.4.0 worker backs up and clears its journal on `forget`. A 2.3.x worker ignores the command (it keeps polling, as before).
- **Connection** (`LocalHttp.cs`, `Worker.cs`, `MobileModel.cs`): `WorkerHello.waitMs`, `WorkerReply.held/waitedMs`. The desk holds a `wait` answer for up to min(waitMs, 20 s) on a monitor pulsed by `JobQueue.Changed` (after every saved change) and `ReceiverApi.Wake()`, then asks the queue again without the report. The worker sends waitMs 8000 while accepting jobs and not busy (setting `longPoll`, default on), with request timeouts of 8 s + waitMs, keeps the request in `pending`, and interrupts it (`Abort`) on a new report, Stop or Start; a held reply is followed by the next poll at once, otherwise the 2 s / 3 s rhythm stays. `Connected` now means "in touch within 15 s"; `Accepting` is separate; `/health` adds `workerAccepting`; a phone's job is accepted while the helper is in touch even if mobile entry is off there.
- **Progress** (`CostarSession.cs`): `EntryProgress` on the coordinator (Begin/Stage/End, copies on Read; End without Begin is ignored). The Runner calls `OnStage` from `Timed` and the two `BeginStage` points with a planned count; the online thread and the mobile run call Begin/End.
- **UI** (`DesktopUi.cs`, `OnlineTab.cs`, `Ui.cs`): header card with chip, headline, sub line, progress bar, last result, update line; Mobile tab card and four buttons; Online tab card/actions/log; Files & settings tab (`FolderStats`, `Cleanup`, `AppSettings`, export of the diagnostics ZIP to the Desktop); coloured `RichTextBox` logs (`LogLines.Kind` decides the colour; testable without System.Drawing). Desk receiver: chips, `ListView`, grouped buttons, Mark done / Remove, update check and install (`Updater.LaunchMode="Desk"` → `Start-Desk.cmd`).
- **Files** (`AppData.cs`): `AppData.Reports/Diagnostics` move the old folders once; `Runner.ReportsRoot` and `RunDiagnostics.Root` point there. `Cleanup.Packages` keeps current + running + newest other; `Cleanup.Runtimes` keeps the running build + 2; `Cleanup.Logs` keeps 20 startup logs and diagnostics ZIPs ≤ 30 days. `AppSettings` (settings.json) replaces the flag files `det-last`, `order-check-on`, `preferred-branch.txt` and keeps them in step for older packages.
- **Clipboard:** the Online tab's timer runs at 250 ms while idle (1 s while busy).
- **Split:** `CostarAutofill.cs` → `Native.cs`, `Runner.cs`, `Runner.Customer.cs`, `Runner.Grid.cs`, `Runner.Online.cs`, `OnlineTab.cs`, `OnlineModelTests.cs` (no code change beyond the move and `OnlineModelTests.SelfTest`). Build.ps1 lists 22 files; `Tests/check-package.cjs` now checks that list against `Source\*.cs`.
- **END OF DAY:** counts of released / started-again / marked-done / removed jobs.
- **Self-tests:** 96 groups (new: desk exits + forget; released job close; held poll; progress; cleanup plan + folder stats; settings round trip + log colours; the recovery test now expects started jobs to be startable again).

## Checks performed here

- Compiled with Roslyn at C# 5 against .NET 4.8 reference assemblies (Build.ps1's list and references): **0 errors**, the usual 3 warnings.
- Self-tests under .NET 8: **92 of 96** plus **16 of 16**; the 4 Windows-only groups fail here as before. The held-poll test exercises the real `ReceiverApi.Handle` with a background submit; the desk-exits test covers stranded `injecting` jobs with a reachable and an unreachable helper.
- Node tests: package (now with the file-list check), job card, startup, Order Check rules and C# 5 scan.
- Two reviewers on the full diff, each with a follow-up round:
  - Protocol/worker reviewer. Blocking (fixed): `forget` while a run was busy nulled the journal under the typing thread (`Forget` now returns while busy; the desk refuses Mark done on a job a reachable helper is typing). Should-fixes (all fixed): Release/StartAgain stopped a live run; a released job's close still needed the original COSTAR; the hold ignored `available`; two lost-wakeup/zombie-request windows in the held poll; the interrupt didn't wake the sleep; a 2.3.x helper facing a 2.4.0 desk's Mark done keeps reporting (now a hint on the desk).
  - UI/files/split reviewer. Blocking (fixed): the root TableLayoutPanel had no column style, so the header clipped the tab control. Should-fixes (all fixed): a refused online start ended a running mobile job's header state; the read-only RichTextBox refused its trim; the held-poll race; Save worker report had vanished; the home folder row counted subfolders; `AppData.Locate` unsynchronised; cleanup planning on the UI thread.
  - Follow-up findings, done after the rounds: Mark done / Remove allowed for a job the helper never picked up or an unreachable helper holds (`MarkDone(id, workerReachable)`, `Remove(id, workerReachable)`; tested); the forget hint resets once the helper stops reporting the job; the hold is skipped when the queue changed during the poll itself; buttons grow with their captions for 120/125 % DPI and the COSTAR list drops down wide; "No" to Clean up resets the note and a closed form gets no stray box; the two "window is closed" messages name the new buttons; the phone page says "mobile entry off, your card will wait" instead of "RDP worker online" when the helper is in touch but not taking jobs.
- Package, manifest, latest.json; install replayed with **2.3.2's own Updater code**; secret scan.

## Not verified here

- **The window itself.** No Windows here, so the new layout has not been seen. It uses TableLayoutPanel/FlowLayoutPanel with AutoSize everywhere, so it should hold together; the first start on the PC is its first look.
- Live COSTAR entry is unchanged in code; the stage hook only reports.
- The long poll against the real desk receiver over the shop LAN (tested here in-process).

---

# Validation — v2.3.2 — 10 October 2026

## Basis

- Tommy's diagnostics, 10 Oct 19:50, and the entry report of TTW1730569 (2.3.1). It was used here for the grid geometry only; no customer value was printed or kept.
  - DET went on line 6 with its notes on lines 7–9 (structural check passed), and 0358091 ×2 went on line 1.
  - Item 0358092: `grid_shape` "items above DET: steady, but lines 1-6 are not on their places". Boxes at 0, 159, 178 … px: line 1 at its place, lines 2–25 140 px lower. Focus was in line 1's 42×20 cell at x=834.
  - Then the fallback chose the first empty line after everything: line 10, drawn 140 px low. The click moved focus there, line 1 closed, line 10 moved back up, and `RequireLineStill` stopped: "moved before typing".
  - Earlier in the same run, "DET notes" had the same shape. The MAKE/MODEL editor (806×160 at 225,483) was focused, and lines 8–25 were 140 px lower.
- Control dumps (before and at the stop):
  - 25 ITEM boxes, one panel per line under the grid container. Line 1 is at y=369, 1 px under the ITEM label (341+27).
  - When DET's notes appear, the bottom panel (line 25's) moves to line 7 and lines 7–24 move down one. DET and lines 1–5 keep their boxes.
  - A focused empty line stays 20 px tall; focused filled lines and notes open to 160 px.
- 2.3.0's stop (9 Oct) is the same mechanism, seen through `EvenLines`.

## Changes

- **Grid** (`OrderModel.cs`):
  - `Countable()`: exactly 25 boxes (`CostarLines`), the first within 6 px of 1 px under the ITEM label.
  - `LinesTo(handle)`: the handles from line 1 down to that box.
  - `NextFreeAbove(index)`: the box after the last filled box above `index`, or -1.
  - `Lattice`, `LinesAt` and `OnLattice` are removed.
- **Choosing lines** (`CostarAutofill.cs`):
  - `SteadyGrid(why, wantCounted, …)`: two identical looks, as before. It waits up to 1.5 s for a countable look only when one is wanted. The learnt lattice is gone.
  - `LineRow(line)` needs a countable look and takes `Rows[line-1]`.
  - `NextEmptyRow` is the first empty box after the last filled one (2.2.1's rule).
  - `ItemRowAbove(detLine | -1)`: DET is found by its text, and must be at `detLine-1` when the look is countable. The item goes on `NextFreeAbove(DET)`. It falls back to after everything when nothing is free above DET or an item of this order is already below it (`items_after_det`).
  - Each of these returns the chosen box plus its `LinesTo` path.
- **Before typing**, `RequireLineStill(row, path)` takes a fresh steady look and checks:
  - the same `LinesTo` path;
  - the box is still empty;
  - focus is still on the box. If not, the box is clicked once more (`line_focus_retry`) and checked again; otherwise entry stops.
  - Positions are no longer compared.
- **DET first / DET last:**
  - `Runner.DetFirst` comes from the new Online tab check box "DET first (items above DET)". It is ticked by default; `%LOCALAPPDATA%\TempeMobileCostar\det-last` exists while it is unticked. The value is captured on the UI thread for each fill and logged in `online_fill_start` ("det-first" / "det-last").
  - DET first: `DetFirstLine` checks the grid is countable and that DET's line and every line below it are empty. Then DET goes on that line, followed by `DetNotes(line)`, then the items above DET.
  - Otherwise (`det_last` event with the reason, or the box unticked): the items go to the first empty line after everything, then DET there, then `DetNotes(0)`. This is 2.2.1's order.
  - Resume with DET already entered: leave the grid, wait for the notes, read DET's line, `DetNotes`. Missing items go above DET only with DET first on.
  - `DetNotes`: template, `RequireNotesUnderDet` (structural, plus DET's line when countable), MAKE/MODEL, REGO NO, ODOMETER, PAYING BY.
- **Final check:** the DET block moved to `Selectors.CheckDetBlock(s, vehicle, rego, payment)`, with the same rules. Exactly one DET; its three notes are the next three filled rows; PAYING BY is fourth when set.
- **Mobile:** numbered lines use the same `LineRow` and `RequireLineStill`. The plan is unchanged.
- **END OF DAY:** unusual grid shapes, orders with items after DET's notes, `det_last` pickups, fills with DET first off, and `line_focus_retry` counts.
- **Self-tests:**
  - Replaced the two lattice groups with line numbers by count, and a line as the Nth box (open line, moved box, stray/missing/scrolled box).
  - Added: next line above DET; the 10 Oct grid with the tyre's line open (`ProductGrid`, `Countable`, `NextFreeAbove`, `LinesTo`, cells of the open line); the final DET check for DET first, DET last and items after the notes (positive and negative); end-of-day lines.
  - Total 90.

## Checks performed here

- Compiled with Roslyn at C# 5 against .NET 4.8 reference assemblies, with Build.ps1's reference set and with csc.rsp's: **0 errors**, the usual 3 warnings.
- Self-tests under .NET 8: **86 of 90** plus **16 of 16**. The 4 Windows-only groups fail here as before.
- Replay on the real 10 Oct dumps (local only):
  - The new and stopped Repair Orders are countable.
  - DET is line 6; the notes are on lines 7–9; the next item is line 2 (the same box as line 2 on the new order).
  - With line 1 open (lines 2–25 +140 px) and with line 7 open, the grid is still countable and line 2 is chosen. Its `LinesTo` is unchanged once the open line closes, and the open line's 806×160 description cell is found.
  - The box that was line 8 before DET's notes fails `LinesTo` afterwards; line 3's passes.
  - `CheckDetBlock` passes on the stopped order.
- A separate review of the diff and full sources found nothing blocking. Its should-fix (tests for the final DET check on every layout) and nits are done: the focus re-check, the first-box tolerance, wording, and the test data.
- A second review round on those fixes also found nothing blocking. The `RequireLineStill` loop always ends, a moved box is followed rather than missed, and `CheckDetBlock` behaves the same as the old inline check for every layout `Run()` can produce.
- Node tests (package, job card, startup, Order Check rules/sharing, C# 5 scan of OrderCheck.cs) pass. The page is unchanged.
- The real Windows compiler (`csc /langversion:5`) remains the final check on the PC. If it refuses the build, `Launch.ps1` sets 2.3.2 aside and starts 2.3.1.
- Package, manifest and latest.json. The install was replayed with **2.3.1's own Updater code** (the version on the PC).

## Not verified here

- Live COSTAR: a DET-first pickup with two or more items, and the "DET first" check box on the PC.

---

# Validation — v2.3.1 — 9 October 2026

## Basis

- Tommy's diagnostics, 13:45. 2.3.0 built and passed its self-tests on the RDP PC.
- The one 2.3.0 order, TTW1730549 (store Parramatta NSW, confirmed into Branch 11):
  - DET went to line 6 with its notes on 7–9; tyre S1028 went to line 1 with its quantity;
  - then "Item M FB" stopped: `EvenLines` was false on the very next look, 6 ms later.
- Its retry at 13:15:55 was refused. Order Check (read at 13:15) listed TTW1730549 as document 7856262: the helper's own open, stopped Repair Order.
- Earlier runs logged "grid_read_plan_reset: header labels changed" during product item stages (5 runs): COSTAR re-lays its grid out while it loads a product.
- A separate review of the change (three rounds) found a 2.3.0 bug: `Runner.Check()` still required `RepairOrder Branch 11`, so any other branch would stop at the first check.

## Changes

- **Branch:** `Runner.Check()` uses `Branches.OrderTitle(caption, branch)`.
- **Grid** (`OrderModel.cs`): `Lattice` (median pitch and start), `LinesAt(start, pitch, lines, slack)`, `OnLattice`.
- **Looking at the grid** (`CostarAutofill.cs`):
  - `SteadyGrid(why, lines, out snapshot, out numbered)`: two identical consecutive looks (ITEM label y; every box's handle, y and text). It gives up after at least 4 looks and 2.5 s, or 10 s.
  - `Numbered`: lines 1..N each within 3 px of the lattice learnt on the run's first steady, evenly spaced grid, stored relative to the ITEM label; no fewer boxes than learnt.
  - `NoteGridShape`: event `grid_shape` (offsets, sizes, classes, filled, focus; no values), up to 2 normal and 2 problem shapes per run.
  - `LineRow` (lines 1..max(line, last filled) countable), `ItemRowAbove`, `RequireNotesUnderDet` (structural: the three notes are the next three filled rows after DET, plus line checks when countable), `SteadyLook` for every "first empty line after everything".
  - `AddCode`: `Focus`, then `RequireLineStill` (live position relative to the Repair Order within 3 px, live text empty), then `WriteFocused`.
- **Fallback:** if the lines stay out of place (or DET's line is unknown on a resume, or an item is already below DET), the remaining items go after everything (`items_after_det`). DET missing, doubled or moved stops entry.
- **Verify:** the three DET notes must be exactly the three filled rows after DET, with PAYING BY (when set) the fourth.
- **Resume:**
  - `Selectors.OrderPrint(s, delivery)`: every header field, Time in, Ship Via, the delivery panel, products as code x qty @ net, note lines as text. COSTAR's own DET/M FB texts and blank DET notes are left out.
  - `SettledPrint`: two equal prints from fully read looks, at least 3 tries, up to 15 s. It is taken when a run that typed something (or a verified resume) stops, and stored with `stoppedIn`.
  - On retry, the helper's own stopped Repair Order (`OwnAttempt`) must give the same print before anything is typed; otherwise it refuses. A Repair Order that already holds the order (PO# and phone) but isn't that attempt is refused.
  - For an order Order Check lists, the only candidate is that own Repair Order (`MustResume`); otherwise the 2.3.0 refusal stands.
  - The resume leaves the grid (PO#) and waits for DET's notes before reading DET's line.
- **END OF DAY:** lines out of step, items after notes, and listed-order retries appear under THINGS TO LOOK AT.
- Self-test groups 86 (lines by place) and 87 (stopped-order print).

## Checks performed here

- Compiled with Roslyn at C# 5 against .NET 4.8 reference assemblies, with Build.ps1's reference set and with csc.rsp's: **0 errors**, the usual 3 warnings.
- Self-tests under .NET 8: **83 of 87** plus **16 of 16**. The 4 Windows-only groups fail here as before.
- Three review rounds by a separate agent on the diff and full sources. The last round had no blocking findings.
- Node tests. The page is unchanged.
- Package, manifest and latest.json. The install was replayed with **2.3.0's own Updater code** (the version on the PC).

## Not verified here

- Live COSTAR: how quickly the grid holds still after a product (`grid_shape` will show it), and a real resume.

---

# Validation — v2.3.0 — 9 October 2026

## Basis

- Tommy (9 Oct): COSTAR loses DET's notes on close when DET is entered last. Enter DET first on line 6, items above. Also: work with any COSTAR branch open on the PC (Branch 1 orders).
- Real captures (2 Oct, empty and filled Repair Orders): 25 item boxes, all enabled, 19 px apart, line labels 1–25 alongside, so box N is line N.
- Day logs 3–5 Oct: only "COSTAR:  11 Tempe Tyres Tempe" was ever seen, so the branch parser is written for the known format and tested on invented titles for other branches.

## Changes

- **Branches** (`CostarSession.cs`): `Branches.OfMain` / `NameOfMain` / `OfOrder` / `MainTitle(title,branch)` / `OrderTitle(title,branch)` / `OrLegacy` / `Place` / `StoreMatches`.
  - `CostarInstance` carries Branch, BranchName and Label; `Same` includes the branch.
  - Every former `Branch11` check compares with the selected or recorded branch: detection, Main, OnlineOrder, OpenNew, ValidateTarget, the Runner constructor, and online window reuse/resume.
  - `MobileCheckpoint.branch` (0 = legacy Branch 11). `Runner(pid, branch, …)`; diagnostics Env "branch".
  - `Selectors.Blank/BlankDelivery(s, branch)`: Branch 11 keeps TEMPE/NSW; other branches accept their own default suburb and a valid AU state.
  - Worker window: branch labels, a remembered branch (`preferred-branch.txt`), mobile paused when the branch changes while mobile is enabled, and the yellow bold update line.
- **Store check** (`AutofillForm.CheckStoreBranch`): pickup store vs branch place (strict). On a mismatch, a Yes/No dialog names any matching open COSTAR; the answer is remembered per store and branch for the session. Logged as `online_branch_question` / `online_branch_confirmed` / `online_branch_refused`.
  - While the dialog is open (`askingBranch`), the clipboard timer and `StartEntry` do nothing: a WinForms timer still ticks under a message box, and before this guard a newly copied order could replace the one being asked about. The order is captured before asking and must still be the one on screen afterwards. A minimised helper window is restored and activated first.
- **Website** (`OnlineOrders/Tempe-Orders-COSTAR.html` = GitHub testrun.html, and `transfer-core.js`, identical rules):
  - pickups from any store; `store` sent; schema 3 for non-Tempe pickups (refused by helpers before 2.3.0), schema 1 for Tempe;
  - Store picker (localStorage), store-aware titles and list;
  - COSTAR check limited to Tempe.
  - The helper validates schema 3 and requires a store.
- **DET first:**
  - `Order.DetLine(itemLines)` = max(6, itemLines+2).
  - `Grid.EvenLines` / `LineOf`; `Runner.LineRow` (requires empty line and even spacing), `ItemRowAbove` (next free line above DET, or the old after-everything rule when none fits), `RequireNotesUnderDet`.
  - `AddCode(…, line, above)`.
  - Online pickups: DET block (DET, template, notes check, MAKE/MODEL, REGO NO, ODOMETER, PAYING BY), then items above. Resume reuses an existing DET at its own line; if its notes are missing (stopped right after DET was typed), it leaves the grid once (`LeaveForDetNotes`, else `LeaveGrid`) so they appear. The final check requires exactly one DET.
  - Mobile plan v3: DET (line), notes, notes row, then items on lines 1..n. `MobileRow.line` comes from the snapshot. `After` checks the planned line for add/det steps (DET block consecutive from its line); line-0 steps keep the old rules. `PrepareCheckpoint` moves unstarted older-plan jobs to v3 and refuses started ones (as before).
- **Launch.ps1:** if the build or self-tests fail in the package `current.txt` points to, the pointer is renamed `current.txt.failed` first. Then it points at the newest earlier installed package (`packages\Tempe-COSTAR-Helper-v*` with a lower `VERSION.txt` and a Launch.ps1), so old shortcuts hand over to it (2.2.1 on Tommy's PC). With none, there is no pointer and each shortcut starts its own folder. The message names the version that starts.
- **Self-tests 81–85:** branch titles and instances; store and suburb rules; DET placement and line-checked item proofs (positive and negative); grid lines and the DET line rule; old-plan checkpoints; schema 3.

## Checks performed here

- **Compiled with a real C# compiler** (new for this release): Roslyn from PowerShell 7.4.6 (GitHub release) at `LanguageVersion.CSharp5`, against .NET Framework 4.8 reference assemblies (`mono/reference-assemblies` on GitHub), with Build.ps1's reference list and again with the framework's full csc.rsp list: **0 errors**, the same 3 harmless warnings as 2.2.1. The known-good 2.2.1 compiles the same way, so the method agrees with the RDP PC's csc. (Against 4.5 references the X509 `using` blocks fail in both versions: the PC has .NET 4.6 or later.)
- **Self-tests run** under .NET 8 (compiled as above; a stand-in for `JavaScriptSerializer`; `AutofillForm.SelfTest` moved out of the Form class in the scratch copy only): **81 of 85** helper groups and **16 of 16** Order Check groups pass. The 4 that fail need Windows (process identity, a WinForms TextBox, folder ACLs, user32) and fail identically for 2.2.1 (76 of 80 there).
- **Launcher fallback**, 6 scenarios with PowerShell: a failed update points back to 2.2.1 ("starts version 2.2.1 again") and an old 2.2.0 shortcut then hands over to 2.2.1; with only 2.3.0 installed the pointer is set aside; a failing folder that isn't the pointer target leaves it alone; a passing update changes nothing and old shortcuts hand over to it.
- **Page:** the inline script parses and runs against a fake DOM (Store picker rendered with Tempe NSW, a choice is remembered and the list reloads). `transfer-core.js` is embedded verbatim; Tempe → schema 1, other stores → schema 3 with the store named.
- Static checks (balance, C# 6+ syntax, shadowing, `using`s, one entry point) and a line-by-line diff review against 2.2.1.
- Node: package, job card, startup, Order Check rules/sharing/C# 5 (7 tests).
- ZIP, manifest and latest.json; the install replayed with the helper's own `Updater.Validate`, `Extract` and `VerifyManifest` from the compiled code.

## Not verified here

- Live COSTAR behaviour: typing on line 6 with empty lines above, the notes appearing under DET, and other branches' window titles (parsed from the known format).
- On the PC only: the 4 Windows-only self-test groups and the WinForms screens (the branch question, the yellow update line). A failed build or self-test sets the update aside automatically.

---

# Validation — v2.2.1 — 7 October 2026

## Basis

- **Tommy's screenshot (2.2.0):** Order Check reading normally (98 jobs, PO column found, WIP COSTAR PID 227392).
- **The saved Tempe Orders page:** "COSTAR check unavailable … Order Check has not read COSTAR yet (setup)".
- So a different Order Check answered on 127.0.0.1:8795. `HttpServer.Start` failed silently: `SetState("error")` was overwritten by the next successful read. Loopback ports are machine-wide on the shared RDP server, while Order Check's mutex is session-local (`Local\TempeOrderCheck_v1`).

## Changes

- `HttpServer` tries 8795–8804 (ExclusiveAddressUse) and keeps `Port`. `Route` checks the Host header against the served port.
- `Problem` names the occupant of 8795 (its `/health`: version, state, user, session) and stays in the status text permanently.
- `/health` adds port, state, session and user.
- **Open board** appends `?reader=http://127.0.0.1:<port>` when not 8795 (the board already supports `?reader`).
- **Tempe Orders page** (`testrun.html`):
  - `findOrderChecks()` probes ports 8795–8804 (`/health`, then `/wip.json`) and uses the most recently read Order Check in state "ok";
  - merges `/entered.json` from all;
  - lists idle copies as a note, and gives a clear error when only an unready copy answers.
- Order Check self-test group 16 (`PortTest`): a busy port → the next port is served, the busy port is reported, own Host is accepted, the other port's Host gets 403.

## Checks performed here

- 14 C# files clean (balance, C# 6+ syntax, shadowing; one entry point). Order Check C# 5 check.
- Node end-to-end: two fake Order Checks (old copy on 8795 in setup; healthy on 8796 with WIP and entered) → the page uses 8796, matches PO# / helper-entered / missing, and notes 8795. With only the old copy: a clear message.
- All package tests. ZIP, manifest and latest.json fingerprint verified.

---

# Validation — v2.2.0 — 6 October 2026

## Changes

- **Resume:**
  - `Selectors.SameOrderInProgress` (PO# = order number, same phone, comment empty or equal).
  - `Run()`: resume path skips the empty check and the phone lookup (account and name taken from the order), reuses item rows by code and occurrence (`ExistingRow`, `FinishLine`), and reuses DET/F rows (`FinishFreight`). Memos are idempotent as before.
  - AutofillForm remembers `stoppedIn[orderId] = window` when a run stops after typing (`Runner.Writes > 0`), retries there, and forgets on success. `Verify` still requires the exact item sequence.
- **Missing orders:**
  - `OnlineOrders/Tempe-Orders-COSTAR.html` (= GitHub `testrun.html`) gains the COSTAR check: `/wip.json` and `/entered.json` from 127.0.0.1:8795; matching by PO#, by the order number in the comment (digit-boundary safe), by helper-entered, or by amount ±max($1, 2%) as "probably".
  - **Make it** reuses Send to COSTAR; **Make all missing** spaces sends 3 s apart.
  - Order Check route `/entered.json` ← `Hosting.Entered` ← `EnteredOrders.Json()` (today and yesterday's `online_fill_ok` from the day log; order numbers and times only).
- **Auto-update:**
  - `Updater.cs`: HTTPS GET of `latest.json` only under `https://tommyvenzin.github.io/tempe/helper/` (TLS 1.2, no redirects).
  - Release validation: version, ZIP name matching the version, SHA-256 format, size 10 KB–50 MB.
  - Download size limit; ZIP SHA-256 must match; extraction with a zip-slip guard; every file checked against `PACKAGE-SHA256.json`; install to `packages\Tempe-COSTAR-Helper-vX`; `current.txt` pointer; restart through the matching Start-*.cmd after the helper closes.
  - `Launch.ps1` hands over to a newer version found via `current.txt` (`VERSION.txt` comparison; `-NoHandOver` prevents loops).
  - Worker window: checks at start and every 6 h, offers in the status line, refuses during entry.
- **Time saved:**
  - `TimeSaved` counts `online_fill_ok` / `mobile_job_ready` / stopped from the day logs.
  - Minutes in `time-saved.json` (default 4/4, written only when a report is made).
  - Status line (cached 1 min); Boss report HTML (today/7/30 days, day table, no order details); END OF DAY line.
- Self-tests 78–80: resume recognition (made-up customer), time-saved counting and report, updater validation, manifest tamper detection and the zip-slip guard.

## Checks performed here

- 14 C# files: balance, C# 6+ syntax and shadowing scans clean, one entry point.
- Argument-count check on all new methods (flags reviewed: all framework/LINQ/lambda false positives).
- Order Check C# 5 check. All Node tests, including the page's JavaScript syntax.
- Matching logic unit-tested in Node: PO#, comment, helper-entered, amount, missing, and digits inside a phone number not matching.
- ZIP, manifest and latest.json fingerprint verified.

## Not verified here

- Compilation and live COSTAR.
- PowerShell syntax of the Launch.ps1 hand-over (no PowerShell here; reviewed by hand).
- Chrome's private-network access from the GitHub page to 127.0.0.1 (Order Check's board already does the same).

---

# Validation — v2.1.0 — 6 October 2026

## Basis

Tommy's screen recording TEIK.mp4 (22 s, silent), frame by frame:
- the phone is entered in the Repair Order;
- the "Search…" window (Search for an Existing Customer) opens with "Nothing found!", the Phone box empty, Branch "11" and OK disabled;
- the phone is typed into Phone, Branch is cleared and Search is pressed;
- 3 accounts appear (other branches), row 1 highlighted and OK enabled;
- row 1 is taken, the account loads, and SHOP is typed into Ship Via.

## Changes

- **Selectors:**
  - `NothingFound` (a static "Nothing found!");
  - `FieldRightOf(label)` (a box to the right of its label, same vertical centre ±6);
  - `ShipVia` (the box under "Ship Via", same parent).
- **`TryChooseFirstAccount`:**
  - if OK is disabled (not a list box), `SearchAllBranches` runs: WM_SETTEXT Phone (digits of the phone typed for the lookup), WM_SETTEXT Branch "", BM_CLICK Search, then wait up to 15 s for OK enabled ("accounts found") or "Nothing found!" (after 800 ms, non-busy popup snapshot);
  - none found: BM_CLICK Cancel, `lookupCancelled`, and the new-customer path.
  - `sawChooser` is set only when an account is chosen.
- **`SetShipViaShop`:** if Account# is non-empty, PutMapped Ship Via "SHOP". Online pickups run it as stage "Ship Via SHOP" before the final check; mobile runs it after the final check (Ship Via is not part of the mobile proof) and it is non-fatal.
- `lookupPhone` is recorded where the phone is typed (online header, mobile phone step).
- **Fixed before release** (found by a new argument-count check): `Diag.Write()` had no matching overload, so `Diag.Write(0,0)`.
- Self-test 77: Search window boxes, Nothing found, chooser with a disabled OK, and Ship Via (geometry from the 5 Oct popup_layout).

## Checks performed here

- 13 C# files: balance, C# 6+ syntax and shadowing scans clean, one entry point.
- **New:** a method-existence and argument-count check for every helper call (all flags reviewed; the only real one is fixed).
- Order Check C# 5 check. All Node tests. ZIP and manifest verified.

## Not verified here

Compilation, and live COSTAR behaviour of the Search window's Search button and Ship Via.

---

# Validation — v2.0.3 — 5 October 2026

## Basis: end-of-day report 5 Oct 22:37–22:51 (2.0.2)

- 19 runs: 8 completed; 7 open-order checks (about 60 ms, "not empty"); 2 account-list stops; 1 modifier stop; 1 focus stop after a failed list.
- Memory 42–56 MB, CPU 0.0% average.
- **Account list:**
  - The popup was recognised (`account_chooser` accept=True, acceptEnabled=False).
  - `account_first_row_error` ArgumentException on the first panel, then "grid found but it has no rows": the smallest panels were tried first and the code returned at the first table without rows.

## Changes

- `Msaa`:
  - `Children` (AccessibleChildren, falling back to get_accChild; handles simple int child IDs), `RoleOf`, `LocationOf`, `SelectChild`;
  - `FindTable(root, depth)`, exception-tolerant;
  - `TopRows(table, take)`: rows by screen position, header rows (first child role 25) skipped;
  - `Shape` (roles/counts/positions only).
- `SelectFirstRow(front, ok)`:
  - candidate panels ≥200×60, largest first; depth 1, then 2;
  - per row: accSelect, check OK, click left edge inside the popup, wait ≤700 ms for OK; up to 3 rows;
  - on failure logs `account_grid_shape`.
- `Native.NoModifiers`: waits ≤3 s; the message names the key.
- `AutofillForm.lastFilledWindow`: the Repair Order of the last successful fill is not re-tried (`online_skip_review_ro`).
- `RunDiagnostics.Stopped`: RepairOrderInUseException → Outcome "probe". `DiagnosticsBundle.IsProbe` also recognises 2.0.2-style checks (online, "not empty", under 1 s, at the empty-order stage). Excluded from TODAY counts and the detailed completion %.
- `OpenNew`: "Order Entry" is not logged as a prompt.
- Report ZIPs use CompressionLevel.Fastest.
- Self-test 76: probe counting (current and legacy checks excluded; a genuine mobile "not empty" stop still counted).

## Checks performed here

13 C# files: balance, C# 6+ syntax and shadowing scans clean, one entry point. Order Check C# 5 check. All Node tests. ZIP and manifest verified.

## Not verified here

Compilation, and COSTAR's customer list grid under the new selection (the report records its shape if it still fails).

---

# Validation — v2.0.2 (lag fix) — 4 October 2026

## Findings in code

- `Snapshot()`: `WaitIdle(3000)` and then reads **regardless**. Each WM_GETTEXT is a SendMessageTimeout of 100 ms to COSTAR's UI thread, up to 8 s per snapshot.
- `LookupCustomer` / `CustomerFormReady` repeat full snapshots every 30–50 ms while COSTAR searches. 2.0.1 extended that to 15 s, so queued requests built up on COSTAR's thread.
- `timeBeginPeriod(1)` during every entry: global on NT 6.2.
- Order Check always on (thread, server, timer).
- Worker poll 1 s, with a window scan per poll.
- `new JavaScriptSerializer()` per message.
- `Process.GetCurrentProcess()` not disposed in Order Check's window search.

## Changes

- `Snapshot`:
  - `WaitIdle(8000)`, then `Responsive(window,60)`. If not answering: no text reads; readable controls marked `busy`.
  - A failed read with COSTAR not answering stops further reads.
  - Sets `lastSnapshotBusy`; counts `busySkips`/`busySnapshots` (logged per run as `costar_busy_skips`).
- `Current()` waits (150 ms steps, up to 20 s) for a non-busy snapshot. `Settled()` and the startup wait treat busy as not ready.
- Lookup loops back off 150 ms on busy and poll 120 ms while "SEARCHING" (was 30–50 ms).
- `FastTimer()` is no longer called (no `timeBeginPeriod`).
- Order Check is opt-in (flag file `order-check-on` in the helper's data folder; tab button).
  - `Hosting.EntryPid` stops reads of the entry COSTAR; `Hosting.Hold` stops reads during entry.
  - Process leak fixed.
- Worker poll 2 s while enabled; `Available()` cached 3 s.
- `Wire` uses one `JavaScriptSerializer` per thread.
- `GCSettings.LatencyMode = SustainedLowLatency`.
- `PerfMonitor`:
  - samples every 5 s for the status line;
  - writes `perf` (ws, private, heap, handles, gdi, user, threads, cpu) to the day log every 5 minutes, and `perf_after_job` after each job;
  - END OF DAY shows start/peak/now and CPU, and flags >300 MB, handle growth >500, GDI/USER growth >200, or CPU >5%.
- Self-test 75: perf parsing and the report lines.

## Checks performed here

13 C# files: balance, C# 6+ syntax and shadowing scans clean, one entry point. Order Check C# 5 check. All Node tests. ZIP and manifest verified.

## Not verified here

Compilation, live CPU/memory on the RDP server (the new meter and day log will show it).

---

# Validation — v2.0.1 — 4 October 2026

## Basis: diagnostics 4 Oct 00:37–00:56 (2.0.0, 7 online runs, 1 completed)

- 3× "target field is covered": first click on a fresh Repair Order, 70–430 ms after it appeared.
- 1× "search did not cancel": the commit dialog appeared 2236 ms after Tab, then "SEARCHING" with COSTAR busy for 6 s, then Escape at 3 s cancelled the search.
- 1× commit timeout: 2523 ms with a 2500 ms limit.
- 1× Add New 30.9 s beside a reviewed order.
- Memory dropped to 1 MB after every run (EmptyWorkingSet).

## Changes

- `SearchPatienceMs=15000` for a running search (LookupCustomer and CustomerFormReady). Popups keep 750 ms; other waits keep 3 s.
- `CommitField` limit 8000 ms.
- `ClickTarget`: if covered, it logs `covered` (masked: COSTAR or another app, window class) and waits up to 1.5 s, re-aiming at the live rectangle. If another process is on top and nobody is typing, `BringToFront(root)` once. Then `covered_wait`.
- `Memory.Trim`: `GC.Collect()` only above 96 MB managed heap; no EmptyWorkingSet.
- `TempeOrderCheck.Hosting.Store` (hosted Store) is read directly by `OrderCheckLink`; HTTP remains only as a fallback.
- `Hosting.Hold` (= coordinator busy) makes `Poller.Cycle` wait during entry.
- `OpenNew` logs the first foreground COSTAR prompt (title/class) as `add_new_prompt`.
- **Time in:**
  - `Selectors.TimeIn` finds the "Time in" label → combo directly below → its single inner Edit (optional).
  - `Order.TimeInText("HH:mm")` → "h:mm am/pm"; `Order.ClockMinutes` compares formats.
  - `SetTimeIn()` runs after the online header for pickups. It is non-fatal and logs `time_in` set / not kept / box not found.
  - `Verify` adds a non-fatal note if Time in differs from the booking.
- Self-test 74: Time in format, comparison and box finding (real layout: label 109,295; combo 109,309; Edit 112,312; Promised beside it).

## Checks performed here

13 C# files: bracket balance, C# 6+ syntax and shadowing scans clean, one entry point. Order Check C# 5 check (no lambdas). All Node tests (helper package/job card/startup, Order Check rules/sharing). ZIP and manifest verified.

## Not verified here

Compilation and live COSTAR behaviour (RDP PC). Whether COSTAR accepts "10:30 am" typed into Time in: the helper reports either way.

---

# Validation — v2.0.0 (one system) — 3 October 2026

## Merge

- `Source/OrderCheck.cs` (Order Check 1.4.0 reader, namespace `TempeOrderCheck`) is compiled into the helper.
  - Its `Program`/`Main` is replaced by `Hosting` (claims the old app's mutex `Local\TempeOrderCheck_v1`, works out the board address). One entry point remains: `TempeCostar.Program.Main`.
  - The old app lowered the whole process to below-normal priority. Not done here, so entry speed is unaffected. Its reader and Search threads already run at below-normal thread priority.
- `MainForm(board, hosted)` is embedded as the third tab (TopLevel=false).
  - Hosted: no tray icon, no Exit; `Shutdown()` runs when the helper closes.
  - `TargetChanged` tells the helper to forget its cached WIP key and refresh its own COSTAR list.
  - If the helper's current target becomes the WIP window, it is dropped and the other Tempe COSTAR is chosen.
- Self-test: `--self-test` runs `MobileTests.Run()` and `TempeOrderCheck.SelfTests.Run()` and writes both reports. Failure of either fails the build.
- Board files are in `Website/`, mirroring the GitHub repo. Sharing docs, the extension update and notes are in `OrderCheck/`. Order Check's Node tests are in `Tests/OrderCheck` with repointed paths.
- Data folders unchanged: `%LOCALAPPDATA%\TempeOrderCheck` (WIP window, interval, Mark OK marks), so settings carry over.

## Checks performed here

- All 13 C# files: bracket balance, C# 6+ syntax scan, loop-shadowing scan. Exactly one `Main`.
- Order Check's own C# 5 checker (no lambdas) on `OrderCheck.cs`.
- Order Check Node tests (10 rules groups, GitHub sharing, Firebase payload).
- Helper package, job card and startup tests (website script references include the board).
- ZIP and SHA-256 manifest verified from a fresh extract.

## Not verified here

Compilation and the 88 self-test groups run on the RDP PC.

---

# Validation — v1.9.0 — 3 October 2026

## Basis (diagnostics 3 Oct 23:39–23:41, helper 1.8.3)

- **Auto-fill runs:**
  - "The selected COSTAR is not ready to open a new order": the main window did not come forward.
  - "The target field is covered": the Repair Order was behind another window.
  - "Open one empty Repair Order": the window Add New returned was gone a moment later.
- **Manual run:** the phone matched several accounts. COSTAR showed its customer Search list (WinForms form, 53 controls; buttons Add new / Include Inactive / Print Results / Search / Cancel / OK / Clear). The helper pressed Cancel and entered a new customer. Later "no foreground window" stopped it at the first item.

## Changes

- `Native.BringToFront`: SetForegroundWindow, then a short AttachThreadInput to the active window's thread (BringWindowToTop + SetForegroundWindow), then SwitchToThisWindow. Used by `Runner.Activate`, popup recovery and `OpenNew`.
- `Runner.Check(foreground)`:
  - a null foreground is waited out (up to 1.5 s);
  - if another process holds the foreground, COSTAR's window is enabled, and no real user input arrived in the last 2 s (`Native.UserActiveWithin`, which ignores the helper's own SendInput), COSTAR is brought back, at most 3 times per run;
  - COSTAR popups are never bypassed.
- `CommitField` re-checks the foreground right before sending Tab.
- `OpenNew` returns a new Repair Order only after the same window has stayed visible and titled for 300 ms.
- **Account list:**
  - `Selectors.AccountChooser` accepts the OK button even when disabled.
  - `TryChooseFirstAccount`: highlight the top row (`Msaa` from Order Check: table → top row by screen position → `accSelect`, plus a click inside the list), wait for OK to enable, then BM_CLICK OK.
  - The popup's structure is captured once.
- **`OrderCheckLink`:**
  - reads Order Check's `targetKey` (PID@local start ticks) and matches it to the helper's UTC start ±2 s;
  - auto-select skips that window, and a manual pick is refused;
  - before online entry, GET `127.0.0.1:8795/wip.json` (1.5 s timeout) and refuse when a row's `po` equals the TTW number;
  - an absent or old Order Check never blocks.
- `Build.ps1` references `Accessibility.dll`.
- Self-tests 73: Order Check key/lookup, and the real Search-list shape.

## Checks performed here

Exact replacements reviewed. Bracket balance, C# 6+ syntax and loop-shadowing scans are clean. JavaScript/package tests pass. ZIP and manifest verified. Order Check 1.4.0: its own package, rules (10 groups), sharing and C# 5 checks all pass here.

## Not verified here

Compilation and self-tests (on the RDP PC). Whether COSTAR's grid accepts `accSelect` (the click on row 1 covers it). The exact WIP PO column name (Order Check reports it).

---

# Validation — v1.8.3 — 3 October 2026

## Basis

1.8.2 screenshot: "1 Tempe COSTAR windows found: choose one in the list above". The list was disabled and the status read "Mobile job pinned to its original instance". The journal held the 2 October 17:00 job as ready_for_review. Its COSTAR process and Repair Order window no longer existed.

## Cause

- The worker accepts a new job only after the journal job is closed.
- The desk closes a reviewed job by sending "close", which the worker acknowledges.
- `ApplyTargets` auto-selects only the pinned process while a pin exists. `UpdateStatus` disables the list while pinned.
- `Worker.Run("close")` required the pinned COSTAR before reaching its existing "window already gone" acknowledgement.
- Result: once COSTAR closed, nothing could be selected, closed or started.

## Changes

- `CostarWindows.OrderWindowGone(cp)`: the window no longer exists, or belongs to another process. `CostarWindows.PinnedProcessGone(cp)`: no COSTAR process with that PID, start time and session.
- `Worker.Run("close")`: the closed-or-gone acknowledgement now runs before the same-COSTAR requirement. Live windows are unchanged (same-COSTAR check, `ValidateTarget`, `CloseMobile`).
- `WorkerForm.ApplyTargets`: a pin whose window or process is gone ("dead pin") no longer restricts selection or locks the list. It is logged and explained. Live pins behave as before.
- `MobileRecovery.CanReset` unchanged: the existing safety tests (no reset after any entered field) still hold.
- Self-test 71: gone-window and gone-process recognition.

## Checks performed here

Counted replacements reviewed as diffs. Bracket balance, C# 6+ syntax and loop-shadowing scans are clean. JavaScript/package tests pass. ZIP and manifest verified. Compilation and self-tests run on the RDP PC.

## Known remaining edge

COSTAR closed **in the middle of** a mobile entry leaves a failed job with entered fields. It no longer locks the list, but the automatic reset deliberately refuses it. It needs its own guarded recovery, to be designed with care.

---

# Validation — v1.8.2 — 3 October 2026

## Basis: 1.8.1 day log and 1.6.1 runs (diagnostics of 3 October)

- **1.8.1:** started 4 times with no crash. An online order (TTW1730376) was refused with "Select a Branch 11 COSTAR instance above": no COSTAR target was selected. The helper never searched for COSTAR at startup, and the search result was not logged. Detection code was identical to 1.6.1 except the 1.8.0 window-title reading.
- **1.6.1 mobile:** 7.96 / 8.92 / 8.05 s.
  - DET lookup about 80 ms, but leave-grid needed 3 clicks (0.47–1.16 s) although the DET notes existed after the first click.
  - Checkpoint saves about 66 ms each (20 per job) even without forced flush.
  - One startup stop: "A COSTAR field is still loading" while COSTAR was busy (1.16 s) drawing the new order.

## Changes

- `Native.Class`, `Native.Caption`, `Native.TryText`: the 1.6.1 P/Invoke calls (StringBuilder, CharSet.Unicode), with one reused StringBuilder per thread and per kind. The unmanaged buffer code is removed.
- `CostarWindows.Choices` records what it saw (`LastScan`: COSTAR main-window titles and process-check failures). `WorkerForm`:
  - searches at startup;
  - `EnsureTarget()` before Start / resume mobile and before online Fill;
  - logs `costar_found` / `costar_not_found`;
  - explains a failed search in the log.
- `WaitForMobileStartup` waits while any control text read failed. The online reuse path uses `Settled(Current())`, up to 5 s.
- DET: `LeaveForDetNotes` clicks PO# once and accepts when the three DET notes exist and are stable. Otherwise it falls back to `LeaveGrid`.
- `PrivateFiles.Save` times JSON / encrypt / write / replace. `Worker.Persist` times the checkpoint copy. Per-run totals go in the run file, and the end-of-day page shows the per-save breakdown and any COSTAR-not-found searches.

## Checks performed here

Exact counted replacements reviewed as diffs. Bracket balance, C# 6+ syntax scan and loop-variable shadowing scan are clean. JavaScript/package tests pass. ZIP and SHA-256 manifest verified. No C# compiler or COSTAR here; compilation and the 70 self-tests run on the RDP PC.

---

# Validation — v1.8.1 (1.8.0 + day log) — 3 October 2026

## Added in 1.8.1

- `Diagnostics.cs`:
  - `AppLog`: a thread-safe, masked JSON-lines day log (`events-YYYYMMDD.jsonl`), working-set MB on every line, rate-limited desk-connection errors (first, every 20th, recovery), crash capture via `AppDomain.UnhandledException` (type, message, first 4 stack frames). Never throws.
  - Retention: day logs 180 days; saved bundles 30 days.
  - Bundle: adds `day-log/` (last 14 days). The summary now starts with `EndOfDay`: today, speed by version, things to look at. `Summary(reports)` is unchanged for callers.
  - `Popup` also records a text-free `popup_layout` (control kind, position, size, enabled).
- Hooks:
  - `Program`: app start, exit and startup crash.
  - `Worker`: mobile start/stop, job start (with resume step and job-card age), ready, failed, close, unstarted reset, connection drops and recovery.
  - `AutofillForm`: order loaded or failed to load, queue decisions, duplicate refusals, fill start (manual/auto, seconds after loading, queue length), fresh Repair Order opened beside one in use, Add New time, fill result (seconds, run file), queue paused, stop pressed.
  - `Runner.Dispose`: memory before and after the trim.
  - `WorkerForm`: **Add note** dialog, tab switches, Stop all, report saved.
- `MobileTests.cs`: 70 groups (adds the end-of-day page check, on synthetic data; tests never write to the real day log).

## Checks performed here

Exact counted replacements reviewed as diffs. C# tokenizer bracket balance, C# 6+ syntax scan, and a scan for loop variables that share a name with a lambda in their own header: all clean. Lambda-name overlaps are only in sibling scopes, the same patterns that compiled in 1.6.1. JavaScript/package tests pass. ZIP and SHA-256 manifest verified.

## Not verified here

Same as 1.8.0: no C# compiler or COSTAR in this environment. Compilation, the 70 self-tests and live behaviour are confirmed on the RDP machine.

---

# Validation — v1.8.0 lean build — 3 October 2026

## Basis

1.6.x diagnostics (4 runs, COSTAR 5.7.6.0, Tempe Branch 11): screen reading took 19–43% of each run; a 10.3 s mobile job made ~12,200 text reads (14 full form reads, 53 grid reads). A real capture shows the item grid has ~214 controls (100 edits, 51 statics, 32 buttons) of which the engine's grid logic uses the 5 column labels and the cells under them.

## Changes

- **Text reads (Native):** WM_GETTEXT, GetClassName and GetWindowText write into one reusable unmanaged buffer per thread (freed with the thread); previously each read allocated a 4,096-char StringBuilder plus a marshalled native copy.
- **Snapshot:** phase 1 collects geometry/class/state for all controls (local calls); phase 2 reads text only for the controls a read plan names. Skipped controls are marked and read on demand through `ControlInfo.Late` if anything asks (counted as late reads, first 20 logged). Button captions are read only for popups. Control classes are cached per window for the run.
- **Grid read plan:** after the grid labels are learned from a full read, grid reads take the 5 labels plus edits within each label's column tolerance (the same tolerance `ProductGrid`/`Cell` use). If a label disappears or its text changes, that snapshot is completed in full and the labels are learned again.
- **Label searches** (`Selectors.Label`, `Selectors.Header`) use only text that was actually read (`Peek`), so skipped display labels are never fetched.
- **Header cache:** `HeaderNow` reuses the last map while all 11 fields are the same windows, visible, enabled, same parent, same rectangle; returned fields are fresh copies read live on first use. Any change falls back to the previous full read.
- **Customer lookup:** `Selectors.AccountChooser` classifies a selection list (list control, or a WinForms form with a list area and exactly one OK/Select-type button; message boxes `#32770` excluded). `TryChooseFirstAccount` selects row 0 for list boxes, presses that button via BM_CLICK, or Enter only when no risky button exists; bounded to 2 attempts; the lookup then waits up to 5 s for the chosen account and never falls back to a new customer.
- **Online:** `RepairOrderInUseException` is raised before any input when a reused open order is not empty; the online tab then opens a fresh order (`OpenNew(...,allowExisting:true)` identifies the window that was not there before, and uses BM_CLICK if an open order covers Add New). `OrderQueue` + "Fill automatically" queue copied orders while one is entered, refuse duplicates and orders already entered this session, and pause after a stop.
- **Memory:** after each job, full GC + `EmptyWorkingSet`.
- **Diagnostics:** text reads, skipped, late and header-cache counts per run (summary SCREEN READS, CSV columns).
- **Self-tests:** 69 groups (adds read plan + on-demand reads, account chooser, order queue).

## Checks performed here

Exact counted replacements, reviewed as diffs against 1.6.1; every grid-snapshot consumer audited (only labels plus the five columns are used; totals and delivery checks use full reads); C# tokenizer bracket balance and C# 6+ syntax scan clean; JavaScript/package tests pass; ZIP and SHA-256 manifest verified.

## Not verified here

No C# compiler or COSTAR in this environment: compilation, the 69 self-tests, live read counts and the real two-account popup are confirmed on the RDP machine. 1.5.5–1.6.1 compiled there with the same toolchain.

---

# Validation — v1.6.1 speed build — 2 October 2026

## Basis (1.6.0 diagnostics, 2 runs on COSTAR 5.7.6.0)

- Mobile 10.3 s; leave-grid needed 3 attempts (1.18 s). Online pickup 5.2 s; leave-grid 3 attempts (0.53 s), the second re-click fired 44 ms after the first because COSTAR was briefly busy before processing the click.
- Mobile: 17 checkpoint saves between steps took 1.20 s (about 70 ms each).
- Existing customer lookup on an online pickup completed without a stop.

## Changes

- `CostarAutofill.cs`: before leaving the grid after DET, wait up to 1.5 s for the DET row's description (COSTAR's code lookup), then leave; if it does not fill, continue as 1.6.0 did. Leave-grid re-clicks after a settle only once 120 ms have passed since the click.
- `MobileModel.cs`: `PrivateFiles.Save` takes an optional `flush` flag (default true: unchanged for settings, desk queue and status reports).
- `Worker.cs`: checkpoint saves use `flush=false`; 1 s desk poll while mobile entry is enabled and not paused (3 s otherwise).
- `MobileTests.cs`: storage round-trip also covers `flush=false`.

## Checks performed here

Exact counted replacements reviewed as diffs; C# tokenizer balance and C# 6+ syntax scan clean; JavaScript/package tests pass; ZIP and SHA-256 manifest verified. C# compilation and the 66 self-tests run on the RDP machine at first launch (1.6.0 built there with the same toolchain).

---

# Validation — v1.6.0 speed build — 2 October 2026

## Basis

Changes target what the 1.5.5 diagnostics measured on 2 October (4 runs, COSTAR 5.7.6.0, Tempe Branch 11):
- DET: leaving the item grid failed its first click in both runs and waited a full 2 s before the second click worked.
- Mobile: about 2.9 s between steps, consistent with two encrypted checkpoint saves per step plus progress saves.
- Existing customer (TTW1730342): COSTAR did not answer for more than 2 s after the phone entry; the helper read the screen mid-redraw, found no labels and stopped with a layout error.

## Changes

- `CostarAutofill.cs`: `WaitIdle` (WM_NULL via SendMessageTimeout, abort-if-hung, capped) before every screen read, before Ready checks and before clicks; `HeaderNow` tolerates a brief header redraw (3 s cap, stops at once on focus loss); the customer lookup treats a missing header during redraw as transient within its existing 20 s limit; leave-grid re-clicks within 0.7 s and accepts PO# after COSTAR settles or after a 300 ms hold (6 s total budget, as before); shorter polls; 1 ms timer resolution during a run (released in Dispose); online Fill opens a Repair Order with the existing Add New routine when none is open.
- `MobileRunner.cs`: one checkpoint save per step (the pending marker), final save after the last step; pre-step re-read only for the first step of a run; customer-popup recovery limited to phone/name/reference steps; shorter startup/stability polls.
- `Worker.cs`: progress saves throttled to 2.5 s; checkpoint and progress save times sent to diagnostics.
- `Diagnostics.cs`: correct stop stage, idle-wait and save counters, time between steps, wait outcome labels, label-only layout fingerprint.
- `MobileTests.cs`: 66 groups (adds stop-stage, between-step and wait-label checks).

## Resume safety of the single save per step

Before each step the journal records all verified steps and marks the step pending. If entry stops after the step's input, the existing recovery compares COSTAR with the verified view: unchanged means not applied, exactly the step's change means applied, anything else stops without guessing. This is the same reconciliation used before; the removed "after" save only shortened what recovery had to re-check.

## Checks performed here

- Every edit applied as an exact, counted replacement and reviewed as a diff against 1.5.5.
- C# tokenizer bracket balance and a scan for C# 6+ syntax (`/langversion:5`): clean.
- JavaScript/package tests pass; ZIP and SHA-256 manifest verified.

## Not verified here

No Windows compiler or COSTAR is available in this environment. C# compilation, the 66 self-tests and live timing are verified by the first run on the RDP machine. 1.5.5 compiled and ran there with the same toolchain.
