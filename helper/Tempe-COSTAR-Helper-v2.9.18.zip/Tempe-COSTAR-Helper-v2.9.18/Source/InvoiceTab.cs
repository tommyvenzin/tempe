// 2.9.15 "Invoice read (dry run)" (spec of 20 Nov 2026): the RDP helper's Invoice tab, last after Wholesale so the other
// tabs keep their places. Read open invoice reads the COSTAR Invoice staff have already opened (InvoiceRun, on a thread
// of its own) and shows what was read and what Buffalo's delivery label would need; Copy Buffalo Details puts exactly
// the text of the Buffalo box on the clipboard (checked: read back, tried again). Reading never means sold or complete:
// the Sold button is always disabled and has nothing on its click (InvoiceDryRun.SellingEnabled is false). The timer
// only shows what the run has already read; nothing here looks at COSTAR.
using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed partial class WorkerForm {
        readonly TabPage invoicePage=new TabPage("Invoice");
        readonly Button invoiceRead=Ui.PrimaryButton("Read open invoice",190),invoiceStop=Ui.DangerButton("Stop",100),
            invoiceCopy=Ui.SecondaryButton("Copy Buffalo Details",190),invoiceSold=InvoiceUi.SoldButton(),
            invoiceFill=Ui.SecondaryButton("Fill Buffalo page",170),invoiceFillCancel=Ui.SecondaryButton("Cancel",90);
        readonly TextBox invoiceExpected=new TextBox {Width=170,Font=Ui.Base,Margin=new Padding(0,6,16,0)};
        readonly Label invoiceStatus=Ui.Text("Not read yet.",1000),invoiceCopyLine=Ui.Hint("",1000),invoiceFillLine=Ui.Hint("",1000);
        TextBox invoiceReview,invoiceBuffalo;
        volatile InvoiceRun invoiceRun;InvoiceOutcome invoiceShown;string invoiceBuffaloShown="";
        // The read is using COSTAR (for Stop all).
        // A read running, or a Buffalo fill waiting for a page (so Stop all can withdraw it).
        bool InvoiceBusy { get { var r=invoiceRun;if(r!=null&&r.Running) return true;var box=buffaloOutbox;return box!=null&&box.State=="waiting"; } }
        void BuildInvoicePage() {
            invoicePage.BackColor=Ui.Canvas;invoicePage.Padding=new Padding(0);
            var expectedRow=Ui.Row(36);expectedRow.Margin=new Padding(0,6,0,0);
            expectedRow.Controls.Add(new Label {Text="Expected invoice #:",AutoSize=true,Font=Ui.Base,ForeColor=Ui.Ink,Margin=new Padding(0,9,6,0)});
            expectedRow.Controls.Add(invoiceExpected);
            expectedRow.Controls.Add(Ui.Hint("Optional. When given, the open invoice must be this number, or nothing is prepared. Needed when more than one Invoice is open.",460));
            var rows=InvoiceUi.ButtonRows(invoiceRead,invoiceStop,invoiceSold,invoiceCopy,invoiceFill,invoiceFillCancel);
            var card=InvoiceUi.TopCard(Ui.Title("Invoice (dry run: read only)"),InvoiceUi.Intro(),expectedRow,rows[0],rows[1],invoiceStatus,invoiceCopyLine,invoiceFillLine);
            invoiceReview=InvoiceUi.Box();invoiceBuffalo=InvoiceUi.Box();
            var layout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=4,BackColor=Ui.Canvas,Padding=new Padding(0),Margin=new Padding(0)};
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,62));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,38));
            layout.Controls.Add(card,0,0);
            layout.Controls.Add(invoiceReview,0,1);
            layout.Controls.Add(new Label {Text="Buffalo details (what Copy puts on the clipboard)",AutoSize=true,Font=Ui.Bold,ForeColor=Ui.Ink,Margin=new Padding(0,8,0,4)},0,2);
            layout.Controls.Add(invoiceBuffalo,0,3);
            invoicePage.Controls.Add(layout);
            invoiceRead.Click+=delegate{DeskForm.Attempt(StartInvoiceRead);};
            invoiceStop.Click+=delegate{StopInvoice("Stop was pressed","stop");};
            invoiceCopy.Click+=delegate{DeskForm.Attempt(CopyInvoiceBuffalo);};
            invoiceFill.Click+=delegate{DeskForm.Attempt(FillInvoiceBuffalo);};
            invoiceFillCancel.Click+=delegate{var box=buffaloOutbox;if(box!=null&&box.Cancel()) AppLog.Note("buffalo_fill","cancelled");UpdateInvoiceTab();};
            // invoiceSold: no Click handler, ever (dry run).
            invoiceStop.Enabled=false;invoiceCopy.Enabled=false;invoiceFill.Enabled=false;invoiceFillCancel.Visible=false;
            invoiceReview.Text="Open the invoice in COSTAR, then press Read open invoice. What was read shows here: the invoice's identity, X (customer), Y (Ship to), "+
                "the header fields, every line with its exact Item, freight, the totals check, and anything missing or unclear.";
        }
        void StartInvoiceRead() {
            var last=invoiceRun;
            Order.Require(last==null||!last.Running,"The invoice is already being read.");
            Order.Require(!coordinator.Busy,(coordinator.Owner.Length>0?coordinator.Owner:"An entry")+" is using COSTAR: wait for it to finish, then press Read open invoice.");
            var run=new InvoiceRun(coordinator,invoiceExpected.Text);
            invoiceRun=run;invoiceShown=null;invoiceBuffaloShown="";
            var box=buffaloOutbox;if(box!=null&&box.Withdraw("you read another invoice")) AppLog.Note("buffalo_fill","withdrawn new_read");
            invoiceReview.Text="";invoiceBuffalo.Text="";Show(invoiceCopyLine,"");
            AppLog.Note("invoice_dry_run_start",invoiceExpected.Text.Trim().Length>0?"expected given":"no expected #");
            var thread=new Thread(delegate() { run.Run(); }) {IsBackground=true,Name="Invoice read (dry run)"};
            thread.Start();
            UpdateStatus();
        }
        // Stop (and Stop all, its hotkey, or closing): the read stops, and a Buffalo fill no page has taken yet is
        // withdrawn, saying which.
        void StopInvoice(string why,string logWord) {
            var run=invoiceRun;if(run!=null&&run.Running) { run.Cancel=true;run.Line="Stopping the read ..."; }
            var box=buffaloOutbox;if(box!=null&&box.Withdraw(why)) AppLog.Note("buffalo_fill","withdrawn "+logWord);
        }
        void UpdateInvoiceTab() {
            if(invoiceReview==null) return;
            var run=invoiceRun;bool running=run!=null&&run.Running;
            invoiceRead.Enabled=!running&&!coordinator.Busy;invoiceStop.Enabled=running;invoiceExpected.ReadOnly=running;
            if(run!=null) {
                if(running) Show(invoiceStatus,run.Line);
                else {
                    var o=run.Outcome;
                    if(o!=null&&!Object.ReferenceEquals(o,invoiceShown)) {
                        invoiceShown=o;
                        invoiceReview.Text=o.Review;invoiceBuffalo.Text=o.Buffalo;invoiceBuffaloShown=invoiceBuffalo.Text;
                        Show(invoiceStatus,o.Status);
                    }
                }
            }
            var shown=invoiceShown;
            invoiceCopy.Enabled=!running&&shown!=null&&shown.Read!=null&&invoiceBuffaloShown.Length>0;
            UpdateBuffaloFill(running,shown);
        }
        static void Show(Label label,string text) { text=text??"";if(label.Text!=text) label.Text=text; }
        // Exactly the Buffalo box's text (the one InvoicePreview.Buffalo gave for the read shown), checked on the clipboard.
        void CopyInvoiceBuffalo() {
            // An earlier "Copied ..." never stays on screen over a copy that didn't work.
            Show(invoiceCopyLine,"");
            var shown=invoiceShown;
            Order.Require(shown!=null&&shown.Read!=null&&invoiceBuffaloShown.Length>0,"Read an invoice first: there are no Buffalo details to copy.");
            string text=invoiceBuffalo.Text;
            Order.Require(text==invoiceBuffaloShown&&text==shown.Buffalo,"The Buffalo box doesn't hold what was prepared: press Read open invoice again.");
            int attempts;string why=InvoiceClipboard.Copy(text,out attempts);
            int count=InvoiceUi.LineCount(text);
            string tries=attempts<0?"unknown":attempts.ToString(System.Globalization.CultureInfo.InvariantCulture);
            AppLog.Note("invoice_copy",why==null?"copied lines="+count+" attempts="+tries:"not copied attempts="+tries);
            if(why!=null) Show(invoiceCopyLine,"Not copied: "+why+". Nothing was sent to Buffalo.");
            Order.Require(why==null,"The Buffalo details weren't copied: "+why+". Try Copy Buffalo Details again.");
            Show(invoiceCopyLine,"Copied the Buffalo details ("+count+" lines). Nothing was sent to Buffalo.");
        }

        // ---- 2.9.17: Fill Buffalo page (InvoiceBuffalo.cs) ----
        BuffaloOutbox buffaloOutbox;BuffaloLink buffaloLink;string buffaloProblem="",buffaloShipped="",buffaloFolder="",buffaloLoggedSeen="",buffaloLoggedProblem="",buffaloLoggedEnd="";
        // At start: the extension's files to their fixed folder, the key and pair.json, the loopback server. Whatever
        // fails only switches Fill off (with why); reading and Copy are untouched.
        void StartBuffaloLink() {
            try {
                string from=Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"..","BuffaloFill"));
                buffaloFolder=BuffaloKey.Folder;
                string copied=BuffaloExtensionFiles.Install(from,buffaloFolder);
                if(copied!=null) AppLog.Note("buffalo_ext_copy_failed",copied);
                buffaloShipped=BuffaloExtensionFiles.Version(from);
                var key=BuffaloKey.LoadOrCreate(BuffaloKey.Store);
                BuffaloKey.WritePair(buffaloFolder,key);
                var box=new BuffaloOutbox();
                var link=new BuffaloLink(key,box,AutofillForm.Version);
                string shipped=buffaloShipped,folder=buffaloFolder;
                link.ExtensionShipped=delegate { return shipped; };
                link.ExtensionOnDisk=delegate { return BuffaloExtensionFiles.Version(folder); };
                if(!link.Start()) { buffaloProblem=link.Problem;AppLog.Note("buffalo_link_off","ports");return; }
                buffaloOutbox=box;buffaloLink=link;
                if(copied!=null) buffaloProblem="the extension's files couldn't be updated in "+buffaloFolder+" ("+copied+")";
                AppLog.Note("buffalo_link_on","port="+link.Port.ToString(CultureInfo.InvariantCulture)+" ext="+shipped);
            } catch(Exception e) { buffaloProblem=e.GetType().Name+": "+e.Message;AppLog.Note("buffalo_link_off",e.GetType().Name); }
        }
        void StopBuffaloLink() {
            var box=buffaloOutbox;if(box!=null) box.Withdraw("the helper closed");
            var link=buffaloLink;if(link!=null) link.Stop();
        }
        void FillInvoiceBuffalo() {
            Show(invoiceFillLine,"");
            var shown=invoiceShown;var box=buffaloOutbox;
            Order.Require(box!=null&&buffaloLink!=null,"Fill Buffalo page is off: "+(buffaloProblem.Length>0?buffaloProblem:"the helper's link to Chrome didn't start")+".");
            Order.Require(shown!=null&&shown.Read!=null,"Read an invoice first: there is nothing to fill.");
            string why;var job=BuffaloJobs.Build(shown.Read,out why);
            Order.Require(job!=null,"Not filled: "+why+".");
            var at=box.FilledAt(job.invoice);
            if(at!=null) {
                // Worded by how that time ended (a refused one isn't asked about: nothing was typed).
                string how=box.FilledHow(job.invoice),when=at.Value.ToLocalTime().ToString("HH:mm",CultureInfo.InvariantCulture);
                string what=how=="filled"||how=="partial"?"was filled on a Buffalo page at "+when+" (it may already be saved in Buffalo)":
                    how=="failed"?"was sent to a Buffalo page at "+when+" and the fill stopped part way (that page may hold part of it, or have been saved)":
                    "was sent to a Buffalo page at "+when+", which didn't answer (it may have been filled, or saved)";
                var answer=MessageBox.Show(this,"Invoice "+job.invoice+" "+what+".\r\n\r\nFill it again?","Fill Buffalo page",MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2);
                if(answer!=DialogResult.Yes) return;
            }
            box.Offer(job);
            AppLog.Note("buffalo_fill","offered rows="+job.rows.Count.ToString(CultureInfo.InvariantCulture)+" rows_ready="+(job.rowsReady?"yes":"no")+
                " left="+BuffaloJobs.LeftBoxes(job).Count.ToString(CultureInfo.InvariantCulture)+" unresolved="+job.unresolvedCount.ToString(CultureInfo.InvariantCulture));
            UpdateInvoiceTab();
        }
        // The Fill button and its line, from the outbox (the server's thread changes it; this only reads).
        void UpdateBuffaloFill(bool running,InvoiceOutcome shown) {
            var box=buffaloOutbox;
            string state=box==null?"off":box.State;
            // 2.9.18: what the extension says about itself goes to the day log when it changes (its own words only).
            var link=buffaloLink;
            if(link!=null) {
                string seen=link.SeenVersion+"|"+link.SeenChrome,problem=link.SeenProblem;
                if(link.SeenUtc!=DateTime.MinValue&&seen!=buffaloLoggedSeen) { buffaloLoggedSeen=seen;AppLog.Note("buffalo_ext_seen","ext="+link.SeenVersion+" chrome="+link.SeenChrome); }
                if(problem!=buffaloLoggedProblem) { buffaloLoggedProblem=problem;if(problem.Length>0) AppLog.Note("buffalo_ext_problem",problem); }
            }
            // 2.9.18: how each offer ended, once, in fixed words (never the page's reasons or what was left for a person:
            // those can name a customer's suburb or e-mail).
            if(box!=null&&(state=="expired"||state=="silent"||state=="done")) {
                string end=state+"|"+box.OfferedUtc.Ticks.ToString(CultureInfo.InvariantCulture);
                if(end!=buffaloLoggedEnd) {
                    buffaloLoggedEnd=end;
                    string kind=link==null?"":InvoiceUi.ExpiredKind(link.SeenUtc,link.SeenVersion,link.SeenProblem,link.SeenProblemUtc,box.OfferedUtc,buffaloShipped);
                    AppLog.Note("buffalo_fill",InvoiceUi.EndWords(state,box.Result,kind,link==null?"":link.SeenVersion,link==null?"":link.SeenChrome));
                }
            }
            bool busy=state=="waiting"||state=="taken";
            string notFillable=shown==null||shown.Read==null?"read an invoice first":BuffaloJobs.NotFillable(shown.Read);
            invoiceFill.Enabled=box!=null&&!running&&!busy&&notFillable==null;
            invoiceFillCancel.Visible=state=="waiting";invoiceFillCancel.Enabled=state=="waiting";
            Show(invoiceFillLine,BuffaloLine(box,state,shown,notFillable));
        }
        string BuffaloLine(BuffaloOutbox box,string state,InvoiceOutcome shown,string notFillable) {
            if(box==null) return buffaloProblem.Length>0?"Fill Buffalo page is off: "+buffaloProblem+".":"";
            string n=box.Invoice??"";
            bool other=shown!=null&&shown.Read!=null&&n.Length>0&&shown.Read.Number!=n;
            string pre=other?"(Invoice "+n+", not the one shown) ":"";
            // The link runs, but something at start went wrong (the extension's files weren't updated): said until fixed.
            string problem=buffaloProblem.Length>0?" Fill may not work: "+buffaloProblem+".":"";
            switch(state) {
                case "waiting": return "Waiting for a blank Buffalo Create Consignment page in Chrome for invoice "+n+": switch to it ("+box.SecondsLeft.ToString(CultureInfo.InvariantCulture)+" s left). Nothing is saved there."+
                    InvoiceUi.ExtensionSays(buffaloLink)+problem;
                case "taken": return pre+"The Buffalo page is filling invoice "+n+" …";
                case "expired": return pre+"No blank Buffalo Create Consignment page took invoice "+n+" in "+BuffaloOutbox.OfferSeconds+" s: nothing was filled."+ExpiredWhy(box)+problem;
                case "silent": return pre+"The Buffalo page took invoice "+n+" but didn't answer: it may be part-filled. Check every box, or open a new Create Consignment page, before saving.";
                case "withdrawn": return "The Buffalo fill for invoice "+n+" was withdrawn ("+box.WithdrawnWhy+"): nothing was filled.";
                case "cancelled": return "Cancelled: nothing was filled for invoice "+n+".";
                case "done": return pre+Outcome(box.Result,n);
            }
            if(notFillable!=null&&shown!=null&&shown.Read!=null) return "Fill Buffalo page isn't available for this read: "+notFillable+"."+problem;
            return problem.Trim();
        }
        string ExpiredWhy(BuffaloOutbox box) {
            var link=buffaloLink;if(link==null) return "";
            return InvoiceUi.ExpiredWhy(link.SeenUtc,link.SeenVersion,link.SeenProblem,link.SeenProblemUtc,box.OfferedUtc,buffaloShipped,buffaloFolder);
        }
        static string Outcome(BuffaloResult r,string n) {
            if(r==null) return "";
            string left=r.left.Count>0?" Left for you: "+String.Join("; ",r.left)+".":"";
            switch(r.outcome) {
                case "filled": return "Filled the Buffalo page from invoice "+n+" ("+r.boxes+" receiver boxes, "+r.rows+" item rows). Check every box against the invoice, then Save it yourself in Buffalo."+left;
                case "partial": return "Filled what was ready on the Buffalo page from invoice "+n+" ("+r.boxes+" receiver boxes, "+r.rows+" item rows): NOT READY."+left+" Finish the highlighted boxes, check everything, then Save it yourself.";
                case "refused": return "The Buffalo page refused invoice "+n+": "+(r.why??"")+". Nothing was filled.";
                default: return "The fill for invoice "+n+" stopped part way: "+(r.why??"")+". Don't Save that page: open a new Create Consignment page and click Fill again.";
            }
        }
    }

    internal static class InvoiceUi {
        // 2.9.18: the buttons in two rows that never wrap, the read's and then Buffalo's. As one row of six they wrapped
        // at the helper's usual width, and the wrapped row was laid out taller than the card had measured it, which cut
        // off the lines under it: the Fill line ("Waiting for a blank Buffalo page …", and why nothing was filled).
        internal static FlowLayoutPanel[] ButtonRows(Button read,Button stop,Button sold,Button copy,Button fill,Button cancel) {
            var readRow=Ui.Row();readRow.Margin=new Padding(0,8,0,0);readRow.WrapContents=false;
            readRow.Controls.Add(read);readRow.Controls.Add(stop);readRow.Controls.Add(sold);
            var buffaloRow=Ui.Row();buffaloRow.Margin=new Padding(0,0,0,4);buffaloRow.WrapContents=false;
            buffaloRow.Controls.Add(copy);buffaloRow.Controls.Add(fill);buffaloRow.Controls.Add(cancel);
            return new[] {readRow,buffaloRow};
        }
        internal static Label Intro() {
            return Ui.Hint("Reads the COSTAR Invoice that is already open (open it in COSTAR first: any COSTAR, any branch) and prepares its details for review and for Buffalo delivery labels. "+
                "It never sells, saves, prints or books anything, in COSTAR or in Buffalo; in COSTAR it doesn't open or close anything, type, click, switch tabs or answer windows. "+
                "Fill Buffalo page only types these details into a blank Create Consignment page open in Chrome (with the Tempe Buffalo Fill extension), for you to check and Save yourself. "+
                "The only thing it may do in COSTAR is scroll the invoice's line list when there are more than 25 lines, and scroll it back: leave the PC alone while it reads. "+
                "Reading is not selling: Sold stays disabled. Customer details show here only and are never written to the day log.",820);
        }
        // The card at the top of the Invoice tab: its parts one under the other, in one panel (the card's only child).
        // 2.9.18: the card takes its height from that panel measured with each wrapping label at its MaximumSize, but lays it
        // out at the card's own inside width; a label measured wider than that wrapped onto more lines than the card had room
        // for, and the last lines (the Fill line) were cut off. So each wrapping label is kept to the card's inside width
        // (never wider than it was made). It is fitted when the card's parent starts a layout, before the card is measured
        // (the card spans its parent's width): fitted only once the card had its new size, a narrower window (after
        // maximise and restore, say) kept the card at the height measured for the wider one. Fitted again when the card's own
        // size changes, for any other parent.
        internal static Panel TopCard(params Control[] parts) {
            var card=Ui.Card();
            var lines=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Surface};
            foreach(var p in parts) lines.Controls.Add(p);
            card.Controls.Add(lines);card.Dock=DockStyle.Top;
            Control hooked=null;
            LayoutEventHandler before=delegate(object sender,LayoutEventArgs e) {
                var parent=card.Parent;if(parent==null) return;
                FitLabels(lines,parent.DisplayRectangle.Width-card.Margin.Horizontal-card.Padding.Horizontal);
            };
            card.ParentChanged+=delegate {
                if(hooked!=null) hooked.Layout-=before;
                hooked=card.Parent;if(hooked!=null) hooked.Layout+=before;
            };
            card.SizeChanged+=delegate { FitLabels(lines,card.DisplayRectangle.Width); };
            FitLabels(lines,card.DisplayRectangle.Width);
            return card;
        }
        static readonly System.Runtime.CompilerServices.ConditionalWeakTable<Label,object> madeWidth=new System.Runtime.CompilerServices.ConditionalWeakTable<Label,object>();
        internal static void FitLabels(Control lines,int width) {
            if(width<=0) return;
            foreach(Control c in lines.Controls) {
                var l=c as Label;if(l==null||!l.AutoSize) continue;
                int made=(int)madeWidth.GetValue(l,x=>x.MaximumSize.Width);
                if(made<=0) continue;
                int w=Math.Min(made,width);
                if(l.MaximumSize.Width!=w) l.MaximumSize=new Size(w,0);
            }
        }
        // While a fill waits: what the extension said in the last 20 s keeps the Buffalo page in front from taking it.
        internal static string ExtensionSays(BuffaloLink link) {
            if(link==null) return "";
            string problem=link.SeenProblem;DateTime at=link.SeenProblemUtc;
            if(problem.Length==0||(link.Now()-at).TotalSeconds>20) return "";
            return " Tempe Buffalo Fill says: "+problem+".";
        }
        // Why no page took the job, as far as the helper can tell: the extension isn't the version this helper ships
        // (whenever it was last seen: it then gets no job), it never called after the click (not installed from the
        // helper's folder, or no blank page in front), its check of the page failed, or it said what kept the page in front
        // from taking it. ExpiredKind names which, in fixed words for the day log.
        internal static string ExpiredKind(DateTime seenUtc,string seenVersion,string problem,DateTime problemUtc,DateTime offeredUtc,string shipped) {
            if((seenVersion.Length>0||seenUtc>=offeredUtc)&&seenVersion!=shipped) return "version";
            if(seenUtc<offeredUtc) return "no_contact";
            if(problem.Length>0&&problemUtc>=offeredUtc) return CheckFailed(problem)?"check_failed":"page_said";
            return "not_in_front";
        }
        // The extension's words for a page check that didn't work (background.js trouble()).
        internal static bool CheckFailed(string problem) {
            return problem.StartsWith("the page check failed",StringComparison.Ordinal)||problem.StartsWith("Chrome wouldn’t run the page check",StringComparison.Ordinal)||
                problem.StartsWith("Chrome gave no answer from the page check",StringComparison.Ordinal);
        }
        internal static string ExpiredWhy(DateTime seenUtc,string seenVersion,string problem,DateTime problemUtc,DateTime offeredUtc,string shipped,string folder) {
            switch(ExpiredKind(seenUtc,seenVersion,problem,problemUtc,offeredUtc,shipped)) {
                case "version": return " Tempe Buffalo Fill in Chrome is "+(seenVersion.Length>0?seenVersion:"another version")+" but this helper ships "+shipped+
                    ": click Reload on it in chrome://extensions, refresh the Buffalo page, then click Fill again.";
                case "no_contact": return " Tempe Buffalo Fill in Chrome didn't contact the helper in that time. Is it installed from the helper's folder (chrome://extensions, Load unpacked, "+folder+
                    "), and was a blank Create Consignment page in front? If its button says \"Not set up\", click Remove on it in chrome://extensions and load that folder instead. Then click Fill again.";
                case "check_failed": return " Tempe Buffalo Fill couldn't check the Buffalo page: "+problem+". Fill can't work on that page yet: use Copy Buffalo Details, then Save diagnostics and send them.";
                case "page_said": return " Tempe Buffalo Fill said the Buffalo page in front couldn't take it: "+problem+". Open a new Create Consignment page, keep it in front, then click Fill again.";
                default: return " Open a blank one in Chrome and keep it in front, then click Fill again.";
            }
        }
        // The day log's line for how an offer ended: fixed words and counts only.
        internal static string EndWords(string state,BuffaloResult r,string kind,string ext,string chrome) {
            if(state=="expired") return "expired why="+(kind.Length>0?kind:"unknown")+" ext="+(ext.Length>0?ext:"none")+" chrome="+(chrome.Length>0?chrome:"unknown");
            if(state=="done"&&r!=null) {
                string o=r.outcome=="filled"||r.outcome=="partial"||r.outcome=="refused"||r.outcome=="failed"?r.outcome:"other";
                return "done outcome="+o+" boxes="+r.boxes.ToString(CultureInfo.InvariantCulture)+" rows="+r.rows.ToString(CultureInfo.InvariantCulture)+" left="+r.left.Count.ToString(CultureInfo.InvariantCulture);
            }
            return state=="silent"?"silent":"ended "+(state=="done"?"done":"other");
        }
        // The Sold action exists only as this button: always disabled, nothing on its click.
        internal static Button SoldButton() {
            var b=Ui.SecondaryButton("Sold (disabled in dry run)",210);
            b.Enabled=false;
            return b;
        }
        // How many handlers a button's Click has (-1: it can't be told).
        internal static int ClickHandlers(Control c) {
            try {
                var key=typeof(Control).GetField("EventClick",BindingFlags.NonPublic|BindingFlags.Static);
                var events=typeof(Component).GetProperty("Events",BindingFlags.NonPublic|BindingFlags.Instance);
                if(key==null||events==null) return -1;
                var list=events.GetValue(c,null) as EventHandlerList;
                if(list==null) return -1;
                var d=list[key.GetValue(null)];
                return d==null?0:d.GetInvocationList().Length;
            } catch(Exception) { return -1; }
        }
        // A large read-only monospace box (fixed-width columns line up).
        internal static TextBox Box() {
            return new TextBox {Multiline=true,ReadOnly=true,WordWrap=false,ScrollBars=ScrollBars.Both,Dock=DockStyle.Fill,Font=new Font("Consolas",9.5F),
                BackColor=Ui.Surface,ForeColor=Ui.Ink,BorderStyle=BorderStyle.FixedSingle,HideSelection=false,Margin=new Padding(0)};
        }
        internal static int LineCount(string text) {
            if(String.IsNullOrEmpty(text)) return 0;
            var lines=text.Replace("\r\n","\n").Split('\n').ToList();
            while(lines.Count>0&&lines[lines.Count-1].Length==0) lines.RemoveAt(lines.Count-1);
            return lines.Count;
        }
    }

    // The Windows clipboard, on an STA thread of its own (ported from Ebay-auto's RoClipboard): Unicode text, set, then
    // read back; tried up to Attempts times. Only ever on a person's click of Copy Buffalo Details.
    internal static class InvoiceClipboard {
        internal const int Attempts=3,PauseMs=250,TimeoutMs=8000;
        // Pure: set, then read back, up to Attempts times; null once exactly text was read back, else why not.
        internal static string CopyChecked(string text,Action<string> set,Func<string> get,Action<int> pause,out int attempts) {
            return CopyChecked(text,set,get,pause,null,out attempts);
        }
        // given up: once true (the caller stopped waiting), nothing more is put on the clipboard.
        internal static string CopyChecked(string text,Action<string> set,Func<string> get,Action<int> pause,Func<bool> givenUp,out int attempts) {
            string why="not tried";attempts=0;
            for(int i=1;i<=Attempts;i++) {
                if(givenUp!=null&&givenUp()) return "given up (the clipboard didn't answer in time)";
                attempts=i;
                try {
                    set(text);
                    string back=get();
                    if(back==text) return null;
                    why=String.IsNullOrEmpty(back)?"nothing was read back":"something else was read back ("+back.Length+" characters)";
                } catch(Exception e) { why=Failure(e); }
                if(i<Attempts) pause(PauseMs);
            }
            return why;
        }
        static string Failure(Exception e) {
            return e is ExternalException?"the clipboard was busy ("+e.GetType().Name+")":e.GetType().Name+": "+Sanitize.Text(e.Message,120);
        }
        internal const string TimedOut="the clipboard didn't answer within 8 s (a copy still under way may land late: check what you paste)";
        // Copies text: null once it was read back the same, else why not. attempts: -1 when it timed out (unknown).
        internal static string Copy(string text,out int attempts) {
            int tries=0;var gaveUp=new bool[1];
            string why=OnSta(delegate {
                return CopyChecked(text,
                    delegate(string t) { if(Volatile.Read(ref gaveUp[0])) return;var data=new DataObject();data.SetData(DataFormats.UnicodeText,false,t);Clipboard.SetDataObject(data,true,10,100); },
                    delegate { return Clipboard.ContainsText(TextDataFormat.UnicodeText)?Clipboard.GetText(TextDataFormat.UnicodeText):null; },
                    delegate(int ms) { Thread.Sleep(ms); },delegate { return Volatile.Read(ref gaveUp[0]); },out tries);
            },delegate { Volatile.Write(ref gaveUp[0],true); });
            attempts=why==TimedOut?-1:tries;
            return why;
        }
        static string OnSta(Func<string> work,Action giveUp) {
            string result="not done";
            var thread=new Thread(delegate() { try { result=work(); } catch(Exception e) { result=Failure(e); } });
            thread.SetApartmentState(ApartmentState.STA);thread.IsBackground=true;thread.Name="Invoice clipboard";
            thread.Start();
            if(!thread.Join(TimeoutMs)) { giveUp();return TimedOut; }
            return result;
        }
    }
}
