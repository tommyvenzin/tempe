// 2.9.17 "Fill Buffalo page" (Tommy, 26 Nov 2026: "copy to buffalo button will automatically copy paste all the info and
// pass it to the correct box on the opened buffalo page"; Chrome inside the RDP, one click in the helper, and when NOT
// READY fill what is ready). The helper never touches Buffalo itself: it hands a job (the Buffalo details as data, built
// next to the Buffalo text from the same rules) to the Tempe Buffalo Fill extension in Chrome on this PC, which types them
// into a blank Create Consignment page for a person to check and Save. Nothing here touches COSTAR either (this file is
// under Build.ps1's invoice guard).
//  - The job: receiver boxes (each a value or UNRESOLVED with why), item rows only when every line is settled
//    (all-or-nothing), the stops the text gives, the note lines. No SKUs, prices, X fields or COSTAR account.
//  - The link: a loopback server of its own (127.0.0.1:8811-8840, independent of Order Check), both directions signed
//    with a key that never crosses the wire (HMAC-SHA256; the key is in this Windows user's profile only, written to the
//    extension's folder for it to read). Other Windows users on the RDP server can't take a job or forge one.
//  - The outbox: one job, tied to the read shown, withdrawn on a new read, offered for 45 s, taken once, answered once.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    // ---- the job (JSON field names are the extension's) ----
    // A receiver box: exactly one of value (may be "" for a box Buffalo allows blank) and unresolved (why).
    public sealed class BuffaloBox { public string value;public string unresolved; }
    public sealed class BuffaloPlace { public string suburb;public string state;public string postcode;public string unresolved; }
    public sealed class BuffaloRow { public string reference;public int qty;public string description;public int unitKg;public int weight; }
    public sealed class BuffaloJob {
        public int schema=BuffaloLink.Schema;public string id;public string invoice;public string branch;
        public bool ready;public int unresolvedCount;
        public BuffaloBox name,address1,email,contact,phone,reference;public BuffaloPlace suburb;
        public bool rowsReady;public List<string> rowsWhy=new List<string>();public List<BuffaloRow> rows=new List<BuffaloRow>();
        public List<string> stops=new List<string>();public List<int> notes=new List<int>();
    }
    // What the extension says it did (no customer words: counts and the reasons it gives).
    public sealed class BuffaloResult {
        public string id;public string outcome;public int boxes;public int rows;public List<string> left=new List<string>();public string why;
    }

    internal static class BuffaloJobs {
        // Why the read shown can't be filled at all (null: it can).
        internal static string NotFillable(InvoiceRead r) {
            if(r==null||r.Refused!=null) return "read an invoice first";
            if(r.ReadAgain!=null) return r.ReadAgain;
            if(!r.YShown) return "Ship to wasn't read ("+(r.YWhy??"not read")+")";
            if(String.IsNullOrEmpty(r.Number)) return "the invoice's number wasn't read: press Read again";
            // The number is the receiver's and every row's Reference: with < or > (as any box) it's left to a person.
            if(r.Number.IndexOf('<')>=0||r.Number.IndexOf('>')>=0) return "the invoice's number has < or > in it: type the details in Buffalo yourself";
            return null;
        }
        // The job for the read shown, built with the same rules (and counted the same way) as the Buffalo text.
        internal static BuffaloJob Build(InvoiceRead r,out string notFillable) {
            notFillable=NotFillable(r);
            if(notFillable!=null) return null;
            var j=new BuffaloJob {id=Wire.Token().Substring(0,16),invoice=r.Number,branch=r.Branch>0?r.Branch.ToString(CultureInfo.InvariantCulture):""};
            j.unresolvedCount=InvoicePreview.Unresolved(r);j.ready=j.unresolvedCount==0;
            j.name=Needed(r,"y.name");j.address1=Needed(r,"y.addr1");
            j.email=Optional(r,"y.email");j.contact=Optional(r,"y.contact");j.phone=Phone(r);
            j.reference=new BuffaloBox {value=r.Number};
            j.suburb=Place(r);
            // The item rows: all or nothing.
            var counted=r.Lines.Where(l=>l.Kind!="note").Select(BuffaloRules.Classify).ToList();
            var items=counted.Where(x=>x.Type!=null).ToList();
            foreach(var x in counted.Where(x=>x.Unresolved)) j.stops.Add("line "+x.Number.ToString(CultureInfo.InvariantCulture)+": "+x.How);
            if(counted.Any(x=>x.Unresolved)) j.rowsWhy.Add("a line is UNRESOLVED");
            var fit=counted.FirstOrDefault(x=>x.Fitting);
            if(fit!=null&&items.Any(x=>x.Type!=BuffaloRules.Carton||x.Wheel)) {
                j.rowsWhy.Add("a fitting, balancing or labour charge beside tyres or wheels");
                j.stops.Add("line "+fit.Number.ToString(CultureInfo.InvariantCulture)+" is a fitting, balancing, changeover, nitrogen or labour charge beside tyres or wheels: were they sent fitted (a wheel and tyre package)?");
            }
            if(items.Count==0&&!counted.Any(x=>x.Unresolved)&&r.LinesComplete) { j.rowsWhy.Add("nothing on the invoice to send");j.stops.Add("nothing on the invoice to send (no tyre, wheel or small box)"); }
            if(!r.LinesComplete) { j.rowsWhy.Add("the lines are incomplete");j.stops.Add("the lines are INCOMPLETE: "+(r.LinesWhy??"not read")); }
            else if(!InvoicePreview.LinesAddUp(r)) { j.rowsWhy.Add("the lines don't add up to the invoice total");j.stops.Add((r.CrossCheck??"the lines weren't checked against the invoice total")+" (a line may be missing)"); }
            if(r.Incomplete.Any(w=>w!=null&&w.StartsWith("line ",StringComparison.Ordinal))) j.rowsWhy.Add("a line wasn't fully read");
            if(!InvoicePreview.Done(r)) j.stops.Add("the read is INCOMPLETE: "+String.Join("; ",InvoicePreview.Reasons(r)));
            j.rowsReady=j.rowsWhy.Count==0&&items.Count>0;
            if(j.rowsReady) {
                foreach(var type in BuffaloRules.Types) {
                    int qty=items.Where(x=>x.Type==type).Sum(x=>x.Qty);
                    if(qty==0) continue;
                    int kg=BuffaloRules.Kg(type);
                    j.rows.Add(new BuffaloRow {reference=r.Number,qty=qty,description=type,unitKg=kg,weight=qty*kg});
                }
            }
            j.notes=r.Lines.Where(l=>l.Kind=="note").Select(l=>l.Number).ToList();
            // Receiver gaps are counted in the text too: a receiver box left for the person isn't a stop of its own.
            return j;
        }
        // Text only on the Buffalo page, but a value with < or > is left for a person to type (it would only ever be
        // shown as text, never run, but it can't be told from a typing mistake).
        static BuffaloBox Value(string v) {
            if(v!=null&&(v.IndexOf('<')>=0||v.IndexOf('>')>=0)) return new BuffaloBox {unresolved="it contains < or >: type it in Buffalo yourself"};
            return new BuffaloBox {value=v??""};
        }
        static InvoiceField Field(InvoiceRead r,string role) { return r.Fields.FirstOrDefault(x=>x.Role==role); }
        // As InvoicePreview's Needed: unread or empty is UNRESOLVED.
        static BuffaloBox Needed(InvoiceRead r,string role) {
            var f=Field(r,role);
            if(f==null||f.State=="not read") return new BuffaloBox {unresolved="not read on Ship to"};
            if(String.IsNullOrEmpty(f.Value)) return new BuffaloBox {unresolved="empty on Ship to"};
            return Value(f.Value);
        }
        // As Optional: unread is UNRESOLVED, empty is a blank box.
        static BuffaloBox Optional(InvoiceRead r,string role) {
            var f=Field(r,role);
            if(f==null||f.State=="not read") return new BuffaloBox {unresolved="not read on Ship to"};
            return Value(f.Value??"");
        }
        // As Phone: Mobile Ph, else Bus Ph, else Home Ph; one unread before the one used: can't tell.
        static BuffaloBox Phone(InvoiceRead r) {
            foreach(var p in new[]{new[]{"y.mobile","Mobile Ph"},new[]{"y.busph","Bus Ph"},new[]{"y.homeph","Home Ph"}}) {
                var f=Field(r,p[0]);
                if(f==null||f.State=="not read") return new BuffaloBox {unresolved="Ship to's "+p[1]+" wasn't read"};
                if(!String.IsNullOrEmpty(f.Value)) return Value(f.Value);
            }
            return new BuffaloBox {value=""};
        }
        // The suburb with Ship to's state and postcode: Buffalo's list is picked from only when all three are known.
        static BuffaloPlace Place(InvoiceRead r) {
            var s=Needed(r,"y.suburb");
            var st=Field(r,"y.state");var pc=Field(r,"y.postcode");
            var p=new BuffaloPlace {suburb=s.value,state=st==null?null:st.Value,postcode=pc==null?null:pc.Value};
            if(s.unresolved!=null) { p.suburb=null;p.unresolved=s.unresolved;return p; }
            if(String.IsNullOrEmpty(p.state)||String.IsNullOrEmpty(p.postcode)) { p.unresolved="Ship to's state or postcode wasn't read or is empty: pick the suburb from Buffalo's list yourself";return p; }
            if(Value(p.state).unresolved!=null||Value(p.postcode).unresolved!=null) { p.unresolved="it contains < or >: pick it from Buffalo's list yourself";p.suburb=null;return p; }
            return p;
        }
        // Receiver boxes the job leaves for a person (for the helper's status line; no customer words).
        internal static List<string> LeftBoxes(BuffaloJob j) {
            var l=new List<string>();
            if(j==null) return l;
            if(j.name.unresolved!=null) l.Add("Name");if(j.address1.unresolved!=null) l.Add("Address");if(j.suburb.unresolved!=null) l.Add("Suburb");
            if(j.email.unresolved!=null) l.Add("Email");if(j.contact.unresolved!=null) l.Add("Contact");if(j.phone.unresolved!=null) l.Add("Phone");
            return l;
        }
    }

    // ---- the outbox: one job at a time, shared by the window's thread and the server's ----
    internal sealed class BuffaloOutbox {
        internal const int OfferSeconds=45,ResultSeconds=30;
        readonly object gate=new object();
        BuffaloJob job;DateTime offeredUtc,takenUtc,endedUtc;string state="none",line="";BuffaloResult result;
        readonly Dictionary<string,DateTime> filled=new Dictionary<string,DateTime>(StringComparer.Ordinal);
        // How that last time ended: taken, silent (no answer), filled, partial or failed (for the question's words).
        readonly Dictionary<string,string> filledHow=new Dictionary<string,string>(StringComparer.Ordinal);
        DateTime? filledBefore;string howBefore;   // the guard as it was before this job was taken (put back when it's refused)
        internal Func<DateTime> Now=delegate { return DateTime.UtcNow; };
        // States: none, waiting (offered), taken, done (answered), expired, withdrawn, cancelled, silent (taken, no answer).
        internal string State { get { lock(gate) { Tick();return state; } } }
        internal string Invoice { get { lock(gate) return job==null?null:job.invoice; } }
        internal BuffaloResult Result { get { lock(gate) return result; } }
        // When this invoice's job was last taken by a Buffalo page in this helper's run and not refused (the duplicate
        // guard: something may have been typed, and the page may have been saved).
        internal DateTime? FilledAt(string invoice) { lock(gate) { Tick();DateTime t;return invoice!=null&&filled.TryGetValue(invoice,out t)?(DateTime?)t:null; } }
        internal string FilledHow(string invoice) { lock(gate) { Tick();string h;return invoice!=null&&filledHow.TryGetValue(invoice,out h)?h:null; } }
        internal void Offer(BuffaloJob j) { lock(gate) { job=j;offeredUtc=Now();state="waiting";result=null;line=""; } }
        // A new read, Stop, unpairing or closing: a job nobody took goes; one being filled keeps its answer.
        internal bool Withdraw(string why) {
            lock(gate) {
                Tick();
                if(state!="waiting") return false;
                state="withdrawn";line=why;endedUtc=Now();return true;
            }
        }
        internal bool Cancel() { lock(gate) { Tick();if(state!="waiting") return false;state="cancelled";endedUtc=Now();return true; } }
        void Tick() {
            var now=Now();
            if(state=="waiting"&&(now-offeredUtc).TotalSeconds>OfferSeconds) { state="expired";endedUtc=now; }
            else if(state=="taken"&&(now-takenUtc).TotalSeconds>ResultSeconds) { state="silent";endedUtc=now;if(job!=null) filledHow[job.invoice]="silent"; }
        }
        // The server's side: the job on offer (null: none).
        internal BuffaloJob Offered() { lock(gate) { Tick();return state=="waiting"?job:null; } }
        internal bool Take(string id) {
            lock(gate) {
                Tick();
                if(state!="waiting"||job==null||id!=job.id) return false;
                DateTime was;filledBefore=filled.TryGetValue(job.invoice,out was)?(DateTime?)was:null;
                string how;howBefore=filledHow.TryGetValue(job.invoice,out how)?how:null;
                state="taken";takenUtc=Now();filled[job.invoice]=takenUtc;filledHow[job.invoice]="taken";return true;
            }
        }
        // One answer, for the job taken (a late answer after "silent" still counts: it's the truth). A refusal typed
        // nothing, so the duplicate guard goes back to what it was.
        internal bool Answer(BuffaloResult r) {
            lock(gate) {
                Tick();
                if(job==null||r==null||r.id!=job.id||(state!="taken"&&state!="silent")) return false;
                if(r.outcome=="refused") {
                    if(filledBefore.HasValue) filled[job.invoice]=filledBefore.Value;else filled.Remove(job.invoice);
                    if(howBefore!=null) filledHow[job.invoice]=howBefore;else filledHow.Remove(job.invoice);
                } else filledHow[job.invoice]=r.outcome;
                result=r;state="done";endedUtc=Now();return true;
            }
        }
        internal int SecondsLeft { get { lock(gate) { Tick();return state=="waiting"?Math.Max(0,OfferSeconds-(int)(Now()-offeredUtc).TotalSeconds):0; } } }
        internal DateTime OfferedUtc { get { lock(gate) return offeredUtc; } }
        internal string WithdrawnWhy { get { lock(gate) return line; } }
    }

    // ---- the key: 32 random bytes in this Windows user's profile (DPAPI), and the extension's copy ----
    public sealed class BuffaloKeyFile { public string key;public string created; }
    internal static class BuffaloKey {
        internal static string Store { get { return Path.Combine(AppData.Home,"buffalo-fill.dat"); } }
        internal static string Folder { get { return Path.Combine(AppData.Home,"BuffaloFill"); } }
        internal static byte[] LoadOrCreate(string store) {
            try {
                var k=PrivateFiles.Load<BuffaloKeyFile>(store);
                if(k!=null&&!String.IsNullOrEmpty(k.key)) { var b=FromB64Url(k.key);if(b!=null&&b.Length==32) return b; }
            } catch(Exception e) { AppLog.Note("buffalo_key_unreadable",e.GetType().Name); }
            var bytes=new byte[32];using(var rng=RandomNumberGenerator.Create()) rng.GetBytes(bytes);
            PrivateFiles.Save(store,new BuffaloKeyFile {key=B64Url(bytes),created=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture)});
            return bytes;
        }
        // pair.json in the extension's folder (this user's profile only): the extension reads it with its own URL.
        internal static void WritePair(string folder,byte[] key) {
            Directory.CreateDirectory(folder);
            string path=Path.Combine(folder,"pair.json"),json="{\"v\":1,\"key\":\""+B64Url(key)+"\"}";
            if(File.Exists(path)&&File.ReadAllText(path,Encoding.UTF8)==json) return;
            string temp=path+"."+Guid.NewGuid().ToString("N")+".tmp";
            File.WriteAllText(temp,json,new UTF8Encoding(false));
            if(File.Exists(path)) File.Replace(temp,path,null);else File.Move(temp,path);
        }
        internal static string B64Url(byte[] b) { return Convert.ToBase64String(b).TrimEnd('=').Replace('+','-').Replace('/','_'); }
        internal static byte[] FromB64Url(string s) {
            try { s=(s??"").Replace('-','+').Replace('_','/');while(s.Length%4!=0) s+="=";return Convert.FromBase64String(s); } catch(FormatException) { return null; }
        }
    }

    // ---- the extension's files: shipped in the package's BuffaloFill folder, copied to the fixed folder Chrome loads ----
    internal static class BuffaloExtensionFiles {
        // The files the extension is made of (pair.json is the helper's, never copied over).
        internal static readonly string[] Names={"manifest.json","background.js","content.js","fill.js","popup.html","popup.js","icon48.png","icon128.png"};
        // Copies when anything differs: into a fresh folder beside the target, checked, then file by file with the
        // manifest last. Returns null when the target holds the package's files, else why not.
        internal static string Install(string from,string to) {
            try {
                if(!Directory.Exists(from)) return "the package has no BuffaloFill folder";
                foreach(var n in Names) if(!File.Exists(Path.Combine(from,n))) return "the package's BuffaloFill folder lacks "+n;
                Directory.CreateDirectory(to);
                var changed=Names.Where(n=>!Same(Path.Combine(from,n),Path.Combine(to,n))).ToList();
                if(changed.Count==0) return null;
                string incoming=Path.Combine(Path.GetDirectoryName(to.TrimEnd('\\','/'))??to,"BuffaloFill.incoming-"+Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(incoming);
                try {
                    foreach(var n in changed) {
                        File.Copy(Path.Combine(from,n),Path.Combine(incoming,n),true);
                        if(!Same(Path.Combine(from,n),Path.Combine(incoming,n))) return "a copy of "+n+" didn't match";
                    }
                    foreach(var n in changed.Where(n=>n!="manifest.json").Concat(changed.Where(n=>n=="manifest.json"))) {
                        string src=Path.Combine(incoming,n),dst=Path.Combine(to,n);
                        if(File.Exists(dst)) File.Replace(src,dst,null);else File.Move(src,dst);
                    }
                } finally { try { Directory.Delete(incoming,true); } catch(Exception) { } }
                foreach(var n in Names) if(!Same(Path.Combine(from,n),Path.Combine(to,n))) return n+" didn't update";
                return null;
            } catch(Exception e) { return e.GetType().Name+": "+e.Message; }
        }
        static bool Same(string a,string b) {
            if(!File.Exists(a)||!File.Exists(b)) return false;
            return Wire.Equal(Wire.Hash(File.ReadAllBytes(a)),Wire.Hash(File.ReadAllBytes(b)));
        }
        // The version in a folder's manifest.json ("" when it can't be read).
        internal static string Version(string folder) {
            try {
                string text=File.ReadAllText(Path.Combine(folder,"manifest.json"),Encoding.UTF8);
                var m=Regex.Match(text,"\"version\"\\s*:\\s*\"([0-9.]+)\"");
                return m.Success?m.Groups[1].Value:"";
            } catch(Exception) { return ""; }
        }
    }

    // ---- the link: a loopback server of its own, every request and answer signed ----
    internal sealed class BuffaloLink {
        internal const int Schema=1,FirstPort=8811,Ports=30,SkewSeconds=60;
        internal const string App="Tempe Buffalo Fill";
        readonly byte[] key;readonly BuffaloOutbox outbox;readonly string helperVersion;
        internal Func<string> ExtensionShipped=delegate { return ""; };
        internal Func<string> ExtensionOnDisk=delegate { return ""; };
        TcpListener listener;Thread thread;volatile bool stopping;
        internal int Port;internal string Problem="";
        // When this server took its port: a request signed before then was sent to someone else (a copy kept by whoever
        // held the port before is refused, nonces being new after a restart).
        DateTime startedUtc=DateTime.MinValue;
        // At most this many connections at once, each given this long in all: slow or many connections (another user on
        // the RDP server) are dropped instead of holding the helper's shared worker threads.
        internal const int MaxConnections=8;internal int RequestMillis=2500;
        readonly SemaphoreSlim slots=new SemaphoreSlim(MaxConnections,MaxConnections);
        readonly object nonceGate=new object();readonly Dictionary<string,DateTime> nonces=new Dictionary<string,DateTime>(StringComparer.Ordinal);
        // What the extension last told the helper (for the status line): when, its version, its Chrome's version (2.9.18),
        // and what it last said keeps the Buffalo page in front from taking a job ("" once a page has asked for one).
        internal DateTime SeenUtc=DateTime.MinValue;internal string SeenVersion="";
        internal string SeenChrome="",SeenProblem="";internal DateTime SeenProblemUtc=DateTime.MinValue;
        internal Func<DateTime> Now=delegate { return DateTime.UtcNow; };

        internal BuffaloLink(byte[] key,BuffaloOutbox outbox,string helperVersion) { this.key=key;this.outbox=outbox;this.helperVersion=helperVersion; }

        internal bool Start(int first=FirstPort,int count=Ports) {
            Exception firstError=null;
            for(int p=first;p<first+count&&listener==null;p++) {
                TcpListener attempt=null;
                try { attempt=new TcpListener(IPAddress.Loopback,p);attempt.ExclusiveAddressUse=true;attempt.Start(16);listener=attempt;Port=p;startedUtc=Now(); }
                catch(Exception e) { if(firstError==null) firstError=e;try { if(attempt!=null) attempt.Stop(); } catch(Exception) { } }
            }
            if(listener==null) { Problem="Ports "+first+"-"+(first+count-1)+" are all in use, so the Buffalo page can't reach the helper ("+(firstError==null?"":firstError.GetType().Name)+")";return false; }
            thread=new Thread(Accept) {IsBackground=true,Name="Buffalo link"};thread.Start();
            return true;
        }
        internal void Stop() { stopping=true;try { if(listener!=null) listener.Stop(); } catch(Exception) { } }
        void Accept() {
            while(!stopping) {
                TcpClient client;
                try { client=listener.AcceptTcpClient(); } catch(Exception) { if(stopping) return;Thread.Sleep(200);continue; }
                if(!slots.Wait(0)) { try { client.Close(); } catch(Exception) { } continue; }
                ThreadPool.QueueUserWorkItem(delegate { try { Serve(client); } finally { slots.Release(); } });
            }
        }
        void Serve(TcpClient client) {
            try {
                using(client)
                using(new Timer(delegate { try { client.Close(); } catch(Exception) { } },null,RequestMillis,Timeout.Infinite)) {
                    client.ReceiveTimeout=RequestMillis;client.SendTimeout=RequestMillis;
                    var s=client.GetStream();
                    var req=TempeOrderCheck.Http.Read(s);
                    var resp=req==null?TempeOrderCheck.Http.Error(400,"Bad Request","Bad request"):Route(req);
                    var bytes=TempeOrderCheck.Http.Serialize(resp);s.Write(bytes,0,bytes.Length);
                }
            } catch(Exception) { }
        }

        // ---- the signatures (the extension's background.js computes the same) ----
        internal static string Hex(byte[] b) { var sb=new StringBuilder(b.Length*2);foreach(var x in b) sb.Append(x.ToString("x2",CultureInfo.InvariantCulture));return sb.ToString(); }
        internal static string Sha(byte[] data) { using(var h=SHA256.Create()) return Hex(h.ComputeHash(data??new byte[0])); }
        internal static string Mac(byte[] key,string text) { using(var h=new HMACSHA256(key)) return Hex(h.ComputeHash(Encoding.UTF8.GetBytes(text))); }
        internal static string RequestText(string method,int port,string path,string ts,string nonce,byte[] body) {
            return "req\n"+method+"\n127.0.0.1:"+port.ToString(CultureInfo.InvariantCulture)+"\n"+path+"\n"+ts+"\n"+nonce+"\n"+Sha(body);
        }
        internal static string ResponseText(int port,string nonce,int code,byte[] body) {
            return "resp\n127.0.0.1:"+port.ToString(CultureInfo.InvariantCulture)+"\n"+nonce+"\n"+code.ToString(CultureInfo.InvariantCulture)+"\n"+Sha(body);
        }

        internal TempeOrderCheck.HttpResponse Route(TempeOrderCheck.HttpRequest req) {
            if(!TempeOrderCheck.Http.HostAllowed(req.Header("Host"),Port)) return TempeOrderCheck.Http.Error(403,"Forbidden","Host not allowed");
            string origin=req.Header("Origin");
            // Only an extension (not a web page): the key is the boundary, this only keeps pages out.
            if(origin!=null&&!origin.StartsWith("chrome-extension://",StringComparison.Ordinal)) return TempeOrderCheck.Http.Error(403,"Forbidden","Origin not allowed");
            if(req.Method=="OPTIONS") {
                var pre=TempeOrderCheck.Http.Json(204,"No Content",new byte[0]);
                if(origin!=null) { pre.Headers["Access-Control-Allow-Origin"]=origin;pre.Headers["Vary"]="Origin"; }
                pre.Headers["Access-Control-Allow-Methods"]="GET, POST, OPTIONS";
                pre.Headers["Access-Control-Allow-Headers"]="Content-Type, X-Tbf-Ts, X-Tbf-Nonce, X-Tbf-Mac";
                pre.Headers["Access-Control-Allow-Private-Network"]="true";pre.Headers["Access-Control-Max-Age"]="600";
                return pre;
            }
            if(req.Method=="GET"&&req.Path=="/health") return Plain(origin,200,"{\"app\":\""+App+"\",\"v\":"+Schema+"}");
            if(req.Method!="POST"||!req.Path.StartsWith("/buffalo/",StringComparison.Ordinal)) return TempeOrderCheck.Http.Error(404,"Not Found","Unknown address");
            string ts=req.Header("X-Tbf-Ts"),nonce=req.Header("X-Tbf-Nonce"),mac=req.Header("X-Tbf-Mac");
            if(String.IsNullOrEmpty(ts)||String.IsNullOrEmpty(nonce)||String.IsNullOrEmpty(mac)||nonce.Length>64) return TempeOrderCheck.Http.Error(401,"Unauthorized","Not signed");
            long ms;
            if(!Int64.TryParse(ts,NumberStyles.None,CultureInfo.InvariantCulture,out ms)) return TempeOrderCheck.Http.Error(401,"Unauthorized","Bad time");
            var when=new DateTime(1970,1,1,0,0,0,DateTimeKind.Utc).AddMilliseconds(ms);
            if(Math.Abs((Now()-when).TotalSeconds)>SkewSeconds) return TempeOrderCheck.Http.Error(401,"Unauthorized","Clock out of step");
            if(when<startedUtc) return TempeOrderCheck.Http.Error(401,"Unauthorized","Signed before this helper started");
            if(!Wire.Equal(Mac(key,RequestText(req.Method,Port,req.Path,ts,nonce,req.Body)),mac.ToLowerInvariant())) return TempeOrderCheck.Http.Error(401,"Unauthorized","Bad signature");
            lock(nonceGate) {
                var now=Now();
                foreach(var old in nonces.Where(kv=>(now-kv.Value).TotalSeconds>2*SkewSeconds).Select(kv=>kv.Key).ToList()) nonces.Remove(old);
                if(nonces.ContainsKey(nonce)) return TempeOrderCheck.Http.Error(401,"Unauthorized","Repeated");
                nonces[nonce]=now;
            }
            Dictionary<string,object> ask;
            try { ask=Wire.Read<Dictionary<string,object>>(req.Body.Length==0?"{}":Encoding.UTF8.GetString(req.Body))??new Dictionary<string,object>(); }
            catch(Exception) { return Signed(origin,nonce,400,Fail("bad JSON")); }
            string ext=Str(ask,"ext");
            SeenUtc=Now();SeenVersion=Tidy(ext,20);
            string chrome=Tidy(Str(ask,"chrome"),12);if(chrome.Length>0) SeenChrome=chrome;
            var answer=new Dictionary<string,object> { {"ok",true},{"helper",helperVersion},{"schema",Schema},{"extShipped",ExtensionShipped()},{"extOnDisk",ExtensionOnDisk()} };
            if(req.Path=="/buffalo/hello") {
                // A hello may say what keeps the page in front from taking a job (its own words; nothing from the page's boxes).
                if(ask.ContainsKey("problem")) { SeenProblem=Tidy(Str(ask,"problem"),200);SeenProblemUtc=Now(); }
                return Signed(origin,nonce,200,answer);
            }
            if(req.Path=="/buffalo/poll") {
                SeenProblem="";SeenProblemUtc=Now();   // a page asking for a job is settled and blank
                object tab;var t=ask.TryGetValue("tab",out tab)?tab as Dictionary<string,object>:null;
                bool settled=t!=null&&Bool(t,"settled"),blank=t!=null&&Bool(t,"blank");
                int schema=Int(ask,"schema");
                var offered=outbox.Offered();
                // A job only to the version the helper ships, speaking the same schema, on a settled blank page.
                if(offered!=null&&schema==Schema&&ext.Length>0&&ext==ExtensionShipped()&&settled&&blank) answer["job"]=offered;
                return Signed(origin,nonce,200,answer);
            }
            if(req.Path=="/buffalo/take") {
                bool took=outbox.Take(Str(ask,"id"));
                answer["ok"]=took;if(!took) answer["why"]="this job isn't on offer any more";
                return Signed(origin,nonce,200,answer);
            }
            if(req.Path=="/buffalo/result") {
                var r=new BuffaloResult {id=Str(ask,"id"),outcome=Str(ask,"outcome"),boxes=Int(ask,"boxes"),rows=Int(ask,"rows"),why=Clip(Str(ask,"why"),300)};
                object left;var list=ask.TryGetValue("left",out left)?left as System.Collections.ArrayList:null;
                if(list!=null) foreach(var x in list.Cast<object>().Take(30)) r.left.Add(Clip(Convert.ToString(x,CultureInfo.InvariantCulture),120));
                if(r.outcome!="filled"&&r.outcome!="partial"&&r.outcome!="refused"&&r.outcome!="failed") return Signed(origin,nonce,400,Fail("unknown outcome"));
                bool took=outbox.Answer(r);
                answer["ok"]=took;
                return Signed(origin,nonce,200,answer);
            }
            return Signed(origin,nonce,404,Fail("unknown address"));
        }
        static Dictionary<string,object> Fail(string why) { return new Dictionary<string,object> { {"ok",false},{"why",why} }; }
        static string Clip(string s,int n) { s=s??"";return s.Length>n?s.Substring(0,n):s; }
        // Text the extension sends about itself, made safe for a status line and the day log: one line of printable
        // characters (anything else becomes '?'), clipped.
        internal static string Tidy(string s,int n) {
            var sb=new StringBuilder();
            foreach(char c in Clip(s,n)) sb.Append((c>=' '&&c<='~')||c=='’'||c=='—'||c=='…'?c:'?');
            return sb.ToString().Trim();
        }
        static string Str(Dictionary<string,object> d,string k) { object v;return d.TryGetValue(k,out v)&&v!=null?Convert.ToString(v,CultureInfo.InvariantCulture):""; }
        static bool Bool(Dictionary<string,object> d,string k) { object v;return d.TryGetValue(k,out v)&&v is bool&&(bool)v; }
        static int Int(Dictionary<string,object> d,string k) { object v;if(!d.TryGetValue(k,out v)||v==null) return 0;try { return Convert.ToInt32(v,CultureInfo.InvariantCulture); } catch(Exception) { return 0; } }
        TempeOrderCheck.HttpResponse Plain(string origin,int code,string json) {
            var r=TempeOrderCheck.Http.Json(code,code==200?"OK":"Error",Encoding.UTF8.GetBytes(json));
            if(origin!=null) { r.Headers["Access-Control-Allow-Origin"]=origin;r.Headers["Vary"]="Origin"; }
            return r;
        }
        TempeOrderCheck.HttpResponse Signed(string origin,string nonce,int code,object value) {
            var body=Encoding.UTF8.GetBytes(Wire.Json(value));
            var r=TempeOrderCheck.Http.Json(code,code==200?"OK":code==400?"Bad Request":"Not Found",body);
            r.Headers["X-Tbf-Mac"]=Mac(key,ResponseText(Port,nonce,code,body));
            if(origin!=null) { r.Headers["Access-Control-Allow-Origin"]=origin;r.Headers["Vary"]="Origin";r.Headers["Access-Control-Expose-Headers"]="X-Tbf-Mac"; }
            return r;
        }
    }
}
