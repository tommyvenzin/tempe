# Mobile receiver interface — Phone-first speed update 1.4

This interface is implemented by `Source/LocalHttp.cs` and consumed by the existing `Website/costar-client.js`. Pinad mode changes desk-side approval and queue progression; phone and worker API contracts are unchanged.
The online-order importer keeps its existing schema and validation unchanged.

## Connection

The desk helper QR code opens the Job Card with a fragment:
`#pc=<encoded private HTTPS origin>&key=<random pairing token>`.
The client stores this on that website origin and removes the fragment from
history. Tokens never go in API query strings. Requests use
`Authorization: Bearer <token>`, no cookies, no redirects, and an 8-second timeout.
The current client accepts private IPv4 addresses, loopback, and `.local` hosts
on HTTPS only. An iPhone must use the desk PC's LAN address, not localhost.

The server is designed to bind only the selected private interface, validate authentication
on every API route, restrict CORS to the actual permitted website origins,
validate request Host/Origin, limit request sizes, use a trusted TLS certificate,
and never log pairing tokens. Server-side schema validation is authoritative.
No public port forwarding or user-facing login is part of V1. Pairing should
have a revocable phone token, not a shared token embedded in site source.

All routes below are under `/api/mobile/v1`.

| Route | Response / action |
| --- | --- |
| `GET /health` | `{service:"tempe-mobile-jobcard",apiVersion:1,receiving:true,workerConnected:true,workerAccepting:true,pendingCount:0}`. Submit requires `receiving` and `workerConnected` (2.4.0: the RDP helper in touch within 15 s, even with mobile entry switched off there; `workerAccepting` says whether it takes jobs right now, and a job sent while it is false waits in the queue). |
| `POST /jobs` | Persist the complete fixed payload once, keyed by `submissionId`, then return its status. An identical replay returns the same job. A different payload under the same ID must return 409 without modifying the order. |
| `GET /jobs/{id}` | Return the status of that exact job; 404 only if not known. |
| `POST /jobs/{id}/retry` | Body `{submissionId}`. Resume the same saved job after a failure; never create another order or accept a replacement payload. Return current status if it is already queued, injecting or ready. |
| `GET /tyres?url=...` | Authenticated GET-only fetch returning `{ok:true,status:200,text:"..."}`. Permit only HTTPS `tempetyres.com.au` / `www.tempetyres.com.au` product search/detail paths, reject redirects off those hosts, credentials and non-443 ports. Do not implement an open proxy. |

Status shape:

```json
{
  "submissionId": "MJC-<UUID>",
  "status": "queued",
  "version": 1,
  "message": "Waiting for COSTAR",
  "progress": ""
}
```

Allowed statuses: `queued`, `awaiting_approval`, `injecting`, `failed`,
`ready_for_review`. Versions strictly increase per submission. A received job
continues independently of the phone. The client ignores older versions and
rejects a status for another ID. Reconnection polls only; it never creates work.
The receiver must atomically claim jobs, persist checkpoints and deduplicate
retry requests. The UI alone is not a duplicate-injection safeguard.

## Submission

```json
{
  "schema": "tempe.mobile-jobcard.v1",
  "submissionId": "MJC-<UUID>",
  "draftId": "<UUID>",
  "createdUtc": "2026-09-29T00:00:00.000Z",
  "customer": {"name": "TEST CUSTOMER", "mobile": "0400000000"},
  "vehicle": {"registration": "ABC123", "makeModel": "TEST VEHICLE", "odometer": 0},
  "products": [{"type": "tyre", "sku": "TEST123", "quantity": 4, "description": "TEST TYRE"}],
  "fittingCode": "M FB",
  "alignment": null,
  "additionalNotes": ""
}
```

Products: 1–3 unique SKU lines, explicit `wheel`/`tyre` type, quantity 1–100.
No prices or totals are submitted. Optional alignment is null, WA or WAFR.
Customer name/mobile, registration, make/model and odometer are mandatory.
Odometer 0 is valid. Additional notes are at most 400 characters.

The RDP worker reuses the existing native-control engine, preserving
COSTAR's prices for mobile jobs only. It enters wheels, tyres, mandatory M FB,
optional WA/WAFR, existing DET vehicle/rego/odometer fields, then an additional
M note only when supplied. Existing online-order price checks remain intact.

The 29 September inspector captures identify the main Add new button and the
Branch 11 RepairOrder window. Both captured windows share a PID and have different
window handles; the worker must support that case as well as a new process.
Opening uses live native controls rather than fixed guessed coordinates. Recover a partial
job by reconciling the saved checkpoint against the live customer's fields and
rows; never blindly replay products. A mismatch must stop for manual review.


## Supplied receiver and worker

- Receiver: chosen private IPv4 interface, HTTPS 8790. Public certificate download only on HTTP 8791. No HTTP.sys URL ACL or automatic firewall rule.
- Worker: authenticated POST `/api/worker/v1/poll` every three seconds, separate worker bearer key, paired worker ID and per-job lease. The worker pins the exported TLS leaf certificate SHA-256 and checks validity dates. It does not globally disable certificate validation.
- Phone status readiness requires a worker heartbeat within 15 seconds and receiving enabled. An occupied COSTAR window blocks opening a new job without making an already queued job disappear.
- Queue and worker journal use atomic file replacement and Windows current-user DPAPI. A failed queue persistence operation rolls back the in-memory change. Claims are replayed with the same lease until acknowledged, including after a lost reply.
- Reports use monotonically increasing worker sequence numbers. Duplicate/old reports do not regress the receipt. A close acknowledgement increments the completed receipt version and retains `ready_for_review`, with a reminder to review in COSTAR. The receipt remains readable by the phone after the window closes.
- Each native operation saves its intent before input and its verified state afterwards. Retry compares name/account/phone/reference and ordered row codes/descriptions/quantities against the checkpoint. Prices are deliberately excluded from mobile verification and entry.
- The Add New selector uses the observed visible/enabled BUTTON caption under the Branch 11 main window, validates the current hit-test target and tracks the new RepairOrder HWND. It does not rely on the old PID or recorded pixel coordinates.
- Phone key rotation is available in the desk UI. The worker connection is replaced by exporting/importing a new connection file after certificate/network setup changes.

Idle state is measured on the physical desk session, not the RDP host; Windows' [GetLastInputInfo documentation](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getlastinputinfo) specifies that the API only reports input for its calling session. With Pinad mode off, approval is fixed at receipt: waiting until the PC becomes idle does not approve an active arrival.

The desk checkbox stores `QueueState.pinadMode` atomically with the queue. Older saved queues without the field default to false; existing true values remain enabled. Enabling approves all open `awaiting_approval` receipts and increments their versions; new arrivals are approved regardless of idle state. Disabling affects future arrivals and automatic progression, preserving existing approvals. A failed save rolls back both the mode and receipt changes. The setting is desk-only; phone requests cannot enable it.

When Pinad mode is enabled, a poll from the accepting worker that owns the current `ready_for_review` job requests `close` if the next pending FIFO job is approved and queued. `available` is normally false at this point because the completed window is still open; it is required again before assigning the next job. The receiver saves `nextRequested` before returning `close`, replays that command after a lost reply, and waits for the existing authenticated `closed` acknowledgement before releasing the current job. Failed, partial and unapproved jobs are not skipped. Both new and replayed close commands respect Stop receiving / worker accepting state. A close already delivered can finish even after Pinad mode or receiving is disabled.

With no pending job, the completed window stays open. A late submission triggers the same close handshake on the next poll. Pinad mode off retains the manual Next Order workflow. The worker still validates the original window and pauses on a close prompt. Version 1.4 additionally validates the name/account retained during phone lookup against the saved checkpoint. The desk protocol is unchanged; install the updated RDP worker to use the entry improvements. The desk list retains the latest 20 closed receipts for later review; all receipts remain in the saved queue.

List cleanup sets the persistent `Receipt.hiddenFromList` flag for `ready_for_review` receipts only. Delete selected handles one receipt; Clear completed handles all completed receipts, including the current ready receipt and history outside the 20-row display limit. Existing receipts without the flag remain visible. The UI filters removed receipts before taking the latest 20 closed entries. Cleanup retains submission hashes, phone status/version, worker leases and currentId so replay protection and the next-order close handshake keep working. It makes no COSTAR call. Failed persistence rolls back the visibility change.


## Phone-first entry and checkpoint compatibility (1.4)

The first mutation is the customer phone. Phone lookup may select an account and name different from the submitted name; that resolved identity becomes part of the verified checkpoint. Later steps cannot change it. If no customer is found, the submitted name is used. The mobile payload has no address fields. Online entry separately replaces supplied address fields while retaining the matched account/name.

`MobileCheckpoint.planVersion = 2` identifies the phone/name/reference step order. A checkpoint with no started operation may adopt this plan; an older partial checkpoint is rejected before input. Completed older checkpoints remain usable for normal close, which compares their verified identity/reference. No queue or API migration is required.

All inserted strings pass through uppercase conversion. Customer and grid writes still validate the target process/window/control, commit through COSTAR's controls and read back results. DET alone needs the PO focus change; subsequent memo commits use Tab. Progress-only status writes are throttled to at most once per 500 ms, while before/after operation checkpoints and final status remain durable. Reports include elapsed/stage/snapshot timings.

## 2.4.0 additions (worker poll)

- `WorkerHello.waitMs` (optional, 0 by default): the worker offers to wait. When the queue has nothing for it, the desk holds the request until the queue changes (a job, an approval, Retry, Next Order, Mark done, Remove, Pinad) or `waitMs` (at most 20 s) passes, or the caller goes away, then asks the queue again without re-applying the report. The reply then carries `held:true` and `waitedMs`. A 2.3.x desk ignores `waitMs` and answers at once; a 2.3.x worker never sends it. Before the second look the desk uses the newest request's `accepting` and its own `receiving`, so a request a worker already abandoned (Stop pressed) can't be handed a job.
- `WorkerReply.command:"forget"` with `status`: the report in the hello names a job this desk no longer has, or one it closed by hand (Mark done / Remove) that is not the current job. A 2.4.0 worker backs up and clears its journal (not while it is typing). A 2.3.x worker ignores the command and keeps that job; the desk shows a hint after five repeats.
- Desk actions `Mark done by hand` (any open job that is not being typed: `ready_for_review` + closed, current slot cleared) and `Remove job` (waiting or failed: status `removed`, hidden). The phone sees the status text.
- Worker action `Release job (finished by hand)`: the worker reports `ready_for_review` and remembers `releasedByHand`; the later `close` command is acknowledged `closed` without touching COSTAR. Works with any desk version. `Start this job again` sets the saved checkpoint aside (backup kept) so Retry opens a new Repair Order.


## 2.5.0 additions (eBay orders)

The eBay PC's extension ("404 But It's Found" 1.4) sends eBay orders; the RDP helper takes them with its own long-poll. The phone and mobile-worker contracts above are unchanged.

### Keys and origins

- `ReceiverSettings.ebayToken`: the eBay key, separate from the phone key, created on the desk's first 2.5.0 start, revoked by **Reset eBay pairing**. An empty key never matches.
- Routes under `/api/ebay/` accept requests with no `Origin` or with an extension origin (`chrome-extension://` + 32 letters a–p) only. The paired website origin and the desk's own pages are refused there, and an extension origin is refused on every other route. The origin rule, the key and the route all use the same normalised path (an encoded path can't pass as another kind of route).
- One eBay key for every pairing (a new pairing hands out the same key until **Reset eBay pairing**); any extension that holds it is accepted. eBay orders are entered without an approval step on the desk (Tommy, 23 Oct: straight away).
- `POST /api/ebay/v1/pair` `{pin}` is the one route without a key: it works only while **Pair eBay PC** is open on the desk (10 minutes), takes 6 digits, closes after 5 wrong tries, works once, and answers `{ok, key, receiver}`.

### Routes for the eBay PC (Bearer eBay key)

| Route | Response / action |
| --- | --- |
| `GET /api/ebay/v1/health` | `{service:"tempe-ebay",apiVersion:1,receiving,helperConnected,ebayOn,ready,detail,waiting,pendingCount}`. `helperConnected`: the RDP helper's eBay side polled within 30 s. |
| `POST /api/ebay/v1/orders` | Body: an eBay order (below). Validated in full, then queued once per eBay order number. The same content again (any send time) returns the same status. Different content: replaces it only while the RDP helper has never had it; after that 409 (`CONFLICT:`) until it is removed on the desk. A removed order sent again: if nothing was typed for it, queued fresh (new Repair Order); if it was partly typed, the same content is queued again WITHOUT `fresh` (the helper continues its Repair Order only if unchanged, otherwise stops) and other content is 409. Taken while the RDP helper is offline (it waits). |
| `GET /api/ebay/v1/orders/{number}` | Its status; 404 if unknown. |
| `POST /api/ebay/v1/orders/{number}/retry` | Body `{orderNumber}` (must match). A failed order goes back to queued: the helper continues in the same Repair Order only if nothing in it changed. |

Status: `{orderNumber,status,message,progress,version,updatedUtc,typed,waiting}`. Statuses: `queued`, `entering`, `ready_for_review` (a message containing `CHECK BY HAND:` names what must still be done by hand), `failed`, `removed`. `waiting` (queued only): why it waits, in words.

Order (`schema:"tempe.ebay-order.v1"`):

```json
{
  "schema": "tempe.ebay-order.v1", "submissionId": "EBY-12-34567-89012", "createdUtc": "2026-10-23T05:12:00.000Z",
  "orderNumber": "12-34567-89012", "orderDate": "23/10/26", "priceSource": "total minus postage", "sentFrom": "404 But It's Found 1.4",
  "buyer": {"name": "TEST BUYER", "phone": "0400000000", "email": "abc@members.ebay.com", "username": "TESTBUYER1"},
  "address": {"street": "1 TEST CRESCENT", "street2": "", "suburb": "TESTVILLE", "state": "NSW", "postcode": "2799"},
  "items": [{"sku": "W43116", "itemId": "175288170173", "title": "", "quantity": 1, "unitCents": 14000}],
  "freightCents": 1000, "totalCents": 15000
}
```

Rules (`EbayOrder.Validate`): order number `NN-NNNNN-NNNNN`; order date dd/mm/yy, not in the future; phone 8–15 digits; state and 4-digit postcode; eBay username `[A-Za-z0-9._*-]`; 1–4 items, each a COSTAR code (`[A-Z0-9][A-Z0-9._-]*`, not F/M/DET/WA/WAFR/SERVICE), a 9–15 digit eBay item number (no repeats), quantity 1–20 and a unit price; items × quantities + freight = total.

### Route for the RDP helper (Bearer worker key)

`POST /api/worker/v1/ebay` with `EbayHello {workerId, accepting, available, detail, report, waitMs, working, declined, declineReason, sequence}`; answers `EbayReply {command, order, lease, fresh, startAgain, status, ack, held, waitedMs}`. Words in `detail`, `declineReason`, `report.message` and `report.progress` are cleaned (control characters → spaces, cut to 400 / 2000 / 1000), never refused, on both sides.

- `report {orderNumber, lease, status, message, progress, sequence, typed}`: applied once per sequence for the order's current lease; `ack` = that sequence (the helper then stops resending it). A report for another lease or an unknown order answers `forget`. A finished, removed or marked-done order is never changed by a late report.
- `command:"enter"`: the next queued order (oldest first), with a new lease, while `accepting` and `available`; the same lease again while that claim is unconfirmed (also to a helper that is switched off: it hands it back with `declined`; a helper entering it ignores it, and never starts the same lease twice). One order at a time per helper. `fresh:true`: a new Repair Order (Start again, or a removed order sent again). `startAgain:true` only after **Start again** on the desk: the one case where the helper enters an order its journal says it already entered. Both are cleared by the helper's first report for that lease.
- `waitMs` (≤ 20 s) holds the request until the eBay queue changes, as for the mobile poll. The helper checks again that it may start (quiet moment, other tabs, COSTAR Sydney) when an order arrives.
- `declined` = the lease of an order handed over that the helper could not start: it goes back to `queued` with `Waiting: <declineReason>` (its `fresh`/`startAgain` kept).
- `working` = the lease of the order the helper is entering right now, `""` when none (`null`: not said); set from the moment the helper takes an order. `sequence` = the helper's report counter when it wrote the hello (read after `working` and the report; a new journal starts it from the time, so it never goes back). An order the desk holds as `entering` for this helper, already reported on, under another lease, not the subject of this hello's report, and whose last applied report is not newer than `sequence`, is set to `failed` ("no longer entering") and counted as possibly typed: the helper was closed or restarted. A late, older poll can't do this. The helper saves an entry's last report before letting go of its lease.
- Details sent again with different content are taken only before the helper's first report on the order (a handed-back claim doesn't count).

Desk actions: **Retry** (failed → queued), **Start again in a new RO** (failed → queued with `fresh` and `startAgain`; the helper also retires its record of having entered it), **Mark done by hand** and **Remove** (waiting or failed; an order the helper has taken only while the helper is out of touch), **Hide finished**. The helper refuses, before touching COSTAR: an order it entered before (unless Start again), an order sent as `fresh` that its journal says was partly typed (unless Start again), and an order the desk says was typed when it has no record of it (unless Start again). The queue (`ebay.dat`, DPAPI, current user) keeps the newest 300 receipts; waiting ones are never dropped.

## 2.5.1 (trust certificate)

- `GET /trust.cer` on the trust port answers the root certificate that signed the desk's HTTPS certificate (found by building its chain from the Windows certificate stores; public part only). `Tempe-Mobile-Root.cer` in the desk folder is used only when that root can't be found. The phone pairing page shows the same certificate's name and SHA-256. No route or contract changed.

## 2.6.0 additions (Repair Orders)

Phones (the same phone key and origins as the Job Card) read COSTAR Tempe's Work-in-Progress, open a Repair Order and send changes; the RDP helper does each request with its own long-poll. Job, eBay and worker contracts above are unchanged. Requests live in the desk's memory only (no file): a desk restart forgets them, and the phone says "the desk PC lost track" and reads again.

### Routes for the phone (under `/api/mobile/v1`, Bearer phone key)

| Route | Response / action |
| --- | --- |
| `GET /health` | Adds `ro` (true: this desk has Repair Orders; a 2.5.x desk has no such field), `roConnected` (the RDP helper's Repair Order side polled within 30 s), `roOn`, `roReady` (free to open one now), `roDetail` (why not, in words). |
| `GET /ro/list` | `{list, refresh, helper:{connected,on,ready,detail,waiting}}`. `list`: the last Work-in-Progress read (`RoList {rows, readUtc, source, note}`; `source` `costar`, or `order-check` when COSTAR Tempe was busy and Order Check's read of at most 15 minutes was used), or null. `refresh`: the list request waiting or under way, or null. |
| `POST /ro/requests` | Body `RoAsk {id:"RO-<UUID>", kind, doc, edit}`; answers its `RoStatus`. `kind`: `list`, `open` (read one Repair Order), `edit` (with `edit`) or `close` (only a Repair Order the helper left open). The same ID with the same content returns the same status; other content under that ID is 409 (`CONFLICT:`). A list while one waits, or an open of a Repair Order whose open waits, joins that request (its status, with its own ID, is returned: follow that ID). One edit or close per Repair Order at a time (another is refused until it ends). At most 20 waiting in all. Refused while the desk has stopped receiving. |
| `GET /ro/requests/{id}` | Its status; 404 if unknown (the desk restarted, or it finished more than 3 hours ago). |

The phone writes a save down (its ID and change) before sending it and only ever asks about that ID again: after a reload, going back or a lost connection it asks `GET /ro/requests/{id}`, or sends the same `POST` again (the same ID and content return the same status). Sending the same change again after the desk forgot it is safe: the helper types a change only into a Repair Order whose fingerprint is still the `baseSig` the phone read, so a change that went in once comes back `CHANGED:` with nothing typed. A refusal (HTTP 4xx) queues nothing.

`RoStatus {id, kind, doc, status, message, progress, waiting, version, updatedUtc, typed, leftOpen, snapshot, notes}`. Statuses: `queued` (`waiting`: why, in words), `working`, `done`, `failed`. `version` goes up with every change. `typed`: something was changed in COSTAR. `leftOpen`: the Repair Order is still open in COSTAR Tempe (a change that stopped after typing). `snapshot`: the Repair Order as read (open, edit: after the change, or COSTAR's copy when it changed meanwhile). `notes`: what COSTAR changed by itself (said, not a stop). A request not taken within 10 minutes fails; one being done fails when the RDP helper is silent for 90 s or says it was restarted (an edit then counts as possibly typed). A failed edit whose message starts `CHANGED:` typed nothing: the Repair Order changed after the phone read it, and `snapshot` is COSTAR's copy now.

`RoSnapshot`: `doc, readUtc, sig`; `account, name, phone, email, address, address2, suburb, state, postcode, po, comment`; `shipVia, dateIn, timeIn, writtenBy, customerWaiting` (`yes`/`no`/`""`); `makeModel, rego, odometer, det` (DET's three notes); `counted, totalCents, loose` (lines with no item code but words or a price left in them); `lines [{n, kind (item, note, det, car), code, description, qty, net, list}]` (filled lines, top to bottom); `cannot {box: why}` (boxes the phone can't change on this Repair Order: locked, missing, the mobile on a customer account, …; also `car`); `limits {box: letters}`. `sig`: the first 16 hex of SHA-256 over the customer boxes, Ship Via, Date In (as a date), Customer Waiting, DET, the total, the loose lines and every line's code, words, quantity and net price.

Change (`RoEdit`, `schema:"tempe.ro-edit.v1"`):

```json
{
  "schema": "tempe.ro-edit.v1", "doc": "123456", "baseSig": "0123456789ABCDEF",
  "header": {"name": "TEST CUSTOMER", "po": "TEST PO"},
  "shipVia": "SHOP", "dateIn": "2026-10-28", "customerWaiting": "yes",
  "makeModel": "TEST CAR", "rego": "TEST01", "odometer": "123456",
  "lines": [{"index": 0, "code": "W43116", "qty": "2", "price": "150.00"}, {"index": 3, "code": "M", "text": "TEST NOTE"}, {"index": 4, "code": "WA", "remove": true}],
  "add": [{"kind": "item", "code": "VALVE", "qty": "4", "price": "5.00"}, {"kind": "note", "code": "M", "text": "TEST NOTE"}]
}
```

Absent or null: unchanged. `baseSig`: the `sig` the phone was shown. `lines[].index`: the line's place among the filled lines (0 = top), with its `code` as read (checked again). Rules (`RoEdit.ValidateShape` on the desk, `Validate` again on the helper against what it reads): header boxes from the list above with COSTAR's letters, mobile 8–15 digits, state NSW/VIC/QLD/SA/WA/TAS/NT/ACT, postcode 4 digits; Ship Via ≤ 20; Date In `yyyy-MM-dd` within a year of today; quantities 0.01–9999, prices up to 999999.99 (two decimals); notes ≤ 80 letters; items qty/price, notes words, never DET or the car notes (they change under `makeModel`/`rego`/`odometer`); new items are COSTAR codes, not DET or M (M lines have no quantity or price); at most 8 new lines and 25 lines in all.

### Route for the RDP helper (Bearer worker key)

`POST /api/worker/v1/ro` with `RoHello {workerId, accepting, available, detail, report, waitMs, working, declined, declineReason, sequence}`; answers `RoReply {command, task, ack, held, waitedMs}`, as for the eBay poll (words cleaned, never refused). Its body may be up to 1 MB (a report can carry COSTAR's whole Work-in-Progress list); every other request stays at 64 KB. The desk decides that from the path read as the routes read it and the worker key, before it reads the body.

- `report {id, lease, status (working, done, failed), message, progress, sequence, typed, leftOpen, snapshot, list, notes}`: applied once per sequence for the request's current lease; `ack` = that sequence. A list report with `done` replaces the desk's list.
- `command:"do"` with `task {id, lease, kind, doc, edit}`: the oldest waiting request (a list first) while `accepting`; open and edit only while `available`, list and close also while COSTAR is busy (the helper reads Order Check's copy then; close is one window message). The same task again while unconfirmed; one at a time per helper. `declined` = the lease of a task it can't start now: back to `queued` with `Waiting: <declineReason>`.
- `working` / `sequence`: as for eBay; a request the desk holds as being done under another lease, older than `sequence`, fails ("it was closed or restarted").
- `waitMs` (≤ 20 s) holds the request until a phone asks something.

The helper's `ro-journal.dat` (DPAPI, current user) holds the request it is doing, its last report until the desk takes it, and the Repair Order it left open (number, window, COSTAR process), so the phone's `close` closes exactly that window and nothing else.
