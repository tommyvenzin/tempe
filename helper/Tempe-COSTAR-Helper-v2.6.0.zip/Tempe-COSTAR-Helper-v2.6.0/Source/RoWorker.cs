// The RDP helper's Repair Order side (2.6.0): asks the desk PC for the phones' Repair Order requests
// and does them in the selected COSTAR (Tempe), one at a time, in a quiet moment: reads its Work-in-
// Progress list, opens a Repair Order from it (double click on its row, or Enter on the selected row),
// reads it, types the phone's changes, checks them and closes it again. A change that stops after
// typing leaves the Repair Order open for a person to check (the phone can ask to close it then).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    // What the helper is doing (saved before COSTAR is touched): after a restart it tells the desk the
    // request stopped. touched: something was typed into the Repair Order.
    public sealed class RoAttempt { public string id,lease,kind,doc,atUtc;public long window,processStart;public int processId;public bool touched; }
    // A Repair Order this helper left open after a change stopped (the phone may ask to close it).
    public sealed class RoLeftOpen { public string doc,atUtc;public long window,processStart;public int processId; }
    public sealed class RoJournal { public RoAttempt running;public RoLeftOpen leftOpen;public RoReport report;public int sequence; }
    // What an open from Work-in-Progress saw, for the engine when it stops: the Repair Order windows
    // there before anything was clicked (shown or not), and whether a person used the PC meanwhile
    // (then no window that opened is taken for the helper's own, so none is ever closed).
    internal sealed class RoOpenWatch { internal HashSet<long> Before;internal bool UserActive;internal readonly Stopwatch Clock=Stopwatch.StartNew(); }

    // COSTAR's Work-in-Progress list in the selected COSTAR: read it, find a document in it, open it.
    // Reads through accessibility (as Order Check does); the only input is Search (pressed through
    // accessibility), the mouse wheel over the list, and the double click (or Enter) that opens a row.
    internal static class RoWip {
        internal sealed class Spot { internal RoListRow Row;internal int Index,Left,Top,Width,Height,State=-1,First=-1,Last=-1; }
        static TempeOrderCheck.WipHandles Screen(CostarInstance t,out IntPtr main) {
            main=CostarWindows.Main(t);
            var h=TempeOrderCheck.WipScreen.Locate(main);
            Order.Require(h!=null,"COSTAR "+t.Label+" isn't showing Work-in-Progress. Leave it on Work-in-Progress.");
            return h;
        }
        static string Money(decimal total) { return "$"+total.ToString("0.00",CultureInfo.InvariantCulture); }
        static RoListRow Row(TempeOrderCheck.WipRow r) {
            return new RoListRow {doc=r.Doc,date=r.OrderDateText,name=r.Name,total=r.HasTotal?Money(r.Total):"",shipVia=r.ShipVia,comment=r.Comment,by=r.By,po=r.Po,status=r.Status};
        }
        // The list as COSTAR shows it now. search: press Search first (the newest list).
        internal static RoList ReadList(CostarInstance t,bool search,Func<bool> cancelled) {
            IntPtr main;var h=Screen(t,out main);
            var notes=new List<string>();
            if(search&&h.Search!=IntPtr.Zero) PressSearch(h,cancelled);
            else notes.Add(search?"COSTAR's Search button wasn't found, so the list is as COSTAR showed it":"read as COSTAR showed it (a Repair Order is open there)");
            var reader=new TempeOrderCheck.GridReader();
            var rows=reader.Read(h.Grid);
            string filter=TempeOrderCheck.WipScreen.FilterText(h);
            if(filter.Length>0) notes.Insert(0,"COSTAR's Work-in-Progress is filtered ("+filter+")");
            return new RoList {rows=rows.Select(Row).ToList(),readUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture),source="costar",note=String.Join("; ",notes.ToArray())};
        }
        // Order Check's last read of its own WIP window, if it is recent: the list when COSTAR is busy.
        internal static RoList FromOrderCheck(TimeSpan maxAge) {
            var store=TempeOrderCheck.Hosting.Store;if(store==null) return null;
            Dictionary<string,object> root;
            try { root=new System.Web.Script.Serialization.JavaScriptSerializer {MaxJsonLength=16*1024*1024}.DeserializeObject(Encoding.UTF8.GetString(store.Snapshot())) as Dictionary<string,object>; }
            catch(Exception) { return null; }
            if(root==null||Field(root,"state")!="ok") return null;
            DateTimeOffset at;
            if(!DateTimeOffset.TryParse(Field(root,"readAt"),CultureInfo.InvariantCulture,DateTimeStyles.None,out at)||DateTimeOffset.Now-at>maxAge) return null;
            object rowsValue;var rows=root.TryGetValue("rows",out rowsValue)?rowsValue as System.Collections.IEnumerable:null;
            if(rows==null) return null;
            var list=new List<RoListRow>();
            foreach(object o in rows) {
                var r=o as Dictionary<string,object>;if(r==null) continue;
                decimal total;bool has=Field(r,"hasTotal")=="True"&&Decimal.TryParse(Field(r,"total"),NumberStyles.Number,CultureInfo.InvariantCulture,out total);
                list.Add(new RoListRow {doc=Field(r,"doc"),date=Field(r,"orderDateText"),name=Field(r,"name"),total=has?Money(Decimal.Parse(Field(r,"total"),NumberStyles.Number,CultureInfo.InvariantCulture)):"",
                    shipVia=Field(r,"shipVia"),comment=Field(r,"comment"),by=Field(r,"by"),po=Field(r,"po"),status=Field(r,"status")});
            }
            return new RoList {rows=list,readUtc=at.UtcDateTime.ToString("o",CultureInfo.InvariantCulture),source="order-check",note="Order Check's list from "+at.ToString("HH:mm",CultureInfo.InvariantCulture)};
        }
        static string Field(Dictionary<string,object> d,string key) { object v;return d!=null&&d.TryGetValue(key,out v)&&v!=null?Convert.ToString(v,CultureInfo.InvariantCulture):""; }
        // Search through accessibility on its own thread (COSTAR may take seconds), then a list that
        // holds still (two equal row counts).
        static void PressSearch(TempeOrderCheck.WipHandles h,Func<bool> cancelled) {
            string error=null;
            var th=new Thread(delegate() {
                Accessibility.IAccessible b=null;
                try { b=Msaa.FromWindow(h.Search);b.accDoDefaultAction(0); }
                catch(Exception e) { error=e.Message; }
                finally { Msaa.Release(b); }
            });
            th.IsBackground=true;th.SetApartmentState(ApartmentState.MTA);th.Start();
            Order.Require(th.Join(20000),"COSTAR didn't finish its Work-in-Progress search within 20 s. Is a window open in COSTAR?");
            Order.Require(error==null,"Couldn't press Search in COSTAR's Work-in-Progress: "+error);
            var reader=new TempeOrderCheck.GridReader();var timer=Stopwatch.StartNew();int last=-2;
            while(timer.ElapsedMilliseconds<8000) {
                Order.Require(!cancelled(),"Stopped.");
                Thread.Sleep(400);
                int count=reader.TableRowCount(h.Grid);
                if(count>=0&&count==last) return;
                last=count;
            }
        }
        // Where document `doc` is in the list: its row's values, its Document # cell on the screen, its
        // state, its place among the rows, and which rows are in view. Null when the list doesn't hold it.
        internal static Spot Find(IntPtr grid,string doc) {
            Native.Rect box;Order.Require(Native.GetWindowRect(grid,out box),"COSTAR's Work-in-Progress list is gone.");
            Accessibility.IAccessible client=null,table=null;
            try {
                client=Msaa.FromWindow(grid);
                table=Msaa.Role(client)==Msaa.RoleTable?client:Msaa.FindTable(client,3);
                Order.Require(table!=null,"COSTAR's Work-in-Progress list isn't showing a table. Press Search in COSTAR.");
                Dictionary<string,int> columns=null;string poColumn="";Spot hit=null;int index=-1,first=-1,last=-1;
                var seen=new HashSet<string>(StringComparer.Ordinal);string want=Order.Norm(doc);
                foreach(object o in Msaa.Children(table,5000)) {
                    try {
                        var row=o as Accessibility.IAccessible;
                        if(row==null||Msaa.RoleOf(table,o)!=Msaa.RoleRow) continue;
                        var cells=Msaa.Children(row,80);
                        try {
                            if(cells.Count==0||Msaa.RoleOf(row,cells[0])==25) continue; // the column headings
                            if(columns==null) {
                                columns=new Dictionary<string,int>(StringComparer.Ordinal);
                                for(int i=0;i<cells.Count;i++) { string n=Msaa.NameOf(row,cells[i]).Trim();if(n.Length>0&&!columns.ContainsKey(n)) columns[n]=i; }
                                poColumn=TempeOrderCheck.GridReader.FindPoColumn(columns.Keys);
                            }
                            int di;if(!columns.TryGetValue("Document #",out di)||di>=cells.Count) continue;
                            string d=Order.Norm(Msaa.ValueOf(row,cells[di]));
                            if(d.Length==0) continue;
                            int l,t,w,hh;bool placed=Msaa.LocationOf(row,cells[di],out l,out t,out w,out hh)&&w>0&&hh>0;
                            // The list can hold its active row twice: one place per document.
                            if(!seen.Add(d)) { if(d==want&&hit!=null&&hit.Height==0&&placed) { hit.Left=l;hit.Top=t;hit.Width=w;hit.Height=hh; } continue; }
                            index++;
                            if(placed&&t>=box.Top&&t+hh<=box.Bottom) { if(first<0) first=index;last=index; }
                            if(d!=want) continue;
                            Func<string,string> cell=delegate(string name) { int ci;return name.Length>0&&columns.TryGetValue(name,out ci)&&ci<cells.Count?Order.Clean(Msaa.ValueOf(row,cells[ci])):""; };
                            hit=new Spot {Index=index,State=Msaa.StateOf(table,o),Row=new RoListRow {doc=d,date=cell("Order Date"),name=cell("Name"),total=cell("Doc Total"),shipVia=cell("Ship Via"),
                                comment=cell("Comment"),by=cell("Written By"),status=cell("Status"),po=poColumn.Length>0?cell(poColumn):null}};
                            if(placed) { hit.Left=l;hit.Top=t;hit.Width=w;hit.Height=hh; }
                        } finally { foreach(var c in cells) Msaa.Release(c); }
                    } finally { Msaa.Release(o); }
                }
                if(hit!=null) { hit.First=first;hit.Last=last; }
                return hit;
            } finally { if(!Object.ReferenceEquals(table,client)) Msaa.Release(table);Msaa.Release(client); }
        }
        // Selects the row through accessibility (the list then brings it into view). Never opens it.
        static void SelectRow(IntPtr grid,string doc) {
            Accessibility.IAccessible client=null,table=null;
            try {
                client=Msaa.FromWindow(grid);
                table=Msaa.Role(client)==Msaa.RoleTable?client:Msaa.FindTable(client,3);
                if(table==null) return;
                string want=Order.Norm(doc);int docIndex=-1;
                foreach(object o in Msaa.Children(table,5000)) {
                    bool done=false;
                    try {
                        var row=o as Accessibility.IAccessible;
                        if(row==null||Msaa.RoleOf(table,o)!=Msaa.RoleRow) continue;
                        var cells=Msaa.Children(row,80);
                        try {
                            if(cells.Count==0||Msaa.RoleOf(row,cells[0])==25) continue;
                            if(docIndex<0) for(int i=0;i<cells.Count;i++) if(Msaa.NameOf(row,cells[i]).Trim()=="Document #") { docIndex=i;break; }
                            if(docIndex<0||docIndex>=cells.Count||Order.Norm(Msaa.ValueOf(row,cells[docIndex]))!=want) continue;
                            Msaa.SelectChild(table,o);done=true;
                        } finally { foreach(var c in cells) Msaa.Release(c); }
                    } finally { Msaa.Release(o); }
                    if(done) return;
                }
            } catch(Exception) {
            } finally { if(!Object.ReferenceEquals(table,client)) Msaa.Release(table);Msaa.Release(client); }
        }
        // In view and clickable: the Document # cell inside the list, clear of its edges (its scroll
        // bars are drawn inside it), and the list itself under that point.
        static bool InView(IntPtr grid,Spot s) {
            Native.Rect box;if(s==null||s.Height<=4||s.Width<=4||!Native.GetWindowRect(grid,out box)) return false;
            var p=Point(s);
            return s.Top>=box.Top+2&&s.Top+s.Height<=box.Bottom-20&&p.X>box.Left+2&&p.X<box.Right-24&&Native.WindowFromPoint(p)==grid;
        }
        static Native.Point Point(Spot s) { return new Native.Point {X=s.Left+Math.Min(s.Width/2,40),Y=s.Top+s.Height/2}; }
        static void Front(IntPtr main,Func<bool> cancelled) {
            Native.BringToFront(main);var timer=Stopwatch.StartNew();
            while(!cancelled()&&Native.GetForegroundWindow()!=main&&timer.ElapsedMilliseconds<2000) Thread.Sleep(25);
            Order.Require(!cancelled(),"Stopped.");
            Order.Require(Native.GetForegroundWindow()==main&&Native.IsWindowEnabled(main),"COSTAR's main window couldn't be brought in front (another window is open in COSTAR?).");
        }
        static bool Inside(IntPtr h,IntPtr parent) { for(var p=h;p!=IntPtr.Zero;p=Native.GetParent(p)) if(p==parent) return true;return false; }
        // Brings the row into view: selected through accessibility first; then the mouse wheel over the
        // list, towards it (after one click on a row in view, so the list has the mouse wheel).
        static Spot Reveal(IntPtr main,IntPtr grid,string doc,Spot spot,Func<bool> cancelled,Action<string> say,RoOpenWatch watch) {
            if(InView(grid,spot)) return spot;
            SelectRow(grid,doc);Thread.Sleep(300);
            var again=Find(grid,doc);if(again!=null) spot=again;
            if(InView(grid,spot)) return spot;
            say("Scrolling COSTAR's Work-in-Progress list to Repair Order "+doc+".");
            Native.Rect box;Order.Require(Native.GetWindowRect(grid,out box),"COSTAR's Work-in-Progress list is gone.");
            var center=new Native.Point {X=(box.Left+box.Right)/2,Y=(box.Top+box.Bottom)/2};
            bool clicked=false;
            for(int round=0;round<14;round++) {
                Order.Require(!cancelled(),"Stopped.");
                Quiet(watch,doc);Front(main,cancelled);
                Order.Require(Native.WindowFromPoint(center)==grid,"COSTAR's Work-in-Progress list is covered.");
                if(!clicked) {
                    // One click on the row in view nearest the middle: the list takes the mouse wheel.
                    var any=FirstInView(grid);
                    if(any!=null) { Native.NoModifiers();Quiet(watch,doc);Order.Require(Native.WindowFromPoint(Point(any))==grid,"COSTAR's Work-in-Progress list is covered.");Native.ClickNow(Point(any));clicked=true;Thread.Sleep(200); }
                }
                int notches;
                if(spot.First>=0&&spot.Index<spot.First) notches=Math.Max(1,Math.Min(10,(spot.First-spot.Index+2)/3));
                else if(spot.Last>=0&&spot.Index>spot.Last) notches=-Math.Max(1,Math.Min(10,(spot.Index-spot.Last+2)/3));
                else notches=spot.Height>0&&spot.Top<box.Top?1:-1;
                Native.NoModifiers();Quiet(watch,doc);Order.Require(Native.WindowFromPoint(center)==grid,"COSTAR's Work-in-Progress list is covered.");Native.WheelNow(center,notches);Thread.Sleep(250);
                var next=Find(grid,doc);
                if(next==null) break;
                bool moved=next.First!=spot.First||next.Last!=spot.Last||next.Top!=spot.Top;
                spot=next;
                if(InView(grid,spot)) return spot;
                if(!moved&&round>=2) break;
            }
            throw new InvalidOperationException("Repair Order "+doc+"'s row couldn't be brought into view in COSTAR's Work-in-Progress list. Open it by hand.");
        }
        // A row in view (for the click that gives the list the mouse wheel): its Document # cell (a click
        // there only selects the row), in the row nearest the middle.
        static Spot FirstInView(IntPtr grid) {
            Native.Rect box;if(!Native.GetWindowRect(grid,out box)) return null;
            Accessibility.IAccessible client=null,table=null;Spot best=null;int mid=(box.Top+box.Bottom)/2,docIndex=-1;
            try {
                client=Msaa.FromWindow(grid);
                table=Msaa.Role(client)==Msaa.RoleTable?client:Msaa.FindTable(client,3);
                if(table==null) return null;
                foreach(object o in Msaa.Children(table,400)) {
                    try {
                        var row=o as Accessibility.IAccessible;
                        if(row==null||Msaa.RoleOf(table,o)!=Msaa.RoleRow) continue;
                        var cells=Msaa.Children(row,80);
                        try {
                            if(cells.Count==0||Msaa.RoleOf(row,cells[0])==25) continue;
                            if(docIndex<0) for(int i=0;i<cells.Count;i++) if(Msaa.NameOf(row,cells[i]).Trim()=="Document #") { docIndex=i;break; }
                            if(docIndex<0||docIndex>=cells.Count) continue;
                            int l,t,w,h;if(!Msaa.LocationOf(row,cells[docIndex],out l,out t,out w,out h)) continue;
                            var s=new Spot {Left=l,Top=t,Width=w,Height=h};
                            if(InView(grid,s)&&(best==null||Math.Abs(t-mid)<Math.Abs(best.Top-mid))) best=s;
                        } finally { foreach(var c in cells) Msaa.Release(c); }
                    } finally { Msaa.Release(o); }
                }
            } catch(Exception) { return null; }
            finally { if(!Object.ReferenceEquals(table,client)) Msaa.Release(table);Msaa.Release(client); }
            return best;
        }
        // Nobody has used the PC since the open began (the helper's own clicks and keys don't count):
        // checked before every click, scroll and key, so nothing goes in under a person's hands.
        static void Quiet(RoOpenWatch watch,string doc) {
            if(!Native.UserActiveWithin((int)Math.Min(600000,watch.Clock.ElapsedMilliseconds+1000))) return;
            watch.UserActive=true;
            throw new InvalidOperationException("Someone used the COSTAR PC while Repair Order "+doc+" was being opened, so the helper stopped there (nothing more clicked or pressed). Try again when the PC is free.");
        }
        // Every Repair Order window of this COSTAR, shown or not yet (COSTAR may build one before it shows).
        static HashSet<long> AllOrders(CostarInstance t) {
            CostarWindows.Main(t);var set=new HashSet<long>();
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) { if(Native.Pid(w)==t.Pid&&Native.Caption(w).StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase)) set.Add(w.ToInt64());return true; },IntPtr.Zero);
            return set;
        }
        // Opens `doc` from the list: Search, its row brought into view, a double click on its Document #
        // cell; if nothing opens, Enter on it once it is the selected row (Tommy, 27 Oct: both work).
        // Nobody may use the PC meanwhile (checked before every click and key). Returns the new Repair
        // Order window; spot: its row as found; selected: it was the list's selected row after.
        internal static IntPtr Open(CostarInstance t,string doc,Func<bool> cancelled,Action<string> say,RoOpenWatch watch,out Spot spot,out bool selected) {
            IntPtr main;var h=Screen(t,out main);
            Order.Require(CostarWindows.Orders(t).Count==0,"A Repair Order is open in COSTAR "+t.Label+". Close it first.");
            watch.Before=AllOrders(t);
            Quiet(watch,doc);Front(main,cancelled);
            say("Looking for Repair Order "+doc+" in COSTAR's Work-in-Progress.");
            if(h.Search!=IntPtr.Zero) PressSearch(h,cancelled);
            spot=Find(h.Grid,doc);
            Order.Require(spot!=null,"Repair Order "+doc+" isn't in COSTAR "+t.Label+"'s Work-in-Progress list (finished, or filtered out?).");
            spot=Reveal(main,h.Grid,doc,spot,cancelled,say,watch);
            Quiet(watch,doc);Front(main,cancelled);
            Order.Require(AllOrders(t).SetEquals(watch.Before),"COSTAR opened a window while its list was being scrolled. Nothing was double-clicked: check COSTAR.");
            // Found again just before the click: the place is now, not from a moment ago.
            var now=Find(h.Grid,doc);
            Order.Require(now!=null&&InView(h.Grid,now),"Repair Order "+doc+"'s row moved in the list. Nothing was opened; try again.");
            spot=now;
            say("Opening Repair Order "+doc+".");
            // The last look, then the double click at once (no waiting for a held key after it).
            Native.NoModifiers();Quiet(watch,doc);
            Order.Require(Native.GetForegroundWindow()==main&&Native.WindowFromPoint(Point(spot))==h.Grid,"COSTAR's Work-in-Progress list was covered just before the double click. Nothing was opened; try again.");
            Native.DoubleClickNow(Point(spot));
            IntPtr window=WaitForWindow(t,watch,main,doc,cancelled);
            if(window==IntPtr.Zero) {
                var sel=Find(h.Grid,doc);
                Order.Require(sel!=null&&sel.State>=0&&(sel.State&0x6)!=0,"Repair Order "+doc+" didn't open with a double click, and its row isn't selected. Open it by hand.");
                Quiet(watch,doc);Front(main,cancelled);
                Order.Require(Inside(Native.Focus(main),h.Grid),"COSTAR's Work-in-Progress list doesn't have the keyboard, so Enter isn't pressed. Open Repair Order "+doc+" by hand.");
                // Pressed only with COSTAR idle (WaitForWindow), its main window in front, the list holding
                // the keyboard and no Repair Order window being built: the key can't reach anything else.
                Order.Require(Native.GetForegroundWindow()==main&&AllOrders(t).SetEquals(watch.Before),"COSTAR changed before Enter could be pressed. Nothing was pressed; try again.");
                AppLog.Note("ro_open_enter",doc+": the double click opened nothing; Enter on the selected row");
                Native.NoModifiers();Quiet(watch,doc);
                Order.Require(Native.GetForegroundWindow()==main&&Inside(Native.Focus(main),h.Grid),"COSTAR changed before Enter could be pressed. Nothing was pressed; try again.");
                Native.KeyNow(13);
                window=WaitForWindow(t,watch,main,doc,cancelled);
                Order.Require(window!=IntPtr.Zero,"Repair Order "+doc+" didn't open (a double click and Enter were tried). Open it by hand.");
            }
            var after=Find(h.Grid,doc);
            selected=after!=null&&after.State>=0&&(after.State&0x6)!=0;
            return window;
        }
        // The Repair Order window that wasn't there before, once it has stayed the same for 300 ms. A
        // COSTAR message box shown instead stops it: nothing is pressed in it. A person using the PC
        // meanwhile stops it too (their window could be the next one). Zero only when nothing opened, no
        // new Repair Order window is being built (even hidden), and COSTAR has answered at once for 3 s
        // in a row, at least 8 s after the click (30 s at most): a slow COSTAR still opening it is
        // waited for, so nothing is ever pressed into a late window.
        static IntPtr WaitForWindow(CostarInstance t,RoOpenWatch watch,IntPtr main,string doc,Func<bool> cancelled) {
            var timer=Stopwatch.StartNew();var settle=Stopwatch.StartNew();IntPtr candidate=IntPtr.Zero;int idle=0;
            while(timer.ElapsedMilliseconds<30000) {
                Order.Require(!cancelled(),"Stopped while Repair Order "+doc+" was opening. Check COSTAR.");
                Quiet(watch,doc);
                var building=AllOrders(t).Where(x=>!watch.Before.Contains(x)).ToList();
                var fresh=CostarWindows.Orders(t).Where(x=>!watch.Before.Contains(x.ToInt64())).ToList();
                Order.Require(fresh.Count<=1,"More than one Repair Order opened in COSTAR "+t.Label+". Check COSTAR.");
                if(fresh.Count==1) {
                    Order.Require(Branches.OrderTitle(Native.Caption(fresh[0]),t.Branch),"The Repair Order that opened is not in "+t.Label+".");
                    if(fresh[0]==candidate&&settle.ElapsedMilliseconds>=300) return fresh[0];
                    if(fresh[0]!=candidate) { candidate=fresh[0];settle.Restart(); }
                    idle=0;
                } else {
                    candidate=IntPtr.Zero;
                    var fg=Native.GetForegroundWindow();
                    if(fg!=IntPtr.Zero&&fg!=main&&Native.Pid(fg)==t.Pid&&Native.Class(fg)=="#32770"&&timer.ElapsedMilliseconds>=300) Question(fg,doc);
                    UIntPtr result;
                    bool answering=building.Count==0&&fg==main&&Native.SendNull(main,0,UIntPtr.Zero,IntPtr.Zero,0x0002,500,out result)!=IntPtr.Zero;
                    idle=answering?idle+1:0;
                    if(timer.ElapsedMilliseconds>=8000&&idle>=60) return IntPtr.Zero;
                }
                Thread.Sleep(50);
            }
            Order.Require(AllOrders(t).SetEquals(watch.Before),"Repair Order "+doc+" took more than 30 s to open. Check COSTAR.");
            return IntPtr.Zero;
        }
        // A COSTAR message box instead of the Repair Order: read (for the phone), never answered.
        static void Question(IntPtr dialog,string doc) {
            var words=new List<string>();var buttons=new List<string>();
            Native.EnumChildWindows(dialog,delegate(IntPtr h,IntPtr unused) {
                if(!Native.IsWindowVisible(h)) return true;
                string cls=Native.Class(h),text;if(!Native.TryText(h,out text)) return true;
                if(cls.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0) buttons.Add(Order.Norm(text).Replace("&",""));
                else if(cls.IndexOf("STATIC",StringComparison.OrdinalIgnoreCase)>=0&&Order.Clean(text).Length>0) words.Add(Order.Clean(text));
                return words.Count+buttons.Count<40;
            },IntPtr.Zero);
            string said=EbayText.Clean(String.Join(" ",words.ToArray()),300).Replace("\"","'");
            AppLog.Note("ro_open_question",doc+": a COSTAR message box, buttons "+String.Join("/",buttons.ToArray()));
            throw new InvalidOperationException("COSTAR showed a message instead of opening Repair Order "+doc+(said.Length>0?": \""+said+"\"":"")+". Nothing was answered: answer it at the PC (COSTAR may then open the Repair Order: check it there).");
        }
    }

    internal sealed class RoEngine : IDisposable {
        readonly EntryCoordinator coordinator;readonly WorkerSettings settings;readonly string journalPath;readonly object gate=new object();readonly Action<string> log;
        RoJournal state;volatile Runner runner;volatile bool disposed,busy;int started;
        internal volatile bool Enabled;
        internal const int QuietSeconds=10,TempeBranch=11;
        internal volatile string Connection="Desk PC: connecting ...",Detail="",Current="",LastLine="";
        volatile int lastContactTick;internal volatile int RoundTripMs=-1;
        internal int SecondsSinceContact { get { int t=lastContactTick;return t==0?-1:unchecked(Environment.TickCount-t)/1000; } }
        volatile HttpWebRequest pending;volatile bool interrupted;readonly AutoResetEvent wake=new AutoResetEvent(false);
        readonly Stopwatch progressClock=Stopwatch.StartNew();
        // COSTAR checked again at most every 3 s (a window scan).
        DateTime checkedAt=DateTime.MinValue;bool lastFree;string lastWhy="";
        internal bool Busy {get{return busy;}}
        // The Repair Order this helper left open after a change stopped ("" when none), for the window.
        internal string LeftOpen { get { lock(gate) return state.leftOpen==null?"":state.leftOpen.doc; } }
        internal RoEngine(WorkerSettings config,string folder,Action<string> notify,EntryCoordinator entries) {
            coordinator=entries;NetworkRules.Worker(config);settings=config;log=notify;journalPath=Path.Combine(folder,"ro-journal.dat");
            try { state=PrivateFiles.Load<RoJournal>(journalPath); }
            catch(Exception e) {
                try{File.Copy(journalPath,journalPath+".unreadable-"+DateTime.Now.ToString("yyyyMMdd-HHmmss"),true);}catch(Exception){}
                AppLog.Note("ro_journal_unreadable",e.GetType().Name);state=null;
            }
            // A new journal counts its reports on from the time, so they come after any earlier one's.
            if(state==null) state=new RoJournal {sequence=(int)Math.Min(Int32.MaxValue/2,Math.Max(0,(DateTime.UtcNow-new DateTime(2026,1,1,0,0,0,DateTimeKind.Utc)).TotalSeconds))};
            var lost=state.running;
            if(lost!=null) {
                state.running=null;
                // Its Repair Order still open (the same window in the same COSTAR): remembered as left
                // open, typed into or not, so it can be closed from the phone; never closed here.
                bool open=false;
                try {
                    var h=new IntPtr(lost.window);ProcessIdentity identity;
                    open=lost.window!=0&&Native.IsWindow(h)&&(int)Native.Pid(h)==lost.processId&&Native.Caption(h).StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase)
                        &&LocalProcess.IsNamed(lost.processId,"COSTAR",out identity)&&identity.Started==lost.processStart;
                } catch(Exception) { open=false; }
                if(open) state.leftOpen=new RoLeftOpen {doc=lost.doc,window=lost.window,processId=lost.processId,processStart=lost.processStart,atUtc=lost.atUtc};
                string why=lost.touched?"The RDP helper closed while changing Repair Order "+lost.doc+". Check it in COSTAR Tempe"+(open?" (it is still open there: close it there or from the phone)":"")+" before trying again."
                    :open?"The RDP helper closed while Repair Order "+lost.doc+" was open (nothing was typed). It is still open in COSTAR Tempe: close it there or from the phone."
                    :"The RDP helper closed while doing this. Try again.";
                try { Report(lost.id,lost.lease,"failed",why,"",lost.touched,open); } catch(Exception) { }
            }
            Enabled=AppSettings.Current.roOn;
        }
        static string Now { get { return DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture); } }
        void Save() { lock(gate) PrivateFiles.Save(journalPath,state); }
        void Running(RoAttempt attempt) { lock(gate) { state.running=attempt;Save(); } }
        // Under gate: the next report (the desk acknowledges it by its sequence).
        void SetReport(string id,string lease,string status,string message,string progress,bool typed,bool leftOpen,RoSnapshot snapshot=null,RoList list=null,List<string> notes=null) {
            state.sequence++;
            state.report=new RoReport {id=id,lease=lease,status=status,message=EbayText.Clean(message,2000),progress=EbayText.Clean(progress,1000),sequence=state.sequence,typed=typed,leftOpen=leftOpen,snapshot=snapshot,list=list,notes=notes};
        }
        void Report(string id,string lease,string status,string message,string progress,bool typed,bool leftOpen,RoSnapshot snapshot=null,RoList list=null,List<string> notes=null) {
            lock(gate) { SetReport(id,lease,status,message,progress,typed,leftOpen,snapshot,list,notes);Save(); }
            if(status!="working"||(progress??"").Length==0) { Detail=message;log(message); }
            Interrupt();
        }
        volatile string declineLease,declineReason;
        void Decline(string lease,string why) { declineReason=EbayText.Clean(why,400);declineLease=lease;Detail=why;Interrupt(); }
        internal void Start() {
            if(disposed) return;
            if(!AppSettings.Current.roOn){AppSettings.Current.roOn=true;AppSettings.Current.Save();}
            bool was=Enabled;Enabled=true;AppLog.Note("ro_start","");Connect();if(!was)Interrupt();
        }
        // persist: the Repair Orders switch itself. Stop all entry only pauses.
        internal void Stop(bool persist) {
            if(persist&&AppSettings.Current.roOn){AppSettings.Current.roOn=false;AppSettings.Current.Save();}
            bool was=Enabled;Enabled=false;var active=runner;if(active!=null)active.Cancel=true;
            if(was){AppLog.Note("ro_stop",persist?"switched off":"stop all");Interrupt();}
        }
        internal void Connect(){if(disposed)return;if(Interlocked.Exchange(ref started,1)!=0)return;var t=new Thread(Loop);t.IsBackground=true;t.Start();}
        void Interrupt(){interrupted=true;var r=pending;if(r!=null){try{r.Abort();}catch(Exception){}}wake.Set();}
        // Whether a Repair Order may be opened in the selected COSTAR now, and why not. openAllowed: a
        // Repair Order may already be open (closing the one this helper left open).
        bool Free(out string detail,bool openAllowed=false) {
            if(!Enabled) { detail="Repair Orders are switched off on the RDP helper";return false; }
            if(coordinator.Busy) { detail=coordinator.Owner+" is filling COSTAR";return false; }
            if(coordinator.MobilePaused) { detail="Waiting: the Online orders tab is open on the RDP helper";return false; }
            var t=coordinator.Selected;
            if(t==null) { detail="No COSTAR is selected in the RDP helper";return false; }
            if(t.Branch!=TempeBranch) { detail="The selected COSTAR is "+t.Label+": Repair Orders from the phone are COSTAR Tempe's (Branch "+TempeBranch+"). Select COSTAR Tempe in the RDP helper";return false; }
            if(OrderCheckLink.IsWipWindow(t)) { detail="The selected COSTAR is Order Check's Work-in-Progress window";return false; }
            if(CostarInputLock.LegacyOpen()) { detail="Close the original online-order helper";return false; }
            if(Native.UserActiveWithin(QuietSeconds*1000)) { detail="Waiting for a quiet moment: someone is using the COSTAR PC";return false; }
            if(!openAllowed) {
                if(DateTime.UtcNow-checkedAt<TimeSpan.FromSeconds(3)) { detail=lastWhy;return lastFree; }
                string d;bool free=CostarWindows.Available(t,out d);
                if(!free&&d.StartsWith("A Repair Order is open",StringComparison.Ordinal)) d="A Repair Order is open in COSTAR "+t.Label+": close it (or finish the phone job waiting for review) first";
                checkedAt=DateTime.UtcNow;lastFree=free;lastWhy=free?"COSTAR "+t.Label+" is free":d;
                detail=lastWhy;return free;
            }
            detail="COSTAR "+t.Label+" ready";return true;
        }
        RoReply Request(RoHello hello) {
            var request=(HttpWebRequest)WebRequest.Create(settings.baseUrl.TrimEnd('/')+"/api/worker/v1/ro");
            request.Method="POST";request.ContentType="application/json";request.Headers["Authorization"]="Bearer "+settings.token;request.AllowAutoRedirect=false;request.Proxy=null;
            request.Timeout=8000+hello.waitMs;request.ReadWriteTimeout=8000+hello.waitMs;request.ServicePoint.Expect100Continue=false;
            request.ServerCertificateValidationCallback=delegate(object sender,X509Certificate cert,X509Chain chain,System.Net.Security.SslPolicyErrors errors) {
                if(cert==null)return false;using(var c=new X509Certificate2(cert))return DateTime.Now>=c.NotBefore&&DateTime.Now<=c.NotAfter&&Wire.Equal(Wire.Hash(c.RawData),settings.certificateHash);
            };
            byte[] bytes=Encoding.UTF8.GetBytes(Wire.Json(hello));request.ContentLength=bytes.Length;
            pending=request;
            try {
                using(var output=request.GetRequestStream())output.Write(bytes,0,bytes.Length);
                try {using(var response=request.GetResponse())using(var input=response.GetResponseStream())using(var reader=new StreamReader(input,Encoding.UTF8))return Wire.Read<RoReply>(reader.ReadToEnd());}
                catch(WebException e) {
                    if(e.Response!=null)using(var input=e.Response.GetResponseStream())using(var reader=new StreamReader(input)) {
                        string body=reader.ReadToEnd();var code=((HttpWebResponse)e.Response).StatusCode;
                        // A desk older than 2.6.0 answers this route with "key invalid" (401) or "not found".
                        if(code==HttpStatusCode.NotFound||code==HttpStatusCode.Unauthorized) throw new InvalidOperationException("The desk receiver did not take the Repair Order request ("+(int)code+"). Update the desk receiver to 2.6.0 (yellow line on the desk PC).");
                        throw new InvalidOperationException("Receiver rejected the request: "+body);
                    }
                    throw;
                }
            } finally { pending=null; }
        }
        void Loop() {
            while(!disposed) {
                bool held=false;
                try {
                    string detail;bool accepting=Enabled,available=false;
                    if(!accepting) detail="Repair Orders switched off on the RDP helper";
                    else if(busy) detail="Working on a Repair Order";
                    else available=Free(out detail);
                    string working=runLease??"";
                    RoReport report;int sequence;lock(gate){report=state.report==null?null:Wire.Copy(state.report);sequence=state.sequence;}
                    string declined=declineLease,declinedWhy=declineReason;
                    int waitMs=accepting&&!busy&&declined==null&&AppSettings.Current.longPoll?(available?8000:2000):0;
                    var clock=Stopwatch.StartNew();interrupted=false;
                    var reply=Request(new RoHello {workerId=settings.workerId,accepting=accepting,available=available,detail=EbayText.Clean(detail,400),report=report,waitMs=waitMs,working=working,declined=declined,declineReason=declinedWhy,sequence=sequence});
                    if(declined!=null&&declineLease==declined){declineLease=null;declineReason=null;}
                    held=reply!=null&&reply.held;
                    int waited=reply==null?0:Math.Max(0,reply.waitedMs);
                    RoundTripMs=(int)Math.Max(0,clock.ElapsedMilliseconds-waited);lastContactTick=Environment.TickCount==0?1:Environment.TickCount;
                    Connection="Desk PC connected";if(!busy)Detail=detail;
                    if(reply!=null&&report!=null&&reply.ack==report.sequence) lock(gate) { if(state.report!=null&&state.report.sequence==report.sequence){state.report=null;try{Save();}catch(Exception){}} }
                    if(reply!=null&&reply.command=="do"&&reply.task!=null&&!busy&&!disposed) {
                        if(Enabled) Accept(reply.task);
                        else if(reply.task.lease!=lastStartedLease) Decline(reply.task.lease,"Repair Orders switched off on the RDP helper");
                    }
                } catch(Exception e) {
                    if(disposed) break;
                    if(interrupted){interrupted=false;continue;}
                    Connection="Desk PC not reachable: "+e.Message;AppLog.PollError("ro: "+e.Message);
                }
                if(!disposed){int ms=held?100:Enabled?2000:3000;wake.WaitOne(ms);}
            }
        }
        // The lease of the last request started: one handed back again before its result is in (the
        // report not acknowledged yet) is never started a second time.
        volatile string lastStartedLease,runLease,runId;
        void Accept(RoTask task) {
            if(String.IsNullOrWhiteSpace(task.lease)||task.lease==lastStartedLease) return;
            if(task.kind!="list") {
                if(!RoEdit.IsDoc(task.doc)) { Report(task.id,task.lease,"failed","The Repair Order number isn't valid.","",false,false);return; }
                if(task.kind=="edit") {
                    try { Order.Require(task.edit!=null&&task.edit.doc==task.doc,"The change is for another Repair Order.");task.edit.ValidateShape(); }
                    catch(InvalidOperationException e) { Report(task.id,task.lease,"failed","Not changed: "+e.Message,"",false,false);return; }
                }
            }
            if(task.kind=="close") {
                RoLeftOpen left;lock(gate) left=state.leftOpen;
                if(left==null||left.doc!=task.doc) { Report(task.id,task.lease,"failed","The RDP helper didn't leave Repair Order "+task.doc+" open. If it is open in COSTAR, close it there.","",false,false);return; }
            }
            EntryLease entry=null;
            if(task.kind!="list") {
                string detail;
                if(!Free(out detail,task.kind=="close")) { Decline(task.lease,detail);return; }
                entry=coordinator.TryBegin("Repair Order "+task.doc,true);
                if(entry==null) { Decline(task.lease,(coordinator.Owner.Length>0?coordinator.Owner:"Another entry")+" is filling COSTAR");return; }
            }
            bool startedThread=false,claimed=false;
            try {
                lock(gate) {
                    if(busy||disposed) return;
                    if(!Enabled) { Decline(task.lease,"Repair Orders switched off on the RDP helper");return; }
                    busy=true;claimed=true;runLease=task.lease;runId=task.id;lastStartedLease=task.lease;
                }
                var e2=entry;
                var thread=new Thread(delegate(){ if(task.kind=="list") RunList(task); else Run(task,e2); });
                thread.IsBackground=true;thread.SetApartmentState(ApartmentState.STA);thread.Start();startedThread=true;
            } finally { if(!startedThread){if(claimed){runLease=null;runId=null;lastStartedLease=null;busy=false;}if(entry!=null)entry.Dispose();} }
        }
        // Progress words for the phone (at most one report every 2.5 s).
        void Progress(string message) {
            log("RO: "+message);Detail=message;
            if(progressClock.ElapsedMilliseconds<2500) return;
            progressClock.Restart();
            var r=runner;string id=runId,lease=runLease;
            if(id==null||lease==null) return;
            try { Report(id,lease,"working",message,message,r!=null&&(r.Writes>0||r.Touched),false); } catch(Exception) { }
        }
        void Finish() { runLease=null;runId=null;busy=false;Current="";Interrupt(); }
        void RunList(RoTask task) {
            try {
                Current="Work-in-Progress list";
                Report(task.id,task.lease,"working","Reading COSTAR Tempe's Work-in-Progress","",false,false);
                RoList list=null;string why=null,detail;var t=coordinator.Selected;
                bool free=Free(out detail),freeWithOpenRo=!free&&Free(out detail,true);
                if(free||freeWithOpenRo) {
                    // With a Repair Order open nothing is pressed: the list is read as COSTAR shows it.
                    var entry=coordinator.TryBegin("Work-in-Progress list",true);
                    if(entry!=null) {
                        try {
                            // Search is pressed only with no Repair Order open now (looked at again here, not
                            // taken from the check a few seconds ago).
                            bool search=free&&CostarWindows.Orders(entry.Target).Count==0;
                            using(new CostarInputLock()) list=RoWip.ReadList(entry.Target,search,delegate{return disposed||!Enabled;});
                        }
                        catch(Exception e) { why=e.Message; }
                        finally { entry.Dispose(); }
                    } else why=(coordinator.Owner.Length>0?coordinator.Owner:"Another entry")+" is filling COSTAR";
                } else { Free(out detail);why=detail; }
                if(list==null) {
                    var copy=RoWip.FromOrderCheck(TimeSpan.FromMinutes(15));
                    if(copy!=null) { copy.note=copy.note+(why==null?"":" (COSTAR Tempe was busy: "+why+")");list=copy; }
                }
                if(list!=null) {
                    string words=list.rows.Count+" Repair Orders in Work-in-Progress"+(String.IsNullOrEmpty(list.note)?"":" · "+list.note);
                    Report(task.id,task.lease,"done",words,"",false,false,null,list);
                    LastLine="WIP list read ("+list.rows.Count+") at "+DateTime.Now.ToString("HH:mm");
                    AppLog.Note("ro_list",list.rows.Count+" rows from "+list.source);
                } else {
                    Report(task.id,task.lease,"failed","The Work-in-Progress list couldn't be read: "+(why??(t==null?"no COSTAR is selected":"COSTAR is busy")),"",false,false);
                    AppLog.Note("ro_list_failed",why??"");
                }
            } catch(Exception e) {
                try { Report(task.id,task.lease,"failed","The Work-in-Progress list couldn't be read: "+e.Message,"",false,false); } catch(Exception) { }
            } finally { Finish(); }
        }
        static Order RoOrder(string doc) { return new Order {orderId="RO-"+doc,comment="",customer=new Customer {name="",phone=""},lines=new List<OrderLine>()}; }
        void Run(RoTask task,EntryLease entry) {
            CostarInputLock inputLock=null;var clock=Stopwatch.StartNew();string doc=task.doc;RoAttempt attempt=null;IntPtr window=IntPtr.Zero;Runner r=null;
            var watch=new RoOpenWatch();CostarInstance target=null;
            string what=task.kind=="edit"?"Changing":task.kind=="close"?"Closing":"Opening";
            try {
                Current=what+" Repair Order "+doc;progressClock.Restart();
                inputLock=new CostarInputLock();var t=entry.Target;target=t;CostarWindows.Main(t);
                coordinator.Progress.Begin("Repair Order",doc,task.kind=="edit"?10:3);
                if(task.kind=="close") { RunClose(task,t);return; }
                attempt=new RoAttempt {id=task.id,lease=task.lease,kind=task.kind,doc=doc,processId=t.Pid,processStart=t.Started,atUtc=Now};
                Running(attempt);
                Report(task.id,task.lease,"working",what+" Repair Order "+doc+" in COSTAR "+t.Label,"",false,false);
                AppLog.Note("ro_"+task.kind+"_start",doc+(task.kind=="edit"?" ("+task.edit.Summary()+")":""));
                RoWip.Spot spot;bool selected;
                window=RoWip.Open(t,doc,delegate{return !Enabled||disposed;},Progress,watch,out spot,out selected);
                attempt.window=window.ToInt64();Running(attempt);
                r=new Runner(t.Pid,t.Branch,RoOrder(doc),"",false,Progress,window.ToInt64());runner=r;
                r.OnStage=coordinator.Progress.Stage;
                r.BeforeFirstWrite=delegate { if(!attempt.touched){attempt.touched=true;Running(attempt);} };
                r.Cancel=!Enabled||disposed;
                var snap=r.ReadRo(doc,spot.Row,selected);
                List<string> notes=new List<string>();string done="";
                if(task.kind=="edit") {
                    if(snap.sig!=task.edit.baseSig) {
                        // Someone changed it after the phone read it: nothing is typed; the phone gets what it holds now.
                        bool shut=r.CloseRo();
                        if(!shut) Left(doc,window,t);
                        lock(gate) { state.running=null;SetReport(task.id,task.lease,"failed","CHANGED: Repair Order "+doc+" changed after your phone read it, so nothing was typed. Here is what it holds now: check your changes and save again."+(shut?"":" COSTAR didn't close it (it may be asking something): close it at the PC."),"",false,!shut,snap);Save(); }
                        Interrupt();coordinator.Progress.End(false,doc+" changed meanwhile");
                        AppLog.Note("ro_edit_changed",doc);
                        r.Diag.Completed();
                        return;
                    }
                    snap=r.EditRo(task.edit,snap);
                    notes.AddRange(r.RoNotes);notes.AddRange(r.Checks);
                    done="Saved to COSTAR: "+task.edit.Summary()+".";
                }
                bool closed=r.CloseRo();
                if(!closed) Left(doc,window,t);
                string closing=closed?(task.kind=="edit"?"Closed again (it's in Work-in-Progress).":"Read and closed again.")
                    :task.kind=="edit"?"All of it is in and checked, but COSTAR didn't close the Repair Order: it may be asking something at the PC. Answer it there, then close it (or close it from the phone)."
                    :"COSTAR didn't close it again (it may be asking something at the PC): close it there or from the phone.";
                lock(gate) { state.running=null;SetReport(task.id,task.lease,"done",(done.Length>0?done+" ":"")+closing,"",task.kind=="edit",!closed,snap,null,notes);Save(); }
                Detail=done.Length>0?done:"Read Repair Order "+doc+".";log("RO: "+Detail);Interrupt();
                r.Diag.Completed();
                LastLine=(task.kind=="edit"?"Changed ":"Read ")+doc+(notes.Count>0?" (check by hand)":"")+(closed?"":" (left open)")+" at "+DateTime.Now.ToString("HH:mm");
                coordinator.Progress.End(true,doc+(task.kind=="edit"?" changed":" read")+(closed?"":", left open"));
                AppLog.Note("ro_"+task.kind+"_ok",doc+" in "+(clock.ElapsedMilliseconds/100/10.0).ToString("0.0",CultureInfo.InvariantCulture)+" s run="+r.Diag.RunId+(notes.Count>0?" notes="+notes.Count:"")+(closed?"":" left open"));
            } catch(Exception e) {
                try{if(r!=null)r.Diag.Stopped(e);}catch{}
                // Typed: a write was tried (counted before it goes), not only one that went through.
                bool typed=(attempt!=null&&attempt.touched)||(r!=null&&(r.Writes>0||r.Touched)),leftOpen=false,gone=false;string extra="";
                // A Repair Order window that opened but wasn't handed over (the open stopped after it
                // appeared) is this helper's only when nobody used the PC meanwhile and it is the only one.
                if(window==IntPtr.Zero&&target!=null&&watch.Before!=null&&!watch.UserActive) {
                    try {
                        var fresh=CostarWindows.Orders(target).Where(x=>!watch.Before.Contains(x.ToInt64())).ToList();
                        if(fresh.Count==1&&Branches.OrderTitle(Native.Caption(fresh[0]),target.Branch)) window=fresh[0];
                        else if(fresh.Count>1) extra=" COSTAR opened "+fresh.Count+" Repair Order windows: check them and close them at the PC.";
                    } catch(Exception) { }
                } else if(window==IntPtr.Zero&&watch.UserActive) extra=" If a Repair Order opened, it was left as it is.";
                if(window!=IntPtr.Zero) {
                    if(Native.IsWindow(window)) {
                        bool shut=false;
                        // Closed again only when nothing was typed and no Stop was pressed; never over a COSTAR question.
                        if(!typed&&!(e is OperationCanceledException)) { try { shut=r!=null?r.CloseRo():CloseWindow(window); } catch(Exception) { shut=false; } }
                        if(!shut&&Native.IsWindow(window)) { try { Left(doc,window,entry.Target); } catch(Exception) { } leftOpen=true; }
                    } else gone=true;
                }
                string message=(e.Message.StartsWith("CHANGED:",StringComparison.Ordinal)?"":"Stopped: ")+e.Message;
                if(typed&&r!=null&&r.RoDone.Count>0) message+=" Already changed: "+String.Join("; ",r.RoDone.ToArray())+".";
                if(leftOpen) message+=" Repair Order "+doc+" is left open in COSTAR Tempe: check it there, then close it (or close it from the phone).";
                else if(typed) message+=gone?" The Repair Order was closed while the helper was typing (at the PC, or COSTAR stopped): check Repair Order "+doc+" in COSTAR Tempe.":" Check Repair Order "+doc+" in COSTAR Tempe.";
                else if(window!=IntPtr.Zero) message+=gone?" It was closed before anything was typed.":" Nothing was changed; it was closed again.";
                message+=extra;
                LastLine=doc+" stopped at "+DateTime.Now.ToString("HH:mm");
                coordinator.Progress.End(false,doc+" stopped: "+e.Message);
                AppLog.Note("ro_"+task.kind+"_stopped",doc+" "+RoText.ForLog(e.Message)+(typed?" (typed)":"")+(leftOpen?" (left open)":"")+(r!=null?" run="+r.Diag.RunId:""));
                try { lock(gate) { state.running=null;SetReport(task.id,task.lease,"failed",message,"",typed,leftOpen);Save(); } Detail=message;log("RO: "+message);Interrupt(); }
                catch(Exception persist) { Enabled=false;log("RO: Repair Orders stopped: the result could not be saved. "+persist.Message); }
            } finally {
                try{if(r!=null){r.Dispose();log("RO: COSTAR report: "+r.ZipPath);}}catch(Exception){}
                finally{runner=null;try{if(inputLock!=null)inputLock.Dispose();}finally{try{entry.Dispose();}finally{Finish();}}}
            }
        }
        // Remembered so the phone (or a person) can have it closed later.
        void Left(string doc,IntPtr window,CostarInstance t) {
            lock(gate) { state.leftOpen=new RoLeftOpen {doc=doc,window=window.ToInt64(),processId=t.Pid,processStart=t.Started,atUtc=Now};state.running=null;Save(); }
        }
        // WM_CLOSE to a Repair Order window, only while nothing of COSTAR's is open on it.
        static bool CloseWindow(IntPtr window) {
            if(!Native.IsWindow(window)) return true;
            if(Runner.CloseBlocker(window)!=null) return false;
            UIntPtr result;Native.WriteMessage(window,0x10,UIntPtr.Zero,null,3,1000,out result);
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<8000) { if(!Native.IsWindow(window)) return true;Thread.Sleep(100); }
            return false;
        }
        // Closes the Repair Order this helper left open (only that window, in the same COSTAR, and only
        // while COSTAR shows nothing on it).
        void RunClose(RoTask task,CostarInstance t) {
            RoLeftOpen left;lock(gate) left=state.leftOpen;
            Order.Require(left!=null&&left.doc==task.doc,"The RDP helper didn't leave Repair Order "+task.doc+" open.");
            var h=new IntPtr(left.window);
            if(!Native.IsWindow(h)||(int)Native.Pid(h)!=left.processId) {
                lock(gate) { state.leftOpen=null;SetReport(task.id,task.lease,"done","Repair Order "+task.doc+" was already closed.","",false,false);Save(); }
                coordinator.Progress.End(true,task.doc+" was already closed");
                LastLine="Already closed: "+task.doc+" at "+DateTime.Now.ToString("HH:mm");
                Interrupt();return;
            }
            Order.Require(left.processId==t.Pid&&left.processStart==t.Started&&Native.Caption(h).StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase),"That Repair Order belongs to another COSTAR. Close it at the PC.");
            string why=Runner.CloseBlocker(h);
            if(why!=null) {
                lock(gate) { SetReport(task.id,task.lease,"failed","Repair Order "+task.doc+" wasn't closed: "+why+". Answer it at the PC, then close it there (or from the phone).","",false,true);Save(); }
                coordinator.Progress.End(false,task.doc+" not closed");
                LastLine="Couldn't close "+task.doc+" at "+DateTime.Now.ToString("HH:mm");
                AppLog.Note("ro_close","blocked");
                Interrupt();return;
            }
            Progress("Closing Repair Order "+task.doc+".");
            bool shut=CloseWindow(h);
            lock(gate) {
                if(shut) state.leftOpen=null;
                SetReport(task.id,task.lease,shut?"done":"failed",shut?"Closed Repair Order "+task.doc+" (it's in Work-in-Progress).":"COSTAR didn't close Repair Order "+task.doc+": it may be asking something. Answer it at the PC.","",false,!shut);Save();
            }
            AppLog.Note("ro_close",task.doc+(shut?" closed":" still open"));
            coordinator.Progress.End(shut,task.doc+(shut?" closed":" not closed"));
            LastLine=(shut?"Closed ":"Couldn't close ")+task.doc+" at "+DateTime.Now.ToString("HH:mm");
            Interrupt();
        }
        public void Dispose(){disposed=true;Stop(false);}
    }
}
