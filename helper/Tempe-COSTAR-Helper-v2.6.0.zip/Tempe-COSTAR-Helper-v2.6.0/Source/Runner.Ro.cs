// The entry engine, part 5 (2.6.0): Repair Orders from the phone. Reads a Repair Order the helper
// opened from Work-in-Progress, types the phone's changes into it, checks the result and closes it
// again. Nothing is saved, sold or printed: COSTAR keeps the Repair Order in Work-in-Progress.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    internal sealed partial class Runner {
        string roDoc="";List<ControlInfo> lastLook;
        // What this run changed so far, in words without customer details (said when a change stops).
        internal readonly List<string> RoDone=new List<string>();
        // Said with the result: boxes COSTAR changed by itself.
        internal readonly List<string> RoNotes=new List<string>();
        // ---- Reading ----
        List<ControlInfo> WaitForRo() {
            Say("Waiting for COSTAR to show Repair Order "+roDoc+".");
            var wait=Diag.Wait("ro_open");
            try {
                var timer=Stopwatch.StartNew();string problem="COSTAR has not finished opening the Repair Order.";
                while(timer.ElapsedMilliseconds<30000) {
                    wait.Tick();Check(false);
                    var front=Native.GetForegroundWindow();
                    if(front==root&&Native.IsWindowEnabled(root)) {
                        var s=Snapshot(root);
                        if(lastSnapshotBusy) { problem="COSTAR is busy drawing the Repair Order.";Pause(150);continue; }
                        try {
                            Selectors.Header(s);Selectors.ProductGrid(s);Selectors.Total(s);
                            if(s.Any(c=>c.TextState=="read-failed-or-timed-out")) { problem="COSTAR was still drawing the Repair Order.";Pause(150);continue; }
                            wait.Done("ok");return s;
                        } catch(InvalidOperationException e) { problem=e.Message; }
                    } else if(front!=root) {
                        if(front!=IntPtr.Zero) Diag.ForegroundLost(front,Native.IsWindowEnabled(root));
                        problem="Another window is in front of the Repair Order ("+DescribeCover(front)+").";
                        // Another program on top and nobody using the PC: COSTAR back in front (a few times).
                        if(front!=IntPtr.Zero&&Native.Pid(front)!=pid&&!Native.UserActiveWithin(2000)&&focusRecoveries<3) { focusRecoveries++;Native.BringToFront(root); }
                    }
                    Pause(60);
                }
                wait.Done("timeout");
                throw new InvalidOperationException("Repair Order "+roDoc+" didn't finish opening in COSTAR. "+problem);
            } finally { wait.End(); }
        }
        // EM_GETLIMITTEXT: the most letters a box takes (0 when it doesn't say).
        int LimitOf(ControlInfo c) {
            if(c==null) return 0;UIntPtr result;
            if(Native.SendNull(new IntPtr(c.Handle),0xD5,UIntPtr.Zero,IntPtr.Zero,3,500,out result)==IntPtr.Zero) return 0;
            ulong n=result.ToUInt64()&0xFFFFFFFF;return n>0&&n<100000?(int)n:0;
        }
        // The Repair Order as it is: two full looks that agree (COSTAR holding still), read into a
        // snapshot (Customer Waiting through accessibility; a calendar box's text read directly).
        RoSnapshot RoLook(string why) {
            var wait=Diag.Wait("ro_look");
            try {
                var timer=Stopwatch.StartNew();string previous=null,problem="";
                while(timer.ElapsedMilliseconds<20000) {
                    wait.Tick();Ready();
                    try {
                        List<ControlInfo> gs;bool counted;SteadyGrid(why,true,out gs,out counted);
                        var s=Current();
                        if(lastSnapshotBusy||s.Any(c=>c.TextState=="busy"||c.TextState=="read-failed-or-timed-out")) { problem="COSTAR was busy.";previous=null;Pause(150);continue; }
                        string kind;var date=RoSelectors.DateIn(s,out kind);
                        if(date!=null&&date.TextState!="read") { string t;if(Native.TryText(new IntPtr(date.Handle),out t)) { date.Text=t;date.TextState="read"; } }
                        string waitingWhy;string waiting=WaitingState(s,out waitingWhy);
                        var snap=RoRead.Build(s,roDoc,waiting,waitingWhy,LimitOf);
                        lastLook=s;
                        if(snap.sig==previous) { wait.Done("ok");return snap; }
                        previous=snap.sig;
                    } catch(InvalidOperationException e) { problem=e.Message;previous=null; }
                    Pause(100);
                }
                wait.Done("timeout");
                throw new InvalidOperationException("Repair Order "+roDoc+" kept changing while it was read ("+why+"). "+problem);
            } finally { wait.End(); }
        }
        // Repair Order `doc`, just opened from Work-in-Progress: waited for, read, and checked to be that
        // one. Nothing is clicked or typed. wip: its Work-in-Progress row; selected: that row was the
        // list's selected one after it was opened.
        internal RoSnapshot ReadRo(string doc,RoListRow wip,bool selected) {
            roDoc=doc;Diag.Kind="ro";runClock.Restart();if(stageCount<2) stageCount=2;
            try {
                Diag.BeginStage("Read the Repair Order");Stage("Reading Repair Order "+doc);
                Activate();var first=WaitForRo();Dump("ro-before-controls",first);Diag.Layout(first);
                var snap=RoLook("reading it");
                RoIdentity(lastLook,snap,wip,selected);
                // The PO# as it is: what leaving the item lines checks stays the same (LeaveGrid).
                order.orderId=Order.Clean(snap.po);
                Say("Read Repair Order "+doc+": "+snap.lines.Count+" line(s), total $"+(snap.totalCents/100m).ToString("0.00",CultureInfo.InvariantCulture)+".");
                Diag.EndStage(true);
                return snap;
            } catch(Exception e) { Say("STOPPED: "+e.Message);try{CaptureForegroundWindow(e.Message);Dump("stopped-controls",Snapshot(root));}catch{}throw; }
            finally { log.Flush(); }
        }
        // Is this the Repair Order that was asked for? COSTAR's window title has no number, so: its number
        // in a box nobody types into (a label or a read-only box; never a customer box or an item line, so
        // a comment or a note naming another Repair Order's number doesn't count), or else its name,
        // comment and PO# as in its Work-in-Progress row with that row being the selected one (or the
        // same total).
        void RoIdentity(List<ControlInfo> s,RoSnapshot snap,RoListRow wip,bool selected) {
            bool shown=NumberShown(s,roDoc);
            bool name=wip!=null&&Order.Norm(wip.name).Length>0&&Order.Norm(snap.name)==Order.Norm(wip.name);
            bool comment=wip!=null&&(Order.Norm(wip.comment).Length==0?Order.Norm(snap.comment).Length==0:Order.Norm(snap.comment).StartsWith(Order.Norm(wip.comment),StringComparison.Ordinal));
            bool po=wip!=null&&(wip.po==null||Order.Norm(snap.po)==Order.Norm(wip.po));
            int wipCents=wip==null?-1:RoRead.Cents(wip.total);bool total=wipCents>=0&&wipCents==snap.totalCents;
            Diag.EventRaw("ro_identity","number shown="+shown+" name="+name+" comment="+comment+" po="+po+" total="+total+" selected="+selected);
            Order.Require(shown||(name&&comment&&po&&(selected||total)),"The Repair Order COSTAR opened doesn't look like "+roDoc+" (its "+(!name?"name":!comment?"comment":!po?"PO#":"number")+" isn't as in Work-in-Progress). Nothing was changed.");
        }
        // The Repair Order's number in a label or a read-only box (not a box anybody types into: the
        // customer boxes, the item lines, any box that takes typing).
        internal static bool NumberShown(List<ControlInfo> s,string doc) {
            string digits=Regex.IsMatch(doc??"",@"^\d+$")?doc.TrimStart('0'):null;
            var typedInto=new HashSet<long>();var gridPanels=new HashSet<long>();
            try { var h=Selectors.Header(s);foreach(var c in new[]{h.Name,h.Account,h.Address,h.Address2,h.Suburb,h.State,h.Postcode,h.Phone,h.Email,h.PO,h.Comment}) if(c!=null) typedInto.Add(c.Handle); }
            catch(InvalidOperationException) { }
            try { foreach(var r in Selectors.ProductGrid(s).Rows) gridPanels.Add(r.Parent); } catch(InvalidOperationException) { }
            if(s==null) return false;
            foreach(var c in s) {
                if(c.TextState!="read"||String.IsNullOrEmpty(c.Text)||typedInto.Contains(c.Handle)||gridPanels.Contains(c.Parent)) continue;
                bool fixedBox=c.Visible&&c.Class.IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)>=0&&(!c.Enabled||(c.Style&0x800)!=0);
                if(!c.Static&&!fixedBox) continue;
                string t=Order.Norm(c.Text);
                if(t==doc) return true;
                if(digits!=null&&digits.Length>=4) foreach(Match m in Regex.Matches(t,@"\d+")) if(m.Value.TrimStart('0')==digits) return true;
            }
            return false;
        }
        // ---- Changing ----
        // The phone's change, typed into this Repair Order (read just before: `before`). Every box is
        // found first (nothing typed if one is missing); then line changes, lines out (the lowest first),
        // new lines, the car, the header boxes (the phone last), Ship Via, Date In, Customer Waiting; out
        // of the item lines; one more look, compared with what was asked. Stops at the first thing that
        // isn't right (RoDone says what went in before it).
        internal RoSnapshot EditRo(RoEdit edit,RoSnapshot before) {
            edit.Validate(before);
            int changes=edit.lines==null?0:edit.lines.Count,adds=edit.add==null?0:edit.add.Count,boxes=edit.header==null?0:edit.header.Count;
            stageCount=stageIndex+2+changes+adds+boxes+(edit.CarChange?1:0)+(edit.shipVia!=null?1:0)+(edit.dateIn!=null?1:0)+(edit.customerWaiting!=null?1:0);
            Timed("Find every box to change",delegate { RoPreflight(edit,before); });
            int count=before.lines.Count;
            if(edit.lines!=null) {
                foreach(var l in edit.lines.Where(x=>!x.remove).OrderBy(x=>x.index).ToList()) { var c=l;Timed("Line "+(c.index+1)+" "+Order.Norm(c.code),delegate { RoChangeLine(c,count); }); }
                foreach(var l in edit.lines.Where(x=>x.remove).OrderByDescending(x=>x.index).ToList()) { var c=l;int n=count;Timed("Take out line "+(c.index+1)+" "+Order.Norm(c.code),delegate { RoRemove(c.index,Order.Norm(c.code),n); });count--; }
            }
            if(edit.add!=null) foreach(var a in edit.add) { var c=a;Timed(c.kind=="item"?"Add "+Order.Norm(c.code):"Add a note",delegate { if(c.kind=="item") RoAddItem(c,before.det);else RoAddNote(c.text); }); }
            if(edit.CarChange) Timed("Car",delegate { RoCar(edit,before.det); });
            if(boxes>0) RoHeader(edit);
            if(edit.shipVia!=null) Timed("Ship Via",delegate { RoStep("Ship Via "+Order.Norm(edit.shipVia),"Ship Via typed (not checked)",delegate { RoShipVia(edit.shipVia); }); });
            if(edit.dateIn!=null) Timed("Date In",delegate {
                string day=DateTime.ParseExact(edit.dateIn,"yyyy-MM-dd",CultureInfo.InvariantCulture).ToString("dd/MM/yyyy",CultureInfo.InvariantCulture);
                RoStep("Date In "+day,"Date In typed as "+day+" (not checked)",delegate { RoDateIn(edit.dateIn); });
            });
            if(edit.customerWaiting!=null) Timed("Customer Waiting",delegate {
                bool tick=edit.customerWaiting=="yes";
                RoStep(tick?"Customer Waiting ticked":"Customer Waiting unticked","Customer Waiting clicked (not checked)",delegate { SetWaiting(tick); });
            });
            RoSnapshot after=null;
            Timed("Final check",delegate {
                // Out of the item lines first (COSTAR keeps a line once it is left), as a click on Close does.
                LeaveGrid("after the changes");
                after=RoLook("the final check");
                var notes=new List<string>();var problems=RoExpect.Check(before,edit,after,notes);
                foreach(var n in notes) if(!RoNotes.Contains(n)) RoNotes.Add(n);
                try { Dump("ro-after-controls",lastLook); } catch(Exception) { }
                Order.Require(problems.Count==0,"The Repair Order doesn't show everything that was asked: "+String.Join(" ",problems.ToArray()));
            });
            Say("All changes are in Repair Order "+roDoc+".");
            return after;
        }
        static ControlInfo HeaderBox(FieldMap h,string key) {
            switch(key) {
                case "name":return h.Name;case "phone":return h.Phone;case "email":return h.Email;case "address":return h.Address;case "address2":return h.Address2;
                case "suburb":return h.Suburb;case "state":return h.State;case "postcode":return h.Postcode;case "po":return h.PO;case "comment":return h.Comment;
                default:throw new InvalidOperationException("Unknown box "+key+".");
            }
        }
        // Every box the change types into, found before anything is typed.
        void RoPreflight(RoEdit edit,RoSnapshot before) {
            Ready();var s=Current();var h=Selectors.Header(s);
            if(edit.header!=null) foreach(var key in edit.header.Keys) {
                var box=HeaderBox(h,key);CheckTarget(box);
                Order.Require((Native.GetWindowLong(new IntPtr(box.Handle),-16)&0x800)==0,"The "+RoEdit.Label(key)+" is locked in COSTAR. Nothing was changed.");
            }
            if(edit.shipVia!=null) { var box=Selectors.ShipVia(s);Order.Require(box!=null,"The Ship Via box isn't showing. Nothing was changed.");CheckTarget(box); }
            if(edit.dateIn!=null) { string kind;var box=RoSelectors.DateIn(s,out kind);Order.Require(box!=null&&(kind=="edit"||kind=="combo"),"Date In can't be typed into on this Repair Order. Nothing was changed.");CheckTarget(box); }
            if(edit.customerWaiting!=null) { string why;string now=WaitingState(s,out why);Order.Require(now.Length>0&&why.Length==0,"Customer Waiting can't be changed: "+why+" Nothing was changed."); }
            int count=before.lines.Count;
            if(edit.lines!=null) foreach(var l in edit.lines) {
                List<ControlInfo> gs;Grid g;string code=Order.Norm(l.code);var row=FilledRow(l.index,code,count,out gs,out g);
                if(l.qty!=null) Selectors.Cell(gs,row,g.Quantity);
                if(l.price!=null) Selectors.Cell(gs,row,code=="F"?g.ListPrice:g.Net);
                if(l.text!=null) Selectors.Cell(gs,row,g.Description);
            }
            if(edit.CarChange&&before.det) {
                var gs2=GridCurrent();
                foreach(var p in new[]{new{Prefix="MAKE/MODEL",Code="M",Given=edit.makeModel},new{Prefix="REGO NO",Code="M",Given=edit.rego},new{Prefix="ODOMETER",Code="M ODO",Given=edit.odometer}})
                    if(p.Given!=null) Order.Require(Selectors.FindMemo(gs2,p.Prefix,p.Code)!=null,"DET's "+p.Prefix+" note isn't there. Nothing was changed.");
            }
            Say("Found every box to change; nothing typed yet.");
        }
        // The `index`-th filled line (0-based), which must hold `code`, with `count` filled lines in all.
        ControlInfo FilledRow(int index,string code,int count,out List<ControlInfo> s,out Grid g) {
            bool counted;g=SteadyGrid("line "+(index+1),false,out s,out counted);
            Order.Require(g!=null,"COSTAR's item lines kept changing, so line "+(index+1)+" can't be found safely. Stopped.");
            var filled=g.Rows.Where(r=>r.Value.Length>0).ToList();
            Order.Require(filled.Count==count,"The Repair Order now has "+filled.Count+" filled lines instead of "+count+". Stopped.");
            Order.Require(index<filled.Count&&Order.Norm(filled[index].Value)==code,"Line "+(index+1)+" is not "+code+" any more. Stopped.");
            return filled[index];
        }
        static string PriceText(string price) { return Decimal.Parse(price,NumberStyles.Number,CultureInfo.InvariantCulture).ToString("0.00",CultureInfo.InvariantCulture); }
        // A step that may type. It goes into RoDone as soon as it may have reached COSTAR: `done` once
        // it is checked, `maybe` (what may have gone in) when it stops after typing, nothing when it typed
        // nothing (COSTAR already showed it). A stop never tells the phone less than went in.
        void RoStep(string done,string maybe,Action act) {
            int before=writeAttempts;
            try { act(); }
            catch(Exception) { if(writeAttempts>before) RoDone.Add(maybe);throw; }
            if(writeAttempts>before) RoDone.Add(done);
        }
        void RoChangeLine(RoLineEdit c,int count) {
            string code=Order.Norm(c.code),label=code+" (line "+(c.index+1)+")";
            if(c.text!=null) RoStep("note "+label+" changed","note "+label+" typed (its words not checked)",delegate { RoNoteText(c.index,code,count,c.text,"note "+label); });
            if(c.qty!=null) RoStep("quantity of "+label+" "+RoRead.Num(c.qty),"quantity of "+label+" typed as "+RoRead.Num(c.qty)+" (not checked)",delegate { RoCell(c.index,code,count,true,c.qty,"quantity of "+label); });
            if(c.price!=null) RoStep("price of "+label+" $"+PriceText(c.price),"price of "+label+" typed as $"+PriceText(c.price)+" (not checked)",delegate { RoCell(c.index,code,count,false,c.price,"price of "+label); });
        }
        // A quantity (qty) or price box of a line: typed, committed, read again where the line is now.
        void RoCell(int index,string code,int count,bool qty,string value,string label) {
            List<ControlInfo> s;Grid g;var row=FilledRow(index,code,count,out s,out g);
            Func<Grid,ControlInfo> column=delegate(Grid x) { return qty?x.Quantity:code=="F"?x.ListPrice:x.Net; };
            string want=qty?RoRead.Num(value):PriceText(value);
            Func<string,bool> same=delegate(string t) { return qty?RoRead.Num(t)==RoRead.Num(value):RoRead.Cents(t)==RoRead.Cents(value); };
            var cell=Selectors.Cell(s,row,column(g));
            if(same(ReadLive(cell))) { Say("The "+label+" is already "+want+".");return; }
            Put(cell,want,label,true);Ready();
            row=FilledRow(index,code,count,out s,out g);
            string now=ReadLive(Selectors.Cell(s,row,column(g)));
            Order.Require(same(now),"The "+label+" didn't keep "+want+" (COSTAR shows "+now+").");
        }
        void RoNoteText(int index,string code,int count,string text,string label) {
            string expected=Order.EntryText(Order.Clean(text));
            Func<MemoTarget> locate=delegate {
                var s=GridCurrent();var g=Selectors.ProductGrid(s);var filled=g.Rows.Where(r=>r.Value.Length>0).ToList();
                Order.Require(filled.Count==count&&index<filled.Count&&Order.Norm(filled[index].Value)==code,"Line "+(index+1)+" moved. Stopped.");
                return new MemoTarget {Row=filled[index],Editor=Selectors.Cell(s,filled[index],g.Description)};
            };
            List<ControlInfo> s0;Grid g0;var row=FilledRow(index,code,count,out s0,out g0);
            var target=FocusMemo(locate,label,new MemoTarget {Row=row,Editor=Selectors.Cell(s0,row,g0.Description)});
            WriteNote(target.Editor,expected,label);Ready();
            NoteBack(locate,expected,label);
        }
        void NoteBack(Func<MemoTarget> locate,string expected,string label) {
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<3000) { Ready();try { if(Order.Norm(locate().Editor.Value)==Order.Norm(expected)) return; } catch(InvalidOperationException) { } Pause(25); }
            throw new InvalidOperationException("The "+label+" didn't keep its words.");
        }
        // A key into a box (no Shift/Ctrl/Alt/Windows held, COSTAR in front, the box focused).
        void RoKey(IntPtr h,ushort key,string label) {
            for(int attempt=1;;attempt++) {
                Native.NoModifiers();Check(true);
                Order.Require(Native.Focus(root)==h,"The "+label+" lost focus before a key press.");
                if(Native.HeldModifier()==null) break;
                Order.Require(attempt<3,"A Shift, Ctrl, Alt or Windows key kept going down just before a key press in the "+label+".");
            }
            Native.KeyNow(key);Diag.Key();
        }
        // Taking a line out as Tommy does (27 Oct): click its item code, then Delete; if that does
        // nothing, its right-click menu's Delete. The cursor goes after the code's last letter first, so
        // a Delete key COSTAR doesn't take as "take the line out" changes nothing. A COSTAR question about
        // deleting the line (Yes and No, on the Repair Order) is answered Yes; any other stops. A line
        // that only lost its code (its words or price left) stops at once: nothing more is tried.
        void RoRemove(int index,string code,int count) {
            string label="line "+(index+1)+" ("+code+")";
            List<ControlInfo> s;Grid g;var row=FilledRow(index,code,count,out s,out g);
            var expected=Filled(g);expected.RemoveAt(index);
            int loose=RoRead.Loose(s,g);
            RoStep(label+" taken out",label+": Delete pressed, not seen taken out (check whether it is still there)",delegate {
                Focus(row);var h=new IntPtr(row.Handle);
                string text=ReadNote(h,label);WaitIdle(2000);
                Order.Require(CursorAtEnd(h,text.Length),"The cursor couldn't be put after "+label+"'s code. Stopped before the Delete key.");
                BeforeWrite();
                RoKey(h,0x2E,label);writes++;
                if(LineGone(expected,loose,label,5000)) { Say("Took out "+label+".");return; }
                Diag.EventRaw("ro_remove","the Delete key didn't take the line out; trying the right-click menu");
                if(MenuDelete(index,code,count,label)&&LineGone(expected,loose,label,5000)) { Say("Took out "+label+" (right-click menu).");return; }
                throw new InvalidOperationException("COSTAR didn't take "+label+" out (the Delete key and the right-click menu were tried). Take it out by hand.");
            });
        }
        static List<string> Filled(Grid g) { return g.Rows.Where(r=>r.Value.Length>0).Select(r=>Order.Norm(r.Value)).ToList(); }
        // The line is out: the filled lines are the expected ones, twice (COSTAR holding still), with no
        // more lines that lost only their code than before. A question COSTAR asks meanwhile is looked
        // at (RemoveQuestion). False when nothing changed by the end (COSTAR idle by then).
        bool LineGone(List<string> expected,int loose,string label,int ms) {
            var timer=Stopwatch.StartNew();bool idleChecked=false;
            while(true) {
                Check(false);
                var front=Native.GetForegroundWindow();
                if(front!=root&&front!=IntPtr.Zero&&Native.Pid(front)==pid&&Native.IsWindowVisible(front)) { RemoveQuestion(front,label);timer.Restart();continue; }
                if(front==root&&Native.IsWindowEnabled(root)) {
                    bool same=false;
                    try { same=Filled(Selectors.ProductGrid(GridCurrent())).SequenceEqual(expected); } catch(InvalidOperationException) { }
                    if(same) {
                        List<ControlInfo> s2;bool counted;var g2=SteadyGrid("after taking "+label+" out",false,out s2,out counted);
                        if(g2!=null&&Filled(g2).SequenceEqual(expected)) {
                            Order.Require(RoRead.Loose(s2,g2)<=loose,"COSTAR cleared "+label+"'s item code but left its words or price on the line. Nothing more was tried: check the line in COSTAR.");
                            return true;
                        }
                    }
                }
                if(timer.ElapsedMilliseconds>=ms) {
                    // A slow COSTAR may still be on it: once it has had time to finish, one last look.
                    if(idleChecked) return false;
                    idleChecked=true;WaitIdle(3000);Pause(300);continue;
                }
                Pause(50);
            }
        }
        // A window this Repair Order owns (its own questions).
        bool OwnedByRo(IntPtr window) {
            var owner=window;
            for(int i=0;i<16&&owner!=IntPtr.Zero;i++) { owner=Native.GetWindow(owner,4);if(owner==root) return true; }
            return false;
        }
        // Words in a question that mean more than this one line: never answered.
        internal static readonly Regex NotJustTheLine=new Regex(@"\b(SAV|PRINT|INVOIC|SELL|SOLD|PAY|CLOS|ALL\b|ALLOC|EVERY|ENTIRE|WHOLE|SPECIAL|BACK\s*ORDER|PURCHAS|STOCK|TRANSFER|QUOTE|CREDIT|REFUND|DEPOSIT|WARRANT|CANCEL|CUSTOMER|ACCOUNT)");
        internal static readonly Regex AboutTheLine=new Regex(@"\b(DELETE|REMOVE)\s+((THIS|THE|THAT|SELECTED|CURRENT)\s+){0,2}(LINE|ITEM|ROW|PRODUCT)S?\b|\b(LINE|ITEM|ROW)\b[^.?!]{0,20}\bBE\s+(DELETED|REMOVED)\b");
        // The whole question, in so many words, about this one line and nothing more: "Delete this line?",
        // "Are you sure you want to delete this item?", "Remove the selected row?", "Delete line 3?",
        // "This line will be deleted. Continue?" ... (one line, item, row or product; an optional code or
        // number; "from the Repair Order"). COSTAR's own wording isn't known yet: anything else stops
        // (its words are in the report) and the pattern is widened only to what COSTAR is seen to ask.
        internal static readonly Regex DeleteThisLine=new Regex(@"^(?:(?:ARE YOU SURE|DO YOU (?:REALLY )?WANT|OK|CONFIRM)(?: YOU WANT)?(?: TO)?,? )?(?:DELETE|REMOVE) (?:(?:THIS|THE|THAT|SELECTED|CURRENT) ){0,2}(?:LINE|ITEM|ROW|PRODUCT)(?: (?:NO\.? ?|#)?[A-Z0-9][A-Z0-9._/-]{0,19})?(?: FROM (?:THE|THIS) (?:REPAIR ORDER|ORDER|JOB CARD|JOB))? ?\??$|^(?:THIS|THE) (?:LINE|ITEM|ROW)(?: [A-Z0-9][A-Z0-9._/-]{0,19})? WILL BE (?:DELETED|REMOVED)\.? ?(?:(?:CONTINUE|PROCEED|OK) ?\??)?$");
        // Whether a COSTAR question while a line is taken out may be answered Yes: a box the Repair Order
        // owns, exactly the buttons Yes and No, and the whole question one of DeleteThisLine's (and none of
        // the words that mean more than this line). words: the question's words; buttons: its buttons' words.
        internal static bool YesToRemove(string words,List<string> buttons,bool owned) {
            string w=Regex.Replace(Order.Norm(words??""),@"\s+"," ").Trim();
            return owned&&buttons!=null&&buttons.Count==2&&buttons.Contains("YES")&&buttons.Contains("NO")&&DeleteThisLine.IsMatch(w)&&AboutTheLine.IsMatch(w)&&!NotJustTheLine.IsMatch(w);
        }
        // COSTAR asking to confirm taking this line out (YesToRemove): answered Yes, as asked. Anything
        // else stops, nothing answered.
        void RemoveQuestion(IntPtr front,string label) {
            var popup=Snapshot(front);
            string words=Regex.Replace(String.Join(" ",popup.Where(c=>c.Static&&c.TextState=="read").Select(c=>Order.Norm(c.Text)).ToArray()),@"\s+"," ").Trim();
            var buttons=popup.Where(c=>c.Visible&&c.TextState=="read"&&c.Class.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0).ToList();
            var names=buttons.Select(b=>Order.Norm(b.Text).Replace("&","")).ToList();
            var yes=buttons.Where(b=>b.Enabled&&Order.Norm(b.Text).Replace("&","")=="YES").ToList();
            bool owned=OwnedByRo(front),answer=YesToRemove(words,names,owned)&&yes.Count==1;
            Diag.EventRaw("ro_remove_question",Native.Class(front)+(owned?"":" (not the Repair Order's)")+" buttons: "+String.Join("/",names.ToArray())+(answer?" (about this line: Yes)":"")+" words: "+Sanitize.Text(words,120));
            if(!answer) { CaptureForegroundWindow("taking "+label+" out");throw new InvalidOperationException("COSTAR asked something while "+label+" was taken out. Nothing was answered: answer it at the PC."); }
            UIntPtr result;Native.WriteMessage(new IntPtr(yes[0].Handle),0xF5,UIntPtr.Zero,null,3,1000,out result);
            Say("COSTAR asked to confirm taking "+label+" out: answered Yes.");
            var timer=Stopwatch.StartNew();
            while(Native.IsWindow(front)&&Native.IsWindowVisible(front)&&timer.ElapsedMilliseconds<3000) Pause(50);
            Order.Require(!Native.IsWindow(front)||!Native.IsWindowVisible(front),"COSTAR's question about taking "+label+" out stayed open after Yes. Check it at the PC.");
        }
        sealed class MenuItem { internal string Name;internal bool Enabled;internal int L,T,W,H; }
        // The line's right-click menu: COSTAR's own line menu (not a text box's Undo / Cut / Copy / Paste
        // menu) with one enabled item named Delete, clicked where the menu shows it while it is still
        // open. False when there is no such menu or item (an open menu is closed with Escape, pressed
        // only while Windows says a menu has the keyboard). Any other window after the right click
        // stops: nothing is pressed in it.
        bool MenuDelete(int index,string code,int count,string label) {
            List<ControlInfo> s;Grid g;var row=FilledRow(index,code,count,out s,out g);
            var h=new IntPtr(row.Handle);Native.Rect r;Order.Require(Native.GetWindowRect(h,out r),"The "+label+" moved.");
            var point=new Native.Point {X=r.Left+Math.Min(20,Math.Max(4,(r.Right-r.Left)/3)),Y=r.Top+(r.Bottom-r.Top)/2};
            Order.Require(Native.WindowFromPoint(point)==h,"The "+label+" is covered.");
            var before=PopupsNow();
            Native.NoModifiers();Check(true);
            Order.Require(Native.WindowFromPoint(point)==h,"The "+label+" is covered.");
            Native.RightClickNow(point);Diag.Click();
            var fresh=new List<IntPtr>();var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<2000) {
                Thread.Sleep(50);fresh=PopupsNow().Where(w=>!before.Contains(w)).ToList();
                if(fresh.Count>0) { Thread.Sleep(150);fresh=PopupsNow().Where(w=>!before.Contains(w)).ToList();break; }
            }
            if(fresh.Count==0) { Diag.EventRaw("ro_remove","no menu after the right click");return false; }
            if(fresh.Count>1||!IsMenu(fresh[0])) {
                Diag.EventRaw("ro_remove","after the right click: "+String.Join(", ",fresh.Select(w=>Native.Class(w)).ToArray()));
                CaptureForegroundWindow("right click on "+label);
                throw new InvalidOperationException("COSTAR opened a window after the right click on "+label+". Nothing was pressed in it: close it at the PC.");
            }
            var menu=fresh[0];var items=new List<MenuItem>();
            Accessibility.IAccessible acc=null;
            try { acc=Msaa.FromWindow(menu);MenuItems(acc,2,items); }
            catch(Exception e) { Diag.EventRaw("ro_remove","the menu couldn't be read: "+e.GetType().Name); }
            finally { Msaa.Release(acc); }
            Diag.EventRaw("ro_remove_menu",String.Join(" | ",items.Take(20).Select(i=>i.Name+(i.Enabled?"":" (off)")).ToArray()));
            bool textMenu=items.Any(i=>i.Name=="CUT")&&items.Any(i=>i.Name=="COPY")&&items.Any(i=>i.Name=="PASTE");
            var delete=items.Where(i=>Regex.IsMatch(i.Name,@"\bDELETE\b")&&!Regex.IsMatch(i.Name,@"\bALL\b")).ToList();
            if(textMenu||delete.Count!=1||!delete[0].Enabled||delete[0].W<=4||delete[0].H<=4) {
                Diag.EventRaw("ro_remove",textMenu?"the right click showed the text box's own menu":"no single Delete item in the menu");
                CloseMenu(menu,label);return false;
            }
            var at=new Native.Point {X=delete[0].L+delete[0].W/2,Y=delete[0].T+delete[0].H/2};
            // The menu still open and its item where it was read, just before the click (which then goes at
            // once: no waiting for a held key after this look).
            Native.NoModifiers();Check(false);
            Order.Require(Native.IsWindow(menu)&&Native.IsWindowVisible(menu)&&Within(Native.WindowFromPoint(at),menu),"COSTAR's menu closed before Delete could be clicked. Nothing was clicked: take "+label+" out by hand.");
            BeforeWrite();Native.ClickNow(at);Diag.Click();writes++;
            return true;
        }
        static bool Within(IntPtr h,IntPtr ancestor) { for(int i=0;i<32&&h!=IntPtr.Zero;i++,h=Native.GetParent(h)) if(h==ancestor) return true;return false; }
        // A menu: Windows' own menu window, or a window whose accessibility says it is a menu.
        static bool IsMenu(IntPtr w) {
            if(Native.Class(w)=="#32768") return true;
            Accessibility.IAccessible a=null;
            try { a=Msaa.FromWindow(w);return Msaa.Role(a)==11; } catch(Exception) { return false; }
            finally { Msaa.Release(a); }
        }
        // Escape to an open menu, only while Windows says a menu has COSTAR's keyboard (a menu loop):
        // otherwise the key could reach the Repair Order. Left open then, and said.
        void CloseMenu(IntPtr menu,string label) {
            if(!Native.IsWindow(menu)||!Native.IsWindowVisible(menu)) return;
            Order.Require(Native.InMenuMode(root),"COSTAR's right-click menu on "+label+" is open and nothing was clicked in it. Close it at the PC (Escape).");
            Native.KeyNow(27);Diag.Key();
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<1500&&Native.IsWindow(menu)&&Native.IsWindowVisible(menu)) Thread.Sleep(50);
            Order.Require(!Native.IsWindow(menu)||!Native.IsWindowVisible(menu),"COSTAR's right-click menu on "+label+" stayed open. Close it at the PC.");
        }
        // Menu items (role 12) with their words, whether they can be clicked, and their places.
        static void MenuItems(Accessibility.IAccessible parent,int depth,List<MenuItem> items) {
            foreach(object child in Msaa.Children(parent,60)) {
                try {
                    int role=Msaa.RoleOf(parent,child);
                    if(role==12) {
                        var item=new MenuItem {Name=Order.Norm(Msaa.NameOf(parent,child)).Replace("&","")};
                        int state=Msaa.StateOf(parent,child);item.Enabled=state>=0&&(state&0x1)==0;
                        int l,t,w,h;if(Msaa.LocationOf(parent,child,out l,out t,out w,out h)) { item.L=l;item.T=t;item.W=w;item.H=h; }
                        items.Add(item);
                    } else if(depth>0) { var a=child as Accessibility.IAccessible;if(a!=null) MenuItems(a,depth-1,items); }
                } finally { if(child is Accessibility.IAccessible) Msaa.Release(child); }
            }
        }
        // COSTAR's visible windows other than the Repair Order (a menu or a question shows as one); a menu's
        // shadow and tooltips are not windows of their own here.
        List<IntPtr> PopupsNow() {
            var list=new List<IntPtr>();
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) { if(Native.Pid(w)==pid&&Native.IsWindowVisible(w)&&w!=root&&!Decoration(w)) list.Add(w);return true; },IntPtr.Zero);
            return list;
        }
        internal static bool Decoration(IntPtr w) {
            string c=Native.Class(w);
            return c=="SysShadow"||c.IndexOf("tooltips_class",StringComparison.OrdinalIgnoreCase)>=0;
        }
        // A new item: on the next free line above DET when there is one (the helper's way), else after
        // everything; then its quantity and price when given (COSTAR's own price stays otherwise).
        void RoAddItem(RoNewLine a,bool det) {
            string code=Order.Norm(a.code);
            RoStep(code+" added",code+" typed on a new line (its quantity and price not checked)",delegate {
                int above=0;
                if(det) { try { if(Selectors.ProductGrid(GridCurrent()).Rows.Count(r=>Order.Norm(r.Value)=="DET")==1) above=-1; } catch(InvalidOperationException) { } }
                long handle=AddCode(code,false,true,false,0,above);
                string label="new "+code;
                if(a.qty!=null) {
                    var s=GridCurrent();var g=Selectors.ProductGrid(s);var cell=Selectors.Cell(s,Row(s,handle,code),g.Quantity);
                    if(RoRead.Num(ReadLive(cell))!=RoRead.Num(a.qty)) { Put(cell,RoRead.Num(a.qty),"quantity of "+label,true);Ready(); }
                }
                if(a.price!=null) {
                    var s=GridCurrent();var g=Selectors.ProductGrid(s);var cell=Selectors.Cell(s,Row(s,handle,code),code=="F"?g.ListPrice:g.Net);
                    if(RoRead.Cents(ReadLive(cell))!=RoRead.Cents(a.price)) { Put(cell,PriceText(a.price),"price of "+label,true);Ready(); }
                }
                var s2=GridCurrent();var g2=Selectors.ProductGrid(s2);var r2=Row(s2,handle,code);
                if(a.qty!=null) Order.Require(RoRead.Num(Selectors.Cell(s2,r2,g2.Quantity).Value)==RoRead.Num(a.qty),"The quantity of "+label+" didn't stay "+RoRead.Num(a.qty)+".");
                if(a.price!=null) Order.Require(RoRead.Cents(Selectors.Cell(s2,r2,code=="F"?g2.ListPrice:g2.Net).Value)==RoRead.Cents(a.price),"The price of "+label+" didn't stay $"+PriceText(a.price)+".");
                Say("Added "+code+".");
            });
        }
        // A new note: an M line after everything, with the phone's words.
        void RoAddNote(string text) {
            RoStep("note added","a note line typed (its words not checked)",delegate {
                long handle=AddCode("M",true);
                string expected=Order.EntryText(Order.Clean(text));
                Func<MemoTarget> locate=delegate { var s=GridCurrent();var g=Selectors.ProductGrid(s);var r=Row(s,handle,"M");return new MemoTarget {Row=r,Editor=Selectors.Cell(s,r,g.Description)}; };
                var target=FocusMemo(locate,"new note");WriteNote(target.Editor,expected,"new note");Ready();
                NoteBack(locate,expected,"new note");
            });
        }
        // The car is DET's three notes; a Repair Order without DET gets DET (after everything) first.
        void RoCar(RoEdit edit,bool det) {
            if(!det) RoStep("DET added","DET typed (its notes not checked)",delegate { AddCode("DET",false,false,true);WaitForDetailsTemplate(); });
            if(edit.makeModel!=null) RoStep("make/model","make/model typed (not checked)",delegate { Memo("MAKE/MODEL",Order.Clean(edit.makeModel),"M",false); });
            if(edit.rego!=null) RoStep("rego","rego typed (not checked)",delegate { Memo("REGO NO",Order.Clean(edit.rego),"M",false); });
            if(edit.odometer!=null) RoStep("odometer","odometer typed (not checked)",delegate { Memo("ODOMETER",Order.Clean(edit.odometer),"M ODO",false); });
        }
        void RoHeader(RoEdit edit) {
            string account=Order.Clean(ReadLive(HeaderNow().Account));
            foreach(var key in RoEdit.HeaderKeys) {
                string value;if(key=="phone"||!edit.header.TryGetValue(key,out value)) continue;
                string label=RoEdit.Label(key),k=key,v=value;
                Timed("Customer: "+label,delegate {
                    RoStep(label,label+" typed (not checked)",delegate {
                        var box=HeaderBox(HeaderNow(),k);
                        PutMapped(box,v,label,true,k=="email");
                        Order.Require(Order.Clean(ReadLive(HeaderNow().Account))==account,"COSTAR changed the customer account while the "+label+" was typed. Stopped; check the Repair Order.");
                        if(k=="po") order.orderId=Order.Clean(RoEdit.Entry("po",v));
                    });
                });
            }
            string phone;if(edit.header.TryGetValue("phone",out phone)) Timed("Customer: mobile phone",delegate { RoStep("mobile phone","mobile phone typed (COSTAR may have looked the customer up: check the customer)",delegate { RoPhone(phone); }); });
        }
        // The phone (only on a Repair Order without a customer account): after Tab COSTAR may look the
        // customer up. COSTAR's "Customer Not found" notice for a new phone is dismissed (as on every
        // phone job); a list of customers, any other window or an account loaded stops (the phone is the
        // last header box).
        void RoPhone(string value) {
            var h=HeaderNow();
            Order.Require(Order.Clean(ReadLive(h.Account)).Length==0,"This Repair Order is on a customer account: change the phone in COSTAR.");
            if(Order.Phone(ReadLive(h.Phone))==Order.Phone(value)) return;
            Put(h.Phone,value,"mobile phone",true);
            var timer=Stopwatch.StartNew();int stable=0;
            while(timer.ElapsedMilliseconds<SearchPatienceMs) {
                Check(false);var front=Native.GetForegroundWindow();
                if(front!=root&&front!=IntPtr.Zero) {
                    var popup=IsCustomerPopup(front)?PopupSnapshot(front):null;
                    if(popup!=null&&Native.Pid(front)==pid&&CustomerPopup(front,popup)) { stable=0;continue; }
                    if(timer.ElapsedMilliseconds<1500) { Pause(100);continue; }
                    CaptureForegroundWindow("phone change");
                    throw new InvalidOperationException("COSTAR opened a window after the mobile phone was changed (more than one customer with that phone?). Nothing was answered: finish it at the PC.");
                }
                var s=Snapshot(root);
                if(lastSnapshotBusy||Selectors.CustomerSearchInProgress(s)) { stable=0;Pause(150);continue; }
                var m=Selectors.Header(s);
                Order.Require(m.Account.Value.Length==0,"COSTAR matched the new phone to customer account "+m.Account.Value+". Check the Repair Order at the PC.");
                if(++stable>=3) break;
                Pause(150);
            }
            Order.Require(stable>=3,"COSTAR was still busy after the phone was changed. Check the Repair Order at the PC.");
        }
        void RoShipVia(string value) {
            var box=Selectors.ShipVia(Current());
            Order.Require(box!=null,"The Ship Via box isn't showing.");
            PutMapped(box,value,"Ship Via",true);
        }
        // Date In typed the way the box shows dates (07/10/2026 or 7/10/2026 ...), read back as a date.
        void RoDateIn(string iso) {
            string kind;var box=RoSelectors.DateIn(Current(),out kind);
            Order.Require(box!=null&&(kind=="edit"||kind=="combo"),"Date In can't be typed into on this Repair Order.");
            var want=DateTime.ParseExact(iso,"yyyy-MM-dd",CultureInfo.InvariantCulture);
            string now=ReadLive(box);DateTime have;string format;
            if(RoRead.ParseDate(now,out have,out format)&&have.Date==want.Date) { Say("Date In is already "+now+".");return; }
            string text=RoRead.DateText(now,want);
            Put(box,text,"Date In",true);Ready();
            string after=ReadLive(box);
            Order.Require(RoRead.DateKey(after)==iso,"Date In didn't keep "+text+" (COSTAR shows "+after+").");
        }
        // Why a Repair Order can't be closed safely now, or null: it is disabled (COSTAR asking something
        // on it) or a COSTAR window it owns is showing (a question, a list, a menu). WM_CLOSE then would
        // take that window with it, as if it had been answered.
        internal static string CloseBlocker(IntPtr window) {
            if(!Native.IsWindow(window)) return null;
            if(!Native.IsWindowEnabled(window)) return "COSTAR is asking something on it";
            uint owner=Native.Pid(window);bool open=false;
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) {
                if(w==window||Native.Pid(w)!=owner||!Native.IsWindowVisible(w)||Decoration(w)) return true;
                var o=Native.GetWindow(w,4);
                for(int i=0;i<16&&o!=IntPtr.Zero;i++,o=Native.GetWindow(o,4)) if(o==window) { open=true;return false; }
                return true;
            },IntPtr.Zero);
            return open?"a COSTAR window is open on it":null;
        }
        // The Repair Order's own close (WM_CLOSE): nothing saved, sold or printed; COSTAR keeps it in
        // Work-in-Progress. Only while nothing of COSTAR's is open on it (CloseBlocker). False when it
        // isn't closed (blocked, or still open after 8 s: COSTAR asking something, never answered).
        internal bool CloseRo() {
            if(!Native.IsWindow(root)) return true;
            string why=CloseBlocker(root);
            if(why!=null) { Diag.EventRaw("ro_close_blocked",why);Say("Repair Order "+roDoc+" not closed: "+why+".");return false; }
            UIntPtr result;Native.WriteMessage(root,0x10,UIntPtr.Zero,null,3,1000,out result);
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<8000) { if(!Native.IsWindow(root)) { Diag.EventRaw("ro_closed",timer.ElapsedMilliseconds+" ms");return true; }Thread.Sleep(100); }
            Diag.EventRaw("ro_close_open","still open after 8 s");
            return false;
        }
    }
}
