// Self-tests for Repair Orders from the phone (2.6.0): reading a Repair Order from its controls, the
// rules for a change, the check of the result, the desk's queue and its routes. Never opens, clicks
// or types into COSTAR. Made-up customers and cars.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace TempeCostar {
    internal static class RoTests {
        static void Check(bool value,string message){if(!value)throw new InvalidOperationException(message);}
        static void Reject(Action action,string message,string contains=null) {
            string error=null;try{action();}catch(InvalidOperationException e){error=e.Message;}
            Check(error!=null,message);
            if(contains!=null) Check(error.Contains(contains),message+" (said: "+error+")");
        }
        const string ST="WindowsForms10.STATIC.app.0.1",ED="WindowsForms10.EDIT.app.0.1",WN="WindowsForms10.Window.8.app.0.1",CB="WindowsForms10.COMBOBOX.app.0.1",DT="WindowsForms10.SysDateTimePick32.app.0.1";
        static ControlInfo Mk(long h,long parent,string cls,int x,int y,int w,int hh,string text) {
            return new ControlInfo {Handle=h,Parent=parent,Class=cls,Visible=true,Enabled=true,Bounds=new[]{x,y,w,hh},RelativeBounds=new[]{x,y,w,hh},Text=text,TextState="read"};
        }
        // A made-up Repair Order: the customer panel, Time In / Date In / Written By, Ship to, the 25
        // lines (lines[n] = code, description, quantity, net) and the total.
        sealed class Fixture {
            internal string Account="",Name="TEST CUSTOMER",Phone="0400000001",Email="test.customer@example.com",Address="1 TEST STREET",Address2="",Suburb="TESTVILLE",State="NSW",Postcode="2999",Po="",Comment="WAITING FOR TYRES";
            internal string ShipVia="",TimeIn="8:30 am",DateIn="27/10/2026",DateKind="edit",WrittenBy="TV",Total="$650.00";
            internal Dictionary<int,string[]> Lines=Standard();
            internal int NameStyle;
        }
        static Dictionary<int,string[]> Standard() {
            return new Dictionary<int,string[]> {
                {1,new[]{"W43116","WINRUN 265/70R16 112T MAXCLAW A/T","4","140.00"}},
                {2,new[]{"WA","WHEEL ALIGNMENT FRONT","1","89.00"}},
                // M codes are COSTAR's note lines (M FB: its fitting and balancing words).
                {3,new[]{"M FB","FITTING & BALANCING","",""}},
                {6,new[]{"DET","DETAILS","",""}},
                {7,new[]{"M","MAKE/MODEL: TOYOTA HILUX","",""}},
                {8,new[]{"M","REGO NO: ABC123","",""}},
                {9,new[]{"M ODO","ODOMETER: 40631","",""}},
                {10,new[]{"M","CALL BEFORE FITTING","",""}}
            };
        }
        static List<ControlInfo> Ro(Fixture f) {
            var s=new List<ControlInfo>();
            s.Add(Mk(1,100,ST,20,60,150,18,"ACCOUNT# / NAME"));
            s.Add(Mk(2,100,ED,20,79,60,20,f.Account));var name=Mk(3,100,ED,85,79,250,20,f.Name);name.Style=f.NameStyle;s.Add(name);
            s.Add(Mk(4,100,ED,20,100,315,20,f.Address));s.Add(Mk(5,100,ED,20,121,315,20,f.Address2));
            s.Add(Mk(6,100,ED,20,142,200,20,f.Suburb));s.Add(Mk(7,100,ED,225,142,40,20,f.State));s.Add(Mk(8,100,ED,270,142,65,20,f.Postcode));
            s.Add(Mk(9,100,ST,20,170,80,18,"MOBILE PH"));s.Add(Mk(10,100,ED,20,189,120,20,f.Phone));
            s.Add(Mk(11,100,ST,150,170,60,18,"EMAIL"));s.Add(Mk(12,100,ED,150,189,185,20,f.Email));
            s.Add(Mk(13,100,ST,350,170,40,18,"PO#"));s.Add(Mk(14,100,ED,350,189,100,20,f.Po));
            s.Add(Mk(15,100,ST,20,220,70,18,"COMMENT"));s.Add(Mk(16,100,ED,95,220,300,20,f.Comment));
            s.Add(Mk(30,150,ST,460,60,60,18,"TIME IN"));s.Add(Mk(31,150,CB,460,79,90,22,""));s.Add(Mk(32,31,ED,463,81,70,18,f.TimeIn));
            s.Add(Mk(33,150,ST,560,60,60,18,"DATE IN"));
            if(f.DateKind=="edit") s.Add(Mk(34,150,ED,560,79,90,20,f.DateIn));
            else if(f.DateKind=="combo") { s.Add(Mk(34,150,CB,560,79,90,22,""));s.Add(Mk(35,34,ED,563,81,70,18,f.DateIn)); }
            else if(f.DateKind=="picker") s.Add(Mk(34,150,DT,560,79,90,20,f.DateIn));
            s.Add(Mk(36,150,ST,660,60,80,18,"WRITTEN BY"));s.Add(Mk(37,150,ED,660,79,60,20,f.WrittenBy));
            s.Add(Mk(40,200,ST,500,170,70,18,"SHIP VIA"));s.Add(Mk(41,200,ED,500,189,100,20,f.ShipVia));
            s.Add(Mk(20,300,ST,69,341,79,27,"ITEM"));s.Add(Mk(21,300,ST,223,341,87,27,"DESCRIPTION"));s.Add(Mk(22,300,ST,728,341,45,27,"QTY OR HRS"));s.Add(Mk(23,300,ST,769,341,56,26,"LIST"));s.Add(Mk(24,300,ST,873,341,56,27,"NET"));
            for(int i=0;i<25;i++) {
                int y=369+19*i;long panel=500+i,b=1000+10*i;string[] v;if(!f.Lines.TryGetValue(i+1,out v))v=new[]{"","","",""};
                s.Add(Mk(panel,300,WN,37,y,1010,20,""));
                s.Add(Mk(b,panel,ED,72,y,155,20,v[0]));s.Add(Mk(b+1,panel,ED,225,y,480,20,v[1]));
                // A note line has no quantity or price boxes.
                if(RoRead.Kind(v[0])=="item"&&v[0].Length>0) { s.Add(Mk(b+2,panel,ED,728,y,40,20,v[2]));s.Add(Mk(b+3,panel,ED,769,y,56,20,v[3]));s.Add(Mk(b+4,panel,ED,873,y,56,20,v[3])); }
            }
            s.Add(Mk(50,400,ST,900,860,60,18,"TAX IN"));s.Add(Mk(51,400,ST,900,878,80,18,f.Total));
            return s;
        }
        static RoSnapshot Read(Fixture f,string waiting="no") { return RoRead.Build(Ro(f),"07497644",waiting,"",null); }
        static RoEdit Edit(RoSnapshot snap) { return new RoEdit {schema=RoEdit.Schema,doc=snap.doc,baseSig=snap.sig}; }
        static RoAsk Ask(string kind,string doc=null,RoEdit edit=null) { return new RoAsk {id="RO-"+Guid.NewGuid().ToString(),kind=kind,doc=doc,edit=edit}; }
        static RoHello Hello(RoReport report=null,bool accepting=true,bool available=true,string working=null,int sequence=1000) {
            return new RoHello {workerId="test-worker",accepting=accepting,available=available,report=report,working=working,sequence=sequence};
        }
        static RoReport Report(RoReply r,string status,int sequence,RoSnapshot snapshot=null,RoList list=null) {
            return new RoReport {id=r.task.id,lease=r.task.lease,status=status,message=status,progress="",sequence=sequence,snapshot=snapshot,list=list};
        }
        static HttpInput Request(string method,string path,string token,string origin=null,object body=null) {
            var r=new HttpInput {method=method,path=path,body=body==null?"":Wire.Json(body),headers=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase)};
            if(token!=null)r.headers["authorization"]="Bearer "+token;
            if(origin!=null)r.headers["origin"]=origin;
            if(body!=null)r.headers["content-type"]="application/json";
            return r;
        }
        static T Body<T>(HttpOutput o){return Wire.Read<T>(Encoding.UTF8.GetString(o.bytes));}
        internal static void Cases(Action<string,Action> Case) {
            Case("Repair Orders: a Repair Order is read from its boxes and lines (DET and the car, what can't be changed, the fingerprint)",()=>{
                var f=new Fixture();var snap=Read(f);
                Check(snap.name=="TEST CUSTOMER"&&snap.phone=="0400000001"&&snap.suburb=="TESTVILLE"&&snap.comment=="WAITING FOR TYRES"&&snap.dateIn=="27/10/2026"&&snap.timeIn=="8:30 am"&&snap.writtenBy=="TV","Header boxes were not read.");
                Check(snap.counted&&snap.lines.Count==8&&String.Join(",",snap.lines.Select(l=>l.n.ToString(CultureInfo.InvariantCulture)).ToArray())=="1,2,3,6,7,8,9,10","Lines and their numbers were not read.");
                Check(String.Join(",",snap.lines.Select(l=>l.kind).ToArray())=="item,item,note,det,car,car,car,note","Line kinds: "+String.Join(",",snap.lines.Select(l=>l.kind).ToArray()));
                Check(snap.det&&snap.makeModel=="TOYOTA HILUX"&&snap.rego=="ABC123"&&snap.odometer=="40631","The car was not read from DET's notes.");
                Check(snap.lines[0].qty=="4"&&snap.lines[0].net=="140.00"&&snap.totalCents==65000,"Quantity, price or total.");
                Check(snap.customerWaiting=="no"&&!snap.cannot.ContainsKey("phone")&&!snap.cannot.ContainsKey("dateIn")&&!snap.cannot.ContainsKey("add")&&!snap.cannot.ContainsKey("shipVia"),"A cash Repair Order must be fully changeable: "+String.Join("; ",snap.cannot.Select(p=>p.Key+"="+p.Value).ToArray()));
                Check(RoEdit.IsSig(snap.sig)&&Read(new Fixture()).sig==snap.sig,"The fingerprint must be 16 hex digits and the same for the same Repair Order.");
                var g=new Fixture();g.TimeIn="9:00 am";g.WrittenBy="SA";Check(Read(g).sig==snap.sig,"Time In and Written By are not part of the fingerprint.");
                g=new Fixture();g.Lines[1]=new[]{"W43116","WINRUN 265/70R16 112T MAXCLAW A/T","2","140.00"};Check(Read(g).sig!=snap.sig,"A new quantity must change the fingerprint.");
                g=new Fixture();g.Comment="DONE";Check(Read(g).sig!=snap.sig,"A new comment must change the fingerprint.");
                Check(Read(new Fixture(),"yes").sig!=snap.sig,"Customer Waiting is part of the fingerprint.");
                g=new Fixture();g.Account="C10023";Check(Read(g).cannot["phone"].Contains("C10023"),"A Repair Order on an account must not take a phone change.");
                g=new Fixture();g.NameStyle=0x800;Check(Read(g).cannot["name"].Contains("locked"),"A read-only box must be marked.");
                g=new Fixture();g.DateKind="picker";Check(Read(g).cannot["dateIn"].Contains("calendar"),"A calendar box can't be typed into.");
                g=new Fixture();g.DateKind="combo";g.DateIn="07/10/2026";var combo=Read(g);Check(combo.dateIn=="07/10/2026"&&!combo.cannot.ContainsKey("dateIn"),"A drop-down date box must be read.");
                g=new Fixture();g.DateKind="none";Check(Read(g).cannot.ContainsKey("dateIn"),"No date box must be marked.");
                Check(Read(new Fixture(),"").cannot.ContainsKey("customerWaiting"),"An unreadable Customer Waiting must be marked.");
                g=new Fixture();g.Lines.Remove(6);g.Lines.Remove(7);g.Lines.Remove(8);g.Lines.Remove(9);
                var nodet=Read(g);Check(!nodet.det&&nodet.makeModel==""&&nodet.lines.All(l=>l.kind!="car"),"Without DET there is no car.");
                g=new Fixture();g.Lines[12]=new[]{"DET","DETAILS","",""};Check(Read(g).cannot.ContainsKey("car"),"Two DETs: the car can't be changed.");
            });
            Case("Repair Orders: Date In is read in the box's own format and written back the same way",()=>{
                DateTime d;string f;
                Check(RoRead.ParseDate("07/10/2026",out d,out f)&&f=="dd/MM/yyyy"&&d==new DateTime(2026,10,7),"dd/MM/yyyy");
                Check(RoRead.ParseDate("7/10/2026",out d,out f)&&f=="d/MM/yyyy","d/MM/yyyy");
                Check(RoRead.ParseDate("27 Oct 2026",out d,out f)&&d==new DateTime(2026,10,27),"27 Oct 2026");
                Check(RoRead.ParseDate("27/10/2026 10:21 AM",out d,out f)&&d==new DateTime(2026,10,27),"A time after the date is ignored.");
                Check(!RoRead.ParseDate("next week",out d,out f)&&!RoRead.ParseDate("",out d,out f),"Words are not a date.");
                Check(RoRead.DateText("07/10/2026",new DateTime(2026,11,3))=="03/11/2026"&&RoRead.DateText("7/10/2026",new DateTime(2026,11,3))=="3/11/2026","The new date must follow the box's format.");
                Check(RoRead.DateText("",new DateTime(2026,11,3))=="03/11/2026","An empty box gets dd/MM/yyyy.");
                Check(RoRead.DateText("27/10/2026 10:21 AM",new DateTime(2026,11,3))=="03/11/2026 10:21 AM","A time after the date is kept.");
                Check(RoRead.DateKey("7/10/2026")=="2026-10-07"&&RoRead.DateKey("07/10/2026")=="2026-10-07","The date key.");
            });
            Case("Repair Orders: the phone's change is checked before anything is typed",()=>{
                var snap=Read(new Fixture());
                var e=Edit(snap);e.header=new Dictionary<string,string>{{"comment","fitted, call customer"},{"email","New.Address@Example.com"}};
                e.shipVia="SHOP";e.dateIn=DateTime.Today.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture);e.customerWaiting="yes";e.rego="XYZ789";
                e.lines=new List<RoLineEdit>{new RoLineEdit{index=0,code="W43116",qty="2",price="135.50"},new RoLineEdit{index=7,code="M",text="call when done"},new RoLineEdit{index=1,code="WA",remove=true}};
                e.add=new List<RoNewLine>{new RoNewLine{kind="item",code="VALVE",qty="4",price="5"},new RoNewLine{kind="note",code="M",text="key in the box"}};
                e.ValidateShape();e.Validate(snap);
                Check(e.Summary().Contains("comment")&&e.Summary().Contains("2 line(s) added")&&!e.Summary().Contains("fitted"),"The summary names what changes, never the words.");
                Func<RoEdit> copy=()=>Wire.Copy(e);
                Action<Action<RoEdit>,string,string> bad=(change,message,contains)=>{var x=copy();change(x);Reject(()=>{x.ValidateShape();x.Validate(snap);},message,contains);};
                bad(x=>x.schema="tempe.ro-edit.v0","An old page's change must be refused.","older");
                bad(x=>x.doc="07 497","A bad Repair Order number.","number");
                bad(x=>x.baseSig="abc","A change without the fingerprint.",null);
                bad(x=>{x.header=null;x.shipVia=null;x.dateIn=null;x.customerWaiting=null;x.rego=null;x.lines=null;x.add=null;},"Nothing to change.","Nothing");
                bad(x=>x.header["account"]="C1","The account is not changed from the phone.","doesn't change");
                bad(x=>x.header["phone"]="12345","A short phone.","8 to 15");
                bad(x=>x.header["state"]="XX","A state.","state");
                bad(x=>x.header["postcode"]="123","A postcode.","4 digits");
                bad(x=>x.header["email"]="not-an-email","An email.","email");
                bad(x=>x.header["name"]="  ","An empty name.","name");
                bad(x=>x.header["comment"]="line\u0007bell","Control characters.",null);
                bad(x=>x.lines[0].qty="0","Quantity 0.","Quantities");
                bad(x=>x.lines[0].qty="1.234","Three decimals.","Quantities");
                bad(x=>x.lines[0].price="-1","A negative price.","Prices");
                bad(x=>x.lines[0].price="12.345","Three decimals in a price.","Prices");
                bad(x=>x.lines[2].qty="1","A line taken out and changed.","taken out");
                bad(x=>x.add[0].code="DET","DET is added through the car.","not DET");
                bad(x=>x.add[0].code="M","A bare M is a note.","not DET or M");
                bad(x=>x.add[1].text=" ","A note without words.","no words");
                bad(x=>{for(int i=0;i<RoEdit.MaxAdds;i++)x.add.Add(new RoNewLine{kind="note",code="M",text="x"});},"Too many new lines.","at most");
                bad(x=>x.dateIn="2030-01-01","A date years away.","within a year");
                bad(x=>x.dateIn="27/10/2026","A date in the wrong form.","Date In");
                bad(x=>x.customerWaiting="maybe","Customer Waiting yes/no.","yes or no");
                bad(x=>x.rego="ABC!23","A rego with symbols.","rego");
                bad(x=>x.odometer="40k","An odometer with letters.","digits");
                bad(x=>x.shipVia="SHOP\u0001","Ship Via with a control character.","Ship Via");
                // Against the Repair Order as it is now.
                bad(x=>x.baseSig="0123456789ABCDEF","A Repair Order that changed after the phone read it.","CHANGED:");
                bad(x=>x.lines[0].code="W99999","A line that moved.","not W99999");
                bad(x=>x.lines.Add(new RoLineEdit{index=3,code="DET",remove=true}),"DET can't be taken out.","car section");
                bad(x=>x.lines.Add(new RoLineEdit{index=4,code="M",remove=true}),"A car note can't be taken out.","car section");
                bad(x=>x.lines.Add(new RoLineEdit{index=4,code="M",text="MAKE/MODEL: X"}),"A car note is changed in the car section.","car section");
                bad(x=>{x.lines[1]=new RoLineEdit{index=7,code="M",qty="2"};},"A note has no quantity.","Only item lines");
                bad(x=>{x.lines[1]=new RoLineEdit{index=0,code="W43116",text="hello"};x.lines.RemoveAt(0);},"An item has no words to change.","Only note lines");
                var onAccount=new Fixture();onAccount.Account="C10023";var acc=Read(onAccount);
                var p=Edit(acc);p.header=new Dictionary<string,string>{{"phone","0400 111 222"}};Reject(()=>p.Validate(acc),"A phone change on an account Repair Order.","account");
                var full=new Fixture();for(int i=11;i<=25;i++) full.Lines[i]=new[]{"M","NOTE "+i,"",""};for(int i=4;i<=5;i++) full.Lines[i]=new[]{"M","NOTE "+i,"",""};
                var fullSnap=Read(full);Check(fullSnap.lines.Count==25,"The full fixture has 25 lines.");
                var more=Edit(fullSnap);more.add=new List<RoNewLine>{new RoNewLine{kind="note",code="M",text="one more"}};Reject(()=>more.Validate(fullSnap),"A 26th line.","25 lines");
                more.lines=new List<RoLineEdit>{new RoLineEdit{index=24,code="M",remove=true}};more.Validate(fullSnap);
                var limited=Read(new Fixture());limited.limits["name"]=10;var lim=Edit(limited);lim.header=new Dictionary<string,string>{{"name","A VERY LONG CUSTOMER NAME"}};
                Reject(()=>lim.Validate(limited),"COSTAR's letter limit.","10 letters");
                var noDate=new Fixture();noDate.DateKind="picker";var nd=Read(noDate);var de=Edit(nd);de.dateIn=DateTime.Today.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture);
                Reject(()=>de.Validate(nd),"Date In in a calendar box.","calendar");
                var nocar=new Fixture();nocar.Lines.Remove(6);nocar.Lines.Remove(7);nocar.Lines.Remove(8);nocar.Lines.Remove(9);var nc=Read(nocar);
                var car=Edit(nc);car.makeModel="Ford Ranger";car.Validate(nc);
            });
            Case("Repair Orders: the result must be what was asked (old lines in order, new ones anywhere, nothing else moved)",()=>{
                var before=Read(new Fixture());
                var e=Edit(before);e.header=new Dictionary<string,string>{{"comment","fitted"}};e.shipVia="SHOP";e.customerWaiting="yes";e.rego="XYZ789";
                e.lines=new List<RoLineEdit>{new RoLineEdit{index=0,code="W43116",qty="2"},new RoLineEdit{index=1,code="WA",price="95"},new RoLineEdit{index=7,code="M",text="call when done"}};
                e.add=new List<RoNewLine>{new RoNewLine{kind="item",code="VALVE",qty="4",price="5"},new RoNewLine{kind="note",code="M",text="key in the box"}};
                Func<Fixture> applied=()=>{
                    var f=new Fixture();f.Comment="FITTED";f.ShipVia="SHOP";f.Total="$999.00";
                    f.Lines[1]=new[]{"W43116","WINRUN 265/70R16 112T MAXCLAW A/T","2","140.00"};
                    f.Lines[2]=new[]{"WA","WHEEL ALIGNMENT FRONT","1","95.00"};
                    f.Lines[4]=new[]{"VALVE","TYRE VALVE","4","5.00"};
                    f.Lines[8]=new[]{"M","REGO NO: XYZ789","",""};
                    f.Lines[10]=new[]{"M","CALL WHEN DONE","",""};
                    f.Lines[11]=new[]{"M","KEY IN THE BOX","",""};
                    return f;
                };
                var notes=new List<string>();
                var ok=RoExpect.Check(before,e,Read(applied(),"yes"),notes);
                Check(ok.Count==0&&notes.Count==0,"The applied change must pass: "+String.Join(" | ",ok.ToArray()));
                var f2=applied();f2.Lines[1]=new[]{"W43116","WINRUN 265/70R16 112T MAXCLAW A/T","4","140.00"};
                Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Any(p=>p.Contains("lines are not as asked")),"A quantity that didn't stay must be found.");
                f2=applied();f2.Lines[12]=new[]{"F","FREIGHT","1","10.00"};
                Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Any(p=>p.Contains("lines")),"A line nobody asked for must be found.");
                f2=applied();f2.Lines.Remove(4);f2.Lines[12]=new[]{"VALVE","TYRE VALVE","4","5.00"};
                Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Count==0,"A new item may go anywhere.");
                f2=applied();f2.Name="SOMEONE ELSE";Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Any(p=>p.Contains("name")),"The customer must not change by itself.");
                f2=applied();f2.Account="C99";Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Any(p=>p.Contains("account")),"The account must not change by itself.");
                f2=applied();f2.Postcode="2044";notes.Clear();
                Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Count==0&&notes.Any(n=>n.Contains("postcode")),"A box COSTAR changed by itself is said, not a stop.");
                Check(RoExpect.Check(before,e,Read(applied(),"no"),notes).Any(p=>p.Contains("Customer Waiting")),"Customer Waiting must be as asked.");
                f2=applied();f2.ShipVia="POST";Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Any(p=>p.Contains("Ship Via")),"Ship Via must be as asked.");
                f2=applied();f2.Lines[8]=new[]{"M","REGO NO: ABC123","",""};Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Count>0,"The rego must be as asked.");
                // Taking a line out: the lines under it move up.
                var r=Edit(before);r.lines=new List<RoLineEdit>{new RoLineEdit{index=1,code="WA",remove=true}};
                var gone=new Fixture();gone.Lines.Remove(2);
                Check(RoExpect.Check(before,r,Read(gone),notes).Count==0,"A line taken out (lines left in place).");
                var shifted=new Fixture();shifted.Lines=new Dictionary<int,string[]>();foreach(var pair in Standard()) if(pair.Key!=2) shifted.Lines[pair.Key>2?pair.Key-1:pair.Key]=pair.Value;
                Check(RoExpect.Check(before,r,Read(shifted),notes).Count==0,"A line taken out (lines moved up).");
                Check(RoExpect.Check(before,r,Read(new Fixture()),notes).Count>0,"A line that is still there must be found.");
                // A car on a Repair Order without DET: DET and its three notes come in as new lines.
                var bare=new Fixture();bare.Lines=new Dictionary<int,string[]>{{1,new[]{"W43116","WINRUN","4","140.00"}}};var b=Read(bare);
                var c=Edit(b);c.makeModel="Ford Ranger";c.rego="DEF456";
                var withCar=new Fixture();withCar.Lines=new Dictionary<int,string[]>{{1,new[]{"W43116","WINRUN","4","140.00"}},{3,new[]{"DET","DETAILS","",""}},{4,new[]{"M","MAKE/MODEL: FORD RANGER","",""}},{5,new[]{"M","REGO NO: DEF456","",""}},{6,new[]{"M ODO","ODOMETER:","",""}}};
                Check(RoExpect.Check(b,c,Read(withCar),notes).Count==0,"DET and its notes for a new car.");
                // The same item twice: the new one may be above the old one, with another quantity.
                var twice=Edit(before);twice.add=new List<RoNewLine>{new RoNewLine{kind="item",code="W43116",qty="1"}};
                var t=new Fixture();t.Lines[1]=new[]{"W43116","WINRUN 265/70R16 112T MAXCLAW A/T","1","140.00"};t.Lines[2]=new[]{"W43116","WINRUN 265/70R16 112T MAXCLAW A/T","4","140.00"};t.Lines[3]=new[]{"WA","WHEEL ALIGNMENT FRONT","1","89.00"};t.Lines[4]=new[]{"M FB","FITTING & BALANCING","",""};
                Check(RoExpect.Check(before,twice,Read(t),notes).Count==0,"The same code twice is matched either way round.");
                // A line that only lost its code (its words and price still there) is not "taken out".
                var cleared=new Fixture();cleared.Lines[2]=new[]{"","WHEEL ALIGNMENT FRONT","1","89.00"};var half=Read(cleared);
                Check(half.loose==1&&half.lines.All(l=>l.code!="WA")&&half.sig!=Read(gone).sig,"A line without its code must be counted (and in the fingerprint).");
                Check(RoExpect.Check(before,r,half,notes).Any(p=>p.Contains("item code")),"A line that only lost its code must stop the change.");
                // Nothing priced asked: the total must stay.
                var words=Edit(before);words.header=new Dictionary<string,string>{{"comment","fitted"}};
                var same=new Fixture();same.Comment="FITTED";Check(RoExpect.Check(before,words,Read(same),notes).Count==0,"A comment change with the same total passes.");
                var moved=new Fixture();moved.Comment="FITTED";moved.Total="$700.00";
                Check(RoExpect.Check(before,words,Read(moved),notes).Any(p=>p.Contains("total went from $650.00 to $700.00")),"A total that moved with nothing priced asked must stop.");
                var note=Edit(before);note.lines=new List<RoLineEdit>{new RoLineEdit{index=7,code="M",remove=true}};
                var noteGone=new Fixture();noteGone.Lines.Remove(10);noteGone.Total="$600.00";
                Check(RoExpect.Check(before,note,Read(noteGone),notes).Any(p=>p.Contains("total")),"Taking a note out must not move the total.");
            });
            Case("Repair Orders: only this line's own question is answered; the number counts only where nobody types; no customer words in the day log",()=>{
                var yn=new List<string>{"YES","NO"};
                foreach(var q in new[]{"Delete this line?","Are you sure you want to delete this item?","Remove the selected row?","Delete line?","This line will be deleted. Continue?","Delete this line from the Repair Order?"})
                    Check(Runner.YesToRemove(q,yn,true),"Not answered: "+q);
                foreach(var q in new[]{"Delete line 3?","DELETE ITEM W43116?","Do you want to delete this line?","Remove this product?","Are you sure you want to remove the current row?"})
                    Check(Runner.YesToRemove(q,yn,true),"Not answered: "+q);
                foreach(var q in new[]{"Remove the special order for this item?","Delete all lines?","This item has been invoiced. Delete this line?","Save changes before deleting this line?","Delete this item and its stock allocation?","Delete this line and email the customer?","Close the Repair Order?","Print the job card?","The line has been deleted.",
                    "Delete selected rows?","Delete this line and its linked fitting line?","This line is on order from the supplier. Delete this line?","This item has been received. Delete this line?","The item is reserved for job 1234. Delete this item?","Delete these lines?","Are you sure?"})
                    Check(!Runner.YesToRemove(q,yn,true),"Answered although it isn't only about this line: "+q);
                Check(!Runner.YesToRemove("Delete this line?",new List<string>{"OK"},true)&&!Runner.YesToRemove("Delete this line?",new List<string>{"YES","NO","CANCEL"},true)&&!Runner.YesToRemove("Delete this line?",new List<string>{"OK","CANCEL"},true),"Only exactly Yes and No.");
                Check(!Runner.YesToRemove("Delete this line?",yn,false),"Only a question the Repair Order owns.");
                // The number: in a label or a read-only box, never in a box anybody types into.
                var plain=Ro(new Fixture());Check(!Runner.NumberShown(plain,"07497644"),"The fixture shows no number.");
                var label=Ro(new Fixture());label.Add(Mk(60,150,ST,800,60,90,18,"07497644"));Check(Runner.NumberShown(label,"07497644"),"A label with the number.");
                var digits=Ro(new Fixture());digits.Add(Mk(60,150,ST,800,60,120,18,"RO # 7497644"));Check(Runner.NumberShown(digits,"07497644"),"The number without its leading zero.");
                var fixedBox=Ro(new Fixture());var box=Mk(61,150,ED,800,90,90,20,"07497644");box.Style=0x800;fixedBox.Add(box);Check(Runner.NumberShown(fixedBox,"07497644"),"A read-only box with the number.");
                var typedBox=Ro(new Fixture());typedBox.Add(Mk(62,150,ED,800,90,90,20,"07497644"));Check(!Runner.NumberShown(typedBox,"07497644"),"A box anybody types into doesn't count.");
                var f=new Fixture();f.Comment="WARRANTY FOR 07497644";Check(!Runner.NumberShown(Ro(f),"07497644"),"A comment naming the number doesn't count.");
                f=new Fixture();f.Po="07497644";Check(!Runner.NumberShown(Ro(f),"07497644"),"The PO# doesn't count.");
                f=new Fixture();f.Lines[11]=new[]{"M","SEE RO 07497644","",""};Check(!Runner.NumberShown(Ro(f),"07497644"),"A note line naming the number doesn't count.");
                // The day log: no customer words, accounts or numbers.
                string said=RoText.ForLog("COSTAR showed a message instead of opening Repair Order 07497644: \"JOHN CITIZEN owes $50\". Nothing was answered.");
                Check(!said.Contains("JOHN")&&!said.Contains("07497644")&&said.Contains("Nothing was answered"),"COSTAR's words left the log: "+said);
                string account=RoText.ForLog("COSTAR matched the new phone to customer account C10023. Check the Repair Order at the PC.");
                Check(!account.Contains("C10023")&&account.Contains("Check the Repair Order"),"An account number reached the log: "+account);
                Check(!RoText.ForLog("call 0412 345 678 or a@b.com").Contains("345"),"A phone number reached the log.");
                Check(RoText.ForLog("It said: CUSTOMER SMITH IS ON HOLD. Stopped.").IndexOf("SMITH",StringComparison.Ordinal)<0,"Words after said: reached the log.");
            });
            Case("Repair Orders: the desk queue hands out one request at a time, takes reports, and never leaves a request stuck",()=>{
                var q=new RoQueue();var now=new DateTime(2026,10,27,1,0,0,DateTimeKind.Utc);q.Clock=()=>now;int fired=0;q.Changed+=()=>fired++;
                var snap=Read(new Fixture());
                Reject(()=>q.Submit(new RoAsk{id="12",kind="list"}),"A request needs an ID.","ID");
                Reject(()=>q.Submit(Ask("delete","07497644")),"Unknown kinds are refused.","Unknown");
                Reject(()=>q.Submit(Ask("open","07 497")),"A bad RO number.","number");
                Reject(()=>q.Submit(Ask("open","07497644",Edit(snap))),"Only a change carries changes.","Only");
                var list=q.Submit(Ask("list"));Check(list.status=="queued"&&fired==1,"A list request waits for the helper.");
                Check(q.Submit(Ask("list")).id==list.id,"A second list request joins the first.");
                var open=q.Submit(Ask("open","07497644"));Check(q.Submit(Ask("open","07497644")).id==open.id,"A second open of the same RO joins the first.");
                var again=Ask("open","07497645");var first=q.Submit(again);Check(q.Submit(again).id==first.id,"The same ID sent again is the same request.");
                var clash=Wire.Copy(again);clash.doc="07497646";Reject(()=>q.Submit(clash),"An ID used for something else.","CONFLICT");
                // COSTAR busy: the list is read anyway (Order Check's copy), opening waits.
                var r1=q.Poll(Hello(null,true,false,""));Check(r1.command=="do"&&r1.task.kind=="list"&&r1.task.lease.Length>20,"The list goes first, even while COSTAR is busy.");
                Check(q.Poll(Hello(null,true,false,r1.task.lease)).command=="do"&&q.Poll(Hello(null,true,false,r1.task.lease)).task.lease==r1.task.lease,"An unanswered claim is handed out again with the same lease.");
                var rows=new RoList{rows=new List<RoListRow>{new RoListRow{doc="07497644",name="TEST CUSTOMER"}},readUtc="x",source="costar"};
                var w1=q.Poll(Hello(Report(r1,"working",1),true,false,r1.task.lease));Check(w1.command=="wait"&&w1.ack==1,"While the helper works on one request, nothing else is handed out.");
                var d1=q.Poll(Hello(Report(r1,"done",2,null,rows),true,false,""));
                Check(d1.ack==2&&q.Get(list.id).status=="done"&&q.List.rows.Count==1&&d1.command=="wait","A finished list is kept for the phones; opening still waits for COSTAR.");
                Check(q.Get(open.id).status=="queued","The open waits while COSTAR is busy.");
                var r2=q.Poll(Hello(null,true,true,""));Check(r2.command=="do"&&r2.task.kind=="open"&&r2.task.doc=="07497644","COSTAR free: the oldest open is handed out.");
                var dec=q.Poll(new RoHello{workerId="test-worker",accepting=true,available=false,working="",declined=r2.task.lease,declineReason="someone is using the COSTAR PC",sequence=1000});
                Check(q.Get(open.id).status=="queued"&&q.Get(open.id).message=="Waiting: someone is using the COSTAR PC"&&dec.command=="wait","A declined request waits again with the reason.");
                var r3=q.Poll(Hello(null,true,true,""));Check(r3.task.id==open.id&&r3.task.lease!=r2.task.lease,"A declined request comes back with a new lease.");
                var r3b=q.Poll(Hello(Report(r3,"done",3,snap),true,true,""));
                var st=q.Get(open.id);Check(st.status=="done"&&st.snapshot!=null&&st.snapshot.sig==snap.sig,"The snapshot reaches the phone.");
                Check(r3b.command=="do"&&r3b.task.doc=="07497645","The next open follows at once.");
                // A report for an old lease, or an unknown request, is acked and dropped.
                var stale=q.Poll(Hello(new RoReport{id=open.id,lease=r2.task.lease,status="failed",sequence=4},true,false,""));
                Check(stale.ack==4&&q.Get(open.id).status=="done","A stale report must not change a finished request.");
                Check(q.Poll(Hello(new RoReport{id="RO-00000000-0000-0000-0000-000000000000",lease="x",status="done",sequence=5},true,false,"")).ack==5,"An unknown request's report is acked.");
                q.Poll(Hello(Report(r3b,"done",6,snap),true,false,""));Check(q.Get(first.id).status=="done","The second open is done.");
                // A change: the helper restarts while typing it.
                var e=Edit(snap);e.customerWaiting="yes";var change=q.Submit(Ask("edit",snap.doc,e));
                Reject(()=>q.Submit(Ask("edit",snap.doc,e)),"Two changes to one RO at once.","already has a change");
                var r4=q.Poll(Hello(null,true,true,""));Check(r4.task.kind=="edit"&&r4.task.edit.customerWaiting=="yes"&&r4.task.edit.baseSig==snap.sig,"The change goes to the helper as sent.");
                q.Poll(Hello(Report(r4,"working",7),true,true,r4.task.lease,7));
                q.Poll(Hello(null,true,true,"",6));Check(q.Get(change.id).status=="working","An older hello can't end a request the helper reported on later.");
                q.Poll(Hello(null,true,true,"",8));
                var lost=q.Get(change.id);Check(lost.status=="failed"&&lost.typed&&lost.message.Contains("Check it in COSTAR"),"A change the helper stopped working on fails, marked as maybe typed.");
                // Time-outs: queued too long, or the helper silent while working.
                var late=q.Submit(Ask("close","07497644"));now=now.AddMinutes(11);q.Tidy(now);
                Check(q.Get(late.id).status=="failed"&&q.Get(late.id).message.Contains("10 minutes"),"A request nobody got to fails after 10 minutes.");
                var o2=q.Submit(Ask("open","07497650"));var r5=q.Poll(Hello(null,true,true,""));q.Poll(Hello(Report(r5,"working",9),true,true,r5.task.lease,9));
                q.Tidy(now.AddSeconds(-30));Check(q.Get(o2.id).status=="working","Still in touch: still working.");
                q.Tidy(now.AddSeconds(-100));Check(q.Get(o2.id).status=="failed","A silent helper's request fails.");
                // Switched off: nothing handed out.
                q.Submit(Ask("open","07497651"));Check(q.Poll(Hello(null,false,true,"")).command=="wait","Repair Orders switched off: wait.");
                for(int i=0;i<RoQueue.MaxWaiting-1;i++) q.Submit(Ask("open","0749"+(7700+i).ToString(CultureInfo.InvariantCulture)));
                Reject(()=>q.Submit(Ask("open","07499999")),"Too many waiting.","Too many");
                now=now.AddHours(5);q.Tidy(DateTime.MinValue);
                Check(q.Recent(500).Count<=RoQueue.Keep,"Old requests go.");
            });
            Case("Receiver Repair Order routes: the phone key and origin, list, requests and status; the worker route; health",()=>{
                var settings=new ReceiverSettings {address="192.168.1.2",phoneToken="phone-test",workerToken="worker-test",workerId="test-worker",ebayToken="ebay-test",webUrl="https://example.com/Fitment_Planner.html"};
                var api=new ReceiverApi(settings,new JobQueue(null,s=>{}),Path.GetTempPath(),()=>false,id=>{});
                const string root="/api/mobile/v1/ro";
                Check(api.Handle(Request("GET",root+"/list","phone-test")).status==400,"Before the queue exists the routes say so.");
                var q=new RoQueue();api.UseRo(q);
                Check(api.Handle(Request("GET",root+"/list",null)).status==401&&api.Handle(Request("GET",root+"/list","ebay-test")).status==401&&api.Handle(Request("GET",root+"/list","worker-test")).status==401,"Only the phone key opens the Repair Order routes.");
                Check(api.Handle(Request("GET",root+"/list","phone-test","https://evil.example")).status==403,"Another website may not use them.");
                Check(api.Handle(Request("GET",root+"/list","phone-test","chrome-extension://abcdefghijklmnopabcdefghijklmnop")).status==403,"The eBay extension may not use them.");
                var empty=api.Handle(Request("GET",root+"/list","phone-test","https://example.com"));
                Check(empty.status==200&&empty.headers["Access-Control-Allow-Origin"]=="https://example.com","The paired website reads the list.");
                var view=Body<Dictionary<string,object>>(empty);var helper=(Dictionary<string,object>)view["helper"];
                Check(view["list"]==null&&!(bool)helper["connected"]&&((string)helper["waiting"]).Contains("not running"),"No list yet, helper not in touch.");
                var ask=Ask("list");var posted=api.Handle(Request("POST",root+"/requests","phone-test","https://example.com",ask));
                var ps=Body<RoStatus>(posted);Check(posted.status==200&&ps.status=="queued"&&ps.waiting.Contains("not running"),"A request is taken and says why it waits.");
                Check(api.Handle(Request("GET",root+"/requests/"+ask.id,"phone-test")).status==200&&api.Handle(Request("GET",root+"/requests/RO-11111111-1111-1111-1111-111111111111","phone-test")).status==404,"Status, and 404 for an unknown request.");
                var bad=Ask("open","07497644");bad.edit=new RoEdit();Check(api.Handle(Request("POST",root+"/requests","phone-test",null,bad)).status==400,"A malformed request is refused.");
                Check(api.Handle(Request("POST","/api/worker/v1/ro","phone-test",null,Hello())).status==401&&api.Handle(Request("POST","/api/worker/v1/ro","worker-test",null,new RoHello{workerId="intruder"})).status==400,"The worker route needs the worker key and ID.");
                Check(api.Handle(Request("GET","/api/worker/v1/ro","worker-test")).status==400,"The worker route takes POST only.");
                var claim=Body<RoReply>(api.Handle(Request("POST","/api/worker/v1/ro","worker-test",null,Hello(null,true,false,""))));
                Check(claim.command=="do"&&claim.task.id==ask.id,"The worker route hands the request out.");
                var health=Body<Dictionary<string,object>>(api.Handle(Request("GET","/api/mobile/v1/health","phone-test")));
                Check((bool)health["ro"]&&(bool)health["roConnected"]&&(bool)health["roOn"]&&!(bool)health["roReady"],"Health tells the phone about Repair Orders.");
                var done=Hello(new RoReport{id=ask.id,lease=claim.task.lease,status="done",message="47 Repair Orders",sequence=1,list=new RoList{rows=new List<RoListRow>{new RoListRow{doc="07497644"}},readUtc="2026-10-27T01:00:00Z",source="costar"}},true,false,"");
                done.detail="COSTAR\u0085 busy "+new string('x',600);
                api.Handle(Request("POST","/api/worker/v1/ro","worker-test",null,done));
                var read=Body<Dictionary<string,object>>(api.Handle(Request("GET",root+"/list","phone-test")));
                Check(read["list"]!=null&&read["refresh"]==null,"The list reaches the phone.");
                Check(!api.RoDetail.Any(Char.IsControl)&&api.RoDetail.Length<=400,"Words from the helper are cleaned.");
                settings.phoneToken="";Check(api.Handle(Request("GET",root+"/list","")).status==401,"An empty key never matches.");
            });
            Case("Receiver Repair Order worker poll: a held poll wakes when a phone asks",()=>{
                var settings=new ReceiverSettings {address="192.168.1.2",phoneToken="phone-test",workerToken="worker-test",workerId="test-worker"};
                var api=new ReceiverApi(settings,new JobQueue(null,s=>{}),Path.GetTempPath(),()=>false,id=>{});var q=new RoQueue();api.UseRo(q);
                var hello=Hello(null,true,true,"");hello.waitMs=3000;
                RoReply reply=null;var t=new Thread(()=>{reply=Body<RoReply>(api.Handle(Request("POST","/api/worker/v1/ro","worker-test",null,hello)));});
                var clock=System.Diagnostics.Stopwatch.StartNew();t.Start();Thread.Sleep(300);
                var ask=Ask("open","07497644");api.Handle(Request("POST","/api/mobile/v1/ro/requests","phone-test",null,ask));
                Check(t.Join(5000)&&reply!=null&&reply.command=="do"&&reply.held&&clock.ElapsedMilliseconds<2500,"The held poll must answer as soon as the request arrives.");
            });
            Case("Receiver reads bigger bodies on the Repair Order worker route with the worker key only (the WIP list)",()=>{
                var settings=new ReceiverSettings {address="192.168.1.2",phoneToken="phone-test",workerToken="worker-test",workerId="test-worker"};
                var api=new ReceiverApi(settings,new JobQueue(null,s=>{}),Path.GetTempPath(),()=>false,id=>{});
                Func<string,string,int,bool> fits=(path,key,size)=>{
                    string body=new string('x',size);
                    var raw=Encoding.ASCII.GetBytes("POST "+path+" HTTP/1.1\r\nHost: 192.168.1.2:8790\r\nContent-Type: application/json\r\n"+(key==null?"":"Authorization: Bearer "+key+"\r\n")+"Content-Length: "+size+"\r\n\r\n"+body);
                    try { LocalServer.Read(new MemoryStream(raw),api.LargeBody);return true; } catch(InvalidOperationException) { return false; }
                };
                Check(fits("/api/worker/v1/ro","worker-test",200000)&&!fits("/api/worker/v1/ro","worker-test",1048577),"The Repair Order worker route takes up to 1 MB.");
                Check(!fits("/api/worker/v1/ro",null,70000)&&!fits("/api/worker/v1/ro","phone-test",70000),"Without the worker key it stays at 64 KB (nothing big is buffered for a stranger).");
                Check(!fits("/api/worker/../mobile/v1/ro/requests","worker-test",70000)&&!fits("/api/worker/v1/ro/../../mobile/v1/ro/requests","worker-test",70000),"A path that only starts like the worker route stays at 64 KB.");
                Check(!fits("/api/mobile/v1/ro/requests","phone-test",70000)&&fits("/api/mobile/v1/ro/requests","phone-test",60000),"Phone routes stay at 64 KB.");
                Check(!fits("/api/worker/v1/poll","worker-test",70000),"The other worker routes stay at 64 KB.");
            });
        }
    }
}
