using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;

namespace TempeCostar {
    public sealed class ReceiverSettings {
        // ebayToken (2.5.0): the eBay PC's extension key, separate from the phones' key.
        public string address,certificateThumbprint,phoneToken,workerToken,workerId,webUrl,ebayToken;
        public int port=8790,trustPort=8791;
        internal string Origin {get{return "https://"+address+":"+port;}}
    }
    public sealed class WorkerSettings {public string baseUrl,token,workerId,certificateHash;}
    // 2.5.1: the certificate the desk hands out at /trust.cer is the root that actually signed its
    // HTTPS certificate, found by signature in this Windows user's stores. A setup that stopped half
    // way (25 Oct: trust.cer from a second setup, HTTPS still on the first one's certificate) can't
    // hand out the wrong one. Null when it can't be found; the desk then hands out its file.
    internal static class TrustRoot {
        internal static X509Certificate2 Of(X509Certificate2 leaf,X509Certificate2Collection extra) {
            if(leaf==null) return null;
            using(var chain=new X509Chain()) {
                chain.ChainPolicy.RevocationMode=X509RevocationMode.NoCheck;
                chain.ChainPolicy.VerificationFlags=X509VerificationFlags.AllowUnknownCertificateAuthority|X509VerificationFlags.IgnoreNotTimeValid;
                if(extra!=null) chain.ChainPolicy.ExtraStore.AddRange(extra);
                chain.Build(leaf);
                int n=chain.ChainElements.Count;
                if(n<2) return null;
                foreach(X509ChainElement e in chain.ChainElements) foreach(var s in e.ChainElementStatus) if((s.Status&X509ChainStatusFlags.NotSignatureValid)!=0) return null;
                var top=chain.ChainElements[n-1].Certificate;
                return top.Subject==top.Issuer?new X509Certificate2(top.RawData):null;
            }
        }
    }
    internal static class NetworkRules {
        internal static bool Private(IPAddress a) {
            if(IPAddress.IsLoopback(a))return true;
            if(a.AddressFamily!=AddressFamily.InterNetwork)return false;
            byte[] b=a.GetAddressBytes();return b[0]==10||(b[0]==192&&b[1]==168)||(b[0]==172&&b[1]>=16&&b[1]<=31);
        }
        internal static string Website(string value) {
            if(String.IsNullOrWhiteSpace(value))return "";
            Uri u;Order.Require(Uri.TryCreate(value.Trim(),UriKind.Absolute,out u)&&u.Scheme=="https"&&u.UserInfo==""&&u.Query==""&&u.Fragment==""&&!PrivateHost(u.Host),"Use the public HTTPS website URL, without a query or fragment.");
            if(!u.AbsolutePath.EndsWith("/",StringComparison.Ordinal)&&Path.GetExtension(u.AbsolutePath)=="")u=new Uri(u.AbsoluteUri+"/");
            return new Uri(u,"Fitment_Planner.html").AbsoluteUri;
        }
        static bool PrivateHost(string host) {IPAddress ip;return host.Equals("localhost",StringComparison.OrdinalIgnoreCase)||(IPAddress.TryParse(host,out ip)&&Private(ip));}
        internal static void Worker(WorkerSettings c) {
            Uri u;IPAddress ip;
            Order.Require(c!=null&&Uri.TryCreate(c.baseUrl,UriKind.Absolute,out u)&&u.Scheme=="https"&&IPAddress.TryParse(u.Host,out ip)&&Private(ip)&&u.AbsolutePath=="/"&&u.UserInfo==""&&u.Query==""&&u.Fragment=="","Invalid receiver connection address.");
            Order.Require(c.token!=null&&c.token.Length>=32&&c.workerId!=null&&c.certificateHash!=null&&c.certificateHash.Length==64,"Incomplete worker connection file.");
        }
        internal static bool TyreUrl(Uri u) {return u!=null&&u.Scheme=="https"&&u.Port==443&&u.UserInfo==""&&(u.Host=="tempetyres.com.au"||u.Host=="www.tempetyres.com.au")&&new[]{"/tyres","/tyreproducts","/search"}.Contains(u.AbsolutePath);}
        internal static string FetchTyres(string target) {
            Uri url;Order.Require(Uri.TryCreate(target,UriKind.Absolute,out url)&&TyreUrl(url),"Only Tempe tyre searches and product pages are allowed.");
            for(int redirects=0;redirects<4;redirects++) {
                var req=(HttpWebRequest)WebRequest.Create(url);req.Method="GET";req.AllowAutoRedirect=false;req.Timeout=12000;req.ReadWriteTimeout=12000;req.UserAgent="TempeMobileJobCard/1.0";req.Accept="text/html";req.AutomaticDecompression=DecompressionMethods.GZip|DecompressionMethods.Deflate;
                using(var response=(HttpWebResponse)req.GetResponse()) {
                    int status=(int)response.StatusCode;
                    if(status>=300&&status<400){url=new Uri(url,response.Headers["Location"]??"");Order.Require(TyreUrl(url),"Tempe redirected outside the permitted product pages.");continue;}
                    Order.Require(status>=200&&status<300,"Tempe returned an unsuccessful response.");
                    using(var stream=response.GetResponseStream())using(var memory=new MemoryStream()) {
                        byte[] buffer=new byte[16384];int n;
                        while((n=stream.Read(buffer,0,buffer.Length))>0){Order.Require(memory.Length+n<=8000000,"Product page is too large.");memory.Write(buffer,0,n);}
                        return Encoding.UTF8.GetString(memory.ToArray());
                    }
                }
            }
            throw new InvalidOperationException("Too many product-page redirects.");
        }
    }
    internal sealed class HttpInput {
        internal string method,path;internal Dictionary<string,string> headers;internal string body;
        // 2.4.0: whether the caller is still waiting (a held worker poll checks before answering).
        internal Func<bool> alive;
    }
    internal sealed class HttpOutput {
        internal int status=200;internal string type="application/json; charset=utf-8";internal byte[] bytes;
        internal Dictionary<string,string> headers=new Dictionary<string,string>();
        internal static HttpOutput Json(object value,int code=200) {return new HttpOutput {status=code,bytes=Encoding.UTF8.GetBytes(Wire.Json(value))};}
        internal static HttpOutput Text(string text,string type) {return new HttpOutput {bytes=Encoding.UTF8.GetBytes(text),type=type};}
    }
    internal sealed class LocalServer : IDisposable {
        readonly TcpListener listener;readonly X509Certificate2 certificate;readonly string expectedHost;
        readonly Func<HttpInput,HttpOutput> route;readonly SemaphoreSlim capacity=new SemaphoreSlim(16);volatile bool stopped;
        internal LocalServer(string address,int port,X509Certificate2 cert,Func<HttpInput,HttpOutput> handler) {
            IPAddress ip=IPAddress.Parse(address);Order.Require(NetworkRules.Private(ip)&&!IPAddress.IsLoopback(ip),"Choose the desk PC's private LAN IPv4 address.");
            listener=new TcpListener(ip,port);certificate=cert;route=handler;expectedHost=address+":"+port;
        }
        internal void Start(){listener.Start(20);var t=new Thread(Accept);t.IsBackground=true;t.Start();}
        void Accept() {
            while(!stopped)try {
                var client=listener.AcceptTcpClient();if(!capacity.Wait(0)){client.Close();continue;}
                ThreadPool.QueueUserWorkItem(delegate {try {Serve(client);}finally {client.Close();capacity.Release();}});
            }catch(SocketException){if(!stopped)Thread.Sleep(200);}catch(ObjectDisposedException){return;}
        }
        void Serve(TcpClient client) {
            if(!NetworkRules.Private(((IPEndPoint)client.Client.RemoteEndPoint).Address))return;
            client.ReceiveTimeout=10000;client.SendTimeout=10000;
            Stream stream=client.GetStream();SslStream tls=null;
            try {
                if(certificate!=null) {tls=new SslStream(stream,false);tls.ReadTimeout=10000;tls.WriteTimeout=10000;tls.AuthenticateAsServer(certificate,false,SslProtocols.Tls12,false);stream=tls;}
                HttpOutput result;
                try {
                    var request=Read(stream);string host;
                    Order.Require(request.headers.TryGetValue("host",out host)&&host.Equals(expectedHost,StringComparison.OrdinalIgnoreCase),"Invalid request host.");
                    // A socket that is readable with nothing to read has been closed by the caller.
                    request.alive=delegate { try { return client.Connected&&!(client.Client.Poll(0,SelectMode.SelectRead)&&client.Client.Available==0); } catch(Exception) { return false; } };
                    result=route(request);
                } catch(Exception e) {result=HttpOutput.Json(new{error=e is InvalidOperationException?e.Message:"Request could not be processed."},400);}
                Write(stream,result);
            }catch(IOException){}catch(AuthenticationException){}catch(ObjectDisposedException){}
            catch(Exception e){System.Diagnostics.Trace.WriteLine("Receiver connection failed: "+e.GetType().Name);}
            finally{if(tls!=null)tls.Dispose();}
        }
        static HttpInput Read(Stream stream) {
            using(var header=new MemoryStream()) {
                int b,matched=0;byte[] ending={13,10,13,10};
                while(matched<4) {
                    b=stream.ReadByte();Order.Require(b>=0&&header.Length<16384,"Invalid or oversized HTTP headers.");header.WriteByte((byte)b);
                    matched=b==ending[matched]?matched+1:(b==13?1:0);
                }
                string[] lines=Encoding.ASCII.GetString(header.ToArray()).Split(new[]{"\r\n"},StringSplitOptions.None);
                string[] start=lines[0].Split(' ');Order.Require(start.Length==3&&start[2]=="HTTP/1.1"&&start[1].StartsWith("/",StringComparison.Ordinal)&&!start[1].StartsWith("//",StringComparison.Ordinal),"Invalid request line.");
                var headers=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
                foreach(string line in lines.Skip(1).Where(x=>x.Length>0)) {
                    int colon=line.IndexOf(':');Order.Require(colon>0&&!Char.IsWhiteSpace(line[0]),"Invalid header.");
                    string key=line.Substring(0,colon).Trim();Order.Require(!headers.ContainsKey(key),"Duplicate header.");headers.Add(key,line.Substring(colon+1).Trim());
                }
                Order.Require(!headers.ContainsKey("transfer-encoding")&&!headers.ContainsKey("expect"),"Chunked or deferred bodies are unsupported.");
                int length=0;string size;
                if(headers.TryGetValue("content-length",out size))Order.Require(Int32.TryParse(size,out length)&&length>=0&&length<=65536,"Invalid request size.");
                byte[] body=new byte[length];int offset=0;
                while(offset<length){int n=stream.Read(body,offset,length-offset);Order.Require(n>0,"Incomplete request body.");offset+=n;}
                return new HttpInput {method=start[0],path=start[1],headers=headers,body=new UTF8Encoding(false,true).GetString(body)};
            }
        }
        static void Write(Stream stream,HttpOutput r) {
            byte[] body=r.bytes??new byte[0];
            var b=new StringBuilder("HTTP/1.1 "+r.status+" "+(r.status==200?"OK":r.status==204?"No Content":"Response")+"\r\nConnection: close\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nReferrer-Policy: no-referrer\r\n");
            b.Append("Content-Type: ").Append(r.type).Append("\r\nContent-Length: ").Append(body.Length).Append("\r\n");
            foreach(var pair in r.headers)b.Append(pair.Key).Append(": ").Append(pair.Value).Append("\r\n");
            b.Append("\r\n");byte[] head=Encoding.ASCII.GetBytes(b.ToString());stream.Write(head,0,head.Length);stream.Write(body,0,body.Length);stream.Flush();
        }
        public void Dispose(){stopped=true;listener.Stop();}
    }
    internal sealed class ReceiverApi {
        internal readonly JobQueue Queue;internal readonly ReceiverSettings Settings;
        internal volatile bool Receiving=true;internal volatile bool WorkerAccepting,WorkerAvailable;
        internal DateTime LastWorker=DateTime.MinValue;internal string WorkerDetail="RDP helper not connected";
        readonly string website;readonly Func<bool> idle;readonly Action<string> incoming;readonly object workerGate=new object();
        // 2.4.0: a worker poll that asked to wait (waitMs) sleeps here until the queue changes.
        readonly object pulse=new object();int version;
        // How often the same job was answered with "forget": a 2.3.x helper never acts on it.
        string forgetId="";int forgetCount;
        internal string ForgetHint { get { lock(workerGate) return forgetCount>=5?"The RDP helper keeps reporting a job this desk closed ("+forgetId+"). Update it to 2.4.0 or restart it; it may still show that job.":""; } }
        internal ReceiverApi(ReceiverSettings settings,JobQueue queue,string site,Func<bool> isIdle,Action<string> onIncoming) {
            Settings=settings;Queue=queue;website=site;idle=isIdle;incoming=onIncoming;
            Queue.Changed+=delegate { lock(pulse) { version++;Monitor.PulseAll(pulse); } };
        }
        // 2.4.0: Connected = the RDP helper is talking to this desk (within 15 s), whether or not
        // mobile entry is switched on there; Accepting says whether it takes jobs right now.
        internal bool Connected {get {lock(workerGate)return DateTime.UtcNow-LastWorker<TimeSpan.FromSeconds(15);}}
        internal bool Accepting {get {lock(workerGate)return Connected&&WorkerAccepting;}}
        internal int SecondsSinceWorker {get {lock(workerGate)return LastWorker==DateTime.MinValue?-1:(int)(DateTime.UtcNow-LastWorker).TotalSeconds;}}
        internal void Wake() { lock(pulse) { version++;Monitor.PulseAll(pulse); } }
        // ---- eBay orders (2.5.0) ----
        // The eBay queue (null: eBay routes answer 503), the PIN pairing, and what the RDP helper's
        // eBay side last said. EbayIncoming: a new eBay order arrived; EbayPaired: the PIN was used.
        EbayQueue ebay;internal EbayQueue Ebay {get{return ebay;}}
        internal readonly EbayPairing Pairing=new EbayPairing();internal Action<string> EbayIncoming,EbayPaired;
        internal DateTime LastEbayWorker=DateTime.MinValue;internal bool EbayAccepting,EbayAvailable;internal string EbayDetail="RDP helper not connected";
        readonly object ebayPulse=new object();int ebayVersion;
        internal void UseEbay(EbayQueue queue) {
            Order.Require(queue!=null&&ebay==null,"The eBay queue is already set.");
            ebay=queue;queue.Changed+=WakeEbay;
        }
        internal bool EbayConnected {get {lock(workerGate)return DateTime.UtcNow-LastEbayWorker<TimeSpan.FromSeconds(30);}}
        internal int SecondsSinceEbayWorker {get {lock(workerGate)return LastEbayWorker==DateTime.MinValue?-1:(int)(DateTime.UtcNow-LastEbayWorker).TotalSeconds;}}
        // Why a queued eBay order is still waiting, in words for the eBay PC.
        internal string EbayWaiting {
            get {
                if(!Receiving) return "Tommy's desk PC has stopped receiving.";
                lock(workerGate) {
                    if(DateTime.UtcNow-LastEbayWorker>=TimeSpan.FromSeconds(30)) return "The RDP helper on the COSTAR PC is not running (or not in touch).";
                    if(!EbayAccepting) return "eBay orders are switched off in the RDP helper"+(String.IsNullOrEmpty(EbayDetail)?".":": "+EbayDetail);
                    if(!EbayAvailable) return String.IsNullOrEmpty(EbayDetail)?"Waiting for COSTAR Sydney.":EbayDetail;
                }
                return "Next in line for COSTAR Sydney.";
            }
        }
        internal void WakeEbay() { lock(ebayPulse) { ebayVersion++;Monitor.PulseAll(ebayPulse); } }
        // What the RDP helper's eBay side last said, read together (for the desk window).
        internal void EbaySide(out bool connected,out bool on,out bool ready,out string detail) {
            lock(workerGate) { connected=DateTime.UtcNow-LastEbayWorker<TimeSpan.FromSeconds(30);on=connected&&EbayAccepting;ready=on&&EbayAvailable;detail=EbayDetail??""; }
        }
        // Chrome and Edge extension pages: chrome-extension://<32 letters a-p>.
        internal static bool ExtensionOrigin(string origin) { return origin!=null&&System.Text.RegularExpressions.Regex.IsMatch(origin,@"^(chrome-extension|extension)://[a-p]{32}$"); }
        internal HttpOutput Handle(HttpInput r) {
            string origin;bool hasOrigin=r.headers.TryGetValue("origin",out origin);
            string allowed=String.IsNullOrEmpty(Settings.webUrl)?null:new Uri(Settings.webUrl).GetLeftPart(UriPartial.Authority);
            // One reading of the path for the origin rule, the key and the route (2.5.0): an encoded
            // path can't pass as one kind of route here and be routed as another.
            Uri uri;
            try { uri=new Uri(Settings.Origin+r.path); } catch(UriFormatException) { return HttpOutput.Json(new{error="Invalid request path."},400); }
            // eBay routes: the eBay PC's extension (or no browser at all), never a website.
            bool ebayRoute=uri.AbsolutePath.StartsWith("/api/ebay/",StringComparison.Ordinal);
            if(hasOrigin && ebayRoute && !ExtensionOrigin(origin))return HttpOutput.Json(new{error="Only the eBay PC's extension can send eBay orders."},403);
            if(hasOrigin && !ebayRoute && origin!=Settings.Origin && origin!=allowed)return HttpOutput.Json(new{error="Website origin is not paired with this PC."},403);
            HttpOutput output;
            try {output=Route(r,uri);}catch(Exception e) {output=HttpOutput.Json(new{error=e is InvalidOperationException?e.Message:"Local request failed. Check the desk helper."},e.Message.StartsWith("CONFLICT:",StringComparison.Ordinal)?409:400);}
            if(hasOrigin) {output.headers["Access-Control-Allow-Origin"]=origin;output.headers["Vary"]="Origin";}
            return output;
        }
        HttpOutput Route(HttpInput r,Uri uri) {
            string path=uri.AbsolutePath;
            if(r.method=="OPTIONS") {
                Order.Require(r.headers.ContainsKey("origin"),"Missing origin.");
                var o=new HttpOutput {status=204};o.headers["Access-Control-Allow-Methods"]="GET, POST, OPTIONS";o.headers["Access-Control-Allow-Headers"]="Authorization, Content-Type";o.headers["Access-Control-Allow-Private-Network"]="true";return o;
            }
            if(!path.StartsWith("/api/",StringComparison.Ordinal))return Static(path,r.method);
            string authorization;r.headers.TryGetValue("authorization",out authorization);
            // 2.5.0: the eBay PIN pairing is the one route without a key (it hands the eBay key out once).
            if(path=="/api/ebay/v1/pair")return Pair(r);
            bool worker=path=="/api/worker/v1/poll",ebayWorker=path=="/api/worker/v1/ebay",ebayRoute=path.StartsWith("/api/ebay/",StringComparison.Ordinal);
            string key=worker||ebayWorker?Settings.workerToken:ebayRoute?Settings.ebayToken:Settings.phoneToken;
            if(String.IsNullOrEmpty(key)||!Wire.Equal(authorization,"Bearer "+key))return HttpOutput.Json(new{error=ebayRoute?"The eBay key is not valid. Pair the eBay PC again (Pair eBay PC on Tommy's desk receiver).":"Pairing key is invalid."},401);
            if(r.method=="POST") {string type;Order.Require(r.headers.TryGetValue("content-type",out type)&&type.Split(';')[0].Trim()=="application/json","Expected JSON.");}
            if(ebayWorker)return EbayWorkerPoll(r);
            if(ebayRoute)return EbayRoute(r,path);
            if(worker&&r.method=="POST") {
                var hello=Wire.Read<WorkerHello>(r.body);Order.Require(hello!=null&&hello.workerId==Settings.workerId,"Wrong paired worker.");
                if(hello.report!=null){Order.Safe(hello.report.message,"worker message",2000);Order.Safe(hello.report.progress,"worker progress",1000);}
                hello.accepting=hello.accepting&&Receiving;
                lock(workerGate){LastWorker=DateTime.UtcNow;WorkerAccepting=hello.accepting;WorkerAvailable=hello.available;WorkerDetail=hello.detail??"Connected";}
                // The version is read before the poll (which itself counts as one change), so a job
                // arriving while the poll runs is never missed.
                int v;lock(pulse)v=version;
                var reply=Queue.Poll(hello);
                int after;lock(pulse)after=version;
                if(reply.command=="forget") { lock(workerGate) { string id=reply.status==null?"":reply.status.submissionId;if(id==forgetId)forgetCount++;else{forgetId=id;forgetCount=1;} } }
                else lock(workerGate) { forgetCount=0; }
                // 2.4.0: nothing to do and the worker offered to wait: hold the connection until the
                // queue changes (a job, an approval, Next Order) or the caller goes away, then ask
                // the queue again. The report was applied above, so the second look carries none.
                int waitMs=Math.Min(Math.Max(hello.waitMs,0),20000);
                // Only when nothing but the poll itself changed the queue meanwhile (the poll saves once;
                // a job or an approval that arrived during it is answered straight away).
                if(waitMs>0&&reply.command=="wait"&&hello.accepting&&after<=v+1) {
                    var clock=System.Diagnostics.Stopwatch.StartNew();bool alive=true;
                    lock(pulse) {
                        while(version<=after&&clock.ElapsedMilliseconds<waitMs) {
                            Monitor.Wait(pulse,(int)Math.Max(1,Math.Min(500,waitMs-clock.ElapsedMilliseconds)));
                            if(r.alive!=null&&!r.alive()){alive=false;break;}
                        }
                    }
                    if(!alive) return HttpOutput.Json(new WorkerReply {command="wait",held=true,waitedMs=(int)clock.ElapsedMilliseconds});
                    // The worker may have sent a newer request meanwhile (Stop pressed): never assign a
                    // job on a stale "accepting"; the newest request's word counts.
                    lock(workerGate){hello.accepting=hello.accepting&&WorkerAccepting&&Receiving;}
                    hello.report=null;reply=Queue.Poll(hello);
                    reply.held=true;reply.waitedMs=(int)clock.ElapsedMilliseconds;
                    lock(workerGate){LastWorker=DateTime.UtcNow;}
                }
                return HttpOutput.Json(reply);
            }
            const string prefix="/api/mobile/v1";
            if(path==prefix+"/health"&&r.method=="GET")return HttpOutput.Json(new{service="tempe-mobile-jobcard",apiVersion=1,receiving=Receiving,workerConnected=Connected,workerAccepting=Accepting,pendingCount=Queue.List().Count(j=>!j.closed&&j.status!="ready_for_review")});
            if(path==prefix+"/jobs"&&r.method=="POST") {
                var job=Wire.Read<MobileJob>(r.body);Order.Require(job!=null,"Missing job.");
                var existing=Queue.Get(job.submissionId);
                // 2.4.0: a job is taken while the RDP helper is in touch, even with mobile entry
                // switched off there (it waits in the queue and says so); only a helper that is
                // offline altogether refuses it.
                Order.Require(existing!=null||(Receiving&&Connected),"The PC receiver is stopped or the RDP helper is offline.");
                var status=Queue.Submit(job,idle());if(existing==null)incoming(job.submissionId);return HttpOutput.Json(status);
            }
            if(path.StartsWith(prefix+"/jobs/",StringComparison.Ordinal)) {
                string tail=path.Substring((prefix+"/jobs/").Length);bool retry=tail.EndsWith("/retry",StringComparison.Ordinal);string id=retry?tail.Substring(0,tail.Length-6):tail;
                if(retry&&r.method=="POST") {Order.Require(Receiving&&Connected,"The RDP helper is offline.");var body=Wire.Read<Dictionary<string,string>>(r.body);Order.Require(body!=null&&body.ContainsKey("submissionId")&&body["submissionId"]==id,"Retry ID mismatch.");return HttpOutput.Json(Queue.Retry(id));}
                if(!retry&&r.method=="GET"){var status=Queue.Get(id);return status==null?HttpOutput.Json(new{error="Unknown submission"},404):HttpOutput.Json(status);}
            }
            if(path==prefix+"/tyres"&&r.method=="GET") {
                var query=System.Web.HttpUtility.ParseQueryString(uri.Query);string target=query["url"];
                Order.Require(target!=null&&target.Length<=2500,"Missing or oversized tyre URL.");
                return HttpOutput.Json(new{ok=true,status=200,text=NetworkRules.FetchTyres(target)});
            }
            return HttpOutput.Json(new{error="Route not found"},404);
        }
        // ---- eBay routes (2.5.0) ----
        HttpOutput Pair(HttpInput r) {
            Order.Require(r.method=="POST","Method not allowed.");
            string type;Order.Require(r.headers.TryGetValue("content-type",out type)&&type.Split(';')[0].Trim()=="application/json","Expected JSON.");
            Order.Require(ebay!=null&&!String.IsNullOrEmpty(Settings.ebayToken),"eBay orders are not set up on this desk PC.");
            var body=Wire.Read<Dictionary<string,string>>(r.body);string pin=null;
            Order.Require(body!=null&&body.TryGetValue("pin",out pin)&&System.Text.RegularExpressions.Regex.IsMatch(pin??"",@"^\d{6}$"),"Type the 6-digit PIN shown on Tommy's desk PC.");
            Order.Require(Pairing.Active,"Pairing is not open on the desk PC. Click Pair eBay PC there first; its PIN works for "+EbayPairing.Minutes+" minutes.");
            if(!Pairing.Try(pin))return HttpOutput.Json(new{error=Pairing.Active?"Wrong PIN. Check the number on the desk PC.":"Wrong PIN. Pairing is closed now: click Pair eBay PC on the desk PC again."},403);
            var hook=EbayPaired;if(hook!=null){try{hook("paired");}catch(Exception){}}
            return HttpOutput.Json(new{ok=true,key=Settings.ebayToken,receiver=Settings.Origin});
        }
        static EbayStatus Waiting(EbayStatus s,string why) { if(s!=null&&s.status=="queued")s.waiting=why;return s; }
        HttpOutput EbayRoute(HttpInput r,string path) {
            const string prefix="/api/ebay/v1";
            Order.Require(ebay!=null,"eBay orders are not set up on this desk PC.");
            if(path==prefix+"/health"&&r.method=="GET") {
                bool connected=EbayConnected,on,ready;string detail;
                lock(workerGate){on=connected&&EbayAccepting;ready=on&&EbayAvailable;detail=EbayDetail;}
                return HttpOutput.Json(new{service="tempe-ebay",apiVersion=1,receiving=Receiving,helperConnected=connected,ebayOn=on,ready=ready,detail=detail??"",waiting=EbayWaiting,pendingCount=ebay.Waiting});
            }
            if(path==prefix+"/orders"&&r.method=="POST") {
                var order=Wire.Read<EbayOrder>(r.body);Order.Require(order!=null,"No eBay order was sent.");
                var existing=EbayOrder.IsNumber(order.orderNumber)?ebay.Get(order.orderNumber):null;
                // An order is taken while the RDP helper is offline too: it waits in the queue.
                Order.Require(existing!=null||Receiving,"Tommy's desk PC has stopped receiving. Try again later.");
                var status=ebay.Submit(order);
                if(existing==null){var hook=EbayIncoming;if(hook!=null){try{hook(order.orderNumber);}catch(Exception){}}}
                return HttpOutput.Json(Waiting(status,EbayWaiting));
            }
            if(path.StartsWith(prefix+"/orders/",StringComparison.Ordinal)) {
                string tail=path.Substring((prefix+"/orders/").Length);bool retry=tail.EndsWith("/retry",StringComparison.Ordinal);string number=retry?tail.Substring(0,tail.Length-6):tail;
                Order.Require(EbayOrder.IsNumber(number),"Unknown eBay order number.");
                if(retry&&r.method=="POST") {
                    var body=Wire.Read<Dictionary<string,string>>(r.body);string confirm;
                    Order.Require(body!=null&&body.TryGetValue("orderNumber",out confirm)&&confirm==number,"Retry order number mismatch.");
                    Order.Require(Receiving,"Tommy's desk PC has stopped receiving. Try again later.");
                    return HttpOutput.Json(Waiting(ebay.Retry(number),EbayWaiting));
                }
                if(!retry&&r.method=="GET"){var s=ebay.Get(number);return s==null?HttpOutput.Json(new{error="Unknown eBay order"},404):HttpOutput.Json(Waiting(s,EbayWaiting));}
            }
            return HttpOutput.Json(new{error="Route not found"},404);
        }
        // The RDP helper's eBay side asks for work (its own long-poll, like the mobile one).
        HttpOutput EbayWorkerPoll(HttpInput r) {
            Order.Require(r.method=="POST","Method not allowed.");
            Order.Require(ebay!=null,"eBay orders are not set up on this desk PC.");
            var hello=Wire.Read<EbayHello>(r.body);Order.Require(hello!=null&&hello.workerId==Settings.workerId,"Wrong paired worker.");
            // Words are cleaned, never refused: a refused report would be sent again forever.
            hello.detail=EbayText.Clean(hello.detail,400);hello.declineReason=EbayText.Clean(hello.declineReason,400);
            if(hello.report!=null){hello.report.message=EbayText.Clean(hello.report.message,2000);hello.report.progress=EbayText.Clean(hello.report.progress,1000);}
            hello.accepting=hello.accepting&&Receiving;
            lock(workerGate){LastEbayWorker=DateTime.UtcNow;EbayAccepting=hello.accepting;EbayAvailable=hello.available;EbayDetail=hello.detail??"";}
            int v;lock(ebayPulse)v=ebayVersion;
            var reply=ebay.Poll(hello);
            int after;lock(ebayPulse)after=ebayVersion;
            int waitMs=Math.Min(Math.Max(hello.waitMs,0),20000);
            if(waitMs>0&&reply.command=="wait"&&hello.accepting&&after<=v+1) {
                var clock=System.Diagnostics.Stopwatch.StartNew();bool alive=true;
                lock(ebayPulse) {
                    while(ebayVersion<=after&&clock.ElapsedMilliseconds<waitMs) {
                        Monitor.Wait(ebayPulse,(int)Math.Max(1,Math.Min(500,waitMs-clock.ElapsedMilliseconds)));
                        if(r.alive!=null&&!r.alive()){alive=false;break;}
                    }
                }
                if(!alive)return HttpOutput.Json(new EbayReply {command="wait",held=true,ack=reply.ack,waitedMs=(int)clock.ElapsedMilliseconds});
                lock(workerGate){hello.accepting=hello.accepting&&EbayAccepting&&Receiving;}
                hello.report=null;var again=ebay.Poll(hello);
                again.held=true;again.waitedMs=(int)clock.ElapsedMilliseconds;again.ack=reply.ack;reply=again;
                lock(workerGate){LastEbayWorker=DateTime.UtcNow;}
            }
            return HttpOutput.Json(reply);
        }
        HttpOutput Static(string path,string method) {
            if(method!="GET")return HttpOutput.Json(new{error="Method not allowed"},405);
            string relative=Uri.UnescapeDataString(path).TrimStart('/');if(relative=="")relative="Fitment_Planner.html";
            string root=Path.GetFullPath(website)+Path.DirectorySeparatorChar;string file=Path.GetFullPath(Path.Combine(root,relative.Replace('/',Path.DirectorySeparatorChar)));
            if(!file.StartsWith(root,StringComparison.OrdinalIgnoreCase)||!File.Exists(file))return HttpOutput.Json(new{error="File not found"},404);
            string ext=Path.GetExtension(file).ToLowerInvariant();string type;
            switch(ext){case ".html":type="text/html; charset=utf-8";break;case ".js":type="application/javascript; charset=utf-8";break;case ".css":type="text/css; charset=utf-8";break;case ".png":type="image/png";break;case ".jpg":case ".jpeg":type="image/jpeg";break;case ".svg":type="image/svg+xml";break;case ".ico":type="image/x-icon";break;default:return HttpOutput.Json(new{error="File type not served"},404);}
            for(string check=file;check!=null&&check.StartsWith(root,StringComparison.OrdinalIgnoreCase);check=Path.GetDirectoryName(check))if((File.GetAttributes(check)&FileAttributes.ReparsePoint)!=0)return HttpOutput.Json(new{error="Linked files are not served"},404);
            Order.Require(new FileInfo(file).Length<=10000000,"Website file too large.");return new HttpOutput {type=type,bytes=File.ReadAllBytes(file)};
        }
    }
}
