using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace TempeCostar {
    // 2.4.0: one data folder, %LOCALAPPDATA%\TempeMobileCostar, with everything the helper writes:
    //   worker\, desk\      settings and queue/journal (DPAPI; unchanged)
    //   packages\           installed versions (auto-update) and current.txt
    //   runtime\<id>\       compiled builds (Build.ps1)
    //   reports\            per-run entry reports (customer details; 30 days)  <- was TempeCostarAutofill\Reports
    //   diagnostics\        masked run files and day logs (180 days)          <- was TempeCostarAutofill\Diagnostics
    //   Tempe-COSTAR-Diagnostics-*.zip  saved by the Save diagnostics button (30 days)
    //   startup-*.txt       Build.ps1 startup logs
    //   settings.json       plain settings (no secrets): see AppSettings
    // Older folders are moved here once (same drive, instant); if the move fails they stay in use.
    internal static class AppData {
        internal static string Home { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TempeMobileCostar"); } }
        static string Legacy { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TempeCostarAutofill"); } }
        static string reports,diagnostics;static readonly object gate=new object();
        internal static string Reports { get { lock(gate) return reports??(reports=Locate("Reports","reports")); } }
        internal static string Diagnostics { get { lock(gate) return diagnostics??(diagnostics=Locate("Diagnostics","diagnostics")); } }
        internal static string Packages { get { return Path.Combine(Home,"packages"); } }
        internal static string Runtime { get { return Path.Combine(Home,"runtime"); } }
        // The new place if it exists or the old one can be moved there; otherwise the old place.
        static string Locate(string oldName,string newName) {
            string target=Path.Combine(Home,newName),old=Path.Combine(Legacy,oldName);
            try {
                if(Directory.Exists(target)) return target;
                if(Directory.Exists(old)) {
                    Directory.CreateDirectory(Home);
                    try { Directory.Move(old,target); return target; }
                    catch(IOException) { return old; }
                    catch(UnauthorizedAccessException) { return old; }
                }
                Directory.CreateDirectory(target);
                return target;
            } catch(Exception) { return Directory.Exists(old)?old:target; }
        }
        internal static string Bytes(long n) {
            if(n>=1024L*1024*1024) return (n/(1024.0*1024*1024)).ToString("0.0",CultureInfo.InvariantCulture)+" GB";
            if(n>=1024*1024) return (n/(1024.0*1024)).ToString("0.0",CultureInfo.InvariantCulture)+" MB";
            if(n>=1024) return (n/1024.0).ToString("0",CultureInfo.InvariantCulture)+" KB";
            return n+" B";
        }
    }

    // One row of the Files tab: a folder, how many items it holds, their size and age.
    internal sealed class FolderStat {
        internal string Name,Path,Note;internal int Items;internal long Size;internal DateTime Oldest=DateTime.MaxValue,Newest=DateTime.MinValue;
        internal string Age { get { return Items==0?"-":Oldest==Newest?Oldest.ToString("d MMM",CultureInfo.InvariantCulture):Oldest.ToString("d MMM",CultureInfo.InvariantCulture)+" - "+Newest.ToString("d MMM",CultureInfo.InvariantCulture); } }
    }
    internal static class FolderStats {
        // topLevelOnly: each file and each subfolder counts as one item. filesOnly: the files in
        // the folder itself (its subfolders are rows of their own).
        internal static FolderStat Of(string name,string path,string note,bool topLevelOnly,bool filesOnly=false) {
            var s=new FolderStat { Name=name,Path=path,Note=note };
            try {
                var d=new DirectoryInfo(path);
                if(!d.Exists) return s;
                if(filesOnly) { foreach(var f in d.GetFiles()) Count(s,f.Length,f.LastWriteTime); }
                else if(topLevelOnly) {
                    foreach(var f in d.GetFiles()) Count(s,f.Length,f.LastWriteTime);
                    foreach(var sub in d.GetDirectories()) { long size=0;DateTime newest=DateTime.MinValue;Walk(sub,ref size,ref newest);Count(s,size,newest==DateTime.MinValue?sub.LastWriteTime:newest); }
                } else foreach(var f in d.GetFiles("*",SearchOption.AllDirectories)) Count(s,f.Length,f.LastWriteTime);
            } catch(Exception) { }
            return s;
        }
        static void Walk(DirectoryInfo d,ref long size,ref DateTime newest) {
            try { foreach(var f in d.GetFiles("*",SearchOption.AllDirectories)) { size+=f.Length;if(f.LastWriteTime>newest) newest=f.LastWriteTime; } } catch(Exception) { }
        }
        static void Count(FolderStat s,long size,DateTime when) {
            s.Items++;s.Size+=size;
            if(when<s.Oldest) s.Oldest=when;
            if(when>s.Newest) s.Newest=when;
        }
    }

    // Housekeeping beyond the 30-day report retention (2.4.0). Never touches the folder this
    // helper runs from, the package current.txt points to, settings, queue or journal files.
    internal static class Cleanup {
        internal sealed class Plan { internal readonly List<string> Folders=new List<string>(),Files=new List<string>();internal long Bytes;internal List<string> Kept=new List<string>(); }
        // Installed versions: keep the one current.txt names, the one running, and the newest other one.
        internal static Plan Packages(string packagesRoot,string running,string currentPointer) {
            var plan=new Plan();
            try {
                var d=new DirectoryInfo(packagesRoot);
                if(!d.Exists) return plan;
                var folders=d.GetDirectories("Tempe-COSTAR-Helper-v*").Select(x=>new { Dir=x,Version=Updater.Parse(x.Name.Substring("Tempe-COSTAR-Helper-v".Length)) }).OrderByDescending(x=>x.Version).ToList();
                var keep=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                if(!String.IsNullOrEmpty(currentPointer)) keep.Add(currentPointer.TrimEnd('\\'));
                if(!String.IsNullOrEmpty(running)) keep.Add(running.TrimEnd('\\'));
                foreach(var f in folders) { if(!keep.Contains(f.Dir.FullName.TrimEnd('\\'))) { keep.Add(f.Dir.FullName.TrimEnd('\\')); break; } }
                foreach(var f in folders) {
                    if(keep.Contains(f.Dir.FullName.TrimEnd('\\'))) { plan.Kept.Add(f.Dir.Name); continue; }
                    plan.Folders.Add(f.Dir.FullName);plan.Bytes+=Size(f.Dir);
                }
                // A download still being checked (Updater.Install) is left alone for ten minutes.
                foreach(var x in d.GetDirectories("incoming-*")) if(DateTime.UtcNow-x.LastWriteTimeUtc>TimeSpan.FromMinutes(10)) { plan.Folders.Add(x.FullName);plan.Bytes+=Size(x); }
            } catch(Exception) { }
            return plan;
        }
        // Compiled builds: keep the one running and the two newest others.
        internal static Plan Runtimes(string runtimeRoot,string runningBin) {
            var plan=new Plan();
            try {
                var d=new DirectoryInfo(runtimeRoot);
                if(!d.Exists) return plan;
                string runningRoot=String.IsNullOrEmpty(runningBin)?"":Path.GetFullPath(Path.Combine(runningBin,"..")).TrimEnd('\\');
                var folders=d.GetDirectories().OrderByDescending(x=>x.LastWriteTimeUtc).ToList();int kept=0;
                foreach(var f in folders) {
                    bool running=String.Equals(f.FullName.TrimEnd('\\'),runningRoot,StringComparison.OrdinalIgnoreCase);
                    if(running || kept<2) { kept++;plan.Kept.Add(f.Name);continue; }
                    plan.Folders.Add(f.FullName);plan.Bytes+=Size(f);
                }
            } catch(Exception) { }
            return plan;
        }
        // Startup logs: keep the 20 newest. Diagnostics ZIPs older than `zipDays` days.
        internal static Plan Logs(string home,int zipDays) {
            var plan=new Plan();
            try {
                var d=new DirectoryInfo(home);
                if(!d.Exists) return plan;
                foreach(var f in d.GetFiles("startup-*.txt").OrderByDescending(x=>x.LastWriteTimeUtc).Skip(20)) { plan.Files.Add(f.FullName);plan.Bytes+=f.Length; }
                DateTime cutoff=DateTime.UtcNow.AddDays(-zipDays);
                foreach(var f in d.GetFiles("Tempe-COSTAR-Diagnostics-*.zip")) if(f.LastWriteTimeUtc<cutoff) { plan.Files.Add(f.FullName);plan.Bytes+=f.Length; }
            } catch(Exception) { }
            return plan;
        }
        internal static int Apply(Plan plan,out long freed) {
            int removed=0;freed=0;
            foreach(var f in plan.Files) { try { long n=new FileInfo(f).Length;File.Delete(f);removed++;freed+=n; } catch(Exception) { } }
            foreach(var f in plan.Folders) { try { long n=Size(new DirectoryInfo(f));Directory.Delete(f,true);removed++;freed+=n; } catch(Exception) { } }
            return removed;
        }
        static long Size(DirectoryInfo d) { try { return d.GetFiles("*",SearchOption.AllDirectories).Sum(f=>f.Length); } catch(Exception) { return 0; } }
    }

    // Plain settings shared by the RDP helper's tabs (2.4.0). No secrets here; those stay in the
    // DPAPI files. Older flag files are read once and then replaced by settings.json.
    public sealed class AppSettings {
        public bool detFirst=true,orderCheck=false,longPoll=true;
        public int preferredBranch;
        // 2.5.0: eBay orders on (taken from the desk and entered by themselves) and their branch.
        public bool ebayOn=false;
        public int ebayBranch=1;
        // 2.5.2 (Tommy, 26 Oct): close each eBay Repair Order once it is in (not when something needs checking by hand).
        public bool ebayClose=true;
        public string lastSeenVersion="";
        static readonly object gate=new object();
        static AppSettings current;
        static string File_ { get { return Path.Combine(AppData.Home,"settings.json"); } }
        internal static AppSettings Current {
            get {
                lock(gate) {
                    if(current!=null) return current;
                    AppSettings s=null;
                    try { if(File.Exists(File_)) s=Wire.Read<AppSettings>(File.ReadAllText(File_,Encoding.UTF8)); } catch(Exception) { s=null; }
                    if(s==null) { s=new AppSettings();Migrate(s); }
                    current=s;return s;
                }
            }
        }
        // Flag files of 2.0.2-2.3.2: order-check-on, det-last, preferred-branch.txt.
        static void Migrate(AppSettings s) {
            try {
                string home=PrivateFiles.Home;
                s.orderCheck=File.Exists(Path.Combine(home,"order-check-on"));
                s.detFirst=!File.Exists(Path.Combine(home,"det-last"));
                string branch=Path.Combine(home,"preferred-branch.txt");int n;
                if(File.Exists(branch) && Int32.TryParse(File.ReadAllText(branch).Trim(),out n) && n>0) s.preferredBranch=n;
                s.Save();
            } catch(Exception) { }
        }
        internal void Save() {
            lock(gate) {
                try { Directory.CreateDirectory(AppData.Home);File.WriteAllText(File_,Wire.Json(this),new UTF8Encoding(false)); } catch(Exception) { }
                // Keep the old flags in step for a helper that is started from an older package.
                try {
                    string home=PrivateFiles.Home;
                    string detLast=Path.Combine(home,"det-last"),orderOn=Path.Combine(home,"order-check-on");
                    if(detFirst) { if(File.Exists(detLast)) File.Delete(detLast); } else if(!File.Exists(detLast)) File.WriteAllText(detLast,"DET after the items");
                    if(orderCheck) { if(!File.Exists(orderOn)) File.WriteAllText(orderOn,"on"); } else if(File.Exists(orderOn)) File.Delete(orderOn);
                    if(preferredBranch>0) File.WriteAllText(Path.Combine(home,"preferred-branch.txt"),preferredBranch.ToString(CultureInfo.InvariantCulture));
                } catch(Exception) { }
            }
        }
    }
}
