// The Online orders tab (AutofillForm): loads orders from the clipboard, the queue, the store
// check, and starts each entry in its own Repair Order.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace TempeCostar {
    public sealed class AutofillForm : Form {
        const string Prefix="TEMPE_COSTAR_ORDER_V1\n";
        readonly JavaScriptSerializer json=new JavaScriptSerializer { MaxJsonLength=200000 };
        
        readonly TextBox preview=new TextBox { Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Vertical,Width=770,Height=190,Font=Ui.Base,BackColor=Ui.Surface,BorderStyle=BorderStyle.FixedSingle };
        readonly TextBox payment=new TextBox { Width=155,MaxLength=60,Font=Ui.Base };
        readonly CheckBox fitting=Ui.Check("Include fitting / balancing / disposal note",true);
        // 2.3.2: pickups get DET on line 6 and the items above it (2.3.0's layout, the default), or,
        // unticked, the items first and DET after them, as before 2.3.0. Remembered between starts.
        readonly CheckBox detFirst=Ui.Check("DET first (items above DET)",true);
        readonly CheckBox receive=Ui.Check("Auto-load copied orders (this tab only)",false);
        readonly CheckBox autoFill=Ui.Check("Fill automatically",false);
        readonly OrderQueue queue=new OrderQueue();
        readonly Button fill=Ui.PrimaryButton("Fill Repair Order",220);
        readonly Button stop=Ui.DangerButton("Stop",110);
        readonly Button load=Ui.SecondaryButton("Load copied order",170);
        readonly RichTextBox status=Ui.Log();
        readonly Label queueLine=Ui.Hint("",770);string lastFinished="";
        // 2.4.0: the clipboard is checked 4x a second while this tab is idle (the sequence number
        // is a cheap call), so a sent order starts sooner; once a second while busy.
        readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer { Interval=250 };
        readonly BoundedLog messages=new BoundedLog();
        readonly EntryCoordinator coordinator;
        Order order;volatile Runner runner;volatile bool stopRequested;uint clipboardSequence;bool busy,activeTab,queuePaused;string lastReport,currentId;DateTime shownAt;
        // The Repair Order the last successful fill used (left open for review).
        volatile IntPtr lastFilledWindow;
        // Orders that stopped after typing something, and the Repair Order they were in: a
        // retry goes back there and continues instead of starting another Repair Order.
        readonly Dictionary<string,IntPtr> stoppedIn=new Dictionary<string,IntPtr>(StringComparer.OrdinalIgnoreCase);
        // What each of those Repair Orders held when the order stopped (2.3.1; null if unreadable then).
        readonly Dictionary<string,string> stoppedPrints=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
        internal bool Busy {get{return busy;}}
        // 2.5.0: why eBay orders should wait for this tab, or null. Only typing, a branch question, or
        // automatic filling that will start by itself (this tab showing, Fill automatically on) count:
        // an order merely loaded for a manual Fill, or a paused line, doesn't hold eBay orders up.
        // Read from the eBay thread: fields only, each read once.
        internal string PendingReason {
            get {
                if(busy) return "an online order is being entered"+(currentId==null?"":" ("+currentId+")");
                if(askingBranch) return "the Online orders tab is asking which COSTAR an order goes to";
                if(!activeTab||!receive.Checked||!autoFill.Checked) return null;
                var loaded=order;
                if(startWhenFree&&loaded!=null) return "online order "+loaded.orderId+" starts as soon as COSTAR is free";
                // The line only starts by itself when no order is loaded (see ClipboardTick).
                int waiting=queue.Count;
                if(!queuePaused&&loaded==null&&waiting>0) return waiting+" online order(s) waiting to be filled automatically";
                return null;
            }
        }
        // 2.5.0: an automatic fill that found COSTAR busy (an eBay order typing) starts once it is free.
        bool startWhenFree;
        // Set by the worker window: finds and selects a COSTAR if none is chosen.
        internal Func<bool> EnsureTarget;
        internal void StopEntry(){if(busy)AppLog.Note("stop_pressed","online "+currentId);stopRequested=true;var active=runner;if(active!=null)active.Cancel=true;}
        internal void SetActive(bool active){activeTab=active;UpdateReceiving();}
        void UpdateReceiving(){timer.Interval=busy?1000:250;timer.Enabled=activeTab&&receive.Checked&&(!busy||autoFill.Checked);UpdateQueueLine();}
        void UpdateQueueLine(){
            string text=busy?"Entering "+(currentId??"")+" ...":queue.Count>0?queue.Count+" order(s) waiting"+(queuePaused?" - click Fill Repair Order to continue":""):order!=null?order.orderId+" loaded. Click Fill Repair Order.":lastFinished.Length>0?lastFinished+"  ·  waiting for the next order":"No order loaded.";
            if(queueLine.Text!=text)queueLine.Text=text;
            // The last order's details stay readable but greyed once it is done.
            Color want=order!=null||busy?Ui.Ink:Ui.Muted;if(preview.ForeColor!=want)preview.ForeColor=want;
        }
        internal void FlushLog(){Ui.AppendColoured(status,messages.Drain());UpdateQueueLine();}
        // One line for the window's header (2.4.0).
        internal string StateLine {
            get {
                if(busy) return "Online: filling "+(currentId??"an order");
                int waiting=queue.Count;
                return "Online: "+(autoFill.Checked?"fill automatically on":receive.Checked?"auto-load on":"manual")+(waiting>0?", "+waiting+" waiting"+(queuePaused?" (paused)":""):order!=null?", "+order.orderId+" loaded":"");
            }
        }
        Form Host {get{return Parent==null?this:Parent.FindForm();}}
        // Online pickups name their store ("Tempe NSW"). Before anything is typed, that store must
        // belong to the selected COSTAR's branch, or a person confirms (remembered for this session
        // per store and branch). Deliveries and orders from older pages (no store) are not checked.
        readonly HashSet<string> confirmedStores=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        // True while that question is open. A WinForms timer still ticks under a message box, so
        // nothing is loaded from the clipboard and no entry starts until it is answered.
        bool askingBranch;
        void CheckStoreBranch(Order o,CostarInstance target) {
            if(o==null || o.IsDelivery || String.IsNullOrWhiteSpace(o.store) || target==null) return;
            if(Branches.StoreMatches(o.store,target.BranchName)) return;
            string key=Order.Norm(o.store)+"|"+target.Branch.ToString(CultureInfo.InvariantCulture);
            if(confirmedStores.Contains(key)) return;
            CostarInstance other=null;
            try { other=CostarWindows.Choices().FirstOrDefault(c=>!c.Same(target) && !OrderCheckLink.IsWipWindow(c) && Branches.StoreMatches(o.store,c.BranchName)); }
            catch(Exception) { other=null; }
            string store=Order.Clean(o.store);
            string text=o.orderId+" is a pickup at "+store+", but the selected COSTAR is "+target.Label+"."+
                (other!=null?"\r\n\r\n"+other.Label+" is also open: choose it in the list at the top to enter the order there.":"")+
                "\r\n\r\nEnter it into "+target.Label+" anyway?";
            // After an earlier order the helper may be minimised: bring it back so the question is seen.
            Form owner=Host;
            if(owner==null) owner=this;
            try { if(owner.WindowState==FormWindowState.Minimized) owner.WindowState=FormWindowState.Normal; owner.Activate(); } catch(Exception) { }
            AppLog.Note("online_branch_question",o.orderId+" store="+store+" branch="+target.Branch);
            DialogResult answer;
            askingBranch=true;
            try { answer=MessageBox.Show(owner,text,"Check the branch",MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2); }
            finally { askingBranch=false; }
            if(answer!=DialogResult.Yes) {
                AppLog.Note("online_branch_refused",o.orderId+" store="+store+" branch="+target.Branch);
                throw new InvalidOperationException("Not entered: "+o.orderId+" is a "+store+" pickup and the selected COSTAR is "+target.Label+". Choose the right COSTAR at the top, then click Fill.");
            }
            confirmedStores.Add(key);
            AppLog.Note("online_branch_confirmed",o.orderId+" store="+store+" branch="+target.Branch);
        }
        internal const string Version="2.5.2 - eBay RO closes";
        internal AutofillForm(EntryCoordinator entries) {
            coordinator=entries;
            Text="COSTAR Autofill - " + Version; ClientSize=new Size(840,740); StartPosition=FormStartPosition.CenterScreen; Font=Ui.Base; BackColor=Ui.Canvas;
            // 2.4.0 layout: order card (load, preview, options), actions, then the log filling the rest.
            var layout=new TableLayoutPanel { Dock=DockStyle.Fill,ColumnCount=1,RowCount=4,Padding=new Padding(12),BackColor=Ui.Canvas };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Controls.Add(layout);
            var card=Ui.Card();card.Dock=DockStyle.Top;
            var lines=new FlowLayoutPanel { FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Surface };
            lines.Controls.Add(Ui.Title("Online orders from the Tempe Orders page"));
            var transfer=Ui.Row(44);transfer.Controls.Add(load);transfer.Controls.Add(receive);transfer.Controls.Add(autoFill);lines.Controls.Add(transfer);
            lines.Controls.Add(preview);lines.Controls.Add(queueLine);
            var options=Ui.Row(40);options.Controls.Add(new Label { Text="Paying by (optional):",AutoSize=true,Font=Ui.Base,ForeColor=Ui.Ink,Padding=new Padding(0,8,6,0) });options.Controls.Add(payment);options.Controls.Add(fitting);options.Controls.Add(detFirst);lines.Controls.Add(options);
            lines.Controls.Add(Ui.Hint("Phone first · keep COSTAR account/name · update supplied address · Fill opens a fresh Repair Order in the selected COSTAR's branch; orders left open for review are not touched. DET first unticked = the old way (items first, then DET and its notes).",770));
            card.Controls.Add(lines);
            detFirst.Checked=AppSettings.Current.detFirst;
            detFirst.CheckedChanged+=delegate {
                AppSettings.Current.detFirst=detFirst.Checked;AppSettings.Current.Save();
                AppLog.Note("det_first",detFirst.Checked?"on":"off");
                Append(detFirst.Checked?"DET first: pickups get DET on line 6 and their items above it.":"DET first is off: pickups get their items first, then DET and its notes (the old way).");FlushLog();
            };
            var actions=Ui.Row();actions.Margin=new Padding(0,10,0,6);actions.Controls.Add(fill);actions.Controls.Add(stop);
            fill.Enabled=false;stop.Enabled=false;
            layout.Controls.Add(card,0,0);layout.Controls.Add(actions,0,1);layout.Controls.Add(status,0,2);
            layout.Controls.Add(Ui.Hint("During entry leave COSTAR in front. Stop shortcut: Ctrl + Alt + F10. After a stop, finish that Repair Order by hand, then click Fill Repair Order for the next one.",770),0,3);
            load.Click+=delegate { LoadClipboard(true); };
            fill.Click+=delegate { StartEntry(); };stop.Click+=delegate { StopEntry(); };
            receive.CheckedChanged+=delegate{clipboardSequence=Native.GetClipboardSequenceNumber();if(!receive.Checked&&autoFill.Checked)autoFill.Checked=false;UpdateReceiving();};
            autoFill.CheckedChanged+=delegate{
                if(autoFill.Checked){if(!receive.Checked)receive.Checked=true;queuePaused=false;Append("Fill automatically is on: each order you send with Send to COSTAR is entered straight away, one at a time, in its own new Repair Order. The same order is never entered twice.");}
                UpdateReceiving();FlushLog();
            };
            timer.Tick+=delegate { ClipboardTick(); };
            FormClosing+=delegate(object sender,FormClosingEventArgs e) { if(busy) { StopEntry(); e.Cancel=true; Append("Stopping entry. Close the helper again after it stops."); } };
            Shown+=delegate {Append("Send an order from your website, click Load copied order, then Fill Repair Order. Or tick Fill automatically and just click Send to COSTAR.");};
        }
        protected override void Dispose(bool disposing){if(disposing)timer.Dispose();base.Dispose(disposing);}
        void Append(string text) {messages.Add(text);}
        // Reads one order from the clipboard; null if it holds no valid COSTAR order.
        Order ParseClipboard(bool manual) {
            clipboardSequence=Native.GetClipboardSequenceNumber();
            string copied=OrderClipboard.Read(Handle);
            if(copied==null) { if(manual) Append("No order text found. Click Send to COSTAR in the HTML helper.");return null; }
            string text=copied.Replace("\r\n","\n");
            if(!text.StartsWith(Prefix,StringComparison.Ordinal)) { if(manual) Append("Clipboard does not contain a COSTAR order. Use the new Send to COSTAR button."); return null; }
            Order.Require(text.Length<=200000,"The order is too large.");
            var candidate=json.Deserialize<Order>(text.Substring(Prefix.Length)); Order.Require(candidate!=null,"Invalid order data."); candidate.Validate(true);
            return candidate;
        }
        void ShowOrder(Order loaded) {
            order=loaded;shownAt=DateTime.Now; var b=new StringBuilder();
                b.AppendLine(order.orderId+"  |  "+order.customer.name+"  |  $"+(order.totalCents/100m).ToString("0.00",CultureInfo.InvariantCulture));
                b.AppendLine(order.customer.phone+"  "+order.customer.email);
                b.AppendLine("Billing: "+order.customer.streetAddress+" "+order.customer.address2+", "+order.customer.suburb+" "+order.customer.state+" "+order.customer.postcode);
                fitting.Enabled=!order.IsDelivery;detFirst.Enabled=!order.IsDelivery;
                fitting.Text=order.IsDelivery?"In-store fitting note is not used for delivery orders":"Include fitting / balancing / disposal note";
                if(order.IsDelivery) {
                    var d=order.shipping;
                    b.AppendLine(order.deliveryMethod+" | Dispatch: "+order.deliveringBranch+" | Ship Via: "+d.shipVia);
                    b.AppendLine("Deliver to: "+d.name+", "+d.streetAddress+" "+d.address2+", "+d.suburb+" "+d.state+" "+d.postcode);
                    b.AppendLine("Contact: "+d.contact+" "+d.businessPhone+" | "+d.instructions);
                    b.AppendLine("Freight: $"+(order.freightCents/100m).ToString("0.00",CultureInfo.InvariantCulture)+" | Payment method: "+order.paymentMethod);
                    if(order.requiresReview) b.AppendLine("MANUAL COMPLETION: missing package tyres/quantities/pricing. COSTAR's item price will be kept; online package price will not be assigned to one wheel.");
                    b.AppendLine("Rego: "+order.rego);
                } else b.AppendLine("Pickup: "+order.pickupDate+" "+order.pickupTime+(String.IsNullOrWhiteSpace(order.store)?"":"  |  Store: "+order.store)+"  |  Rego: "+(String.IsNullOrWhiteSpace(order.rego)?"(not supplied)":order.rego));
                if(order.surchargeCents>0) b.AppendLine("Card surcharge: $"+(order.surchargeCents/100m).ToString("0.00",CultureInfo.InvariantCulture)+" handled automatically by COSTAR. Amount before surcharge: $"+(order.TotalBeforeSurchargeCents/100m).ToString("0.00",CultureInfo.InvariantCulture)+". No surcharge item will be added.");
                b.AppendLine("Vehicle: "+order.vehicle); b.AppendLine("Comment: "+order.comment); b.AppendLine();
                foreach(var l in order.ItemSteps(false).Select(step=>step.Line)) b.AppendLine(l.code+"  x"+l.quantity+(l.kind=="package"?"  ONLINE PACKAGE $":"  @ $")+(l.unitCents/100m).ToString("0.00",CultureInfo.InvariantCulture)+"  "+l.description);
                preview.Text=b.ToString();fill.Enabled=!busy;
        }
        // True when a new order was loaded and shown.
        bool LoadClipboard(bool manual) {
            if(busy) return false;
            try {
                var candidate=ParseClipboard(manual);
                if(candidate==null) return false;
                ShowOrder(candidate);
                AppLog.Note("online_loaded",candidate.orderId+(candidate.IsDelivery?" delivery":" pickup")+" lines="+(candidate.lines==null?0:candidate.lines.Count)+(manual?" manual":" auto")+(candidate.requiresReview?" package-review":""));
                if(queue.WasEntered(candidate.orderId)) Append("Received "+candidate.orderId+". It was already entered in this session: click Fill only if you really want a second copy.");
                else Append("Received "+candidate.orderId+". Click Fill Repair Order; a new Repair Order is opened for you.");
                return true;
            } catch(System.Runtime.InteropServices.ExternalException) { Append("Clipboard is busy. Click Load copied order again."); }
            catch(Exception e) { order=null;fill.Enabled=!busy&&queue.Count>0;preview.Clear();Append("Order was not loaded: "+e.Message);AppLog.Note("online_load_failed",e.Message); }
            finally{FlushLog();}
            return false;
        }
        // While an order is being entered, or after a stop, newly copied orders wait in line.
        void QueueFromClipboard() {
            try {
                var candidate=ParseClipboard(false);
                if(candidate==null) return;
                string result=queue.Add(candidate,currentId);
                AppLog.Note("online_queue_"+result,candidate.orderId+" waiting="+queue.Count);
                if(result=="queued") Append("Queued "+candidate.orderId+" ("+queue.Count+" waiting).");
                else if(result=="duplicate") Append(candidate.orderId+" is already waiting or being entered; not added twice.");
                else Append(candidate.orderId+" was already entered in this session; not added again.");
                if(!busy) fill.Enabled=order!=null||queue.Count>0;
            } catch(System.Runtime.InteropServices.ExternalException) { /* Clipboard busy; a later copy is picked up next time. */ }
            catch(Exception e) { Append("Copied order was not queued: "+e.Message);AppLog.Note("online_load_failed",e.Message); }
            finally{FlushLog();}
        }
        void ClipboardTick() {
            if(!activeTab || !receive.Checked || askingBranch) return;
            if(startWhenFree && !busy && order!=null && autoFill.Checked && !coordinator.Busy) { startWhenFree=false;StartEntry();return; }
            bool changed=Native.GetClipboardSequenceNumber()!=clipboardSequence;
            if(busy) { if(changed && autoFill.Checked) QueueFromClipboard(); return; }
            if(autoFill.Checked && (queuePaused || queue.Count>0)) {
                if(changed) QueueFromClipboard();
                if(!queuePaused && order==null && queue.Count>0) StartEntry();
                return;
            }
            if(!changed) return;
            if(LoadClipboard(false) && autoFill.Checked && order!=null) {
                if(queue.WasEntered(order.orderId)) { Append("Not filling "+order.orderId+" automatically: it was already entered in this session.");AppLog.Note("online_refused",order.orderId+" already entered");FlushLog();return; }
                StartEntry();
            }
        }
        void SetBusy(bool value) { busy=value;fill.Enabled=!value&&(order!=null||queue.Count>0);stop.Enabled=value;load.Enabled=!value;payment.Enabled=!value;fitting.Enabled=!value&&(order==null||!order.IsDelivery);detFirst.Enabled=!value&&(order==null||!order.IsDelivery);receive.Enabled=!value;UpdateReceiving(); }
        void StartEntry() {
            if(busy || askingBranch) return;
            if(order==null) { var next=queue.Next(); if(next==null) return; ShowOrder(next); }
            queuePaused=false;
            EntryLease entry=null;bool began=false;
            try {
                order.Validate(true);
                if(coordinator.Selected==null && EnsureTarget!=null) EnsureTarget();
                entry=coordinator.TryBegin("Online order",false);
                if(entry==null && coordinator.Selected!=null && autoFill.Checked) startWhenFree=true;
                Order.Require(entry!=null,coordinator.Selected==null?"Select a COSTAR in the list above.":"Wait for the current mobile, online or eBay entry to finish."+(startWhenFree?" This order starts by itself as soon as it is done.":""));
                var submitted=order;
                CheckStoreBranch(submitted,entry.Target);
                Order.Require(Object.ReferenceEquals(order,submitted),"The order on screen changed while the branch question was open. Nothing was entered; check it and click Fill again.");
                string pay=payment.Text;bool includeFitting=fitting.Checked,detFirstOn=detFirst.Checked;
                var lease=entry;stopRequested=false;lastReport=null;currentId=submitted.orderId;SetBusy(true);var host=Host;
                AppLog.Note("online_fill_start",submitted.orderId+(autoFill.Checked?" auto":" manual")+(submitted.IsDelivery?"":detFirstOn?" det-first":" det-last")+" waited "+(int)(DateTime.Now-shownAt).TotalSeconds+" s after loading, queue="+queue.Count);
                var fillClock=Stopwatch.StartNew();
                coordinator.Progress.Begin("Online order",submitted.orderId,4+(submitted.lines==null?0:submitted.lines.Count)+(submitted.IsDelivery?1:3));began=true;
                var thread=new Thread(delegate() {
                    bool success=false;string error=null;string[] checks=new string[0];
                    try {
                        using(var input=new CostarInputLock()) {
                            string orderCheck;string already=OrderCheckLink.AlreadyInCostar(submitted.orderId,out orderCheck);
                            CostarWindows.Main(lease.Target);
                            // A single open order of the selected branch is tried first: it may be
                            // empty, or already hold this customer. If it holds another job, or several
                            // are open, a fresh one is opened with Add New; earlier ones stay as they are.
                            var open=CostarWindows.Orders(lease.Target);
                            IntPtr window=open.Count==1&&Branches.OrderTitle(Native.Caption(open[0]),lease.Target.Branch)?open[0]:IntPtr.Zero;
                            IntPtr earlier;
                            lock(stoppedIn) { if(!stoppedIn.TryGetValue(submitted.orderId,out earlier)) earlier=IntPtr.Zero; }
                            bool ownOpen=earlier!=IntPtr.Zero && open.Contains(earlier) && Branches.OrderTitle(Native.Caption(earlier),lease.Target.Branch);
                            // 9 Oct: Order Check lists a Repair Order that is still open, so a stopped
                            // order's retry was refused as "already in COSTAR". When Order Check lists the
                            // order, the helper may only continue that order's own earlier attempt: the
                            // Repair Order it stopped in this session, still open, holding exactly what it
                            // held at the stop (checked in Run before anything is typed). Otherwise the
                            // refusal stands. A listed order is never entered afresh.
                            string duplicate=null;
                            if(already!=null) {
                                if(!ownOpen) { AppLog.Note("online_duplicate_blocked",submitted.orderId+": "+orderCheck); throw new InvalidOperationException(already); }
                                duplicate=already;window=earlier;
                                AppLog.Note("online_duplicate_check_open",submitted.orderId+": "+orderCheck+"; the Repair Order it stopped in is open");
                                Append("Order Check lists "+submitted.orderId+": that is the Repair Order the helper stopped in. It continues there only if nothing in it changed since.");
                            } else {
                                AppLog.Note("order_check",submitted.orderId+": "+orderCheck);
                                // 5 Oct: every order first tried the previous order's Repair Order
                                // (left open for review), found it full and only then opened a new one.
                                // The helper knows which order it filled last: go straight to Add New.
                                if(ownOpen) { window=earlier;Append("Going back to the Repair Order "+submitted.orderId+" was started in.");AppLog.Note("online_resume",submitted.orderId); }
                                else if(window!=IntPtr.Zero && window==lastFilledWindow) { window=IntPtr.Zero; AppLog.Note("online_skip_review_ro",submitted.orderId); }
                            }
                            bool reopened=duplicate!=null;
                            while(true) {
                                long openMs=-1;
                                if(window==IntPtr.Zero) {
                                    Append(open.Count==0?"Opening a new Repair Order with Add New.":"Earlier Repair Orders stay open for review; opening a fresh one with Add New.");
                                    var openTimer=Stopwatch.StartNew();
                                    window=CostarWindows.OpenNew(lease.Target,delegate{},delegate{return stopRequested;},true);
                                    openMs=openTimer.ElapsedMilliseconds;AppLog.Note("online_add_new",submitted.orderId+" "+openMs+" ms, other orders open="+open.Count);
                                }
                                runner=new Runner(lease.Target.Pid,lease.Target.Branch,submitted,pay,includeFitting,Append,window.ToInt64());
                                runner.OnStage=coordinator.Progress.Stage;
                                runner.FreshlyOpened=openMs>=0;if(openMs>=0)runner.Diag.OpenNewMs=openMs;runner.DetFirst=detFirstOn;
                                runner.MustResume=duplicate!=null;runner.DuplicateMessage=duplicate;
                                runner.OwnAttempt=ownOpen && window==earlier;
                                if(runner.OwnAttempt) lock(stoppedIn) { string print; runner.ResumePrint=stoppedPrints.TryGetValue(submitted.orderId,out print)?print:null; }
                                runner.Cancel=stopRequested;
                                try { runner.Run();success=true;lastFilledWindow=window;lock(stoppedIn){stoppedIn.Remove(submitted.orderId);stoppedPrints.Remove(submitted.orderId);}break; }
                                catch(RepairOrderInUseException) {
                                    if(duplicate!=null) throw new InvalidOperationException(duplicate);
                                    if(reopened) throw;
                                    reopened=true;var used=runner;runner=null;used.Dispose();
                                    Append("The open Repair Order already holds another job; it is left untouched.");AppLog.Note("online_ro_in_use",submitted.orderId);
                                    window=IntPtr.Zero;open=CostarWindows.Orders(lease.Target);
                                }
                                catch(Exception) {
                                    if(runner!=null && (runner.Writes>0 || runner.ResumeVerified)) lock(stoppedIn) { stoppedIn[submitted.orderId]=window; stoppedPrints[submitted.orderId]=runner.StopPrint; }
                                    throw;
                                }
                            }
                        }
                    } catch(Exception e){error=e.Message;}
                    finally {
                        try {var active=runner;if(active!=null){checks=active.Checks.ToArray();active.Dispose();lastReport=active.ZipPath;}}
                        catch(Exception e){error="Report cleanup failed: "+e.Message;}
                        finally {runner=null;lease.Dispose();}
                        coordinator.Progress.End(success,success?submitted.orderId+" ready for review":submitted.orderId+" stopped: "+(error??""));
                    }
                    try {BeginInvoke(new Action(delegate {
                        SetBusy(false);currentId=null;
                        if(success) queue.Entered(submitted.orderId);
                        string runFile=lastReport==null?"":Path.GetFileNameWithoutExtension(lastReport);
                        AppLog.Note(success?"online_fill_ok":"online_fill_stopped",submitted.orderId+" in "+(fillClock.ElapsedMilliseconds/1000)+" s run="+runFile+(success?"":" "+error));
                        order=null;fill.Enabled=queue.Count>0;
                        lastFinished=(success?"Finished ":"Stopped ")+submitted.orderId+(success&&checks.Length>0?" (check by hand)":"")+" at "+DateTime.Now.ToString("HH:mm");
                        Append(success?"Finished "+submitted.orderId+". Review it in COSTAR.":"Entry stopped: "+error);
                        if(success&&checks.Length>0)Append("CHECK BY HAND: "+String.Join(" ",checks));
                        if(success&&error!=null)Append(error);
                        if(lastReport!=null)Append("Report: "+lastReport);
                        if(success && autoFill.Checked && queue.Count>0) {
                            var next=queue.Next();ShowOrder(next);
                            Append("Next in line: "+next.orderId+(queue.Count>0?" ("+queue.Count+" more waiting).":"."));
                            FlushLog();StartEntry();return;
                        }
                        if(!success && queue.Count>0) {queuePaused=true;AppLog.Note("online_queue_paused",queue.Count+" waiting");Append("Automatic filling paused: "+queue.Count+" order(s) waiting. Check COSTAR, then click Fill Repair Order to continue with the next one.");}
                        if(!success && host!=null){host.WindowState=FormWindowState.Normal;host.Activate();}
                        FlushLog();
                    }));}catch(InvalidOperationException){}
                });
                thread.IsBackground=true;thread.SetApartmentState(ApartmentState.STA);
                if(host!=null)host.WindowState=FormWindowState.Minimized;
                thread.Start();
            } catch(Exception e) {
                if(entry!=null)entry.Dispose();SetBusy(false);currentId=null;var host=Host;if(host!=null)host.WindowState=FormWindowState.Normal;Append(e.Message);
                if(began)coordinator.Progress.End(false,e.Message);
                AppLog.Note("online_fill_refused",e.Message);
            }
        }
    }
}
