// The entry engine, part 3 of 4: the item grid (lines by count), DET and its notes, items,
// freight and memos.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed partial class Runner {
        ControlInfo BlankRow(List<ControlInfo> snapshot) {
            var g=Selectors.ProductGrid(snapshot); int bottom=g.Rows.Where(c=>c.Value.Length>0).Select(c=>c.Y).DefaultIfEmpty(-1).Max();
            var next=g.Rows.FirstOrDefault(c=>c.Y>bottom && c.Value.Length==0);
            Order.Require(next!=null,"No empty item row is visible. Entry stopped; check the order before continuing manually.");
            return next;
        }
        // Looking at COSTAR's item grid. A look only counts once the grid holds still: two looks in a
        // row with the same boxes, places and texts (COSTAR re-lays the grid out while it loads a
        // product or makes DET's notes). 2.3.2: lines are numbered by the order of the boxes
        // (Grid.Countable). 9 and 10 Oct, 2.3.0 and 2.3.1 stopped at the second item because they
        // numbered lines by their places, and COSTAR had opened the line just filled (focus still in
        // it), pushing every line below it ~140 px down. Odd shapes go to the diagnostics (no values).
        int shapesOk,shapesOdd;bool gridNoted;
        bool Counted(Grid g) {
            bool ok=g!=null && g.Countable();
            if(ok && !gridNoted && g.EvenLines) {
                gridNoted=true;
                Diag.SetEnv("gridLines",g.Rows.Count+" boxes, "+(g.Rows[1].Y-g.Rows[0].Y)+" px apart, line 1 "+(g.Rows[0].Y-g.Item.Y)+" px below the ITEM label");
            }
            return ok;
        }
        // A steady look at the grid, or null if it kept changing (at least 4 looks and 2.5 s; 10 s at
        // most, so time COSTAR spends busy doesn't use the looks up). counted: its lines can be
        // numbered. Wanting that, a steady look that can't be counted is returned only after 1.5 s.
        Grid SteadyGrid(string why,bool wantCounted,out List<ControlInfo> snapshot,out bool counted) {
            var wait=Diag.Wait("grid_lines");
            try {
                var timer=Stopwatch.StartNew();string previous=null;int looks=0;
                while(true) {
                    wait.Tick();Ready();var s=GridCurrent();looks++;Grid g=null;string signature=null;
                    try {
                        g=Selectors.ProductGrid(s);
                        signature=g.Item.Y.ToString(CultureInfo.InvariantCulture)+"|"+String.Join(";",g.Rows.Select(r=>r.Handle.ToString(CultureInfo.InvariantCulture)+"@"+r.Y.ToString(CultureInfo.InvariantCulture)+"="+r.Value).ToArray());
                    } catch(InvalidOperationException) { g=null;signature=null; }
                    if(g!=null && signature!=null && signature==previous) {
                        bool ok=Counted(g);
                        if(ok || !wantCounted || timer.ElapsedMilliseconds>=1500) {
                            if(!ok && wantCounted) NoteGridShape(g,why+": steady, but the lines can't be counted",true);
                            wait.Done(ok || !wantCounted?"ok":"steady-uncounted");snapshot=s;counted=ok;return g;
                        }
                    }
                    previous=signature;
                    if((looks>=4 && timer.ElapsedMilliseconds>=2500) || timer.ElapsedMilliseconds>=10000) {
                        if(g!=null) NoteGridShape(g,why+": still changing after "+looks+" looks",true);
                        wait.Done("changing");snapshot=s;counted=false;return null;
                    }
                    Pause(40);
                }
            } finally { wait.End(); }
        }
        // The order print once COSTAR holds still: two equal prints in a row from fully read looks
        // (a look taken while COSTAR was busy doesn't count). At least 3 tries; 15 s at most; else null.
        string SettledPrint() {
            var timer=Stopwatch.StartNew();string previous=null;int tries=0;
            while(timer.ElapsedMilliseconds<15000 && (tries<3 || timer.ElapsedMilliseconds<5000)) {
                if(!Native.IsWindow(root)) return null;
                tries++;string print;
                try {
                    var look=Snapshot(root);
                    print=lastSnapshotBusy || look.Any(c=>c.TextState=="busy" || c.TextState=="read-failed-or-timed-out")?null:Selectors.OrderPrint(look,order.IsDelivery);
                } catch(InvalidOperationException) { print=null; }
                if(print!=null && print==previous) return print;
                previous=print;Pause(150);
            }
            return null;
        }
        // Where COSTAR's item boxes are, no values: y offset/height from the first box, x and w when
        // different, #class when different, * filled, f focused, and the focused control if it is not
        // one of them. Two harmless and two problem shapes per run at most.
        void NoteGridShape(Grid g,string why,bool problem) {
            if(problem?shapesOdd>=2:shapesOk>=2) return;
            if(problem) shapesOdd++; else shapesOk++;
            try {
                long focus=Native.Focus(root).ToInt64();
                var b=new StringBuilder(why+" | "+g.Rows.Count+" boxes:");
                int top=g.Rows.Count>0?g.Rows[0].Y:0,x0=g.Rows.Count>0?g.Rows[0].X:0,w0=g.Rows.Count>0?g.Rows[0].W:0;
                string class0=g.Rows.Count>0?g.Rows[0].Class:"";
                foreach(var r in g.Rows) {
                    if(b.Length>430) { b.Append(" ..."); break; }
                    b.Append(' ').Append(r.Y-top).Append('/').Append(r.H);
                    if(r.X!=x0) b.Append('x').Append(r.X-x0);
                    if(r.W!=w0) b.Append('w').Append(r.W);
                    if(r.Class!=class0) b.Append('#').Append(r.Class.Length>14?r.Class.Substring(0,14):r.Class);
                    string peek=r.Peek;
                    if(!String.IsNullOrEmpty(peek) && peek.Trim().Length>0) b.Append('*'); else if(peek==null) b.Append('?');
                    if(r.Handle==focus) b.Append('f');
                }
                if(g.Item!=null) b.Append(" | ITEM label bottom y=").Append(g.Item.Y+g.Item.H).Append(", first box y=").Append(top).Append(", ").Append(Grid.CostarLines).Append(" lines expected");
                // Focus outside the boxes (an editor drawn over a line?): its class and place.
                Native.Rect fr,rr;var fh=new IntPtr(focus);
                if(focus!=0 && !g.Rows.Any(r=>r.Handle==focus) && Native.GetWindowRect(fh,out fr) && Native.GetWindowRect(root,out rr)) {
                    string fc=Native.Class(fh);
                    b.Append(" | focus ").Append(fc.Length>24?fc.Substring(0,24):fc).Append(" at ").Append(fr.Left-rr.Left).Append(',').Append(fr.Top-rr.Top).Append(' ').Append(fr.Right-fr.Left).Append('x').Append(fr.Bottom-fr.Top);
                }
                Diag.EventRaw("grid_shape",b.ToString());
            } catch(Exception) { }
        }
        // Choosing the line to type on (2.3.2). Each way returns the empty box and the boxes from line 1
        // down to it (Grid.LinesTo), which RequireLineStill checks again once the box has focus.
        //
        // The empty box on numbered line `line` (1-based); the lines must be countable.
        ControlInfo LineRow(int line,out string path) {
            List<ControlInfo> s;bool counted;
            var g=SteadyGrid("line "+line,true,out s,out counted);
            Order.Require(g!=null && counted && line<=g.Rows.Count,"COSTAR's item lines can't be counted right now, so line "+line+" can't be found safely. Entry stopped before typing.");
            var row=g.Rows[line-1];
            Order.Require(row.Value.Length==0,"Line "+line+" already holds "+row.Value+". Entry stopped; check the order.");
            path=g.LinesTo(row.Handle);return row;
        }
        // The first empty line after everything (notes, freight, deliveries, DET last), as before 2.3.0.
        ControlInfo NextEmptyRow(out string path) {
            List<ControlInfo> s;bool counted;
            var g=SteadyGrid("next empty line",false,out s,out counted);
            Order.Require(g!=null,"COSTAR's item grid kept changing, so the next empty line can't be chosen safely. Entry stopped; check the order.");
            var row=BlankRow(s);path=g.LinesTo(row.Handle);return row;
        }
        // The next item's line above DET: the line after the last filled one above DET (line 1 first).
        // The order of the boxes picks it, so a line drawn open or a box moved by COSTAR doesn't matter.
        // detLine: DET's line (when the lines can be counted, DET must still be on it), or -1 if not known.
        // Instead the first empty line after everything (as before 2.3.0) when nothing is free above
        // DET (an order an older helper started) or an item of this order is already below DET; once
        // used, the rest of the run's items follow it. DET missing or doubled stops entry.
        readonly HashSet<string> itemCodes=new HashSet<string>(StringComparer.Ordinal);bool itemsAfterNotes;
        ControlInfo ItemRowAbove(int detLine,out string path) {
            List<ControlInfo> s;bool counted;
            var g=SteadyGrid("items above DET",detLine>0,out s,out counted);
            Order.Require(g!=null,"COSTAR's item grid kept changing, so the next item line can't be chosen safely. Entry stopped; check the order.");
            var dets=g.Rows.Where(r=>Order.Norm(r.Value)=="DET").ToList();
            Order.Require(dets.Count==1,"DET is missing or doubled on this Repair Order. Entry stopped; check the order.");
            int d=g.Rows.IndexOf(dets[0]);
            if(counted && detLine>0) Order.Require(d==detLine-1,"DET is no longer on line "+detLine+". Entry stopped; check the order.");
            bool itemsBelow=g.Rows.Skip(d+1).Any(r=>itemCodes.Contains(Order.Norm(r.Value)));
            int free=itemsAfterNotes || itemsBelow?-1:g.NextFreeAbove(d);
            if(free>=0) { var row=g.Rows[free];path=g.LinesTo(row.Handle);return row; }
            if(!itemsAfterNotes) {
                itemsAfterNotes=true;
                Diag.EventRaw("items_after_det",itemsBelow?"an item is already below DET":"no free line above DET");
                Say(itemsBelow?"Items of this order are already below DET, so the rest go in after DET's notes.":"No free line is left above DET, so the remaining items go in after DET's notes.");
            }
            var next=BlankRow(s);path=g.LinesTo(next.Handle);return next;
        }
        // DET first (2.3.0) needs DET's line counted on the grid as it is now, and that line and every
        // line below it empty. If not, this order gets DET after its items (as before 2.3.0), logged.
        int DetFirstLine(int itemLines) {
            int line=Order.DetLine(itemLines);
            List<ControlInfo> s;bool counted;
            var g=SteadyGrid("DET's line",true,out s,out counted);
            string why=g==null?"COSTAR's item grid kept changing":!counted?"COSTAR's item lines can't be counted":
                line>g.Rows.Count?"there is no line "+line:g.Rows.Skip(line-1).Any(r=>r.Value.Length>0)?"line "+line+" or a line below it is already used":null;
            if(why==null) return line;
            Diag.EventRaw("det_last",why);
            Say("DET goes in after the items on this order ("+why+").");
            return 0;
        }
        // DET's three notes must be the filled lines directly under it, so the items can go above it
        // without mixing with them. Anything else stops entry. detLine: DET's line, checked when the
        // lines can be counted (0: wherever DET is).
        void RequireNotesUnderDet(int detLine) {
            List<ControlInfo> s;bool counted;
            var g=SteadyGrid("DET notes",detLine>0,out s,out counted);
            Order.Require(g!=null,"COSTAR's item grid kept changing, so DET's notes can't be checked. Entry stopped; check the order.");
            var filled=g.Rows.Where(r=>r.Value.Length>0).ToList();
            var dets=filled.Where(r=>Order.Norm(r.Value)=="DET").ToList();
            Order.Require(dets.Count==1,"DET is missing or doubled on this Repair Order. Entry stopped; check the order.");
            int at=g.LineOf(dets[0].Handle);
            if(counted && detLine>0) Order.Require(at==detLine,"DET is not on line "+detLine+". Entry stopped; check the order.");
            int d=filled.IndexOf(dets[0]);
            var under=new HashSet<long>(filled.Skip(d+1).Take(3).Select(r=>r.Handle));
            foreach(var note in new[]{new{Prefix="MAKE/MODEL",Code="M"},new{Prefix="REGO NO",Code="M"},new{Prefix="ODOMETER",Code="M ODO"}}) {
                var memo=Selectors.FindMemo(s,note.Prefix,note.Code);
                Order.Require(memo!=null && under.Contains(memo.Row.Handle),"COSTAR put DET's "+note.Prefix+" note "+(memo==null?"nowhere":"somewhere other than directly under DET")+". Entry stopped; check the order.");
            }
            Say(counted?"DET is on line "+at+" with its notes directly under it.":"DET's notes are directly under it.");
        }
        // 2.3.2: the chosen line, focused and about to be typed into, must still be the same box on the
        // same line, with the same boxes above it (Grid.LinesTo), and still empty. Not its place: the
        // click moves focus out of the line that had it, COSTAR closes that line and everything below it
        // moves up (10 Oct: 2.3.1 compared places and stopped right there).
        // Focus must still be on it then; if COSTAR took it back while closing the other line, the line
        // is clicked once more and checked again.
        void RequireLineStill(ControlInfo row,string path) {
            for(int attempt=1;;attempt++) {
                List<ControlInfo> s;bool counted;
                var g=SteadyGrid("chosen line",false,out s,out counted);
                Order.Require(g!=null,"COSTAR's item grid kept changing after the line was chosen. Entry stopped; check the order.");
                string now=g.LinesTo(row.Handle);
                if(now!=path) NoteGridShape(g,"chosen line "+Lines(path)+" is "+(now==null?"gone":"now line "+Lines(now)+(Lines(now)==Lines(path)?" with other boxes above it":"")),true);
                Order.Require(path!=null && now==path,"The chosen item line moved before typing. Entry stopped; check the order.");
                Order.Require(ReadLive(row).Length==0,"The chosen item line is no longer empty. Entry stopped; check the order.");
                if(Native.Focus(root).ToInt64()==row.Handle) return;
                Order.Require(attempt<2,"COSTAR did not keep focus on the chosen item line. Entry stopped; check the order.");
                Diag.EventRaw("line_focus_retry","focus left the chosen line before typing; clicking it again");
                Focus(row);
            }
        }
        static int Lines(string path) { return path==null?0:path.Split(',').Length; }
        ControlInfo Row(List<ControlInfo> snapshot,long handle,string code) {
            var r=Selectors.One(Selectors.ProductGrid(snapshot).Rows.Where(c=>c.Handle==handle),"current item row");
            Order.Require(Order.Norm(r.Value)==code,"COSTAR changed the current item code unexpectedly."); return r;
        }
        void LeaveGrid(string stage) {
            // Leaving the description commits COSTAR's generated notes. Waiting
            // inside DET can leave those rows hidden indefinitely. PO# is an
            // already-filled header field: focus it without changing its text.
            var wait=Diag.Wait("leave_grid");
            try {
            Ready();ControlInfo po=HeaderNow().PO;
            var budget=Stopwatch.StartNew();
            for(int attempt=1;attempt<=12 && budget.ElapsedMilliseconds<6000;attempt++) {
                if(attempt>1)Diag.EventRaw("leave_grid_retry","attempt "+attempt+" "+stage);
                Ready();Order.Require(ReadLive(po)==order.orderId,"The PO# changed before leaving the item editor.");
                TraceFocus("Leaving item editor " + stage + ", attempt " + attempt,po);
                if(Native.Focus(root).ToInt64()!=po.Handle) ClickTarget(po);
                // COSTAR can finish the item lookup after the click and pull focus back
                // into the grid. Accept PO# once COSTAR has been busy and settled with
                // focus still there, or after it has held focus for 300 ms. Otherwise
                // click again quickly instead of waiting out a long timeout.
                var timer=Stopwatch.StartNew();long heldSince=-1;idleWaitedMs=0;
                while(timer.ElapsedMilliseconds<700) {
                    wait.Tick();Ready();Order.Require(ReadLive(po)==order.orderId,"The PO# changed while leaving the item editor.");
                    bool onPo=Native.Focus(root).ToInt64()==po.Handle,settled=idleWaitedMs>=15;
                    if(onPo) {
                        if(heldSince<0)heldSince=timer.ElapsedMilliseconds;
                        if(settled || timer.ElapsedMilliseconds-heldSince>=300) {
                            CheckTarget(po); TraceFocus("Confirmed outside item editor " + stage,po);
                            Say("Left item editor " + stage + "; PO# unchanged."); wait.Done(attempt==1?"ok":"ok-attempt-"+attempt); return;
                        }
                    } else if(heldSince>=0 || (settled && timer.ElapsedMilliseconds>=120)) break; // Focus was pulled back, or COSTAR settled without taking the click.
                    Pause(20);
                }
            }
            TraceFocus("Could not leave item editor " + stage,po);wait.Done("failed");
            throw new InvalidOperationException("COSTAR did not leave the item editor " + stage + ".");
            } finally {wait.End();}
        }
        // DET: one click on PO# makes the DET description lose focus, and that is what
        // creates the MAKE/MODEL, REGO NO and ODOMETER notes. Once those notes exist the
        // click has done its job, wherever COSTAR then puts the cursor. 1.6.1 runs showed
        // 0.5-1.2 s spent winning focus back to PO# after the notes already existed.
        // Falls back to the full leave-grid routine if the notes do not appear.
        bool LeaveForDetNotes() {
            var wait=Diag.Wait("det_leave_once");
            try {
                Ready();ControlInfo po=HeaderNow().PO;
                Order.Require(ReadLive(po)==order.orderId,"The PO# changed before leaving the item editor.");
                if(Native.Focus(root).ToInt64()!=po.Handle) ClickTarget(po);
                var timer=Stopwatch.StartNew();string previous=null;int stable=0;
                while(timer.ElapsedMilliseconds<1500) {
                    wait.Tick();Ready();
                    try {
                        var s=GridCurrent();
                        var car=Selectors.FindMemo(s,"MAKE/MODEL","M");var rego=Selectors.FindMemo(s,"REGO NO","M");var odo=Selectors.FindMemo(s,"ODOMETER","M ODO");
                        if(car!=null && rego!=null && odo!=null) {
                            string signature=Selectors.MemoSignature(car)+"|"+Selectors.MemoSignature(rego)+"|"+Selectors.MemoSignature(odo);
                            stable=signature==previous?stable+1:1;previous=signature;
                            if(stable>=2) {
                                Order.Require(ReadLive(po)==order.orderId,"The PO# changed while leaving the item editor.");
                                Say("Left item editor after DET; notes created; PO# unchanged.");wait.Done("ok");return true;
                            }
                        } else { stable=0;previous=null; }
                    } catch(InvalidOperationException) { stable=0;previous=null; }
                    Pause(25);
                }
                wait.Done("fallback");return false;
            } finally {wait.End();}
        }
        // line: type on that line (1-based). above: the next free line above DET (items going in above
        // DET): DET's line, or -1 if it is not known. Neither: the first empty line after everything.
        long AddCode(string code,bool allowBlankDescription,bool priced=false,bool commitOutsideGrid=false,int line=0,int above=0) {
            code=Order.EntryText(code);
            Ready(); string path; var row=line>0?LineRow(line,out path):above!=0?ItemRowAbove(above,out path):NextEmptyRow(out path);
            Focus(row); RequireLineStill(row,path); WriteFocused(row,code,"item " + code,true);
            // DET reveals its generated note rows only once the description loses
            // focus, so leave the grid before waiting for them. First let COSTAR finish
            // looking up the code itself (the row's description fills in): a PO# click
            // made before that is undone when COSTAR moves focus back into the grid.
            if(commitOutsideGrid) {
                var lookup=Diag.Wait("det_lookup");
                try {
                    var settle=Stopwatch.StartNew();bool filled=false;
                    while(settle.ElapsedMilliseconds<1500) {
                        lookup.Tick();Ready();
                        try {
                            var s=GridCurrent();var r=Row(s,row.Handle,code);var d=Selectors.Cell(s,r,Selectors.ProductGrid(s).Description);
                            if(d.TextState=="read" && d.Value.Length>0) {filled=true;break;}
                        } catch(InvalidOperationException) { /* Row still loading. */ }
                        Pause(20);
                    }
                    lookup.Done(filled?"ok":"not-filled-continuing");
                } finally {lookup.End();}
                if(code!="DET" || !LeaveForDetNotes()) LeaveGrid("after " + code);
            }
            var wait=Diag.Wait(code=="DET"?"det_row_load":"item_load");
            try {
            var timer=Stopwatch.StartNew(); string previous=null; int stable=0;
            while(timer.ElapsedMilliseconds<15000) {
                wait.Tick();Ready(); var snapshot=GridCurrent();
                try {
                    var r=Row(snapshot,row.Handle,code); var grid=Selectors.ProductGrid(snapshot);
                    var description=Selectors.Cell(snapshot,r,grid.Description);
                    if(description.TextState=="read" && (allowBlankDescription || description.Value.Length>0)) {
                        string signature=description.Value + "|" + String.Join(";",grid.Rows.Where(x=>x.Value.Length>0).Select(x=>x.Value));
                        if(priced) signature += "|" + Selectors.Cell(snapshot,r,grid.Quantity).Value + "|" + Selectors.Cents(Selectors.Cell(snapshot,r,grid.Net));
                        if(signature==previous) stable++; else { previous=signature; stable=1; }
                        if(stable>=2) {wait.Done("ok");return row.Handle;}
                    } else { stable=0; previous=null; }
                } catch(InvalidOperationException) { stable=0; previous=null; }
                Pause(20);
            }
            wait.Done("timeout");
            throw new InvalidOperationException("COSTAR did not finish loading " + code + ".");
            } finally {wait.End();}
        }
        void AddLine(OrderLine line,int above=0) { FinishLine(line,AddCode(line.code,false,true,false,0,above)); }
        // The nth (0-based) item row holding this code, or 0 if there is none.
        long ExistingRow(string code,int nth) {
            var rows=Selectors.ProductGrid(GridCurrent()).Rows.Where(r=>Order.Norm(r.Value)==Order.Norm(code)).ToList();
            return rows.Count>nth?rows[nth].Handle:0;
        }
        // Description check, quantity and price for a row that holds this line's code. Safe to
        // run again on a row entered by an earlier, stopped attempt.
        void FinishLine(OrderLine line,long handle) {
            var s=GridCurrent(); var g=Selectors.ProductGrid(s); var r=Row(s,handle,line.code);
            string description=Order.Norm(Selectors.Cell(s,r,g.Description).Value);
            if(line.kind=="service") {
                bool front=description.Contains("FRONT"), rear=description.Contains("REAR"), alignment=description.Contains("ALIGNMENT");
                Order.Require(alignment && front && (line.code=="WA" ? !rear : rear),"The COSTAR alignment description does not match the online service.");
            }
            // Product SKU is the identifier; preserve COSTAR's own product description.
            if(PutQuantity(Selectors.Cell(s,r,g.Quantity),line.quantity,"quantity for " + line.code)) {
                Ready();s=GridCurrent();g=Selectors.ProductGrid(s);r=Row(s,handle,line.code);
            }
            var net=Selectors.Cell(s,r,g.Net);
            bool package=line.kind=="package";
            if(!package && Selectors.Cents(net)!=line.unitCents) Put(net,(line.unitCents/100m).ToString("0.00",CultureInfo.InvariantCulture),"price for " + line.code,true);
            Ready(); s=GridCurrent(); g=Selectors.ProductGrid(s); r=Row(s,handle,line.code);
            int actualPrice=Selectors.Cents(Selectors.Cell(s,r,g.Net));
            Order.Require(Selectors.Cell(s,r,g.Quantity).Value==line.quantity.ToString(CultureInfo.InvariantCulture) && (package || actualPrice==line.unitCents),"The quantity or price changed after COSTAR validated it.");
            if(package) {
                packagePrices[order.lines.IndexOf(line)]=actualPrice;
                Say("Package SKU " + line.code + " entered at COSTAR's current unit price $" + (actualPrice/100m).ToString("0.00",CultureInfo.InvariantCulture) + ". Missing tyre components, quantities and package pricing require manual completion.");
            } else Say("Verified item " + line.code + ".");
        }
        bool PutQuantity(ControlInfo field,int quantity,string label) {
            string expected=quantity.ToString(CultureInfo.InvariantCulture);
            if(ReadLive(field)==expected) { skippedQuantities++;return false; }
            Put(field,expected,label,true);return true;
        }
        void AddFreight() { if(order.freightCents==0) return; FinishFreight(AddCode("F",false,true)); }
        void FinishFreight(long handle) {
            var s=GridCurrent();var g=Selectors.ProductGrid(s);var r=Row(s,handle,"F");
            Order.Require(Order.Norm(Selectors.Cell(s,r,g.Description).Value)=="FREIGHT","F did not load the recorded Freight item.");
            if(PutQuantity(Selectors.Cell(s,r,g.Quantity),1,"freight quantity")) {
                Ready();s=GridCurrent();g=Selectors.ProductGrid(s);r=Row(s,handle,"F");
            }
            // The recording edits List, which then updates Net and the tax-in total.
            Put(Selectors.Cell(s,r,g.ListPrice),(order.freightCents/100m).ToString("0.00",CultureInfo.InvariantCulture),"freight charge",true);
            Ready();s=GridCurrent();g=Selectors.ProductGrid(s);r=Row(s,handle,"F");
            Order.Require(Selectors.Cell(s,r,g.Quantity).Value=="1" && Selectors.Cents(Selectors.Cell(s,r,g.Net))==order.freightCents,"The freight charge did not retain its expected value.");
        }
        void WaitForDetailsTemplate() {
            var wait=Diag.Wait("det_template");
            try {
            var timer=Stopwatch.StartNew(); string previous=null,lastProblem="The note rows have not appeared."; int stable=0;
            while(timer.ElapsedMilliseconds<12000) {
                wait.Tick();Ready(); var s=GridCurrent();
                try {
                    var car=Selectors.FindMemo(s,"MAKE/MODEL","M");
                    var rego=Selectors.FindMemo(s,"REGO NO","M");
                    var odo=Selectors.FindMemo(s,"ODOMETER","M ODO");
                    if(car!=null && rego!=null && odo!=null) {
                        string signature=Selectors.MemoSignature(car)+"|"+Selectors.MemoSignature(rego)+"|"+Selectors.MemoSignature(odo);
                        stable=signature==previous?stable+1:1;previous=signature;
                        if(stable>=2) { Say("DET template ready: car, rego and odometer notes located."); wait.Done("ok"); return; }
                    } else { stable=0;previous=null; }
                } catch(InvalidOperationException e) { stable=0;previous=null;lastProblem=e.Message; }
                Pause(25);
            }
            TraceFocus("DET template did not settle",null);wait.Done("timeout");
            throw new InvalidOperationException("DET did not finish creating stable car/rego notes. " + lastProblem);
            } finally {wait.End();}
        }
        MemoTarget ResolveMemo(string prefix,string code,long createdRow) {
            var s=GridCurrent();
            // Existing DET rows are located afresh by their label, never by a stale editor handle.
            var target=Selectors.FindMemo(s,prefix,code);
            if(target!=null) return target;
            Order.Require(createdRow!=0,"The " + prefix + " note disappeared after DET. Entry stopped.");
            var g=Selectors.ProductGrid(s); var row=Row(s,createdRow,code);
            var editor=Selectors.Cell(s,row,g.Description);
            Order.Require(editor.Value.Length==0,"An unfamiliar note appeared in the new memo row.");
            return new MemoTarget { Row=row,Editor=editor };
        }
        MemoTarget FocusMemo(Func<MemoTarget> locate,string label,MemoTarget initial=null) {
            // Click the live description directly, as in the recording. Only use
            // item-cell navigation if COSTAR redirects focus while expanding it.
            var wait=Diag.Wait("memo_focus");
            try {
            for(int attempt=1;attempt<=3;attempt++) {
                if(attempt>1)Diag.EventRaw("memo_focus_retry",label+" attempt "+attempt);
                Ready();var target=attempt==1 && initial!=null?initial:locate();
                if(attempt>1) {
                    ClickTarget(target.Row);var selection=Stopwatch.StartNew();
                    while(selection.ElapsedMilliseconds<500) {
                        Ready();target=locate();var focus=Native.Focus(root).ToInt64();
                        if(focus==target.Row.Handle){CommitField(target.Row);break;}
                        if(focus==target.Editor.Handle)break;
                        Pause(25);
                    }
                    Ready();target=locate();
                }
                if(Native.Focus(root).ToInt64()!=target.Editor.Handle)ClickTarget(target.Editor);
                var timer=Stopwatch.StartNew();string previous=Selectors.MemoSignature(target);
                while(timer.ElapsedMilliseconds<1200) {
                    wait.Tick();Ready();
                    try {
                        var live=locate(); string signature=Selectors.MemoSignature(live);
                        if(Native.Focus(root).ToInt64()==live.Editor.Handle) {
                            if(signature==previous) {
                                CheckTarget(live.Editor); TraceFocus("Confirmed focus for " + label,live.Editor);wait.Done(attempt==1?"ok":"ok-attempt-"+attempt);return live;
                            }
                            previous=signature;
                        } else {
                            previous=null;
                            if(timer.ElapsedMilliseconds>=100)break;
                        }
                    } catch(InvalidOperationException) { previous=null; }
                    Pause(25);
                }
                TraceFocus("Reacquiring " + label + " after a focus/layout change",target.Editor);
            }
            wait.Done("failed");
            throw new InvalidOperationException("COSTAR did not keep focus in " + label + " after selecting and refocusing its note row.");
            } finally {wait.End();}
        }
        void ReadMemoEquals(string prefix,string code,string expected) {
            var wait=Diag.Wait("memo_readback");
            try {
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<3000) {
                wait.Tick();Ready(); var snapshot=GridCurrent();
                try {
                    var live=Selectors.FindMemo(snapshot,prefix,code);
                    if(live!=null && live.Editor.Value==expected) {wait.Done("ok");return;}
                } catch(InvalidOperationException) { /* Wait for the validated editor to reappear. */ }
                Pause(25);
            }
            wait.Done("timeout");
            throw new InvalidOperationException(prefix + " note did not retain the expected value after COSTAR validation.");
            } finally {wait.End();}
        }
        void Memo(string prefix,string value,string code,bool allowCreate=true) {
            Ready(); var existing=Selectors.FindMemo(GridCurrent(),prefix,code); long createdRow=0;
            if(existing==null) {
                Order.Require(allowCreate,"DET did not provide the " + prefix + " note.");
                createdRow=AddCode(code,true);
            }
            Func<MemoTarget> locate=delegate { return ResolveMemo(prefix,code,createdRow); };
            string expected=Order.EntryText(prefix+":"+(String.IsNullOrWhiteSpace(value)?"":" "+value));
            var first=existing??locate();
            if(first.Editor.Value!=expected) {
                Say("Preparing " + prefix + " note.");
                var target=FocusMemo(locate,prefix + " note",first);
                WriteFocused(target.Editor,expected,prefix + " note",true);
                Ready();
            }
            ReadMemoEquals(prefix,code,expected);
        }
    }
}
