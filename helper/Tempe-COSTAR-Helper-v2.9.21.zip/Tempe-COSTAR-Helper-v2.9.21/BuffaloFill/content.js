// Tempe Buffalo Fill 1.0.3 — on Buffalo's Create Consignment page only. It just says "this page is showing" twice a
// second (and when it starts showing or gets the keyboard); the background does the rest. It never reads or writes the
// page and never holds the key.
// 1.0.3 (Tommy, 27 Nov: "find a way to make it faster, this is too slow"): it says so while the page shows, whether or
// not Chrome has the keyboard (1.0.2 waited for a click into Chrome), so the person can stay in the helper. A page that
// doesn't show (another tab, a minimised window, or one Chrome says is covered) says nothing, so it is never filled.
(() => {
  const token = Math.random().toString(36).slice(2) + Date.now().toString(36);
  document.documentElement.setAttribute('data-tempe-buffalo-fill-script', token);
  let timer = null;
  const alive = () => {
    try { return !!(chrome.runtime && chrome.runtime.id) && document.documentElement.getAttribute('data-tempe-buffalo-fill-script') === token; }
    catch (e) { return false; }
  };
  const stop = () => { clearInterval(timer); window.removeEventListener('focus', tick); document.removeEventListener('visibilitychange', tick); };
  function tick() {
    if (!alive()) { stop(); return; }
    if (document.visibilityState !== 'visible') return;
    try { const p = chrome.runtime.sendMessage({ t: 'tick' }); if (p && p.catch) p.catch(() => { }); }
    catch (e) { stop(); }
  }
  // Twice a second: after a click on Fill the page asks for the job within 0.5 s (0.25 s on average). Each tick is one
  // look at the page (a few boxes read) and, on a blank page, one signed request to the helper on this PC.
  timer = setInterval(tick, 500);
  window.addEventListener('focus', tick);
  document.addEventListener('visibilitychange', tick);
  tick();
})();
