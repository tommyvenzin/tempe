// 2.9.7: the wholesale orders as the helper shows them, shared by the RDP helper's Wholesale tab (one pass on a
// button) and the wholesale helper's own window (the loop, Start-Wholesale.cmd): a line saying where the run is, the
// BUF orders of the last list read with what the dry run would do with each (or why it isn't opened), and the picked
// order's detail: each line's kind (tyre, wheel, tube, freight, other) and Sydney's stock, the Comment before and after,
// card details yes / no / can't tell, the approvals the helper keeps for it, what couldn't be read and when it's tried
// again. Nothing here touches COSTAR.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed class WholesaleView {
        internal readonly Label Line=Ui.Text("",820),Detail=Ui.Hint("",820);
        internal readonly ListView List=new ListView {View=View.Details,FullRowSelect=true,HideSelection=false,Font=Ui.Base,MultiSelect=false,Dock=DockStyle.Fill};
        internal readonly RichTextBox Log=Ui.Log();
        readonly BoundedLog messages=new BoundedLog();
        readonly WholesaleState state;
        string shown="";
        internal WholesaleView(WholesaleState kept) {
            state=kept;
            foreach(var c in new[]{new ColumnHeader {Text="Order",Width=100},new ColumnHeader {Text="Ordered",Width=86},new ColumnHeader {Text="Ship date",Width=86},new ColumnHeader {Text="Ship Via",Width=76},
                new ColumnHeader {Text="Comment",Width=150},new ColumnHeader {Text="Terms",Width=66},new ColumnHeader {Text="Why",Width=50},new ColumnHeader {Text="What it would do",Width=760}}) List.Columns.Add(c);
            List.SelectedIndexChanged+=delegate{ShowOrder();};
            Detail.Margin=new Padding(0,6,0,6);
        }
        internal void Append(string text) { messages.Add(text); }
        // The page: the card on top (title, words, Line), the buttons, the list, the picked order, the log.
        internal TableLayoutPanel Build(Control card,Control buttons) {
            var layout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=5,Padding=new Padding(12),BackColor=Ui.Canvas};
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent,60));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,40));
            layout.Controls.Add(card,0,0);layout.Controls.Add(buttons,0,1);layout.Controls.Add(List,0,2);layout.Controls.Add(Detail,0,3);layout.Controls.Add(Log,0,4);
            return layout;
        }
        // The run's state shown (on the window's thread, from its timer).
        internal void Update(WholesaleRun run) {
            Ui.AppendColoured(Log,messages.Drain());
            if(run==null) return;
            bool running=run.Running;
            Ui.SetText(Line,run.Loop?(run.Status.Length>0?run.Status:running?"Starting ...":run.Summary):running?"Running: "+run.Count()+" so far.":run.Summary);
            var looks=run.Looks;
            string key=looks.Count+"|"+String.Join(",",looks.Select(Key).ToArray());
            if(key==shown) return;
            shown=key;
            string selected=List.SelectedItems.Count>0?List.SelectedItems[0].Text:null;
            List.BeginUpdate();
            try {
                List.Items.Clear();
                foreach(var l in looks) {
                    var r=l.Row;var v=l.Verdict;
                    var item=new ListViewItem(new[]{r.Doc,r.OrderDate,r.ShipDate,r.ShipVia,r.Comment,v!=null?l.Terms??"(unread)":"",l.Queue,Result(l)}) {Tag=l};
                    if(l.Locked) item.ForeColor=Color.FromArgb(29,78,216);
                    else if(v!=null) item.ForeColor=v.Problems.Count>0?Color.FromArgb(185,28,28):v.Action=="sell"?Color.FromArgb(21,128,61):v.Action=="flag"?Color.FromArgb(180,83,9):Ui.Muted;
                    else if(l.Skip!=null) item.ForeColor=l.ListProblem?Color.FromArgb(185,28,28):Ui.Muted;
                    List.Items.Add(item);
                    if(selected!=null&&r.Doc==selected) item.Selected=true;
                }
            } finally { List.EndUpdate(); }
            ShowOrder();
        }
        static string Key(WholesaleLook l) { return l.Row.Doc+(l.Opened?"o":"")+(l.Locked?"k":"")+(l.Verdict==null?"":l.Verdict.Action+l.Verdict.Problems.Count)+(l.Skip==null?"":"s")+(l.LeftOpen==null?"":"l"); }
        internal static string Result(WholesaleLook l) {
            var v=l.Verdict;
            if(l.Locked) return "Open on another PC (COSTAR's Document Already Open, OK pressed): skipped, tried again in 2 minutes";
            if(l.Skip!=null) return "Not opened: "+l.Skip;
            if(v!=null) return WholesaleRules.Plain(v)+(l.LeftOpen!=null?" (left open in COSTAR: "+l.LeftOpen+")":"");
            if(l.LeftOpen!=null) return "Left open in COSTAR: "+l.LeftOpen;
            return l.Opened?"Reading ...":"To open";
        }
        // The picked order: its lines as read, what would change, what the helper keeps for it.
        void ShowOrder() {
            var item=List.SelectedItems.Count>0?List.SelectedItems[0]:null;var l=item==null?null:item.Tag as WholesaleLook;
            if(l==null) { Ui.SetText(Detail,"Pick an order to see its lines and what the dry run found.");return; }
            var parts=new List<string>();
            var m=state==null?null:state.Get(l.Row.Doc);
            if(l.Verdict==null) parts.Add("Order "+l.Row.Doc+": "+Result(l)+".");
            else {
                var v=l.Verdict;
                string card=l.Card==true?"yes":l.Card==false?"no":"can't tell";
                parts.Add("Order "+l.Row.Doc+": Terms "+(l.Terms??"(unread)")+"; card details in the Notes: "+card+(l.NotesShown?"":" (no Notes popped up)")+".");
                parts.Add("Comment \""+(l.OrderComment??"(unread)")+"\""+(v.Action=="flag"?" would become \""+v.CommentAfter+"\"":v.Action=="sell"?" (Sell, then Cancel)":"")+".");
                var lines=l.Lines.Select(x=>"line "+x.Number+" "+x.Item+(x.Note?" (note)":" "+x.Kind.ToUpperInvariant()+(x.Kind=="tyre"?" "+(x.Size.Length>0?x.Size:"")+" ("+WholesaleRules.StockWords(x)+")":"")+", order qty "+x.OrderQty)).ToArray();
                parts.Add(lines.Length>0?String.Join("; ",lines)+".":"No lines read.");
                if(l.Memos.Count>0) parts.Add(String.Join("; ",l.Memos.ToArray())+".");
                if(v.Approve.Count>0) parts.Add("Staff's go would approve "+String.Join(" and ",v.Approve.Select(x=>"["+x+"]").ToArray())+" for these lines (the dry run doesn't keep it).");
            }
            // What changed or was left open (a stop: the order has no verdict then).
            if(l.ChangedValues!=null) parts.Add("Opening its tyre lines changed "+l.ChangedValues+".");
            if(l.LeftOpen!=null&&l.Verdict!=null) parts.Add("Left open in COSTAR: "+l.LeftOpen+".");   // (without a verdict: Result says it)
            if(m!=null) {
                if(m.review!=null||m.items!=null) parts.Add("Approvals kept: "+(m.review!=null?"[review] for "+m.review:"")+(m.review!=null&&m.items!=null?"; ":"")+(m.items!=null?"[items] for "+m.items:"")+" (since "+WholesalePlan.Clock(m.approvedAt)+").");
                else parts.Add("No approvals kept for it.");
                if(m.last=="problem") parts.Add("Can't read: "+m.problems+(m.retryAt>0?". Tried again at "+WholesalePlan.Clock(m.retryAt):"")+".");
                if(m.last=="locked") parts.Add("Open on another PC: tried again at "+WholesalePlan.Clock(m.retryAt)+".");
            }
            Ui.SetText(Detail,String.Join(" ",parts.ToArray()));
        }
    }

    // 2.9.8 / 2.9.9: the speed comparison's window pieces, shared by the wholesale helper and the RDP helper's Wholesale
    // tab: the dialog that starts it (how many orders, any to include), the report's own window, the Approach box.
    internal static class SpeedComparisonUi {
        internal const string About="It opens the same BUF orders with each approach in turn, one approach after another: the 2.9.7 approach first, each of the four improvements on its own, all four together, all four searching by order number, all four with the list filtered to BUF, and the 2.9.7 approach again last (9 passes). "+
            "Each order's stages are timed and its result compared with the 2.9.7 approach's. It's a dry run: every order is opened, read and closed; nothing is typed, sold or changed. It ignores what was previewed today, keeps nothing as previewed, and can be run again at once. "+
            "About 3 minutes a pass for 10 orders (about half an hour). COSTAR is the comparison's alone until it ends: phone jobs, eBay and online orders wait. Leave the PC alone while it runs.";
        // True when started; size and include: what was asked for.
        internal static bool Ask(IWin32Window owner,out int size,out List<string> include) {
            size=10;include=new List<string>();
            using(var dialog=new Form {Text="Wholesale speed comparison",Size=new Size(700,430),FormBorderStyle=FormBorderStyle.FixedDialog,StartPosition=FormStartPosition.CenterParent,MinimizeBox=false,MaximizeBox=false,Font=Ui.Base,BackColor=Ui.Canvas}) {
                var note=new Label {AutoSize=false,Location=new Point(14,12),Size=new Size(660,170),Text=About};
                var countLabel=new Label {AutoSize=true,Location=new Point(14,192),Text="Orders to compare (4 to 20):"};
                var count=new NumericUpDown {Location=new Point(230,189),Width=70,Minimum=4,Maximum=20,Value=10};
                var includeLabel=new Label {AutoSize=false,Location=new Point(14,228),Size=new Size(660,40),Text="Orders to include (optional: their numbers, e.g. ones with several tyre lines, Notes, a memo, wheels or other items; the rest are chosen from the list, spread from top to bottom):"};
                var box=new TextBox {Location=new Point(14,272),Size=new Size(660,26)};
                var go=Ui.PrimaryButton("Start the comparison",200);go.Location=new Point(14,320);
                var cancel=Ui.SecondaryButton("Cancel",100);cancel.Location=new Point(574,320);
                dialog.Controls.AddRange(new Control[]{note,countLabel,count,includeLabel,box,go,cancel});
                bool started=false;
                go.Click+=delegate{started=true;dialog.Close();};
                cancel.Click+=delegate{dialog.Close();};
                dialog.AcceptButton=go;dialog.CancelButton=cancel;
                dialog.ShowDialog(owner);
                if(!started) return false;
                size=(int)count.Value;include=Numbers(box.Text);
                return true;
            }
        }
        // Order numbers typed in the box (spaces, commas or semicolons between them), each as COSTAR lists it. Pure.
        internal static List<string> Numbers(string text) {
            return Regex.Split((text??"").ToUpperInvariant(),@"[\s,;]+").Select(x=>Order.Norm(x)).Where(x=>x.Length>0&&RoEdit.IsDoc(x)).Distinct().Take(20).ToList();
        }
        // The report in a window of its own (fixed-width letters, so its tables line up).
        internal static void ShowReport(IWin32Window owner,string text) {
            var window=new Form {Text="Wholesale speed comparison report",Size=new Size(1080,740),StartPosition=FormStartPosition.CenterScreen,Font=Ui.Base,BackColor=Ui.Canvas};
            var box=new TextBox {Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Both,WordWrap=false,Dock=DockStyle.Fill,Font=new Font("Consolas",9.5F),Text=(text??"").Replace("\r\n","\n").Replace("\n","\r\n")};
            window.Controls.Add(box);
            if(owner!=null) window.Show(owner);else window.Show();
        }
        // The Approach box: the eight approaches, the 2.9.7 one first.
        internal static ComboBox ApproachBox(string key) {
            var box=new ComboBox {DropDownStyle=ComboBoxStyle.DropDownList,Width=320,Font=Ui.Base,Margin=new Padding(0,6,8,0)};
            foreach(var k in WholesaleSpeed.Keys) box.Items.Add(WholesaleSpeed.NameOf(k));
            box.SelectedIndex=Math.Max(0,Array.IndexOf(WholesaleSpeed.Keys,WholesaleSpeed.Preset(key).key));
            return box;
        }
        // The report's lines for a log (each line a message: the log takes a line at a time).
        internal static IEnumerable<string> Lines(string text) { return (text??"").Replace("\r\n","\n").Split('\n'); }
    }
    // 2.9.9: the approach (and the wholesale helper's checking on / off) kept in a small file: wholesale-settings.json for
    // the wholesale helper, wholesale-tab-settings.json beside the RDP helper's files. Never throws; unreadable: defaults.
    internal static class WholesaleSettingsFile {
        internal static WholesaleSettings Load(string file) {
            try { if(File.Exists(file)) { var s=Wire.Read<WholesaleSettings>(File.ReadAllText(file,Encoding.UTF8));if(s!=null) return s; } } catch(Exception e) { AppLog.Note("wholesale_settings_unreadable",e.GetType().Name); }
            return new WholesaleSettings();
        }
        internal static void Save(string file,WholesaleSettings settings) {
            try {
                string temp=file+".tmp";File.WriteAllText(temp,Wire.Json(settings),new UTF8Encoding(false));
                if(File.Exists(file)) File.Replace(temp,file,null);else File.Move(temp,file);
            } catch(Exception e) { AppLog.Note("wholesale_settings_not_saved",e.GetType().Name); }
        }
    }
}
