// The RDP helper's Wholesale tab (2.9.0, stage 1 of the wholesale orders: a dry run). A button runs one pass of the
// dry run (WholesaleRun: nothing typed, sold or changed); Stop stops it; the list shows each BUF order of COSTAR
// Sydney's "Orders yet to be filled" and what the helper would do with it; picking one shows its lines as read.
// 2.9.7: the new rules (Tommy, 14 Nov), the list and detail shared with the wholesale helper's window (WholesaleView),
// up to 100 orders a press, and what was previewed kept (wholesale-state.json), so the next press gets further down
// the list. Checking again and again by itself is the wholesale helper's (Start-Wholesale.cmd, a Windows session of
// its own): this tab keeps COSTAR Sydney's Work-in-Progress for eBay orders.
// 2.9.9 (Tommy, 15 Nov 08:33: "put Speed test and the Approach selector on the Wholesale tab in my usual RDP helper";
// "Make this test available using my current Windows login and COSTAR session"): the Approach box (the press's pass uses
// it; Back to 2.9.7; kept in wholesale-tab-settings.json) and Run speed comparison (WholesaleSpeedTest, the same
// comparison as the wholesale helper's, in this session's COSTAR Sydney: each of its passes goes back to Repair Order at
// its end, as a press does; COSTAR is its alone until it ends, so phone jobs, eBay and online orders wait; it ignores
// what was previewed and keeps nothing, so it can be run again at once). Why it can't start is said before anything
// is pressed (a message box) or, once it's under way, on the tab's line, in the log and in the report.
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed partial class WorkerForm {
        readonly TabPage wholesalePage=new TabPage("Wholesale");
        readonly Button wholesaleStart=Ui.PrimaryButton("Check wholesale orders (dry run)",290),wholesaleStop=Ui.DangerButton("Stop",100),
            wholesaleBaseline=Ui.SecondaryButton("Back to 2.9.7",140),wholesaleCompare=Ui.PrimaryButton("Run speed comparison",230);
        ComboBox wholesaleApproach;WholesaleSettings wholesaleSettings;string wholesaleSettingsFile;
        WholesaleView wholesaleView;WholesaleState wholesaleState;
        volatile WholesaleRun wholesale;volatile WholesaleSpeedTest wholesaleTest;bool wholesaleTestSeen,wholesaleShowTest;
        void WholesaleAppend(string text){if(wholesaleView!=null) wholesaleView.Append(text);}
        // The dry run's press or the speed comparison is using COSTAR (for Stop all).
        bool WholesaleBusy { get { var r=wholesale;var t=wholesaleTest;return (r!=null&&r.Running)||(t!=null&&t.Running); } }
        void BuildWholesalePage() {
            wholesalePage.BackColor=Ui.Canvas;wholesalePage.Padding=new Padding(0);
            string folder=Path.Combine(PrivateFiles.Home,"worker");PrivateFiles.DirectoryReady(folder);
            wholesaleState=new WholesaleState(folder);wholesaleView=new WholesaleView(wholesaleState);
            wholesaleSettingsFile=Path.Combine(folder,"wholesale-tab-settings.json");wholesaleSettings=WholesaleSettingsFile.Load(wholesaleSettingsFile);
            var card=Ui.Card();card.Dock=DockStyle.Top;
            var lines=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Surface};
            lines.Controls.Add(Ui.Title("Wholesale orders in COSTAR Sydney: dry run (2.9.7 rules)"));
            lines.Controls.Add(Ui.Hint("Opens up to 100 BUF orders on \"Orders yet to be filled\" whose ShipDate isn't after today, oldest first: staff's go requests, then orders not looked at yet, then ones to try again. "+
                "A Comment of WWW and BUF words only (any order, any spelling of BUFFALO) is a new order; the helper's tags [stock] [card] [review] [items] wait for staff's go; any other words are staff's. "+
                "It reads Terms, card details (yes or no only), and each line (tyre, wheel, tube, freight, other); each tyre's Sydney \"= Avail\" must be 4 or more. "+
                "It shows what it WOULD do: Sell, then Cancel, or the Comment with the tags it would add. Nothing is typed, sold or changed. "+
                "COSTAR Sydney comes to the front: leave the PC alone until it's done. eBay orders wait meanwhile; COSTAR Sydney goes back to Repair Order at the end. "+
                "Each press goes further down the list (orders previewed today aren't opened again unless their row changes). To check by itself all day, use the wholesale helper (Start-Wholesale.cmd) in a Windows session of its own.",820));
            lines.Controls.Add(Ui.Hint("Run speed comparison: "+SpeedComparisonUi.About+" Approach: how a press works through the orders (the 2.9.7 approach until you pick another; Back to 2.9.7 returns to it).",820));
            lines.Controls.Add(wholesaleView.Line);
            card.Controls.Add(lines);
            var buttons=Ui.Row();buttons.Margin=new Padding(0,10,0,6);buttons.Controls.Add(wholesaleStart);buttons.Controls.Add(wholesaleStop);buttons.Controls.Add(wholesaleCompare);
            var speedRow=Ui.Row();speedRow.Margin=new Padding(0,0,0,6);
            wholesaleApproach=SpeedComparisonUi.ApproachBox(wholesaleSettings.approach);
            speedRow.Controls.Add(new Label {Text="Approach:",AutoSize=true,Font=Ui.Base,ForeColor=Ui.Ink,Margin=new Padding(0,10,6,0)});
            speedRow.Controls.Add(wholesaleApproach);speedRow.Controls.Add(wholesaleBaseline);
            var rows=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Canvas,Margin=new Padding(0)};
            rows.Controls.Add(buttons);rows.Controls.Add(speedRow);
            wholesalePage.Controls.Add(wholesaleView.Build(card,rows));
            wholesaleStart.Click+=delegate{DeskForm.Attempt(StartWholesale);};
            wholesaleStop.Click+=delegate{StopWholesale();};
            wholesaleCompare.Click+=delegate{DeskForm.Attempt(StartWholesaleComparison);};
            wholesaleApproach.SelectedIndexChanged+=delegate{ChooseWholesaleApproach();};
            wholesaleBaseline.Click+=delegate{wholesaleApproach.SelectedIndex=0;};
            wholesaleStop.Enabled=false;
            Ui.SetText(wholesaleView.Line,"Not run yet. Approach: "+WholesaleSpeed.NameOf(WholesaleSpeed.Preset(wholesaleSettings.approach).key)+".");
        }
        void ChooseWholesaleApproach() {
            int i=wholesaleApproach.SelectedIndex;if(i<0||i>=WholesaleSpeed.Keys.Length) return;
            string key=WholesaleSpeed.Keys[i];if(key==WholesaleSpeed.Preset(wholesaleSettings.approach).key) return;
            wholesaleSettings.approach=key;WholesaleSettingsFile.Save(wholesaleSettingsFile,wholesaleSettings);
            var r=wholesale;
            WholesaleAppend("Approach: "+WholesaleSpeed.NameOf(key)+(r!=null&&r.Running?" (from the next press)":"")+".");
            AppLog.Note("wholesale_approach",key+" (the RDP helper's tab)");
        }
        void StartWholesale() {
            var last=wholesale;var test=wholesaleTest;
            Order.Require(last==null||!last.Running,"The dry run is already running.");
            Order.Require(test==null||!test.Running,"The speed comparison is running: wait for it to end (or press Stop).");
            Order.Require(!coordinator.Busy,(coordinator.Owner.Length>0?coordinator.Owner:"An entry")+" is using COSTAR: wait for it to finish.");
            var settings=wholesaleSettings;
            var run=new WholesaleRun(coordinator,WholesaleAppend,new WholesaleOptions {State=wholesaleState,RestoreList=true,Speed=delegate { return WholesaleSpeed.Preset(settings.approach); }});wholesale=run;wholesaleShowTest=false;
            AppLog.Note("wholesale_dry_run_start",WholesaleSpeed.Preset(settings.approach).key);
            var thread=new Thread(delegate() { run.Run();WholesaleAppend(run.Summary); });
            thread.IsBackground=true;thread.Start();
            UpdateStatus();
        }
        // The speed comparison: the reasons it can't start said here, before anything is pressed; then how many orders
        // (and any to include); then it runs on a thread of its own.
        void StartWholesaleComparison() {
            var last=wholesale;var test=wholesaleTest;
            Order.Require(test==null||!test.Running,"The speed comparison is already running.");
            Order.Require(last==null||!last.Running,"A wholesale dry run is running: wait for it to end (or press Stop), then press Run speed comparison.");
            Order.Require(!coordinator.Busy,"The comparison can't start now: "+(coordinator.Owner.Length>0?coordinator.Owner:"another job")+" is using COSTAR. Press Run speed comparison again when it's done.");
            var t=WholesaleRun.Sydney();
            Order.Require(RoWip.Shown(t,RoListKind.Wip).Count==0&&RoWip.Shown(t,RoListKind.Wholesale).Count==0,"The comparison can't start: a Repair Order or an Order is open in COSTAR Sydney. Close it, then press Run speed comparison again (the comparison opens orders one at a time).");
            string session=Native.SessionProblem();
            Order.Require(session==null,"The comparison can't start: "+session+".");
            int size;List<string> include;
            if(!SpeedComparisonUi.Ask(this,out size,out include)) return;
            Order.Require(!coordinator.Busy,"The comparison can't start now: "+(coordinator.Owner.Length>0?coordinator.Owner:"another job")+" is using COSTAR. Press Run speed comparison again when it's done.");
            var comparison=new WholesaleSpeedTest(coordinator,WholesaleAppend,Native.SessionProblem,null,size,include,false);
            wholesaleTest=comparison;wholesaleTestSeen=true;wholesaleShowTest=true;
            WholesaleAppend("Speed comparison started: "+size+" orders"+(include.Count>0?" (including "+String.Join(", ",include.ToArray())+")":"")+". Leave the PC alone until it's done; phone jobs, eBay and online orders wait meanwhile.");
            var thread=new Thread(delegate() {
                comparison.Run();
                WholesaleAppend(comparison.StatusLine);
                foreach(var line in SpeedComparisonUi.Lines(comparison.ReportText)) WholesaleAppend(line);
                if(comparison.ReportFile.Length>0) WholesaleAppend("The report is saved: "+comparison.ReportFile+" (Save diagnostics includes it).");
            }) {IsBackground=true,Name="Wholesale speed comparison"};
            thread.Start();
            UpdateStatus();
        }
        // Stop: the press's pass at once (as before); the comparison after the order in hand (closed as usual).
        void StopWholesale() {
            var run=wholesale;if(run!=null&&run.Running) { run.Cancel=true;WholesaleAppend("Stopping the dry run ..."); }
            var test=wholesaleTest;if(test!=null&&test.Running) { test.Stop();WholesaleAppend("Stopping the speed comparison after the order in hand ..."); }
        }
        void UpdateWholesaleTab() {
            if(wholesaleView==null) return;
            var run=wholesale;bool running=run!=null&&run.Running;
            var test=wholesaleTest;bool testing=test!=null&&test.Running;
            wholesaleStart.Enabled=!running&&!testing&&!coordinator.Busy;wholesaleStop.Enabled=running||testing;
            // Pressable whenever nothing of this tab runs: if COSTAR is busy with other work, the press says so.
            wholesaleCompare.Enabled=!running&&!testing;
            // The comparison's passes shown while it runs, and its last one (with its line) until the next press.
            if(test!=null&&(testing||wholesaleShowTest)) { wholesaleView.Update(test.Current);Ui.SetText(wholesaleView.Line,test.StatusLine); }
            else wholesaleView.Update(run);
            // The comparison ended: its line stays; the report in its own window (why it couldn't start: a message).
            if(test!=null&&!testing&&wholesaleTestSeen) {
                wholesaleTestSeen=false;
                Ui.SetText(wholesaleView.Line,test.StatusLine);
                if(test.Passes>0) SpeedComparisonUi.ShowReport(this,test.ReportText);
                else MessageBox.Show(this,test.StatusLine,"Wholesale speed comparison",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
        }
    }
}
