// The RDP helper's Repair Order side (2.6.0): asks the desk PC for the phones' Repair Order requests
// and does them in the selected COSTAR (Tempe), one at a time, in a quiet moment: reads its Work-in-
// Progress list, opens a Repair Order from it (double click on its row, or Enter on the selected row),
// reads it, types the phone's changes, checks them and closes it again. A change that stops after
// typing leaves the Repair Order open for a person to check (the phone can ask to close it then).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    // What the helper is doing (saved before COSTAR is touched): after a restart it tells the desk the
    // request stopped. touched: something was typed into the Repair Order.
    // printing (2.6.2): OK was about to go on COSTAR's print form (the Job Card may have printed).
    public sealed class RoAttempt { public string id,lease,kind,doc,atUtc;public long window,processStart;public int processId;public bool touched,printing; }
    // A Repair Order this helper left open after a change stopped (the phone may ask to close it).
    public sealed class RoLeftOpen { public string doc,atUtc;public long window,processStart;public int processId; }
    public sealed class RoJournal { public RoAttempt running;public RoLeftOpen leftOpen;public RoReport report;public int sequence; }
    // What an open from Work-in-Progress saw, for the engine when it stops: the Repair Order windows
    // there before anything was clicked (shown or not), and whether a person used the PC meanwhile
    // (then no window that opened is taken for the helper's own, so none is ever closed).
    // BeforeAll (2.9.4): every top-level window of that COSTAR before the open (Document Already Open's form must be new).
    // 2.9.6: Stay, StayPid: the Repair Orders left open beside the open, kept for a person (RoEngine.FateOf), in that
    // COSTAR; KeptChanged: one of them closed or changed meanwhile (then nothing more is taken for the open's own).
    internal sealed class RoOpenWatch { internal HashSet<long> Before,BeforeAll,Stay;internal int StayPid;internal bool UserActive,KeptChanged;internal readonly Stopwatch Clock=Stopwatch.StartNew(); }

    // How long each part of an open from Work-in-Progress took (2.6.1), for the day log and the report.
    internal sealed class RoOpenTimes {
        internal long ScanMs,SearchMs=-1,RevealMs,WindowMs=-1,TotalMs;internal int Rows,Scans,Wheels,Notches;internal bool OneCell,Clicked,Direct,FilterCleared;internal string How="",Hit="";
        // 2.9.8 (the wholesale speed test): Hint: the place the row was looked for first (0: none); Hinted: found there;
        // Fallbacks: times the list was read in full after all (the place didn't hold it, or the direct open didn't
        // take); SelectTries: tries to make the row the active one.
        internal int Hint,Fallbacks,SelectTries;internal bool Hinted;
        // 2.6.11: the filter cleared (a person's search: for the phone's result only, never the day log).
        internal string Filter="";
        internal void Took(WipScan scan) { ScanMs+=scan.Ms;Scans++;Rows=scan.Lines.Count;OneCell=scan.OneCell; }
        static string S(long ms) { return (ms/100/10.0).ToString("0.0",CultureInfo.InvariantCulture)+" s"; }
        public override string ToString() {
            var b=new StringBuilder();
            b.Append("list read ").Append(S(ScanMs)).Append(" (").Append(Rows).Append(" rows").Append(OneCell?", one cell each":", every cell").Append(Scans>1?", "+Scans+" reads":"").Append(")");
            b.Append(SearchMs>=0?", Search "+S(SearchMs):", no Search");
            if(FilterCleared) b.Append(" (COSTAR's filter cleared first)");
            b.Append(", row ").Append(How.Length>0?How:"not reached").Append(" ").Append(S(RevealMs));
            if(Wheels>0) b.Append(" (").Append(Notches).Append(" notches").Append(Clicked?", one click to give the list the wheel":"").Append(")");
            if(Hit.Length>0) b.Append(", at the point: ").Append(Hit);
            if(Hint>0) b.Append(Hinted?", found at its known place":", not at its known place");
            if(Fallbacks>0) b.Append(", read in full after all ").Append(Fallbacks).Append(Fallbacks==1?" time":" times");
            if(Direct) b.Append(", opened without the mouse (Enter)");
            if(WindowMs>=0) b.Append(", COSTAR opened it in ").Append(S(WindowMs));
            b.Append(", ").Append(S(TotalMs)).Append(" in all");
            return b.ToString();
        }
    }

    // The scroll arithmetic of an open (2.6.1), apart from COSTAR so it can be tested. Rows are counted in
    // the list's order.
    internal static class WipScroll {
        internal const int MaxSteps=40,MaxTurnNotches=20,MaxRevealMs=30000;
        // Notches for one turn towards a row `rows` away (room: rows the list can still go that way before its
        // end, as seen; it may be a row out): one while it isn't known how far a notch goes; then as many as
        // bring the row to the middle, 20 at most, and only as many as stay a row short of the list's end (a
        // list may stop at its end, or go on past its last row: a turn short of it shows every notch of it);
        // one when not even that fits. Each turn is waited out before the next.
        internal static int Turn(int rows,int perNotch,int room) {
            if(perNotch<=0) return 1;
            int n=Math.Max(1,Math.Min(MaxTurnNotches,(int)Math.Ceiling(rows/(double)perNotch)));
            if(n*perNotch>room-1) n=Math.Max(1,(room-1)/perNotch);
            return n;
        }
        // Rows a turn must move the list (at least one; no more than it can go before its end).
        internal static int Expect(int notches,int perNotch,int room) { return Math.Max(1,Math.Min(room,notches*Math.Max(1,perNotch))); }
        // After a turn that came through (moved: rows, the way it was turned; room: rows it could go before
        // the list's end, as seen): how many rows a notch moves (0: still not known), or -1 when the turn moved
        // the list other than its notches say (then a notch may still be on its way: stop). One notch comes
        // through whole or not at all, so any move of one notch is all of it (no more than a notch's rows: the
        // list may have stopped at its end); it measures a notch unless it took the list to its end. A turn
        // of more notches must move exactly that many notches' rows (it stays short of the end: Turn).
        internal static int Accounted(int perNotch,int moved,int notches,int room) {
            if(moved<=0) return -1;
            if(notches==1) return perNotch<=0?(moved>=room?0:moved):moved<=perNotch?perNotch:-1;
            return perNotch>0&&moved==notches*perNotch?perNotch:-1;
        }
    }

    // One look at COSTAR's Work-in-Progress list for one open (2.6.1). Only each row's Document # cell is
    // read (one cell a row through accessibility; 2.6.0 read every cell of every row, about 4 s a look, and
    // looked again after each scroll step), and the cells are kept, so where the rows are after a scroll
    // is one call a row. Everything is released when the open ends.
    internal sealed class WipScan : IDisposable {
        // Pos: the row's place among the list's children (1 = first), to look at it again with new objects.
        internal sealed class Line { internal string Doc;internal Accessibility.IAccessible Row,Cell;internal int Left,Top,Width,Height,Pos;internal bool Placed; }
        // The list shows no table (before COSTAR's first Search, or while it is being made again).
        internal sealed class NoTable : InvalidOperationException { internal NoTable():base("COSTAR's Work-in-Progress list isn't showing a table. Press Search in COSTAR.") {} }
        // A cell read on its own that isn't the Document # cell: the list is read again, every cell.
        sealed class WrongCell : Exception { }
        internal readonly List<Line> Lines=new List<Line>();
        // HeadBottom: the bottom of the column headings, when the list tells (a row placed above it is hidden
        // behind them, never in view).
        internal int Target=-1,First=-1,Last=-1,DocIndex=-1,HeadBottom=-1;internal bool OneCell;internal long Ms;
        // 2.9.8: read at a known place only (FromHint): the wanted row and up to two rows either side, not the whole list.
        internal bool Hinted;
        readonly List<object> owned=new List<object>();
        Accessibility.IAccessible client,table;Dictionary<string,int> columns;string poColumn="";
        Func<Accessibility.IAccessible> source;
        const string DocColumn="Document #";
        internal Line TargetLine { get { return Target>=0&&Target<Lines.Count?Lines[Target]:null; } }
        // 2.9.8 (the wholesale speed test, "find the row directly"): the wanted row read at the place the pass's list read
        // found it (pos: its place among the list's children, as Line.Pos; or a place or two either side, as the list can
        // hold its active row twice), and the rows up to two places either side of it (for the checks that it's the active
        // and only selected row). The columns come from one row read whole (by name, as a whole read takes them); each
        // row's Document # cell is then taken on its own and its name checked. Null when no such place holds this document
        // now (the list changed, or COSTAR made its rows again): the list is then read in full. The opened window's number
        // is checked as always.
        internal static WipScan FromHint(Func<Accessibility.IAccessible> root,Native.Rect box,string doc,int pos) {
            if(pos<1) return null;
            var clock=Stopwatch.StartNew();var scan=new WipScan {source=root,Hinted=true};
            try {
                scan.client=root();
                scan.table=Msaa.Role(scan.client)==Msaa.RoleTable?scan.client:Msaa.FindTable(scan.client,3);
                if(scan.table==null||!(scan.ColumnsFrom(pos)||scan.ColumnsFrom(pos+1)||scan.ColumnsFrom(pos-1))) { scan.Dispose();return null; }
                string want=Order.Norm(doc);int at=-1;
                foreach(int p in new[]{pos,pos-1,pos+1,pos-2,pos+2}) {
                    Accessibility.IAccessible r,c;
                    if(p>=1&&scan.CellAt(p,out r,out c)&&Order.Norm(Msaa.ValueOf(r,c))==want) { at=p;break; }
                }
                if(at<0) { scan.Dispose();return null; }
                for(int p=Math.Max(1,at-2);p<=at+2;p++) {
                    Accessibility.IAccessible r,c;
                    if(!scan.CellAt(p,out r,out c)) continue;
                    string d=Order.Norm(Msaa.ValueOf(r,c));
                    if(d.Length==0||!RoEdit.IsDoc(d)) continue;
                    if(p!=at&&d==want) continue;   // the same document elsewhere (the active row twice): only the one at its place
                    int l,t,w,hh;bool placed=Msaa.LocationOf(r,c,out l,out t,out w,out hh)&&w>0&&hh>0;
                    scan.Lines.Add(new Line {Doc=d,Row=r,Cell=c,Left=l,Top=t,Width=w,Height=hh,Placed=placed,Pos=p});
                    if(p==at) scan.Target=scan.Lines.Count-1;
                }
                if(scan.Target<0) { scan.Dispose();return null; }
                scan.OneCell=true;scan.Range(box);scan.Ms=clock.ElapsedMilliseconds;
                return scan;
            } catch(Exception) { scan.Dispose();return null; }
        }
        // The columns by name from the row at a place, every cell of it read (false: no data row there, or no Document #).
        bool ColumnsFrom(int p) {
            if(p<1) return false;
            object o=null;try { o=table.get_accChild(p); } catch(Exception) { o=null; }
            var row=o as Accessibility.IAccessible;
            if(row==null||Msaa.RoleOf(table,o)!=Msaa.RoleRow) { Msaa.Release(o);return false; }
            owned.Add(o);
            var cells=Msaa.Children(row,80);
            try {
                if(cells.Count==0||Msaa.RoleOf(row,cells[0])==25) return false;   // the column headings
                var map=new Dictionary<string,int>(StringComparer.Ordinal);
                for(int i=0;i<cells.Count;i++) { string n=Msaa.NameOf(row,cells[i]).Trim();if(n.Length>0&&!map.ContainsKey(n)) map[n]=i; }
                int di;if(!map.TryGetValue(DocColumn,out di)) return false;
                columns=map;poColumn=TempeOrderCheck.GridReader.FindPoColumn(map.Keys);DocIndex=di;
                return true;
            } finally { foreach(var c in cells) Msaa.Release(c); }
        }
        // The data row at a place and its Document # cell taken on its own, named as that column (false: not so).
        bool CellAt(int p,out Accessibility.IAccessible row,out Accessibility.IAccessible cell) {
            row=null;cell=null;if(DocIndex<0) return false;
            object ro=null,co=null;
            try { ro=table.get_accChild(p); } catch(Exception) { ro=null; }
            var r=ro as Accessibility.IAccessible;
            if(r==null||Msaa.RoleOf(table,ro)!=Msaa.RoleRow) { Msaa.Release(ro);return false; }
            owned.Add(ro);
            try { co=r.get_accChild(DocIndex+1); } catch(Exception) { co=null; }
            var c=co as Accessibility.IAccessible;
            if(c==null) { Msaa.Release(co);return false; }
            owned.Add(co);
            if(Msaa.NameOf(r,c).Trim()!=DocColumn) return false;
            row=r;cell=c;return true;
        }
        internal static WipScan Take(IntPtr grid,string doc,bool allCells=false) {
            Native.Rect box;Order.Require(Native.GetWindowRect(grid,out box),"COSTAR's Work-in-Progress list is gone.");
            return From(delegate { return Msaa.FromWindow(grid); },box,doc,allCells);
        }
        // From any accessibility root and the list's place on the screen (the self-tests give a made-up
        // list). allCells: every cell of every row (as 2.6.0 did), when one cell on its own can't be trusted.
        internal static WipScan From(Func<Accessibility.IAccessible> root,Native.Rect box,string doc,bool allCells) {
            var clock=Stopwatch.StartNew();
            if(!allCells) {
                var scan=new WipScan {source=root};bool wrong=false;
                try { scan.Read(root(),box,doc,false); }
                catch(WrongCell) { wrong=true; }
                catch(Exception) { scan.Dispose();throw; }
                // The wanted row's cell too must be named as the Document # column.
                if(!wrong&&scan.OneCell&&scan.TargetLine!=null&&Msaa.NameOf(scan.TargetLine.Row,scan.TargetLine.Cell).Trim()!=DocColumn) wrong=true;
                if(!wrong) { scan.Ms=clock.ElapsedMilliseconds;return scan; }
                scan.Dispose();AppLog.Note("ro_wip_cells","a cell read on its own wasn't the Document # cell: every cell read");
            }
            var all=new WipScan {source=root};
            try { all.Read(root(),box,doc,true); }
            catch(Exception) { all.Dispose();throw; }
            all.Ms=clock.ElapsedMilliseconds;return all;
        }
        void Read(Accessibility.IAccessible root,Native.Rect box,string doc,bool allCells) {
            client=root;
            table=Msaa.Role(client)==Msaa.RoleTable?client:Msaa.FindTable(client,3);
            if(table==null) throw new NoTable();
            string want=Order.Norm(doc);var seen=new Dictionary<string,int>(StringComparer.Ordinal);
            int docIndex=-1,alone=0,pos=0;bool one=!allCells;
            foreach(object o in Msaa.Children(table,5000)) {
                owned.Add(o);pos++;
                var row=o as Accessibility.IAccessible;
                if(row==null||Msaa.RoleOf(table,o)!=Msaa.RoleRow) continue;
                Accessibility.IAccessible cell=null;
                if(docIndex>=0&&one) {
                    object c=null;try { c=row.get_accChild(docIndex+1); } catch(Exception) { c=null; }
                    if(c!=null) owned.Add(c);
                    cell=c as Accessibility.IAccessible;
                    // Its name checked on the first rows and on every 10th after them (and on the wanted one at
                    // the end): one that isn't the Document # cell means reading the whole list again.
                    if(cell!=null&&(alone<3||alone%10==0)&&Msaa.NameOf(row,cell).Trim()!=DocColumn) throw new WrongCell();
                    if(cell!=null) alone++; else one=false; // no cell on its own: every cell from here (named with them)
                }
                if(cell==null) {
                    var cells=Msaa.Children(row,80);
                    try {
                        if(cells.Count==0) continue;
                        if(Msaa.RoleOf(row,cells[0])==25) { // the column headings
                            int hl,ht,hw,hh2;if(Msaa.LocationOf(table,row,out hl,out ht,out hw,out hh2)&&hw>0&&hh2>0) HeadBottom=Math.Max(HeadBottom,ht+hh2);
                            continue;
                        }
                        if(columns==null) {
                            columns=new Dictionary<string,int>(StringComparer.Ordinal);
                            for(int i=0;i<cells.Count;i++) { string n=Msaa.NameOf(row,cells[i]).Trim();if(n.Length>0&&!columns.ContainsKey(n)) columns[n]=i; }
                            poColumn=TempeOrderCheck.GridReader.FindPoColumn(columns.Keys);
                            Order.Require(columns.TryGetValue(DocColumn,out docIndex),"COSTAR's Work-in-Progress list has no Document # column.");
                        }
                        if(docIndex<cells.Count) cell=cells[docIndex] as Accessibility.IAccessible;
                    } finally { foreach(var c in cells) if(!Object.ReferenceEquals(c,cell)) Msaa.Release(c); }
                    if(cell==null) continue;
                    owned.Add(cell);
                }
                string d=Order.Norm(Msaa.ValueOf(row,cell));
                if(d.Length==0||!RoEdit.IsDoc(d)) continue;
                int l,t,w,hh;bool placed=Msaa.LocationOf(row,cell,out l,out t,out w,out hh)&&w>0&&hh>0;
                int at;
                if(seen.TryGetValue(d,out at)) {
                    // The list can hold its active row twice: one line per document, at the place shown.
                    var first=Lines[at];
                    if(!first.Placed&&placed) { first.Row=row;first.Cell=cell;first.Left=l;first.Top=t;first.Width=w;first.Height=hh;first.Placed=true;first.Pos=pos; }
                    continue;
                }
                seen[d]=Lines.Count;
                Lines.Add(new Line {Doc=d,Row=row,Cell=cell,Left=l,Top=t,Width=w,Height=hh,Placed=placed,Pos=pos});
                if(d==want) Target=Lines.Count-1;
            }
            OneCell=one&&docIndex>=0&&alone>0;DocIndex=docIndex;
            Range(box);
        }
        // Where rows show: from the bottom of the column headings (when the list tells where they are; a few
        // pixels either way: a row hidden behind them is a whole row higher), inside the list.
        internal int ViewTop(Native.Rect box) { return HeadBottom>0?Math.Max(box.Top,HeadBottom-4):box.Top; }
        void Range(Native.Rect box) {
            First=-1;Last=-1;int top=ViewTop(box);
            for(int i=0;i<Lines.Count;i++) { var x=Lines[i];if(x.Placed&&x.Top>=top&&x.Top+x.Height<=box.Bottom) { if(First<0) First=i;Last=i; } }
        }
        static void Place(Line x) { int l,t,w,h;x.Placed=Msaa.LocationOf(x.Row,x.Cell,out l,out t,out w,out h)&&w>0&&h>0;x.Left=l;x.Top=t;x.Width=w;x.Height=h; }
        // Where every row is now (one call each) and which are wholly in view. False when no row has a
        // place any more (the rows were made again: read the list again).
        internal bool Places(Native.Rect box) {
            bool any=false;foreach(var x in Lines) { Place(x);any|=x.Placed; }
            Range(box);return any;
        }
        internal void PlaceTarget() { var x=TargetLine;if(x!=null) Place(x); }
        internal int InView { get { return First<0?0:Last-First+1; } }
        // A row's height: the middle one of the steps between rows in view (19 px when nothing tells).
        internal int RowHeight {
            get {
                var steps=new List<int>();
                for(int i=Math.Max(0,First);First>=0&&i<Last;i++) { var a=Lines[i];var b=Lines[i+1];if(a.Placed&&b.Placed&&b.Top>a.Top) steps.Add(b.Top-a.Top); }
                if(steps.Count>0) { steps.Sort();return Math.Max(1,steps[steps.Count/2]); }
                return First>=0?Math.Max(1,Lines[First].Height):19;
            }
        }
        // Where the list is scrolled to, in rows: for every row wholly in view, its number less the rows above
        // it on the screen, the middle of those (one odd answer from accessibility doesn't move it). Null when
        // no row is in view. Larger: scrolled further down.
        internal int? ScrollRow(Native.Rect box) {
            if(First<0) return null;
            int h=RowHeight,top=ViewTop(box);var at=new List<int>();
            for(int i=First;i<=Last;i++) { var x=Lines[i];if(x.Placed&&x.Top>=top&&x.Top+x.Height<=box.Bottom) at.Add(i-(int)Math.Round((x.Top-box.Top)/(double)h)); }
            if(at.Count==0) return null;
            at.Sort();return at[at.Count/2];
        }
        // Rows the list can still move: up (above the first row in view) or down (below the last).
        internal int Room(bool up) { return First<0?0:up?First:Lines.Count-1-Last; }
        // The wanted row looked at with new objects at its place among the list's children: why it isn't
        // this Repair Order there, at the same place, or null when it is.
        internal string FreshCheck() {
            var x=TargetLine;if(x==null||source==null) return "no row";
            Accessibility.IAccessible root=null,fresh=null,row=null,cell=null;object o=null,c=null;
            try {
                root=source();fresh=Msaa.Role(root)==Msaa.RoleTable?root:Msaa.FindTable(root,3);
                if(fresh==null) return "no table";
                try { o=fresh.get_accChild(x.Pos); } catch(Exception) { o=null; }
                row=o as Accessibility.IAccessible;if(row==null) return "no row there";
                if(DocIndex<0) return "no Document # column";
                if(OneCell) { try { c=row.get_accChild(DocIndex+1); } catch(Exception) { c=null; } cell=c as Accessibility.IAccessible; }
                else { var cells=Msaa.Children(row,80);try { if(DocIndex<cells.Count) { c=cells[DocIndex];cell=c as Accessibility.IAccessible; } } finally { foreach(var k in cells) if(!Object.ReferenceEquals(k,c)) Msaa.Release(k); } }
                if(cell==null||Msaa.NameOf(row,cell).Trim()!=DocColumn) return "not the Document # cell";
                string d=Order.Norm(Msaa.ValueOf(row,cell));if(d!=x.Doc) return "Repair Order "+(d.Length>0?d:"(none)")+" is there now";
                int l,t,w,h;bool placed=Msaa.LocationOf(row,cell,out l,out t,out w,out h)&&w>0&&h>0;
                if(!placed||t!=x.Top||l!=x.Left) return "it moved";
                return null;
            } finally { Msaa.Release(c);Msaa.Release(o);if(fresh!=null&&!Object.ReferenceEquals(fresh,root)) Msaa.Release(fresh);Msaa.Release(root); }
        }
        // The wanted row is the selected (or focused) one, and no other row is either (for Enter, which opens
        // the list's current row).
        internal bool OnlyTargetSelected() {
            var x=TargetLine;if(x==null) return false;
            int st=Msaa.StateOf(table,x.Row);if(st<0||(st&0x6)==0) return false;
            foreach(var y in Lines) { if(Object.ReferenceEquals(y,x)) continue;int s=Msaa.StateOf(table,y.Row);if(s>=0&&(s&0x6)!=0) return false; }
            return true;
        }
        // 2.6.5: the wanted row is the list's active row, the one Enter opens: it carries the keyboard's mark
        // (focused) while the list has the keyboard, or it is the row that doesn't offer "Activate" while the
        // others do (COSTAR's list, the maps of 28 Oct: only the active row has no action).
        internal bool TargetActive() {
            var x=TargetLine;if(x==null) return false;
            int st=Msaa.StateOf(table,x.Row);
            if(st>=0&&(st&0x4)!=0) return true;
            string a;if(!Msaa.TryAction(table,x.Row,out a)||a.Trim().Length>0) return false;
            int others=0;
            foreach(var y in Lines) {
                if(Object.ReferenceEquals(y,x)) continue;
                string b;if(!Msaa.TryAction(table,y.Row,out b)||!String.Equals(b.Trim(),"Activate",StringComparison.OrdinalIgnoreCase)) return false;
                if(++others>=3) break;
            }
            return others>0;
        }
        // 2.6.5: the wanted row looked up afresh (new objects, at its place among the list's children) and
        // still this Repair Order there: the row (to press its "Activate"), or null with why not.
        internal Accessibility.IAccessible FreshTargetRow(out string why) {
            var x=TargetLine;why=null;
            if(x==null||source==null) { why="no row";return null; }
            Accessibility.IAccessible root=null,fresh=null,row=null,cell=null;object o=null,c=null;bool keep=false;
            try {
                root=source();fresh=Msaa.Role(root)==Msaa.RoleTable?root:Msaa.FindTable(root,3);
                if(fresh==null) { why="no table";return null; }
                try { o=fresh.get_accChild(x.Pos); } catch(Exception) { o=null; }
                row=o as Accessibility.IAccessible;if(row==null) { why="no row there";return null; }
                if(DocIndex<0) { why="no Document # column";return null; }
                if(OneCell) { try { c=row.get_accChild(DocIndex+1); } catch(Exception) { c=null; } cell=c as Accessibility.IAccessible; }
                else { var cells=Msaa.Children(row,80);try { if(DocIndex<cells.Count) { c=cells[DocIndex];cell=c as Accessibility.IAccessible; } } finally { foreach(var k in cells) if(!Object.ReferenceEquals(k,c)) Msaa.Release(k); } }
                if(cell==null||Msaa.NameOf(row,cell).Trim()!=DocColumn) { why="not the Document # cell";return null; }
                string d=Order.Norm(Msaa.ValueOf(row,cell));if(d!=x.Doc) { why="Repair Order "+(d.Length>0?d:"(none)")+" is there now";return null; }
                keep=true;return row;
            } finally { Msaa.Release(c);if(!keep) Msaa.Release(o);if(fresh!=null&&!Object.ReferenceEquals(fresh,root)) Msaa.Release(fresh);Msaa.Release(root); }
        }
        // Every row's place as last looked at, as one string: what changes when the list moves.
        internal string Signature() {
            var b=new StringBuilder();b.Append(First).Append('/').Append(Last).Append(':');
            foreach(var x in Lines) b.Append(x.Placed?x.Top.ToString(CultureInfo.InvariantCulture):"-").Append(',');
            return b.ToString();
        }
        // A row wholly in view, nearest the middle of the view (where a click only selects a row).
        internal Line NearestMiddle(Native.Rect box) {
            int mid=(box.Top+box.Bottom)/2;Line best=null;
            for(int i=Math.Max(0,First);First>=0&&i<=Last;i++) { var x=Lines[i];if(x.Placed&&(best==null||Math.Abs(x.Top+x.Height/2-mid)<Math.Abs(best.Top+best.Height/2-mid))) best=x; }
            return best;
        }
        // The wanted row: still that document (its cell read again), its state, its values, selected.
        internal bool TargetStill() { var x=TargetLine;return x!=null&&Order.Norm(Msaa.ValueOf(x.Row,x.Cell))==x.Doc; }
        internal int TargetState() { var x=TargetLine;return x==null?-1:Msaa.StateOf(table,x.Row); }
        // 2.6.5: what the wanted row offers ("Activate", or "" once it is the active row); null: can't be read.
        internal string TargetAction() { var x=TargetLine;string a;return x!=null&&Msaa.TryAction(table,x.Row,out a)?a.Trim():null; }
        internal void SelectTarget() { var x=TargetLine;if(x!=null) Msaa.SelectChild(table,x.Row); }
        internal RoListRow TargetRow() {
            var x=TargetLine;if(x==null) return null;
            var cells=Msaa.Children(x.Row,80);
            try {
                Func<string,string> cell=delegate(string name) { int ci;return columns!=null&&name.Length>0&&columns.TryGetValue(name,out ci)&&ci<cells.Count?Order.Clean(Msaa.ValueOf(x.Row,cells[ci])):""; };
                return new RoListRow {doc=x.Doc,date=cell("Order Date"),name=cell("Name"),total=cell("Doc Total"),shipVia=cell("Ship Via"),comment=cell("Comment"),by=cell("Written By"),status=cell("Status"),po=poColumn.Length>0?cell(poColumn):null};
            } finally { foreach(var c in cells) Msaa.Release(c); }
        }
        public void Dispose() {
            foreach(var o in owned) Msaa.Release(o);
            owned.Clear();Lines.Clear();
            if(table!=null&&!Object.ReferenceEquals(table,client)) Msaa.Release(table);
            Msaa.Release(client);table=null;client=null;
        }
    }

    // 2.6.7: a Repair Order window's number and PO# (null when they can't be read), read without typing or
    // pressing anything: the words of its labels (COSTAR's), then only the box beside the RepairOrder label
    // and the box under PO#. For the phone's request that closes a Repair Order left open in COSTAR first
    // (RoEngine.CloseFirst): which one it was, and whether it is an online order's.
    internal static class RoPeek {
        // 2.9.6: NoNumber: the box beside the RepairOrder label was read and is empty (a new Repair Order, never saved:
        // the 28 Oct maps of phone jobs being entered; every Repair Order opened from Work-in-Progress shows its number).
        internal sealed class Seen { internal string Doc,Po;internal bool NoNumber; }
        internal static Seen Read(IntPtr window) {
            var s=new List<ControlInfo>();
            try {
                Native.Rect rb;if(!Native.GetWindowRect(window,out rb)) return new Seen();
                // COSTAR answering at once, or nothing is read (as the runner's reads: a busy COSTAR isn't
                // asked again and again); the first read that fails ends the reading.
                UIntPtr answer;if(Native.SendNull(window,0,UIntPtr.Zero,IntPtr.Zero,0x0002,250,out answer)==IntPtr.Zero) return new Seen();
                uint owner=Native.Pid(window);var handles=new List<IntPtr>();bool failed=false;
                Native.EnumChildWindows(window,delegate(IntPtr h,IntPtr unused) { if(Native.Pid(h)==owner&&Native.IsWindowVisible(h)) handles.Add(h);return handles.Count<4000; },IntPtr.Zero);
                foreach(var h in handles) {
                    Native.Rect box;if(!Native.GetWindowRect(h,out box)) continue;
                    var c=new ControlInfo {Handle=h.ToInt64(),Root=window.ToInt64(),Parent=Native.GetParent(h).ToInt64(),Class=Native.Class(h),Style=Native.GetWindowLong(h,-16),Visible=true,Enabled=Native.IsWindowEnabled(h),
                        Bounds=new[]{box.Left,box.Top,box.Right-box.Left,box.Bottom-box.Top},RelativeBounds=new[]{box.Left-rb.Left,box.Top-rb.Top,box.Right-box.Left,box.Bottom-box.Top},TextState="not-read"};
                    c.Password=c.Class.IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)>=0&&(c.Style&0x20)!=0;
                    string t;
                    if(c.Static&&!failed) { if(Native.TryText(h,out t)) { c.Text=t;c.TextState="read"; } else failed=true; }
                    s.Add(c);
                }
                if(failed) return new Seen();
            } catch(Exception) { return new Seen(); }
            return Find(s,delegate(ControlInfo c) { string t;return c.TextState=="read"?c.Text:!c.Password&&Native.TryText(new IntPtr(c.Handle),out t)?t:null; });
        }
        // The number beside the RepairOrder label (a label or a box: Runner.NumberBox) and the box under PO#.
        // text: a control's words (read on demand).
        internal static Seen Find(List<ControlInfo> s,Func<ControlInfo,string> text) {
            var seen=new Seen();
            try { var box=Runner.NumberBox(s);if(box!=null) { string raw=text(box),t=Order.Clean(raw);if(Regex.IsMatch(t,@"^\d{4,}$")) seen.Doc=t;else if(raw!=null&&t.Length==0) seen.NoNumber=true; } } catch(InvalidOperationException) { }
            try { var box=Selectors.Under(s,Selectors.Label(s,"PO#",0));string t=text(box);if(t!=null) seen.Po=Order.Clean(t); } catch(InvalidOperationException) { }
            return seen;
        }
    }
    // When the list must be searched (COSTAR reading its Work-in-Progress again) before a Repair Order is
    // opened from it (2.6.1): when it shows nothing, when the Repair Order isn't in it, or when it may be
    // listed but finished meanwhile: Order Check's recent copy (read with Search) doesn't have it, or there
    // is no recent copy that has it and nobody pressed Search in this COSTAR for 10 minutes.
    internal static class WipSearch {
        internal static readonly TimeSpan Trusted=TimeSpan.FromMinutes(10);
        internal static bool Needed(bool empty,bool found,bool? inRecentCopy,TimeSpan? sinceSearch) {
            if(empty||!found||inRecentCopy==false) return true;
            if(inRecentCopy==true) return false;
            return sinceSearch==null||sinceSearch.Value>Trusted;
        }
        static readonly Dictionary<string,long> last=new Dictionary<string,long>(StringComparer.Ordinal);
        static readonly Stopwatch clock=Stopwatch.StartNew();   // not the wall clock (it can be set back)
        static string Key(CostarInstance t) { return t.Pid.ToString(CultureInfo.InvariantCulture)+":"+t.Started.ToString(CultureInfo.InvariantCulture); }
        internal static void Pressed(CostarInstance t) { lock(last) last[Key(t)]=clock.ElapsedMilliseconds; }
        internal static TimeSpan? Since(CostarInstance t) { long at;lock(last) return last.TryGetValue(Key(t),out at)?TimeSpan.FromMilliseconds(clock.ElapsedMilliseconds-at):(TimeSpan?)null; }
    }

    // What an open does on the screen while it brings a row into view (2.6.1): COSTAR's own list
    // (CostarWipScreen), or a made-up one in the self-tests.
    internal interface IWipScreen {
        Native.Rect Box();                    // the list's place on the screen
        bool ListAt(Native.Point p);          // the list itself is under that point
        bool ListHasKeyboard();               // the list itself (not a box inside it) has the keyboard
        string KeyboardAt();                  // what has the keyboard, for the day log (a window's class)
        void Ready();                         // nobody used the PC since the open began; COSTAR in front
        void Click(Native.Point p);           // checked again just before: no key held, nobody, the list there
        void PastClick();                     // waits until a click now can't make a double click with the last
        void Wheel(Native.Point p,int notches);
        void GiveKeyboard();                  // 2.6.5: the keyboard to the list directly (no click)
        bool Activate(WipScan scan,string doc); // 2.6.5: the wanted row made the active row directly (its "Activate")
        void Say(string words);
        WipScan Scan(string doc);             // the list read again
        string DocAt(Native.Point p,WipScan scan); // the number accessibility says is at that point (null: can't tell)
    }
    internal sealed class CostarWipScreen : IWipScreen {
        readonly IntPtr main,grid;readonly RoOpenWatch watch;readonly string doc;readonly Func<bool> cancelled;readonly Action<string> say;
        readonly Stopwatch sinceClick=new Stopwatch();
        // 2.9.8: the row's known place (0: none): the list is read again at that place only, in full when it isn't there.
        internal int Hint;internal RoOpenTimes Times;
        internal CostarWipScreen(IntPtr main,IntPtr grid,RoOpenWatch watch,string doc,Func<bool> cancelled,Action<string> say) { this.main=main;this.grid=grid;this.watch=watch;this.doc=doc;this.cancelled=cancelled;this.say=say; }
        public Native.Rect Box() { Native.Rect box;Order.Require(Native.GetWindowRect(grid,out box),"COSTAR's Work-in-Progress list is gone.");return box; }
        public bool ListAt(Native.Point p) { return Native.WindowFromPoint(p)==grid; }
        public bool ListHasKeyboard() { return Native.Focus(main)==grid; }
        public string KeyboardAt() { var f=Native.Focus(main);return f==IntPtr.Zero?"nothing in COSTAR":Native.Class(f)+(RoWip.Inside(f,grid)?" inside the list":""); }
        public void Ready() { Order.Require(!cancelled(),"Stopped.");RoWip.Quiet(watch,doc);RoWip.Front(main,cancelled); }
        public void Click(Native.Point p) { PastClick();Native.NoModifiers();RoWip.Quiet(watch,doc);Order.Require(ListAt(p),"COSTAR's Work-in-Progress list is covered.");Native.ClickNow(p);sinceClick.Restart(); }
        public void PastClick() { if(!sinceClick.IsRunning) return;int wait=Native.DoubleClickMs()+60-(int)sinceClick.ElapsedMilliseconds;if(wait>0) Thread.Sleep(Math.Min(wait,2000)); }
        public void Wheel(Native.Point p,int notches) { Native.NoModifiers();RoWip.Quiet(watch,doc);Order.Require(ListAt(p),"COSTAR's Work-in-Progress list is covered.");Native.WheelStepsNow(p,notches); }
        public void GiveKeyboard() { RoWip.Quiet(watch,doc);Direct.Focus(grid,3000,cancelled); }
        // The row looked up afresh and its "Activate" pressed on a thread of its own, with the last look (COSTAR's
        // main window in front and free, nobody at the PC) just before it (RoWip.Activated: what came of it).
        public bool Activate(WipScan scan,string wanted) {
            RoWip.Quiet(watch,doc);
            var act=Direct.Act(delegate(out object child,out string why) { child=null;return scan.FreshTargetRow(out why); },delegate {
                if(Native.GetForegroundWindow()!=main||!Native.IsWindowEnabled(main)) return RoWip.MainNotFree;
                if(Native.UserActiveWithin(1500)) return Direct.PcInUse;
                return null;
            });
            return RoWip.Activated(act,Direct.Went(act,5000,400),watch,wanted);
        }
        public void Say(string words) { say(words); }
        public WipScan Scan(string wanted) {
            if(Hint>0) {
                Native.Rect box;var g=grid;
                var s=Native.GetWindowRect(grid,out box)?WipScan.FromHint(delegate { return Msaa.FromWindow(g); },box,wanted,Hint):null;
                if(s!=null) { Hint=s.TargetLine.Pos;return s; }
                Hint=0;if(Times!=null) Times.Fallbacks++;
            }
            return WipScan.Take(grid,wanted);
        }
        public string DocAt(Native.Point p,WipScan scan) { return RoWip.DocAt(p,scan.DocIndex); }
    }

    // 2.9.0 (wholesale orders): the list a document is opened from, and the windows it opens. Work-in-Progress opens
    // Repair Orders ("RepairOrder  Branch 11 ..."), as always; COSTAR Sydney's "Orders yet to be filled" opens wholesale
    // Orders ("Order  Branch 1 ..."), for the wholesale dry run. OrderCheckCopy: Order Check's recent read of the list
    // tells whether the document is listed (Work-in-Progress only; never recorded as a Work-in-Progress Search either).
    internal sealed class RoListKind {
        internal readonly string Title;internal readonly bool OrderCheckCopy;readonly Func<string,bool> isWindow;readonly Func<string,int,bool> inBranch;
        RoListKind(string title,bool copy,Func<string,bool> window,Func<string,int,bool> branch) { Title=title;OrderCheckCopy=copy;isWindow=window;inBranch=branch; }
        static readonly Regex OrderWindow=new Regex(@"^Order\s+Branch\s+(\d{1,3})(?=\s|$)",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant);
        internal static readonly RoListKind Wip=new RoListKind("Work-in-Progress",true,c=>c.StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase),Branches.OrderTitle);
        internal static readonly RoListKind Wholesale=new RoListKind("Orders yet to be filled",false,c=>OrderWindow.IsMatch(c),WholesaleBranch);
        static bool WholesaleBranch(string caption,int branch) {
            var m=OrderWindow.Match(caption??"");int n;
            return branch>0&&m.Success&&Int32.TryParse(m.Groups[1].Value,NumberStyles.Integer,CultureInfo.InvariantCulture,out n)&&n==branch;
        }
        internal bool IsWindow(string caption) { return isWindow(caption??""); }
        internal bool InBranch(string caption,int branch) { return inBranch(caption??"",branch); }
    }

    // COSTAR's Work-in-Progress list in the selected COSTAR: read it, find a document in it, open it.
    // Reads through accessibility (as Order Check does); the only input is Search (pressed through
    // accessibility, and only when the row isn't listed), the mouse wheel over the list (with one click on
    // a row when the list doesn't have the keyboard), and the double click (or Enter) that opens a row.
    internal static class RoWip {
        static TempeOrderCheck.WipHandles Screen(CostarInstance t,out IntPtr main) { return Screen(t,RoListKind.Wip,out main); }
        static TempeOrderCheck.WipHandles Screen(CostarInstance t,RoListKind kind,out IntPtr main) {
            main=CostarWindows.Main(t);
            var h=TempeOrderCheck.WipScreen.Locate(main,kind.Title);
            Order.Require(h!=null,"COSTAR "+t.Label+" isn't showing "+kind.Title+". Leave it on "+kind.Title+".");
            return h;
        }
        static string Money(decimal total) { return "$"+total.ToString("0.00",CultureInfo.InvariantCulture); }
        static RoListRow Row(TempeOrderCheck.WipRow r) {
            return new RoListRow {doc=r.Doc,date=r.OrderDateText,name=r.Name,total=r.HasTotal?Money(r.Total):"",shipVia=r.ShipVia,comment=r.Comment,by=r.By,po=r.Po,status=r.Status};
        }
        // The list as COSTAR shows it now. search: press Search first (the newest list). clear (2.6.11): COSTAR's
        // own search boxes emptied first (its Clear button), so a filter left on the PC doesn't hide Repair Orders.
        internal static RoList ReadList(CostarInstance t,bool search,bool clear,Func<bool> cancelled) {
            IntPtr main;var h=Screen(t,out main);
            var notes=new List<string>();
            if(clear&&search) {
                string boxes;string before=KnownFilter(h,cancelled,out boxes);
                if(before==null) notes.Add("COSTAR didn't answer when its search boxes were looked at, so its filter wasn't cleared: try again");
                else if(before.Length==0) notes.Add("COSTAR's Work-in-Progress wasn't filtered");
                else if(h.Clear==IntPtr.Zero||h.Search==IntPtr.Zero) notes.Add("COSTAR's filter ("+before+") wasn't cleared: its "+(h.Clear==IntPtr.Zero?"Clear":"Search")+" button wasn't found. Clear it at the PC");
                else {
                    string why=ClearFilter(h,cancelled);
                    AppLog.Note("ro_filter_cleared",(why==null?"for the list: ":"not cleared for the list ("+why+"): ")+boxes);
                    notes.Add(why==null?"COSTAR's filter cleared ("+before+")":"COSTAR's filter ("+before+") wasn't cleared: "+why+". Clear it at the PC");
                }
            }
            if(search&&h.Search!=IntPtr.Zero) { PressSearch(h,cancelled);WipSearch.Pressed(t); }
            else notes.Add(search?"COSTAR's Search button wasn't found, so the list is as COSTAR showed it":"read as COSTAR showed it (a Repair Order is open there)");
            var reader=new TempeOrderCheck.GridReader();
            var rows=reader.Read(h.Grid);
            string unused;string filter=KnownFilter(h,cancelled,out unused);
            if(filter==null) notes.Insert(0,"COSTAR didn't answer when its search boxes were looked at (the list may be filtered)");
            else if(filter.Length>0) notes.Insert(0,"COSTAR's Work-in-Progress is filtered ("+filter+")");
            return new RoList {rows=rows.Select(Row).ToList(),readUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture),source="costar",note=String.Join("; ",notes.ToArray())};
        }
        // Order Check's last read of its own WIP window, if it is recent: the list when COSTAR is busy.
        internal static RoList FromOrderCheck(TimeSpan maxAge) {
            var store=TempeOrderCheck.Hosting.Store;if(store==null) return null;
            Dictionary<string,object> root;
            try { root=new System.Web.Script.Serialization.JavaScriptSerializer {MaxJsonLength=16*1024*1024}.DeserializeObject(Encoding.UTF8.GetString(store.Snapshot())) as Dictionary<string,object>; }
            catch(Exception) { return null; }
            if(root==null||Field(root,"state")!="ok") return null;
            DateTimeOffset at;
            if(!DateTimeOffset.TryParse(Field(root,"readAt"),CultureInfo.InvariantCulture,DateTimeStyles.None,out at)||DateTimeOffset.Now-at>maxAge) return null;
            object rowsValue;var rows=root.TryGetValue("rows",out rowsValue)?rowsValue as System.Collections.IEnumerable:null;
            if(rows==null) return null;
            var list=new List<RoListRow>();
            foreach(object o in rows) {
                var r=o as Dictionary<string,object>;if(r==null) continue;
                decimal total;bool has=Field(r,"hasTotal")=="True"&&Decimal.TryParse(Field(r,"total"),NumberStyles.Number,CultureInfo.InvariantCulture,out total);
                list.Add(new RoListRow {doc=Field(r,"doc"),date=Field(r,"orderDateText"),name=Field(r,"name"),total=has?Money(Decimal.Parse(Field(r,"total"),NumberStyles.Number,CultureInfo.InvariantCulture)):"",
                    shipVia=Field(r,"shipVia"),comment=Field(r,"comment"),by=Field(r,"by"),po=Field(r,"po"),status=Field(r,"status")});
            }
            string filter=Field(root,"filter");
            return new RoList {rows=list,readUtc=at.UtcDateTime.ToString("o",CultureInfo.InvariantCulture),source="order-check",note="Order Check's list from "+at.ToString("HH:mm",CultureInfo.InvariantCulture)+(filter.Length>0?" (filtered: "+filter+")":"")};
        }
        // Whether Order Check's copy from the last 3 minutes lists `doc` (null: no such copy). A filtered copy
        // proves nothing either way.
        internal static bool? InRecentCopy(string doc) {
            var copy=FromOrderCheck(TimeSpan.FromMinutes(3));
            if(copy==null||copy.note.Contains("(filtered:")) return null;
            string want=Order.Norm(doc);
            return copy.rows.Any(r=>Order.Norm(r.doc)==want);
        }
        static string Field(Dictionary<string,object> d,string key) { object v;return d!=null&&d.TryGetValue(key,out v)&&v!=null?Convert.ToString(v,CultureInfo.InvariantCulture):""; }
        // Search through accessibility on its own thread (COSTAR may take seconds), then a list that
        // holds still (two equal row counts).
        // 2.6.11: COSTAR's Clear (Alt+L) pressed through accessibility, as Search is; null when its search boxes
        // then read empty (within 3 s), else why not (for the person; never the search's words). Nothing else is
        // pressed. ready: the caller's own look, on every pass of the wait and just before the press (the open's:
        // nobody at the PC since it began, which stops the open).
        internal static string ClearFilter(TempeOrderCheck.WipHandles h,Func<bool> cancelled,Action ready=null) {
            if(h.Clear==IntPtr.Zero) return "COSTAR's Clear button wasn't found";
            // Never while someone is typing in those boxes: a quiet moment (nobody at the PC for 3 s) waited for, up to
            // ClearQuietWaitMs; none comes, nothing is pressed.
            var quiet=Stopwatch.StartNew();
            while(Native.UserActiveWithin(RoEngine.CloseQuietSeconds*1000)) {
                Order.Require(!cancelled(),"Stopped.");
                if(ready!=null) ready();
                if(quiet.ElapsedMilliseconds>=ClearQuietWaitMs) { AppLog.Note("ro_filter_clear_failed","someone is using the PC: "+Native.LastInputSeen());return "someone is using the PC"; }
                Thread.Sleep(200);
            }
            Order.Require(!cancelled(),"Stopped.");
            if(ready!=null) ready();
            string error=PressButton(h.Clear,5000);
            // Not answered: it may still go, so nothing more is read or pressed (as for Search).
            Order.Require(error==null||!error.StartsWith("COSTAR didn't answer",StringComparison.Ordinal),"COSTAR didn't answer its Work-in-Progress Clear within 5 s. Is a window open in COSTAR?");
            if(error!=null) { AppLog.Note("ro_filter_clear_failed",error);return "COSTAR's Clear couldn't be pressed"; }
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<3000) {
                Order.Require(!cancelled(),"Stopped.");
                if(TempeOrderCheck.WipScreen.FilterTextKnown(h)=="") return null;
                Thread.Sleep(200);
            }
            AppLog.Note("ro_filter_clear_failed","the search boxes didn't read empty within 3 s of Clear");
            return "COSTAR's search boxes didn't empty after Clear";
        }
        // What COSTAR's search boxes hold, looked at again for up to 2 s while a box doesn't answer; null: still
        // unknown. boxes: the filled boxes' names alone (for the day log).
        internal static string KnownFilter(TempeOrderCheck.WipHandles h,Func<bool> cancelled,out string boxes) {
            var timer=Stopwatch.StartNew();
            while(true) {
                string f=TempeOrderCheck.WipScreen.FilterTextKnown(h,out boxes);
                if(f!=null||timer.ElapsedMilliseconds>=2000) return f;
                Order.Require(!cancelled(),"Stopped.");
                Thread.Sleep(200);
            }
        }
        internal const int ClearQuietWaitMs=10000;
        // A button's accessibility default action (Press) on a thread of its own; null, or why it couldn't be.
        static string PressButton(IntPtr button,int ms) {
            string error=null;
            var th=new Thread(delegate() {
                Accessibility.IAccessible b=null;
                try { b=Msaa.FromWindow(button);b.accDoDefaultAction(0); }
                catch(Exception e) { error=e.Message; }
                finally { Msaa.Release(b); }
            });
            th.IsBackground=true;th.SetApartmentState(ApartmentState.MTA);th.Start();
            if(!th.Join(ms)) return "COSTAR didn't answer the press within "+(ms/1000)+" s";
            return error;
        }
        internal static void PressSearch(TempeOrderCheck.WipHandles h,Func<bool> cancelled) {
            string error=PressButton(h.Search,20000);
            Order.Require(error==null||!error.StartsWith("COSTAR didn't answer",StringComparison.Ordinal),"COSTAR didn't finish its Work-in-Progress search within 20 s. Is a window open in COSTAR?");
            Order.Require(error==null,"Couldn't press Search in COSTAR's Work-in-Progress: "+error);
            var reader=new TempeOrderCheck.GridReader();var timer=Stopwatch.StartNew();int last=-2;
            while(timer.ElapsedMilliseconds<8000) {
                Order.Require(!cancelled(),"Stopped.");
                Thread.Sleep(400);
                int count=reader.TableRowCount(h.Grid);
                if(count>=0&&count==last) return;
                last=count;
            }
        }
        // In view and clickable: the Document # cell inside the list, below its column headings and clear of
        // its edges (its scroll bars are drawn inside it), and the list itself under that point.
        internal static bool InView(IWipScreen screen,WipScan scan,WipScan.Line s) {
            if(s==null||!s.Placed||s.Height<=4||s.Width<=4) return false;
            var box=screen.Box();var p=Point(s);
            return s.Top>=Math.Max(box.Top+2,scan.ViewTop(box))&&s.Top+s.Height<=box.Bottom-20&&p.X>box.Left+2&&p.X<box.Right-24&&screen.ListAt(p);
        }
        internal static Native.Point Point(WipScan.Line s) { return new Native.Point {X=s.Left+Math.Min(s.Width/2,40),Y=s.Top+s.Height/2}; }
        internal static void Front(IntPtr main,Func<bool> cancelled) {
            Native.BringToFront(main);var timer=Stopwatch.StartNew();
            while(!cancelled()&&Native.GetForegroundWindow()!=main&&timer.ElapsedMilliseconds<2000) Thread.Sleep(25);
            Order.Require(!cancelled(),"Stopped.");
            Order.Require(Native.GetForegroundWindow()==main&&Native.IsWindowEnabled(main),"COSTAR's main window couldn't be brought in front (another window is open in COSTAR?).");
        }
        internal static bool Inside(IntPtr h,IntPtr parent) { for(var p=h;p!=IntPtr.Zero;p=Native.GetParent(p)) if(p==parent) return true;return false; }
        internal const string MainNotFree="COSTAR's main window isn't in front and free";
        // 2.6.5: what came of the row's "Activate" (went: Direct.Went's answer). True: pressed. False: not pressed or
        // failed (activating a row opens nothing, so the mouse way may follow). The last look's no stops the open
        // there, as Quiet does: someone at the PC (marked, so a window that opens meanwhile is never taken for
        // the helper's), or COSTAR's main window not in front and free.
        internal static bool Activated(Direct.Pending act,string went,RoOpenWatch watch,string doc) {
            if(went=="pressed") return true;
            string refused=act.Refused;
            if(refused==Direct.PcInUse) {
                if(watch!=null) watch.UserActive=true;
                AppLog.Note("ro_user_active",doc+": at the last look before Activate, "+Native.LastInputSeen());
                throw new InvalidOperationException("Someone used the COSTAR PC while Repair Order "+doc+" was being opened, so the helper stopped there (nothing more clicked or pressed). Try again when the PC is free.");
            }
            if(refused!=null) throw new InvalidOperationException("COSTAR's main window wasn't in front and free when Repair Order "+doc+" was to be opened (a COSTAR window open?). Nothing was pressed: check COSTAR, then try again.");
            AppLog.Note("ro_open_direct",doc+": its row wasn't made the active one ("+(went=="failed"?act.PressError:act.FindError)+")");
            return false;
        }
        // 2.6.5 (no mouse): the wanted row made the list's selected row and its active row through accessibility
        // (selected, then its "Activate" pressed with the last look just before it; it may stay out of view:
        // Enter doesn't need it in view), and the list given the keyboard directly. True when a read with new
        // objects then shows that row still that Repair Order, the active row (Enter opens the active row: it
        // carries the keyboard's mark, or it alone offers no "Activate") and the only selected one, with the list
        // holding the keyboard (Tommy, 27 Oct: Enter opens it). False: the mouse way (Reveal, the double click).
        internal static bool SelectForEnter(IWipScreen screen,ref WipScan scan,string doc,RoOpenTimes times) {
            var clock=Stopwatch.StartNew();
            try {
                for(int attempt=1;attempt<=2;attempt++) {
                    screen.Ready();
                    scan.SelectTarget();
                    // Its "Activate" pressed only while it offers it (the selection may have made it the active row
                    // already: then there is nothing to press).
                    if(scan.TargetAction()!=""&&!screen.Activate(scan,doc)) return false;
                    Thread.Sleep(150);
                    if(!screen.ListHasKeyboard()) {
                        screen.GiveKeyboard();
                        var wait=Stopwatch.StartNew();
                        while(!screen.ListHasKeyboard()&&wait.ElapsedMilliseconds<800) Thread.Sleep(40);
                        if(!screen.ListHasKeyboard()) { AppLog.Note("ro_open_direct",doc+": the list didn't take the keyboard ("+screen.KeyboardAt()+")");return false; }
                    }
                    ReadAgain(screen,ref scan,doc,times);
                    if(scan.TargetStill()&&scan.TargetActive()&&scan.OnlyTargetSelected()&&screen.ListHasKeyboard()) { times.How="made the active row directly";times.Direct=true;times.SelectTries=attempt;return true; }
                }
                AppLog.Note("ro_open_direct",doc+": its row didn't become the active and only selected one");
                return false;
            } finally { times.RevealMs+=clock.ElapsedMilliseconds; }
        }
        // Brings the wanted row into view (2.6.1): nothing when it is in view already; else it is selected
        // through accessibility (the list may scroll to it by itself); else the mouse wheel over the list.
        // The wheel goes a notch at first (to see how many rows a notch moves), then as many notches a turn as
        // bring the row to the middle of the view (WipScroll.Turn: 20 at most, never past the list's end).
        // After each turn the list must have moved by exactly all of it and held still before anything else
        // happens, so no notch is ever still on its way (COSTAR, or the remote desktop, can be slow to pass
        // them on); if it hasn't within its time, or moved otherwise, the helper stops there and opens
        // nothing. The wheel is turned only while the list itself has the keyboard (one click on a row in view
        // gives it), so it can't turn anything else of COSTAR's. Returns whether the list may have moved.
        internal static bool Reveal(IWipScreen screen,ref WipScan scan,string doc,RoOpenTimes times) {
            var clock=Stopwatch.StartNew();
            try {
                if(InView(screen,scan,scan.TargetLine)) { times.How="in view";return false; }
                scan.SelectTarget();Thread.Sleep(150);
                if(!scan.Places(screen.Box())) ReadAgain(screen,ref scan,doc,times);
                if(InView(screen,scan,scan.TargetLine)) { times.How="in view once selected";return true; }
                screen.Say("Scrolling COSTAR's Work-in-Progress list to Repair Order "+doc+".");
                var box=screen.Box();
                var center=new Native.Point {X=(box.Left+box.Right)/2,Y=(box.Top+box.Bottom)/2};
                int perNotch=0,clicks=0;bool fresh=false;
                for(int step=0;step<WipScroll.MaxSteps&&clock.ElapsedMilliseconds<WipScroll.MaxRevealMs;step++) {
                    screen.Ready();
                    Order.Require(screen.ListAt(center),"COSTAR's Work-in-Progress list is covered.");
                    if(!screen.ListHasKeyboard()) {
                        Order.Require(clicks<2,"COSTAR's Work-in-Progress list doesn't keep the keyboard, so the list wasn't scrolled. Open Repair Order "+doc+" by hand.");
                        var any=scan.NearestMiddle(box);
                        Order.Require(any!=null&&InView(screen,scan,any),"COSTAR's Work-in-Progress list shows no row to click, so it wasn't scrolled. Open Repair Order "+doc+" by hand.");
                        // Its Document # cell: a click there only selects the row.
                        screen.Click(Point(any));clicks++;times.Clicked=true;
                        var waiting=Stopwatch.StartNew();
                        while(!screen.ListHasKeyboard()&&waiting.ElapsedMilliseconds<1000) Thread.Sleep(50);
                        if(!screen.ListHasKeyboard()) {
                            string at=screen.KeyboardAt();AppLog.Note("ro_wip_keyboard","after a click on a row: "+at);
                            throw new InvalidOperationException("COSTAR's Work-in-Progress list didn't take the keyboard ("+at+" has it), so it wasn't scrolled. Open Repair Order "+doc+" by hand.");
                        }
                    }
                    int? from=scan.ScrollRow(box);
                    Order.Require(from!=null,"COSTAR's Work-in-Progress list shows no row in view, so it wasn't scrolled. Open Repair Order "+doc+" by hand.");
                    int rows=(scan.First+scan.Last)/2-scan.Target;       // + : the row is above the middle (wheel up)
                    if(rows==0) break;
                    // room 0: the row is at an edge of the view, partly hidden (one notch, if the list still goes).
                    bool up=rows>0;int room=scan.Room(up);
                    int notches=WipScroll.Turn(Math.Abs(rows),perNotch,room);
                    int expect=WipScroll.Expect(notches,perNotch,room);
                    screen.Wheel(center,up?notches:-notches);times.Wheels++;times.Notches+=notches;
                    int moved=AwaitMoved(screen,ref scan,doc,times,from.Value,up?notches:-notches,expect,800+150*notches,ref fresh);
                    // Not all of it seen with these objects: once more with new ones (old ones may keep answering
                    // with the places they had); from then on every look is with new objects.
                    if(moved<0&&!fresh) { fresh=true;moved=AwaitMoved(screen,ref scan,doc,times,from.Value,up?notches:-notches,expect,0,ref fresh); }
                    if(moved<0&&room==0) break;
                    Order.Require(moved>=0,"COSTAR's Work-in-Progress list didn't scroll as far as it was turned (it may still be on its way). Nothing was opened; try again.");
                    int next=WipScroll.Accounted(perNotch,moved,notches,room);
                    Order.Require(next>=0,"COSTAR's Work-in-Progress list scrolled "+moved+" rows for "+notches+" wheel notches, not what they should move. Nothing was opened; try again.");
                    perNotch=next;
                    box=screen.Box();
                    if(InView(screen,scan,scan.TargetLine)) { times.How=times.Wheels==1?"brought into view with one wheel turn":"brought into view with "+times.Wheels+" wheel turns";return true; }
                }
                throw new InvalidOperationException("Repair Order "+doc+"'s row couldn't be brought into view in COSTAR's Work-in-Progress list. Open it by hand.");
            } finally { times.RevealMs+=clock.ElapsedMilliseconds; }
        }
        // The point to double-click (2.6.1), after the row is in view: first everything that takes time
        // before the click (`beforeLastLook`: COSTAR in front, its windows looked at; the double-click time
        // waited out), then the last looks: when the list moved or was searched, read again with new objects
        // and watched holding still for 200 ms; the row at that place among the list's children looked at with
        // new objects (still this Repair Order, at the same place); its cell read twice 150 ms apart.
        internal static Native.Point Aim(IWipScreen screen,ref WipScan scan,string doc,RoOpenTimes times,bool searched,Action beforeLastLook) {
            bool moved=Reveal(screen,ref scan,doc,times);
            if(beforeLastLook!=null) beforeLastLook();
            screen.PastClick();
            var box=screen.Box();
            if(moved||searched) {
                ReadAgain(screen,ref scan,doc,times);
                string places=scan.Signature();Thread.Sleep(200);scan.Places(box);
                Order.Require(scan.Signature()==places,"COSTAR's Work-in-Progress list was still moving. Nothing was opened; try again.");
            }
            scan.PlaceTarget();
            string fresh=scan.FreshCheck();
            if(fresh!=null) { ReadAgain(screen,ref scan,doc,times);scan.PlaceTarget();fresh=scan.FreshCheck(); }
            Order.Require(fresh==null,"Repair Order "+doc+"'s row in COSTAR's Work-in-Progress list didn't look the same when looked at again ("+fresh+"). Nothing was opened; try again.");
            var x=scan.TargetLine;int top=x.Top;bool placed=x.Placed;
            Thread.Sleep(150);scan.PlaceTarget();
            Order.Require(x.Placed==placed&&x.Top==top&&scan.TargetStill()&&InView(screen,scan,x),"Repair Order "+doc+"'s row moved in the list. Nothing was opened; try again.");
            return Point(x);
        }
        // Just before the double click: what accessibility finds at the point is not another Repair Order (it
        // may not tell: then the looks before stand).
        internal static void CheckPoint(IWipScreen screen,Native.Point point,WipScan scan,string doc,RoOpenTimes times) {
            string under=screen.DocAt(point,scan);times.Hit=under==null?"can't tell":under==doc?"this one":"another";
            Order.Require(under==null||under==doc,"Accessibility found Repair Order "+under+" under the point, not "+doc+". Nothing was opened; try again.");
        }
        // The Repair Order number accessibility finds at a point: a Document # cell there (or a row, through its
        // Document # cell); null when it can't tell (it names the list itself, or something else).
        internal static string DocAt(Native.Point p,int docIndex) {
            object child;var a=Msaa.FromPoint(p,out child);Accessibility.IAccessible cell=null;object c=null;
            try {
                if(a==null) return null;
                int id=child is int?(int)child:0;
                if(id!=0) {
                    // A simple child: its own role, name and value.
                    object r=null;try { r=a.get_accRole(id); } catch(Exception) { r=null; }
                    if(!(r is int)||(int)r!=29) return null;
                    string name="",value="";try { name=Convert.ToString(a.get_accName(id),CultureInfo.InvariantCulture)??"";value=Convert.ToString(a.get_accValue(id),CultureInfo.InvariantCulture)??""; } catch(Exception) { return null; }
                    return name.Trim()=="Document #"?Order.Norm(value):null;
                }
                int role=Msaa.Role(a);
                if(role==29) return Msaa.NameOf(null,a).Trim()=="Document #"?Order.Norm(Msaa.ValueOf(null,a)):null;
                if(role==Msaa.RoleRow&&docIndex>=0) {
                    try { c=a.get_accChild(docIndex+1); } catch(Exception) { c=null; }
                    cell=c as Accessibility.IAccessible;
                    return cell!=null&&Msaa.NameOf(a,cell).Trim()=="Document #"?Order.Norm(Msaa.ValueOf(a,cell)):null;
                }
                return null;
            } catch(Exception) { return null; }
            finally { Msaa.Release(c);Msaa.Release(a); }
        }
        // After `notches` wheel notches (+ up, - down) from scroll row `from`: waits until the list has moved
        // at least `expect` rows the way it was turned and then held still for 150 ms, so all of that turn has
        // come through and no notch is still on its way. `limitMs` for that, and a further 1.5 s of stillness
        // short of it means the rest isn't coming. Returns the rows moved, or -1 (not all of it came, or it
        // went the other way). Each look is with the objects of the last read, or (fresh, or once no row has a
        // place any more: the rows were made again) a new read; the list must stay the same list.
        static int AwaitMoved(IWipScreen screen,ref WipScan scan,string doc,RoOpenTimes times,int from,int notches,int expect,int limitMs,ref bool fresh) {
            var timer=Stopwatch.StartNew();var still=Stopwatch.StartNew();string last=null;int count=scan.Lines.Count,target=scan.Target;
            while(timer.ElapsedMilliseconds<limitMs+1500) {
                Thread.Sleep(40);
                var box=screen.Box();
                if(fresh) ReadAgain(screen,ref scan,doc,times);
                else if(!scan.Places(box)) { fresh=true;ReadAgain(screen,ref scan,doc,times); }
                Order.Require(scan.Lines.Count==count&&scan.Target==target,"COSTAR's Work-in-Progress list changed while it was scrolled. Nothing was opened; try again.");
                int? at=scan.ScrollRow(box);if(at==null) continue;
                int delta=at.Value-from;
                if(notches>0?delta>0:delta<0) return -1;
                int moved=Math.Abs(delta);var x=scan.TargetLine;
                string now=at.Value.ToString(CultureInfo.InvariantCulture)+"|"+(x!=null&&x.Placed?x.Top.ToString(CultureInfo.InvariantCulture):"-");
                if(now!=last) { last=now;still.Restart();continue; }
                if(moved>=expect&&still.ElapsedMilliseconds>=150) return moved;
                if(timer.ElapsedMilliseconds>=limitMs&&still.ElapsedMilliseconds>=1500) return -1;
            }
            return -1;
        }
        // The list read again (new objects); the wanted row must still be in it.
        static void ReadAgain(IWipScreen screen,ref WipScan scan,string doc,RoOpenTimes times) {
            scan.Dispose();scan=null;scan=screen.Scan(doc);times.Took(scan);
            Order.Require(scan.Target>=0,"Repair Order "+doc+" went from COSTAR's Work-in-Progress list. Nothing was opened.");
        }
        // Nobody has used the PC since the open began (the helper's own clicks and keys don't count):
        // checked before every click, scroll and key, so nothing goes in under a person's hands.
        internal static void Quiet(RoOpenWatch watch,string doc) {
            if(!Native.UserActiveWithin((int)Math.Min(600000,watch.Clock.ElapsedMilliseconds+1000))) return;
            watch.UserActive=true;
            // 2.6.6: what was seen, for the day log (28 Oct: a stop while COSTAR took 12 s to open one).
            AppLog.Note("ro_user_active",doc+": "+Native.LastInputSeen()+", "+watch.Clock.ElapsedMilliseconds+" ms into the open");
            throw new InvalidOperationException("Someone used the COSTAR PC while Repair Order "+doc+" was being opened, so the helper stopped there (nothing more clicked or pressed). Try again when the PC is free.");
        }
        // 2.9.6: every shown Repair Order window is one left open beside the open (stay; none when null). Pure.
        internal static bool OnlyKept(IEnumerable<long> shown,HashSet<long> stay) { return shown.All(w=>stay!=null&&stay.Contains(w)); }
        // 2.9.6: one kept open beside the open is still there as it was: the same window, of this COSTAR, shown, a Repair
        // Order's.
        internal static bool KeptThere(IntPtr h,int pid) { return Native.IsWindow(h)&&(int)Native.Pid(h)==pid&&Native.IsWindowVisible(h)&&Native.Caption(h).StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase); }
        // 2.9.6: whether one kept open beside the open closed or changed (marked: nothing more is then taken for the open's
        // own, closed or remembered as left open).
        internal static bool KeptChanged(RoOpenWatch watch) {
            if(watch==null||watch.Stay==null||watch.KeptChanged) return watch!=null&&watch.KeptChanged;
            foreach(long w in watch.Stay) if(!KeptThere(new IntPtr(w),watch.StayPid)) { watch.KeptChanged=true;return true; }
            return false;
        }
        // 2.9.6: the open stops (nothing more pressed) when one kept open beside it closed or changed meanwhile: COSTAR may
        // have closed it, or made its window again (it would then look like the open's own).
        internal static void KeptStill(RoOpenWatch watch,string doc) {
            if(!KeptChanged(watch)) return;
            AppLog.Note("ro_beside_changed",doc+": a Repair Order kept open beside it closed or changed during the open");
            throw new InvalidOperationException("A Repair Order kept open in COSTAR closed or changed while Repair Order "+doc+" was being opened. Nothing more was pressed, and nothing was closed: check COSTAR at the PC.");
        }
        // 2.9.4: every top-level window of this COSTAR.
        internal static HashSet<long> TopWindows(CostarInstance t) {
            var set=new HashSet<long>();
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) { if(Native.Pid(w)==t.Pid) set.Add(w.ToInt64());return true; },IntPtr.Zero);
            return set;
        }
        // 2.9.4: a Repair Order form of this branch by its title, with its "RepairOrder" or still without it (a form
        // COSTAR is still opening is titled "Branch 11  Tempe Tyres Tempe"). Pure.
        static readonly Regex FormTitle=new Regex(@"^\s*(?:RepairOrder\s+)?Branch\s+(\d{1,3})(?=\s|$)",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant);
        internal static bool FormOf(string caption,int branch) {
            var m=FormTitle.Match(caption??"");int n;
            return branch>0&&m.Success&&Int32.TryParse(m.Groups[1].Value,NumberStyles.Integer,CultureInfo.InvariantCulture,out n)&&n==branch;
        }
        // 2.9.7: the same for the list's own kind of window: a wholesale Order's form ("Order  Branch 1 ...", or the bare
        // "Branch 1 ..." COSTAR gives it while it's being made), a Repair Order's as above.
        static readonly Regex OrderFormTitle=new Regex(@"^\s*(?:Order\s+)?Branch\s+(\d{1,3})(?=\s|$)",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant);
        internal static bool FormOf(string caption,int branch,RoListKind kind) {
            if(kind!=RoListKind.Wholesale) return FormOf(caption,branch);
            var m=OrderFormTitle.Match(caption??"");int n;
            return branch>0&&m.Success&&Int32.TryParse(m.Groups[1].Value,NumberStyles.Integer,CultureInfo.InvariantCulture,out n)&&n==branch;
        }
        // Every Repair Order window of this COSTAR (2.9.0: or wholesale Order, by the list), shown or not yet (COSTAR
        // may build one before it shows).
        internal static HashSet<long> AllOrders(CostarInstance t,RoListKind kind) {
            CostarWindows.Main(t);var set=new HashSet<long>();
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) { if(Native.Pid(w)==t.Pid&&kind.IsWindow(Native.Caption(w))) set.Add(w.ToInt64());return true; },IntPtr.Zero);
            return set;
        }
        // The shown windows of that kind (Repair Orders: CostarWindows.Orders, as always).
        internal static List<IntPtr> Shown(CostarInstance t,RoListKind kind) {
            if(kind==RoListKind.Wip) return CostarWindows.Orders(t);
            CostarWindows.Main(t);var result=new List<IntPtr>();
            Native.EnumWindows(delegate(IntPtr h,IntPtr unused) { if(Native.Pid(h)==t.Pid&&Native.IsWindowVisible(h)&&kind.IsWindow(Native.Caption(h))) result.Add(h);return true; },IntPtr.Zero);
            return result;
        }
        // Opens `doc` from the list (2.6.1): the list read once; Search first only when it is needed
        // (WipSearch); its row brought into view and aimed at (Aim); a double click on its Document # cell;
        // if nothing opens, Enter on it once it is the selected row (Tommy, 27 Oct: both work). Nobody may use
        // the PC meanwhile (checked before every click, wheel turn and key). Returns the new Repair Order
        // window; row: its row's values as listed; selected: it was the list's selected row after; times:
        // how long each part took.
        // 2.9.0: kind: the list and its windows (Work-in-Progress and Repair Orders unless given).
        // stay (2.9.6): the Repair Orders left open as they are for a person (RoEngine.FateOf: Stay): this one opens beside
        // them. Any other shown Repair Order window stops the open, as before (the wholesale dry run gives none).
        // hint (2.9.8): the row's place among the list's children when the caller knows it (0: not known); ownFilter: the
        // list's search words are the caller's own (the wholesale speed test's), never cleared here: not listed then is not
        // listed.
        internal static IntPtr Open(CostarInstance t,string doc,Func<bool> cancelled,Action<string> say,RoOpenWatch watch,RoOpenTimes times,out RoListRow row,out bool selected,RoListKind kind=null,HashSet<long> stay=null,int hint=0,bool ownFilter=false) {
            row=null;selected=false;var total=Stopwatch.StartNew();WipScan scan=null;kind=kind??RoListKind.Wip;
            try {
                IntPtr main;var h=Screen(t,kind,out main);
                Order.Require(OnlyKept(Shown(t,kind).Select(w=>w.ToInt64()),stay),"A Repair Order is open in COSTAR "+t.Label+". Close it first.");
                watch.Stay=stay;watch.StayPid=t.Pid;
                watch.Before=AllOrders(t,kind);watch.BeforeAll=TopWindows(t);
                if(stay!=null) { watch.Before.UnionWith(stay);watch.BeforeAll.UnionWith(stay); }   // never taken for the open's own
                Quiet(watch,doc);Front(main,cancelled);
                say("Looking for Repair Order "+doc+" in COSTAR's Work-in-Progress.");
                // 2.9.8: a known place (the wholesale pass's list read): that row first; not there: the whole list, as before.
                if(hint>0) {
                    times.Hint=hint;Native.Rect gb;var g=h.Grid;
                    if(Native.GetWindowRect(g,out gb)) scan=WipScan.FromHint(delegate { return Msaa.FromWindow(g); },gb,doc,hint);
                    if(scan!=null) { times.Hinted=true;times.Took(scan); } else times.Fallbacks++;
                }
                if(scan==null) { try { scan=WipScan.Take(h.Grid,doc);times.Took(scan); } catch(WipScan.NoTable) { scan=null; } }
                bool? inCopy=kind.OrderCheckCopy?InRecentCopy(doc):null;bool searched=false;
                // 2.9.0: another list (searched as its run began): Search again only when the document isn't in it.
                bool needed=kind.OrderCheckCopy?WipSearch.Needed(scan==null||scan.Lines.Count==0,scan!=null&&scan.Target>=0,inCopy,WipSearch.Since(t)):scan==null||scan.Lines.Count==0||scan.Target<0;
                if(h.Search!=IntPtr.Zero&&needed) {
                    if(scan!=null) { scan.Dispose();scan=null; }
                    var searching=Stopwatch.StartNew();PressSearch(h,cancelled);if(kind.OrderCheckCopy) WipSearch.Pressed(t);times.SearchMs=searching.ElapsedMilliseconds;searched=true;
                    scan=WipScan.Take(h.Grid,doc);times.Took(scan);
                    // Not there after a Search: once more reading every cell, before saying it isn't listed.
                    if(scan.Target<0&&scan.OneCell) { scan.Dispose();scan=null;scan=WipScan.Take(h.Grid,doc,true);times.Took(scan); }
                }
                Order.Require(scan!=null,"COSTAR's Work-in-Progress list isn't showing a table. Press Search in COSTAR.");
                // 2.6.11: not listed while COSTAR's own search boxes hold a filter (2 Nov 09:50, 10:10: a 2-row list after a
                // search at the PC): the filter cleared, Search pressed, and looked for again.
                string boxes="",filter="";
                if(scan.Target<0&&!ownFilter) filter=KnownFilter(h,cancelled,out boxes)??"";
                if(filter.Length>0&&h.Search!=IntPtr.Zero) {
                    // A stop names the boxes only: its words go to the day log and the run report, the search's words don't.
                    Order.Require(h.Clear!=IntPtr.Zero,"Repair Order "+doc+" isn't in COSTAR "+t.Label+"'s Work-in-Progress list, which is filtered at the PC ("+boxes+"), and COSTAR's Clear button wasn't found. Clear it at the PC (Clear, then Search), then try again.");
                    say("COSTAR's Work-in-Progress is filtered ("+filter+"): clearing it to find Repair Order "+doc+".");
                    Order.Require(!cancelled(),"Stopped.");
                    Quiet(watch,doc);   // nobody at the PC since the open began, as before every press here
                    string why=ClearFilter(h,cancelled,delegate{Quiet(watch,doc);});
                    AppLog.Note("ro_filter_cleared",(why==null?"for open ":"not cleared for open ")+doc+(why==null?"":" ("+why+")")+": "+boxes);
                    Order.Require(why==null,"Repair Order "+doc+" isn't in COSTAR "+t.Label+"'s Work-in-Progress list, which is filtered at the PC ("+boxes+"), and the filter couldn't be cleared ("+why+"). Clear it at the PC (Clear, then Search), or try again.");
                    // Said with whatever comes next (opened, or stopped): the person's search at the PC was emptied.
                    times.FilterCleared=true;times.Filter=filter;
                    scan.Dispose();scan=null;
                    Quiet(watch,doc);
                    var searching=Stopwatch.StartNew();PressSearch(h,cancelled);if(kind.OrderCheckCopy) WipSearch.Pressed(t);times.SearchMs=Math.Max(0L,times.SearchMs)+searching.ElapsedMilliseconds;searched=true;
                    scan=WipScan.Take(h.Grid,doc);times.Took(scan);
                    if(scan.Target<0&&scan.OneCell) { scan.Dispose();scan=null;scan=WipScan.Take(h.Grid,doc,true);times.Took(scan); }
                }
                if(scan.Target<0) throw new RoNotListedException("Repair Order "+doc+" isn't in COSTAR "+t.Label+"'s Work-in-Progress list (finished, or filtered out?).");
                row=scan.TargetRow();
                var screen=new CostarWipScreen(main,h.Grid,watch,doc,cancelled,say) {Hint=scan.Hinted?scan.TargetLine.Pos:0,Times=times};
                // 2.6.5: no mouse first: the row selected and made the active one through accessibility, the list
                // given the keyboard directly, then Enter (checked as the Enter of 2.6.1 is, and the row checked again
                // right before it). Nothing opened: the mouse way below.
                if(Direct.On) {
                    IntPtr opened=OpenDirect(t,h,main,screen,ref scan,doc,cancelled,say,watch,times,out selected,kind);
                    if(opened!=IntPtr.Zero) return opened;
                    times.Direct=false;times.How="";
                }
                // 2.9.8: the mouse way needs every row's place: a read at a known place is made whole first.
                if(scan.Hinted) {
                    screen.Hint=0;scan.Dispose();scan=null;times.Fallbacks++;
                    scan=WipScan.Take(h.Grid,doc);times.Took(scan);
                    Order.Require(scan.Target>=0,"Repair Order "+doc+" went from COSTAR's Work-in-Progress list. Nothing was opened.");
                }
                var point=Aim(screen,ref scan,doc,times,searched,delegate {
                    Quiet(watch,doc);Front(main,cancelled);
                    Order.Require(AllOrders(t,kind).SetEquals(watch.Before),"COSTAR opened a window while its list was being scrolled. Nothing was double-clicked: check COSTAR.");
                    say("Opening Repair Order "+doc+".");
                });
                // The last looks were just now; then at once: what accessibility finds at the point not another Repair
                // Order, then no key held, nobody, COSTAR in front and the list under the point (2.9.6: right before the
                // double click, nothing in between: a Repair Order kept open beside it is a COSTAR window too).
                CheckPoint(screen,point,scan,doc,times);
                var opening=Stopwatch.StartNew();
                watch.BeforeAll=TopWindows(t);
                Native.NoModifiers();Quiet(watch,doc);KeptStill(watch,doc);
                Order.Require(Native.GetForegroundWindow()==main&&Native.WindowFromPoint(point)==h.Grid,"COSTAR's Work-in-Progress list was covered just before the double click. Nothing was opened; try again.");
                Native.DoubleClickNow(point);
                IntPtr window=WaitForWindow(t,watch,main,doc,cancelled,kind);
                if(window==IntPtr.Zero) {
                    // Read again (new objects): Enter opens the selected row, so it must be this one, and only it.
                    ReadAgain(screen,ref scan,doc,times);
                    Order.Require(scan.OnlyTargetSelected(),"Repair Order "+doc+" didn't open with a double click, and its row isn't the one selected. Open it by hand.");
                    Quiet(watch,doc);Front(main,cancelled);
                    Order.Require(Native.Focus(main)==h.Grid,"COSTAR's Work-in-Progress list doesn't have the keyboard, so Enter isn't pressed. Open Repair Order "+doc+" by hand.");
                    // Pressed only with COSTAR idle (WaitForWindow), its main window in front, the list holding
                    // the keyboard and no Repair Order window being built: the key can't reach anything else.
                    Order.Require(Native.GetForegroundWindow()==main&&AllOrders(t,kind).SetEquals(watch.Before),"COSTAR changed before Enter could be pressed. Nothing was pressed; try again.");
                    AppLog.Note("ro_open_enter",doc+": the double click opened nothing; Enter on the selected row");
                    opening.Restart();
                    watch.BeforeAll=TopWindows(t);
                    Native.NoModifiers();Quiet(watch,doc);KeptStill(watch,doc);
                    Order.Require(Native.GetForegroundWindow()==main&&Native.Focus(main)==h.Grid,"COSTAR changed before Enter could be pressed. Nothing was pressed; try again.");
                    Native.KeyNow(13);
                    window=WaitForWindow(t,watch,main,doc,cancelled,kind);
                    Order.Require(window!=IntPtr.Zero,"Repair Order "+doc+" didn't open (a double click and Enter were tried). Open it by hand.");
                }
                times.WindowMs=opening.ElapsedMilliseconds;
                int after=scan.TargetState();
                selected=after>=0&&(after&0x6)!=0;
                return window;
            } finally { if(scan!=null) scan.Dispose();times.TotalMs=total.ElapsedMilliseconds; }
        }
        // 2.6.5: Enter on the row made the active and only selected one (SelectForEnter), with the same checks as
        // the Enter of 2.6.1: COSTAR idle and in front, the list holding the keyboard, no Repair Order window being
        // built, nobody at the PC; and the row looked at once more right before Enter. Zero when that can't be
        // done or nothing opened (then the mouse way).
        static IntPtr OpenDirect(CostarInstance t,TempeOrderCheck.WipHandles h,IntPtr main,IWipScreen screen,ref WipScan scan,string doc,Func<bool> cancelled,Action<string> say,RoOpenWatch watch,RoOpenTimes times,out bool selected,RoListKind kind) {
            selected=false;
            Quiet(watch,doc);Front(main,cancelled);
            Order.Require(AllOrders(t,kind).SetEquals(watch.Before),"COSTAR opened a window before Repair Order "+doc+" was opened. Nothing was pressed: check COSTAR.");
            if(!SelectForEnter(screen,ref scan,doc,times)) return IntPtr.Zero;
            say("Opening Repair Order "+doc+".");
            Quiet(watch,doc);Front(main,cancelled);
            Order.Require(Native.GetForegroundWindow()==main&&AllOrders(t,kind).SetEquals(watch.Before),"COSTAR changed before Enter could be pressed. Nothing was pressed; try again.");
            // The last look, right before Enter: still that Repair Order, the active row and the only selected one.
            Order.Require(scan.TargetStill()&&scan.TargetActive()&&scan.OnlyTargetSelected(),"Repair Order "+doc+"'s row changed in the list before Enter. Nothing was pressed; try again.");
            var opening=Stopwatch.StartNew();
            watch.BeforeAll=TopWindows(t);
            Native.NoModifiers();Quiet(watch,doc);KeptStill(watch,doc);
            Order.Require(Native.GetForegroundWindow()==main&&Native.Focus(main)==h.Grid,"COSTAR changed before Enter could be pressed. Nothing was pressed; try again.");
            Native.KeyNow(13);
            IntPtr window=WaitForWindow(t,watch,main,doc,cancelled,kind);
            if(window==IntPtr.Zero) { AppLog.Note("ro_open_direct",doc+": Enter on its row opened nothing; the mouse way");return IntPtr.Zero; }
            times.WindowMs=opening.ElapsedMilliseconds;
            // Not taken as a sign it is that Repair Order: the helper made it so (the opened one is still checked
            // by its number, or its name, comment, PO# and total all as listed).
            selected=false;
            return window;
        }
        // The Repair Order window that wasn't there before, once it has stayed the same for 300 ms. A
        // COSTAR message box shown instead stops it: nothing is pressed in it. A person using the PC
        // meanwhile stops it too (their window could be the next one). Zero only when nothing opened, no
        // new Repair Order window is being built (even hidden), and COSTAR has answered at once for 3 s
        // in a row, at least 8 s after the click (30 s at most): a slow COSTAR still opening it is
        // waited for, so nothing is ever pressed into a late window.
        static IntPtr WaitForWindow(CostarInstance t,RoOpenWatch watch,IntPtr main,string doc,Func<bool> cancelled,RoListKind kind) {
            var timer=Stopwatch.StartNew();var settle=Stopwatch.StartNew();IntPtr candidate=IntPtr.Zero;int idle=0;
            while(timer.ElapsedMilliseconds<30000) {
                Order.Require(!cancelled(),"Stopped while Repair Order "+doc+" was opening. Check COSTAR.");
                Quiet(watch,doc);KeptStill(watch,doc);
                var building=AllOrders(t,kind).Where(x=>!watch.Before.Contains(x)).ToList();
                var fresh=Shown(t,kind).Where(x=>!watch.Before.Contains(x.ToInt64())).ToList();
                Order.Require(fresh.Count<=1,"More than one Repair Order opened in COSTAR "+t.Label+". Check COSTAR.");
                if(fresh.Count==1) {
                    Order.Require(kind.InBranch(Native.Caption(fresh[0]),t.Branch),"The Repair Order that opened is not in "+t.Label+".");
                    if(fresh[0]==candidate&&settle.ElapsedMilliseconds>=300) return fresh[0];
                    if(fresh[0]!=candidate) { candidate=fresh[0];settle.Restart(); }
                    idle=0;
                } else {
                    candidate=IntPtr.Zero;
                    var fg=Native.GetForegroundWindow();
                    if(fg!=IntPtr.Zero&&fg!=main&&Native.Pid(fg)==t.Pid&&Native.Class(fg)=="#32770"&&timer.ElapsedMilliseconds>=300) Question(fg,doc);
                    // 2.9.4: COSTAR's "Document Already Open" before its Repair Order window shows: OK pressed, the phone told.
                    // 2.9.7: a wholesale Order's too (Tommy, 14 Nov: "safely dismiss it, skip that order and continue").
                    if(fg!=IntPtr.Zero&&fg!=main&&Native.Pid(fg)==t.Pid&&timer.ElapsedMilliseconds>=300) InUse(t,main,watch,fg,doc,cancelled,kind);
                    UIntPtr result;
                    bool answering=building.Count==0&&fg==main&&Native.SendNull(main,0,UIntPtr.Zero,IntPtr.Zero,0x0002,500,out result)!=IntPtr.Zero;
                    idle=answering?idle+1:0;
                    if(timer.ElapsedMilliseconds>=8000&&idle>=60) return IntPtr.Zero;
                }
                Thread.Sleep(50);
            }
            Order.Require(AllOrders(t,kind).SetEquals(watch.Before),"Repair Order "+doc+" took more than 30 s to open. Check COSTAR.");
            return IntPtr.Zero;
        }
        // 2.9.4: COSTAR's "Document Already Open" in front before the Repair Order shows (6 and 8 Nov: the request waited
        // 30 s and stopped, and so did every one after it until a person pressed OK; Runner.InUse once a Repair Order
        // window has shown). Its owner must be a Repair Order form of this branch that the open made: not the main
        // window, not there before the open. Its OK pressed right after the usual look (nobody at the PC, not stopped);
        // then that form, when COSTAR leaves it open with nothing of its own over it, closed with its own close
        // (AfterInUse). The phone is told (RoInUseException). Nothing happens for any other window, or when it changed
        // in between (looked at again).
        static long inUseNotPressed,inUseNotTaken;
        static void InUse(CostarInstance t,IntPtr main,RoOpenWatch watch,IntPtr dialog,string doc,Func<bool> cancelled,RoListKind kind) {
            if(!Runner.IsInUseWindow(dialog)) return;
            IntPtr form=Native.GetWindow(dialog,4);
            string what=kind==RoListKind.Wholesale?"Order":"Repair Order";
            string notTaken=form==IntPtr.Zero?"it has no owner":form==main?"it is over COSTAR's main window":Native.Pid(form)!=t.Pid?"its owner isn't this COSTAR's"
                :watch.BeforeAll==null||watch.BeforeAll.Contains(form.ToInt64())?"its window was there before the open":!FormOf(Native.Caption(form),t.Branch,kind)?"its window isn't a "+what+" of Branch "+t.Branch
                :NewForms(t,watch,kind)!=1?"more than one new "+what+" window":null;
            if(notTaken==null&&KeptChanged(watch)) notTaken="a Repair Order kept open beside the open closed or changed";
            // Said once (no words): a first one seen on site that isn't answered can be told apart.
            if(notTaken!=null) { if(inUseNotTaken!=dialog.ToInt64()) { inUseNotTaken=dialog.ToInt64();AppLog.Note("ro_in_use",doc+": Document Already Open seen, not answered: "+notTaken); } return; }
            string words;IntPtr ok=DocumentInUse.Read(dialog,out words);
            if(ok==IntPtr.Zero) return;
            int answered=DocumentInUse.Answer(dialog,ok,delegate {
                try { Quiet(watch,doc); }
                catch(InvalidOperationException q) { throw new InvalidOperationException(q.Message+" COSTAR is showing \"Document Already Open\" ("+what+" "+doc+" is open on another PC): press its OK at the PC."); }
                return !cancelled();
            });
            if(answered<0) {
                if(inUseNotPressed!=dialog.ToInt64()) { inUseNotPressed=dialog.ToInt64();AppLog.Note("ro_in_use",doc+": Document Already Open, OK not pressed; looked at again"); }
                return;
            }
            Order.Require(answered==1,"COSTAR's \"Document Already Open\" stayed open after its OK was pressed. Nothing more was pressed: close it at the PC ("+what+" "+doc+" is open on another PC).");
            string after=AfterInUse(t,main,form,watch,cancelled);
            AppLog.Note(kind==RoListKind.Wholesale?"wholesale_in_use":"ro_in_use",doc+": Document Already Open before the "+what+" showed, OK pressed; its form "+after);
            Order.Require(after!="asked again","COSTAR showed \"Document Already Open\" again after its OK. Nothing more was pressed: answer it at the PC ("+what+" "+doc+" is open on another PC).");
            Order.Require(after!="asked","COSTAR asked something as the empty "+what+" window it had opened was closed. Nothing was answered: answer it at the PC ("+what+" "+doc+" is open on another PC, nothing was changed).");
            throw new RoInUseException(doc,words,after=="left open"?"form":after.EndsWith("busy",StringComparison.Ordinal)?"busy":"");
        }
        // 2.9.4: the Repair Order forms of this branch that weren't there before the open (the second review: only one, the
        // dialog's owner, may be taken for the open's own).
        static int NewForms(CostarInstance t,RoOpenWatch watch,RoListKind kind) {
            int n=0;
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) { if(Native.Pid(w)==t.Pid&&!watch.BeforeAll.Contains(w.ToInt64())&&FormOf(Native.Caption(w),t.Branch,kind)) n++;return true; },IntPtr.Zero);
            return n;
        }
        // After Document Already Open's OK, the form COSTAR was opening the Repair Order in, up to 5 s: "gone" (COSTAR
        // closed it), "asked again" (another Document Already Open over it: never pressed), "closed" (left open, usable,
        // nothing of COSTAR's over it for a second, nobody at the PC since the open began, not stopped, all looked at
        // once more right before: closed with its own close, WM_CLOSE; nothing was typed in it), "asked" (COSTAR asking
        // something on it as it closes: never answered), or "left open". "gone" and "closed" end ", busy" when COSTAR's
        // main window isn't usable 2 s later. A person at the PC is noted (watch.UserActive: nothing more is taken over).
        static string AfterInUse(CostarInstance t,IntPtr main,IntPtr form,RoOpenWatch watch,Func<bool> cancelled) {
            var timer=Stopwatch.StartNew();int steady=0;
            while(timer.ElapsedMilliseconds<5000&&steady<10) {
                if(!Native.IsWindow(form)) return Settled("gone",main);
                if(AskedAgain(form)) return "asked again";
                steady=Native.IsWindowEnabled(form)&&Runner.CloseBlocker(form)==null?steady+1:0;
                Thread.Sleep(100);
            }
            if(!Native.IsWindow(form)) return Settled("gone",main);
            if(Person(watch)||steady<10||cancelled()||KeptChanged(watch)) return "left open";
            // The last look, right before the close.
            if(AskedAgain(form)) return "asked again";
            if(!Native.IsWindowEnabled(form)||Runner.CloseBlocker(form)!=null||KeptChanged(watch)) return "left open";
            UIntPtr result;Native.WriteMessage(form,0x10,UIntPtr.Zero,null,3,1000,out result);
            for(var closing=Stopwatch.StartNew();closing.ElapsedMilliseconds<8000;Thread.Sleep(100)) {
                if(!Native.IsWindow(form)) return Settled("closed",main);
                if(AskedAgain(form)) return "asked again";
            }
            // Still open: COSTAR asking something on it (its close waits for the answer), or busy.
            return !Native.IsWindowEnabled(form)||Runner.CloseBlocker(form)!=null?"asked":"left open";
        }
        // Someone at the PC since the open began: noted, so nothing more of COSTAR's is taken for the open's own.
        static bool Person(RoOpenWatch watch) {
            if(!Native.UserActiveWithin((int)Math.Min(600000,watch.Clock.ElapsedMilliseconds+1000))) return false;
            watch.UserActive=true;return true;
        }
        // The form gone: COSTAR's main window usable again within 2 s (nothing else of COSTAR's over it), or ", busy".
        static string Settled(string how,IntPtr main) {
            for(var look=Stopwatch.StartNew();look.ElapsedMilliseconds<2000;Thread.Sleep(100)) if(Native.IsWindowEnabled(main)) return how;
            return how+", busy";
        }
        // Another Document Already Open showing over the form.
        static bool AskedAgain(IntPtr form) {
            uint owner=Native.Pid(form);bool found=false;
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) {
                if(w==form||Native.Pid(w)!=owner||!Native.IsWindowVisible(w)||!Runner.IsInUseWindow(w)) return true;
                var o=Native.GetWindow(w,4);
                for(int i=0;i<16&&o!=IntPtr.Zero;i++,o=Native.GetWindow(o,4)) if(o==form) { found=true;return false; }
                return true;
            },IntPtr.Zero);
            return found;
        }
        // A COSTAR message box instead of the Repair Order: read (for the phone), never answered.
        static void Question(IntPtr dialog,string doc) {
            var words=new List<string>();var buttons=new List<string>();
            Native.EnumChildWindows(dialog,delegate(IntPtr h,IntPtr unused) {
                if(!Native.IsWindowVisible(h)) return true;
                string cls=Native.Class(h),text;if(!Native.TryText(h,out text)) return true;
                if(cls.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0) buttons.Add(Order.Norm(text).Replace("&",""));
                else if(cls.IndexOf("STATIC",StringComparison.OrdinalIgnoreCase)>=0&&Order.Clean(text).Length>0) words.Add(Order.Clean(text));
                return words.Count+buttons.Count<40;
            },IntPtr.Zero);
            string said=EbayText.Clean(String.Join(" ",words.ToArray()),300).Replace("\"","'");
            AppLog.Note("ro_open_question",doc+": a COSTAR message box, buttons "+String.Join("/",buttons.ToArray()));
            throw new InvalidOperationException("COSTAR showed a message instead of opening Repair Order "+doc+(said.Length>0?": \""+said+"\"":"")+". Nothing was answered: answer it at the PC (COSTAR may then open the Repair Order: check it there).");
        }
    }

    internal sealed class RoEngine : IDisposable {
        readonly EntryCoordinator coordinator;readonly WorkerSettings settings;readonly string journalPath;readonly object gate=new object();readonly Action<string> log;
        RoJournal state;volatile Runner runner;volatile bool disposed,busy;int started;
        internal volatile bool Enabled;
        // How long nobody may have used the PC before a phone's request starts in COSTAR. 2.6.7 (Tommy, 28 Oct
        // 15:34: "change all idle time to 3 seconds", "when its waiting for costar to be ready"): 3 s (it was 10 s).
        internal const int QuietSeconds=3,TempeBranch=11;
        internal volatile string Connection="Desk PC: connecting ...",Detail="",Current="",LastLine="";
        volatile int lastContactTick;internal volatile int RoundTripMs=-1;
        internal int SecondsSinceContact { get { int t=lastContactTick;return t==0?-1:unchecked(Environment.TickCount-t)/1000; } }
        volatile HttpWebRequest pending;volatile bool interrupted;readonly AutoResetEvent wake=new AutoResetEvent(false);
        readonly Stopwatch progressClock=Stopwatch.StartNew();
        // COSTAR checked again at most every 3 s (a window scan).
        DateTime checkedAt=DateTime.MinValue;bool lastFree;string lastWhy="";
        internal bool Busy {get{return busy;}}
        // 2.6.7 (Tommy, 28 Oct 15:11: "if I'm trying to access it through phone but the pc is opening a repair
        // order, close that repair order so I can access it on the phone"): a Repair Order open in COSTAR Tempe
        // is closed first when the phone asks to open, change or print one, with COSTAR's own close (nothing
        // saved, sold or printed: it stays in Work-in-Progress), once nobody has used the PC for
        // CloseQuietSeconds and COSTAR isn't asking anything on it. Never one held for a person to finish: a
        // phone job's or an online order's (HeldForReview), or one whose PO# is an online order's.
        internal const int CloseQuietSeconds=3;   // Tommy, 28 Oct 15:34: every wait for COSTAR to be ready 3 s
        // The Repair Order windows other work leaves open for a person (set by the helper's window). Null: no
        // Repair Order is closed for the phone at all (as before 2.6.7).
        internal volatile Func<HashSet<long>> HeldForReview;
        // What was read of each open Repair Order (its number and PO#), kept a minute: read only with nobody at the PC
        // and COSTAR asking nothing on it (2.9.6: one held for a person too, for its number), so COSTAR isn't asked while
        // someone works in it.
        readonly Dictionary<long,KeyValuePair<DateTime,RoPeek.Seen>> peeked=new Dictionary<long,KeyValuePair<DateTime,RoPeek.Seen>>();
        // The Repair Order this helper left open after a change stopped ("" when none), for the window.
        internal string LeftOpen { get { lock(gate) return state.leftOpen==null?"":state.leftOpen.doc; } }
        // 2.6.10: a new phone job closed this Repair Order window first (WorkerEngine.CloseOpenFirst): if it is the one
        // this helper left open, it's no longer open.
        internal void ForgetLeftOpen(long window) { lock(gate) { if(state.leftOpen!=null&&state.leftOpen.window==window) { state.leftOpen=null;Save(); } } }
        internal RoEngine(WorkerSettings config,string folder,Action<string> notify,EntryCoordinator entries) {
            coordinator=entries;NetworkRules.Worker(config);settings=config;log=notify;journalPath=Path.Combine(folder,"ro-journal.dat");
            try { state=PrivateFiles.Load<RoJournal>(journalPath); }
            catch(Exception e) {
                try{File.Copy(journalPath,journalPath+".unreadable-"+DateTime.Now.ToString("yyyyMMdd-HHmmss"),true);}catch(Exception){}
                AppLog.Note("ro_journal_unreadable",e.GetType().Name);state=null;
            }
            // A new journal counts its reports on from the time, so they come after any earlier one's.
            if(state==null) state=new RoJournal {sequence=(int)Math.Min(Int32.MaxValue/2,Math.Max(0,(DateTime.UtcNow-new DateTime(2026,1,1,0,0,0,DateTimeKind.Utc)).TotalSeconds))};
            var lost=state.running;
            if(lost!=null) {
                state.running=null;
                // Its Repair Order still open (the same window in the same COSTAR): remembered as left
                // open, typed into or not, so it can be closed from the phone; never closed here.
                bool open=false;
                try {
                    var h=new IntPtr(lost.window);ProcessIdentity identity;
                    open=lost.window!=0&&Native.IsWindow(h)&&(int)Native.Pid(h)==lost.processId&&Native.Caption(h).StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase)
                        &&LocalProcess.IsNamed(lost.processId,"COSTAR",out identity)&&identity.Started==lost.processStart;
                } catch(Exception) { open=false; }
                if(open) state.leftOpen=new RoLeftOpen {doc=lost.doc,window=lost.window,processId=lost.processId,processStart=lost.processStart,atUtc=lost.atUtc};
                string why=lost.touched?"The RDP helper closed while changing Repair Order "+lost.doc+". Check it in COSTAR Tempe"+(open?" (it is still open there: close it there or from the phone)":"")+" before trying again."+(lost.printing?" Its Job Card may have printed: check the printer.":"")
                    :lost.printing?"The RDP helper closed while printing the Job Card of Repair Order "+lost.doc+": it may have printed. Check the printer before printing it again."+(open?" It is still open in COSTAR Tempe: close it there or from the phone.":"")
                    :open?"The RDP helper closed while Repair Order "+lost.doc+" was open (nothing was typed). It is still open in COSTAR Tempe: close it there or from the phone."
                    :"The RDP helper closed while doing this. Try again.";
                try { Report(lost.id,lost.lease,"failed",why,"",lost.touched,open); } catch(Exception) { }
            }
            Enabled=AppSettings.Current.roOn;
        }
        static string Now { get { return DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture); } }
        // 2.6.2: when this helper last printed (or may have printed) each Repair Order's Job Card.
        readonly Dictionary<string,DateTime> printedAt=new Dictionary<string,DateTime>();
        internal static readonly TimeSpan PrintAgainAfter=TimeSpan.FromMinutes(2);
        string RecentPrint(string doc) {
            DateTime at;lock(gate) if(!printedAt.TryGetValue(doc,out at)) return null;
            var ago=DateTime.UtcNow-at;if(ago>=PrintAgainAfter||ago<TimeSpan.Zero) return null;
            return "Job Card not printed: one for Repair Order "+doc+" went to the printer "+(int)ago.TotalSeconds+" s ago. Check the printer; print it again after 2 minutes if it isn't there.";
        }
        void Save() { lock(gate) PrivateFiles.Save(journalPath,state); }
        void Running(RoAttempt attempt) { lock(gate) { state.running=attempt;Save(); } }
        // Under gate: the next report (the desk acknowledges it by its sequence).
        void SetReport(string id,string lease,string status,string message,string progress,bool typed,bool leftOpen,RoSnapshot snapshot=null,RoList list=null,List<string> notes=null) {
            state.sequence++;
            state.report=new RoReport {id=id,lease=lease,status=status,message=EbayText.Clean(message,2000),progress=EbayText.Clean(progress,1000),sequence=state.sequence,typed=typed,leftOpen=leftOpen,snapshot=snapshot,list=list,notes=notes};
        }
        void Report(string id,string lease,string status,string message,string progress,bool typed,bool leftOpen,RoSnapshot snapshot=null,RoList list=null,List<string> notes=null) {
            lock(gate) { SetReport(id,lease,status,message,progress,typed,leftOpen,snapshot,list,notes);Save(); }
            if(status!="working"||(progress??"").Length==0) { Detail=message;log(message); }
            Interrupt();
        }
        volatile string declineLease,declineReason;
        CostarInstance checkedFor;   // 2.9.6: the COSTAR Free's last look was for
        void Decline(string lease,string why) { declineReason=EbayText.Clean(why,400);declineLease=lease;Detail=why;Interrupt(); }
        internal void Start() {
            if(disposed) return;
            if(!AppSettings.Current.roOn){AppSettings.Current.roOn=true;AppSettings.Current.Save();}
            bool was=Enabled;Enabled=true;AppLog.Note("ro_start","");Connect();if(!was)Interrupt();
        }
        // persist: the Repair Orders switch itself. Stop all entry only pauses.
        internal void Stop(bool persist) {
            if(persist&&AppSettings.Current.roOn){AppSettings.Current.roOn=false;AppSettings.Current.Save();}
            bool was=Enabled;Enabled=false;var active=runner;if(active!=null)active.Cancel=true;
            if(was){AppLog.Note("ro_stop",persist?"switched off":"stop all");Interrupt();}
        }
        internal void Connect(){if(disposed)return;if(Interlocked.Exchange(ref started,1)!=0)return;var t=new Thread(Loop);t.IsBackground=true;t.Start();}
        void Interrupt(){interrupted=true;var r=pending;if(r!=null){try{r.Abort();}catch(Exception){}}wake.Set();}
        internal void Reconnect(){Interrupt();}
        // 2.9.3: the Online orders tab holding phone work back (EntryCoordinator.MobileHeld).
        internal const string HeldDetail="Waiting: someone is using the RDP PC, with the Online orders tab showing (it goes on once the PC has been left alone for 2 minutes)";
        // 2.9.6 (Tommy, 11 Nov 09:30: "also if its not on the correct branch, please change the branch"): the phone's Repair
        // Orders go into COSTAR Tempe whichever COSTAR the RDP helper is set to, as eBay orders go into COSTAR Sydney, and
        // the helper's own setting is left as it is (phone jobs and online orders keep theirs; a branch switch would pause
        // mobile). Pure. selected: the COSTAR the helper is set to; last: the COSTAR Tempe it was set to last; open: the
        // COSTARs open in this session; orderCheck: Order Check's Work-in-Progress window (never used). The one set, when
        // it is a COSTAR Tempe still open; else the one set last while it is still open; else the only COSTAR Tempe open.
        // Null: why.
        internal static CostarInstance PickTempe(CostarInstance selected,CostarInstance last,IList<CostarInstance> open,Func<CostarInstance,bool> orderCheck,out string why) {
            why=null;
            var usable=(open??new List<CostarInstance>()).Where(c=>c!=null&&c.Branch==TempeBranch&&!orderCheck(c)).ToList();
            if(selected!=null&&selected.Branch==TempeBranch&&!orderCheck(selected)&&usable.Any(c=>c.Same(selected))) return selected;
            if(last!=null) { var same=usable.FirstOrDefault(c=>c.Same(last));if(same!=null) return same; }
            if(usable.Count==1) return usable[0];
            string set=selected==null?"no COSTAR":"COSTAR "+selected.Label+(orderCheck(selected)?" (Order Check's Work-in-Progress window)":"");
            why=usable.Count==0?"COSTAR Tempe (Branch "+TempeBranch+") isn't open on the RDP PC (the RDP helper is set to "+set+")"
                :usable.Count+" COSTAR Tempe windows are open and the RDP helper is set to "+set+": close all but one, or select the one to use in the RDP helper (it is remembered; switching branch there pauses mobile jobs until Start / resume mobile)";
            return null;
        }
        // 2.9.6: PickTempe now; COSTAR's windows looked at again at most every 3 s (as for eBay orders' COSTAR Sydney). The
        // one set is used while its program runs (else another COSTAR Tempe may be). TempeLook: the last look's answer for
        // the alerts (the review, round 3: only a look under 30 s old counts: Free doesn't look while other work runs).
        CostarInstance tempe,tempeFor;string tempeWhy;bool tempeForNone=true;readonly Stopwatch tempeAge=new Stopwatch();
        string tempeMissing;readonly Stopwatch tempeMissingAge=new Stopwatch();
        void Missing(string why) { lock(gate) { tempeMissing=why;tempeMissingAge.Restart(); } }
        // True with a look in the last 30 s; missing: why no COSTAR Tempe can be used then (null: one can).
        internal bool TempeLook(out string missing) {
            lock(gate) {
                missing=tempeMissing;
                return tempeMissingAge.IsRunning&&tempeMissingAge.ElapsedMilliseconds<30000;
            }
        }
        CostarInstance TempeTarget(out string why) {
            var selected=coordinator.Selected;
            if(selected!=null&&selected.Branch==TempeBranch&&!OrderCheckLink.IsWipWindow(selected)&&Alive(selected)) { Missing(null);why=null;return selected; }
            lock(gate) {
                if(tempeAge.IsRunning&&tempeAge.ElapsedMilliseconds<3000&&(selected==null?tempeForNone:selected.Same(tempeFor))) { why=tempeWhy;return tempe; }
            }
            List<CostarInstance> open;
            try { open=CostarWindows.Choices(); } catch(Exception e) { why="COSTAR Tempe couldn't be looked for: "+e.Message;Missing(why);return null; }
            var found=PickTempe(selected,coordinator.LastSelected(TempeBranch),open,OrderCheckLink.IsWipWindow,out why);
            lock(gate) { tempe=found;tempeWhy=why;tempeFor=selected;tempeForNone=selected==null;tempeAge.Restart(); }
            Missing(found==null?why:null);
            return found;
        }
        // 2.9.6: TempeTarget's last look forgotten (the COSTAR Tempe it gave has closed).
        void ForgetTempe() { lock(gate) tempeAge.Reset(); }
        // 2.9.6: the COSTAR's program still the one picked, its main window still that branch's (CostarWindows.Main's look).
        static bool Alive(CostarInstance c) { try { CostarWindows.Main(c);return true; } catch(Exception) { return false; } }
        // 2.9.6 (the review, round 2): COSTAR Tempe while the RDP helper is set to another COSTAR: the helper is set to that
        // one for a reason (someone may be working in it, now and then looking away), so the phone waits until the PC has
        // been left alone for 2 minutes (EntryCoordinator.OnlineHoldMs, as the Online orders tab's hold; the last input
        // unknown: it waits). Pure; null: it may go on.
        internal static string AwayHold(CostarInstance target,CostarInstance selected,long sinceInputMs) {
            if(target==null||target.Same(selected)||!EntryCoordinator.Holds(sinceInputMs)) return null;
            return "Waiting: the RDP helper is set to "+(selected==null?"no COSTAR":"COSTAR "+selected.Label)+" and the PC was used in the last "+EntryCoordinator.OnlineHoldMs/60000+" minutes: the phone's Repair Orders go into COSTAR "+target.Label+" once it has been left alone that long";
        }
        // 2.9.6: the COSTAR Tempe a Repair Order was left open in, while its program still runs (null: not found).
        static CostarInstance LeftIn(RoLeftOpen left) {
            if(left==null) return null;
            try { return CostarWindows.Choices().FirstOrDefault(c=>c.Pid==left.processId&&c.Started==left.processStart&&c.Branch==TempeBranch&&!OrderCheckLink.IsWipWindow(c)); }
            catch(Exception) { return null; }
        }
        // Whether a Repair Order may be opened in COSTAR Tempe now, and why not. openAllowed: a
        // Repair Order may already be open (closing the one this helper left open).
        // 2.9.6: t, the COSTAR Tempe it goes into (TempeTarget: whichever COSTAR is selected).
        bool Free(out string detail,bool openAllowed=false) { CostarInstance t;return Free(out detail,out t,openAllowed); }
        // prefer: the COSTAR to use when it is still running (the one a Repair Order to close was left open in).
        bool Free(out string detail,out CostarInstance t,bool openAllowed=false,CostarInstance prefer=null) {
            t=null;
            if(!Enabled) { detail="Repair Orders are switched off on the RDP helper";return false; }
            if(coordinator.Busy) { detail=coordinator.Owner+" is filling COSTAR";return false; }
            if(coordinator.MobileHeld) { detail=HeldDetail;return false; }
            string none=null;t=prefer!=null?prefer:TempeTarget(out none);
            if(t==null) { detail=none;return false; }
            var set=coordinator.Selected;
            string away=AwayHold(t,set,coordinator.SinceInputMs());
            if(away!=null) { detail=away;return false; }
            if(!t.Same(set)&&!Alive(t)) { ForgetTempe();detail="COSTAR "+t.Label+" closed or restarted: looking for COSTAR Tempe again";return false; }
            if(CostarInputLock.LegacyOpen()) { detail="Close the original online-order helper";return false; }
            if(Native.UserActiveWithin(QuietSeconds*1000)) { detail="Waiting for a quiet moment: someone is using the COSTAR PC";return false; }
            if(!openAllowed) {
                // 2.9.6: the last look's answer is for that COSTAR only (another may be the one now).
                if(DateTime.UtcNow-checkedAt<TimeSpan.FromSeconds(3)&&t.Same(checkedFor)) { detail=lastWhy;return lastFree; }
                string d;bool free=CostarWindows.Available(t,out d);
                // 2.6.7: open Repair Orders that may be closed first don't hold the phone up (CloseFirst).
                if(!free&&d.StartsWith("A Repair Order is open",StringComparison.Ordinal)) free=CloseFirst(t,out d);
                checkedAt=DateTime.UtcNow;checkedFor=t;lastFree=free;lastWhy=free&&d.StartsWith("Selected COSTAR ready",StringComparison.Ordinal)?"COSTAR "+t.Label+" is free":d;
                detail=lastWhy;return free;
            }
            detail="COSTAR "+t.Label+" ready";return true;
        }
        // 2.6.7: whether every Repair Order open in COSTAR t may be closed for the phone now; why: what the
        // phone is told (the Repair Order is open, and why it stays, or that it will be closed first).
        // 2.9.6: or stays as it is for a person, the phone's opening beside it (LookFirst).
        bool CloseFirst(CostarInstance t,out string why) {
            string start="A Repair Order is open in COSTAR "+t.Label;
            Func<HashSet<long>> provider=HeldForReview;HashSet<long> held=null;
            try { if(provider!=null) held=provider(); } catch(Exception) { held=null; }
            if(held==null) { why=start+": close it (or finish the phone job waiting for review) first";return false; }
            var open=CostarWindows.Orders(t);
            if(open.Count==0) { why="COSTAR "+t.Label+" is free";return true; }
            // Each read only with COSTAR asking nothing on it and nobody at the PC (LookAt); the first that waits ends the look.
            var looks=new Look[open.Count];
            var first=LookFirst(open.Count,delegate(int i) { return looks[i]=LookAt(open[i],held,false); },null,t.Label);
            if(first.Stop!=null) { why=first.Stop;return false; }
            why=Ready(t.Label,first.Close.Select(i=>looks[i].Seen==null?null:looks[i].Seen.Doc).ToList(),first.Kept);
            return true;
        }
        // 2.6.7: why an open Repair Order stays open for the phone (null: it may be closed first). held: other
        // work left it open for a person (a phone job's, an online order's); blocker: COSTAR is asking
        // something on it (Runner.CloseBlocker); quiet: nobody has used the PC for CloseQuietSeconds; seen:
        // what was read of it (null: not read yet: the looks that need no reading only). Its PO# must have
        // been read, and not be an online order's (after a restart the Online orders tab no longer knows its
        // Repair Orders).
        internal static string KeepOpen(bool held,string blocker,bool quiet,RoPeek.Seen seen) {
            if(held) return "it is a phone job's or an online order's, waiting for review. Finish it at the PC first";
            if(blocker!=null) return blocker+". Answer it at the PC first";
            if(!quiet) return "it will be closed once nobody has used the PC for "+CloseQuietSeconds+" s";
            if(seen==null) return null;
            if(seen.Po==null) return "COSTAR didn't answer when it was looked at. Close it at the PC, or try again";
            if(OnlineOrderPo.IsMatch(seen.Po)) return "it is online order "+Order.Norm(seen.Po)+"'s, maybe waiting for review. Finish or close it at the PC first";
            return null;
        }
        static readonly Regex OnlineOrderPo=new Regex(@"^TTW\d{4,}$",RegexOptions.IgnoreCase);
        // 2.9.6 (Tommy, 11 Nov: "this is silly, i should be able to use it or atleast force to use it while im not on my
        // desk"): a Repair Order kept open for a person no longer keeps the phone out. Held (a phone job's, the Online
        // orders tab's last fill or an online order stopped part way in: HeldForReview) or an online order's by its PO#,
        // it stays as it is, untouched (never closed, nothing pressed or typed in it), and the phone's Repair Order opens
        // beside it: closing it could undo what a person must still check or confirm (CHECK BY HAND, a note COSTAR
        // didn't take yet). Only with COSTAR asking nothing on it and nobody using the PC, as for a close. Pure.
        internal static bool Stays(bool held,string blocker,bool quiet,RoPeek.Seen seen) {
            if(blocker!=null||!quiet) return false;
            if(held) return true;
            return seen!=null&&seen.Po!=null&&OnlineOrderPo.IsMatch(seen.Po.Trim());
        }
        // 2.9.6: whether an open Repair Order may be the one asked for, `asked` (pure): by its number, leading zeros aside;
        // one showing no number (new, never saved: not in Work-in-Progress) isn't; one whose number couldn't be read may be.
        internal static bool MayBe(RoPeek.Seen seen,string asked) {
            if(seen==null) return true;
            if(seen.Doc!=null) {
                string a=seen.Doc.Trim().TrimStart('0'),b=(asked??"").Trim().TrimStart('0');
                return a.Length==0||String.Equals(a,b,StringComparison.OrdinalIgnoreCase);
            }
            return !seen.NoNumber;
        }
        // 2.9.6: its number was read, or it shows none (a new one). Pure.
        internal static bool NumberKnown(RoPeek.Seen seen) { return seen!=null&&(seen.Doc!=null||seen.NoNumber); }
        // 2.9.6: whether one kept open beside the phone's shows another number now than when it was first looked at (pure;
        // either look unread: not known to have changed).
        internal static bool NumberChanged(RoPeek.Seen before,RoPeek.Seen now) {
            if(!NumberKnown(before)||!NumberKnown(now)) return false;
            if(before.Doc==null) return now.Doc!=null;
            return now.Doc==null||now.Doc.Trim().TrimStart('0')!=before.Doc.Trim().TrimStart('0');
        }
        internal static string Cap(string s) { return String.IsNullOrEmpty(s)?s??"":Char.ToUpperInvariant(s[0])+s.Substring(1); }
        // 2.9.6: what becomes of one open Repair Order before a phone's request (FateOf).
        internal enum Fate { Close, Stay, Wait }
        // 2.9.6: one open Repair Order as looked at (LookAt): held for a person (HeldForReview), COSTAR asking something
        // on it (Runner.CloseBlocker), nobody at the PC for CloseQuietSeconds, and what was read of it (null: not read).
        internal sealed class Look { internal bool Held,Quiet;internal string Blocker;internal RoPeek.Seen Seen; }
        // 2.9.6: the first look over them all (LookFirst). Stop: why the phone waits, or the request stops (null: it goes
        // on); Close: the ones closed first; Stay: the ones left as they are, and Kept: what the phone is told of each.
        internal sealed class FirstLook { internal string Stop;internal readonly List<int> Close=new List<int>(),Stay=new List<int>();internal readonly List<string> Kept=new List<string>(); }
        // 2.9.6: one open Repair Order's fate (pure). Wait (why): COSTAR asking something on it, someone using the PC,
        // or one not held whose PO# wasn't read (it might be an online order's: never closed unread). Stay (why: Kept):
        // kept for a person (Stays). Close: closed first (2.6.7, as before).
        internal static Fate FateOf(Look l,out string why) {
            if(l.Blocker!=null) { why=l.Blocker+". Answer it at the PC first";return Fate.Wait; }
            if(!l.Quiet) { why=(l.Held?"it stays as it is, and the phone goes on":"the phone goes on")+" once nobody has used the PC for "+CloseQuietSeconds+" s";return Fate.Wait; }
            if(Stays(l.Held,null,true,l.Seen)) { why=Kept(l.Seen,l.Held);return Fate.Stay; }
            why=KeepOpen(false,null,true,l.Seen??new RoPeek.Seen());
            return why==null?Fate.Close:Fate.Wait;
        }
        // 2.9.6: one kept for a person, as the phone is told of it: its number (a new one: none yet) and whose it is. Pure.
        internal static string Kept(RoPeek.Seen seen,bool held) {
            string po=seen!=null&&seen.Po!=null&&OnlineOrderPo.IsMatch(seen.Po.Trim())?Order.Norm(seen.Po):null;
            string which=seen!=null&&seen.Doc!=null?"Repair Order "+seen.Doc:seen!=null&&seen.NoNumber?"a new Repair Order":"a Repair Order";
            return which+" ("+(po!=null?"online order "+po+"'s, "+(held?"":"maybe ")+"waiting for review":"a phone job's or an online order's, waiting for review")+")";
        }
        // 2.9.6: the first look before a phone's request, at each open Repair Order in turn (look(i): LookAt's); pure. The
        // first that waits stops it (Stop; the rest aren't looked at): for a request (doc, the one asked for), someone at
        // the PC stops it (Free's look, doc null, waits). One kept for a person stays beside it only when its number is
        // known (read, or none shown: a new one), and never when it may be the one asked for (COSTAR has it open
        // already): Free's look waits until it can tell (so the two agree), a request stops. Nothing is closed before
        // this look is through.
        internal static FirstLook LookFirst(int count,Func<int,Look> look,string doc,string label) {
            var first=new FirstLook();
            for(int i=0;i<count;i++) {
                var l=look(i);string why;var fate=FateOf(l,out why);
                string number=l.Seen==null?null:l.Seen.Doc;
                if(fate==Fate.Wait) {
                    first.Stop="A Repair Order is open in COSTAR "+label+(number!=null?" (RO "+number+")":"")+": "+(doc!=null?StopWhy(l,why,false):why);
                    return first;
                }
                if(fate==Fate.Stay) {
                    if(!NumberKnown(l.Seen)) {
                        first.Stop=Cap(why)+" is open in COSTAR "+label+", kept for a person, and its number couldn't be read "+(doc==null?"yet: the phone waits until it can be (the Repair Order asked for is never opened beside itself)"
                            :"(it may be Repair Order "+doc+"). Nothing was closed or opened: try again, or close it at the PC");
                        return first;
                    }
                    if(doc!=null&&MayBe(l.Seen,doc)) { first.Stop=Cap(why)+" is already open in COSTAR "+label+", kept for a person. Nothing was closed or opened: finish it there, or close it at the PC, then try again";return first; }
                    first.Stay.Add(i);first.Kept.Add(why);
                } else first.Close.Add(i);
            }
            return first;
        }
        // 2.9.6: why a request stops on one that waits (pure): someone used the PC (the request ends: no wait promised),
        // else the same words as Free's look.
        internal static string StopWhy(Look l,string why,bool closedSome) {
            return l.Blocker==null&&!l.Quiet?"someone used the PC just now. Nothing "+(closedSome?"more ":"")+"was closed or opened: try again when the PC is free":why;
        }
        // 2.9.6: the ones COSTAR closed or changed while the phone's opened, said loud (pure; null: none).
        internal static string CheckWords(List<string> changed) { return changed.Count==0?null:"CHECK AT THE PC: "+Cap(String.Join("; ",changed.ToArray()))+"."; }
        // 2.9.6: what the phone hears when it may go on (pure): closing, the numbers of the ones closed first (null:
        // unread); kept, the ones that stay (Kept).
        internal static string Ready(string label,List<string> closing,List<string> kept) {
            var parts=new List<string>();
            if(closing.Count==1) parts.Add("Repair Order"+(closing[0]!=null?" "+closing[0]:"")+" is open there and will be closed first");
            else if(closing.Count>1) parts.Add(closing.Count+" Repair Orders are open there and will be closed first");
            if(kept.Count>0) parts.Add(String.Join(" and ",kept.ToArray())+(kept.Count==1?" stays open as it is, and the phone's opens beside it":" stay open as they are, and the phone's opens beside them"));
            return parts.Count==0?"COSTAR "+label+" is free":"COSTAR "+label+" ready: "+String.Join("; ",parts.ToArray());
        }
        // 2.9.6: what the phone's result starts with (pure): closed, the ones closed first ("RO 07000123", "a Repair
        // Order"); left, the ones kept for a person left as they were (Kept); changed, the ones COSTAR closed or changed
        // meanwhile (Kept, then what became of it). "": none was open.
        internal static string Said(List<string> closed,List<string> left,List<string> changed,string label) {
            var b=new StringBuilder();
            if(closed.Count>0) b.Append("Closed ").Append(String.Join(" and ",closed.ToArray())).Append(" first (").Append(closed.Count==1?"it was":"they were").Append(" open in COSTAR ").Append(label).Append("). ");
            if(left.Count>0) b.Append(Cap(String.Join(" and ",left.ToArray()))).Append(left.Count==1?" was left open in COSTAR "+label+" as it was (it may be behind COSTAR's main window). ":" were left open in COSTAR "+label+" as they were (they may be behind COSTAR's main window). ");
            if(changed.Count>0) b.Append(CheckWords(changed)).Append(" ");
            return b.ToString();
        }
        // 2.9.6: what a phone's request did before its open (CloseOpenFirst): the Repair Orders closed first, and the
        // ones kept for a person left beside it (their windows, what the phone is told of each, what was read of each).
        internal sealed class Beside {
            internal readonly List<string> Closed=new List<string>(),Kept=new List<string>();
            internal readonly HashSet<long> Stay=new HashSet<long>();internal readonly List<long> Windows=new List<long>();
            internal readonly List<RoPeek.Seen> Seen=new List<RoPeek.Seen>();
        }
        // 2.9.6: what the phone's result starts with: the ones closed first, and each kept one looked at again now (still
        // open in this COSTAR as it was, its number as it was when read again with nobody at the PC).
        // check: the loud part (CheckWords) on its own, for the phone's notes (a read's message isn't always shown); apart:
        // it goes in the notes, so it's left out of the words returned (a save shows both).
        string BesideSaid(Beside b,CostarInstance t,string doc,out string check,bool apart=false) {
            check=null;
            if(b==null||t==null) return "";
            var left=new List<string>();var changed=new List<string>();
            for(int i=0;i<b.Windows.Count;i++) {
                var h=new IntPtr(b.Windows[i]);
                if(!RoWip.KeptThere(h,t.Pid)) { changed.Add(b.Kept[i]+" was open beside Repair Order "+doc+" and isn't open as it was in COSTAR "+t.Label+" any more (closed, hidden or changed)");continue; }
                RoPeek.Seen now=null;
                try { now=LookAt(h,new HashSet<long>(),true).Seen; } catch(Exception) { now=null; }
                if(NumberChanged(b.Seen[i],now)) changed.Add(b.Kept[i]+" now shows "+(now.Doc!=null?"Repair Order "+now.Doc:"no number"));
                else left.Add(b.Kept[i]);
            }
            if(changed.Count>0) AppLog.Note("ro_beside_changed",changed.Count+" kept open beside a phone's request closed or changed");
            check=CheckWords(changed);
            return Said(b.Closed,left,apart?new List<string>():changed,t.Label);
        }
        // 2.9.6: one open Repair Order looked at now: read only with COSTAR asking nothing on it and nobody at the PC
        // (afresh: not an earlier read).
        Look LookAt(IntPtr w,HashSet<long> held,bool afresh) {
            var l=new Look {Held=held.Contains(w.ToInt64()),Blocker=Runner.CloseBlocker(w),Quiet=!Native.UserActiveWithin(CloseQuietSeconds*1000)};
            if(l.Blocker==null&&l.Quiet) { if(afresh) lock(gate) peeked.Remove(w.ToInt64());l.Seen=Peeked(w); }
            return l;
        }
        RoPeek.Seen Peeked(IntPtr w) {
            long key=w.ToInt64();KeyValuePair<DateTime,RoPeek.Seen> kept;
            lock(gate) {
                if(peeked.TryGetValue(key,out kept)&&DateTime.UtcNow-kept.Key<TimeSpan.FromMinutes(1)) return kept.Value;
                if(peeked.Count>20) peeked.Clear();
            }
            var one=RoPeek.Read(w);
            if(one.Po!=null&&NumberKnown(one)) lock(gate) peeked[key]=new KeyValuePair<DateTime,RoPeek.Seen>(DateTime.UtcNow,one);   // a failed read is tried again (2.9.6: one whose number wasn't read too)
            return one;
        }
        // 2.6.7: right before the phone's request opens anything, the Repair Orders open in COSTAR t closed, each
        // looked at again just before its close (nothing held, COSTAR asking nothing, nobody at the PC for
        // CloseQuietSeconds, its PO# not an online order's). Stops the request when one stays open.
        // 2.9.6: all are looked at first (read afresh), nothing closed yet (LookFirst): the request stops there when one
        // waits, or when one kept for a person is (or may be) the one asked for. The ones kept for a person stay as they
        // are, untouched (beside.Stay: RoWip.Open opens the phone's beside them). beside: what was closed and kept, kept up
        // to date as they close (a stop after one closed says so).
        void CloseOpenFirst(RoTask task,CostarInstance t,Beside beside) {
            var open=CostarWindows.Orders(t).Where(w=>Native.IsWindow(w)).ToList();
            if(open.Count==0) return;
            Func<HashSet<long>> provider=HeldForReview;HashSet<long> held=null;
            try { if(provider!=null) held=provider(); } catch(Exception) { held=null; }
            Order.Require(held!=null,"A Repair Order is open in COSTAR "+t.Label+". Close it first.");
            var looks=new Look[open.Count];
            var first=LookFirst(open.Count,delegate(int i) { return looks[i]=LookAt(open[i],held,true); },task.doc,t.Label);
            Order.Require(first.Stop==null,first.Stop+".");
            for(int k=0;k<first.Stay.Count;k++) { int i=first.Stay[k];beside.Stay.Add(open[i].ToInt64());beside.Windows.Add(open[i].ToInt64());beside.Kept.Add(first.Kept[k]);beside.Seen.Add(looks[i].Seen); }
            if(first.Stay.Count>0) AppLog.Note("ro_beside",String.Join(", ",first.Stay.Select(i=>looks[i].Seen.Doc??"a new Repair Order").ToArray())+" left as "+(first.Stay.Count==1?"it is":"they are")+" for "+task.kind+" "+task.doc);
            foreach(int i in first.Close) {
                var w=open[i];
                if(!Native.IsWindow(w)) continue;
                // Looked at again just before its close (read afresh): it must still be one to close.
                var l=LookAt(w,held,true);string keep;var fate=FateOf(l,out keep);
                var one=l.Seen??new RoPeek.Seen();
                string name="Repair Order"+(one.Doc!=null?" "+one.Doc:"");
                Order.Require(fate==Fate.Close,"A Repair Order is open in COSTAR "+t.Label+(one.Doc!=null?" (RO "+one.Doc+")":"")+": "+(fate==Fate.Stay?"it changed just before its close (it is now kept for a person), so it was left open. Try again":StopWhy(l,keep,beside.Closed.Count>0))+".");
                // Said to the phone at once (not held back as progress is), so it shows which one goes.
                string closing="Closing "+name+", which was open in COSTAR "+t.Label+", before "+(task.kind=="edit"?"changing":task.kind=="print"?"printing the Job Card of":"opening")+" Repair Order "+task.doc+".";
                log("RO: "+closing);Detail=closing;progressClock.Restart();
                try { Report(task.id,task.lease,"working",closing,closing,false,false); } catch(Exception) { }
                bool shut=CloseWindow(w);
                AppLog.Note("ro_close_first",(one.Doc??"a Repair Order")+(shut?" closed":" still open")+" for "+task.kind+" "+task.doc);
                Order.Require(shut,name+" was open in COSTAR "+t.Label+" and didn't close (COSTAR may be asking something). Answer it at the PC, then try again.");
                lock(gate) { if(state.leftOpen!=null&&state.leftOpen.window==w.ToInt64()) { state.leftOpen=null;Save(); } }
                beside.Closed.Add(one.Doc!=null?"RO "+one.Doc:"a Repair Order");
            }
        }
        RoReply Request(RoHello hello) {
            var request=(HttpWebRequest)WebRequest.Create(settings.baseUrl.TrimEnd('/')+"/api/worker/v1/ro");
            request.Method="POST";request.ContentType="application/json";request.Headers["Authorization"]="Bearer "+settings.token;request.AllowAutoRedirect=false;request.Proxy=null;
            request.Timeout=8000+hello.waitMs;request.ReadWriteTimeout=8000+hello.waitMs;request.ServicePoint.Expect100Continue=false;
            request.ServerCertificateValidationCallback=delegate(object sender,X509Certificate cert,X509Chain chain,System.Net.Security.SslPolicyErrors errors) {
                if(cert==null)return false;using(var c=new X509Certificate2(cert))return DateTime.Now>=c.NotBefore&&DateTime.Now<=c.NotAfter&&Wire.Equal(Wire.Hash(c.RawData),settings.certificateHash);
            };
            byte[] bytes=Encoding.UTF8.GetBytes(Wire.Json(hello));request.ContentLength=bytes.Length;
            pending=request;
            try {
                using(var output=request.GetRequestStream())output.Write(bytes,0,bytes.Length);
                try {using(var response=request.GetResponse())using(var input=response.GetResponseStream())using(var reader=new StreamReader(input,Encoding.UTF8))return Wire.Read<RoReply>(reader.ReadToEnd());}
                catch(WebException e) {
                    if(e.Response!=null)using(var input=e.Response.GetResponseStream())using(var reader=new StreamReader(input)) {
                        string body=reader.ReadToEnd();var code=((HttpWebResponse)e.Response).StatusCode;
                        // A desk older than 2.6.0 answers this route with "key invalid" (401) or "not found".
                        if(code==HttpStatusCode.NotFound||code==HttpStatusCode.Unauthorized) throw new InvalidOperationException("The desk receiver did not take the Repair Order request ("+(int)code+"). Update the desk receiver to 2.6.0 (yellow line on the desk PC).");
                        throw new InvalidOperationException("Receiver rejected the request: "+body);
                    }
                    throw;
                }
            } finally { pending=null; }
        }
        void Loop() {
            while(!disposed) {
                bool held=false;
                try {
                    string detail;bool accepting=Enabled,available=false;
                    if(!accepting) detail="Repair Orders switched off on the RDP helper";
                    else if(busy) detail="Working on a Repair Order";
                    else available=Free(out detail);
                    string working=runLease??"";
                    RoReport report;int sequence;lock(gate){report=state.report==null?null:Wire.Copy(state.report);sequence=state.sequence;}
                    string declined=declineLease,declinedWhy=declineReason;
                    int waitMs=accepting&&!busy&&declined==null&&AppSettings.Current.longPoll?(available?8000:2000):0;
                    var clock=Stopwatch.StartNew();interrupted=false;
                    var reply=Request(new RoHello {workerId=settings.workerId,accepting=accepting,available=available,detail=EbayText.Clean(detail,400),report=report,waitMs=waitMs,working=working,declined=declined,declineReason=declinedWhy,sequence=sequence,print=true,clears=true});
                    if(declined!=null&&declineLease==declined){declineLease=null;declineReason=null;}
                    held=reply!=null&&reply.held;
                    int waited=reply==null?0:Math.Max(0,reply.waitedMs);
                    RoundTripMs=(int)Math.Max(0,clock.ElapsedMilliseconds-waited);lastContactTick=Environment.TickCount==0?1:Environment.TickCount;
                    Connection="Desk PC connected";if(!busy)Detail=detail;
                    if(reply!=null&&report!=null&&reply.ack==report.sequence) lock(gate) { if(state.report!=null&&state.report.sequence==report.sequence){state.report=null;try{Save();}catch(Exception){}} }
                    if(reply!=null&&reply.command=="do"&&reply.task!=null&&!busy&&!disposed) {
                        if(Enabled) Accept(reply.task);
                        else if(reply.task.lease!=lastStartedLease) Decline(reply.task.lease,"Repair Orders switched off on the RDP helper");
                    }
                } catch(Exception e) {
                    if(disposed) break;
                    if(interrupted){interrupted=false;continue;}
                    Connection="Desk PC not reachable: "+NetworkRules.Unreachable(e);AppLog.PollError("ro: "+e.Message);
                }
                if(!disposed){int ms=held?100:Enabled?2000:3000;wake.WaitOne(ms);}
            }
        }
        // The lease of the last request started: one handed back again before its result is in (the
        // report not acknowledged yet) is never started a second time.
        volatile string lastStartedLease,runLease,runId;
        void Accept(RoTask task) {
            if(String.IsNullOrWhiteSpace(task.lease)||task.lease==lastStartedLease) return;
            if(task.kind!="list") {
                if(!RoEdit.IsDoc(task.doc)) { Report(task.id,task.lease,"failed","The Repair Order number isn't valid.","",false,false);return; }
                if(task.kind=="edit") {
                    try { Order.Require(task.edit!=null&&task.edit.doc==task.doc,"The change is for another Repair Order.");task.edit.ValidateShape(); }
                    catch(InvalidOperationException e) { Report(task.id,task.lease,"failed","Not changed: "+e.Message,"",false,false);return; }
                }
            }
            if(task.kind=="close") {
                RoLeftOpen left;lock(gate) left=state.leftOpen;
                if(left==null||left.doc!=task.doc) { Report(task.id,task.lease,"failed","The RDP helper didn't leave Repair Order "+task.doc+" open. If it is open in COSTAR, close it there.","",false,false);return; }
            }
            EntryLease entry=null;
            if(task.kind!="list") {
                string detail;CostarInstance target,prefer=null;
                // 2.9.6: closing the one this helper left open: in the COSTAR Tempe it was left in.
                if(task.kind=="close") { RoLeftOpen leftIn;lock(gate) leftIn=state.leftOpen;prefer=LeftIn(leftIn); }
                if(!Free(out detail,out target,task.kind=="close",prefer)) { Decline(task.lease,detail);return; }
                entry=coordinator.TryBegin("Repair Order "+task.doc,target,true);
                if(entry==null) { Decline(task.lease,coordinator.MobileHeld?HeldDetail:(coordinator.Owner.Length>0?coordinator.Owner:"Another entry")+" is filling COSTAR");return; }
            }
            bool startedThread=false,claimed=false;
            try {
                lock(gate) {
                    if(busy||disposed) return;
                    if(!Enabled) { Decline(task.lease,"Repair Orders switched off on the RDP helper");return; }
                    busy=true;claimed=true;runLease=task.lease;runId=task.id;lastStartedLease=task.lease;
                }
                var e2=entry;
                var thread=new Thread(delegate(){ if(task.kind=="list") RunList(task); else Run(task,e2); });
                thread.IsBackground=true;thread.SetApartmentState(ApartmentState.STA);thread.Start();startedThread=true;
            } finally { if(!startedThread){if(claimed){runLease=null;runId=null;lastStartedLease=null;busy=false;}if(entry!=null)entry.Dispose();} }
        }
        // Progress words for the phone (at most one report every 2.5 s).
        void Progress(string message) {
            log("RO: "+message);Detail=message;
            if(progressClock.ElapsedMilliseconds<2500) return;
            progressClock.Restart();
            var r=runner;string id=runId,lease=runLease;
            if(id==null||lease==null) return;
            try { Report(id,lease,"working",message,message,r!=null&&(r.Writes>0||r.Touched),false); } catch(Exception) { }
        }
        void Finish() { runLease=null;runId=null;busy=false;Current="";Interrupt(); }
        // Order Check's copy is used when it is this recent (it reads its own Tempe COSTAR every 2 minutes
        // in shop hours, pressing Search): the list comes at once and COSTAR Tempe isn't held up for it.
        // A fresh read (↻ on the phone) takes it only from the last 30 s.
        internal static readonly TimeSpan CopyAge=TimeSpan.FromMinutes(3),FreshCopyAge=TimeSpan.FromSeconds(30);
        void RunList(RoTask task) {
            try {
                Current="Work-in-Progress list";
                // 2.6.11: a clear of COSTAR's filter is always a read of COSTAR itself.
                var recent=task.clear?null:RoWip.FromOrderCheck(task.fresh?FreshCopyAge:CopyAge);
                if(recent!=null) {
                    Report(task.id,task.lease,"done",recent.rows.Count+" Repair Orders in Work-in-Progress · "+recent.note,"",false,false,null,recent);
                    LastLine="WIP list (Order Check's copy, "+recent.rows.Count+") at "+DateTime.Now.ToString("HH:mm");
                    AppLog.Note("ro_list",recent.rows.Count+" rows from "+recent.source+" (recent copy"+(task.fresh?", fresh asked":"")+")");
                    return;
                }
                Report(task.id,task.lease,"working","Reading COSTAR Tempe's Work-in-Progress","",false,false);
                RoList list=null;string why=null,detail;CostarInstance t;
                bool free=Free(out detail,out t),freeWithOpenRo=!free&&Free(out detail,out t,true);
                if(free||freeWithOpenRo) {
                    // With a Repair Order open nothing is pressed: the list is read as COSTAR shows it.
                    var entry=coordinator.TryBegin("Work-in-Progress list",t,true);
                    if(entry!=null) {
                        try {
                            // Search is pressed only with no Repair Order open now (looked at again here, not
                            // taken from the check a few seconds ago).
                            bool search=free&&CostarWindows.Orders(entry.Target).Count==0;
                            using(new CostarInputLock()) list=RoWip.ReadList(entry.Target,search,task.clear,delegate{return disposed||!Enabled;});
                            if(task.clear&&!search) list.note=(list.note.Length>0?list.note+"; ":"")+"COSTAR's filter wasn't cleared (a Repair Order is open there): close it, then try again";
                        }
                        catch(Exception e) { why=e.Message; }
                        finally { entry.Dispose(); }
                    } else why=coordinator.MobileHeld?HeldDetail:(coordinator.Owner.Length>0?coordinator.Owner:"Another entry")+" is filling COSTAR";
                } else { Free(out detail);why=detail; }
                if(list==null) {
                    // 2.6.11: a clear asked for is never answered with a copy (nothing was cleared): it fails with why.
                    var copy=task.clear?null:RoWip.FromOrderCheck(TimeSpan.FromMinutes(15));
                    if(copy!=null) { copy.note=copy.note+(why==null?"":" (COSTAR Tempe was busy: "+why+")");list=copy; }
                }
                if(list!=null) {
                    string words=list.rows.Count+" Repair Orders in Work-in-Progress"+(String.IsNullOrEmpty(list.note)?"":" · "+list.note);
                    Report(task.id,task.lease,"done",words,"",false,false,null,list);
                    LastLine="WIP list read ("+list.rows.Count+") at "+DateTime.Now.ToString("HH:mm");
                    AppLog.Note("ro_list",list.rows.Count+" rows from "+list.source);
                } else {
                    Report(task.id,task.lease,"failed","The Work-in-Progress list couldn't be read: "+(why??(t==null?"COSTAR Tempe wasn't found":"COSTAR is busy")),"",false,false);
                    AppLog.Note("ro_list_failed",why??"");
                }
            } catch(Exception e) {
                try { Report(task.id,task.lease,"failed","The Work-in-Progress list couldn't be read: "+e.Message,"",false,false); } catch(Exception) { }
            } finally { Finish(); }
        }
        static Order RoOrder(string doc) { return new Order {orderId="RO-"+doc,comment="",customer=new Customer {name="",phone=""},lines=new List<OrderLine>()}; }
        void Run(RoTask task,EntryLease entry) {
            CostarInputLock inputLock=null;var clock=Stopwatch.StartNew();string doc=task.doc;RoAttempt attempt=null;IntPtr window=IntPtr.Zero;Runner r=null;
            var watch=new RoOpenWatch();var times=new RoOpenTimes();CostarInstance target=null;PrintResult printing=null;var beside=new Beside();bool identified=false;
            string what=task.kind=="edit"?"Changing":task.kind=="close"?"Closing":task.kind=="print"?"Printing the Job Card of":"Opening";
            // 2.6.2: the Job Card printed once the Repair Order is read (print) or the change is in and checked.
            bool print=task.kind=="print"||(task.kind=="edit"&&task.edit!=null&&task.edit.print);
            try {
                Current=what+" Repair Order "+doc;progressClock.Restart();
                inputLock=new CostarInputLock();var t=entry.Target;target=t;CostarWindows.Main(t);
                coordinator.Progress.Begin("Repair Order",doc,(task.kind=="edit"?10:3)+(print?1:0));
                if(task.kind=="close") { RunClose(task,t);return; }
                // 2.6.2: a print alone right after one of this Repair Order (the desk restarted and the phone
                // asked again, say) isn't done: the first may still be on its way to the printer.
                if(task.kind=="print") {
                    string recent=RecentPrint(doc);
                    if(recent!=null) {
                        lock(gate) { SetReport(task.id,task.lease,"failed",recent,"",false,false);Save(); }
                        Detail=recent;log("RO: "+recent);Interrupt();
                        coordinator.Progress.End(false,doc+": a Job Card went moments ago");
                        AppLog.Note("ro_print_recent",doc);
                        return;
                    }
                }
                attempt=new RoAttempt {id=task.id,lease=task.lease,kind=task.kind,doc=doc,processId=t.Pid,processStart=t.Started,atUtc=Now};
                Running(attempt);
                Report(task.id,task.lease,"working",what+" Repair Order "+doc+" in COSTAR "+t.Label,"",false,false);
                AppLog.Note("ro_"+task.kind+"_start",doc+(task.kind=="edit"?" ("+task.edit.Summary()+(print?"; print the Job Card":"")+")":""));
                // 2.6.8: nothing is closed first for an open that can't happen now: COSTAR Tempe must be on
                // Work-in-Progress (RoWip.Open needs it; Free's answer may be up to 3 s old).
                string notWip=CostarWindows.WhyNotOnWip(t);
                Order.Require(notWip==null,notWip+". Nothing was closed or opened.");
                // 2.6.7: a Repair Order open in COSTAR Tempe closed first, when it may be (CloseFirst).
                CloseOpenFirst(task,t,beside);
                RoListRow listed;bool selected;
                window=RoWip.Open(t,doc,delegate{return !Enabled||disposed;},Progress,watch,times,out listed,out selected,null,beside.Stay);
                attempt.window=window.ToInt64();Running(attempt);
                r=new Runner(t.Pid,t.Branch,RoOrder(doc),"",false,Progress,window.ToInt64());runner=r;
                r.OnStage=coordinator.Progress.Stage;
                r.BeforePress=delegate { RoWip.Quiet(watch,doc); };
                r.BeforeFirstWrite=delegate { if(!attempt.touched){attempt.touched=true;Running(attempt);} };
                r.Cancel=!Enabled||disposed;
                // The open from Work-in-Progress happens before the run starts: its time is the run's "open" time.
                r.Diag.OpenNewMs=times.TotalMs;r.Diag.EventRaw("ro_wip",times.ToString());
                var snap=r.ReadRo(doc,listed,selected);
                identified=true;   // 2.9.6: the window is this Repair Order (its number, or its name, comment, PO# and total)
                List<string> notes=new List<string>();string done="";
                if(task.kind=="edit") {
                    if(snap.sig!=task.edit.baseSig) {
                        // Someone changed it after the phone read it: nothing is typed; the phone gets what it holds now.
                        bool shut=r.CloseRo();
                        if(!shut) Left(doc,window,t);
                        string changedCheck;string besideWords=BesideSaid(beside,t,doc,out changedCheck,true).Trim();   // 2.9.6: also what was closed first, and kept (since 2.6.7 left out here)
                        lock(gate) { state.running=null;SetReport(task.id,task.lease,"failed","CHANGED: Repair Order "+doc+" changed after your phone read it, so nothing was typed. Here is what it holds now: check your changes and save again."+(shut?"":" COSTAR didn't close it (it may be asking something): close it at the PC.")+Also(SaidOnTheWay(r,times))+Also(besideWords),"",false,!shut,snap,null,changedCheck==null?null:new List<string>{changedCheck});Save(); }
                        Interrupt();coordinator.Progress.End(false,doc+" changed meanwhile");
                        AppLog.Note("ro_edit_changed",doc+" | "+times);
                        r.Diag.Completed();
                        return;
                    }
                    snap=r.EditRo(task.edit,snap);
                    // Things to check by hand only (2.6.11: what COSTAR showed on the way in goes with the words, below).
                    notes.AddRange(r.RoNotes);notes.AddRange(r.Checks);
                    done="Saved to COSTAR: "+task.edit.Summary()+".";
                    // 2.6.1: the phone hears it is in and checked now; COSTAR's close takes a second or two.
                    try { Report(task.id,task.lease,"working","All of it is in and checked. "+(print?"Printing its Job Card, then closing":"Closing")+" Repair Order "+doc+" again in COSTAR.",print?"Checked; printing the Job Card":"Checked; closing it again in COSTAR",true,false,snap,null,notes); } catch(Exception) { }
                } else if(print) {
                    notes.AddRange(r.Checks);   // a memo's words: to check by hand (the rest goes with the words, below)
                    try { Report(task.id,task.lease,"working","Read Repair Order "+doc+". Printing its Job Card.","Read; printing the Job Card",false,false,snap); } catch(Exception) { }
                } else {
                    // 2.6.11: a read shows these with the Repair Order: COSTAR's notices answered with OK on the way in
                    // (the customer's Notes; a memo's words), and a filter at the PC cleared to find it.
                    notes.AddRange(r.Notices);notes.AddRange(r.Checks);
                    if(times.FilterCleared) notes.Add(FilterClearedWords(times));
                    // 2.6.1: the phone shows the Repair Order now, while COSTAR closes it (a second or two).
                    try { Report(task.id,task.lease,"working","Read Repair Order "+doc+". Closing it again in COSTAR.","Read; closing it again in COSTAR",false,false,snap); } catch(Exception) { }
                }
                // 2.6.2: the Job Card. Never stops the rest: what happened goes with the result. Just before OK
                // the attempt notes it (a helper that closes then says the Job Card may have printed). After a
                // Stop in it, nothing more is done: the Repair Order isn't closed.
                string printWords="";
                if(print) {
                    printing=r.PrintJobCard(doc,delegate { attempt.printing=true;Running(attempt); });
                    if(printing.Printed||printing.Maybe) lock(gate) printedAt[doc]=DateTime.UtcNow;
                    printWords=printing.Words+" ";
                }
                bool printed=printing!=null&&printing.Printed,maybe=printing!=null&&printing.Maybe,stopped=printing!=null&&printing.Stopped;
                bool closed=!stopped&&r.CloseRo();
                if(!closed) Left(doc,window,t);
                string closing=stopped?"Stopped: Repair Order "+doc+" is left open in COSTAR Tempe: close it there or from the phone."
                    :closed?(task.kind=="edit"?"Closed again (it's in Work-in-Progress).":task.kind=="print"?"Closed again.":"Read and closed again.")
                    :task.kind=="edit"?"All of it is in and checked, but COSTAR didn't close the Repair Order: it may be asking something at the PC. Answer it there, then close it (or close it from the phone)."
                    :"COSTAR didn't close it again (it may be asking something at the PC): close it there or from the phone.";
                // A print-only request that surely printed nothing failed; one that may have printed didn't
                // (the phone says to check the printer, never to print again).
                string status=task.kind=="print"&&!printed&&!maybe?"failed":"done";
                // 2.6.11: a change or a print says what COSTAR showed on the way in, and a filter cleared, in its words.
                string besideCheck;string besideDone=BesideSaid(beside,t,doc,out besideCheck,true);   // worked out before the lock: it may read COSTAR
                if(besideCheck!=null) notes.Insert(0,besideCheck);   // shown with a read, and a save turns to a warning
                lock(gate) { state.running=null;SetReport(task.id,task.lease,status,besideDone+(done.Length>0?done+" ":"")+printWords+closing+(task.kind=="open"?"":Also(SaidOnTheWay(r,times))),"",task.kind=="edit",!closed,snap,null,notes);Save(); }
                Detail=done.Length>0?done:print?printWords.Trim():"Read Repair Order "+doc+".";log("RO: "+Detail);Interrupt();
                r.Diag.Completed();
                string printedWords=printed?"Job Card printed":maybe?"Job Card may have printed":"Job Card not printed";
                LastLine=(task.kind=="edit"?"Changed ":task.kind=="print"?(printed?"Printed the Job Card of ":maybe?"May have printed the Job Card of ":"Didn't print the Job Card of "):"Read ")+doc+(print&&task.kind=="edit"?", "+printedWords:"")+(r.Checks.Count>0||r.RoNotes.Count>0?" (check by hand)":"")+(closed?"":" (left open)")+" at "+DateTime.Now.ToString("HH:mm");
                coordinator.Progress.End(status=="done",doc+(task.kind=="edit"?" changed":task.kind=="print"?" "+printedWords:" read")+(closed?"":", left open"));
                AppLog.Note("ro_"+task.kind+"_ok",doc+" in "+(clock.ElapsedMilliseconds/100/10.0).ToString("0.0",CultureInfo.InvariantCulture)+" s run="+r.Diag.RunId+(print?(printed?" printed":maybe?" may have printed: "+RoText.ForLog(printWords):" not printed: "+RoText.ForLog(printWords)):"")+(stopped?" stopped":"")+(notes.Count>0?" notes="+notes.Count:"")+(closed?"":" left open")+" | "+times);
            } catch(Exception e) {
                try{if(r!=null)r.Diag.Stopped(e);}catch{}
                // Typed: a write was tried (counted before it goes), not only one that went through.
                bool typed=(attempt!=null&&attempt.touched)||(r!=null&&(r.Writes>0||r.Touched)),leftOpen=false,gone=false;string extra="";
                // 2.9.6: one kept open beside it closed or changed (COSTAR may have made its window again, so it would look
                // like this request's): nothing is taken for this request's own, closed or remembered as left open.
                // Only until the window is known to be this Repair Order (identified): then it is this request's own, as
                // before. A window that is one of the kept ones is never this request's.
                bool keptChanged=beside.Stay.Count>0&&target!=null&&((!identified&&(watch.KeptChanged||beside.Stay.Any(w=>!RoWip.KeptThere(new IntPtr(w),target.Pid))))||beside.Stay.Contains(window.ToInt64()));
                if(keptChanged) {
                    if(window!=IntPtr.Zero) extra=" A Repair Order window was left as it is in COSTAR: check it at the PC.";
                    window=IntPtr.Zero;
                }
                // A Repair Order window that opened but wasn't handed over (the open stopped after it
                // appeared) is this helper's only when nobody used the PC meanwhile and it is the only one.
                if(keptChanged) { }
                else if(window==IntPtr.Zero&&target!=null&&watch.Before!=null&&!watch.UserActive&&!(e is RoInUseException)) {
                    try {
                        var fresh=CostarWindows.Orders(target).Where(x=>!watch.Before.Contains(x.ToInt64())).ToList();
                        if(fresh.Count==1&&Branches.OrderTitle(Native.Caption(fresh[0]),target.Branch)) window=fresh[0];
                        else if(fresh.Count>1) extra=" COSTAR opened "+fresh.Count+" Repair Order windows: check them and close them at the PC.";
                    } catch(Exception) { }
                } else if(window==IntPtr.Zero&&watch.UserActive&&!(e is RoInUseException)) extra=" If a Repair Order opened, it was left as it is.";
                if(window!=IntPtr.Zero) {
                    if(Native.IsWindow(window)) {
                        bool shut=false;
                        // Closed again only when nothing was typed and no Stop was pressed; never over a COSTAR question.
                        if(!typed&&!(e is OperationCanceledException)) { try { shut=r!=null?r.CloseRo():CloseWindow(window); } catch(Exception) { shut=false; } }
                        if(!shut&&Native.IsWindow(window)) { try { Left(doc,window,entry.Target); } catch(Exception) { } leftOpen=true; }
                    } else gone=true;
                }
                // 2.9.4: open on another PC (COSTAR's Document Already Open, its OK pressed): said as it is, not as a stop.
                var inUse=e as RoInUseException;bool inUseLeft=inUse!=null&&leftOpen;
                string message=inUse!=null?DocumentInUse.Message(inUse,inUseLeft,task.kind,true):(e.Message.StartsWith("CHANGED:",StringComparison.Ordinal)?"":"Stopped: ")+e.Message;
                // 2.6.2: what the print came to, if it got that far.
                if(printing!=null) message+=" "+printing.Words;
                else if(attempt!=null&&attempt.printing) message+=" The Job Card may have printed: check the printer.";
                if(typed&&r!=null&&r.RoDone.Count>0) message+=" Already changed: "+String.Join("; ",r.RoDone.ToArray())+".";
                if(inUse!=null) { }
                else if(leftOpen) message+=" Repair Order "+doc+" is left open in COSTAR Tempe: check it there, then close it (or close it from the phone).";
                else if(typed) message+=gone?" The Repair Order was closed while the helper was typing (at the PC, or COSTAR stopped): check Repair Order "+doc+" in COSTAR Tempe.":" Check Repair Order "+doc+" in COSTAR Tempe.";
                else if(window!=IntPtr.Zero) message+=gone?" It was closed before anything was typed.":" Nothing was changed; it was closed again.";
                message+=extra;
                // 2.6.11: a filter at the PC emptied on the way, and COSTAR's notices answered, are said with a stop too.
                message+=Also(SaidOnTheWay(r,times));
                string besideStop;string before=BesideSaid(beside,target,doc,out besideStop);if(before.Length>0) message=before+message;
                LastLine=doc+(inUse!=null?" is open on another PC (":" stopped at ")+DateTime.Now.ToString("HH:mm")+(inUse!=null?")":"");
                coordinator.Progress.End(false,inUse!=null?doc+" is open on another PC":doc+" stopped: "+e.Message);
                AppLog.Note(inUse!=null?"ro_"+task.kind+"_in_use":"ro_"+task.kind+"_stopped",doc+" "+RoText.ForLog(e.Message)+(typed?" (typed)":"")+(leftOpen?" (left open)":"")+(r!=null?" run="+r.Diag.RunId:"")+(times.TotalMs>0?" | "+times:""));
                // 2.9.4: COSTAR's words for the phone only (this helper's log and status line without them).
                string shown=inUse!=null?DocumentInUse.Message(inUse,inUseLeft,task.kind,false):message;
                try { lock(gate) { state.running=null;SetReport(task.id,task.lease,"failed",message,"",typed,leftOpen);Save(); } Detail=shown;log("RO: "+shown);Interrupt(); }
                catch(Exception persist) { Enabled=false;log("RO: Repair Orders stopped: the result could not be saved. "+persist.Message); }
            } finally {
                try{if(r!=null){r.Dispose();log("RO: COSTAR report: "+r.ZipPath);}}catch(Exception){}
                finally{runner=null;try{if(inputLock!=null)inputLock.Dispose();}finally{try{entry.Dispose();}finally{Finish();}}}
            }
        }
        // 2.6.11: a person's search at the PC emptied to find the Repair Order (its words: for the phone only).
        static string FilterClearedWords(RoOpenTimes times) { return "COSTAR's Work-in-Progress was filtered at the PC ("+times.Filter+"): the filter was cleared to find this Repair Order."; }
        // What COSTAR showed on the way in (the customer's Notes answered) and a filter cleared, as words ("" none).
        static string SaidOnTheWay(Runner r,RoOpenTimes times) {
            var said=new List<string>();
            if(r!=null) said.AddRange(r.Notices);
            if(times.FilterCleared) said.Add(FilterClearedWords(times));
            return String.Join(" ",said.ToArray());
        }
        static string Also(string words) { return words.Length>0?" "+words:""; }
        // Remembered so the phone (or a person) can have it closed later.
        void Left(string doc,IntPtr window,CostarInstance t) {
            lock(gate) { state.leftOpen=new RoLeftOpen {doc=doc,window=window.ToInt64(),processId=t.Pid,processStart=t.Started,atUtc=Now};state.running=null;Save(); }
        }
        // WM_CLOSE to a Repair Order window, only while nothing of COSTAR's is open on it. 2.6.10: also for a new
        // phone job (WorkerEngine.CloseOpenFirst).
        internal static bool CloseWindow(IntPtr window) {
            if(!Native.IsWindow(window)) return true;
            if(Runner.CloseBlocker(window)!=null) return false;
            UIntPtr result;Native.WriteMessage(window,0x10,UIntPtr.Zero,null,3,1000,out result);
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<8000) { if(!Native.IsWindow(window)) return true;Thread.Sleep(100); }
            return false;
        }
        // Closes the Repair Order this helper left open (only that window, in the same COSTAR, and only
        // while COSTAR shows nothing on it).
        void RunClose(RoTask task,CostarInstance t) {
            RoLeftOpen left;lock(gate) left=state.leftOpen;
            Order.Require(left!=null&&left.doc==task.doc,"The RDP helper didn't leave Repair Order "+task.doc+" open.");
            var h=new IntPtr(left.window);
            if(!Native.IsWindow(h)||(int)Native.Pid(h)!=left.processId) {
                lock(gate) { state.leftOpen=null;SetReport(task.id,task.lease,"done","Repair Order "+task.doc+" was already closed.","",false,false);Save(); }
                coordinator.Progress.End(true,task.doc+" was already closed");
                LastLine="Already closed: "+task.doc+" at "+DateTime.Now.ToString("HH:mm");
                Interrupt();return;
            }
            Order.Require(left.processId==t.Pid&&left.processStart==t.Started&&Native.Caption(h).StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase),"That Repair Order belongs to another COSTAR. Close it at the PC.");
            string why=Runner.CloseBlocker(h);
            if(why!=null) {
                lock(gate) { SetReport(task.id,task.lease,"failed","Repair Order "+task.doc+" wasn't closed: "+why+". Answer it at the PC, then close it there (or from the phone).","",false,true);Save(); }
                coordinator.Progress.End(false,task.doc+" not closed");
                LastLine="Couldn't close "+task.doc+" at "+DateTime.Now.ToString("HH:mm");
                AppLog.Note("ro_close","blocked");
                Interrupt();return;
            }
            Progress("Closing Repair Order "+task.doc+".");
            bool shut=CloseWindow(h);
            lock(gate) {
                if(shut) state.leftOpen=null;
                SetReport(task.id,task.lease,shut?"done":"failed",shut?"Closed Repair Order "+task.doc+" (it's in Work-in-Progress).":"COSTAR didn't close Repair Order "+task.doc+": it may be asking something. Answer it at the PC.","",false,!shut);Save();
            }
            AppLog.Note("ro_close",task.doc+(shut?" closed":" still open"));
            coordinator.Progress.End(shut,task.doc+(shut?" closed":" not closed"));
            LastLine=(shut?"Closed ":"Couldn't close ")+task.doc+" at "+DateTime.Now.ToString("HH:mm");
            Interrupt();
        }
        public void Dispose(){disposed=true;Stop(false);}
    }
}
