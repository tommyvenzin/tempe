// Tempe Buffalo Fill 1.0.4 — background service worker.
// Talks only to the Tempe helper on this PC (127.0.0.1:8811-8840), every request and answer signed with the key the
// helper wrote into this extension's own folder (pair.json, read with the extension's own URL; never sent anywhere).
// It asks for a job only for the Create Consignment tab showing in front (the active tab of the Chrome window used last,
// its page visible), only when that page is settled and blank, takes the job once, fills that same document in the
// page's own world (fill.js) and tells the helper what happened. What keeps the page from taking a job (not blank, a
// page check that failed, a page showing in another window) is told to the helper too, so it can say why.
// 1.0.3: Chrome needn't have the keyboard (1.0.2 needed a click into Chrome): the person clicks Fill in the helper and
// stays there, with the Buffalo page showing beside it.
// 1.0.4 (Tommy, 27 Nov: "give me the extension please and make it auto update"): it looks for a newer version in its
// folder about once a minute while Chrome is open, with or without a Create Consignment page (1.0.3 looked only after a
// page's tick), never reloads during a fill, tries again later when a reload came back still old (1.0.3: once per
// version, ever), and says so, on its button and to the helper, when it can't update itself.
importScripts('fill.js');   // self.tempeBuffalo

const CREATE = 'https://portal.transvirtual.com/Portal/Consignment/Create';
const FIRST = 8811, PORTS = 30, SCHEMA = 1;
const VERSION = chrome.runtime.getManifest().version;
const CHROME = (((typeof navigator !== 'undefined' && navigator.userAgent) || '').match(/Chrome\/(\d+)/) || [])[1] || '?';
// A copy of the extension loaded from anywhere but the helper's folder has no pair.json, so it can't be paired.
const NOKEY = 'this copy of Tempe Buffalo Fill has no key (pair.json), so it can’t reach the helper. In chrome://extensions click Remove on it, ' +
  'then Load unpacked and choose the folder the helper keeps it in: %LOCALAPPDATA%\\TempeMobileCostar\\BuffaloFill (paste that into the folder box)';
let keyPromise = null, busy = false, asideBusy = false;
const state = { line: 'Starting.', helper: null, port: null, at: 0 };
// The last line survives the service worker being stopped (storage.session lasts until Chrome closes).
const note = line => { if (line === state.line) return; state.line = line; state.at = Date.now(); chrome.storage.session.set({ line: state.line, at: state.at }).catch(() => { }); };
const short = e => String((e && e.message) || e).slice(0, 100);
const restored = chrome.storage.session.get(['line', 'at']).then(s => { if (s.line && state.line === 'Starting.') { state.line = s.line; state.at = s.at || 0; } }).catch(() => { });
const LOST = /isn’t running|isn’t reachable|Lost the helper|More than one helper/;
const CONNECTED = 'Connected to the Tempe helper: open a blank Create Consignment page, then click Fill Buffalo page in the helper.';

// ---- the key and the signatures (the helper's BuffaloLink computes the same) ----
const fromB64Url = s => { s = String(s || '').replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; const b = atob(s); return Uint8Array.from(b, c => c.charCodeAt(0)); };
const toB64Url = a => btoa(String.fromCharCode.apply(null, Array.from(a))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const hex = buf => Array.from(new Uint8Array(buf), b => b.toString(16).padStart(2, '0')).join('');
async function key() {
  if (!keyPromise) keyPromise = (async () => {
    // A file that isn't there makes Chrome's fetch fail outright ("Failed to fetch"), not answer 404.
    let r = null;
    try { r = await fetch(chrome.runtime.getURL('pair.json'), { cache: 'no-store' }); } catch (e) { }
    if (!r || !r.ok) throw new Error(NOKEY);
    let raw = null;
    try { raw = fromB64Url((await r.json()).key); } catch (e) { }
    if (!raw || raw.length !== 32) throw new Error('pair.json holds no usable key: start the Tempe helper (RDP) once, then click Reload on Tempe Buffalo Fill in chrome://extensions');
    return crypto.subtle.importKey('raw', raw, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  })().catch(e => { keyPromise = null; throw e; });
  return keyPromise;
}
const sha = async bytes => hex(await crypto.subtle.digest('SHA-256', bytes));
const mac = async text => hex(await crypto.subtle.sign('HMAC', await key(), new TextEncoder().encode(text)));

// One signed POST; throws unless the answer is signed by the helper that holds the key, for this port and this nonce.
async function call(port, path, value, timeoutMs) {
  const body = new TextEncoder().encode(JSON.stringify(value));
  const ts = String(Date.now()), nonce = toB64Url(crypto.getRandomValues(new Uint8Array(16)));
  const sig = await mac(['req', 'POST', '127.0.0.1:' + port, path, ts, nonce, await sha(body)].join('\n'));
  const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), timeoutMs || 4000);
  try {
    const r = await fetch('http://127.0.0.1:' + port + path, { method: 'POST', body, cache: 'no-store', credentials: 'omit', redirect: 'error', signal: ctl.signal,
      headers: { 'Content-Type': 'application/json', 'X-Tbf-Ts': ts, 'X-Tbf-Nonce': nonce, 'X-Tbf-Mac': sig } });
    const got = new Uint8Array(await r.arrayBuffer());
    const want = await mac(['resp', '127.0.0.1:' + port, nonce, String(r.status), await sha(got)].join('\n'));
    if ((r.headers.get('X-Tbf-Mac') || '') !== want) throw new Error('an answer not signed by this Windows user’s helper');
    return { status: r.status, json: JSON.parse(new TextDecoder().decode(got)) };
  } finally { clearTimeout(timer); }
}

// ---- finding this user's helper: the one port whose hello is signed with our key ----
let lastSearch = 0, searchWait = 1000, searching = null;
// now: the popup asks, so search once even inside the wait (the wait itself is left as it is). 1.0.4: one search at a
// time; whoever asks while one runs (the worker's start check and a page's first tick) gets its answer.
async function helperPort(now) {
  await key();   // no key: say so (the caller shows why), rather than search and call it "not running"
  const s = await chrome.storage.session.get('port');
  if (s.port) { state.port = s.port; return s.port; }
  if (searching) return searching;
  if (!now && Date.now() - lastSearch < searchWait) return null;
  lastSearch = Date.now();
  searching = (async () => {
    const tries = [];
    for (let p = FIRST; p < FIRST + PORTS; p++) tries.push(call(p, '/buffalo/hello', { ext: VERSION, schema: SCHEMA, chrome: CHROME }, 1500).then(a => a.status === 200 && a.json.ok ? { p, a } : null).catch(() => null));
    const found = (await Promise.all(tries)).filter(Boolean);
    if (found.length !== 1) { searchWait = Math.min(Math.max(searchWait, 1000) * 2, 30000); note(found.length ? 'More than one helper answers for this key: none used.' : 'The Tempe helper (RDP) isn’t running or isn’t reachable.'); return null; }
    searchWait = 1000; state.helper = found[0].a.json.helper; state.port = found[0].p;
    await chrome.storage.session.set({ port: found[0].p });
    return found[0].p;
  })();
  try { return await searching; } finally { searching = null; }
}
async function forget() { state.port = null; state.helper = null; await chrome.storage.session.remove('port'); }
// 1.0.4: one signed hello, the answer's JSON (null: no helper answered). problem: what keeps a page from taking a job, or
// why this extension can't update itself; an update check sends none, so it changes nothing the helper shows about
// pages. A remembered port that no longer answers (the helper restarted on another) is forgotten and the ports searched
// again (within the search's own back-off; now: at once, for the popup).
async function hello(problem, now) {
  for (let tries = 0; tries < 2; tries++) {
    const port = await helperPort(now);
    if (!port) return null;
    const value = { ext: VERSION, schema: SCHEMA, chrome: CHROME };
    if (typeof problem === 'string') value.problem = problem;
    let a = null;
    try { a = await call(port, '/buffalo/hello', value, 1500); } catch (e) { }
    if (a && a.status === 200 && a.json && a.json.ok) { state.helper = a.json.helper; return a.json; }
    await forget();
  }
  return null;
}

// ---- a newer version in this folder (the helper copies it there when it starts): reload, never during a fill ----
const newer = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };
// 1.0.4: before each reload the version it is for, this version, the time and the tries so far are kept (storage.local,
// "update"). A worker that starts still older than that version came back old: it says so, and tries again at most every
// 10 min, 3 tries in all for one version. Reached (or passed): the mark goes. One the helper no longer ships (or no longer
// has in this folder) goes too.
const UPDATE = 'update', RETRY_MS = 10 * 60 * 1000, TRIES = 3;
let upd = null, reloading = false, afterFill = false;
// What it tells the helper when a reload came back still old. The helper knows these words by their opening
// (InvoiceUi.CantUpdate): change both together. Kept under the helper's 200 characters.
const STUCK = 'it reloaded itself to update to ';
const stuckWords = () => STUCK + upd.to + ' but is still ' + VERSION + ': in chrome://extensions click Reload on it, or Remove it and Load unpacked %LOCALAPPDATA%\\TempeMobileCostar\\BuffaloFill';
const stuck = () => !!upd && !reloading && upd.tries > 0 && newer(upd.to, VERSION);
// The button: a red "!" while it can't update itself (the popup's line says what to do).
function badge(on) {
  try { const p = chrome.action.setBadgeText({ text: on ? '!' : '' }); if (p && p.catch) p.catch(() => { }); } catch (e) { }
  if (on) try { const p = chrome.action.setBadgeBackgroundColor({ color: '#a01818' }); if (p && p.catch) p.catch(() => { }); } catch (e) { }
}
function showStuck() {
  note('Can’t update itself: it reloaded itself to update to ' + upd.to + ' but is still ' + VERSION + ', so Chrome isn’t loading it from the helper’s folder, or didn’t take the update. ' +
    'In chrome://extensions click Reload on Tempe Buffalo Fill; if it stays ' + VERSION + ', click Remove on it, then Load unpacked and choose the folder the helper keeps it in: ' +
    '%LOCALAPPDATA%\\TempeMobileCostar\\BuffaloFill (paste that into the folder box).');
  badge(true);
}
async function dropUpdate() { upd = null; badge(false); try { await chrome.storage.local.remove(UPDATE); } catch (e) { } }
// At the worker's start: did the last reload reach its version?
const started = chrome.storage.local.get([UPDATE, 'reloadedFor']).then(async s => {
  if (s && 'reloadedFor' in s) await chrome.storage.local.remove('reloadedFor');   // 1.0.3's once-ever mark: not used
  const r = s && s[UPDATE];
  if (!r || typeof r.to !== 'string') return;
  if (!newer(r.to, VERSION)) { await chrome.storage.local.remove(UPDATE); note('Updated itself to ' + VERSION + '.'); return; }
  upd = { to: r.to, from: String(r.from || ''), at: Number(r.at) || 0, tries: Math.max(1, Number(r.tries) || 1) };
  showStuck();
}).catch(() => { });
// Returns true when this extension isn't the version the helper ships (the helper then gives it no job).
async function versions(a) {
  await started;
  if (!a || !a.extShipped) return false;
  if (upd && (upd.to !== a.extShipped || a.extOnDisk !== a.extShipped)) await dropUpdate();
  if (a.extShipped === VERSION) return false;
  if (a.extOnDisk === a.extShipped && newer(a.extOnDisk, VERSION)) {
    if (reloading) return true;
    const r = upd && upd.to === a.extOnDisk ? upd : { to: a.extOnDisk, tries: 0, at: 0 }, now = Date.now();
    if (r.tries < TRIES && (now - r.at >= RETRY_MS || now < r.at)) {
      // Never while a job has been asked for, taken or is being filled (a tick's busy): tried again when that tick ends.
      if (busy) { afterFill = true; return true; }
      reloading = true;
      upd = { to: r.to, from: VERSION, at: now, tries: r.tries + 1 };
      try { await chrome.storage.local.set({ [UPDATE]: upd }); } catch (e) { reloading = false; upd = null; return true; }
      badge(false);
      note('Updating itself to ' + upd.to + ' (the helper ships it) …');
      setTimeout(() => chrome.runtime.reload(), 300);
      return true;
    }
    if (stuck()) { showStuck(); return true; }
  }
  // 2.9.22 (review): the helper couldn't put its version in this folder, so a Reload would load these same files again:
  // the helper has to copy them first (it does when it starts).
  if (a.extOnDisk !== a.extShipped) note('This extension is ' + VERSION + ' but the helper ships ' + a.extShipped + ', and the helper couldn’t update this extension’s folder, so it can’t update itself: ' +
    'close the Tempe helper (RDP) and start it again (its Invoice tab says why the copy failed).');
  else note('This extension is ' + VERSION + ' but the helper ships ' + a.extShipped + ': in chrome://extensions click Reload on Tempe Buffalo Fill, then refresh the Buffalo page.');
  return true;
}
// One update check: a signed hello with no problem (or, while it can't update itself, the words that say so, as often as
// tell() lets them go), then versions() on the helper's answer. From the alarm, the worker's start, Chrome's start, an
// install, and the end of a tick that held a reload back. Never two at once.
let checking = null;
function check() {
  if (!checking) checking = (async () => {
    await restored; await started;
    if (stuck()) { await tell(stuckWords(), 'update'); return; }
    const a = await hello();
    if (!a) return;
    if (LOST.test(state.line)) note(CONNECTED);
    await versions(a);
  })().catch(() => { }).then(() => { checking = null; });
  return checking;
}
// About once a minute while Chrome is open (Chrome's shortest alarm period is 1 minute before Chrome 120, 30 s from it).
// Made at every start of the worker when it isn't there (Chrome may drop alarms when it restarts).
const ALARM = 'tempe-update-check';
function alarm() {
  try { chrome.alarms.get(ALARM, a => { if (chrome.runtime.lastError || !a) chrome.alarms.create(ALARM, { delayInMinutes: 1, periodInMinutes: 1 }); }); } catch (e) { }
}
if (chrome.alarms) chrome.alarms.onAlarm.addListener(a => { if (a && a.name === ALARM) check(); });

// ---- one tick from a Create Consignment tab that shows ----
// Is the asking tab still the one in front where the person looks: the active tab of the Chrome window used last (the
// normal window focused most recently, whether or not it has the keyboard now: 1.0.3), and that window not minimised?
// Its page says itself whether it is visible (look.front); a tab behind another, or in a minimised window, isn't. Two
// windows each showing a Create page: only the one used last can take a job (the other is told it can't). Asked again
// before the job is taken and before it's filled.
async function inFront(sender) {
  try {
    const t = await chrome.tabs.get(sender.tab.id);
    if (!t || !t.active || t.windowId !== sender.tab.windowId) return false;
    const w = await chrome.windows.getLastFocused({ windowTypes: ['normal'] });
    return !!w && w.id === t.windowId && w.state !== 'minimized';
  } catch (e) { return false; }
}
// A page that ticks shows, so one that isn't in front is in another window (or beside the active tab): said to the
// helper, so its line can say why nothing is filled, with what to do. One click on that page makes it the one in front
// in both cases. The helper knows these words by their opening (InvoiceUi.OtherWindow): change both together.
const NOT_FRONT = 'a blank Create Consignment page is showing in Chrome that isn’t the tab in front in the Chrome window you used last, so it can’t be filled: click once on that page to fill';
// What keeps the page in front from taking a job, told to the helper in a signed hello (no job is asked for or given)
// so its line can say why: when it changes, else at most every 15 s. Only the extension's own words, never the page's
// boxes. Nothing is told without the key. Only a hello the helper answered counts as told; a remembered port that no
// longer answers (the helper restarted on another) is forgotten and the ports searched again (within the search's own
// back-off). The answer can say a newer version is in this extension's folder: reloaded as after a poll.
// 1.0.3: counted for each page on its own (doc: the page's document), so two pages showing, each with its own reason,
// don't send a hello on every tick by taking turns. 1.0.4: why it can't update itself is counted as one more ('update').
const told = new Map();   // document -> { text, at }
async function tell(text, doc) {
  const now = Date.now();
  for (const [d, t] of told) if (now - t.at >= 15000) told.delete(d);
  const last = told.get(doc);
  if (last && last.text === text) return;
  try {
    const a = await hello(text);
    if (a) { told.set(doc, { text: text, at: Date.now() }); await versions(a); }
  } catch (e) { }
}
// A page check that didn't work: on the button's line and to the helper, with Chrome's version.
function trouble(text, doc) { note('Buffalo page: ' + text + ' (Chrome ' + CHROME + ').'); tell(text + ' (Chrome ' + CHROME + ')', doc); }

// The fill's answer as it left it on the page, for when Chrome hands back nothing from the fill: read every half second
// for up to 25 s (the helper calls a fill silent 30 s after it was taken). null if the page is gone or never says.
async function answer(target, id) {
  const end = Date.now() + 25000;
  while (Date.now() < end) {
    let a = null;
    try { const [r] = await chrome.scripting.executeScript({ target, world: 'MAIN', func: self.tempeBuffalo, args: ['answer', { id: id }] }); a = r && r.result; }
    catch (e) { return null; }
    if (a && a.result && a.result.id === id) return a.result;
    await new Promise(r => setTimeout(r, 500));
  }
  return null;
}

// A page that shows but isn't in front (another window, or beside the active tab): when it is blank and could otherwise
// be filled, the helper is told why it isn't (each page at most every 15 s). No job is asked for it, and its looks don't
// count towards the page in front being settled.
async function besides(sender) {
  if (asideBusy) return;
  asideBusy = true;
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: sender.tab.id, documentIds: [sender.documentId] }, world: 'MAIN', func: self.tempeBuffalo, args: ['look'] });
    const look = res && res.result;
    if (look && look.ok === true && look.quiet === true && !look.why && look.front === true) await tell(NOT_FRONT, sender.documentId);
  } catch (e) { } finally { asideBusy = false; }
}

// Settled: the same look (rows and moving boxes) with nothing loading, tick after tick, for 1.5 s. The fill checks
// again itself (0.5 s steady, within 2.5 s: 1.0.3) before it writes anything. 1.0.3: a page that has been showing a
// while has been ticking all along (with the keyboard or not), so it is long settled when Fill is clicked: no wait then.
// 1.0.4: while it can't update itself (another version than the helper's, so no job can come) a tick only says so.
let seen = { doc: null, sig: null, since: 0 }, loading = { doc: null, since: 0 };
async function tick(sender) {
  if (!sender.tab) return;
  await started;
  if (stuck()) { tell(stuckWords(), 'update'); return; }
  if (reloading) return;
  if (!(await inFront(sender))) { await besides(sender); return; }
  if (busy) return;
  busy = true;
  try {
    const target = { tabId: sender.tab.id, documentIds: [sender.documentId] };
    let look;
    try { const [res] = await chrome.scripting.executeScript({ target, world: 'MAIN', func: self.tempeBuffalo, args: ['look'] }); look = res && res.result; }
    catch (e) { trouble('Chrome wouldn’t run the page check (' + short(e) + ')', sender.documentId); return; }
    if (!look || typeof look !== 'object' || typeof look.ok !== 'boolean') { trouble('Chrome gave no answer from the page check', sender.documentId); return; }
    if (!look.ok) { trouble('the page check failed (' + String(look.error || 'no reason given').slice(0, 160) + ')', sender.documentId); return; }
    if (!look.quiet) {
      // Loading for more than 10 s (or its scripts never there) is told to the helper as well.
      const why = look.why || 'the Buffalo page is still loading';
      seen = { doc: null, sig: null, since: 0 }; if (loading.doc !== sender.documentId) loading = { doc: sender.documentId, since: Date.now() };
      note('Buffalo page: ' + why + '.'); if (Date.now() - loading.since > 10000) tell(why + ' (for more than 10 s)', sender.documentId);
      return;
    }
    loading = { doc: null, since: 0 };
    if (seen.doc !== sender.documentId || seen.sig !== look.sig) seen = { doc: sender.documentId, sig: look.sig, since: Date.now() };
    if (Date.now() - seen.since < 1500) { note('Buffalo page: checking it has finished loading …'); return; }
    if (look.why) { note('Buffalo page: ' + look.why + '.'); tell(look.why, sender.documentId); return; }
    if (!look.front || !(await inFront(sender))) return;
    let port;
    try { port = await helperPort(); }
    catch (e) { note('Buffalo page: blank and ready, but this extension can’t reach the helper (see above).'); return; }
    if (!port) return;
    let poll;
    try { poll = await call(port, '/buffalo/poll', { ext: VERSION, schema: SCHEMA, chrome: CHROME, tab: { settled: true, blank: true } }); }
    catch (e) { await forget(); note('Lost the helper (' + String(e.message || e).slice(0, 80) + ').'); return; }
    state.helper = poll.json.helper;
    if (await versions(poll.json)) return;
    const job = poll.json.job;
    if (!job) { note('Ready: click Fill Buffalo page in the helper.'); return; }
    if (job.schema !== SCHEMA || typeof job.id !== 'string') return;
    if (!(await inFront(sender))) return;
    const took = await call(port, '/buffalo/take', { ext: VERSION, id: job.id });
    if (!took.json.ok) return;
    note('Filling invoice ' + job.invoice + ' …');
    let result;
    if (!(await inFront(sender))) result = { id: job.id, outcome: 'refused', boxes: 0, rows: 0, left: [], why: 'the Buffalo tab was no longer the one showing in the Chrome window used last; nothing filled: click Fill again with it showing' };
    else {
      let gone = false;
      try {
        const [r] = await chrome.scripting.executeScript({ target, world: 'MAIN', func: self.tempeBuffalo, args: ['fill', job] });
        result = r && r.result;
      } catch (e) {
        gone = true;
        result = { id: job.id, outcome: 'failed', boxes: 0, rows: 0, left: [], why: 'the Buffalo page changed before it could be filled (' + short(e) + ')' };
      }
      if (!gone && (!result || result.id !== job.id)) result = await answer(target, job.id);
    }
    if (!result || result.id !== job.id) result = { id: job.id, outcome: 'failed', boxes: 0, rows: 0, left: [], why: 'the Buffalo page gave no answer (Chrome ' + CHROME + ')' };
    note('Invoice ' + job.invoice + ': ' + result.outcome + (result.why ? ' — ' + result.why : '') + '.');
    try { await call(port, '/buffalo/result', { ext: VERSION, id: job.id, outcome: result.outcome, boxes: result.boxes | 0, rows: result.rows | 0, left: (result.left || []).slice(0, 30), why: String(result.why || '') }); }
    catch (e) { note(state.line + ' (the helper didn’t get the answer)'); }
  } catch (e) {
    note('Stopped: ' + String(e.message || e).slice(0, 120));
  } finally {
    busy = false;
    if (afterFill) { afterFill = false; setTimeout(check, 0); }   // 1.0.4: the reload held back during this tick
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id || !msg) return;
  if (msg.t === 'status' && !sender.tab) {   // the popup
    (async () => {
      await restored; await started;
      let k = 'ok';
      try { await key(); } catch (e) { k = String(e.message || e); }
      if (k === 'ok') {
        // Whatever is remembered, the popup says only what a signed hello says now: a remembered port that doesn't
        // answer is forgotten and the ports searched once more (the helper may be back on another one). 1.0.4: its answer
        // is an update check too (as the alarm's), and while it can't update itself the hello says so.
        let a = null;
        const why = stuck() ? stuckWords() : undefined;
        try { a = await hello(why, true); } catch (e) { }
        if (a && LOST.test(state.line)) note(CONNECTED);
        if (!a && !LOST.test(state.line)) note('The Tempe helper (RDP) isn’t running or isn’t reachable.');
        if (a) { if (why) told.set('update', { text: why, at: Date.now() }); await versions(a); }
      }
      sendResponse({ version: VERSION, chrome: CHROME, key: k, port: state.port, helper: state.helper, line: state.line, at: state.at });
    })();
    return true;
  }
  if (msg.t === 'tick' && sender.tab && sender.frameId === 0 && typeof sender.url === 'string' && sender.url.indexOf(CREATE) === 0 && sender.documentId) tick(sender);
});

// After install or update: give already open Create pages the content script again (never reload a tab). 1.0.4: and the
// update check, with its alarm, at every start of the worker, of Chrome, and after an install or update.
chrome.runtime.onInstalled.addListener(async () => {
  alarm(); check();
  try {
    const tabs = await chrome.tabs.query({ url: CREATE + '*' });
    for (const t of tabs) chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['content.js'] }).catch(() => { });
  } catch (e) { }
});
chrome.runtime.onStartup.addListener(() => { alarm(); check(); });
alarm(); check();
