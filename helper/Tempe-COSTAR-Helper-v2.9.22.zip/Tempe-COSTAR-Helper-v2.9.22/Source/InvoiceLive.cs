// 2.9.15 "Invoice read (dry run)" (spec of 20 Nov 2026): the live side of reading the COSTAR Invoice that staff have
// already opened, so its details can be prepared for Buffalo delivery labels. READ + PREPARE ONLY: nothing is sold,
// saved, typed, booked, printed or sent; no COSTAR window is opened, closed, pressed, switched or answered.
//
// Everything this file does to COSTAR goes through IInvoiceScreen, whose members are reads (the Invoice windows, one
// window's state, the windows over it, a snapshot of its controls with every box's text, the selected tab, the line
// grid scroll bar's position) plus exactly ONE input: ScrollGrid, which scrolls the invoice's line grid by its own
// scroll bar when the invoice has more than 25 lines (and scrolls it back). InvoiceScreenRules.Check and the self-tests
// hold the interface to that list; Build.ps1 refuses any Invoice*.cs file that names a press, key, click, close,
// keyboard-focus or text-setting call (InvoiceSourceGuard.Patterns is the same list).
//
// How the grid is scrolled (chosen and documented here; NEVER SEEN ON A REAL COSTAR, needs live verification): the
// 3 Nov 14:47:35 map shows the grid's scroll bar as a WinForms SCROLLBAR control [1030,370,17,475], a child of the line
// grid panel [37,340,1010,692], disabled while every line fits. The reader sends WM_VSCROLL (0x0115) to that panel with
// lParam = the scroll bar's handle and SB_PAGEDOWN / SB_PAGEUP (SB_LINEUP / SB_LINEDOWN to land exactly), each followed
// by SB_ENDSCROLL, as a real scroll bar does; WinForms reflects the message to the scroll bar, which moves its Value.
// The position is read with GetScrollInfo(SB_CTL) (read only). No mouse wheel, no keys, no keyboard focus, no clicks,
// COSTAR isn't brought to the front. Pages are merged by COSTAR's own line-number labels (InvoiceReader.Merge).
//
// Locks: the whole read holds the EntryCoordinator gate (TryBeginRead: the same one-at-a-time gate TryBegin takes, so
// no other job can type into COSTAR meanwhile). Scrolling, the only input, also needs CostarInputLock and a quiet
// moment with nobody at the PC, watched (RoOpenWatch) before every scroll; Stop is honoured between scrolls. 2.9.21:
// no quiet moment is waited for when nothing was touched between the click on Read and the guard's Begin; from then on,
// anything touched stops the read before its next scroll, even before the first (a touch before Begin: the 3 s wait).
// Privacy: customer words are only shown in the helper's own window; the day log gets counts, states and codes.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    // A top-level window (an Invoice) as the screen sees it now.
    internal sealed class InvoiceWindow { internal IntPtr Handle;internal uint Pid;internal string Caption="";internal bool Enabled,Visible; }
    // The line grid scroll bar's position (GetScrollInfo, SB_CTL). Top: the furthest position it can reach.
    internal sealed class InvoiceScroll {
        internal bool Found,Enabled;internal int Min,Max,Page,Pos;
        internal int Top { get { int page=Math.Max(1,Page);return Math.Max(Min,Max-page+1); } }
    }

    // The ONLY way the invoice reader touches COSTAR. Reads, plus exactly one input (ScrollGrid).
    internal interface IInvoiceScreen {
        // Visible top-level windows of COSTAR processes whose caption is an Invoice's (InvoiceReader.IsInvoiceCaption).
        List<InvoiceWindow> InvoiceWindows();
        // That window now (null when it is gone).
        InvoiceWindow Window(IntPtr window);
        // The visible windows of its process owned by it (directly or through others): their captions.
        List<string> Over(IntPtr window);
        // Its visible controls with every box's text read (TextState "read"; password boxes never read).
        List<ControlInfo> Snapshot(IntPtr window);
        // The MSAA name of the selected page tab of its tab control (null when it can't be told).
        string SelectedTab(IntPtr window,List<ControlInfo> snapshot);
        // The line grid scroll bar's position (read only).
        InvoiceScroll ScrollInfo(IntPtr scrollBar);
        // The control that has the keyboard on the invoice window's GUI thread (GetGUIThreadInfo, read only): its handle,
        // 0 when none, -1 when it can't be told.
        long KeyboardFocus(IntPtr window);
        // THE one input: scroll the line grid by its scroll bar (code: InvoiceScreenRules.LineUp/LineDown/PageUp/PageDown).
        bool ScrollGrid(IntPtr grid,IntPtr scrollBar,int code);
    }

    internal static class InvoiceScreenRules {
        internal static readonly string[] Reads={"InvoiceWindows","Window","Over","Snapshot","SelectedTab","ScrollInfo","KeyboardFocus"};
        internal static readonly string[] Inputs={"ScrollGrid"};
        internal const int LineUp=0,LineDown=1,PageUp=2,PageDown=3;
        internal static bool Allowed(int code) { return code>=LineUp&&code<=PageDown; }
        // null when the interface's methods are exactly the allowed reads plus the one input (no properties, no events).
        internal static string Check(Type screen) {
            var flags=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static|BindingFlags.DeclaredOnly;
            var names=screen.GetMethods(flags).Select(m=>m.Name).OrderBy(n=>n,StringComparer.Ordinal).ToList();
            var allowed=Reads.Concat(Inputs).OrderBy(n=>n,StringComparer.Ordinal).ToList();
            if(screen.GetProperties(flags).Length>0||screen.GetEvents(flags).Length>0) return "it has properties or events";
            if(names.Count!=names.Distinct().Count()) return "a method is overloaded";
            var extra=names.Except(allowed).ToList();var missing=allowed.Except(names).ToList();
            if(extra.Count>0) return "it has more than the allowed methods: "+String.Join(", ",extra.ToArray());
            if(missing.Count>0) return "it lacks "+String.Join(", ",missing.ToArray());
            return null;
        }
    }

    // The build's source guard (Build.ps1 holds the same list): no Invoice*.cs file may name a press, key, click,
    // close, keyboard focus, text-setting or selling call. Each pattern is written so it doesn't match its own text.
    internal static class InvoiceSourceGuard {
        internal static readonly string[] Patterns={
            @"\bDirec[t]\s*\.",@"BM_CLIC[K]",@"(?i)\b0x0*F[5]\b",@"KeyNo[w]",
            @"\bNative\s*\.\s*(?:Ke[y]|Clic[k]|DoubleClic[k]|RightClic[k]|Whee[l]|Chor[d]|BringToFron[t]|SetForegroundWindo[w]|ShowWindo[w]|WriteMessag[e])",
            @"DoubleClic[k]",@"SendInpu[t]",@"keybd_even[t]",@"mouse_even[t]",@"WM_CLOS[E]",@"CloseWindo[w]",@"(?i)\b0x0*1[0]\b",
            @"WM_SETTEX[T]",@"(?i)\b0x0*[C]\b",@"SetFocu[s]",@"accDoDefaultActio[n]",@"(?i)\bsel[l]\w*\s*\(",@"\bSetTex[t]\s*\(",
            @"SetWindowTex[t]",@"PostMessag[e]",@"SendKey[s]",@"(?i)MOUSEWHEE[L]",@"(?i)\bWM_(?:KEY|SYSKEY|CHAR|[LRM]BUTTON|COMMAN[D])",
            @"ShowTa[b]",@"PressLate[r]",@"\bRoWi[p]\s*\.\s*(?:Ope[n]|Fron[t]|PressSearc[h]|ClearFilte[r])",
            // The project's own MSAA press / tab-switch / focus wrappers (the MSAA default action, child selection).
            @"\bDoDefaul[t]",@"SelectChil[d]",@"accSelec[t]",
            // No using-alias (it would hide a class name from the list below).
            @"\busin[g]\s+\w+\s*=",
            // An allow-list on the classes that can press COSTAR: only these read members may be named.
            @"\bNativ[e]\s*\.\s*(?!(?:Caption|Class|EnumChildWindows|EnumWindows|Focus|GetGUIThreadInfo|GetParent|GetWindowThreadProcessId|GuiInfo|GetWindow|GetWindowLong|GetWindowRect|IsWindow|IsWindowEnabled|IsWindowVisible|LastInputTick|NotePointer|Pid|Rect|SendNull|TryText|UserActiveWithin)\b)\w",
            @"\bRunne[r]\s*\.\s*(?!Decoration\b)\w",@"\bCostarWindow[s]\s*\.\s*(?!IsCostar\b)\w",@"\bWholesaleOrderReade[r]\s*\.\s*(?!(?:Beside|Snapshot|Tab)\b)\w",
            @"\b(?:Msa[a]|Wi[n]|RoWi[p]|RoEngin[e]|WipScree[n]|WipScrol[l]|WipSearc[h]|CostarWipScree[n]|Costa[r]|WholesaleRu[n]|GridReade[r]|Unattende[d])\s*\.\s*\w",
            @"\btypeo[f]\s*\(\s*(?:Native|Msaa|Direct|Runner|RoWip|RoEngine|Win|Costar|CostarWindows|WholesaleOrderReader)\s*\)",
            @"\bGetMetho[d]\s*\(|\bInvokeMembe[r]\b|CreateDelegat[e]|GetDelegateForFunctionPointe[r]",
            // The one input is structural: the only P/Invokes are GetScrollInfo and the scroll message (SendMessageTimeoutW),
            // which is only ever called with WmVScroll, itself 0x0115; the WM_NULL ping only with message 0.
            @"\bexter[n]\s+[\w.]+\s+(?!(?:ScrollMessag[e]|GetScrollInf[o])\s*\()\w+\s*\(",@"EntryPoin[t]\s*=\s*\x22(?!SendMessageTimeoutW\x22)",
            @"\bScrollMessag[e]\s*\((?!\s*IntPtr\s+h\s*,\s*uint\s+msg\s*,)(?!\s*grid\s*,\s*WmVScrol[l]\s*,)",@"\bWmVScrol[l]\s*=\s*(?!0x0115\b)",
            @"\bSendNul[l]\s*\(\s*[^,()]+,\s*(?!0\s*,)"
        };
        // The patterns found in a file's text (none: clean).
        internal static List<string> Hits(string text) {
            var hits=new List<string>();
            foreach(var p in Patterns) if(Regex.IsMatch(text??"",p)) hits.Add(p);
            return hits;
        }
    }

    // The pure parts the reading uses (InvoiceModel's, unless a test gives its own).
    internal delegate InvoicePage InvoicePageReader(List<ControlInfo> s,Func<ControlInfo,string> text,out string why);
    internal delegate bool InvoicePageMerger(List<InvoicePage> pages,out List<InvoiceLine> merged,out string why);
    internal sealed class InvoiceParts {
        internal InvoicePageReader Page;internal InvoicePageMerger Merge;
        internal Func<List<ControlInfo>,Func<ControlInfo,string>,string,List<InvoicePage>,string,InvoiceRead> Parse;
        // Outside (2.9.19): the fingerprint of everything but the line panels (null when the line grid isn't found).
        internal Func<List<ControlInfo>,Func<ControlInfo,string>,string> Fingerprint,Outside;
        internal Func<InvoiceRead,string> Review,Buffalo,Status,LogLine;
        internal Action<int> Pause;
        internal static InvoiceParts Live() {
            return new InvoiceParts {Page=InvoiceReader.Page,Merge=InvoiceReader.Merge,Parse=InvoiceReader.Parse,Fingerprint=InvoiceReader.Fingerprint,Outside=InvoiceReader.FingerprintOutsideLines,
                Review=InvoicePreview.Review,Buffalo=InvoicePreview.Buffalo,Status=InvoicePreview.Status,LogLine=InvoicePreview.LogLine,Pause=Thread.Sleep};
        }
    }

    // What protects the one input (scrolling): Begin before the first scroll (throws why it can't), Problem before each
    // scroll (null: go on), End once scrolling is over (on the thread that began it). Skipped (2.9.21): the last Begin
    // didn't wait for the 3 s quiet moment (nothing was touched since the click on Read).
    internal interface IInvoiceInputGuard {
        void Begin(Func<bool> cancelled);
        string Problem();
        void End();
        bool Skipped { get; }
    }
    // The project's protections for COSTAR input: a quiet moment (3 s with nobody at the PC, within 30 s), the
    // CostarInputLock, then nobody may use the PC (RoOpenWatch, as the wholesale dry run). watchPerson false: the lock
    // only (a harness driving a made-up window).
    // 2.9.21 (Tommy, 27 Nov: "publish after the skip 3s"): clicked is Windows' last input tick taken when Read was clicked
    // (WorkerForm.StartInvoiceRead, on the window's thread, so that input is the click). When it is still the last input
    // as Begin starts, nothing was touched since the click: Begin doesn't wait, and from then on any input at all (the
    // last input tick no longer the click's, or not readable) stops the read before the next scroll; the click itself
    // never does. Otherwise (no click tick, not readable, anything since the click, a mouse move too) the 3 s rule and
    // the watch are exactly as before.
    internal sealed class InvoiceInputGuard : IInvoiceInputGuard {
        readonly bool watchPerson;readonly int? clicked;IDisposable input;RoOpenWatch watch;bool skipped;
        // Windows' by default; the self-tests give their own (no real input, no real input lock).
        internal Func<int?> Tick=Native.LastInputTick;
        internal Func<int,bool> ActiveWithin=Native.UserActiveWithin;
        internal Func<IDisposable> Lock=delegate { return new CostarInputLock(); };
        internal Action<int> Pause=Thread.Sleep;
        internal InvoiceInputGuard(bool watchPerson) : this(watchPerson,null) { }
        internal InvoiceInputGuard(bool watchPerson,int? clicked) { this.watchPerson=watchPerson;this.clicked=clicked; }
        internal bool WatchesPerson { get { return watchPerson; } }
        internal int? Clicked { get { return clicked; } }
        public bool Skipped { get { return skipped; } }
        public void Begin(Func<bool> cancelled) {
            skipped=false;
            if(watchPerson) {
                int? now=clicked.HasValue?Tick():null;
                if(now.HasValue&&now.Value==clicked.Value) skipped=true;
                else {
                    var waiting=Stopwatch.StartNew();
                    while(ActiveWithin(3000)) {
                        if(cancelled!=null&&cancelled()) throw new InvalidOperationException("Stop was pressed");
                        if(waiting.ElapsedMilliseconds>=30000) throw new InvalidOperationException("someone kept using the PC, so the line list wasn't scrolled");
                        Pause(200);
                    }
                }
            }
            input=Lock();
            watch=new RoOpenWatch();Native.NotePointer();
        }
        public string Problem() {
            if(!watchPerson||watch==null) return null;
            if(watch.UserActive||Used()) {
                watch.UserActive=true;
                return "someone used the PC while the line list was being scrolled";
            }
            return null;
        }
        // Skipped: any input since the click (the click's own doesn't count). Waited: any within the watch and the 1 s before it.
        bool Used() {
            if(skipped) { int? now=Tick();return !now.HasValue||now.Value!=clicked.Value; }
            return ActiveWithin((int)Math.Min(600000,watch.Clock.ElapsedMilliseconds+1000));
        }
        public void End() { var held=input;input=null;if(held!=null) held.Dispose(); }
    }

    // The result of one press of Read: a read (complete or not) or a refusal, with the texts the tab shows.
    internal sealed class InvoiceOutcome {
        internal InvoiceRead Read;internal string Refused,RefusedLog;
        internal int Pages=1,Scrolls;internal string Warn;
        // 2.9.21: how long the read waited for nobody to use the PC before its first scroll, and how long the read took
        // up to that point (-1: it didn't get there), for the day log (27 Nov: a 6.5 s read whose split wasn't logged).
        internal long QuietWaitMs=-1,BeforeWaitMs=-1;
        // 2.9.21: the guard didn't wait for the 3 s quiet moment (nothing was touched since the click on Read): quiet=skipped
        // in the day log, else quiet=waited (only when the read got to the wait).
        internal bool QuietSkipped;
        internal readonly Stopwatch Clock=Stopwatch.StartNew();
        // 2.9.19: where the line list was left when it couldn't be scrolled back (-1: it was, or it wasn't scrolled).
        internal int LeftPos=-1;
        // 2.9.19: the list was left there only because COSTAR's keyboard was in its lines (the one case the end check may accept).
        internal bool LeftForKeyboard;
        // Details shown in the window only (they may name a COSTAR window): added to the read's Problems, never logged.
        internal readonly List<string> Shown=new List<string>();
        internal readonly List<string> LogWhy=new List<string>();
        internal string Status="",Review="",Buffalo="";
        internal bool Complete { get { return Read!=null&&Read.Complete; } }
    }

    // Reading one Invoice window (no discovery): the e2e harness drives this with a made-up window by handle.
    internal static class InvoiceReading {
        internal const int MaxPages=80,MaxBackSteps=400;
        internal const string Stopped="Stopped: nothing was prepared. Nothing changed in COSTAR.";
        // 2.9.21: said just before the guard begins (both of its cases: InvoiceInputGuard).
        internal const string StillLine="Keep the mouse and keyboard still for a moment: the helper scrolls COSTAR's line list to read every line (read only), at once if nothing was touched since the click on Read, else once nobody has used the PC for 3 s ...";
        internal static string TextOf(ControlInfo c) { return c!=null&&c.TextState=="read"?c.Text:null; }
        static string Norm(string s) { return Regex.Replace((s??"").Trim(),@"\s+"," ").ToUpperInvariant(); }

        internal static InvoiceOutcome ReadWindow(IInvoiceScreen screen,IntPtr window,string expected,Func<bool> cancelled) {
            return ReadWindow(screen,window,expected,cancelled,new InvoiceInputGuard(true),InvoiceParts.Live(),null);
        }
        internal static InvoiceOutcome ReadWindow(IInvoiceScreen screen,IntPtr window,string expected,Func<bool> cancelled,IInvoiceInputGuard guard,InvoiceParts parts,Action<string> say) {
            if(cancelled==null) cancelled=delegate { return false; };
            if(parts==null) parts=InvoiceParts.Live();
            if(guard==null) guard=new InvoiceInputGuard(true);
            var o=new InvoiceOutcome();
            string want=(expected??"").Trim();
            var w=screen.Window(window);
            if(w==null||!w.Visible) return Refuse(o,"The invoice window closed in COSTAR: nothing was read. Open the invoice in COSTAR, then press Read.","window_gone",parts);
            int branch;string branchName;
            if(!InvoiceReader.IsInvoiceCaption(w.Caption,out branch,out branchName)) return Refuse(o,"That COSTAR window isn't an Invoice: nothing was read.","not_invoice",parts);
            string over=Blocker(screen,w);
            if(over!=null) return Refuse(o,"Something is open over the invoice in COSTAR ("+over+"): close it, then press Read.","window_over",parts);
            if(cancelled()) return Refuse(o,Stopped,"stopped",parts);
            Tell(say,"Reading the invoice (read only) ...");
            List<ControlInfo> s;
            try { s=screen.Snapshot(window); } catch(InvalidOperationException e) { return Refuse(o,e.Message+" Nothing was read.","no_answer",parts); }
            Func<ControlInfo,string> text=TextOf;
            string tab=screen.SelectedTab(window,s);
            string start=parts.Fingerprint(s,text);
            string why;var first=parts.Page(s,text,out why);
            string pagingWhy=null;
            if(first==null) {
                first=new InvoicePage {Lines=new List<InvoiceLine>()};
                pagingWhy="the lines could not be read: "+(String.IsNullOrEmpty(why)?"the line grid wasn't recognised":why);
                o.LogWhy.Add("grid_not_recognised");
            }
            if(first.Lines==null) first.Lines=new List<InvoiceLine>();
            var pages=new List<InvoicePage>{first};
            // The number first: an invoice other than the one expected is refused before anything is scrolled.
            var early=parts.Parse(s,text,tab,new List<InvoicePage>{first},pagingWhy);
            string number=early==null||early.Number==null?"":early.Number.Trim();
            if(want.Length>0&&number!=want)
                return Refuse(o,number.Length==0?"The open invoice's number could not be read, so it can't be checked against "+want+": nothing was prepared.":"The open invoice is "+number+", not "+want+": nothing was prepared.","not_expected",parts);
            if(pagingWhy==null) pagingWhy=PageThrough(screen,window,s,first,pages,guard,parts,cancelled,o,say);
            o.Pages=pages.Count;
            // The consistency guard: everything read again at the end must read the same.
            bool changed=false;string overNow=null;
            try {
                var now=screen.Window(window);
                overNow=now==null?"the invoice closed":Blocker(screen,now);
                if(overNow==null) {
                    var end=screen.Snapshot(window);string endTab=screen.SelectedTab(window,end);
                    changed=parts.Fingerprint(end,text)!=start||endTab!=tab;
                    // 2.9.19: a line list COSTAR kept from being scrolled back shows other lines than at the start.
                    if(changed&&o.LeftForKeyboard&&o.LeftPos>=0&&endTab==tab&&LeftAsRead(parts,s,end,pages,o.LeftPos)) { changed=false;o.LogWhy.Add("left_as_read"); }
                }
            } catch(InvalidOperationException e) { overNow=e.Message; }
            var r=parts.Parse(s,text,tab,pages,pagingWhy);
            if(r==null) r=new InvoiceRead {Complete=false};
            if(r.Problems==null) r.Problems=new List<string>();
            InvoiceReader.SetCaption(r,w.Caption);
            // The run's own reasons go to MarkIncomplete (they may be logged: no window titles in them); the detail,
            // which can name a COSTAR window, stays in Problems (shown only).
            if(overNow!=null) { InvoiceReader.MarkIncomplete(r,EndNotRead);r.ReadAgain=EndNotRead;r.Problems.Add("the invoice could not be read again at the end ("+overNow+")");o.LogWhy.Add("end_not_read"); }
            // 2.9.19: a list left at another place for another reason than COSTAR's keyboard can't be checked at the end: said as that.
            else if(changed&&o.LeftPos>=0&&!o.LeftForKeyboard) { InvoiceReader.MarkIncomplete(r,LeftNotChecked);r.ReadAgain=LeftNotChecked;o.LogWhy.Add("left_unchecked"); }
            else if(changed) { InvoiceReader.MarkIncomplete(r,ChangedWhileRead);r.ReadAgain=ChangedWhileRead;o.LogWhy.Add("changed"); }
            if(o.Warn!=null) r.Problems.Add(o.Warn);
            foreach(var shown in o.Shown) if(!r.Problems.Contains(shown)) r.Problems.Add(shown);
            if(pagingWhy!=null) r.Complete=false;
            string read=r.Number==null?"":r.Number.Trim();
            if(want.Length>0&&read!=want) return Refuse(o,"The open invoice is "+(read.Length>0?read:"(number not read)")+", not "+want+": nothing was prepared.","not_expected",parts);
            o.Read=r;
            Finish(o,parts);
            // 2.9.19: the line list left elsewhere is said on the status line too, not only in the review.
            if(o.Warn!=null&&!String.IsNullOrEmpty(o.Status)) o.Status=o.Status+" Note: "+o.Warn+".";
            return o;
        }
        // 2.9.19 (26 Nov, three reads of a longer invoice: every line was read, then COSTAR had its keyboard in the line
        // list, so the list wasn't scrolled back, and the read ended "changed while it was read"): a list left at another
        // place reads differently at the end only because it shows other lines. It is the same invoice as read when
        // everything outside the line panels reads as it did at the start, and the lines it shows now read exactly as the
        // screen read at that same place while paging.
        static bool LeftAsRead(InvoiceParts parts,List<ControlInfo> s,List<ControlInfo> end,List<InvoicePage> pages,int pos) {
            if(parts.Outside==null||pages==null) return false;
            var at=pages.LastOrDefault(p=>p!=null&&p.Lines!=null&&p.ScrollPos==pos);
            if(at==null) return false;
            string a=parts.Outside(s,TextOf),b=parts.Outside(end,TextOf);
            if(a==null||b==null||a!=b) return false;
            string why;var now=parts.Page(end,TextOf,out why);
            return now!=null&&now.Lines!=null&&PageKey(now)==PageKey(at);
        }
        static void Tell(Action<string> say,string words) { if(say!=null) try { say(words); } catch(Exception) { } }
        // Why nothing may be read (or scrolled) now: a window over the invoice, or the invoice disabled. null: none.
        internal static string Blocker(IInvoiceScreen screen,InvoiceWindow w) {
            if(w==null) return "the invoice closed";
            var over=screen.Over(w.Handle);
            if(over!=null&&over.Count>0) { string t=(over[0]??"").Trim();return t.Length>0?t:"a COSTAR window"; }
            if(!w.Enabled) return "COSTAR is asking something on it";
            return null;
        }
        internal static InvoiceOutcome Refuse(InvoiceOutcome o,string message,string code,InvoiceParts parts) {
            o.Read=null;o.Refused=message;o.RefusedLog=code;
            return Finish(o,parts);
        }
        internal static InvoiceOutcome Finish(InvoiceOutcome o,InvoiceParts parts) {
            if(o.Read==null) {
                o.Status=o.Refused??"";
                o.Review=Crlf((o.Refused??"")+"\n\nNothing was read or prepared. Not sold, not booked, nothing changed in COSTAR.");
                o.Buffalo="";
                return o;
            }
            o.Status=parts.Status(o.Read)??"";o.Review=Crlf(parts.Review(o.Read));o.Buffalo=Crlf(parts.Buffalo(o.Read));
            return o;
        }
        internal static string Crlf(string s) { return (s??"").Replace("\r\n","\n").Replace("\r","\n").Replace("\n","\r\n"); }

        // The line grid's scroll bar: a SCROLLBAR over 200 px tall in the panel that holds the "Item" heading, below it.
        internal static ControlInfo GridScrollBar(List<ControlInfo> s,out string why) {
            var items=s.Where(c=>c.Static&&c.RelativeBounds!=null&&Norm(c.Peek)=="ITEM").ToList();
            var bars=s.Where(c=>c.Visible&&c.Class!=null&&c.Class.IndexOf("SCROLLBAR",StringComparison.OrdinalIgnoreCase)>=0&&c.RelativeBounds!=null&&c.H>200&&c.W<=40).ToList();
            var mine=bars.Where(b=>items.Any(i=>i.Parent==b.Parent&&b.Y>i.Y)).ToList();
            if(mine.Count==1) { why=null;return mine[0]; }
            why=mine.Count>1?mine.Count+" scroll bars sit in the line grid":bars.Count==0?"the line grid's scroll bar wasn't found":"no scroll bar sits in the line grid";
            return null;
        }
        internal static string LineKey(InvoiceLine l) {
            if(l==null) return "";
            var parts=new[]{l.Number.ToString(System.Globalization.CultureInfo.InvariantCulture),l.ItemRaw,l.Item,l.Description,l.Size,l.Qty,l.List,l.Disc,l.Net,l.Tax,l.LineTotal,l.Note,l.Kind,
                l.Hidden==null?"":String.Join("\u001e",l.Hidden.ToArray())};
            return String.Join("\u001f",parts.Select(p=>p??"\u0000").ToArray());
        }
        internal static string PageKey(InvoicePage p) { return p==null||p.Lines==null?"":String.Join("\n",p.Lines.Select(LineKey).ToArray()); }
        static string Numbers(InvoicePage p) { return p==null||p.Lines==null?"":String.Join(",",p.Lines.Select(l=>l.Number.ToString(System.Globalization.CultureInfo.InvariantCulture)).ToArray()); }

        // Pages through the lines when there are more than fit (25), merges them by line number, and scrolls back.
        // null: every line is in pages; else why not (the read is then INCOMPLETE for it).
        static string PageThrough(IInvoiceScreen screen,IntPtr window,List<ControlInfo> s,InvoicePage first,List<InvoicePage> pages,IInvoiceInputGuard guard,InvoiceParts parts,Func<bool> cancelled,InvoiceOutcome o,Action<string> say) {
            string barWhy;var bar=GridScrollBar(s,out barWhy);
            if(bar==null) {
                if(first.Lines.Any(l=>l.Number>=25)) { o.LogWhy.Add("no_scroll_bar");return "lines 26+ could not be read: "+barWhy; }
                return null;
            }
            var barHandle=new IntPtr(bar.Handle);var grid=new IntPtr(bar.Parent);
            var info=screen.ScrollInfo(barHandle)??new InvoiceScroll();
            first.ScrollEnabled=bar.Enabled&&info.Found&&info.Enabled;first.ScrollPos=info.Pos;first.ScrollMax=info.Top;
            // More lines than show: a line number over 25 shows (every number label seen, filled or empty), or the 25th
            // line is filled (the list may go on); else the scroll bar's range says so.
            var seenNumbers=(first.Numbers??new List<int>()).Concat(first.Lines.Select(l=>l.Number)).ToList();
            bool beyond=seenNumbers.Any(n=>n>25);
            bool full=first.Lines.Any(l=>l.Number==25);
            bool disabled=!bar.Enabled||(info.Found&&!info.Enabled);
            string lead=info.Found&&info.Pos>info.Min?"some lines could not be read: ":"lines 26+ could not be read: ";
            // A disabled bar means everything fits (as in the 3 Nov map) unless the screen itself suggests more lines: the
            // range a disabled bar keeps was never seen (it may be left over), so it alone doesn't overrule the disabled state.
            if(disabled&&!beyond&&!full) return null;
            if(!info.Found) {
                if(!bar.Enabled&&!beyond) return null;
                o.LogWhy.Add("scroll_unread");return lead+"the line grid's scroll bar position couldn't be read";
            }
            if(info.Top<=info.Min&&!beyond) return null;
            if(disabled) { o.LogWhy.Add("scroll_disabled");return lead+"the line grid's scroll bar is disabled although the invoice seems to have more lines"; }
            if(info.Top<=info.Min) { o.LogWhy.Add("scroll_range");return lead+"the line grid's scroll bar has nowhere to go although line numbers over 25 show"; }
            // A box in the line list that has COSTAR's keyboard may hold typing not yet saved: never scroll under it.
            string focus=FocusProblem(screen,window,s,bar.Parent,delegate { return screen.Snapshot(window); });
            if(focus!=null) { o.LogWhy.Add(focus==FocusInLines?"focus_in_lines":"focus_unknown");return lead+focus; }
            int origin=info.Pos,pos=info.Pos;
            // 2.9.21: the wait for nobody using the PC is said while it lasts (27 Nov: a 6.5 s read said only "Reading"),
            // and its time goes to the day log, with whether it was skipped (nothing touched since the click on Read).
            Tell(say,StillLine);
            o.BeforeWaitMs=o.Clock.ElapsedMilliseconds;
            try { guard.Begin(cancelled); }
            catch(Exception e) { o.QuietWaitMs=o.Clock.ElapsedMilliseconds-o.BeforeWaitMs;o.QuietSkipped=guard.Skipped;o.LogWhy.Add("not_scrolled");return lead+e.Message; }
            o.QuietWaitMs=o.Clock.ElapsedMilliseconds-o.BeforeWaitMs;o.QuietSkipped=guard.Skipped;
            string why=null;bool stopInput=false;
            var pager=new Pager {Screen=screen,Window=window,Grid=grid,Bar=barHandle,Guard=guard,Parts=parts,Cancelled=cancelled,Outcome=o,Snap=s};
            try {
                // 2.9.19: what was read before the guard watched (the first screen of lines, the header) must read the same
                // now that it watches: from here, anyone using the PC stops the read, so a list COSTAR keeps from being
                // scrolled back can be checked at the end against what was read (LeftAsRead) without missing a change.
                List<ControlInfo> watched=null;
                try { watched=screen.Snapshot(window); } catch(InvalidOperationException e) { why=e.Message;o.LogWhy.Add("not_read_before_scroll"); }
                if(why==null) {
                    if(parts.Fingerprint(watched,TextOf)!=parts.Fingerprint(s,TextOf)) { why=ChangedBeforeScroll;o.LogWhy.Add("changed"); }
                    else pager.Snap=watched;
                }
                if(why==null) Tell(say,"Scrolling COSTAR's line list to read every line (nothing else is touched) ...");
                // Staff left it scrolled down: to the top first.
                if(pos>info.Min) {
                    for(int i=0;i<MaxBackSteps&&pos>info.Min&&why==null;i++) {
                        bool moved;why=pager.Step(InvoiceScreenRules.PageUp,ref pos,out moved);
                        if(why==null&&!moved) { why="the scroll position did not move";o.LogWhy.Add("position_stuck"); }
                    }
                    if(why==null&&pos>info.Min) { why="the line list didn't reach its top";o.LogWhy.Add("no_top"); }
                    if(why==null) {
                        InvoicePage top;why=pager.Settled(pos,info,out top);
                        // The merge needs the screens in scroll order from the top: the screen staff left showing is
                        // read again on the way down (and checked once more after scrolling back), so it is dropped here.
                        if(why==null) { pages.Clear();pages.Add(top); }
                    }
                }
                // Then down a page at a time until the position stops at its end.
                var previous=pages[pages.Count-1];int prevPos=pos;
                for(int n=0;why==null&&pos<info.Top;n++) {
                    if(n>=MaxPages) { why="the invoice has more than "+MaxPages+" pages of lines";o.LogWhy.Add("too_many_pages");break; }
                    bool moved;why=pager.Step(InvoiceScreenRules.PageDown,ref pos,out moved);
                    if(why!=null) break;
                    if(!moved||pos<=prevPos) { why="the scroll position did not move";o.LogWhy.Add("position_stuck");break; }
                    InvoicePage page;why=pager.Settled(pos,info,out page);
                    if(why!=null) break;
                    string before=Numbers(previous),after=Numbers(page);
                    if(after.Length>0&&after==before) {
                        why=PageKey(page)==PageKey(previous)?"the lines did not change after a scroll":"the line numbers did not change after a scroll (the lines did)";
                        o.LogWhy.Add("numbers_same");break;
                    }
                    pages.Add(page);previous=page;prevPos=pos;
                    // The furthest place, as COSTAR's scroll bar reports it now.
                    var nowInfo=screen.ScrollInfo(barHandle);if(nowInfo!=null&&nowInfo.Found) info=nowInfo;
                }
                if(why==null) {
                    List<InvoiceLine> merged;string mergeWhy;
                    if(!parts.Merge(pages,out merged,out mergeWhy)) { why=String.IsNullOrEmpty(mergeWhy)?"the pages of lines did not fit together":mergeWhy;o.LogWhy.Add("merge"); }
                }
                stopInput=pager.StopInput;
            } catch(InvalidOperationException e) { why=e.Message;o.LogWhy.Add("scroll_failed");stopInput=true; }
            finally {
                try {
                    stopInput=stopInput||pager.StopInput;
                    if(pos!=origin&&!stopInput) Back(pager,ref pos,origin,info,first,o);
                    else if(pos!=origin) { o.Warn="the line list in COSTAR was left scrolled to another place ("+(pager.StopWhy??"stopped")+"): scroll it back in COSTAR if needed";o.LogWhy.Add("not_scrolled_back"); }
                } catch(InvalidOperationException e) { o.Warn="the lines did not come back to where they were ("+e.Message+")";o.LogWhy.Add("not_back"); }
                finally { guard.End(); }
            }
            if(pos!=origin) o.LeftPos=pos;
            return why==null?null:lead+why;
        }
        // Back to where the line list was, then the first page must read as it did at the start.
        static void Back(Pager pager,ref int pos,int origin,InvoiceScroll info,InvoicePage first,InvoiceOutcome o) {
            int page=Math.Max(1,info.Page);string why=null;
            for(int i=0;i<MaxBackSteps&&pos!=origin&&why==null;i++) {
                int code=pos>origin?(pos-origin>=page?InvoiceScreenRules.PageUp:InvoiceScreenRules.LineUp):(origin-pos>=page?InvoiceScreenRules.PageDown:InvoiceScreenRules.LineDown);
                bool moved;why=pager.Step(code,ref pos,out moved);
                if(why==null&&!moved) why="the scroll position did not move";
            }
            if(why==null&&pos!=origin) why="it didn't get back in "+MaxBackSteps+" steps";
            // 2.9.19: COSTAR's keyboard went into the line list while its lines were scrolled: what to do about it, plainly.
            if(why!=null&&pager.StopWhy==KeyboardInLines) { o.Warn=LeftForKeyboard;o.LeftForKeyboard=true;o.LogWhy.Add("not_back");return; }
            if(why!=null) { o.Warn="the lines did not come back to where they were ("+why+")";o.LogWhy.Add("not_back");return; }
            InvoicePage again;why=pager.Settled(pos,info,out again);
            if(why!=null||PageKey(again)!=PageKey(first)) { o.Warn="the lines did not come back to where they were";o.LogWhy.Add("not_back"); }
        }
        // The two reasons a read's parts may come from two invoices (2.9.17: also kept as InvoiceRead.ReadAgain).
        internal const string EndNotRead="the invoice could not be read again at the end: press Read again",ChangedWhileRead="the invoice changed while it was read: press Read again";
        internal const string KeyboardInLines="COSTAR's keyboard is in the line list",KeyboardUnknown="where COSTAR's keyboard is couldn't be told";
        internal const string CouldntTell="where COSTAR's keyboard is couldn't be told, so the line list wasn't scrolled";
        internal const string CouldntTellAfterScroll="where COSTAR's keyboard is couldn't be told, so the line list wasn't scrolled any further";
        internal const string LeftNotChecked="the line list was left at another place, so the invoice couldn't be checked again at the end: press Read again";
        internal const string ChangedBeforeScroll="the invoice changed before its lines were scrolled: press Read again";
        internal const string LeftForKeyboard="COSTAR put its keyboard in the line list while the helper scrolled it, so the helper left the list where it was: in COSTAR, scroll the line list back to the top, and click where you mean to type before you type";
        // 2.9.19: said as the line list (a line, its headings or a button in it such as &TaxIn): anything under the line grid stops the scroll.
        internal const string FocusInLines="COSTAR's keyboard is in the line list (a line, its headings or a button there such as TaxIn) – click outside the line list in COSTAR, then press Read again";
        // Why the line list must not be scrolled now because of where COSTAR's keyboard is (null: fine). The grid is the
        // line grid panel (the scroll bar's parent): a focused control inside it may hold typing COSTAR hasn't taken yet,
        // which a scroll (COSTAR reuses its line boxes) could commit to a line or move to another. A box elsewhere on the
        // invoice isn't under the scroll. A focus that can't be told: not scrolled either.
        internal static string FocusProblem(IInvoiceScreen screen,IntPtr window,List<ControlInfo> s,long grid) { return FocusProblem(screen,window,s,grid,null); }
        // fresh (2.9.19): a new snapshot (a read), taken when the keyboard is on a control the given snapshot doesn't hold
        // (COSTAR may make a control after it was taken, as it seems to for a line's details); the walk is then made on it.
        // It can't be taken: not scrolled.
        internal static string FocusProblem(IInvoiceScreen screen,IntPtr window,List<ControlInfo> s,long grid,Func<List<ControlInfo>> fresh) {
            long f=screen.KeyboardFocus(window);
            if(f==0) return null;
            if(f<0) return CouldntTell;
            if(f==grid) return FocusInLines;
            var byHandle=new Dictionary<long,ControlInfo>();
            foreach(var c in s??new List<ControlInfo>()) byHandle[c.Handle]=c;
            if(fresh!=null&&f!=window.ToInt64()&&!byHandle.ContainsKey(f)) {
                List<ControlInfo> again;
                try { again=fresh(); } catch(InvalidOperationException) { return CouldntTell; }
                byHandle=new Dictionary<long,ControlInfo>();
                foreach(var c in again??new List<ControlInfo>()) byHandle[c.Handle]=c;
            }
            ControlInfo at;long h=f;
            for(int i=0;i<16&&byHandle.TryGetValue(h,out at);i++) { if(at.Parent==grid) return FocusInLines;h=at.Parent; }
            return null;
        }
        // One scroll and its reading, with the checks before each scroll.
        sealed class Pager {
            internal IInvoiceScreen Screen;internal IntPtr Window,Grid,Bar;internal IInvoiceInputGuard Guard;internal InvoiceParts Parts;internal Func<bool> Cancelled;internal InvoiceOutcome Outcome;
            internal bool StopInput;internal string StopWhy;internal List<ControlInfo> Snap;
            internal string Step(int code,ref int pos,out bool moved) {
                moved=false;
                if(Cancelled()) { StopInput=true;StopWhy="Stop was pressed";Outcome.LogWhy.Add("stopped");return "Stop was pressed"; }
                string person=Guard.Problem();
                if(person!=null) { StopInput=true;StopWhy=person;Outcome.LogWhy.Add("person");return person; }
                // The reason is fixed words (it can reach the day log); the window's title is shown in the window only.
                string over=Blocker(Screen,Screen.Window(Window));
                if(over!=null) { StopInput=true;StopWhy="something is open over the invoice";Outcome.LogWhy.Add("over");Outcome.Shown.Add("something was open over the invoice in COSTAR while its lines were scrolled ("+over+")");return "something is open over the invoice in COSTAR"; }
                string focus=FocusProblem(Screen,Window,Snap,Grid.ToInt64(),delegate { var again=Screen.Snapshot(Window);Snap=again;return again; });
                // 2.9.19: in the lines, or where it is couldn't be told: said as each (only the first may leave the list for the end check).
                if(focus!=null) { bool inLines=focus==FocusInLines;StopInput=true;StopWhy=inLines?KeyboardInLines:KeyboardUnknown;Outcome.LogWhy.Add(inLines?"focus_in_lines":"focus_unknown");return inLines?focus:CouldntTellAfterScroll; }
                if(!Screen.ScrollGrid(Grid,Bar,code)) { StopInput=true;StopWhy="COSTAR didn't take the scroll";Outcome.LogWhy.Add("scroll_refused");return "COSTAR didn't take the scroll"; }
                Outcome.Scrolls++;
                // The new position: looked at for up to 1 s (25 looks 40 ms apart).
                InvoiceScroll now=null;
                for(int look=0;look<25;look++) {
                    if(look>0) Parts.Pause(40);
                    now=Screen.ScrollInfo(Bar);
                    if(now!=null&&now.Found&&now.Pos!=pos) break;
                }
                if(now==null||!now.Found) { StopInput=true;StopWhy="the scroll bar went away";return "the line grid's scroll bar position couldn't be read after a scroll"; }
                moved=now.Pos!=pos;pos=now.Pos;
                return null;
            }
            // The lines once COSTAR has drawn them after a scroll: the same twice running.
            internal string Settled(int pos,InvoiceScroll info,out InvoicePage page) {
                page=null;string lastKey=null;string why="the lines kept changing after a scroll";
                for(int i=0;i<12;i++) {
                    Parts.Pause(i==0?150:120);
                    List<ControlInfo> snap;
                    try { snap=Screen.Snapshot(Window); } catch(InvalidOperationException e) { return e.Message; }
                    Snap=snap;
                    string pageWhy;var p=Parts.Page(snap,TextOf,out pageWhy);
                    if(p==null) { why="the lines could not be read after a scroll"+(String.IsNullOrEmpty(pageWhy)?"":" ("+pageWhy+")");lastKey=null;continue; }
                    if(p.Lines==null) p.Lines=new List<InvoiceLine>();
                    string key=PageKey(p);
                    if(lastKey!=null&&key==lastKey) { p.ScrollPos=pos;p.ScrollEnabled=true;p.ScrollMax=info.Top;page=p;return null; }
                    lastKey=key;
                }
                Outcome.LogWhy.Add("unsettled");
                return why;
            }
        }
    }

    // One press of Read: finds the Invoice already open in COSTAR, reads it (InvoiceReading), and logs counts only.
    // Runs on a thread of its own; the tab shows Line while it runs and Outcome once Running is false.
    internal sealed class InvoiceRun {
        internal const string Owner="The invoice read (read only)";
        internal const string NoneOpen="No COSTAR Invoice is open: open the invoice in COSTAR, then press Read.";
        internal volatile bool Cancel;
        internal volatile bool Running=true;   // from before its thread starts, so it can't be started twice
        internal volatile string Line="Starting ...";
        // 2.9.21: called on the read's thread once Running is false (the tab shows the result then, not on its next refresh).
        internal Action Finished;
        volatile InvoiceOutcome outcome;
        internal InvoiceOutcome Outcome { get { return outcome; } }
        readonly EntryCoordinator coordinator;readonly string expected;readonly IInvoiceScreen screen;readonly IInvoiceInputGuard guard;readonly InvoiceParts parts;
        // The live read (2.9.21): clicked is Windows' last input tick when Read was clicked (StartInvoiceRead), for the guard.
        internal InvoiceRun(EntryCoordinator entries,string expected,int? clicked) : this(entries,expected,new InvoiceWin32Screen(),new InvoiceInputGuard(true,clicked),InvoiceParts.Live()) { }
        internal InvoiceRun(EntryCoordinator entries,string expected,IInvoiceScreen screen,IInvoiceInputGuard guard,InvoiceParts parts) {
            coordinator=entries;this.expected=(expected??"").Trim();this.screen=screen;this.guard=guard;this.parts=parts??InvoiceParts.Live();
        }
        internal string Summary { get { var o=outcome;return o==null?"":o.Status; } }
        internal IInvoiceInputGuard Guard { get { return guard; } }
        bool Cancelled() { return Cancel; }
        void Say(string words) { Line=words; }
        internal void Run() {
            EntryLease lease=null;var clock=Stopwatch.StartNew();InvoiceOutcome o=null;
            try {
                if(coordinator!=null) {
                    lease=coordinator.TryBeginRead(Owner);
                    if(lease==null) { o=InvoiceReading.Refuse(new InvoiceOutcome(),(coordinator.Owner.Length>0?coordinator.Owner:"Something")+" is using COSTAR: press Read again when it's done. Nothing was read.","busy",parts);return; }
                }
                o=Read();
            } catch(Exception e) {
                o=InvoiceReading.Refuse(new InvoiceOutcome(),"The invoice couldn't be read: "+e.Message+" Nothing changed in COSTAR.","error_"+e.GetType().Name,parts);
            } finally {
                if(lease!=null) lease.Dispose();
                if(o==null) o=InvoiceReading.Refuse(new InvoiceOutcome(),"The invoice couldn't be read. Nothing changed in COSTAR.","no_outcome",parts);
                outcome=o;Log(o,clock.ElapsedMilliseconds);
                Running=false;
                var done=Finished;if(done!=null) { try { done(); } catch(Exception) { } }
            }
        }
        InvoiceOutcome Read() {
            Say("Looking for the Invoice open in COSTAR ...");
            var all=screen.InvoiceWindows()??new List<InvoiceWindow>();
            if(all.Count==0) return InvoiceReading.Refuse(new InvoiceOutcome(),NoneOpen,"none_open",parts);
            if(all.Count==1) return InvoiceReading.ReadWindow(screen,all[0].Handle,expected,Cancelled,guard,parts,Say);
            // Several: which one is known by its number only (read, never pressed).
            Say("Several Invoices are open in COSTAR: reading their numbers ...");
            var numbers=new List<string>();var matches=new List<IntPtr>();
            foreach(var w in all) {
                if(Cancel) return InvoiceReading.Refuse(new InvoiceOutcome(),InvoiceReading.Stopped,"stopped",parts);
                string n=NumberOf(w);numbers.Add(n);
                if(expected.Length>0&&n==expected) matches.Add(w.Handle);
            }
            string list=String.Join(", ",numbers.ToArray());
            if(expected.Length==0) return InvoiceReading.Refuse(new InvoiceOutcome(),"COSTAR has "+all.Count+" Invoices open ("+list+"): type the one to read in Expected invoice #, then press Read. Nothing was prepared.","several_open",parts);
            if(matches.Count==1) return InvoiceReading.ReadWindow(screen,matches[0],expected,Cancelled,guard,parts,Say);
            if(matches.Count==0) return InvoiceReading.Refuse(new InvoiceOutcome(),"None of the "+all.Count+" open Invoices is "+expected+" (open: "+list+"): nothing was prepared.","not_expected",parts);
            return InvoiceReading.Refuse(new InvoiceOutcome(),matches.Count+" open Invoices show "+expected+": close the extra one in COSTAR, then press Read. Nothing was prepared.","several_same",parts);
        }
        // An open invoice's number, read only ("?" with why when it can't be).
        string NumberOf(InvoiceWindow w) {
            if(InvoiceReading.Blocker(screen,w)!=null) return "? (something is open over it)";
            try {
                var s=screen.Snapshot(w.Handle);string why;
                var page=parts.Page(s,InvoiceReading.TextOf,out why)??new InvoicePage {Lines=new List<InvoiceLine>()};
                var r=parts.Parse(s,InvoiceReading.TextOf,null,new List<InvoicePage>{page},null);
                string n=r==null||r.Number==null?"":r.Number.Trim();
                return n.Length>0?n:"? (its number wasn't read)";
            } catch(InvalidOperationException) { return "? (COSTAR isn't answering on it)"; }
        }
        // The day log: counts, states, codes and the invoice number only (never customer words, descriptions or SKUs).
        void Log(InvoiceOutcome o,long ms) {
            try {
                string tail=" pages="+o.Pages+" scrolls="+o.Scrolls+" ms="+ms+(o.QuietWaitMs>=0?" before_wait_ms="+o.BeforeWaitMs+" quiet="+(o.QuietSkipped?"skipped":"waited")+" quiet_wait_ms="+o.QuietWaitMs:"");
                if(o.Read==null) { AppLog.Note("invoice_dry_run_refused",(o.RefusedLog??"refused")+tail);return; }
                string line=parts.LogLine(o.Read)??"";
                AppLog.Note("invoice_dry_run",line+tail);
                if(!o.Read.Complete) {
                    var why=o.LogWhy.Distinct().ToList();
                    int problems=o.Read.Problems==null?0:o.Read.Problems.Count;
                    AppLog.Note("invoice_dry_run_incomplete",line+" why="+(why.Count>0?String.Join(",",why.ToArray()):"lines_or_fields")+" problems="+problems+tail);
                }
                // 2.9.19: a complete read that left something to say (the list left where COSTAR's keyboard kept it): its codes.
                else if(o.LogWhy.Count>0) AppLog.Note("invoice_dry_run_note",line+" why="+String.Join(",",o.LogWhy.Distinct().ToArray())+" left_pos="+o.LeftPos.ToString(System.Globalization.CultureInfo.InvariantCulture)+tail);
            } catch(Exception) { }
        }
    }

    // The Win32 screen: COSTAR's windows by handle, read with WM_GETTEXT / GetScrollInfo / MSAA; the one input is
    // WM_VSCROLL to the line grid with its scroll bar's handle.
    internal sealed class InvoiceWin32Screen : IInvoiceScreen {
        const uint WmVScroll=0x0115,SbEndScroll=8,SmtoAbortIfHung=0x0002,SmtoBlock=0x0001;
        const int SbCtl=2;const uint SifRangePagePos=0x7;
        [StructLayout(LayoutKind.Sequential)] struct ScrollInfoData { public uint cbSize,fMask;public int nMin,nMax;public uint nPage;public int nPos,nTrackPos; }
        [DllImport("user32.dll",SetLastError=true)] static extern bool GetScrollInfo(IntPtr h,int bar,ref ScrollInfoData info);
        [DllImport("user32.dll",EntryPoint="SendMessageTimeoutW",SetLastError=true)] static extern IntPtr ScrollMessage(IntPtr h,uint msg,UIntPtr w,IntPtr l,uint flags,uint timeout,out UIntPtr result);
        public List<InvoiceWindow> InvoiceWindows() {
            var found=new List<InvoiceWindow>();var costar=new Dictionary<uint,bool>();
            Native.EnumWindows(delegate(IntPtr h,IntPtr unused) {
                if(!Native.IsWindowVisible(h)) return true;
                string caption=Native.Caption(h);int branch;string name;
                if(!InvoiceReader.IsInvoiceCaption(caption,out branch,out name)) return true;
                uint pid=Native.Pid(h);bool yes;
                if(!costar.TryGetValue(pid,out yes)) { yes=CostarWindows.IsCostar(h);costar[pid]=yes; }
                if(yes) found.Add(new InvoiceWindow {Handle=h,Pid=pid,Caption=caption,Enabled=Native.IsWindowEnabled(h),Visible=true});
                return true;
            },IntPtr.Zero);
            return found;
        }
        public InvoiceWindow Window(IntPtr window) {
            if(window==IntPtr.Zero||!Native.IsWindow(window)) return null;
            return new InvoiceWindow {Handle=window,Pid=Native.Pid(window),Caption=Native.Caption(window),Enabled=Native.IsWindowEnabled(window),Visible=Native.IsWindowVisible(window)};
        }
        public List<string> Over(IntPtr window) {
            var found=new List<string>();uint pid=Native.Pid(window);
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) {
                if(w==window||Native.Pid(w)!=pid||!Native.IsWindowVisible(w)||Runner.Decoration(w)) return true;
                var o=Native.GetWindow(w,4);
                for(int i=0;i<16&&o!=IntPtr.Zero;i++,o=Native.GetWindow(o,4)) if(o==window) { string c=Native.Caption(w);found.Add(c.Length>0?c:"a COSTAR window");break; }
                return true;
            },IntPtr.Zero);
            return found;
        }
        // As WholesaleOrderReader.Snapshot (visible controls of the window's process, at most 4000, after COSTAR has
        // answered WM_NULL), then every box's text read with WM_GETTEXT (password boxes never).
        public List<ControlInfo> Snapshot(IntPtr window) {
            var s=new List<ControlInfo>();
            Native.Rect rb;Order.Require(Native.GetWindowRect(window,out rb),"The invoice window closed in COSTAR.");
            UIntPtr answer;Order.Require(Native.SendNull(window,0,UIntPtr.Zero,IntPtr.Zero,SmtoAbortIfHung,3000,out answer)!=IntPtr.Zero,"COSTAR isn't answering (the invoice may still be loading).");
            uint owner=Native.Pid(window);var handles=new List<IntPtr>();
            Native.EnumChildWindows(window,delegate(IntPtr h,IntPtr unused) { if(Native.Pid(h)==owner&&Native.IsWindowVisible(h)) handles.Add(h);return handles.Count<4000; },IntPtr.Zero);
            foreach(var h in handles) {
                Native.Rect box;if(!Native.GetWindowRect(h,out box)) continue;
                var c=new ControlInfo {Handle=h.ToInt64(),Root=window.ToInt64(),Parent=Native.GetParent(h).ToInt64(),Class=Native.Class(h),Style=Native.GetWindowLong(h,-16),Visible=true,Enabled=Native.IsWindowEnabled(h),
                    Bounds=new[]{box.Left,box.Top,box.Right-box.Left,box.Bottom-box.Top},RelativeBounds=new[]{box.Left-rb.Left,box.Top-rb.Top,box.Right-box.Left,box.Bottom-box.Top},TextState="not-read"};
                c.Password=c.Class.IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)>=0&&(c.Style&0x20)!=0;
                string t;if(!c.Password&&Native.TryText(h,out t)) { c.Text=t;c.TextState="read"; }
                s.Add(c);
            }
            return s;
        }
        public string SelectedTab(IntPtr window,List<ControlInfo> snapshot) { return snapshot==null?null:WholesaleOrderReader.Tab(snapshot); }
        public long KeyboardFocus(IntPtr window) {
            if(window==IntPtr.Zero||!Native.IsWindow(window)) return -1;
            uint pid;var info=new Native.GuiInfo();info.size=Marshal.SizeOf(typeof(Native.GuiInfo));
            if(!Native.GetGUIThreadInfo(Native.GetWindowThreadProcessId(window,out pid),ref info)) return -1;
            return info.focus.ToInt64();
        }
        public InvoiceScroll ScrollInfo(IntPtr scrollBar) {
            var r=new InvoiceScroll();
            if(scrollBar==IntPtr.Zero||!Native.IsWindow(scrollBar)) return r;
            var d=new ScrollInfoData {cbSize=(uint)Marshal.SizeOf(typeof(ScrollInfoData)),fMask=SifRangePagePos};
            if(!GetScrollInfo(scrollBar,SbCtl,ref d)) return r;
            r.Found=true;r.Enabled=Native.IsWindowEnabled(scrollBar);r.Min=d.nMin;r.Max=d.nMax;r.Page=(int)d.nPage;r.Pos=d.nPos;
            return r;
        }
        // The one input. Only to a SCROLLBAR control of a COSTAR process, enabled, whose parent is the grid given; only
        // line/page up/down; nothing else is sent.
        public bool ScrollGrid(IntPtr grid,IntPtr scrollBar,int code) {
            if(!InvoiceScreenRules.Allowed(code)) return false;
            if(grid==IntPtr.Zero||scrollBar==IntPtr.Zero||!Native.IsWindow(scrollBar)||!Native.IsWindow(grid)) return false;
            if(Native.GetParent(scrollBar)!=grid||Native.Pid(scrollBar)!=Native.Pid(grid)) return false;
            if(Native.Class(scrollBar).IndexOf("SCROLLBAR",StringComparison.OrdinalIgnoreCase)<0||!Native.IsWindowEnabled(scrollBar)) return false;
            if(!CostarWindows.IsCostar(scrollBar)) return false;
            UIntPtr result;
            bool sent=ScrollMessage(grid,WmVScroll,new UIntPtr((uint)code),scrollBar,SmtoAbortIfHung|SmtoBlock,2000,out result)!=IntPtr.Zero;
            if(sent) ScrollMessage(grid,WmVScroll,new UIntPtr(SbEndScroll),scrollBar,SmtoAbortIfHung|SmtoBlock,2000,out result);
            return sent;
        }
    }

    // The live side's self-tests (made-up screens only; no COSTAR window is looked at). InvoiceTests.Cases calls
    // InvoiceLiveChecks.Cases(Case). The line pages here are made up by the test's own page reader, so these cases
    // test the paging driver, the refusals and the dry-run guarantees, not InvoiceModel's reading of a screen.
    internal static class InvoiceLiveChecks {
        static void Check(bool value,string message) { if(!value) throw new InvalidOperationException(message); }
        const long GridH=500,BarH=501,StateH=502,ItemH=503,PanelH=504,LabelH=505,BoxH=506;
        // A made-up COSTAR: Invoice windows (handle -> number), one line grid of Total lines, 25 showing from Pos.
        internal sealed class FakeScreen : IInvoiceScreen {
            internal readonly List<InvoiceWindow> Windows=new List<InvoiceWindow>();
            internal readonly Dictionary<long,string> Numbers=new Dictionary<long,string>();
            internal readonly Dictionary<long,List<string>> OverIt=new Dictionary<long,List<string>>();
            internal int Total=20,Pos,Version;internal bool BarEnabled,Stuck,SameNumbers;
            internal readonly List<int> Codes=new List<int>();internal int Snapshots;
            internal Action<FakeScreen> AfterScroll;
            // 2.9.19: EmptyAfter: empty lines the list holds after its last filled one (each shows its number, nothing on
            // it; the page then gives every number it shows). BoxLine: the line whose own panel, number label and Item box
            // (BoxH) the snapshot holds while that line is on screen; the Item box holds "T<n>" on a filled line, else BoxText.
            internal int EmptyAfter,BoxLine;internal string BoxText="";
            // 2.9.19: Header: the words of a made-up box outside the line list (a header box; no ';' or '=' in them).
            // FocusAsked: called each time the helper asks where COSTAR's keyboard is (before each scroll), before it is told.
            internal string Header="";internal Action<FakeScreen> FocusAsked;
            // 2.9.19 (review 2): Refuses: COSTAR doesn't take a scroll (ScrollGrid answers false; it is still counted in Codes,
            // nothing moves). OverAsked, SnapshotAsked: called each time the helper asks what is over the invoice, or for a
            // snapshot, before it is told (SnapshotAsked may throw, as the live screen does when COSTAR doesn't answer).
            internal bool Refuses;internal Action<FakeScreen> OverAsked,SnapshotAsked;
            internal int Top { get { return Math.Max(0,Total+EmptyAfter-25); } }
            internal IntPtr Add(long handle,string number) {
                Windows.Add(new InvoiceWindow {Handle=new IntPtr(handle),Pid=7,Caption="Invoice  Branch 1  Tempe Tyres Sydney",Enabled=true,Visible=true});
                Numbers[handle]=number;return new IntPtr(handle);
            }
            public List<InvoiceWindow> InvoiceWindows() { return Windows.ToList(); }
            public InvoiceWindow Window(IntPtr window) { return Windows.FirstOrDefault(w=>w.Handle==window); }
            public List<string> Over(IntPtr window) { if(OverAsked!=null) OverAsked(this);List<string> o;return OverIt.TryGetValue(window.ToInt64(),out o)?o.ToList():new List<string>(); }
            static ControlInfo Mk(long h,long parent,string cls,int x,int y,int w,int hh,string text,bool enabled) {
                return new ControlInfo {Handle=h,Parent=parent,Class=cls,Visible=true,Enabled=enabled,Bounds=new[]{x,y,w,hh},RelativeBounds=new[]{x,y,w,hh},Text=text,TextState="read"};
            }
            public List<ControlInfo> Snapshot(IntPtr window) {
                if(SnapshotAsked!=null) SnapshotAsked(this);
                Snapshots++;
                string n;Numbers.TryGetValue(window.ToInt64(),out n);
                var s=new List<ControlInfo> {
                    Mk(GridH,1,"WindowsForms10.Window.8.app.0.1",37,340,1010,692,"",true),
                    Mk(ItemH,GridH,"WindowsForms10.STATIC.app.0.1",61,341,79,27,"Item",true),
                    Mk(BarH,GridH,"WindowsForms10.SCROLLBAR.app.0.1",1030,370,17,475,"",BarEnabled),
                    Mk(StateH,1,"WindowsForms10.STATIC.app.0.1",0,0,1,1,"num="+n+";pos="+Pos+";v="+Version+";n="+Total+";same="+(SameNumbers?1:0)+";e="+EmptyAfter+";h="+Header,true)
                };
                if(BoxLine>Pos&&BoxLine<=Pos+25&&BoxLine<=Total+EmptyAfter) {
                    // As the 3 Nov map: the line's panel 19 px below the one before, its number at x 36, its Item box at x 63.
                    int y=369+19*(BoxLine-Pos-1);
                    s.Add(Mk(PanelH,GridH,"WindowsForms10.Window.8.app.0.1",38,y,993,20,"",true));
                    s.Add(Mk(LabelH,PanelH,"WindowsForms10.STATIC.app.0.1",36,y+1,27,19,BoxLine.ToString(System.Globalization.CultureInfo.InvariantCulture),true));
                    s.Add(Mk(BoxH,PanelH,"WindowsForms10.EDIT.app.0.1",63,y,163,20,BoxLine<=Total?"T"+BoxLine.ToString(System.Globalization.CultureInfo.InvariantCulture):BoxText,true));
                }
                return s;
            }
            public string SelectedTab(IntPtr window,List<ControlInfo> snapshot) { return "Ship to"; }
            // A disabled bar's leftover range (WinForms' default 0..100, page 10) when LeftoverRange is set.
            internal bool LeftoverRange;internal long Focus;
            public InvoiceScroll ScrollInfo(IntPtr scrollBar) {
                if(scrollBar.ToInt64()!=BarH) return new InvoiceScroll();
                if(LeftoverRange&&!BarEnabled) return new InvoiceScroll {Found=true,Enabled=false,Min=0,Max=100,Page=10,Pos=0};
                return new InvoiceScroll {Found=true,Enabled=BarEnabled,Min=0,Max=Math.Max(24,Total+EmptyAfter-1),Page=25,Pos=Pos};
            }
            public long KeyboardFocus(IntPtr window) { if(FocusAsked!=null) FocusAsked(this);return Focus; }
            public bool ScrollGrid(IntPtr grid,IntPtr scrollBar,int code) {
                Check(grid.ToInt64()==GridH&&scrollBar.ToInt64()==BarH,"a scroll went somewhere other than the line grid's own scroll bar");
                Check(InvoiceScreenRules.Allowed(code),"a scroll code other than line/page up/down");
                Codes.Add(code);
                if(Refuses) return false;
                if(!Stuck) {
                    int step=code==InvoiceScreenRules.PageDown?25:code==InvoiceScreenRules.LineDown?1:code==InvoiceScreenRules.PageUp?-25:-1;
                    Pos=Math.Max(0,Math.Min(Top,Pos+step));
                }
                if(AfterScroll!=null) AfterScroll(this);
                return true;
            }
        }
        internal sealed class FakeGuard : IInvoiceInputGuard {
            internal int Began,Ended,Asked;internal int PersonAfter=-1;internal string Refuse;
            // 2.9.19 (review 2): OnBegin: called while the guard begins (after its checks), before Begin returns.
            internal Action OnBegin;
            // 2.9.21: what Skipped answers (as if nothing was touched since the click on Read).
            internal bool Skip;
            public bool Skipped { get { return Skip; } }
            public void Begin(Func<bool> cancelled) { if(Refuse!=null) throw new InvalidOperationException(Refuse);Began++;if(OnBegin!=null) OnBegin(); }
            public string Problem() { Asked++;return PersonAfter>=0&&Asked>PersonAfter?"someone used the PC while the line list was being scrolled":null; }
            public void End() { Ended++; }
        }
        static Dictionary<string,string> State(List<ControlInfo> s) {
            var d=new Dictionary<string,string>();
            var c=s.First(x=>x.Handle==StateH);
            foreach(var part in c.Text.Split(';')) { int i=part.IndexOf('=');d[part.Substring(0,i)]=part.Substring(i+1); }
            return d;
        }
        static InvoiceLine Line(int number,string content) { return new InvoiceLine {Number=number,Item="T"+content,ItemRaw="T"+content,Description="tyre "+content,Qty="1",Net="10.00",LineTotal="11.00",Kind="product"}; }
        static bool FakeMerge(List<InvoicePage> pages,out List<InvoiceLine> merged,out string why) {
            var by=new SortedDictionary<int,InvoiceLine>();merged=null;why=null;
            foreach(var p in pages) foreach(var l in p.Lines) {
                InvoiceLine seen;
                if(by.TryGetValue(l.Number,out seen)&&InvoiceReading.LineKey(seen)!=InvoiceReading.LineKey(l)) { why="line "+l.Number+" read differently on two pages";return false; }
                by[l.Number]=l;
            }
            int k=0;foreach(var n in by.Keys) if(n!=++k) { why="line "+k+" is missing";return false; }
            merged=by.Values.ToList();return true;
        }
        static InvoicePage FakePage(List<ControlInfo> s,Func<ControlInfo,string> text,out string why) {
            why=null;var d=State(s);int pos=Int32.Parse(d["pos"]),n=Int32.Parse(d["n"]),v=Int32.Parse(d["v"]);bool same=d["same"]=="1";
            var lines=new List<InvoiceLine>();
            for(int i=1;i<=25&&pos+i<=n;i++) lines.Add(Line(same?i:pos+i,(pos+i)+(v>0?"v"+v:"")));
            var page=new InvoicePage {Lines=lines};
            // 2.9.19: with empty lines after the filled ones, every number on screen, filled or empty (as InvoiceReader.Page).
            string e;int empty;
            if(d.TryGetValue("e",out e)&&Int32.TryParse(e,out empty)&&empty>0) for(int i=1;i<=25&&pos+i<=n+empty;i++) page.Numbers.Add(same?i:pos+i);
            return page;
        }
        // The made-up InvoiceModel: lines Pos+1..Pos+25 of Total (or always numbered 1..25 when SameNumbers).
        internal static InvoiceParts Parts() {
            return new InvoiceParts {
                Page=FakePage,Merge=FakeMerge,
                Parse=delegate(List<ControlInfo> s,Func<ControlInfo,string> text,string tab,List<InvoicePage> pages,string pagingWhy) {
                    var r=new InvoiceRead {Number=State(s)["num"],Branch=1,YShown=tab=="Ship to"};
                    List<InvoiceLine> merged;string why;
                    if(pagingWhy==null&&FakeMerge(pages,out merged,out why)) { r.Lines=merged;r.LinesComplete=true; }
                    else { r.Lines=pages[0].Lines;r.LinesComplete=false;r.LinesWhy=pagingWhy??"merge";r.Problems.Add(r.LinesWhy); }
                    r.Complete=r.LinesComplete;
                    return r;
                },
                Fingerprint=delegate(List<ControlInfo> s,Func<ControlInfo,string> text) { var d=State(s);return d["num"]+"|"+d["pos"]+"|"+d["v"]+"|"+d["n"]+"|"+d["h"]; },
                Review=delegate(InvoiceRead r) { return "Invoice "+r.Number+"\n"+r.Lines.Count+" lines"; },
                Buffalo=delegate(InvoiceRead r) { return "NOT READY FOR BOOKING – 1 item unresolved"; },
                Status=delegate(InvoiceRead r) { return r.Complete?InvoicePreview.ReadComplete:"Read INCOMPLETE — "+String.Join("; ",r.Incomplete.Concat(r.Problems).ToArray())+"; nothing changed in COSTAR."; },
                LogLine=delegate(InvoiceRead r) { return "invoice="+r.Number+" lines="+r.Lines.Count; },
                Pause=delegate(int ms) { }
            };
        }
        // 2.9.19: the made-up InvoiceReader.FingerprintOutsideLines (Parts() has none: Outside null, as 2.9.18). The real
        // one finds no line grid on the made-up screen (its Item heading has no Qty or Hrs heading beside it), so this
        // gives everything the made-up screen shows outside its line panels: all of its state but where the line list is
        // (pos) and what its lines hold (v).
        static string FakeOutside(List<ControlInfo> s,Func<ControlInfo,string> text) {
            var d=State(s);return d["num"]+"|"+d["n"]+"|"+d["e"]+"|"+d["same"]+"|"+d["h"];
        }
        // 2.9.19 (review 2): an outcome as a failed check says it.
        static string Told(InvoiceOutcome x) {
            if(x==null) return "no outcome";
            return x.Status+" (why="+String.Join(",",x.LogWhy.ToArray())+"; warn="+(x.Warn??"none")+"; left at "+x.LeftPos+(x.LeftForKeyboard?" for the keyboard":"")+")";
        }
        static InvoiceOutcome Run(FakeScreen screen,string expected,FakeGuard guard) { return Run(screen,expected,guard,Parts()); }
        static InvoiceOutcome Run(FakeScreen screen,string expected,FakeGuard guard,InvoiceParts parts) {
            var run=new InvoiceRun(null,expected,screen,guard,parts);
            run.Run();
            Check(!run.Running&&run.Outcome!=null,"the run didn't end with an outcome");
            return run.Outcome;
        }
        interface IWithAPress { List<InvoiceWindow> InvoiceWindows();bool Press(IntPtr button); }
        internal static void Cases(Action<string,Action> Case) {
            Case("Invoice live (2.9.15): the reader's only way into COSTAR is reads plus one scroll of the line grid (IInvoiceScreen, by reflection)",()=>{
                Check(InvoiceScreenRules.Check(typeof(IInvoiceScreen))==null,"IInvoiceScreen: "+InvoiceScreenRules.Check(typeof(IInvoiceScreen)));
                Check(InvoiceScreenRules.Inputs.Length==1&&InvoiceScreenRules.Inputs[0]=="ScrollGrid","more than one input method is allowed");
                Check(InvoiceScreenRules.Check(typeof(IWithAPress))!=null,"an interface with a Press method passed the check");
                Check(!InvoiceScreenRules.Allowed(4)&&!InvoiceScreenRules.Allowed(6)&&!InvoiceScreenRules.Allowed(7)&&!InvoiceScreenRules.Allowed(-1),"a scroll code other than line/page up/down is allowed");
                Check(typeof(IInvoiceScreen).IsAssignableFrom(typeof(InvoiceWin32Screen)),"the Win32 screen doesn't implement IInvoiceScreen");
            });
            Case("Invoice live (2.9.15): selling is off and the Sold button is made disabled with nothing on its click",()=>{
                var field=typeof(InvoiceDryRun).GetField("SellingEnabled",BindingFlags.NonPublic|BindingFlags.Public|BindingFlags.Static);
                Check(field!=null&&field.IsLiteral&&Equals(field.GetRawConstantValue(),false),"InvoiceDryRun.SellingEnabled isn't a false constant");
                using(var sold=InvoiceUi.SoldButton()) {
                    Check(!sold.Enabled,"the Sold button is enabled");
                    Check(sold.Text=="Sold (disabled in dry run)","the Sold button's words changed");
                    Check(InvoiceUi.ClickHandlers(sold)==0,"the Sold button has a click handler");
                }
                using(var probe=new System.Windows.Forms.Button()) { probe.Click+=delegate { };Check(InvoiceUi.ClickHandlers(probe)==1,"the click-handler count can't be read (the Sold check would be blind)"); }
            });
            Case("Invoice live (2.9.15): the build's source guard catches each press, key, click, close, focus, text-setting or sell call",()=>{
                var planted=new[]{"Direct"+".Act(x)","Direct"+".Press(h,1)","BM_"+"CLICK","Send(h,0x00"+"F5)","Nati"+"ve.Key"+"Now(13)","Nati"+"ve.Key(9)","Nati"+"ve.Double"+"ClickNow(p)",
                    // 2.9.15 review: the MSAA wrappers, a using-alias, press helpers in other files, any other message.
                    "Ms"+"aa.DoDef"+"ault(a);","Nati"+"ve.Select"+"Child(p,c);","a.acc"+"Select(3,0);","us"+"ing N=Native; N.Click(p)","us"+"ing D=TempeCostar.Direct;",
                    "Ro"+"Wip.ReadList(t,true,false,null)","Ru"+"nner.Press(b)","Costar"+"Windows.Front(w)","Wholesale"+"OrderReader.SelectTab(s)","Wi"+"n.Click(h)",
                    "typ"+"eof(Native).GetField(\"x\")","t.GetMeth"+"od(\"Click\")","[DllImport(\"user32.dll\")] static ex"+"tern IntPtr SendMessageW(IntPtr h,uint m,IntPtr w,IntPtr l);",
                    "[DllImport(\"user32.dll\",EntryPo"+"int=\"Post"+"MessageW\")] static extern IntPtr ScrollMessage(IntPtr h,uint msg,UIntPtr w,IntPtr l,uint flags,uint timeout,out UIntPtr result);",
                    "Scroll"+"Message(grid,0x0100,new UIntPtr(13),bar,2,2000,out r)","Scroll"+"Message(grid,0x0201,UIntPtr.Zero,bar,2,2000,out r)","Scroll"+"Message(h,WmVScroll,c,bar,2,2000,out r)",
                    "const uint WmV"+"Scroll=0x0111","Nati"+"ve.Send"+"Null(h,245,UIntPtr.Zero,IntPtr.Zero,2,100,out a)","Nati"+"ve.Send"+"Null(h,16,UIntPtr.Zero,IntPtr.Zero,2,100,out a)",
                    "Send"+"Input(1,a,2)","keybd"+"_event(1)","mouse"+"_event(2)","WM_"+"CLOSE","Ro"+"Engine.Close"+"Window(w)","Send(w,0x00"+"10,0,0)","WM_"+"SETTEXT","Send(w,0x00"+"0C,0,s)",
                    "Set"+"Focus(h)","Direct"+".Focus(h)","a.acc"+"DoDef"+"aultAction(0)","run.Se"+"ll(order)","Sel"+"lNow()","box.Set"+"Text(\"x\")","Ui.Set"+"Text(l,t)","Set"+"WindowText(h,s)","Post"+"Message(h,1,2,3)"};
                foreach(var p in planted) Check(InvoiceSourceGuard.Hits(p).Count>0,"the guard missed a planted call ("+p.Length+" characters)");
                Check(InvoiceSourceGuard.Hits("var info=screen.ScrollInfo(bar);if(InvoiceDryRun.SellingEnabled) return;const uint WmVScroll=0x0115;label.Text=\"Sold\";").Count==0,"the guard refused clean code");
                // The sources built with this EXE (Build.ps1 keeps them beside the bin folder), when they are there.
                string folder=Path.Combine(Path.GetDirectoryName(typeof(InvoiceLiveChecks).Assembly.Location)??"","..","Source");
                if(Directory.Exists(folder)) foreach(var f in Directory.GetFiles(folder,"Invoice*.cs")) {
                    var hits=InvoiceSourceGuard.Hits(File.ReadAllText(f));
                    Check(hits.Count==0,Path.GetFileName(f)+" names a forbidden call: "+String.Join(" ",hits.ToArray()));
                }
            });
            Case("Invoice live (2.9.15): refusals: none open, several open, another number expected, a window over it, disabled; nothing scrolled",()=>{
                var none=new FakeScreen();
                var o=Run(none,"",new FakeGuard());
                Check(o.Read==null&&o.Status==InvoiceRun.NoneOpen,"none open: "+o.Status);
                var two=new FakeScreen();two.Add(11,"1001");two.Add(12,"1002");
                o=Run(two,"",new FakeGuard());
                Check(o.Read==null&&o.Status.Contains("1001")&&o.Status.Contains("1002")&&o.Status.Contains("Expected invoice #"),"two open, none expected: "+o.Status);
                o=Run(two,"1002",new FakeGuard());
                Check(o.Read!=null&&o.Read.Number=="1002"&&o.Complete,"two open, 1002 expected: "+o.Status);
                o=Run(two,"1003",new FakeGuard());
                Check(o.Read==null&&o.Status.StartsWith("None of the 2 open Invoices is 1003"),"two open, 1003 expected: "+o.Status);
                var one=new FakeScreen();one.Add(11,"1001");
                o=Run(one,"  1002 ",new FakeGuard());
                Check(o.Read==null&&o.Status=="The open invoice is 1001, not 1002: nothing was prepared.","another number: "+o.Status);
                Check(o.Buffalo.Length==0,"a refusal prepared Buffalo details");
                o=Run(one," 1001 ",new FakeGuard());
                Check(o.Complete&&o.Status==InvoicePreview.ReadComplete,"the expected number trimmed: "+o.Status);
                one.OverIt[11]=new List<string>{"Notes"};
                o=Run(one,"",new FakeGuard());
                Check(o.Read==null&&o.Status=="Something is open over the invoice in COSTAR (Notes): close it, then press Read.","a window over it: "+o.Status);
                one.OverIt.Clear();one.Windows[0].Enabled=false;
                o=Run(one,"",new FakeGuard());
                Check(o.Read==null&&o.Status.StartsWith("Something is open over the invoice in COSTAR (")&&o.Status.EndsWith("): close it, then press Read."),"disabled: "+o.Status);
                Check(none.Codes.Count+two.Codes.Count+one.Codes.Count==0,"a refusal scrolled COSTAR");
            });
            Case("Invoice live (2.9.15): up to 25 lines: read without any input; read twice, the same",()=>{
                var screen=new FakeScreen {Total=20};var guard=new FakeGuard();screen.Add(11,"1001");
                var a=Run(screen,"",guard);var b=Run(screen,"",guard);
                Check(a.Complete&&a.Read.Lines.Count==20&&a.Pages==1,"20 lines: "+a.Status);
                Check(screen.Codes.Count==0&&guard.Began==0,"COSTAR was scrolled (or the input lock taken) for 20 lines");
                Check(a.Review==b.Review&&a.Buffalo==b.Buffalo&&a.Status==b.Status,"two reads of the same invoice differ");
                Check(a.Review.Contains("\r\n")&&!a.Review.Replace("\r\n","").Contains("\n"),"the shown text isn't in Windows lines");
            });
            Case("Invoice live (2.9.15): 60 lines: paged by the grid's scroll bar only, merged by line number 1..60, scrolled back and read the same",()=>{
                var screen=new FakeScreen {Total=60,BarEnabled=true};var guard=new FakeGuard();screen.Add(11,"1001");
                var o=Run(screen,"",guard);
                Check(o.Complete&&o.Read.Lines.Count==60,"60 lines: "+o.Status);
                for(int i=0;i<60;i++) Check(o.Read.Lines[i].Number==i+1,"line "+(i+1)+" out of place");
                Check(screen.Pos==0,"the line list wasn't scrolled back (at "+screen.Pos+")");
                Check(guard.Began==1&&guard.Ended==1,"the input guard wasn't begun and ended once");
                Check(screen.Codes.Count(c=>c==InvoiceScreenRules.PageDown)==2&&screen.Codes.All(c=>c==InvoiceScreenRules.PageDown||c==InvoiceScreenRules.PageUp||c==InvoiceScreenRules.LineUp),"unexpected scrolls: "+String.Join(",",screen.Codes.Select(c=>c.ToString()).ToArray()));
                Check(o.Pages==3&&o.Scrolls==screen.Codes.Count,"pages "+o.Pages+", scrolls "+o.Scrolls);
                // Staff left it scrolled to line 26: read from the top, then put back at 26.
                screen.Codes.Clear();screen.Pos=25;
                o=Run(screen,"",guard);
                Check(o.Complete&&o.Read.Lines.Count==60&&screen.Pos==25,"started at line 26: "+o.Status+" (at "+screen.Pos+")");
                // The same with InvoiceModel's own Merge (screens in scroll order from the top, positions rising).
                foreach(int start in new[]{0,25}) {
                    screen.Codes.Clear();screen.Pos=start;
                    var real=Parts();real.Merge=InvoiceReader.Merge;
                    var run=new InvoiceRun(null,"",screen,guard,real);run.Run();o=run.Outcome;
                    Check(o!=null&&o.Complete&&o.Read.Lines.Count==60&&screen.Pos==start,"InvoiceReader.Merge, started at "+start+": "+(o==null?"no outcome":o.Status));
                }
            });
            Case("Invoice live (2.9.15): paging that can't be trusted is INCOMPLETE with its reason, never guessed",()=>{
                var stuck=new FakeScreen {Total=60,BarEnabled=true,Stuck=true};stuck.Add(11,"1001");
                var o=Run(stuck,"",new FakeGuard());
                Check(!o.Complete&&o.Read!=null&&o.Status.Contains("lines 26+ could not be read: the scroll position did not move"),"stuck: "+o.Status);
                var same=new FakeScreen {Total=60,BarEnabled=true,SameNumbers=true};same.Add(11,"1001");
                o=Run(same,"",new FakeGuard());
                Check(!o.Complete&&o.Status.Contains("the line numbers did not change after a scroll"),"numbers unchanged: "+o.Status);
                var disabled=new FakeScreen {Total=60,BarEnabled=false};disabled.Add(11,"1001");
                o=Run(disabled,"",new FakeGuard());
                Check(!o.Complete&&o.Status.Contains("lines 26+ could not be read")&&disabled.Codes.Count==0,"disabled bar with more lines: "+o.Status);
                var person=new FakeScreen {Total=80,BarEnabled=true};person.Add(11,"1001");
                o=Run(person,"",new FakeGuard {PersonAfter=1});
                Check(!o.Complete&&o.Status.Contains("someone used the PC")&&person.Codes.Count==1,"someone at the PC: "+o.Status+" ("+person.Codes.Count+" scrolls)");
                Check(o.Read.Problems.Any(p=>p.Contains("left scrolled")),"not said that the line list was left scrolled");
                var refused=new FakeScreen {Total=60,BarEnabled=true};refused.Add(11,"1001");
                o=Run(refused,"",new FakeGuard {Refuse="Another COSTAR helper is entering data"});
                Check(!o.Complete&&o.Status.Contains("lines 26+ could not be read: Another COSTAR helper")&&refused.Codes.Count==0,"input lock held elsewhere: "+o.Status);
            });
            Case("Invoice live (2.9.15): an invoice that changes while it is read is INCOMPLETE (press Read again)",()=>{
                var screen=new FakeScreen {Total=60,BarEnabled=true};screen.Add(11,"1001");
                screen.AfterScroll=delegate(FakeScreen f) { if(f.Pos==f.Top&&f.Version==0) f.Version=1; };
                var o=Run(screen,"",new FakeGuard());
                Check(!o.Complete&&o.Status.Contains("the invoice changed while it was read: press Read again"),"changed: "+o.Status);
            });
            Case("Invoice live (2.9.15): the Buffalo copy is set, read back and tried again up to 3 times",()=>{
                int sets=0;string board=null;int attempts;
                string why=InvoiceClipboard.CopyChecked("a\r\nb",delegate(string t) { sets++;board=sets<3?"":t; },delegate { return board; },delegate(int ms) { },out attempts);
                Check(why==null&&attempts==3&&sets==3,"third try: "+why);
                why=InvoiceClipboard.CopyChecked("a",delegate(string t) { board="other"; },delegate { return board; },delegate(int ms) { },out attempts);
                Check(why!=null&&attempts==3,"never read back the same, yet copied");
                Check(InvoiceUi.LineCount("a\r\nb\r\n")==2&&InvoiceUi.LineCount("")==0,"lines counted wrongly");
                // Timed out: nothing more is put on the clipboard once the caller has given up.
                bool gaveUp=false;sets=0;
                why=InvoiceClipboard.CopyChecked("a",delegate(string t) { sets++;gaveUp=true; },delegate { return "x"; },delegate(int ms) { },delegate { return gaveUp; },out attempts);
                Check(why!=null&&sets==1,"the copy went on setting the clipboard after it was given up ("+sets+" sets)");
            });
            Case("Invoice live (2.9.15 review): a disabled scroll bar with a leftover range is 'everything fits' unless the screen shows more",()=>{
                var two=new FakeScreen {Total=2,BarEnabled=false,LeftoverRange=true};two.Add(11,"1001");
                var o=Run(two,"",new FakeGuard());
                Check(o.Complete&&o.Read.Lines.Count==2&&two.Codes.Count==0,"2 lines, disabled bar with range 0..100: "+o.Status);
                var full=new FakeScreen {Total=60,BarEnabled=false,LeftoverRange=true};full.Add(11,"1001");
                o=Run(full,"",new FakeGuard());
                Check(!o.Complete&&o.Status.Contains("scroll bar is disabled although")&&full.Codes.Count==0,"25 filled, disabled bar with a range: "+o.Status);
            });
            Case("Invoice live (2.9.15 review): never scrolled while a box in the line list has COSTAR's keyboard",()=>{
                var screen=new FakeScreen {Total=60,BarEnabled=true,Focus=ItemH};screen.Add(11,"1001");var guard=new FakeGuard();
                var o=Run(screen,"",guard);
                Check(!o.Complete&&o.Status.Contains("lines 26+ could not be read: "+InvoiceReading.FocusInLines)&&screen.Codes.Count==0&&guard.Began==0,"focus in the lines: "+o.Status);
                Check(o.LogWhy.Contains("focus_in_lines"),"not coded for the log");
                screen.Focus=GridH;o=Run(screen,"",guard);
                Check(!o.Complete&&screen.Codes.Count==0,"focus on the grid panel itself: "+o.Status);
                screen.Focus=-1;o=Run(screen,"",guard);
                Check(!o.Complete&&o.Status.Contains("keyboard is couldn't be told")&&screen.Codes.Count==0,"focus unknown: "+o.Status);
                // Focus elsewhere on the invoice (not under the line list): read as usual.
                screen.Focus=StateH;o=Run(screen,"",guard);
                Check(o.Complete&&o.Read.Lines.Count==60,"focus outside the lines: "+o.Status);
                // Someone clicks into the lines while it pages: stopped there, not scrolled back under the keyboard.
                var later=new FakeScreen {Total=80,BarEnabled=true};later.Add(11,"1001");
                later.AfterScroll=delegate(FakeScreen f) { f.Focus=ItemH; };
                o=Run(later,"",new FakeGuard());
                Check(!o.Complete&&o.Status.Contains(InvoiceReading.FocusInLines)&&later.Codes.Count==1,"focus moved into the lines: "+o.Status+" ("+later.Codes.Count+" scrolls)");
            });
            Case("Invoice live (2.9.15 review): a window opened over the invoice while paging: its title is shown, never logged",()=>{
                const string secret="JANE MOCKS 0400555111 Notes";
                var screen=new FakeScreen {Total=80,BarEnabled=true};screen.Add(11,"1001");
                screen.AfterScroll=delegate(FakeScreen f) { f.OverIt[11]=new List<string>{secret}; };
                var parts=Parts();
                var fakeParse=parts.Parse;
                // As the real Parse: the paging reason becomes an incomplete reason (InvoicePreview.LogLine logs those).
                parts.Parse=delegate(List<ControlInfo> s,Func<ControlInfo,string> text,string tab,List<InvoicePage> pages,string pagingWhy) {
                    var r=fakeParse(s,text,tab,pages,pagingWhy);if(pagingWhy!=null) InvoiceReader.MarkIncomplete(r,pagingWhy);return r;
                };
                parts.LogLine=InvoicePreview.LogLine;
                var run=new InvoiceRun(null,"",screen,new FakeGuard(),parts);run.Run();var o=run.Outcome;
                Check(o!=null&&o.Read!=null&&!o.Complete,"not incomplete: "+(o==null?"no outcome":o.Status));
                string log=InvoicePreview.LogLine(o.Read)+" "+String.Join(",",o.LogWhy.ToArray());
                Check(log.IndexOf("JANE",StringComparison.OrdinalIgnoreCase)<0&&log.IndexOf("0400555111",StringComparison.Ordinal)<0,"the window's title reached the log line");
                Check(o.Read.Incomplete.All(x=>x.IndexOf("JANE",StringComparison.Ordinal)<0),"the window's title is an incomplete reason");
                Check(o.Read.Problems.Any(x=>x.Contains(secret)),"the window's title isn't shown");
            });
            Case("Invoice live (2.9.19): COSTAR's keyboard going into the line list after the first scroll: never scrolled back under it, said plainly; COMPLETE only when the place it was left at reads as it did there and nothing outside the lines changed",()=>{
                // 26 Nov: three reads of a longer invoice read every line across 2 screens, then found COSTAR's keyboard in the
                // line list (an empty line's empty Item box) and couldn't scroll back (day log why=focus_in_lines,not_back,changed):
                // the end check failed only because the list showed other lines than at the start. The helper still never
                // scrolls while COSTAR's keyboard is in the lines (2.9.18's rule, kept); a list left as it was read isn't "changed".
                // Here: 40 lines then 10 empty ones (50 rows: one scroll down shows lines 26-50); after that scroll COSTAR's
                // keyboard is in line 45's empty Item box. parts.Outside is FakeOutside (the made-up state but pos and v).
                Func<int,string,FakeScreen> list=delegate(int boxLine,string boxText) {
                    var f=new FakeScreen {Total=40,EmptyAfter=10,BarEnabled=true,BoxLine=boxLine,BoxText=boxText};f.Add(11,"1001");
                    f.AfterScroll=delegate(FakeScreen x) { x.Focus=BoxH; };
                    return f;
                };
                var parts=Parts();parts.Outside=FakeOutside;
                string note=" Note: "+InvoiceReading.LeftForKeyboard+".";
                Func<InvoiceOutcome,string> said=delegate(InvoiceOutcome x) { return x.Status+" (why="+String.Join(",",x.LogWhy.ToArray())+")"; };
                // Every time: scrolled down once and never again after the refusal, the list left at lines 26-50, said plainly.
                Action<string,FakeScreen,FakeGuard,InvoiceOutcome> leftThere=delegate(string what,FakeScreen f,FakeGuard g,InvoiceOutcome x) {
                    Check(x.Read!=null,what+": no read: "+x.Status);
                    Check(f.Codes.SequenceEqual(new[]{InvoiceScreenRules.PageDown})&&x.Scrolls==1&&x.Pages==2,what+": not scrolled exactly once down: "+String.Join(",",f.Codes.Select(c=>c.ToString()).ToArray()));
                    Check(f.Pos==25&&x.LeftPos==25&&g.Began==1&&g.Ended==1,what+": not left at lines 26-50 (at "+f.Pos+", LeftPos "+x.LeftPos+"), or the input guard not begun and ended once");
                    Check(x.Warn==InvoiceReading.LeftForKeyboard&&x.Read.Problems.Contains(InvoiceReading.LeftForKeyboard)&&x.Status.EndsWith(note,StringComparison.Ordinal),what+": not said plainly: "+said(x));
                    Check(!x.Read.Problems.Any(p=>p.StartsWith("the lines did not come back",StringComparison.Ordinal)||p.Contains("left scrolled")),what+": said as before: "+String.Join(" | ",x.Read.Problems.ToArray()));
                };
                // (a) The lines shown at the end read as the screen read there while paging, nothing outside them changed: COMPLETE.
                var a=list(45,"");var guard=new FakeGuard();
                var o=Run(a,"",guard,parts);
                leftThere("(a)",a,guard,o);
                Check(o.Complete&&o.Read.Lines.Count==40&&o.Status==InvoicePreview.ReadComplete+note,"(a) left as read: "+said(o));
                Check(o.LogWhy.SequenceEqual(new[]{"focus_in_lines","not_back","left_as_read"})&&!o.LogWhy.Contains("changed"),"(a) logged: "+said(o));
                // The same wherever in the lines COSTAR's keyboard went: a filled line's Item box (line 30), line 45's number
                // label, its panel, the line grid itself.
                var places=new[]{new KeyValuePair<int,long>(30,BoxH),new KeyValuePair<int,long>(45,LabelH),new KeyValuePair<int,long>(45,PanelH),new KeyValuePair<int,long>(45,GridH)};
                foreach(var place in places) {
                    var f=list(place.Key,"");long at=place.Value;f.AfterScroll=delegate(FakeScreen x) { x.Focus=at; };guard=new FakeGuard();
                    string what="(a) the keyboard on "+(at==BoxH?"line 30's Item box":at==LabelH?"line 45's number":at==PanelH?"line 45's panel":"the line grid");
                    o=Run(f,"",guard,parts);leftThere(what,f,guard,o);
                    Check(o.Complete&&o.LogWhy.SequenceEqual(new[]{"focus_in_lines","not_back","left_as_read"}),what+": "+said(o));
                }
                // (b) A header box changed meanwhile (outside the lines): INCOMPLETE, changed while it was read.
                var b=list(45,"");b.AfterScroll=delegate(FakeScreen x) { x.Focus=BoxH;x.Header="CHANGED"; };guard=new FakeGuard();
                o=Run(b,"",guard,parts);leftThere("(b)",b,guard,o);
                Check(!o.Complete&&o.Status.Contains(InvoiceReading.ChangedWhileRead)&&o.Read.ReadAgain==InvoiceReading.ChangedWhileRead&&o.LogWhy.SequenceEqual(new[]{"focus_in_lines","not_back","changed"}),"(b) a header box changed: "+said(o));
                // (c) The lines shown at the end aren't the page read there: typed into once the keyboard was there (every line
                // shown reads differently from then on) ...
                var typedIn=list(45,"");typedIn.FocusAsked=delegate(FakeScreen x) { if(x.Focus==BoxH) x.Version=1; };guard=new FakeGuard();
                o=Run(typedIn,"",guard,parts);leftThere("(c)",typedIn,guard,o);
                Check(!o.Complete&&o.Status.Contains(InvoiceReading.ChangedWhileRead)&&o.LogWhy.SequenceEqual(new[]{"focus_in_lines","not_back","changed"}),"(c) the lines read differently at the end: "+said(o));
                // ... or the list moved a line up in COSTAR meanwhile (the helper sent nothing more).
                var moved=list(45,"");moved.FocusAsked=delegate(FakeScreen x) { if(x.Focus==BoxH&&x.Pos==25) x.Pos=24; };
                o=Run(moved,"",new FakeGuard(),parts);
                Check(o.Read!=null&&!o.Complete&&moved.Codes.Count==1&&moved.Pos==24&&o.LeftPos==25&&o.Warn==InvoiceReading.LeftForKeyboard&&o.Status.Contains(InvoiceReading.ChangedWhileRead)&&
                    o.LogWhy.SequenceEqual(new[]{"focus_in_lines","not_back","changed"}),"(c) the list moved meanwhile: "+said(o)+" (at "+moved.Pos+")");
                // (d) No Outside (as 2.9.18), or one that finds no line grid (the live one, on this made-up screen): changed, as 2.9.18.
                var live=Parts();live.Outside=InvoiceReader.FingerprintOutsideLines;
                Check(InvoiceReader.FingerprintOutsideLines(list(45,"").Snapshot(new IntPtr(11)),InvoiceReading.TextOf)==null,"the live Outside found a line grid on the made-up screen");
                foreach(var p in new[]{Parts(),live}) {
                    var d=list(45,"");guard=new FakeGuard();
                    string what="(d) "+(p.Outside==null?"no Outside":"the live Outside");
                    o=Run(d,"",guard,p);leftThere(what,d,guard,o);
                    Check(!o.Complete&&o.Status.Contains(InvoiceReading.ChangedWhileRead)&&o.LogWhy.SequenceEqual(new[]{"focus_in_lines","not_back","changed"}),what+": "+said(o));
                }
                // COSTAR's keyboard already in the lines before the first scroll (line 22's empty Item box; 20 lines filled of a
                // list of 50 rows): nothing scrolled at all, as 2.9.18.
                var start=new FakeScreen {Total=20,EmptyAfter=30,BarEnabled=true,BoxLine=22,Focus=BoxH};start.Add(11,"1001");guard=new FakeGuard();
                o=Run(start,"",guard,parts);
                Check(o.Read!=null&&!o.Complete&&start.Codes.Count==0&&guard.Began==0&&start.Pos==0&&o.LeftPos==-1&&o.Warn==null&&o.Status.Contains("lines 26+ could not be read: "+InvoiceReading.FocusInLines)&&
                    o.LogWhy.SequenceEqual(new[]{"focus_in_lines"}),"resting in line 22's empty Item box from the start: "+said(o));
            });
            // 2.9.19 (review 2): what was read before the input guard watched is read again once it watches; the end check
            // accepts a list left elsewhere only when COSTAR's keyboard kept it there; COSTAR's keyboard on a control made after
            // the last snapshot; a keyboard that can't be told while scrolling back; the day log's note for a complete read.
            Case("Invoice (2.9.19): the invoice read again once the input guard watches, before any scroll: a header box or the first screen's lines changed while it began: nothing scrolled, INCOMPLETE, changed before its lines were scrolled; unchanged: read as before",()=>{
                // Review 2: a change made before the guard watched (from then on anyone using the PC stops the read) would be
                // missed by the end check for a list COSTAR keeps from being scrolled back (LeftAsRead compares the place it was
                // left at and everything outside the lines, not the first screen). The 26 Nov set-up of the case above: 40 lines
                // then 10 empty; COSTAR's keyboard would go into line 45's empty Item box after the first scroll.
                var parts=Parts();parts.Outside=FakeOutside;
                foreach(int startPos in new[]{0,25}) foreach(bool header in new[]{true,false}) {
                    var f=new FakeScreen {Total=40,EmptyAfter=10,BarEnabled=true,BoxLine=45,Pos=startPos};f.Add(11,"1001");
                    f.AfterScroll=delegate(FakeScreen x) { x.Focus=BoxH; };
                    var g=new FakeGuard();int began=0;
                    // Every line read differently from then on (the made-up page's v): as a line of the first screen changed.
                    g.OnBegin=delegate { began++;if(header) f.Header="CHANGED"; else f.Version=1; };
                    var o=Run(f,"",g,parts);
                    string what=(header?"a header box":"the first screen's lines")+" changed while the guard began (the list showing from line "+(startPos+1)+")";
                    string reason=(startPos==0?"lines 26+ could not be read: ":"some lines could not be read: ")+InvoiceReading.ChangedBeforeScroll;
                    Check(began==1&&g.Began==1&&g.Ended==1,what+": the guard not begun and ended once ("+began+", "+g.Began+", "+g.Ended+")");
                    Check(f.Codes.Count==0&&o.Scrolls==0&&o.Pages==1&&f.Pos==startPos&&o.LeftPos==-1&&!o.LeftForKeyboard&&o.Warn==null,what+": scrolled ("+f.Codes.Count+" scrolls): "+Told(o));
                    Check(o.Read!=null&&!o.Complete&&o.Read.LinesWhy==reason&&o.Status.Contains(reason),what+": not INCOMPLETE for it: "+Told(o));
                    Check(o.LogWhy.Count>0&&o.LogWhy.All(c=>c=="changed"),what+": logged "+Told(o));
                }
                // Unchanged while the guard began (or only COSTAR's keyboard moved, to a box outside the lines): as the case above.
                foreach(bool moved in new[]{false,true}) {
                    var f=new FakeScreen {Total=40,EmptyAfter=10,BarEnabled=true,BoxLine=45};f.Add(11,"1001");
                    f.AfterScroll=delegate(FakeScreen x) { x.Focus=BoxH; };
                    var g=new FakeGuard();int began=0;g.OnBegin=delegate { began++;if(moved) f.Focus=StateH; };
                    var o=Run(f,"",g,parts);
                    Check(began==1&&o.Complete&&o.Read.Lines.Count==40&&f.Codes.SequenceEqual(new[]{InvoiceScreenRules.PageDown})&&o.LeftPos==25&&o.LeftForKeyboard&&
                        o.LogWhy.SequenceEqual(new[]{"focus_in_lines","not_back","left_as_read"}),"unchanged while the guard began"+(moved?" (the keyboard moved to a header box)":"")+": "+Told(o));
                }
                // 60 lines, nothing changed while the guard began: exactly as without the second look.
                var plain=new FakeScreen {Total=60,BarEnabled=true};plain.Add(11,"1001");
                var hooked=new FakeScreen {Total=60,BarEnabled=true};hooked.Add(11,"1001");
                var hg=new FakeGuard();int hb=0;hg.OnBegin=delegate { hb++; };
                var po=Run(plain,"",new FakeGuard());var ho=Run(hooked,"",hg);
                Check(hb==1&&po.Complete&&ho.Complete&&ho.Status==po.Status&&ho.Review==po.Review&&hooked.Codes.SequenceEqual(plain.Codes)&&hooked.Pos==0&&ho.LogWhy.Count==0,"60 lines, nothing changed: not read as before: "+Told(ho));
            });
            Case("Invoice (2.9.19): the end check accepts a line list left where it was read only when COSTAR's keyboard kept it there; the scroll back refused by a person, Stop, a window over the invoice, a scroll COSTAR didn't take, a position that didn't move or a keyboard that couldn't be told: the read stays changed",()=>{
                var parts=Parts();parts.Outside=FakeOutside;
                // The 26 Nov set-up: 40 lines then 10 empty; one scroll down shows lines 26-50, every line is read; then the scroll
                // back is refused, each time for another reason. The screen ends as it does when the keyboard kept it there.
                Func<FakeScreen> list=delegate { var x=new FakeScreen {Total=40,EmptyAfter=10,BarEnabled=true,BoxLine=45};x.Add(11,"1001");return x; };
                var keyed=list();keyed.AfterScroll=delegate(FakeScreen x) { x.Focus=BoxH; };
                var k=Run(keyed,"",new FakeGuard(),parts);
                Check(k.Complete&&k.LeftForKeyboard&&k.LeftPos==25&&keyed.Pos==25&&k.Warn==InvoiceReading.LeftForKeyboard&&k.LogWhy.SequenceEqual(new[]{"focus_in_lines","not_back","left_as_read"}),"the keyboard in the lines: "+Told(k));
                string pageWhy;var keyedEnd=keyed.Snapshot(new IntPtr(11));
                string endOutside=FakeOutside(keyedEnd,InvoiceReading.TextOf),endPage=InvoiceReading.PageKey(FakePage(keyedEnd,InvoiceReading.TextOf,out pageWhy));
                Action<string,FakeGuard,Action<FakeScreen,InvoiceRun>,string[],string> refusedBack=delegate(string what,FakeGuard g,Action<FakeScreen,InvoiceRun> set,string[] want,string words) {
                    var f=list();var run=new InvoiceRun(null,"",f,g,parts);if(set!=null) set(f,run);run.Run();var o=run.Outcome;
                    Check(!run.Running&&o!=null&&o.Read!=null,what+": no read: "+Told(o));
                    // Every line read, the list left at lines 26-50, the screen there reading as the keyboard case's.
                    Check(o.Read.Lines.Count==40&&f.Codes.Count>=1&&f.Codes.Count<=2&&f.Codes[0]==InvoiceScreenRules.PageDown&&f.Codes.Skip(1).All(c=>c==InvoiceScreenRules.PageUp)&&
                        f.Pos==25&&o.LeftPos==25&&g.Began==1&&g.Ended==1,what+": not read and left at lines 26-50 (at "+f.Pos+", "+f.Codes.Count+" scrolls): "+Told(o));
                    var end=f.Snapshot(new IntPtr(11));string endWhy;
                    Check(FakeOutside(end,InvoiceReading.TextOf)==endOutside&&InvoiceReading.PageKey(FakePage(end,InvoiceReading.TextOf,out endWhy))==endPage,what+": the end doesn't read as where the keyboard case left it");
                    Check(!o.LeftForKeyboard&&o.Warn!=null&&o.Warn!=InvoiceReading.LeftForKeyboard&&o.Warn.StartsWith("the lines did not come back to where they were (",StringComparison.Ordinal)&&o.Warn.Contains(words),what+": not said as its own reason: "+Told(o));
                    Check(!o.Complete&&o.Read.ReadAgain==InvoiceReading.LeftNotChecked&&o.Status.Contains(InvoiceReading.LeftNotChecked)&&!o.Status.Contains(InvoiceReading.ChangedWhileRead)&&o.Status.EndsWith(" Note: "+o.Warn+".",StringComparison.Ordinal)&&
                        !o.Status.Contains(InvoiceReading.LeftForKeyboard),what+": not INCOMPLETE, left unchecked: "+Told(o));
                    Check(o.LogWhy.SequenceEqual(want)&&!o.LogWhy.Contains("left_as_read"),what+": logged "+Told(o));
                };
                refusedBack("someone used the PC",new FakeGuard {PersonAfter=1},null,new[]{"person","not_back","left_unchecked"},"someone used the PC");
                refusedBack("Stop pressed",new FakeGuard(),delegate(FakeScreen x,InvoiceRun r) { x.AfterScroll=delegate(FakeScreen y) { r.Cancel=true; }; },new[]{"stopped","not_back","left_unchecked"},"Stop was pressed");
                // A window over the invoice when the scroll back is due, gone by the end (so the end is read).
                refusedBack("a window over the invoice",new FakeGuard(),delegate(FakeScreen x,InvoiceRun r) {
                    int asked=0;
                    x.AfterScroll=delegate(FakeScreen y) { y.OverIt[11]=new List<string>{"Notes"}; };
                    x.OverAsked=delegate(FakeScreen y) { if(y.OverIt.ContainsKey(11)&&++asked>1) y.OverIt.Remove(11); };
                },new[]{"over","not_back","left_unchecked"},"something is open over the invoice");
                refusedBack("a scroll COSTAR didn't take",new FakeGuard(),delegate(FakeScreen x,InvoiceRun r) { x.AfterScroll=delegate(FakeScreen y) { y.Refuses=true; }; },new[]{"scroll_refused","not_back","left_unchecked"},"COSTAR didn't take the scroll");
                refusedBack("a position that didn't move",new FakeGuard(),delegate(FakeScreen x,InvoiceRun r) { x.AfterScroll=delegate(FakeScreen y) { y.Stuck=true; }; },new[]{"not_back","left_unchecked"},"the scroll position did not move");
                refusedBack("where the keyboard is couldn't be told",new FakeGuard(),delegate(FakeScreen x,InvoiceRun r) { x.AfterScroll=delegate(FakeScreen y) { y.Focus=-1; }; },new[]{"focus_unknown","not_back","left_unchecked"},InvoiceReading.CouldntTellAfterScroll);
                // The window still over the invoice at the end: the end isn't read at all (as before), never left_as_read.
                var over=list();over.AfterScroll=delegate(FakeScreen y) { y.OverIt[11]=new List<string>{"Notes"}; };
                var ov=Run(over,"",new FakeGuard(),parts);
                Check(ov.Read!=null&&!ov.Complete&&!ov.LeftForKeyboard&&ov.LeftPos==25&&ov.Read.ReadAgain==InvoiceReading.EndNotRead&&ov.LogWhy.SequenceEqual(new[]{"over","not_back","end_not_read"})&&
                    ov.Read.Problems.Contains("something was open over the invoice in COSTAR while its lines were scrolled (Notes)"),"a window still over the invoice at the end: "+Told(ov));
            });
            Case("Invoice (2.9.19): COSTAR's keyboard moving onto a control made after the last snapshot (while the list is scrolled back, or on the way to the top of a list left scrolled down) is looked up in a new snapshot: in the lines, the next scroll is refused",()=>{
                int PD=InvoiceScreenRules.PageDown,PU=InvoiceScreenRules.PageUp;
                // (a) Scrolled back: 80 lines (0, 25, 50, 55), back a page to 30; then COSTAR makes line 40's panel, number and
                // Item box (in no snapshot before) and puts its keyboard in that box: the next scroll back is refused.
                var back=new FakeScreen {Total=80,BarEnabled=true};back.Add(11,"1001");int madeAt=-1;
                back.AfterScroll=delegate(FakeScreen x) { if(madeAt<0&&x.Codes[x.Codes.Count-1]==PU) { madeAt=x.Snapshots;x.BoxLine=40;x.Focus=BoxH; } };
                var o=Run(back,"",new FakeGuard());
                Check(back.Codes.SequenceEqual(new[]{PD,PD,PD,PU})&&o.Scrolls==4&&back.Pos==30,"(a) not refused after the first page back: "+String.Join(",",back.Codes.Select(c=>c.ToString()).ToArray())+" (at "+back.Pos+")");
                Check(madeAt>0&&back.Snapshots>madeAt,"(a) no new snapshot after the control was made");
                Check(o.Read!=null&&!o.Complete&&o.LeftForKeyboard&&o.LeftPos==30&&o.Warn==InvoiceReading.LeftForKeyboard&&o.Status.Contains(InvoiceReading.ChangedWhileRead)&&
                    o.LogWhy.SequenceEqual(new[]{"focus_in_lines","not_back","changed"}),"(a) said or logged: "+Told(o));
                // (b) On the way to the top: the list left showing lines 51-75; a page up to 26-50, then COSTAR makes line 30's
                // controls and puts its keyboard in its Item box: the next page up is refused, the list left there.
                var top=new FakeScreen {Total=80,BarEnabled=true,Pos=50};top.Add(11,"1001");
                top.AfterScroll=delegate(FakeScreen x) { if(x.Codes.Count==1) { x.BoxLine=30;x.Focus=BoxH; } };
                o=Run(top,"",new FakeGuard());
                Check(top.Codes.SequenceEqual(new[]{PU})&&top.Pos==25,"(b) not refused after the first page up: "+String.Join(",",top.Codes.Select(c=>c.ToString()).ToArray())+" (at "+top.Pos+")");
                Check(o.Read!=null&&!o.Complete&&!o.LeftForKeyboard&&o.LeftPos==25&&o.Status.Contains("some lines could not be read: "+InvoiceReading.FocusInLines)&&o.Warn!=null&&o.Warn.Contains("("+InvoiceReading.KeyboardInLines+")")&&
                    o.LogWhy.SequenceEqual(new[]{"focus_in_lines","not_scrolled_back","left_unchecked"}),"(b) said or logged: "+Told(o));
                // (c) The keyboard on a control no snapshot holds (nor the new one): a new snapshot before each later scroll,
                // then scrolled as usual; on the invoice window itself: no new snapshot at all.
                var plain=new FakeScreen {Total=80,BarEnabled=true};plain.Add(11,"1001");var po=Run(plain,"",new FakeGuard());
                foreach(long at in new long[]{9999,11}) {
                    var f=new FakeScreen {Total=80,BarEnabled=true};f.Add(11,"1001");long focus=at;
                    f.AfterScroll=delegate(FakeScreen x) { x.Focus=focus; };
                    o=Run(f,"",new FakeGuard());
                    int extra=at==11?0:plain.Codes.Count-1;
                    Check(po.Complete&&o.Complete&&o.Status==po.Status&&f.Codes.SequenceEqual(plain.Codes)&&f.Pos==0&&f.Snapshots-plain.Snapshots==extra,
                        "(c) the keyboard on "+(at==11?"the invoice window":"a control in no snapshot")+": "+Told(o)+" ("+(f.Snapshots-plain.Snapshots)+" more snapshots, expected "+extra+")");
                }
                // (d) Before the first scroll: COSTAR makes line 22's controls after the first snapshot (20 lines filled of 50
                // rows) and its keyboard is in that empty Item box: the check before the input lock looks in a new snapshot
                // too, so nothing is scrolled and the lock isn't even taken.
                var early=new FakeScreen {Total=20,EmptyAfter=30,BarEnabled=true};early.Add(11,"1001");bool made=false;
                early.FocusAsked=delegate(FakeScreen x) { if(!made) { made=true;x.BoxLine=22;x.Focus=BoxH; } };
                var eg=new FakeGuard();o=Run(early,"",eg);
                Check(made&&o.Read!=null&&!o.Complete&&early.Codes.Count==0&&eg.Began==0&&o.LeftPos==-1&&o.Warn==null&&o.Status.Contains("lines 26+ could not be read: "+InvoiceReading.FocusInLines)&&
                    o.LogWhy.SequenceEqual(new[]{"focus_in_lines"}),"(d) the keyboard in a box made after the first snapshot, before any scroll: "+Told(o)+" (input lock taken "+eg.Began+" times)");
            });
            Case("Invoice (2.9.19): where COSTAR's keyboard is can't be told while the list is scrolled back (or the new snapshot to look it up isn't answered): not said as the keyboard in the lines, logged focus_unknown, the read stays changed",()=>{
                var parts=Parts();parts.Outside=FakeOutside;
                foreach(bool unanswered in new[]{false,true}) {
                    var f=new FakeScreen {Total=40,EmptyAfter=10,BarEnabled=true,BoxLine=45};f.Add(11,"1001");bool armed=false,thrown=false;
                    if(!unanswered) f.AfterScroll=delegate(FakeScreen x) { x.Focus=-1; };
                    else {
                        // The keyboard on a control no snapshot holds; the new snapshot taken to look it up isn't answered (once).
                        f.AfterScroll=delegate(FakeScreen x) { x.Focus=9999; };
                        f.FocusAsked=delegate(FakeScreen x) { if(x.Focus==9999) armed=true; };
                        f.SnapshotAsked=delegate(FakeScreen x) { if(armed&&!thrown) { thrown=true;throw new InvalidOperationException("COSTAR isn't answering (the invoice may still be loading)."); } };
                    }
                    var g=new FakeGuard();var o=Run(f,"",g,parts);
                    string what=unanswered?"the new snapshot not answered":"focus -1";
                    Check(o.Read!=null&&f.Codes.SequenceEqual(new[]{InvoiceScreenRules.PageDown})&&f.Pos==25&&o.LeftPos==25&&g.Ended==1&&(!unanswered||thrown),what+": not stopped at lines 26-50: "+Told(o));
                    Check(!o.LeftForKeyboard&&o.Warn!=InvoiceReading.LeftForKeyboard&&o.Warn=="the lines did not come back to where they were ("+InvoiceReading.CouldntTellAfterScroll+")",what+": not said as can't be told: "+Told(o));
                    Check(o.LogWhy.SequenceEqual(new[]{"focus_unknown","not_back","left_unchecked"})&&!o.LogWhy.Contains("focus_in_lines"),what+": logged "+Told(o));
                    Check(!o.Complete&&o.Read.ReadAgain==InvoiceReading.LeftNotChecked&&o.Status.Contains(InvoiceReading.LeftNotChecked)&&o.Status.EndsWith(" Note: "+o.Warn+".",StringComparison.Ordinal)&&
                        !o.Status.Contains(InvoiceReading.LeftForKeyboard),what+": not INCOMPLETE, changed: "+Told(o));
                }
                // Can't be told while paging down (80 lines, after the first scroll): stopped there and left, said as can't be told.
                var paging=new FakeScreen {Total=80,BarEnabled=true};paging.Add(11,"1001");paging.AfterScroll=delegate(FakeScreen x) { x.Focus=-1; };
                var p=Run(paging,"",new FakeGuard(),parts);
                Check(p.Read!=null&&paging.Codes.Count==1&&p.LeftPos==25&&!p.LeftForKeyboard&&p.Warn!=null&&p.Warn.Contains("("+InvoiceReading.KeyboardUnknown+")")&&!p.Warn.Contains(InvoiceReading.KeyboardInLines)&&
                    p.LogWhy.SequenceEqual(new[]{"focus_unknown","not_scrolled_back","left_unchecked"})&&!p.Complete&&p.Status.Contains("lines 26+ could not be read: "+InvoiceReading.CouldntTellAfterScroll),"can't be told while paging down: "+Told(p));
            });
            Case("Invoice (2.9.19): the day log: a complete read that left the line list where COSTAR's keyboard kept it makes one note more (why=focus_in_lines,not_back,left_as_read left_pos=25), with no customer words",()=>{
                // The day log is off while the self-tests run (2.6.6: no made-up data in it): AppLog.Note then only counts what it
                // leaves out. So the notes one read makes are counted here, and what the note says is checked from what it is made
                // of (the read's log line, its codes, the place) and from InvoiceRun.Log's own source beside the helper.
                bool was=AppLog.Off;
                try {
                    AppLog.Off=true;
                    const string secret="JANE MOCKS 0400555111";
                    var parts=Parts();parts.Outside=FakeOutside;parts.LogLine=InvoicePreview.LogLine;
                    // Tried up to 3 times: a note from another thread meanwhile would count too.
                    Func<Func<FakeScreen>,int,InvoiceOutcome> notes=delegate(Func<FakeScreen> make,int want) {
                        InvoiceOutcome last=null;int got=-1;
                        for(int i=0;i<3&&got!=want;i++) { int before=AppLog.Skipped;last=Run(make(),"",new FakeGuard(),parts);got=AppLog.Skipped-before; }
                        Check(got==want,"one read made "+got+" notes, expected "+want+": "+Told(last));
                        return last;
                    };
                    // Made-up customer words in a header box (outside the lines).
                    Func<FakeScreen> left=delegate { var f=new FakeScreen {Total=40,EmptyAfter=10,BarEnabled=true,BoxLine=45,Header=secret};f.Add(11,"1001");f.AfterScroll=delegate(FakeScreen x) { x.Focus=BoxH; };return f; };
                    var o=notes(left,2);
                    Check(o.Complete&&o.LeftPos==25&&o.LogWhy.Distinct().SequenceEqual(new[]{"focus_in_lines","not_back","left_as_read"})&&o.LogWhy.All(c=>Regex.IsMatch(c,"^[a-z_]+$")),"left as read: "+Told(o));
                    string detail=parts.LogLine(o.Read)+" why="+String.Join(",",o.LogWhy.Distinct().ToArray())+" left_pos="+o.LeftPos.ToString(System.Globalization.CultureInfo.InvariantCulture);
                    Check(detail.StartsWith("invoice=1001 branch=1 lines=40 ",StringComparison.Ordinal)&&detail.Contains(" complete=yes ")&&detail.EndsWith(" why=focus_in_lines,not_back,left_as_read left_pos=25",StringComparison.Ordinal),"the note's words: "+detail);
                    foreach(var w in secret.Split(' ').Concat(new[]{"tyre","T26","T40"})) Check(detail.IndexOf(w,StringComparison.OrdinalIgnoreCase)<0,"the note holds a customer's or a line's words ("+w.Length+" characters)");
                    // A complete read with nothing to say: one note; an incomplete one: two (its codes in the incomplete note).
                    var c1=notes(delegate { var f=new FakeScreen {Total=60,BarEnabled=true,Header=secret};f.Add(11,"1001");return f; },1);
                    Check(c1.Complete&&c1.LogWhy.Count==0,"a complete read with nothing to say: "+Told(c1));
                    var c2=notes(delegate { var f=left();f.AfterScroll=delegate(FakeScreen x) { x.Focus=BoxH;x.Header="CHANGED"; };return f; },2);
                    Check(!c2.Complete&&c2.LogWhy.SequenceEqual(new[]{"focus_in_lines","not_back","changed"}),"changed: "+Told(c2));
                    // The note as InvoiceRun.Log writes it (the sources built with this EXE, beside the bin folder, when there).
                    string file=Path.Combine(Path.GetDirectoryName(typeof(InvoiceLiveChecks).Assembly.Location)??"","..","Source","InvoiceLive.cs");
                    if(File.Exists(file)) {
                        string text=File.ReadAllText(file).Replace("\r\n","\n");
                        int from=text.IndexOf("\n        void Log(InvoiceOutcome o,long ms) {\n",StringComparison.Ordinal),to=from<0?-1:text.IndexOf("\n        }\n",from+1,StringComparison.Ordinal);
                        Check(from>0&&to>from,"InvoiceRun.Log wasn't found in InvoiceLive.cs");
                        string log=text.Substring(from,to-from);
                        Check(log.Contains("\n                else if(o.LogWhy.Count>0) AppLog.Note(\"invoice_dry_run_note\",line+\" why=\"+String.Join(\",\",o.LogWhy.Distinct().ToArray())+\" left_pos=\"+o.LeftPos.ToString(System.Globalization.CultureInfo.InvariantCulture)+tail);\n"),
                            "InvoiceRun.Log no longer writes the note from the read's log line, its codes and the place only");
                        Check(Regex.Matches(log,@"AppLog\.Note\(").Count==4,"InvoiceRun.Log writes another note");
                    }
                } finally { AppLog.Off=was; }
            });
            Case("Invoice (2.9.21): a read that scrolls says to keep the mouse and keyboard still while it waits for nobody using the PC, then that it scrolls; the wait and the time before it go to the day log in numbers; the tab is told as soon as the read ends",()=>{
                var said=new List<string>();int saidAtBegin=-1;
                var g=new FakeGuard();g.OnBegin=delegate { saidAtBegin=said.Count;Thread.Sleep(120); };
                var screen=new FakeScreen {Total=60,BarEnabled=true};screen.Add(11,"1001");
                var o=InvoiceReading.ReadWindow(screen,new IntPtr(11),"",null,g,Parts(),said.Add);
                const string still="Keep the mouse and keyboard still for a moment: the helper scrolls COSTAR's line list to read every line (read only), at once if nothing was touched since the click on Read, else once nobody has used the PC for 3 s ...";
                Check(InvoiceReading.StillLine==still,"the line said before the wait changed: "+InvoiceReading.StillLine);
                int keep=said.IndexOf(still),scroll=said.IndexOf("Scrolling COSTAR's line list to read every line (nothing else is touched) ...");
                Check(o.Complete&&g.Began==1&&keep>=0&&saidAtBegin==keep+1&&scroll>keep,"not said before the wait, or the scroll not said after it: "+String.Join(" | ",said.ToArray()));
                Check(!said.Any(x=>x.Contains("more than 25 lines")),"still says the invoice has more than 25 lines");
                Check(o.QuietWaitMs>=100&&o.QuietWaitMs<5000&&o.BeforeWaitMs>=0&&o.BeforeWaitMs<5000,"the wait's times: "+o.BeforeWaitMs+" / "+o.QuietWaitMs);
                // A read that doesn't scroll waits for nothing and logs no wait; one the guard refused logs how long it waited.
                var small=new FakeScreen {Total=20};small.Add(11,"1001");
                var s=InvoiceReading.ReadWindow(small,new IntPtr(11),"",null,new FakeGuard(),Parts(),null);
                Check(s.Complete&&s.QuietWaitMs==-1&&s.BeforeWaitMs==-1,"20 lines: "+s.QuietWaitMs);
                var busyPc=new FakeScreen {Total=60,BarEnabled=true};busyPc.Add(11,"1001");
                var r=InvoiceReading.ReadWindow(busyPc,new IntPtr(11),"",null,new FakeGuard {Refuse="someone kept using the PC, so the line list wasn't scrolled"},Parts(),null);
                Check(!r.Complete&&r.QuietWaitMs>=0&&r.LogWhy.Contains("not_scrolled")&&busyPc.Codes.Count==0,"refused: "+Told(r));
                // The run calls Finished once, after Running is false and the outcome is there.
                var run=new InvoiceRun(null,"",screen,new FakeGuard(),Parts());int calls=0;bool ranAfter=false;
                run.Finished=delegate { calls++;ranAfter=!run.Running&&run.Outcome!=null; };
                run.Run();
                Check(calls==1&&ranAfter,"Finished: "+calls+" call(s), after the end: "+ranAfter);
                var throws=new InvoiceRun(null,"",screen,new FakeGuard(),Parts());throws.Finished=delegate { throw new InvalidOperationException("x"); };
                throws.Run();Check(!throws.Running&&throws.Outcome!=null,"a Finished that throws stopped the run");
                // The day log's tail: numbers and fixed words only, and only when the read got to the wait.
                string file=Path.Combine(Path.GetDirectoryName(typeof(InvoiceLiveChecks).Assembly.Location)??"","..","Source","InvoiceLive.cs");
                if(File.Exists(file)) {
                    string text=File.ReadAllText(file).Replace("\r\n","\n");
                    Check(text.Contains("string tail=\" pages=\"+o.Pages+\" scrolls=\"+o.Scrolls+\" ms=\"+ms+(o.QuietWaitMs>=0?\" before_wait_ms=\"+o.BeforeWaitMs+\" quiet=\"+(o.QuietSkipped?\"skipped\":\"waited\")+\" quiet_wait_ms=\"+o.QuietWaitMs:\"\");"),"the day log's tail isn't numbers and fixed words only");
                }
            });
            Case("Invoice (2.9.21, Tommy 27 Nov: \"publish after the skip 3s\"): nothing touched since the click on Read: no 3 s wait, the click itself never stops the read, any newer input does; a newer input before the scroll, no click tick or an unreadable one: the 3 s rule exactly as before; the tick is taken first in StartInvoiceRead and handed to the guard; the allow-list names it; quiet=skipped / waited",()=>{
                // The real InvoiceInputGuard with made-up input: tick is Windows' last input tick (null: unreadable); active
                // answers the old quiet check (Native.UserActiveWithin) and keeps what it was asked; no real input lock.
                const int click=500000;
                int? tick=click;bool tickRead=false;Func<int,bool> active=null;
                var asked=new List<int>();var pauses=new List<int>();int locks=0,released=0;
                Action reset=delegate { tick=click;tickRead=false;asked.Clear();pauses.Clear();locks=0;released=0; };
                Func<int?,InvoiceInputGuard> make=delegate(int? clickedAt) {
                    var made=new InvoiceInputGuard(true,clickedAt);
                    made.Tick=delegate { tickRead=true;return tick; };
                    made.ActiveWithin=delegate(int ms) { asked.Add(ms);return active(ms); };
                    made.Pause=delegate(int ms) { pauses.Add(ms); };
                    made.Lock=delegate { locks++;return new FakeLock(delegate { released++; }); };
                    return made;
                };
                const string person="someone used the PC while the line list was being scrolled";
                // (a) Nothing since the click: Begin doesn't wait (the quiet check, which would count the click just made, isn't
                // even asked). Problem: nothing while the click is the last input, then the person once anything newer comes.
                reset();active=delegate(int ms) { return true; };
                var g=make(click);g.Begin(null);
                Check(g.Skipped&&tickRead&&asked.Count==0&&pauses.Count==0&&locks==1,"(a) nothing since the click: Begin waited (quiet check asked "+asked.Count+" times, "+pauses.Count+" pauses, lock taken "+locks+" times)");
                for(int i=0;i<3;i++) Check(g.Problem()==null,"(a) the click itself stopped a read that skipped the wait");
                Check(asked.Count==0,"(a) Problem used the 3 s rule's look-back after a skip (it would count the click)");
                tick=click+16;
                Check(g.Problem()==person,"(a) an input after the click didn't stop the read");
                tick=click;Check(g.Problem()==person,"(a) a stopped read went on");
                g.End();Check(released==1,"(a) the input lock wasn't let go once: "+released);
                // After a skip, a last input that can't be read stops the read too (as UserActiveWithin does).
                reset();active=delegate(int ms) { return true; };
                var gu=make(click);gu.Begin(null);tick=null;
                Check(gu.Skipped&&gu.Problem()==person,"(a) the last input unreadable after a skip didn't stop the read");gu.End();
                // (b) A newer input before Begin (a mouse move after the click): the 3 s rule as before, the quiet check asked
                // for 3000 ms every 200 ms while it says active; after it, Problem is the old rule (the watch and the 1 s
                // before it), whatever the tick says.
                reset();tick=click+16;int busy=3;active=delegate(int ms) { return busy-->0; };
                var sinceBegin=Stopwatch.StartNew();
                var gb=make(click);gb.Begin(null);
                Check(!gb.Skipped&&asked.Count==4&&asked.All(ms=>ms==3000)&&pauses.Count==3&&pauses.All(ms=>ms==200)&&locks==1,"(b) a newer input before the scroll: not the 3 s rule (skipped "+gb.Skipped+", asked "+String.Join(",",asked.Select(x=>x.ToString()).ToArray())+", "+pauses.Count+" pauses)");
                asked.Clear();active=delegate(int ms) { return false; };tick=click+999;
                // The look-back grows with the watch (review): 60 ms after Begin it is at least 1060 ms, and no more than the
                // time since just before Begin plus 1000.
                Thread.Sleep(60);
                long most=sinceBegin.ElapsedMilliseconds+1000;
                Check(gb.Problem()==null&&asked.Count==1&&asked[0]>=1060&&asked[0]<=most+5,"(b) after the wait Problem isn't the old rule, the watch's time + 1000 (asked "+String.Join(",",asked.Select(x=>x.ToString()).ToArray())+", at most "+most+")");
                active=delegate(int ms) { return true; };
                Check(gb.Problem()==person,"(b) someone at the PC after the wait didn't stop the read");gb.End();
                // (c) No click tick (every read but the one StartInvoiceRead starts): the tick isn't even read.
                reset();tick=click;busy=2;active=delegate(int ms) { return busy-->0; };
                var gc=make(null);gc.Begin(null);
                Check(!gc.Skipped&&!tickRead&&asked.Count==3&&pauses.Count==2,"(c) no click tick: not the 3 s rule (skipped "+gc.Skipped+", tick read "+tickRead+", asked "+asked.Count+")");
                asked.Clear();active=delegate(int ms) { return false; };
                Check(gc.Problem()==null&&!tickRead&&asked.Count==1&&asked[0]>=1000,"(c) no click tick: Problem isn't the old rule");gc.End();
                // (d) The tick can't be read when Begin starts: the 3 s rule.
                reset();tick=null;busy=1;active=delegate(int ms) { return busy-->0; };
                var gd=make(click);gd.Begin(null);
                Check(!gd.Skipped&&tickRead&&asked.Count==2&&pauses.Count==1,"(d) unreadable tick: not the 3 s rule");gd.End();
                // Stop while it waits, as before (the lock not taken); the guard without the person check (the e2e harness)
                // neither reads the tick nor waits.
                reset();tick=click+1;active=delegate(int ms) { return true; };
                var gs=make(click);string stopped=null;
                try { gs.Begin(delegate { return true; }); } catch(InvalidOperationException e) { stopped=e.Message; }
                Check(stopped=="Stop was pressed"&&locks==0,"Stop while waiting: "+(stopped??"not stopped"));
                reset();tick=click+1;active=delegate(int ms) { return true; };
                var gh=new InvoiceInputGuard(false,click);gh.Tick=delegate { tickRead=true;return tick; };gh.ActiveWithin=delegate(int ms) { asked.Add(ms);return true; };
                gh.Lock=delegate { locks++;return new FakeLock(delegate { released++; }); };gh.Pause=delegate(int ms) { pauses.Add(ms); };
                gh.Begin(null);
                Check(!gh.Skipped&&!tickRead&&asked.Count==0&&gh.Problem()==null&&locks==1,"the guard without the person check changed");gh.End();
                // (e) A whole read of 60 lines (a made-up window) with nothing touched since the click, the old quiet check
                // saying "active" all along (the click was just now): read complete, scrolled and back, never waited (a
                // pause would throw), quiet skipped; a mouse move after the first scroll stops it before the next.
                reset();active=delegate(int ms) { return true; };
                var screen=new FakeScreen {Total=60,BarEnabled=true};screen.Add(11,"1001");
                var gw=make(click);gw.Pause=delegate(int ms) { throw new InvalidOperationException("the guard waited"); };
                var said=new List<string>();
                var o=InvoiceReading.ReadWindow(screen,new IntPtr(11),"",null,gw,Parts(),said.Add);
                Check(o.Complete&&o.Read.Lines.Count==60&&screen.Pos==0&&screen.Codes.Count>=2&&o.QuietSkipped&&o.QuietWaitMs>=0&&o.QuietWaitMs<2000&&!o.LogWhy.Contains("person")&&asked.Count==0&&released==1,
                    "(e) a whole read with nothing touched since the click: "+Told(o)+" (quiet check asked "+asked.Count+" times)");
                Check(said.Contains(InvoiceReading.StillLine)&&said.IndexOf(InvoiceReading.StillLine)<said.IndexOf("Scrolling COSTAR's line list to read every line (nothing else is touched) ..."),"(e) said: "+String.Join(" | ",said.ToArray()));
                reset();active=delegate(int ms) { return true; };
                var moved=new FakeScreen {Total=60,BarEnabled=true};moved.Add(11,"1001");moved.AfterScroll=delegate(FakeScreen x) { tick=click+31; };
                var gm=make(click);gm.Pause=delegate(int ms) { throw new InvalidOperationException("the guard waited"); };
                var m=InvoiceReading.ReadWindow(moved,new IntPtr(11),"",null,gm,Parts(),null);
                Check(!m.Complete&&m.QuietSkipped&&m.LogWhy.Contains("person")&&moved.Codes.Count==1&&released==1&&m.Status.Contains(person),"(e) a mouse move after the first scroll didn't stop the read: "+Told(m));
                // The same window with no click tick: the 3 s rule (two "active" answers, two pauses), then read; quiet waited.
                reset();int quietAfter=2;active=delegate(int ms) { return ms==3000&&quietAfter-->0; };
                var plain=new FakeScreen {Total=60,BarEnabled=true};plain.Add(11,"1001");
                var on=InvoiceReading.ReadWindow(plain,new IntPtr(11),"",null,make(null),Parts(),null);
                Check(on.Complete&&!on.QuietSkipped&&pauses.Count==2&&!tickRead&&asked.Where(ms=>ms!=3000).All(ms=>ms>=1000),"(e) no click tick: "+Told(on)+" ("+pauses.Count+" pauses)");
                // The outcome keeps what the guard did (the day log's quiet=skipped / quiet=waited), also when it then refused.
                var fs=new FakeScreen {Total=60,BarEnabled=true};fs.Add(11,"1001");
                var sk=InvoiceReading.ReadWindow(fs,new IntPtr(11),"",null,new FakeGuard {Skip=true},Parts(),null);
                var wt=InvoiceReading.ReadWindow(fs,new IntPtr(11),"",null,new FakeGuard(),Parts(),null);
                var rf=InvoiceReading.ReadWindow(fs,new IntPtr(11),"",null,new FakeGuard {Skip=true,Refuse="the input lock is held"},Parts(),null);
                Check(sk.Complete&&sk.QuietSkipped&&sk.QuietWaitMs>=0&&wt.Complete&&!wt.QuietSkipped&&wt.QuietWaitMs>=0&&!rf.Complete&&rf.QuietSkipped&&rf.LogWhy.Contains("not_scrolled"),
                    "the outcome doesn't keep whether the guard skipped the wait: "+Told(sk)+" / "+Told(wt)+" / "+Told(rf));
                // The live run hands the tick to a guard that watches the person; the 4-argument ReadWindow's guard has none.
                var live=new InvoiceRun(null,"",click).Guard as InvoiceInputGuard;
                Check(live!=null&&live.WatchesPerson&&live.Clicked==click,"the live run doesn't hand the click's tick to its guard");
                var none=new InvoiceRun(null,"",(int?)null).Guard as InvoiceInputGuard;
                Check(none!=null&&none.WatchesPerson&&!none.Clicked.HasValue,"the live run without a tick");
                // The allow-list (InvoiceSourceGuard; Build.ps1's is checked to be the same list by the e2e harness, check 12,
                // and Build.ps1 itself refuses an Invoice*.cs file that names a member its list lacks) names exactly this member.
                Check(InvoiceSourceGuard.Hits("int? clicked=Native.LastInputTick();").Count==0,"InvoiceSourceGuard's allow-list doesn't name Native.LastInputTick");
                Check(InvoiceSourceGuard.Hits("Nati"+"ve.LastInputTicks()").Count>0&&InvoiceSourceGuard.Hits("Nati"+"ve.LastInputSeen()").Count>0,"the allow-list lets in more than Native.LastInputTick");
                // StartInvoiceRead (InvoiceTab.cs beside the bin folder, when there): its first statement takes the tick, the run
                // is made with it, and the read's thread starts after; nothing else in InvoiceTab.cs takes it or makes a run.
                string tabFile=Path.Combine(Path.GetDirectoryName(typeof(InvoiceLiveChecks).Assembly.Location)??"","..","Source","InvoiceTab.cs");
                if(File.Exists(tabFile)) {
                    string tab=File.ReadAllText(tabFile).Replace("\r\n","\n");
                    int from=tab.IndexOf("\n        void StartInvoiceRead() {\n",StringComparison.Ordinal),to=from<0?-1:tab.IndexOf("\n        }\n",from+1,StringComparison.Ordinal);
                    Check(from>0&&to>from,"StartInvoiceRead wasn't found in InvoiceTab.cs");
                    var lines=tab.Substring(from,to-from).Split('\n').Select(l=>l.Trim()).Where(l=>l.Length>0&&!l.StartsWith("//",StringComparison.Ordinal)).ToList();
                    int took=lines.IndexOf("int? clicked=Native.LastInputTick();"),made=lines.IndexOf("var run=new InvoiceRun(coordinator,invoiceExpected.Text,clicked);"),started=lines.IndexOf("thread.Start();");
                    Check(took==1&&made>took&&started>made,"StartInvoiceRead doesn't take the tick first and hand it to the run before the thread starts (at "+took+", "+made+", "+started+")");
                    Check(Regex.Matches(tab,@"\bLastInputTick\b").Count==1&&Regex.Matches(tab,@"\bnew\s+InvoiceRun\s*\(").Count==1&&Regex.Matches(tab,@"\bclicked\s*=").Count==1,"InvoiceTab.cs takes the tick, sets it or makes a run elsewhere too");
                }
            });
        }
        sealed class FakeLock : IDisposable { readonly Action released;internal FakeLock(Action released) { this.released=released; } public void Dispose() { released(); } }
    }
}
