# Tempe COSTAR Helper — v2.9.2 — Wholesale Notes fix

Tommy, 4 Nov 02:14, after the 2.9.1 dry run: "Please fix this": the run stopped on an order where the customer's Notes came up right after a Point-of-sale Memo ("COSTAR showed a window over Order ... ("Notes") that the dry run doesn't answer").

2.9.2 is 2.9.1 plus this fix. Helper only.

## What's fixed

- **The customer's Notes coming up right after a memo stopped the run.** The dry run looked at the Notes the moment they appeared, while COSTAR was still making them (their OK not readable yet), and didn't know them. Now a window over the order that isn't read in full yet (no button, a button greyed or unreadable, a message's words unread) is looked at again until 5 seconds after it first showed; the Notes, once ready, get their OK as before. A window read in full that the dry run doesn't answer still stops it at once, nothing pressed in it. Just before an OK goes, the window is looked at once more: still the same, with nothing of COSTAR's over it.
- **"No card details" only from a whole, settled read of the Notes.** The Notes are read once COSTAR answers; a part COSTAR doesn't give, a list longer than the reader takes in, or no rows yet, is "can't tell" (the order is left alone); and "no" needs two reads half a second apart that agree.
- Everything else is as 2.9.1 (the stock read was right in the 4 Nov run: Sydney's numbers on every tyre line, "Would SELL" on 8 orders). Nothing is typed, sold or changed.

## Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.9.2.zip` to GitHub (the `helper` folder).
2. **RDP PC** and **desk PC:** the yellow line. The title says **2.9.2 - Wholesale Notes fix**.
3. Wholesale tab: run the dry run again and leave the PC alone until it's done (TEST-PLAN 2.9.2).

# Tempe COSTAR Helper — v2.9.1 — Wholesale stock fix

Tommy, 3 Nov 17:10, after the first dry run: "please review on the non stocking clearly tyres are available, or am i reading the reports wrong? but dry run looks solid".

2.9.1 is 2.9.0 plus this fix. Helper only.

## What's fixed

- **Every tyre came out NON-STOCKING in 2.9.0, so every order got CHECK STOCK.** COSTAR keeps a "NON-STOCKING!" label in every opened tyre line, hidden under the stock numbers (your 17:09 map shows the numbers over it); 2.9.0 took it as showing. Now **Sydney's "= Avail" number always wins**, and NON-STOCKING counts only when COSTAR really shows it (nothing over it). An empty "= Avail" with the label covered says "Stock not checked: ... is empty" instead of guessing.
- A tyre line's stock is read only while the line is open: a closed line is clicked open even if COSTAR kept its panel from before (COSTAR empties it when the line closes).
- Everything else is as 2.9.0: nothing is typed, sold or changed.

## Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.9.1.zip` to GitHub (the `helper` folder).
2. **RDP PC** and **desk PC:** the yellow line. The title says **2.9.1 - Wholesale stock fix**.
3. Wholesale tab: run the dry run again and leave the PC alone until it's done (TEST-PLAN 2.9.1).

# Tempe COSTAR Helper — v2.9.0 — Wholesale dry run

Tommy, 29 Oct: "ok this is now for wholesale order, we will do it slowly"; 2 Nov 20:47: "not yet, havent got the deal yet, but make it ready on the back end"; 3 Nov 12:48: "open order, check terms, check notes, check stock, if everything ok, sell and cancel, if not ok, put on comments", future ShipDates "leave it for now", "close equal to save", a new Discord channel, BUF / BUFF / WWW BUFFALO count; 14:51 the maps; 15:54 a NON-STOCKING tyre gets CHECK STOCK, the order's own tyres are in COSTAR's Commit (so they're added back), NO CARD DETAILS "yes please", and the dry run to try.

2.9.0 is 2.8.1 plus the first stage of the wholesale orders: a **dry run**. Helper only (no website files).

## What's new

- **Wholesale tab** (RDP helper, the last tab): **Check wholesale orders (dry run)** looks at COSTAR Sydney's wholesale orders and shows what the helper **would** do with each. **Nothing is typed, sold or changed.**
  - COSTAR Sydney (Branch 1) comes to the front; **Wholesale Order** is pressed in its left-hand menu; a search left on the list is cleared; **Search** is pressed.
  - The **BUF** orders (the order's own Ship Via) are listed, oldest first. Opened: those whose Comment is empty, WWW, BUF, BUFF or BUFFALO (or WWW with one of those) and whose ShipDate isn't after today. Any other Comment: someone is on it. A later ShipDate: left for now.
  - Each is opened from the list (as the phone's Repair Orders are) and its number checked; its pop-ups (the customer's **Notes**, a **Point-of-sale Memo**: only those two) get OK — the Notes are looked at first for **card details: yes or no only**, nothing else is kept; its Comment, Terms and lines are read.
  - When those are fine, each **tyre line is clicked open** to read **Sydney's stock**: one click into the line's words (a box nothing can be typed in), as you'd open it; **ThisBr = Avail** is read and **this order's own tyres are added back** (they're in COSTAR's Commit, so "= Avail" is what's left after this order); **NON-STOCKING!** means Sydney doesn't stock it. Then the order's number is clicked (so COSTAR leaves the last line) and **the order is read again**: if anything changed (a line's boxes, the Comment, Terms, the totals) or COSTAR opened another window, the dry run stops and **leaves the order open for you to check** (closing saves). Nothing is typed.
  - Then the order is closed as it was (closing saves, so only when it was read through, nobody used the PC and Stop wasn't pressed: otherwise it's left open for you, and the tab says whether its lines had been clicked).
  - At the end **Repair Order** is pressed, so COSTAR Sydney is back on Work-in-Progress for eBay orders.
  - What it would do: **sell** (Sell, then Cancel) when Terms are fine and every tyre has more than 4 in Sydney ("= Avail" plus this order's own: "= Avail" 2 and 4 on this order = 6, sells); add **CHECK STOCK** to the end of the Comment when a tyre has 4 or fewer that way, or is NON-STOCKING in Sydney; add **NO CARD DETAILS** for a CASH order without card details in the Notes; or **leave it** (unknown Terms, notes that couldn't be read, more lines than show, a tyre whose stock couldn't be read ...).
- **Map COSTAR screen:** a customer's name on COSTAR's Cashier window, and the words of a message box over COSTAR (a Point-of-sale Memo, for one), are now kept in a map as their length only, like every other customer word (2.8.1 kept them as words).
- It runs only on the button, takes COSTAR like an entry (eBay, phone and online orders wait), and stops if someone uses the PC, Stop / Stop all entry is pressed, or COSTAR shows anything else over an order. After a stop that wasn't a person's it puts COSTAR Sydney back on Work-in-Progress; otherwise the tab says to.

## Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.9.0.zip` to GitHub (the `helper` folder).
2. **RDP PC** and **desk PC:** the yellow line (or by themselves outside shop hours). The title says **2.9.0 - Wholesale dry run**.
3. Wholesale tab: press the button when nobody needs COSTAR Sydney for a few minutes (TEST-PLAN 2.9.0).

# Tempe COSTAR Helper — v2.8.1 — Tempe pickups by themselves

Tommy, 2 Nov: online orders should come in by themselves; 3 Nov 09:01: "Tempe pickups only"; 09:31: "tempe tyres is open 7 days"; 11:02: "Monday to Friday : 08:00 - 17:00, Saturday : 08:00 - 16:00, Sunday : 09:00 - 14:00".

2.8.1 is 2.8.0 plus this. Upload the helper **and** two website files: `testrun.html` (the Tempe Orders page) and `discord.js` (the Order Check board's Discord posts). Update the RDP helper and the desk PC (the yellow line, or by themselves after 18:30).

## What's new

- **Auto on the Tempe Orders page.** With **Auto: on**, every 3 minutes in shop hours (below) the page has Order Check read COSTAR afresh, reads the website's orders, and sends the helper every **Tempe pickup** for **today and tomorrow** that isn't in COSTAR yet. The helper enters them **by itself, one at a time**, whichever tab is showing: SHOP, the Customer Waiting times and closing when clean as in 2.8.0. Nothing goes through the clipboard any more for these, so your own copy and paste isn't touched.
- **Only Tempe pickups.** Deliveries and other stores' pickups are never sent by Auto: send those with **Send to COSTAR** as before. An order Auto can't make (a package to finish by hand, a service without a COSTAR code, a discount) isn't sent either: the page says why, and so does Discord, once.
- **Never twice.** An order is sent only when Order Check (read seconds before) doesn't list it and the helper doesn't know it. Before typing, the helper checks it again itself, on a read of COSTAR that **began after the order arrived and after the last entry finished**, with Search pressed (Order Check is asked for one), so whatever was typed meanwhile, by the helper or by a person, shows: its number as the PO# or in a comment means it's in COSTAR already. **Done already:** Order Check now remembers which online order each job carried for 30 days, so an order whose job has left Work-in-Progress (invoiced, or deleted) isn't entered again, nor is one the helper entered in the last 30 days. **Held for you:** a job with the same amount for that customer (a word of the name) or a walk-in, that isn't another online order: the page and Discord name it, and **Make it** sends it if it's new (another customer's job with the same amount doesn't hold it). An order you send yourself (Send to COSTAR, Make it) is left to the Online orders tab: once the tab has loaded it, it is yours and never entered by itself as well; if nobody loads it within 10 minutes (the Mobile jobs tab showing, say), Auto enters it after all, checked against COSTAR as any other, so it isn't left out. Make it / Make all missing skip what the helper has.
- **Waits for the right moment.** Like the eBay orders: COSTAR on Work-in-Progress, the selected COSTAR still the one picked, the old online-order helper closed, and nobody using this PC for a few seconds. Each order gets a fresh Repair Order (one open stays as it is). An order loaded by hand in the Online orders tab, its line of copied orders, or its branch question go first: the page's orders wait (it says why, and Discord does after 10 minutes). The Online orders tab has a **Clear** button for an order loaded there that you won't fill (Auto may then enter it, if it's a Tempe pickup not in COSTAR); one already entered, or loaded over 30 minutes ago, is put away by itself for the page's orders. Order Check's **Pause** holds Auto too (the page and the helper don't make it read). **Stop all** (or Ctrl+Alt+F10) pauses the page's orders too, until Resume. Only one helper on the RDP server takes the page's orders.
- **When one stops.** One that stopped before anything was typed is tried once more a minute later. Any other stop leaves that order for you, Discord says so, and the orders from the page **pause** until you click **Resume orders from the page** on the helper's Online orders tab (the stopped one stays as it is: finish it in COSTAR, or click Make it on the page).
- **Paired once.** The helper takes these orders only from a page it was paired with, and only from the page on GitHub: in the helper, Files & settings, Runs by itself, **Pair the Tempe Orders page...** shows a 6-digit code for 10 minutes; on the page click **Auto** and type it. The key stays in that Chrome, and the page talks only to that helper (another helper in another Windows session on the RDP server is left alone). Pairing again replaces it.
- **Switch:** Files & settings, Runs by itself, **Enter the Tempe pickups the Tempe Orders page sends by itself** (on). Auto on the page can be turned off at any time; the page then only sends with Send to COSTAR.
- **Open 7 days, with your hours.** Tempe is open Monday to Friday 8:00-17:00, Saturday 8:00-16:00, Sunday 9:00-14:00. The helper's shop hours run from an hour before opening to an hour and a half after closing (as 7:00-18:30 did around the weekdays): **Mon-Fri 7:00-18:30** (as before), **Sat 7:00-17:30**, **Sun 8:00-15:30**. Order Check reads COSTAR, the page's Auto sends, the board's Discord posts and the helpers' Discord watch run then (Sundays too), and updates install themselves only outside them. So an evening order for an early pickup tomorrow still goes in the day before (with Customer Waiting for 08:00-09:00), and tomorrow means tomorrow even when it's a Sunday.
- **Discord:** the orders from the page paused (an order stopped, or was being entered when the helper closed, or Stop all): at any hour, and again every hour in shop hours until Resume. In shop hours: the page hasn't checked in for 15 minutes (closed, or Chrome put it to sleep), the page has had trouble for 15 minutes (the website, Order Check), Auto switched off on the page, orders waiting in the helper for 10 minutes for something a person must sort out (again each hour), and, each kind in one message: the orders held for you, the ones entered but left open for checking (CHECK BY HAND; the phone's jobs wait while one is open), and the ones Auto couldn't send.

## Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.8.1.zip` to the `helper` folder, and `website/testrun.html` and `website/discord.js` to the top folder of the `tempe` repo.
2. **RDP PC** and **desk PC:** click the yellow line (or leave it: they update themselves after 18:30); the title says **2.8.1 - Tempe pickups by themselves**. Reload the Order Check board once.
3. **RDP helper**, Files & settings, Runs by itself: **Pair the Tempe Orders page...**. In Chrome on the RDP PC, reload the Tempe Orders page, click **Auto** and type the code. If Chrome asks whether the page may reach apps on this device, click **Allow**.
4. Keep the Tempe Orders page open in its own Chrome window. In Chrome's settings (Performance), add `tommyvenzin.github.io` to "Always keep these sites active", so Chrome doesn't put it to sleep.

## Check on the first orders

1. A Tempe pickup for today that isn't in COSTAR: within about 3 minutes the page says "1 sent to the helper now" and the helper enters it (the Online orders tab says "From the Tempe Orders page: ... Entering it by itself").
2. A Tempe pickup for tomorrow (Sunday on a Saturday): sent too. One for the day after: not yet (it goes the day before).
3. A delivery, or a Sydney pickup: never sent by Auto.
4. Turn Auto off on the page: nothing more is sent.

Self-tests: **147** helper groups (1 new: the page's orders, Tempe pickups only, the retry and the pause, pairing and the key, Order Check's freshness) + **16** Order Check groups (its server carries the page's requests to the helper). The page: 12 checks; end to end with the real Order Check server: 24.

---

# Tempe COSTAR Helper — v2.8.0 — Runs by itself

Tommy, 2 Nov 20:37: "I want it to be working by itself instead of doing things manually ... I just want it to be atleast 60-80% automatic"; 20:47: "we can start releasing it" and "Please put SHOP on online orders but dont tick customer waiting unless if it is for 14:00 - 16:00"; 20:58: "16:00 count, and make the 08:00 - 09:00 am for tomorrow aswell", a new Discord channel for the alerts, and yes to closing online orders that need no checking; 22:00: "Every pick up that is collect in store get shop, if it has delivery address it is DFE".

2.8.0 is 2.6.12 plus these. Helper only (no website files). It is 2.8.0, not 2.7.x: the RDP PC has the 2.7.0 background test build.

## What's new

- **Online orders: SHOP, DFE and Customer Waiting.** Every online pickup (collect in store, any store) gets Ship Via **SHOP** (before: only customers with a COSTAR customer number). Every delivery order (it has a delivery address) gets Ship Via **DFE** in its delivery panel, whatever the website lists. **Customer Waiting** is ticked only when the booking is **today 14:00-16:00** or the **next shop day 08:00-09:00** (both ends included; on a Saturday the next shop day is Monday). Delivery orders' Customer Waiting is unchanged. SHOP or the booking time (Time in) that COSTAR doesn't take, or a Customer Waiting tick that doesn't take or doesn't stay, is said under CHECK BY HAND and the Repair Order stays open; it never stops the order.
- **Online orders that need no checking close themselves.** When the final check passes (customer, every line, quantities, prices, the total) and nothing needs checking by hand, the Repair Order is closed and stays in Work-in-Progress, as eBay orders already are. One with something to check, or a package to finish by hand, stays open with the reason. Switch: Files & settings, Runs by itself.
- **Start with Windows** (both helpers): tick it and the helper starts when you sign in to Windows (it hands over to a newer installed version by itself, as a shortcut does; with accents in the Windows user name it starts the newest installed version).
- **Mobile turns itself back on.** If mobile was on when the helper closed (a restart, an update, Windows restarting), it comes back on by itself: about 20 s after the helper starts, or, when the helper started before COSTAR was opened, as soon as COSTAR is open (while no COSTAR is selected the helper looks for one every minute, and takes only the branch you used last, or the one mobile was on, never just any COSTAR that is open). Not while a phone job stopped part way needs you, another branch is selected, or the Online orders tab is showing (mobile is paused there; it comes on when you go to another tab). Stop all entry (or Ctrl+Alt+F10) keeps it off until you click Start / resume mobile, also while it is waiting to come back.
- **Updates install themselves outside shop hours** (shop hours: Monday to Saturday 7:00-18:30), only with nothing being entered or waiting in the Online orders tab and nobody having used that PC for 10 minutes. On the RDP PC, COSTAR is held for the update, so nothing starts meanwhile, and it waits while a phone job is stopped part way or a stop that typed nothing may still be retried; on the desk PC the restart waits until no phone job or eBay order is being entered and nobody is at that PC (the yellow line says the update is installed; clicking it restarts at once). A download that fails is tried again the next hour (Discord says so once). A version is restarted into by itself once: if it can't start on that PC, it is set aside and the version before it starts again and stays (the yellow line still works). After an update the RDP helper tells Discord it is running the new version, so a silence after "updating itself" means a look is needed. Outside shop hours the helpers look for a new version every hour. The yellow line still works at any time.
- **One retry by itself.** On the desk PC, a phone job or eBay order that stopped before anything was typed (COSTAR busy, Add new covered, someone at the PC) is retried once, a minute after it stopped, while the RDP helper is in touch and taking that work. Never one stopped by a person's Stop all (or by closing the helper). The stop time and the retry are kept in the desk's queue, so a restart neither repeats nor loses it. A second stop waits for you.
- **Discord alerts** (RDP helper, Files & settings, Runs by itself): **Set Discord alerts...** and paste the channel's webhook (Discord: the channel's settings, Integrations, Webhooks, New Webhook, Copy Webhook URL). It is kept encrypted on the RDP PC and never shown again. A message comes when a job stops (one that typed nothing only if the retry hasn't started it again within 3 minutes); in shop hours, when the desk PC can't be reached for 5 minutes, no COSTAR is open and selected for 5 minutes (also a selected one that was closed), or mobile hasn't come back on 10 minutes after it could have, and when it's back to normal (a message held back by the limits goes later, not never); when an update installs itself and is running, or fails to. Not for a Stop you pressed. At most one message of a kind per 15 minutes, 12 an hour. **Send a test** checks it. The desk PC shows a Windows tray message when the RDP helper is out of touch for 5 minutes.
- **Import connection** (RDP helper, Files & settings): after Setup-Desk.cmd has been run on the desk PC, click **Export RDP connection** there, copy the file to the RDP PC, and pick it here. It connects at once (no restart), removes older copies the launcher would bring back, and offers to delete the file. When the desk's certificate no longer matches, the helper now says that in plain words.

## Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.8.0.zip` to GitHub (the `helper` folder). No website files.
2. **RDP PC** and **desk PC:** click the yellow line. Both titles say **2.8.0 - Runs by itself**.
3. **RDP helper**, Files & settings, Runs by itself: tick **Start this helper when you sign in to Windows**; **Set Discord alerts...** with the new channel's webhook, then **Send a test**. Click **Start / resume mobile** once: from then on it comes back by itself.
4. **Desk PC**, Setup (bottom of the window): tick **Start the receiver when you sign in to Windows**.

## Check on the first orders

1. An online pickup booked **today 14:30**: SHOP, Customer Waiting ticked; nothing to check, so it is closed ("in COSTAR and closed (it's in Work-in-Progress)").
2. An online pickup booked **today 10:30**, or **tomorrow 11:00**: SHOP; Customer Waiting left as it is.
3. An online pickup booked **tomorrow 08:30**: Customer Waiting ticked. A delivery order: Ship Via **DFE**.
4. Close the RDP helper and start it again: about 20 s later, "Mobile is back on by itself".
5. **Send a test**: the message arrives in the channel.

Self-tests: **146** helper groups (3 new: the Runs by itself rules; the desk's one retry of a phone job, and of an eBay order, kept in the queue file; the Customer Waiting times in the Time in group) + **16** Order Check groups.

---

# Tempe COSTAR Helper — v2.6.12 — Clean copy of 2.6.11

Tommy, 2 Nov 13:48: "please release the 2.6.12, you dont have to patch anything, I just want to make sure no corrupt files".

2.6.12 is 2.6.11 with nothing changed but its version number. Updating to it downloads the whole helper again into a new folder, checks the download against its published fingerprint and every file against the package's list before anything starts, then builds the helper from those files. Nothing of 2.6.11's install folder is reused.

## Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.6.12.zip` to GitHub (the `helper` folder). The three files in `website/` are the same as 2.6.11's: upload them again only if you want to.
2. **RDP PC** and **desk PC:** click the yellow line in the helper. Both titles then say **2.6.12 - Clean copy of 2.6.11**.
3. Settings, the phone pairing, the queue and the RDP helper's saved connection stay as they are (they are kept apart from the helper's files). After Setup-Desk.cmd has been run again on the desk PC, the RDP helper needs the desk's new connection file: on the desk click **Export RDP connection**, put `worker-connection.json` beside `Start-RDP.cmd` in `%LOCALAPPDATA%\TempeMobileCostar\packages\Tempe-COSTAR-Helper-v2.6.12` inside RDP, close the RDP helper and start it again; delete the file once it says the desk PC is connected.

Self-tests: as 2.6.11 (**143** helper groups + **16** Order Check groups).

---

# Tempe COSTAR Helper — v2.6.11 — Notices answered, SHOP orders

Tommy, 2 Nov 10:25: "apply those pop up skips on all the orders"; "add clear filter on the repair order html so I can go back to check all current order in case if I leave my pc with something filtered out"; "If I want it to be ordered, then instead of only putting SHOP on the comment, also tick customer waiting, otherwise tyres will never left warehouse"; "remove delivery instruction when autofilling online order"; and "check if anything is not optimal ... and make it optimal".

2.6.11 is 2.6.10 plus these. Upload the helper **and three website files** (the Repair Orders page).

## What's new

- **COSTAR's notices over an order are answered with OK.** Some customers' Repair Orders show the customer's **Notes** before the order can be used, and some a message such as **"Point-of-sale Memo!"** (Tommy, 2 Nov: "it cant be ignored, we have to press OK"; "Some customer have more than 1 pop up"). Until now any such window stopped the entry, or the phone's Repair Order request, for a person. Now, on every order (phone jobs, phone Repair Orders, eBay and online orders), the helper presses the one **OK** of:
  - the customer's **Notes** window (titled Notes, one button): it isn't read (it holds card details);
  - a **Point-of-sale Memo**, or any other COSTAR message with a single OK: its words go to the person with the result, under CHECK BY HAND (numbers of 3 digits or more, such as a card's, and emails taken out). On the phone's Repair Orders they show with the Repair Order; on an eBay order they mean the Repair Order is left open for review, as any check does.
  - One after the other, as they come; only windows of that order (owned by its Repair Order window). A question with choices (Yes / No), a window with other buttons, and anything else still stop it as before, nothing pressed. The Customer Not found notice is answered as before by the customer lookup. An OK is never pressed twice: a notice that stays after its OK is waited for (6 s in all), then the order stops for a person. Run report event `popup_ok`.
- **COSTAR's own filter cleared from the phone.** A search left in COSTAR's Work-in-Progress boxes at the PC (2 Nov 09:50 and 10:10: a 2-row list after a Cust/Contact search) hid the other Repair Orders from the phone, and an open stopped with "isn't in COSTAR's Work-in-Progress list (finished, or filtered out?)". Now:
  - the Repair Orders page says when COSTAR's list is filtered and which box ("COSTAR's list at the PC is filtered (Cust/Contact = SAMPLE), so only those show") with a **Clear COSTAR's filter** button: the RDP helper presses COSTAR's **Clear**, then **Search**, and reads the list again. The button shows once the desk PC and the RDP helper both have 2.6.11 (until then the page says to clear it at the PC). Nothing is pressed while a Repair Order is open in COSTAR, or while someone is using the PC (it waits up to 10 s for a quiet moment, then says the filter wasn't cleared); if COSTAR doesn't answer when its boxes are looked at, it says so rather than guess;
  - opening a Repair Order that isn't in a filtered list clears the filter by itself (Clear, Search, looked for again), saying so on the phone and with the result; day log `ro_filter_cleared` (the boxes' names only: what was typed in them is a person's search and stays out of the day log and the run report).
- **Repair Orders page: Show all.** While a search or Today / This week on the phone narrows the list, a **Show all** chip shows; one tap empties the search and picks All.
- **Repair Orders page: SHOP is the order.** The SHOP button beside Ship Via now does what the Order tick does: Ship Via **SHOP**, **Customer Waiting ticked** and **Date In today** (each where the phone can change it on that Repair Order). Phone jobs and the Order tick already did all three.
- **Phone jobs: Customer Waiting (and Ship Via SHOP) wait for the Repair Order to be back in front.** This is why orders came out with SHOP but no Customer Waiting: 2 Nov 08:02 the Job Card printed (13.6 s) and then "Customer Waiting not ticked (COSTAR isn't in front with Customer Waiting free to change)"; 29 Oct 11:34 someone had clicked COSTAR's main window as the Job Card was to print, so the print was skipped and Customer Waiting stopped with "lost focus". Both left it to tick by hand. Now each ordered part waits up to 20 s for the Repair Order to be in front again (nobody using the PC for 3 s, then the Repair Order brought forward), then ticks; if the PC stays in use it says so and leaves it by hand, as before.
- **Online orders: Shipping Instructions no longer typed.** The Tempe Orders page's "EST FITTING: …" isn't entered into Shipping Instructions any more (the box stays as COSTAR made it).
- **eBay (and other new orders): a window over Add new is waited out for a moment.** 30 Oct 08:14 and three times on 26 Oct: COSTAR Sydney on a Windows desktop of its own, Windows still switching to it 0.1 s after COSTAR was asked forward, so "Add new is covered by another window" stopped the order, which then went in on Retry. Now Add new is looked at again for up to 1.5 s; a window that stays over it is still refused, now saying whose it is (the program's name). Day log `add_new_covered`.

## Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.6.11.zip` to GitHub (the `helper` folder), and the three files in `website/` (`Repair_Orders.html`, `repair-orders.js`, `repair-orders.css`) to the repo's top folder, as the Job Card files.
2. **RDP PC:** click the yellow line in the helper. **Desk PC:** update it too (the phone's Clear COSTAR's filter button shows only when both are on 2.6.11; the rest works without it).
3. On the phone, reload the Repair Orders page once (the page names its new script).

## Check on the first orders

1. **A customer with Notes** (a phone Repair Order request, or a phone job for an account customer): the Notes window comes and goes by itself; the result says "COSTAR showed the customer's Notes before the order (OK pressed)". A Point-of-sale Memo: its words come back under CHECK BY HAND.
2. **Repair Orders page:** leave a search in COSTAR's Work-in-Progress boxes at the PC, tap ↻ on the phone: the page says the list is filtered and offers **Clear COSTAR's filter**; tap it: COSTAR's boxes empty, Search runs, every Repair Order shows. Search for something on the phone: a **Show all** chip appears; tap it: everything's back.
3. **SHOP on the Repair Orders page:** Ship Via SHOP, the Customer Waiting switch on, Date In today, three changes to review.
4. **A phone job with Order ticked while you're using the PC:** it waits for a quiet moment (up to 20 s), then ticks Customer Waiting; still busy: "Customer Waiting not ticked (the Repair Order isn't in front and someone is using the PC). Tick it by hand."
5. **An online delivery order:** Shipping Instructions stays empty.
6. **An eBay order while you're on another desktop:** it goes in first time (the day log has `add_new_covered … clear after … ms`).

Self-tests: **143** helper groups (1 new: the notices, a memo's words, the waits; the clear in the desk's queue and the helper's clears flag in existing groups) + **16** Order Check groups; the Repair Orders page: 11 Node checks and 111 end-to-end checks.

---

# Tempe COSTAR Helper — v2.6.10 — Open RO closed for new jobs

Tommy, 29 Oct 21:45: "at the moment if i want to add new order through phone or check and order through phone if there is any repair order open that is connected to that costar it will not do anything and need to wait for me to manually close right? or has it been patched?" — 21:47: "ok we fix that one first, release new version to patch that".

Checking or changing an order from the phone already closed a Repair Order left open first (2.6.7). A **new order from the phone** (Job Card → SUBMIT TO COSTAR) still waited with "A Repair Order is open in the selected COSTAR" until it was closed by hand. 2.6.10 closes it first for new orders too.

2.6.10 is 2.6.9 plus this. It doesn't include the Background test (2.7.0, a separate test build for the RDP PC). Upload 2.6.10 only.

## What's new

- **A new phone order closes a Repair Order left open in the selected COSTAR first**, then presses Add New as usual. Its own close (as the X does): nothing saved, sold or printed; it stays in Work-in-Progress. The same rules as for the phone's Repair Orders (2.6.7):
  - only once nobody has used the PC for 3 s;
  - never while COSTAR is asking something on it (nothing is answered);
  - never one waiting for a person: the phone job waiting for review (press Next Order), a phone job that stopped there, the one a job was started again from (Start this job again: until that job is in; the phone's Repair Orders don't close it either), an online order's (PO# TTW…, or the Online orders tab's), an eBay order's (PO# 12-34567-89012, or one an eBay order stopped in);
  - never one whose PO# couldn't be read, never in Order Check's own COSTAR, and only while COSTAR shows Work-in-Progress, looked at again right before each close (else Add New couldn't follow anyway).
- **What the phone and the desk PC say:**
  - while it can't be closed yet, why: "A Repair Order is open in COSTAR Tempe: it will be closed once nobody has used the PC for 3 s", "…: it is online order TTW…'s, maybe waiting for review. Finish or close it at the PC first", and so on;
  - when it can: the job goes in, the progress says "Closing Repair Order 07…, which was open in COSTAR Tempe, before entering …", and the result says "Closed RO 07… first (open in COSTAR Tempe)";
  - if someone starts using the PC just as the job starts, it waits for a quiet moment (up to a minute in all: "Waiting for a quiet moment to close a Repair Order left open …"). Still in use after that, or something else keeps it open: the job stops before Add New ("Add new was not pressed": nothing is opened or typed for it), says why (and, with two open, which one it had already closed), and Retry carries on. The phone's sheet then says "Not entered in COSTAR", or "Stopped part way" if it saw the job start (the website is unchanged; the words say Add new was not pressed).
- A Repair Order the phone's Repair Orders left open (after a change stopped) may be closed this way too, as they close it themselves; they then no longer count it as left open.
- A stopped job retried in its own Repair Order closes nothing: only a job about to press Add New does.

## Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.6.10.zip` to GitHub (the `helper` folder). No website files this time.
2. **RDP PC:** click the yellow line in the helper (this is where the change is). The desk PC can update too (nothing changes there), any time.
3. The 2.7.0 Background test for the morning runs from its own folder as before: the usual shortcut starts 2.6.10.

## Check on the first phone jobs

1. Open a Repair Order in COSTAR Tempe at the PC and leave the PC alone. Submit a test Job Card: the phone's progress says "Closing Repair Order …" and the job goes in. The Repair Order you opened is still in Work-in-Progress.
2. Do the same while moving the mouse: the phone says it waits for nobody using the PC for 3 s; stop and it goes on.
3. With a phone job ready for review (before Next Order): the next job waits for Next Order, as before; the reviewed Repair Order is never closed by the next job.
4. With an online order's Repair Order left open (PO# TTW…): the job waits and says so; close it by hand and the job goes in.

Self-tests: **142** helper groups (1 new: the rules for a new phone job) + **16** Order Check groups.

---

# Tempe COSTAR Helper — v2.6.9 — Job Card progress

Tommy, 29 Oct 12:02, with the report of 11:57: "check with the error, and fix it", and "with the jobcard/fitment planner page, can you please add a progress when you submit to costar just like the repair order page".

The error: the phone job of 11:34 stopped at "Quantity for 430332" ("COSTAR did not focus the expected field"), and its retry said "Repair Date box not found".

2.6.9 includes 2.6.8 (Add new on WIP only, below) and 2.6.7: upload 2.6.9 only.

## What's new

- **Job Card → SUBMIT TO COSTAR shows how it's going**, like the Repair Orders page's save sheet:
  - **Sent to the desk PC** (with the time) → **Waiting for the RDP helper**, and why → **Typing into COSTAR** (e.g. "Step 8 of 12 · Add tyre …", with a bar) → **Ready for review in COSTAR**.
  - Why it waits, from the desk PC: "A Repair Order is open in the selected COSTAR", "Another order is being entered in COSTAR", "The order before it is ready for review in COSTAR: press Next Order on the desk PC", "An earlier order stopped: retry or remove it on the desk PC", "2 orders ahead of it", "Next in line", and so on.
  - At the end: what the order came to (Ordered …, Job Card printed …) and anything to check by hand. **Done**, or **New job**.
  - If it stops: where it stopped, why, and **Retry** (the same order: it never goes in twice). Unless the words say nothing went in, it says part of it may be in COSTAR: check there.
  - After Retry of a stopped order it says "Next: the RDP helper carries on with it in its own Repair Order (leave that open in COSTAR)".
  - **Close** only closes the sheet: the order carries on. **Show progress** (in the COSTAR status box) brings it back. While it's open the phone asks every 1.5 s (3 s otherwise).
- **The quantity after a tyre line (the 11:34 stop):** COSTAR moved the keyboard on from the quantity box to Disc by itself, just after the tyre line loaded, and the helper's click back into the quantity didn't take.
  - After an item line loads, the helper now lets COSTAR finish moving the keyboard (usually a few tenths of a second, at most 1.5 s) before it clicks into the next box. If COSTAR leaves it in the right box, nothing is clicked.
  - Right after a line loads, the click must also hold: the keyboard has to stay in the box for a quarter of a second. If the click doesn't take, or COSTAR moves the keyboard on along the same line (to Disc), the helper goes back with Shift+Tab: at most twice, only along that line, only while nobody is using the PC, and nothing is typed. Only then does the quantity go in.
  - The same if COSTAR moves it after the quantity went in, before Tab (then also only while nobody has used the PC for 3 s, looked at right before the click).
- **Repair Date (the 11:34 retry: "box not found"):** COSTAR's Repair Date isn't a Windows edit box but COSTAR's own date box. The helper now finds it under the Repair Date label and reads its date, without typing into it. Today: "Repair Date is today." Another day: "Repair Date isn't today (…): set it to today by hand." Can't be read: "make sure it is today". Found on every Repair Order map from 28 Oct.
- Not errors, on that retry: the Job Card wasn't printed and Customer Waiting wasn't ticked because someone was using the PC just then (as designed: it says so and leaves both to do by hand). "Number not read beside the RepairOrder label" is expected on a new Repair Order: the print form is then checked by the window it belongs to.

## Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.6.9.zip` to GitHub (the `helper` folder). Also upload the three files in the upload set's `website` folder (`Fitment_Planner.html`, `Fitment_Planner.js`, `jobcard-shared.js`) to the repo's **top** folder, replacing the old ones.
2. **Desk PC first:** click the yellow line on the desk receiver. **Then the RDP PC:** click the yellow line in the helper.
3. **Phones:** reload the Job Card page (GitHub can take up to 10 minutes to serve the new files).

## Check on the first phone jobs (a test card first)

1. Submit a test Job Card: the sheet opens and goes Sent → Waiting → Typing (Step … of 12) → Ready for review, then lists what the order came to.
2. Submit one while a Repair Order is open in COSTAR Tempe: the sheet says why it waits. Close that Repair Order and it goes on by itself.
3. Close the sheet while it's typing: the order carries on; **Show progress** brings the sheet back.
4. Send the RDP helper's report after a few jobs: `load_settle` after each tyre line says how long COSTAR took to stop moving the keyboard; `line_box_left`, `click_not_taken` and `shift_tab` show any time COSTAR moved it on and the helper went back; `repair_date` says how the date was read.

Self-tests: **141** helper groups (3 new: why a phone job waits, from the desk to the phone; the quantity after a line loads; COSTAR's date box and its date) + **16** Order Check groups. Job Card page: 59 checks (12 new); in a browser against the real desk code: 28 checks.

---

## Previous release notes (2.6.8) — Add new on WIP only

Found in the report of 29 Oct, 01:18: COSTAR Sydney was left on "Orders yet to be filled", the wholesale orders list. Add new there starts a wholesale Order, not a Repair Order, and the helper pressed Add new without looking at which list COSTAR was showing. The next eBay order would have opened an empty wholesale Order, waited 30 s for a Repair Order, then stopped ("Add New did not appear") and left that Order open.

2.6.8 includes 2.6.7 (Open RO closed first, below). If 2.6.7 isn't uploaded yet, upload only 2.6.8.

### What's new

- **Add new only on Work-in-Progress.** Before every Add new (online orders, phone jobs, eBay orders), the helper checks that the COSTAR shows Work-in-Progress. It finds the list the same way Order Check and the phone's Repair Orders do.
  - On another list it presses nothing and says so: "COSTAR Branch 1 (SYDNEY) is showing "Orders yet to be filled", not Work-in-Progress (Add new there doesn't start a Repair Order). Put it back on Work-in-Progress."
  - If COSTAR is too busy to say which list it shows, or Work-in-Progress is still loading, it waits for it (up to 15 s) instead of pressing.
  - It looks once more right before the press, and checks that the Add new it found is still the one showing.
- **Jobs wait instead of stopping:**
  - eBay orders stay in the desk's queue while COSTAR Sydney shows another list, and the eBay panel says why. They go in by themselves once it's back on Work-in-Progress.
  - Phone jobs and phone Repair Orders (COSTAR Tempe) wait the same way, with the reason on the phone. A Repair Order open in COSTAR Tempe is only closed first for the phone while it's on Work-in-Progress.
  - An online order sent from the Online orders tab stops with that message instead (someone is at the PC then).
  - A job handed out just before the list changed stops instead, with the same message; nothing is pressed. Retry it once COSTAR is back on Work-in-Progress.
- Only the list's title is read: the label across the top of the list, and only when it's COSTAR's own short words ("Orders yet to be filled"). Otherwise it says "another list"; other labels' words are never shown or logged.
- Each refusal goes in the day log (`add_new_refused`), and the end-of-day report lists them under THINGS TO LOOK AT.

### Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.6.8.zip` to GitHub (the `helper` folder). No website files.
2. **RDP PC:** click the yellow line in the helper.

### Check (one minute, no order needed, with the desk PC on)

1. Put COSTAR Sydney on "Orders yet to be filled". Within a few seconds the RDP helper's eBay orders tab says: "COSTAR Branch 1 (SYDNEY) is showing "Orders yet to be filled", not Work-in-Progress …". Nothing opens in COSTAR.
2. Put it back on Work-in-Progress: the line goes back to ready (this also shows the helper recognises COSTAR Sydney's Work-in-Progress), and an eBay order sent meanwhile goes in by itself.
3. The same with COSTAR Tempe: the Mobile jobs tab and the phone say why they wait.
4. Then send one real eBay order as usual: it goes in as before.

Self-tests: **138** helper groups (1 new: the list's title, what's said, and the stop's kind) + **16** Order Check groups.

---

## Previous release notes (2.6.7) — Open RO closed first

Tommy, 28 Oct 15:11: "if I'm trying to access it through phone but the pc is opening a repair order, close that repair order so I can access it on the phone". Until now a phone request waited ("A Repair Order is open in COSTAR Tempe: close it … first") until someone closed it at the PC.

### What's new

- **A Repair Order left open in COSTAR Tempe is closed first.** When the phone asks to open, change or print a Repair Order, the one that's open goes first, with COSTAR's own close: nothing saved, sold or printed, and it stays in Work-in-Progress. Then the phone's request goes ahead.
  - While it closes, the phone shows "Closing Repair Order …, which was open in COSTAR Tempe, before opening Repair Order …".
  - The result starts with "Closed RO … first".
  - This includes one the helper itself left open after a change stopped. What it typed stays in it, so open it on the phone to check it.
- **It's only closed when it's safe:**
  - **Nobody has used the PC for 3 s.** Until then the phone shows "A Repair Order is open in COSTAR Tempe: it will be closed once nobody has used the PC for 3 s". Someone working at the counter who stops for 3 s can have it closed.
  - **COSTAR isn't asking anything on it.** If it is, the phone says so and nothing is answered.
  - **It isn't held for review.** A phone job's Repair Order waiting for review, or one the Online orders tab filled or stopped in, stays open. So does any Repair Order whose PO# is an online order number (TTW…), because after a restart the Online orders tab doesn't remember its Repair Orders.
  - **Its PO# can be read.** If COSTAR doesn't answer the look, it stays open and the phone says why.
- Each close is in the day log (`ro_close_first`).
- **Waiting for COSTAR to be ready is 3 s now** (Tommy, 28 Oct 15:34: "change all idle time to 3 seconds", "when its waiting for costar to be ready"). Repair Orders from the phone and eBay orders used to wait until nobody had touched the RDP PC for 10 s; now it's 3 s. The check that someone used the PC *during* an open or a print is unchanged: it stops there, as before.

### Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.6.7.zip` to GitHub (the `helper` folder). No website files.
2. **RDP PC:** click the yellow line in the helper.

### Check on the first jobs (a test Repair Order first)

1. Open a test Repair Order in COSTAR Tempe at the PC, then step away. From the phone, open another Repair Order.
   - For the first 3 s the phone waits ("… once nobody has used the PC for 3 s").
   - Then the test Repair Order closes and the phone's one opens. The test Repair Order is still in Work-in-Progress.
2. With a phone job waiting for review in COSTAR Tempe, open a Repair Order from the phone. The job's Repair Order stays open, and the phone says it's waiting for review.

Self-tests: **137** helper groups (1 new: what stays open and why, and a Repair Order's number and PO# read from its labels) + **16** Order Check groups.

---

## Previous release notes (2.6.6) — Item lines clicked

28 Oct, 13:28, the diagnostics of 14:05: a car change from the phone stopped on the ODOMETER note, "The field lost focus before validation." 2.6.5 gave the note line the keyboard directly, and COSTAR took it back right after the note's key press. Before 2.6.5, 317 note lines got the keyboard with a click and none lost it. 2.6.6 clicks the Repair Order's item lines again, as 2.6.4 did; everything else stays pressed directly. It also fixes the two other stops in the same report: "COSTAR did not accept customer phone" (3 today) and a freight charge that lost the keyboard after its line loaded.

### What's new

- **The item lines are clicked again, as in 2.6.4.** COSTAR's item lines follow the mouse: a box given the keyboard directly can be taken back, and Tab and Delete act on the line COSTAR is on. Clicked again:
  - a line's item code (a new item, or a line taken out);
  - its words (the note lines: MAKE/MODEL, REGO NO, ODOMETER, a new note);
  - its quantity and price, and the freight charge.
- **Leaving the item lines is a click too.** While the keyboard is in the item lines, the next box is clicked, so COSTAR closes the line the way it does for a click (DET makes its notes then). That next box can be PO#, a box at the top, Customer Waiting or Ship Via.
- **Everything else stays direct (2.6.5)**, once the keyboard is out of the item lines:
  - the boxes at the top (customer, phone, PO#, Date In, Written By);
  - Customer Waiting and the print form's ticks;
  - Print, OK and Add New;
  - eBay's tabs;
  - opening a Repair Order from Work-in-Progress.
- **"COSTAR did not accept customer phone": fixed.** COSTAR now has 5 s to take a box's words (it was 1.5 s). The phone box can take nearly 2 s while COSTAR looks the number up. It stopped 3 orders today and 8 in all, every one at exactly 1.5 s; one that went through took 1.46 s. Words COSTAR takes even later are waited for and read back (`write_late`).
- **A quantity, price or note that COSTAR takes the keyboard from is clicked once more.** After an item loads, COSTAR sometimes moves the keyboard off the quantity or price box between the words going in and Tab: today's 08:16 freight charge ("The field lost focus before validation"), and three earlier quantities.
  - The box is clicked again, marked edited again, and Tab follows (`focus_again`). A note line also gets its key press again: COSTAR keeps a note only after one.
  - This only happens when it's still the same box, it still shows exactly what was put in, COSTAR's Repair Order is in front, and nobody has used the PC in the last 3 s.
  - Only once; otherwise it stops as before.
- **When a box loses the keyboard, the run report says where it went** (`focus_lost`):
  - which box got it (its kind and place, no words);
  - whether COSTAR was in front;
  - whether someone used the PC, and when the last key or mouse move was.
  The 13:28 stop left nothing to say where.
- **A "Someone used the COSTAR PC" stop writes what was seen** (`ro_user_active` in the day log for opens, `user_active` in the run report for prints): how long ago the last key or mouse move was, and how long after the helper's own. The one at 13:38 came 12 s into an open, while COSTAR was still opening the Repair Order.
- **The self-tests after an update no longer write to the day log.** Their made-up Work-in-Progress lists showed up as seven failed opens at 12:45.

### Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.6.6.zip` to GitHub (the `helper` folder). No website files.
2. **RDP PC:** click the yellow line in the helper.

### Check on the first jobs (a test Repair Order first)

1. **A car change from the phone (rego and odometer):** the pointer clicks into each note line, as in 2.6.4. The notes go in, and COSTAR still shows them after the Repair Order is closed and opened again.
2. **A quantity, a price, a new item, a line taken out:** clicked as in 2.6.4.
3. **Customer Waiting and a print:** as in 2.6.5 (the pointer stays still).
4. **Online orders and eBay orders:** the customer phone goes in even when COSTAR is slow to look it up. Any `write_late` or `focus_again` lines in the run report say the helper waited or clicked once more.
5. Anything odd: send Save diagnostics. The run report now says where the keyboard went.

Self-tests: **136** helper groups (1 new: the day log gets nothing from the self-tests) + **16** Order Check groups.

---

## Previous release notes (2.6.5) — Press COSTAR directly

Tommy, 28 Oct, after the first prints: "it's working, but it looks like its clicking instead of like native"; with the maps in (2.6.3, 2.6.4): "full gas no brakes sir". 2.6.5 presses COSTAR the way COSTAR's own code does, everywhere the helper used to move the mouse.

### What's new

- **The mouse stays still.** These are pressed directly now instead of clicked:
  - **Boxes** get the keyboard directly (Windows' own focus), then the words go in as before. This is the click into every box of every order.
  - **Customer Waiting** and **the print form's ticks** are pressed directly and read back.
  - **Print** on the Repair Order's toolbar is pressed directly once COSTAR confirms the button there is Print (never Sell, next to it), with nobody at the PC at that moment; the print form's **OK** and **Cancel** directly.
  - **Work-in-Progress**: the Repair Order's row is selected directly and made COSTAR's active row (the one Enter opens), checked once more, then opened with Enter: no scrolling, no double click.
  - **eBay's Ship to / Rebill to tabs** are shown directly.
  - **Add New** and the **Customer Not found** notice's OK are pressed directly.
- **Keys stay keys**: Tab after a box, Enter, Escape and the note line's letter (COSTAR keeps a note only after a real key press, 25 Oct).
- **The mouse is only the back-up**: when a direct press doesn't do what it should (a tick didn't change, a box didn't get the keyboard, the row didn't open), the helper clicks as before. A press that may still be on its way is never followed by a second one: no second print, no second Repair Order, no tick pressed twice.
- **Not changed on purpose: deleting a Repair Order line** still goes through the line's right-click menu, exactly as in 2.6.4. A Delete can't be undone, so it stays as it is until a map of a Repair Order with lines shows that menu up close.
- **Switch**: Files & settings → "Press COSTAR's buttons, ticks, tabs and boxes directly" (ticked). Untick it to go back to the mouse, as in 2.6.4, if something misbehaves; tick it again any time.
- The run reports count the direct presses, and say each time the mouse had to step in (`direct_fallback` in the day log).

### Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.6.5.zip` to GitHub (the `helper` folder). No website files.
2. **RDP PC:** click the yellow line in the helper.

### Check on the first jobs (a test Repair Order first)

1. **Repair Orders (phone), standing at the PC:** open the test Repair Order, Order / print…, both ticked. COSTAR opens it without the list scrolling, Customer Waiting ticks, Print opens the form, the ticks change, OK goes, COSTAR closes it. The mouse pointer doesn't move. **Watch this first print**: one Job Card from the printer, nothing else.
2. **Customer Waiting kept:** open that Repair Order again in COSTAR and look that Customer Waiting is still ticked (a tick pressed directly must be kept by COSTAR, not only shown).
3. **A phone job**, **an online order**, **an eBay order**: the boxes fill in turn with the pointer still; on eBay the Ship to / Rebill to tabs change without a click.
4. Anything odd: untick the switch (Files & settings), carry on, and send Save diagnostics.

Self-tests: **135** helper groups (1 new: a Repair Order opened from a made-up Work-in-Progress list without a click or the wheel, its row made the active one, and handed to the mouse way when the list won't take the keyboard, another row stays selected or active, nothing tells which row is active, or the list was sorted again; accessibility presses never made late or twice, and never past a last look that says no (the open stops when that look sees someone at the PC); what follows a tick pressed directly) + **16** Order Check groups.

---

## Previous release notes (2.6.4) — Map COSTAR, deeper

Tommy, 28 Oct, with the first five maps: "I dont know if this reads the repair order screen". It read the Repair Order window's boxes, labels, buttons, ticks and tabs, and a line's right-click menu, but not deep enough: Windows gives every COSTAR box its own title, menu and scroll bars that don't show, and the map spent its whole budget on them (2,321 of its first 2,500 objects) before it got to the toolbar and the lines. The print form and the customer search window aren't in any of the five maps: 5 seconds was too short to bring them up.

### What's new

- **The map skips what doesn't show.** A part that doesn't show costs one question and nothing under it is read; Windows' own title bars, scroll bars and size grips are noted but not opened. The Repair Order's toolbar and lines are reached now. A panel with many boxes is read whole (only real lists, like Work-in-Progress, are read in a sample).
- **Ctrl+Alt+F9 maps the COSTAR screen in front, at once.** Bring the screen up at your own pace (the print form, the customer search window, an open menu), then press Ctrl+Alt+F9. A sound says when the map is saved (a different one if it couldn't be taken). The button still works, with 10 seconds now.
- **Only the COSTAR in front is read.** The other COSTARs open in the session (Sydney, the second Tempe) are listed, not read, so each map is quicker (each 2.6.3 map read all three, about 26 s).
- The map's page for reading is shorter: the same button on every line once, counted; a list's rows and cells counted under it, its headings in one line.

### Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.6.4.zip` to GitHub (the `helper` folder). No website files.
2. **RDP PC:** click the yellow line in the helper.

### Map these three screens (on a test Repair Order)

For each one: bring the screen up in COSTAR, press **Ctrl+Alt+F9**, wait for the sound (a few seconds), then the next.

1. **The Repair Order** with lines, the toolbar showing (click into a line first).
2. **The print form:** click Print on that Repair Order; when the form shows, Ctrl+Alt+F9; after the sound, cancel it by hand.
3. **The customer search window** (the one COSTAR shows when a customer is looked up).

Then **Save diagnostics** and send the ZIP to Claude. (The Work-in-Progress list, the eBay Ship to / Rebill tabs and the right-click menu are in the first maps already.)

Self-tests: **134** helper groups (1 new: a made-up Repair Order window as Windows' accessibility shows it, every box with its hidden title and scroll bars: the toolbar is reached, each hidden part is asked one question and nothing under it, frame parts aren't opened, nothing is pressed, only the COSTAR in front is read) + **16** Order Check groups.

---

## Previous release notes (2.6.3) — Map COSTAR

Tommy, 28 Oct, after the first prints: "it's working, but it looks like its clicking instead of like native ... do you want to map it first?" — and "tell me which other process are still manual, so we can map all together". 2.6.3 adds the map; the next update uses it to press what COSTAR allows directly instead of moving the mouse.

### What's new

- **Map COSTAR screen** (RDP helper, right of the window, under Add note). Press it, then within 5 seconds bring up the COSTAR screen to map (a menu can be opened too). The helper then **only reads** COSTAR — nothing is clicked, typed, focused or changed — every COSTAR window that shows, the one in front first: each box, button, tick box, tab, list, menu and toolbar item; COSTAR's own words on it; whether it's greyed, ticked or has the keyboard; and what Windows or accessibility could do with it directly (a press, a tick, a tab's switch, a menu item, a list row's action, a keyboard shortcut).
- Customer words aren't kept: text boxes, list rows and cells are recorded as their length only (e.g. "[14 chars]"); emails and long numbers in labels are masked.
- Each map is saved with the diagnostics (`maps/`, kept 180 days) and goes into the next **Save diagnostics** ZIP (the last 14 days of maps).
- While a map runs (a few seconds, at most 2 minutes), nothing else is typed into COSTAR: a phone job or Repair Order waits for it.

### Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.6.3.zip` to GitHub (the `helper` folder). No website files this time.
2. **RDP PC:** click the yellow line in the helper. (The desk PC can update too; nothing changes there.)

### Map these screens (on a test Repair Order)

Press **Map COSTAR screen**, bring the screen up within 5 s, wait for "Map N saved" in the log. Then the next one:

1. A Repair Order with lines and DET, toolbar showing (click into a line first, so the map sees the lines' editing box too).
2. The print form (Print on that Repair Order; cancel it by hand after the map).
3. The customer search window (the one COSTAR shows when a customer is looked up).
4. COSTAR Tempe's Work-in-Progress list.
5. An eBay-style Repair Order with its Ship to / Rebill tab showing.
6. A line's right-click menu (press Map, then right-click a line within the 5 s and leave the menu open).

Then **Save diagnostics** and send the ZIP to Claude.

Self-tests: **133** helper groups (1 new: the map reads a made-up Work-in-Progress list through the same accessibility calls without selecting, clicking or scrolling anything, keeps the headings, masks the customer words, samples long lists and stops at its budget) + **16** Order Check groups.

---

## Previous release notes (2.6.2) — Print and order from the phone

Tommy, 27 Oct: "instead of ordering straightaway for mobile order I want both options to be showing up after I click on submit to costar, I want it to give me options to tick those 2 before going ahead": **Order** (Ship Via SHOP, CustWaiting ticked, the date today) and **Print the Job Card** ("tick print job card and untick invoice, qty stay 1"). Both are ticked to start with. The Repair Orders page has the same two when saving, and can print a Job Card with nothing changed.

2.6.2 includes 2.6.1 (Repair Orders faster, below): upload 2.6.2 only.

### What's new

- **Job Card → SUBMIT TO COSTAR** asks first, with two ticks, both ticked: **Order** (Ship Via SHOP, Customer Waiting ticked, Repair Date today) and **Print the Job Card**. Untick what you don't want; **Cancel** sends nothing. Without Order, Ship Via, Customer Waiting and the Repair Date stay as COSTAR made them (before 2.6.2 every phone job got SHOP and Customer Waiting). With an RDP helper older than 2.6.2 the old Confirm question shows: it orders as before and prints nothing.
- **Repair Orders → save:** the review has the same two ticks, both ticked each time it opens. Order sets only what isn't so already and says which ("Already Ship Via SHOP", "In your changes: …"); a Ship Via, Date In or Customer Waiting you changed above stays as you set it. With nothing changed the save bar says **Order / print…**; with Order unticked (or nothing left to order) the button is **Print the Job Card**: the helper opens the Repair Order, prints its Job Card and closes it, typing nothing.
- **How the Job Card is printed:** only when ticked, and only once everything else is in and checked (phone job: after the final check, before Customer Waiting is ticked; Repair Orders: just before COSTAR closes it). The helper clicks COSTAR's **Print**, found by its name (never by its place: Sell is next to it). The print form must open for this Repair Order (its number in the title). The helper reads the form's rows by their names: **Job Card** ticked to print, every other document (the Invoice, Freight Label, Delivery Docket) unticked, every eMail box unticked, the Job Card's quantity read and 1. It reads the form again and only then presses **OK**. The printer (To) is left as COSTAR sets it. If anything on the form isn't as expected, it presses **Cancel** (nothing printed) and says why. A COSTAR message is read, never answered. Nothing is brought in front while someone is using the RDP PC. A Job Card is never printed twice: a phone job notes that OK went, so a restart doesn't print it again, and a print alone of a Repair Order whose Job Card went less than 2 minutes before isn't done (the phone says why).
- **What the phone says:** the Job Card's status reads e.g. "READY FOR REVIEW · Ordered: Ship Via SHOP, Customer Waiting ticked, Repair Date today. · Job Card printed (sent to COSTAR's Job Card printer)." Repair Orders ends on **Saved and printed**, **Saved, not printed** (the change is in; why the print didn't go), **Job Card printed** or **Not printed**. When OK went but how it ended can't be told (COSTAR showed a message, the form stayed open, the helper stopped or was closed, the desk PC lost touch), it says **Check the printer**: "the Job Card may have printed". It never says "not printed" then, so a Job Card isn't printed twice by mistake.
- **Try again** after a save that didn't go opens the review again (both ticks as each time): Order and Print never go without being seen. A Stop while printing leaves the Repair Order open (the phone offers to close it).
- **Versions out of step:** the phones offer the choices only when the RDP helper is 2.6.2. If it changes version after a phone looked, the desk PC doesn't hand it a print or a job whose choices it would ignore: the phone says why (Repair Orders: nothing typed, save again; Job Card: stopped, Retry once the RDP helper is 2.6.2).
- **Job Card page:** RETRY can be scrolled clear of the SUBMIT bar on a phone (it was half hidden behind it).

### Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.6.2.zip` to GitHub (the `helper` folder). Also upload the six files in the upload set's `website` folder (`Repair_Orders.html`, `repair-orders.js`, `repair-orders.css`, `Fitment_Planner.html`, `Fitment_Planner.js`, `jobcard-shared.js`) to the repo's **top** folder, replacing the old ones. Skip the 2.6.1 upload set: this one has all of it.
2. **Desk PC first:** click the yellow line on the desk receiver. **Then the RDP PC:** click the yellow line in the helper.
3. **Phones:** reload the Job Card and Repair Orders pages (GitHub can take up to 10 minutes to serve the new files).

### Check on the first prints

Start with a Repair Order that doesn't matter (a test one).

1. **Repair Orders:** open it, change nothing → **Order / print…** → untick Order → **Print the Job Card**. COSTAR opens it, the print form shows for a moment with Job Card ticked and the Invoice unticked, one Job Card comes out of the Job Card printer, COSTAR closes the Repair Order. The phone: **Job Card printed**.
2. If the phone says "Job Card not printed: …", nothing was printed (the form was cancelled, or a COSTAR message is waiting at the PC): send the RDP helper's report. It lists the print form's boxes as the helper read them.
3. **A phone job with both ticked:** READY FOR REVIEW · Ordered … · Job Card printed. In COSTAR: Ship Via SHOP, Customer Waiting ticked, Repair Date today, and one Job Card printed.
4. **A phone job with Order unticked:** Ship Via and Customer Waiting as COSTAR made them.
5. A phone job prints its Job Card just before Customer Waiting is ticked (in case ticking it makes COSTAR open a window). If the printed Job Card should show Customer Waiting, tell Claude.

Only the RDP PC can show: whether COSTAR's Print is a button of its own or drawn into its toolbar (both are handled), whether the print form's boxes read as tick boxes (if they don't: not printed, the form cancelled, said), and whether COSTAR prints a phone job's new Repair Order without asking to save it first (if it asks: not answered, said; the job is still ready for review).

Self-tests: **132** helper groups (3 new: the print form read from its labels and tick boxes, and what must be on it before OK; the phone's choices from the phone through the desk to the RDP helper; Repair Orders print requests, and helpers that don't print) + **16** Order Check groups.

---

## Previous release notes (2.6.1) — Repair Orders faster

Opening a Repair Order from the phone took 15 seconds to 2½ minutes on 27 Oct, and every save opened it again. COSTAR itself took half a second to read it: the time went into finding its row in COSTAR's Work-in-Progress list. Tommy: "I am a speed demon, and this is taking forever".

### What's new

- **Finding the row:** the helper reads the Work-in-Progress list once, only each row's Document # (2.6.0 read every cell of every row, about 4 seconds a time, and again after every scroll step). When the row isn't in view it scrolls straight to it: one wheel notch to see how far a notch moves the list, then one or two turns worked out from where the rows are (one more single notch for the last few rows of the list). Expected: about 3 seconds from tap to the Repair Order on the phone for a row in view, 4 to 6 when the list has to scroll or be searched; COSTAR opening the Repair Order is about 2 of those.
- **Search only when the list may be out of date:** when it shows nothing, when the Repair Order isn't in it, when Order Check's last read (from the last 3 minutes) doesn't have it (finished meanwhile?), or when there's no such read and nobody pressed Search in that COSTAR for 10 minutes.
- **Never a double click on a moving list, or on another row:** every wheel turn must have moved the list by exactly all of its notches, and the list must have held still, before anything else happens (COSTAR, or the remote desktop, can be slow to pass the wheel on). Then the list is read again, the row is looked at again with fresh objects at its place, and its place is checked twice; just before the double click, what Windows' accessibility finds under the mouse must not be another Repair Order, and never a column heading. Otherwise it stops and opens nothing.
- **The wheel only goes to the list:** it is turned only while the list itself has the keyboard (one click on a row in view gives it, as before; never a second click soon enough to make a double click), so it can't turn one of COSTAR's drop-downs.
- **Shown as soon as it's read:** the phone shows the Repair Order the moment the helper has read it, while COSTAR is still closing it (a second or two). After a save the phone says "In COSTAR and checked" as soon as the check is done; **Done** closes the sheet while COSTAR closes the Repair Order.
- **The list at once:** opening the page takes the list from Order Check's own read when it is at most 3 minutes old (Order Check reads its Tempe COSTAR every 2 minutes in shop hours, pressing Search), so COSTAR Tempe isn't held up and an open isn't kept waiting behind a list read. **↻** reads COSTAR's list just now (or takes Order Check's from the last 30 seconds).
- **The phone asks more often while a request is new** (every 0.4 s for the first 10 seconds).
- **The day log says where the time went** for every open: e.g. `list read 0.6 s (130 rows, one cell each), no Search, row brought into view with 3 wheel turns 1.1 s (34 notches), at the point: this one, COSTAR opened it in 1.8 s, 4.3 s in all`. Send the report after the first few.
- A read that COSTAR doesn't close again (it may be asking something at the PC) now says so on the phone, with **Close it in COSTAR**. While the helper waits because a Repair Order is open, the phone names the one it left open (**Close RO … in COSTAR**), whichever Repair Order you're opening; once closed, the open goes on by itself.
- If the Repair Order COSTAR opens shows another number beside its RepairOrder label, nothing is changed. Enter (when the double click opens nothing) is pressed only when the wanted row is the only one selected and the list itself has the keyboard.
- COSTAR's own changes after a save ("check by hand") show as soon as the change is checked.

### Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.6.1.zip` to GitHub (the `helper` folder). Also upload the two files in the upload set's `website` folder (`Repair_Orders.html`, `repair-orders.js`) to the repo's **top** folder, replacing the old ones.
2. **Desk PC:** click the yellow line on the desk receiver. **RDP PC:** click the yellow line in the helper.
3. **Phones:** reload Repair Orders (GitHub can take up to 10 minutes to serve the new files).

### Check

1. Tap a Repair Order far down the list (one you'd have to scroll to in COSTAR): it should be on the phone in a few seconds. COSTAR's list moves a little, then jumps to it (two or three wheel turns), opens it, closes it.
2. Tap one at the top: no scrolling at all.
3. Change something small and save: "In COSTAR and checked" a few seconds after **Save to COSTAR**, then "Checked and closed".
4. Send the RDP helper's report: the day log has the time of each part.

Self-tests: **129** helper groups (3 new: the scroll arithmetic for any list length, wheel setting and list end; a made-up Work-in-Progress list read one cell a row, scrolled to and aimed at through the same accessibility calls: the active row listed twice, rows out of view placed behind the headings or the scroll bar, wrong cells, a list sorted again just before the double click, another Repair Order under the mouse, a list that doesn't take the keyboard, when to Search; and late wheel notches, COSTAR working through them one a look, on a timer or in bursts with pauses, rows made again, failing reads: an open may stop, but never aims at another row) + **16** Order Check groups. The new groups take about 9 seconds of the start after the update.

---

## Previous release notes (2.6.0) — Repair Orders on the phone

Open any Repair Order in COSTAR Tempe's Work-in-Progress on the phone, change it there, and the RDP helper types the change into COSTAR, checks it and closes the Repair Order again (Tommy, 27 Oct).

### What's new

- **Repair Orders page on the phone** (F Alt Tab menu → **Repair Orders**; also in the Job Card's menu). The list is COSTAR Tempe's Work-in-Progress: search by RO number, name, comment or PO#, and filter All / Today / This week. **New RO** opens the Job Card: a new Repair Order still starts there.
- **Open:** tap a Repair Order. The RDP helper opens it from Work-in-Progress (a double-click on its row; if that doesn't open it, the row selected and Enter), reads it and closes it again. The phone shows Customer, Car, Lines and Job (Ship Via, Date In, Customer Waiting). One read in the last 2 minutes shows at once; ↻ reads it again.
- **Change:** name, mobile (only on a Repair Order without a COSTAR account), email, address, suburb, state, postcode, PO#, comment; make/model, rego, odometer (a Repair Order without DET gets DET and its notes); each line's quantity and price, a note's words; take a line out (the bin); add items (code, quantity, price; no price = COSTAR's) and notes; Ship Via; Date In; Customer Waiting. **Review & save** lists every change. **Save to COSTAR** sends it straight in (no approval on the desk).
- **How the helper types it:** it opens the Repair Order and first checks that nothing in it changed since the phone read it. If something did, nothing is typed: the phone shows COSTAR's copy and keeps your changes to check and save again. It finds every box before typing anything. Then: the line changes; the lines taken out (a click on the item code, then Delete; if that does nothing, COSTAR's own right-click menu for the line → Delete; COSTAR asking "delete this line?" with Yes and No is answered Yes, any other question stops it, and so does a line that only loses its code); the new lines; the car; the customer boxes; Ship Via; Date In; Customer Waiting. Then it reads the whole Repair Order again, compares it with what was asked, and closes it (it stays in Work-in-Progress). Nothing is saved, sold or printed.
- **When it stops part way:** if nothing was typed yet, the Repair Order is closed again and the phone says nothing changed. If something may have been typed, the Repair Order is left open in COSTAR Tempe and the phone lists what may already have gone in; check it, then close it in COSTAR or with **Close it in COSTAR** on the phone. **Read it again** keeps the changes that aren't in yet; new lines from that save are left out (they may be in already) and the phone says so.
- **A save never goes in twice:** going back, locking the phone, a reload or a lost signal while it saves doesn't stop it or send it again. The phone follows that same save and shows how it ended when you open the Repair Order again. "Lost contact" → **Check again** asks about that same save. Another save of that Repair Order waits until it has ended.
- **When it runs:** as for phone jobs. Repair Orders on (RDP helper → Mobile jobs tab → **Repair Orders from the phone**, ticked), COSTAR Tempe (Branch 11) selected in the RDP helper and showing Work-in-Progress with no Repair Order open, nothing else being typed, the Online orders tab closed, and nobody using the RDP PC for 10 seconds. Someone touching the RDP PC while a Repair Order is being opened stops it there (nothing more is clicked or pressed). The list can be read while COSTAR is busy: it then comes from Order Check's last read (up to 15 minutes old; the phone says so).
- **Desk receiver:** a **Repair Orders** tab (what phones asked and how it went) and an **RO** chip.
- Changes not saved yet stay on the phone as a draft for 24 hours.

### Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.6.0.zip` to GitHub (the `helper` folder). Also upload the six files in the upload set's `website` folder (`Repair_Orders.html`, `repair-orders.js`, `repair-orders.css`, `costar-client.js`, `Fitment_Planner.html`, `index.html`) to the repo's **top** folder.
2. **Desk PC first:** click the yellow line on the desk receiver. The phone page needs the 2.6.0 desk.
3. **RDP PC:** click the yellow line in the helper.
4. **Phones:** reload F Alt Tab (GitHub can take up to 10 minutes to serve the new files). Repair Orders uses the phone's existing desk connection (the Job Card QR); a phone that isn't connected is sent to the Job Card to scan it.

### Check on the first Repair Orders

Start with a Repair Order that doesn't matter (a test one).

1. Phone → Repair Orders: the list matches COSTAR Tempe's Work-in-Progress; search finds it by number and by name.
2. Tap it: COSTAR opens it, the phone shows it, COSTAR closes it again. If it doesn't open, send the RDP helper's report.
3. Change one quantity and save: the phone ends on "Checked and closed". Open it in COSTAR: that quantity changed and nothing else.
4. Take a line out, add an item and a note, change Date In and tick Customer Waiting, save: the same check. If a line can't be taken out, the phone says so and the Repair Order stays open: send the report.
5. Read it on the phone, change it in COSTAR by hand, then save from the phone: "COSTAR's copy changed", nothing typed.

Self-tests: **126** helper groups (9 new: reading and fingerprinting a Repair Order, Date In formats, the change rules, the after-check, the questions answered and the RO number, the desk queue, the phone routes, the held poll, body sizes) + **16** Order Check groups. Opening, typing and taking lines out can only be checked in COSTAR on the RDP PC.

---

## Previous release notes (2.5.3) — SHOP and waiting

Phone jobs get **Ship Via SHOP** and **Customer Waiting** ticked, and F Alt Tab on a phone has a **Job Card** button (Tommy, 26 Oct).

### What's new

- **Phone jobs: Ship Via SHOP for every customer.** Before, only customers with a COSTAR customer number got SHOP. Online pickups keep that rule; deliveries keep their own Ship Via.
- **Phone jobs: Customer Waiting ticked.** Last, after the job's final check. The helper finds the tick box by its name, reads whether it's ticked, clicks it once if not, and checks that COSTAR kept the tick. If it can't find the box, can't read it, or COSTAR doesn't keep the tick, the log says to tick it by hand; the job still finishes. If COSTAR opens a window when it's ticked, the helper leaves that window for you.
- **F Alt Tab on a phone: Job Card button.** Bottom right, with how many products are on the card (it updates as soon as a tyre is added). One tap opens the Job Card. Desktop screens keep the menu link only.

### Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.5.3.zip` to GitHub (the `helper` folder). Also upload the three files in the upload set's `website` folder (`index.html`, `F_alt_tab.js`, `allaround.css`) to the repo's **top** folder, replacing the old ones.
2. **RDP PC:** click the yellow line in the helper. **Desk PC:** click the yellow line on the desk receiver (its own copy of the website updates with it).
3. **Phones:** reload F Alt Tab (pull down to refresh). GitHub can take up to 10 minutes to serve the new files.

### Check on the first jobs

1. A phone job for a new customer: Ship Via shows SHOP and Customer Waiting is ticked; the log says "Entered Ship Via: SHOP." and "Ticked Customer Waiting."
2. A phone job for an existing customer: the same.
3. F Alt Tab on a phone: add a tyre; the Job Card button shows 1; tap it and the Job Card opens with that tyre.
4. If the log says "Customer Waiting box not found", tell Claude what the box is called on the Repair Order.

Self-tests: **117** helper groups (1 new: finding Customer Waiting by its name) + **16** Order Check groups. The click itself can only be checked in COSTAR on the RDP PC.

---

## Previous release notes (2.5.2) — eBay RO closes

eBay Repair Orders close by themselves once they're in (Tommy, 26 Oct).

### What's new

- **eBay: the Repair Order is closed after entry.** When an eBay order is in and the final check found nothing to check by hand, the helper clicks out of the item lines first (the PO# field, its text unchanged), as your click on Close does, so COSTAR keeps the last line. It checks the total once more, then closes the Repair Order the same way **Next Order** closes a reviewed phone job. The order stays in COSTAR Sydney's Work-in-Progress; nothing is saved, sold or printed.
  - Left open when something needs checking by hand (its CHECK BY HAND note says what).
  - If COSTAR asks anything when it closes, the helper doesn't answer: the order shows **CHECK BY HAND: close it by hand**.
  - RDP helper → eBay orders tab → **Close each Repair Order once it's in** (ticked). Untick it to leave them open as before.
  - The desk says "entered and closed (it's in Work-in-Progress)".
- **Desk after an update:** if the old receiver is still closing, the new one waits up to a minute for its port ("Waiting for port 8790 …") instead of stopping with "Only one usage of each socket address" (25 Oct). After a minute it says which port is taken and what to do.
- Online orders and phone jobs are unchanged (left open for review).

### Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.5.2.zip` to GitHub (the `helper` folder; latest.json replaces the old one).
2. **RDP PC:** click the yellow line in the helper. **Desk PC:** click the yellow line on the desk receiver; if it shows "Waiting for port …", give it a moment.
3. **eBay PC:** nothing to do; extension 1.4.2 stays.

### Check on the first orders

1. Let one eBay order go in: its Repair Order closes by itself and the desk says "entered and closed". Open it from Work-in-Progress: every line is there (tyre, F, M E, M BUY, M DFE) with the notes' words, plus Ship to, Rebill to EBAY with Card#, and SA / SA.
2. If a closed order ever comes back missing its last line (M DFE), untick **Close each Repair Order once it's in** and tell Claude.

Self-tests: **116** helper groups (1 new: the close setting) + **16** Order Check groups. The close itself can only be checked in COSTAR on the RDP PC.

---

## Previous release notes (2.5.1) — notes saved

Note lines now keep the helper's words after the Repair Order is closed and opened again (Tommy, 25 Oct: EBAY ITEM # and EBAY BUYER NAME came back empty, and so did DET's notes and M C).

### What's new

- **Notes are saved.** COSTAR only keeps a note line's words when a key is pressed in that line. The helper put the words in directly, so they showed, but closing the Repair Order brought back COSTAR's own text. Now, once the words are in, the helper presses **A** and then **Backspace** at the end of the line (what you do by hand), checks the line reads exactly right, and only then leaves it. Every note line it fills gets this:
  - eBay orders: `M E` EBAY ITEM # and `M BUY` EBAY BUYER NAME;
  - online orders: DET's MAKE/MODEL and REGO NO, `M C` TO SUIT, `M PC` PAYING BY;
  - phone jobs: the note lines and Additional notes.
- **If it goes wrong, it stops:** if the A doesn't show up, or doesn't go away again, the order stops and names the note line to check (an extra letter may be at its end). A Stop (Ctrl+Alt+F10) pressed in the middle waits the moment it takes to take the letter back. A Retry (eBay, online or phone job) writes and confirms a note again even when it already shows the right words, or its words and the extra letter.
- A note longer than COSTAR's line allows (nobody could type the extra letter) goes in the old way with a **CHECK BY HAND** note: COSTAR may not keep it, so shorten it by hand. The note shows with the finished order: on the desk and the eBay PC for eBay orders, on the desk for phone jobs, on the Online tab for online orders.
- **Desk certificate:** the desk now hands out the certificate that really signed its HTTPS certificate ("Install the PC's certificate" on the eBay PC and phones, and the phone pairing page). On 25 Oct a second Setup-Desk run had left a different one in the download, which gave `ERR_CERT_AUTHORITY_INVALID` on the eBay PC. Nothing to redo: pairings stay as they are.
- Each note line takes a moment longer (two key presses, each checked).

### Install

1. Upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.5.1.zip` to GitHub (the `helper` folder; latest.json replaces the old one).
2. **RDP PC:** click the yellow line in the helper. **Desk PC:** click the yellow line on the desk receiver.
3. **eBay PC:** nothing to do; extension 1.4.2 stays.

### Check on the first orders

1. Let one eBay order go in, close its Repair Order and open it again: `EBAY ITEM # …` and `EBAY BUYER NAME: …` still have the order's words, with no extra letter.
2. Do the same with one online order: MAKE/MODEL, REGO NO and TO SUIT keep their words.
3. If a note line ever comes back without its words, send Claude a screenshot of the reopened Repair Order and say which order it was.

Self-tests: **115** helper groups (2 new: the desk certificate, and a note stopped during its key press) + **16** Order Check groups. Checked by a separate reviewer in two rounds; its findings are fixed (VALIDATION.md). The key press itself can only be checked in COSTAR on the RDP PC. The upload no longer contains the `Tests` folder (test files only; nothing on the PCs uses it).

---

## Previous release notes (2.5.0) — eBay orders

eBay orders go into COSTAR by themselves now (Tommy, 23 Oct). On the eBay PC, the 404 extension's order panel has a **Send to COSTAR** button. One click hands the order to the desk PC; the RDP helper types it into a **new Repair Order in COSTAR Sydney (Branch 1)** and leaves it open for review.

### What goes into the Repair Order

As in the example RO 07497644 (22 Oct), with Tommy's rules:

| Where | What |
| --- | --- |
| Customer | **Phone first** (the buyer's mobile). A matched COSTAR account keeps its account and name; otherwise the buyer's name. Address, suburb, state, postcode and the eBay email are the buyer's. |
| PO# | The eBay order number, e.g. `12-34567-89012`. |
| Comment | `EBAY DFE`, always (the consignment number is added later by someone else). |
| Ship to | The buyer: name, address, eBay email, mobile. **Ship Via `DFE`**. |
| Rebill to | `EBAY` in Rebill to Customer: COSTAR fills EBAY PAYMENTS, its note and **Terms 7INV** by itself. **Card#** = order number + order date, e.g. `12-34567-89012 23/10/26`. |
| Written By, Salesperson | `SA` and `SA`. |
| Lines (an empty line between each) | 1: the tyre (eBay custom label = COSTAR code), its quantity and the **eBay price** · 3: `F` freight (the eBay postage; no F line when postage is free) · 5: `M E` `EBAY ITEM # 175288170173` (one per item) · 7: `M BUY` `EBAY BUYER NAME: TESTBUYER1` · 9: `M DFE` (COSTAR's own text; no consignment number). |
| Final check | Every field above read back; each line on its line with its quantity, price or text; COSTAR's total = the eBay total. Terms should show 7INV. |

The eBay price: one item = what the buyer paid for it (the eBay subtotal = total minus postage, split by its quantity). Several items (up to 4): the item prices shown on the eBay page, used only when they add up exactly to the subtotal. The subtotal and postage must add up to the order total; if they don't (a discount, fee or tax in between), or there is no subtotal and some other line has money on it, the panel says to enter that order by hand instead of guessing.

The helper never saves, sells, prints or takes payment. Repair Orders are left open for review, as with online orders.

### How it runs

- **Straight away:** each order is entered as soon as COSTAR is free and nobody has used the RDP PC for 10 seconds (checked again right before it starts). It waits while a mobile or online order is being entered, or while the Online tab is about to fill one by itself (an online order that arrives meanwhile starts right after). An online order only loaded for a manual Fill doesn't hold eBay orders up. While it waits, the eBay PC and the desk say why.
- **COSTAR Sydney** is found by itself: the one COSTAR of Branch 1 open in the Remote Desktop session (never Order Check's WIP window). Tempe stays selected for mobile and online orders. Leave COSTAR Sydney on **Work-in-Progress** (the helper clicks Add New there).
- **Never twice:** the desk keeps one entry per eBay order number. A second click, or opening the order again, only shows its status. The RDP helper also remembers every eBay order it finished. An order that was partly typed and then removed on the desk is never started again in a new Repair Order: sent again, the helper continues the Repair Order it stopped in only if nothing in it changed, otherwise it stops and the desk decides. Only **Start again in a new RO** (after checking COSTAR) enters an order afresh.
- **A stop** is safe and says why. **Retry** (desk) or **Send again** (eBay PC) continues in the same Repair Order only while nothing in it changed since the stop (Written By and Salesperson included). If its window is gone, the desk offers **Start again in a new RO** (only if the order is NOT in COSTAR) or **Mark done by hand**. A COSTAR window left open from the stop is never closed by the helper: the retry stops and says so. Stopped while Rebill to was showing: the retry first clicks Ship to (nothing typed), then checks as usual.
- **Closed mid-entry:** if the RDP helper closes (or restarts) while entering an order, the desk shows that order as stopped, never stuck as "being entered", and the next orders carry on.
- **CHECK BY HAND:** the order is finished except one thing the helper could not do safely (e.g. it could not open the Rebill to tab, Written By is locked or COSTAR didn't keep SA, or Terms isn't 7INV). The note says exactly what; it shows in amber on the eBay PC, the desk list and the RDP log.

### The windows

- **RDP helper → new eBay orders tab:** Start / Stop eBay orders (remembered between starts), the desk connection, which COSTAR it goes into, the order being entered, the log, and **Check Sydney layout (types nothing)**.
- **Desk receiver → tabs Phone jobs | eBay orders:** the eBay list (order, buyer, total, status, message), Retry, Start again in a new RO, Mark done by hand, Remove, Hide finished, **Pair eBay PC** (address + 6-digit PIN, 10 minutes) and Reset eBay pairing. An **EBAY** chip in the header: on, waiting, stopped or RDP offline.
- **eBay PC → 404 extension 1.4:** Send to COSTAR on the order panel with what will go in (`W43116 x1 @ $140.00 + freight $10.00 = $150.00`) and the order's status; the popup pairs with Tommy's PC.

### Install

1. **RDP PC:** upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.5.0.zip` to GitHub, then click the yellow line in the helper.
2. **Desk PC:** click the yellow line on the desk receiver (2.4.0+ updates itself). The desk must be 2.5.0 to take eBay orders; phones and pairing are kept.
3. **eBay PC:** extract `404-but-its-found-v1.4.zip` over the extension folder, chrome://extensions → reload arrow on the 404 card. Then pair it once (its README, or below).

### First run (about 5 minutes)

1. In the Remote Desktop session open **COSTAR Branch 1 (Sydney)** next to Tempe and leave it on Work-in-Progress.
2. In COSTAR Sydney click **Add New** (an empty Repair Order), then in the helper's **eBay orders** tab click **Check Sydney layout (types nothing)**. It reads the header, Ship to, Written By / Salesperson / Terms and the lines, switches to the Rebill to tab and back, and lists each part with OK / NO. Send Claude a screenshot if any line says NO. Close that empty Repair Order afterwards.
3. Click **Start eBay orders**.
4. **Pair the eBay PC:** desk receiver → eBay orders tab → **Pair eBay PC**. On the eBay PC: 404 icon → type the address → **Install the PC's certificate…** (open the file → Install Certificate → Current User → Place all certificates in the following store → Trusted Root Certification Authorities → Finish → Yes), restart Chrome, then type the address and PIN → **Connect**.
5. Send one real order and watch it go in; check the Repair Order before saving it as usual.

### Things to confirm on the first orders

- Several different tyres in one order get **one M E line each** (Claude's guess).
- The tyre price goes into **Net** (as for online orders); if COSTAR's List differs it shows a discount on that line.
- If COSTAR opens a window after `EBAY` (an account list), the order stops with that window captured; send the entry report.
- If COSTAR adds a line by itself (a levy), the order stops at the final check naming that line; it is fully entered: check it, then Mark done.
- If every order says "Can't send to COSTAR: what the buyer paid …", eBay's page differs from what the panel expects: send Claude a screenshot of that part of the page.
- **Before any Start again, search COSTAR Sydney for the eBay order number**, whatever the dialog says. An order that comes back with "Not entered twice" is already in COSTAR: Mark done.

Self-tests: **113** helper groups (17 new for eBay orders) + **16** Order Check groups. The eBay extension: 7 Node test groups and a full end-to-end run (the real extension in Chromium, made-up eBay pages, the real 2.5.0 desk code over HTTPS; 20 checks). Two rounds of independent review (VALIDATION.md). The COSTAR typing itself can only be checked on the RDP PC: the layout check above is its first look.

Also in this package: the website files the desk PC serves are the current ones from GitHub (Order Check board 1.6.4 with Discord alerts, the F Alt Tab page and its PC check), so an older board can't come back with this install.

---

## Previous release notes (2.4.2)

The phone job card could get stuck on its last order: **New job** only worked once the PC said "ready for review", so after a stopped order, or an order closed/removed on the desk PC (or a reset of the desk's queue), the phone kept showing the old order with no way forward.

- **New job** now works once the order is ready for review, **stopped**, **removed on the desk PC**, or **no longer known to the PC** ("Closed on the PC — start a new job"). A stopped order stays on the desk PC for Retry / Mark done / Remove there; the phone can move on.
- The status line names these states; Retry is hidden once the PC no longer has the order.
- The desk PC's own copy of the page updates with this version. **If your phones open the GitHub copy**, upload the three files in the upload set's `website\` folder to the repo's top folder as well (they replace `Fitment_Planner.html`, `Fitment_Planner.js`, `jobcard-shared.js`).
- Then on the phone: reload the job card (pull down, or close and reopen it). The stuck card shows "Closed on the PC — start a new job"; tap **New job**.

---

## Previous release notes (2.4.1)

Fixes from the first screenshot of 2.4.0 (19 Oct, 08:25). Both the RDP helper and the desk receiver offer it on their yellow line.

- **The desk PC sees the RDP helper as soon as it is open.** 2.4.0 only started talking to the desk once you clicked Start / resume mobile, so the desk said "RDP HELPER OFFLINE" while you were doing online orders. Now it says "RDP HELPER: MOBILE OFF" (amber) until you switch mobile on, phones can send cards that wait in the queue, and a job's result reaches the desk without mobile being on. Nothing is entered while mobile is off.
- **COSTAR list:** the box shows "Branch 11 (TEMPE) · PID 159312" instead of a cut-off line; the full line is in the drop-down.
- **Online orders:** after an order finishes, the line under its details says "Finished TTW… at 08:20 · waiting for the next order" (it said "No order loaded" under a full order), and the details go grey. The two hint lines no longer run off the right edge at the smallest window width.
- **Desk receiver:** the window is taller by default so the Setup card isn't cut off at the bottom; the website row fits on one line; shorter hint.
- Mobile card wording: "Desk PC connected (just now, 12 ms) · mobile off".
- Day log: while the desk PC is off, the connection error is noted on the first failure and then every 100th (about every 5 minutes) instead of every 20th.

---

## Previous release notes (2.4.0)

A rebuild of the helper's shell, asked for on 19 Oct ("recheck everything, make it more efficient, modern UI/UX, better file management, faster connection and faster process"). The entry engine that types into COSTAR is the proven 2.3.2 one; everything around it is new. Delivered by auto-update on the RDP PC (upload the two files, click the yellow line). **The desk PC receiver has to be started once from the new folder** (see "Install" below); from then on it updates itself too.

## 1. Never stuck again

The stuck mobile job of 19 Oct (MJC-…9366) showed the gap: a mobile job whose COSTAR had been restarted failed the same way on every Retry, and nothing in the app could let it go. Now:

- **Mobile tab → Release job (finished by hand):** you finished or closed that Repair Order yourself. The queue moves on (Next Order / Pinad), the helper types nothing. Works even if the desk PC still runs 2.3.x.
- **Mobile tab → Start this job again:** the saved progress is set aside (a backup is kept) and Retry selected on the desk PC enters the job from the start in a new Repair Order. Replaces "Reset unstarted job", which refused any job that had typed a field.
- **Desk PC → Mark done by hand / Remove job:** the same two exits from the desk side, also for a job the RDP helper took and then went silent on (helper closed or offline). The RDP helper is told to forget the job. A job the helper is typing right now is left alone: stop it there first.
- The old "belongs to another COSTAR instance" message now says which button to use.

## 2. The window

- **Header:** one state chip you can read from across the room — **READY**, **FILLING**, **NEEDS YOU**, **NO COSTAR** — with the order, its stage and a progress bar while an order is being entered, and one line for how the last one ended.
- **Mobile jobs tab:** a card with the desk connection (in touch, round trip), the job in hand and what it is doing; four buttons: Start / resume mobile, Stop all entry, Release job, Start this job again.
- **Online orders tab:** the order card (load, preview, options), Fill / Stop, then the log. The DET first and fitting-note choices sit next to Paying by.
- **Files & settings tab:** every folder the helper writes, with item counts, sizes and dates; Open folder; **Clean up now** (old versions, old builds, old startup logs); **Diagnostics ZIP to Desktop** (one click, ready to upload); Boss report; the long-poll setting.
- **Logs** are coloured: red stops, green finished orders, amber things to check.
- **Desk PC receiver:** the same look; the job list is a table (reference, customer, status, message) with coloured statuses; chips for Receiving, the RDP helper (in touch / mobile on or off) and Pinad; buttons grouped by what they do; and it now offers updates like the RDP helper.

## 3. Faster

- **Mobile jobs start at once.** The RDP helper used to ask the desk every 2 s. Now the desk holds the request until something happens (a job, an approval, Next Order), so a job starts the moment it is approved, and a finished/failed report reaches the desk immediately instead of on the next tick. A 2.3.x desk still works the old way. The setting is on the Files & settings tab.
- **Online orders start sooner:** the clipboard is checked four times a second while the tab is idle (it was once a second).
- **Truthful connection status:** the desk shows "RDP helper in touch 1 s ago" even when mobile entry is switched off there (before: "RDP worker offline"), and phones can send jobs while the helper is in touch; they wait in the queue. The phone page says so too ("mobile entry off, your card will wait in the queue"). If your phones use the GitHub copy of the job card, upload `Website/Fitment_Planner.js` as well; the copy the desk PC serves is updated by the install.
- Typing into COSTAR itself is unchanged: COSTAR's own time (phone search, product lookups, Add New) is what remains. Opening the next Repair Order early was looked at and dropped: COSTAR can only do one thing at a time, so Add New cannot overlap with typing.

## 4. Files

Everything now lives under **`%LOCALAPPDATA%\TempeMobileCostar`**: `reports\` (entry reports, 30 days), `diagnostics\` (masked, 180 days), `packages\` (installed versions), `runtime\` (builds), the diagnostics ZIPs and startup logs, and `settings.json` (plain settings: DET first, Order Check, preferred branch, long poll). The old `TempeCostarAutofill\Reports` and `\Diagnostics` folders are moved there once at first start (nothing is lost; if the move fails they stay in use). Clean up keeps the running version, the current one and the newest other one.

## 5. Code

`CostarAutofill.cs` (175 KB) is split into `Native.cs`, `Runner.cs`, `Runner.Customer.cs`, `Runner.Grid.cs`, `Runner.Online.cs` and `OnlineTab.cs`; the online model checks live in `OnlineModelTests.cs`; new `AppData.cs` (folders, cleanup, settings) and `Ui.cs` (the look). 22 source files, listed in Build.ps1.

## Install

1. **RDP PC:** upload `helper/latest.json` and `helper/Tempe-COSTAR-Helper-v2.4.0.zip` to GitHub, reopen the helper, click the yellow line, Yes.
2. **Desk PC (once):** extract `Tempe-COSTAR-Helper-v2.4.0.zip` into a new folder and run `Start-Desk.cmd` from it (no setup needed again; the pairing, queue and settings are kept). Close the old receiver first. From 2.4.0 on the receiver offers updates itself.
3. The page `testrun.html` is unchanged.

Self-tests: **96** helper groups + **16** Order Check groups. New ones cover the desk's Mark done / Remove / forget, the released job's close, the held worker poll, the header's progress, the clean-up plan and the settings file.

Before delivery: compiled here with a real C# 5 compiler (0 errors); 92 of the 96 groups and all 16 Order Check groups run here (the other 4 need Windows); the diff reviewed by a separate reviewer. The new window could not be looked at here (no Windows): the first start on the PC is its first look, so please send a screenshot if anything is cramped or misplaced.

---

## Previous release notes (2.3.2)


Fixes TTW1730569 (10 Oct). It stopped right after its first tyre: "The chosen item line moved before typing". 2.3.0 stopped at the same point on 9 Oct. Delivered by auto-update: upload the two files to GitHub, then click the yellow line in the helper.

## 1. Why DET first kept stopping

COSTAR **opens the line you are on**. After a tyre and its quantity, that line's description box grows to 160 px and every line below it moves about 140 px down, until focus goes somewhere else. DET's notes also move one of COSTAR's line boxes from the bottom of the grid up to line 7.

2.3.0 and 2.3.1 found a line by where it was. With line 1 still open, line 2 was "not in its place", so both stopped at the second item. The control captures from TTW1730569 show exactly this.

## 2. What 2.3.2 does

- **Line N is the Nth box from the top.** The helper counts all 25 of COSTAR's line boxes, with line 1 right under the ITEM heading. Where COSTAR draws them doesn't matter.
- The next item goes on the line after the last filled line above DET (1, 2, 3 …).
- After clicking that line, it checks it is **the same box with the same boxes above it**, still empty and still focused, before typing. 2.3.1 compared positions here; that is what stopped.
- Replayed on the real TTW1730569 captures: with line 1 open, the helper picks line 2, and line 2 is still line 2 after line 1 closes.

## 3. A switch for the old way: "DET first"

The Online tab has a new tick box, **DET first (items above DET)**, ticked by default.

- **Ticked:** DET on line 6 with its notes on lines 7–9, items from line 1. This is what you asked for on 9 Oct.
- **Unticked:** the old way from before 2.3.0. The items go in first, then DET and its notes after them, then PAYING BY.
- The choice is remembered. It only matters while DET isn't typed yet: a stopped order that already has DET keeps it where it is.
- If an order can't have DET first (COSTAR's lines can't be counted, or line 6 is already used), that order gets DET last by itself, and the log says why.
- Mobile jobs keep DET first.

Self-tests: **90** helper groups + **16** Order Check groups. New ones cover line numbers by count (an open line, a box moved by DET's notes, a stray, missing or scrolled box), the next line above DET, the 10 Oct grid with the tyre's line open, the final DET check for DET first, DET last and items after the notes, and the end-of-day lines.

Before delivery:

- The code was compiled here with a real C# 5 compiler: 0 errors.
- 86 of the 90 groups and all 16 Order Check groups were run. The other 4 need Windows.
- The new grid code was replayed on the real 10 Oct captures.
- A separate reviewer checked the change and found nothing blocking.

---

## Previous release notes (2.3.1)

Fixes the first 2.3.0 order (9 Oct, TTW1730549). It stopped right after its tyre ("COSTAR's item lines are not laid out as expected, so line 2 cannot be found safely"), and its retry was refused as "already in COSTAR". Also fixes a 2.3.0 bug that would have stopped every order in a branch other than 11. Delivered by auto-update: upload the files to GitHub, then click the yellow line in the helper.

## 1. Branch 1 (any branch) really works now

2.3.0 still checked "Branch 11" in one place while typing, so an order in any other branch would have stopped at its first step with "The original Repair Order was closed or changed". The check now uses the selected COSTAR's branch.

## 2. Items go above DET reliably

- 2.3.0 only counted COSTAR's lines while all 25 boxes were exactly evenly spaced. Right after a product and its quantity, COSTAR redraws its grid, and the very next look had the boxes out of step.
- Now the helper only decides on a grid that holds still (two looks in a row, same boxes, places and texts). It learns where line 1 is from the new, empty Repair Order, and a box drawn a pixel or two off still counts as its line.
- Just before typing an item code, the line is checked again: still empty, still in place.
- If the lines stay out of place, the order is **finished rather than stopped**: the remaining items go in after DET's notes, the final check still covers everything, and the log says so. The diagnostics record where the boxes were, so it can be fixed for good.
- DET missing, doubled or moved stops entry, as does a grid that keeps changing.

## 3. A stopped order can be sent again, safely

- Order Check lists a Repair Order while it's still open, so 2.3.0 refused the retry ("already in COSTAR as document …").
- Now the helper continues an order only in the Repair Order it stopped that order in (since it was last started), and only if **nothing in it changed** since the stop: customer, address, Time in, Ship Via, every line, quantity, price and note.
- Anything else is left alone with a clear message ("finish it in COSTAR"): a Repair Order you typed or finished by hand, one you changed after the stop, or any order after the helper restarts. A listed order is never entered afresh.

Self-tests: **87** helper groups + **16** Order Check groups (new: lines found by their place; the stopped-order check). Before delivery the code was compiled here with a real C# 5 compiler (0 errors), 83 of the 87 groups plus all 16 Order Check groups were run (the other 4 need Windows), and the change was reviewed three times by a separate reviewer.

---

## Previous release notes (2.3.0)


Two changes Tommy asked for (9 Oct 2026). Delivered by auto-update: upload the files to GitHub, then click the yellow line in the helper.

## 1. Works with any COSTAR branch open on the PC

- The COSTAR list shows **every** COSTAR open in the Remote Desktop session with its branch, e.g. "Branch 11 (TEMPE)", "Branch 1 (…)". Pick the one to enter into.
- Every Repair Order the helper opens, fills or checks must belong to the **selected branch**. If COSTAR shows an order from another branch, entry stops.
- The helper remembers the branch you used last and selects it at the next start (if exactly one COSTAR of that branch is open).
- **Mobile jobs** carry no branch, so they go into the selected COSTAR. If you switch branch while mobile is running, mobile **pauses** and the log says so. Click **Start / resume mobile** to take mobile jobs into the new branch. The mobile line shows "jobs go into Branch …".
- A new Repair Order in another branch may show that branch's own suburb. That's accepted (Branch 11 still expects TEMPE).
- **Tempe Orders page** (upload `testrun.html`): a **Store** picker next to Today/Tomorrow lists every store in the order list, remembered in Chrome. Any store's pickups can be sent.
  - Before typing, the helper checks the order's store against the selected branch ("Tempe NSW" ↔ Branch 11 Tempe). If they don't match, it asks first, and names the right branch if that COSTAR is open. Your answer is remembered until the helper closes.
  - The helper window comes forward for that question, and nothing else is loaded or started until you answer it.
  - Pickups from stores other than Tempe are sent in a new format that helpers older than 2.3.0 refuse ("Update both the HTML page and Windows helper"), so they can never be typed into Branch 11 by an old helper.
  - The COSTAR check (✓ / ≈ / ✗) still covers Tempe only, because Order Check reads the Tempe COSTAR.

## 2. DET first, on line 6

COSTAR could lose DET's notes when DET was entered last. Now, for online pickups and mobile jobs:

1. **DET goes in first, on line 6.** Its MAKE/MODEL, REGO NO and ODOMETER notes appear directly under it (lines 7–9), followed by PAYING BY or the job card notes if any.
2. **Then the items fill lines 1 down**: wheels, tyres, M FB, wheel alignment.
3. With more than four item lines, DET moves down so one empty line always stays between the last item and DET (5 items: DET on line 7).

The helper checks every step. If DET or its notes land anywhere else, entry stops and nothing is guessed. Before typing on a numbered line, it checks that COSTAR's 25 lines are evenly laid out. Deliveries (no DET) are unchanged.

A stopped online order resumes in its own Repair Order as before, including orders started by 2.2.x (DET straight after the items): any missing items go in after everything, the old way. If it stopped right after DET was typed, the resume clicks out of DET once so its notes appear. A **mobile** job half-entered by an older version still can't be resumed by 2.3.0 (the step order changed); finish it by hand. Jobs that hadn't started a step continue normally.

## Safer updates

If an installed update can't build or pass its self-tests on this PC, it now **sets itself aside**: the window says so, and your usual shortcut starts the version installed before it again (2.2.1 for this update). Send the startup report to Claude.

The update offer is now a **yellow, bold line** under the buttons: "UPDATE x.y.z READY - CLICK HERE TO INSTALL". This applies to the update after 2.3.0; for 2.3.0 itself, the 2.2.1 grey line still offers it.

Self-tests: **85** helper groups + **16** Order Check groups. New for this release: before delivery, the code was compiled here with a real C# 5 compiler and 81 of the 85 groups plus all 16 Order Check groups were run (the other 4 need Windows).

---

## Previous release notes (2.2.1)


**The first version delivered by auto-update.** Once these files are on GitHub, 2.2.0 offers it in its status line.

## Fixed: "COSTAR check unavailable … (setup)" while Order Check reads normally

Order Check serves the boards on **127.0.0.1:8795**. On the shared RDP server that address is shared by **every Windows session**, so another Order Check held it. Most likely an old standalone copy left running in another session, or another user's.
- Before, your helper's Order Check couldn't open its server. The error was then overwritten by "Reading normally", so you never saw it, and the Tempe Orders page was talking to the other copy, which was never set up.
- Now, if 8795 is taken, Order Check **uses the next free port** (8796, up to 8804). Its tab **keeps showing** what holds 8795 (for an old copy: its version and state). **Open board** opens the board on the right port automatically.
- The **Tempe Orders page** asks every Order Check on the PC and uses the one that has actually read COSTAR. Any other copies are listed under the COSTAR check, so you know they're there. Every helper's "entered" orders count.

**To clear the old copy for good:** on the RDP server open Task Manager → Users. Find your other session (or ask whoever owns it) and end **OrderCheck.exe** or **TempeMobile.exe** there, or sign that session out.

Self-tests: **80** helper groups + **16** Order Check groups (new: the server moves aside when its port is taken).

---

## Previous release notes (2.2.0)


Four improvements Tommy chose (6 Oct): resume, missing-order check, auto-update, time-saved report.

## 1. A stopped online order continues where it stopped

Before, a retry opened a **new** Repair Order and left the half-done one behind. Now the helper remembers which Repair Order a stopped order was in and **goes back to it**:
- the customer lookup is skipped (the account is already on the order);
- item lines already there are kept (only their quantity and price are checked), and missing ones are added;
- DET or Freight is not added twice, and notes are filled in only if they differ.

It also recognises its own half-done order after a restart (PO# = the order number, same phone), as long as that's the only open Repair Order. The strict final check still catches anything unexpected, such as a duplicate row.

## 2. Missing orders: Tempe Orders page (upload `testrun.html` to GitHub)

The **Today Orders** and **Tomorrow Orders** lists now check COSTAR. Each order shows:
- **✓ In COSTAR**: its order number is in PO# or the comment, or the helper entered it (doc number shown when known);
- **≈ Probably in COSTAR**: no order number, but a job with the same amount (within $1 or 2%), with the doc number(s) to check;
- **✗ Not in COSTAR**, with a **Make it** button that sends it to the helper.

**Make all missing** at the top sends them one after another; turn on Fill automatically first. The list re-checks every 2 minutes, or click **Check again**. It needs **Order Check on** in the helper (second COSTAR on Work-in-Progress). The helper also lists the orders it entered itself, so they show as in COSTAR straight away.

## 3. Auto-update

The helper checks your GitHub page (`helper/latest.json`) at start and every 6 hours. When there's a newer version, the status line at the top says **"Update x.y.z ready: click here to install"**:
1. it downloads the ZIP;
2. it checks the ZIP against the fingerprint in latest.json, then checks **every file** against the package list;
3. it installs beside this version and restarts into it.

It never updates during entry, and only accepts downloads from your GitHub helper folder. Older folders and shortcuts start the newest installed version by themselves (Launch.ps1 hands over).

**To publish a version:** upload its ZIP and `latest.json` to the `helper` folder of the `tempe` repo. I provide both with every release.

## 4. Time saved (for the boss)

- The status line shows **"Today N orders by the helper, about M min saved"**.
- **Boss report** (top row) opens a one-page report: today, last 7 days, last 30 days and a day-by-day table. It shows orders, mobile jobs, how many needed a hand, the helper's time per order and typing saved. No customer details. Print it or save it as PDF from the browser.
- Typing saved = orders × minutes by hand: 4 min per online order and 4 min per mobile job to start with. Change them in `time-saved.json` in the helper's Diagnostics folder (created the first time you open the report).
- The end-of-day report shows it too.

Self-tests: **80** helper groups + **15** Order Check groups.

---

## Previous release notes (2.1.0)


Built from Tommy's video (6 Oct) of entering the order that kept failing (TTW1730345).

## What the video showed

The "two accounts" failures were really **"Nothing found!"**. COSTAR's phone lookup only searches **Tempe (Branch 11)**, and this customer's accounts are in other branches. So COSTAR opened its **Search for an Existing Customer** window with no results and **OK greyed out**. There was no row to pick, which is why 2.0.x couldn't choose one.

What Tommy did by hand, and what the helper now does the same way:
1. Type the phone into the Search window's **Phone** box.
2. **Clear the Branch box** (it says "11").
3. Click **Search**. The accounts from every branch appear, **row 1 highlighted**, OK available.
4. Press **OK**, taking row 1. The account, name, address and email load into the order.
5. Type **SHOP** into **Ship Via**.

If no branch has the phone, the helper presses **Cancel** and enters the order's customer details as a new customer, the same as before.

## New rule: Ship Via = SHOP

Any order whose customer has a **COSTAR customer number** (Account# filled in after the phone lookup) gets **SHOP** in **Ship Via** as the last step. This applies to:
- **online pickups:** just before the final check;
- **mobile jobs:** right after the final check.

It does not apply to:
- **online deliveries:** they keep the Ship Via from the order;
- **new customers:** no customer number.

If COSTAR won't take it, the order still finishes and the log says to enter SHOP by hand.

Self-tests: **77** helper groups + **15** Order Check groups. The new test rebuilds COSTAR's Search window from the layout recorded on 5 Oct.

## Test

- Send TTW1730345 again. The log shows "No account for this phone in Tempe (Branch 11): searching every branch", then row 1 is chosen, then "Entered Ship Via: SHOP".
- Any pickup for an existing customer ends with Ship Via SHOP. A brand-new customer's order has no SHOP.

---

## Previous release notes (2.0.3)


## How 2.0.2 did on 5 October (end-of-day report)

- **Lag fixed:** helper memory 42–56 MB all session, CPU 0.0% average (0.1% peak), no handle growth.
- **9 online orders in 5 minutes with Fill automatically:** 8 entered first or second time, about 7 s each from Send to done (entry itself about 5.2 s).
- **Time in = booking time:** worked on all 8 (8:00 am, 10:00 am, 2:30 pm…).
- **Problems:**
  - The two-account customer (TTW1730345) failed 3 times.
  - One "Release Shift/Ctrl/Alt" stop.
  - 7 "Repair Order not empty" entries made the day look like 42% success. They weren't failures: each was the helper checking the previous order's Repair Order before opening a fresh one.

## What 2.0.3 fixes

| Problem | Cause | 2.0.3 |
|---|---|---|
| Two accounts on one phone: "OK did not become available" | The helper searched the list's panels **smallest first**. It found the small search-criteria panel (a table with no customer rows) and **gave up there**, never reaching the results grid. | Every panel is tried, **largest first**, then one level deeper. Both ways COSTAR can expose rows are handled, header rows are skipped, and up to 3 top rows are tried, stopping as soon as OK lights up. The click lands near the row's left edge. If it still fails, the grid's structure (no names or values) goes into the report. |
| "Release Shift/Ctrl/Alt/Windows keys" | Checked once; a key down for a moment stopped the order | Waits up to 3 s for the key to be released. If it really stays down, the message names the key and explains how to clear a Remote Desktop stuck key. |
| An extra check before every order | Each order first tried the previous order's Repair Order (left for review) | The helper remembers which order it filled last and goes straight to Add New: about 0.5 s faster per order. |
| Report counted checks as failures | | Checks are counted separately. The completion % covers real orders only. |
| "Order Entry" logged as a COSTAR prompt on every order | It's COSTAR's own new-order window | Not logged any more |
| Report ZIP after each order | Best compression on the entry thread | Fastest compression: the next order starts sooner |

Self-tests: **76** helper groups + **15** Order Check groups.

## Test tomorrow

- Send the two-account customer (TTW1730345's phone) with Fill automatically. The first account should be chosen ("Two or more accounts share this phone: chose the first one").
- Send a batch of online orders. The log shows "online_skip_review_ro" instead of a check, and each order is a little faster.

---

## Previous release notes (2.0.2)


2.0.1 made COSTAR and the RDP session laggy. This release is only about speed and memory. No new features.

## What was causing the lag

Every time the helper reads a COSTAR field, COSTAR's screen thread has to answer it. While COSTAR is busy (searching a phone, loading an account, opening an order) it can't answer:
- The helper waited up to 3 s for COSTAR, then read about 250 fields **anyway**, one queued request per field, each waiting 100 ms.
- During a slow phone search it repeated that every 30 ms.
- COSTAR then had to work through the pile after its search, so everything froze.
- 2.0.1 made those waits 5× longer (15 s), so the lag got much worse.

## What 2.0.2 changes

| # | Change | Effect |
|---|---|---|
| 1 | **No reads while COSTAR is busy.** One tiny "are you there?" first; no field reads unless COSTAR answers. If a read fails because COSTAR stopped answering, the rest of that pass is skipped. | No request pile-up |
| 2 | Waits poll every 80–150 ms instead of every 30 ms, and back off while COSTAR is busy | Far fewer reads |
| 3 | The 1 ms Windows timer is no longer switched on during entry. On Windows Server 2012 it applied to the **whole server**. | Less load on everyone's session |
| 4 | **Order Check is OFF unless you turn it on** (button in its tab, remembered) | No background thread, server, timer or COSTAR reads by default |
| 5 | Order Check never reads the COSTAR the helper types into | No two jobs on one COSTAR |
| 6 | Mobile poll every 2 s (was 1 s); COSTAR availability checked at most every 3 s | Half the background work |
| 7 | JSON engine reused instead of a new one per message | Less memory churn |
| 8 | Smoother garbage collection (sustained low latency) | Fewer pauses |
| 9 | Fixed a small handle leak in Order Check's window search | |

## See it working

The status line under the COSTAR list now shows **Helper NN MB, CPU N%**, updated every 5 seconds. Expected: about 30–80 MB, and CPU under 1% when idle.

The day log records memory, CPU, handles and GDI/USER objects every 5 minutes and after each job. The END OF DAY page shows start, peak and now, and flags growth (possible leak) or high CPU. Each run also records how many reads were held back because COSTAR was busy (`costar_busy_skips`).

## Order Check

It's off after this update. To use it, open the **Order Check** tab, click **Turn Order Check on**, and choose a **second** Tempe COSTAR window (not the one the helper types into: Order Check refuses that one).

Self-tests: 75 helper groups + 15 Order Check groups. The Time in feature from 2.0.1 is unchanged.

---

## Previous release notes (2.0.1)


Bug-fix release after the first 2.0.0 runs (4 Oct 00:37–00:56), plus **Time in = booking time**.

## Fixed

| What you saw | Why | 2.0.1 |
|---|---|---|
| "COSTAR's search did not cancel" (the two-account customer) | COSTAR's phone search was slow (2–2.5 s+, COSTAR busy 6 s). After 3 s of "SEARCHING…" the helper pressed Escape, which **cancelled COSTAR's own search**, including the account list it was about to show. | A running search is left alone for up to 15 s. Escape is never sent while COSTAR is still searching. |
| "COSTAR did not commit the field after Tab" | A fixed 2.5 s limit; COSTAR took 2.5 s. | Up to 8 s. Normal fields still move on in milliseconds. |
| "The target field is covered" (3 of 7 runs) | Always the first click on a **brand-new** Repair Order; a retry on the same order always worked. | Waits up to 1.5 s for the field to clear, brings COSTAR back once if another app is on top, and records what was covering it. |
| "A bit slower" | After every job the helper emptied its own memory (1.8.0), so the next job started cold. Each online fill also made a web call from the helper to its own Order Check. | Memory is only cleaned when it has really grown. The duplicate check reads Order Check's data directly. |
| Order Check could read COSTAR while the helper was typing | Two jobs on one COSTAR. | Order Check waits while the helper is entering an order. |
| Add New took 31 s once (reviewed order still open) | Unknown | Any COSTAR prompt shown during Add New is now recorded in the day log. Nothing is pressed. |

The duplicate-check note no longer says "needs Order Check 1.4.0". It says whether Order Check has read the WIP list yet, or whether the list has no PO column.

## New: Time in = booking time (online pickups)

COSTAR fills **Time in** with the moment the Repair Order was opened (e.g. 12:50). For online pickups the helper now enters the **booking time** from the website order instead, in COSTAR's own format ("10:30 am"). Delivery orders and mobile jobs are unchanged. If COSTAR won't take it, the order is still finished and the log says "Set it by hand".

Self-tests: **74** helper groups + **15** Order Check groups.

---

## Previous release notes (2.0.0)


**One app now does everything:** mobile jobs, online orders and Order Check. Order Check is no longer a separate program. It is the third tab in the helper, built, started, self-tested and reported together with the rest. Replaces helper 1.9.0 and the separate Tempe Order Check 1.4.0.

| Tab | Does |
|---|---|
| **Mobile jobs** | Phone job cards → COSTAR (through the desk receiver) |
| **Online orders** | Website orders → COSTAR (Fill / Fill automatically) |
| **Order Check** | Reads a second Tempe COSTAR's Work-in-Progress list every 2 minutes and serves the Order Check board. Runs in the background whichever tab is showing. |

How the parts work together inside one app:
- **One COSTAR choice.** Pick the Work-in-Progress window in the Order Check tab, and the helper immediately switches its own entry to the *other* Tempe COSTAR. It never types into the WIP window.
- **No duplicate online orders.** Before filling, the helper checks the Order Check data. If that TTW number is already in Work-in-Progress, it refuses and names the document.
- **Helper jobs tagged on the board.** Jobs the helper typed in show "Online" (TTW) or "Mobile" (MJC) on the board.
- **One end-of-day report.** Order Check's start and status are in the same day log as everything else.

## Switching from two apps (once)

1. **Close the separate Order Check app:** right-click its tray icon, then **Exit**. Stop using `Start-OrderCheck.cmd`. If it is still running, the Order Check tab tells you to close it.
2. Extract **Tempe-COSTAR-Helper-v2.0.0** into a fresh folder in the RDP session and run **Start-RDP.cmd**. Title **2.0.0 - one system**. The self-tests report **73** helper groups and **15** Order Check groups.
3. **Order Check tab:** your WIP window choice, read interval and Mark OK marks carry over (same settings folder). If it says "Needs setup", choose the second Tempe COSTAR that stays on Work-in-Progress.
4. **Board on GitHub** (only if you haven't uploaded the 1.4.0 board yet): upload `Order_Check.html`, `order-rules.js`, `order-check.js` and `share.js` from this package's `Website` folder to your `tempe` repo.
5. **Chrome extension** (only if not done before): `OrderCheck\Extension-update` holds "Tom does it all" 1.0.2. Copy over the two files, reload the extension, and allow file URLs.

Sharing setup and notes are in `OrderCheck\` (`Sharing\SHARING-SETUP.md`, `ORDER-CHECK-NOTES.md`).

### Order Check tab
Same controls as the old app (WIP COSTAR window, read interval, shop hours, press Search before reading, Read now, Open board, Pause), without the tray icon or Exit button: closing the helper stops it. The board data is still served at `http://127.0.0.1:8795/wip.json` (this PC only), so the board in Chrome works exactly as before.

---

## Previous release notes (1.9.0)


Replaces 1.8.3. Ships together with **Tempe Order Check 1.4.0**.

## What 1.9.0 fixes (your 3 October 23:39–23:41 runs)

**"Fill automatically" didn't fill.** Windows only lets the app you are using change the active window. With auto-fill the order arrives while you are in Chrome, so the helper's request to bring COSTAR forward was refused. That caused "COSTAR is not ready to open a new order", "the target field is covered" and lost focus. Clicking Fill yourself worked because the helper was then the active app.
- COSTAR and the Repair Order are now brought forward the reliable way, even from Chrome.
- A brief moment with no active window (one window closing, another opening) is waited out instead of stopping entry.
- If another app takes the screen during entry and **nobody is typing**, the helper takes COSTAR back once (at most 3 times per order). If you are typing, it stops instead, so your keys never land in COSTAR. A COSTAR popup is never bypassed.
- Add New hands over the new Repair Order only after its window has stayed the same for 300 ms. On 3 Oct, COSTAR replaced the first window it showed.

**Two accounts on one phone now take the first account.** Your example showed COSTAR's customer **Search** list: a results grid with Add new, Include Inactive, Print Results, Search, Cancel, OK and Clear. OK stays greyed out until a row is highlighted, so 1.8.x fell back to Cancel and entered a new customer. 1.9.0:
1. highlights the top row of the results grid (Windows accessibility, the same way Order Check reads COSTAR's grids), plus a click on that row;
2. waits for OK;
3. presses OK.

It never presses Cancel, Add new, Search, Clear or Print, and never creates a new customer once the list was shown.

**Works with Order Check:**
- The helper never types into the COSTAR window Order Check reads, and picks the other Tempe COSTAR by itself. The list marks Order Check's window.
- Before filling an online order, it asks Order Check (if running) whether that TTW number is already in Work-in-Progress. If so it refuses, naming the document. This catches orders entered by someone else or in an earlier session. It needs Order Check 1.4.0 and COSTAR's PO column in the WIP list.

**Build:** now also references `Accessibility.dll`, the same Windows library Order Check already compiles with on this PC. Self-tests: **73 groups**.

### Test it

1. Fresh **Tempe-Mobile-COSTAR-v1.9.0** folder, **Start-RDP.cmd**. Title **1.9.0 - lean build**, **73 test groups passed**.
2. **Auto-fill from Chrome:** tick Fill automatically, go to Chrome, click Send to COSTAR, hands off. COSTAR comes forward and the order is entered.
3. **Two-account phone** (the 3 Oct customer): the first account is chosen. Diagnostics show `account_chooser` and `account_first_row`.
4. With Order Check running: the helper uses the other Tempe COSTAR; send the same online order twice and the second is refused ("already in COSTAR as document …").
5. End of day: **Save diagnostics**.

---

## Previous release notes (1.8.3)


Replaces 1.8.2. Use this one.

## What 1.8.3 fixes (your 3 October screenshot)

1.8.2 found the Tempe COSTAR ("1 Tempe COSTAR windows found") but would not use it. The status line said **"Mobile job pinned to its original instance."**

- **Why:** the last mobile job (Friday 17:00) finished as *ready for review* and was never closed through the desk. Then COSTAR was closed, taking that Repair Order with it. A new job only starts after the previous one is closed, so the helper kept the COSTAR list locked to the old COSTAR, which no longer exists. That blocked mobile **and** online orders. It is an old trap, not a 1.8 change: it happens whenever COSTAR is closed while a finished job is still waiting for Next Order.
- **Fix 1:** a lock to a COSTAR that is no longer running, or whose Repair Order window is gone, no longer blocks the COSTAR list. The current Tempe COSTAR is selected and online orders work straight away. The log explains which earlier job it was.
- **Fix 2:** when the desk asks to close a reviewed job whose Repair Order window is already gone, the helper confirms it closed instead of insisting on the old COSTAR. Next Order on the desk releases the old job and mobile jobs flow again.
- **Unchanged safety:** an unfinished entry still never resumes in a different COSTAR, and the automatic reset still applies only to jobs that entered no fields.

Self-tests: **71 groups**.

### What to do

1. Fresh **Tempe-Mobile-COSTAR-v1.8.3** folder, COSTAR Tempe open, **Start-RDP.cmd**. Title **1.8.3 - lean build**, **71 test groups passed**.
2. The log says the earlier job's COSTAR has closed, then "Using Tempe COSTAR (PID …)". Online orders work now.
3. For mobile: click **Start / resume mobile**, then **Next Order** on the desk receiver (or let Pinad move on when the next job arrives). The old job is confirmed closed and new jobs flow.
4. Check in COSTAR that Friday's last mobile job was saved.

---

## Previous release notes (1.8.2)


Replaces 1.8.1 (and 1.8.0 / 1.7.0). Use this one.

## What 1.8.2 fixes (from your 3 October diagnostics)

- **Finds COSTAR by itself.** 1.8.1 refused an online order with "Select a Branch 11 COSTAR instance above": the helper only looks for COSTAR when Refresh COSTAR list is clicked. 1.8.2 looks at startup, and again whenever Fill or Start / resume mobile needs it. With one Tempe COSTAR open, it is selected automatically.
- **Detection uses the proven 1.6.1 window-reading calls again.** The faster text reading from 1.8.0 is replaced by the exact Windows calls that worked through 1.6.1. Each thread still reuses one buffer, so most of the memory saving is kept.
- **Every search is logged.** The day log records how many Tempe COSTAR windows were found, which one is used, and which COSTAR windows were seen (main-window titles only). If none is found, the helper says so in plain words.
- **No more "field still loading" stop at startup.** A 1.6.1 mobile job stopped because COSTAR was still drawing the new Repair Order when it was checked. Startup now waits until every field reads.
- **DET about 0.5–1 s faster.** In 1.6.1 the first PO# click already created the car/rego/odometer notes, but the helper kept clicking until PO# held focus. It now finishes as soon as the notes exist, and falls back to the old routine if they don't appear.
- **Checkpoint save timing.** Saves still cost about 66 ms each after 1.6.1, so the forced flush was not the cause. Each save is now timed in parts (copy, JSON, encrypt, write, replace), shown in the end-of-day report.

Self-tests: **70 groups** (71 from 1.8.3).

### Test it

1. Fresh **Tempe-Mobile-COSTAR-v1.8.2** folder inside RDP, with COSTAR Tempe open. Run **Start-RDP.cmd**. Title **1.8.2 - lean build**, **70 test groups passed**.
2. Within a second or two, the log says **"Using Tempe COSTAR (PID …)"** without you clicking Refresh.
3. Run a few mobile jobs and online orders as usual. Use **Add note** if anything is odd.
4. End of day: **Save diagnostics**, upload the ZIP.

## End-of-day report (since 1.8.1)

**During the day:** work normally. If something odd happens, click **Add note** (top row) and type a few words, for example "COSTAR froze on the phone lookup". No customer names or numbers, please.

**At the end of the day:** click **Save diagnostics** and upload the ZIP to Claude. It now contains:
- `summary.txt`. The first page is **END OF DAY**:
  - **Today:** runs and completion rate, online orders loaded, filled, stopped, refused or queued, mobile jobs, stops pressed, desk connection drops, crashes, memory after jobs, and your notes with their times.
  - **Speed by version:** median times per job type for each helper version, so improvements show up as numbers.
  - **Things to look at:** crashes, repeated stop reasons, orders that would not load, read-plan misses, two-account lists seen, unusually slow runs and slow stages.
  - After that, the detailed per-stage and per-wait breakdown as before.
- `runs.csv` and `runs/` (one masked file per entry run, as before).
- `day-log/` (new): one line per event, for the last 14 days. It covers everything outside a single entry run, so failures before entry starts are no longer invisible: orders that failed to load, orders refused as duplicates, queue decisions, fills started and finished, fresh Repair Orders opened, mobile jobs picked up and finished, desk connection drops and recovery, stop presses, crashes with the failing code location, memory after each job, tab switches, and your notes.

Everything is masked: no customer names, phones, addresses or emails. Popups are recorded by shape (control type, position, size), not content, plus their button captions.

The day log lives in `%LOCALAPPDATA%\TempeMobileCostar\diagnostics (before 2.4.0: TempeCostarAutofill\Diagnostics)\events-YYYYMMDD.jsonl` and is kept 180 days. Saved ZIPs older than 30 days are cleaned up automatically.


## What 1.8.0 changes

**Reads far less of the screen.** Diagnostics showed screen reading was 19–43% of every run: about 12,000 cross-process text reads in a 10-second mobile job. Most were wasted.
- **Item grid:** each read touched about 180 controls; the engine only ever uses the 5 column labels and the cells under them (about 45). Grid reads now read just those.
- **Customer header:** reused while the panel is unchanged (same windows, same positions), instead of a full form read every time; field values are read live when used.
- **Buttons:** captions are read only on popups; the form and grid never use them.
- **Safety net:** anything the read plan skips is still read on the spot if any check asks for it, so a missed field costs one extra read, never a wrong answer. Diagnostics count these ("late reads"); expected near zero.

**Much less memory churn.** Every text read used to allocate an 8 KB buffer plus a native copy — roughly 100 MB of throwaway memory per mobile job. Reads now reuse one buffer per thread; class names are looked up once per run. After each job the helper returns its memory to Windows.

**Two accounts on one phone → the first one.** When COSTAR shows a selection list, the helper keeps the first row and presses the list's OK/Select button (or Enter when no button could change data), for mobile and online. It never presses Yes/Save/New/Delete, never creates a new customer once a list was shown, and if the list is unfamiliar it stops with the list captured in the report so the exact behaviour can be finished.

**Online Fill always opens its own Repair Order.** With nothing open, with an empty one open, or with earlier orders still open for review: Fill uses an empty/same-customer order, otherwise clicks Add New itself (pressing the button directly if an open order covers it) and fills the new one. Orders that already hold another job are never touched.

**Fill automatically.** Tick it on the Online tab, then just click **Send to COSTAR** on the website. Each order is entered straight away in its own new Repair Order. Orders sent while one is being entered wait in line; the same order is never entered twice in a session. After a stop the line pauses; click Fill to carry on.

Self-tests: **70 groups**. Still Tempe Branch 11 only.

### Test it

1. Fresh **Tempe-Mobile-COSTAR-v1.8.1** folder inside RDP, **Start-RDP.cmd**. Title **1.8.1 - lean build**, **70 test groups passed**.
2. A few mobile jobs and online orders as usual. In the diagnostics summary, **SCREEN READS** should be far below the 1.6.x figures and **late reads** near zero.
3. A phone that has **two accounts** in COSTAR.
4. An online order while the **previous one is still open** for review.
5. **Fill automatically**: tick it, send two orders quickly, then send the first one again (it must be refused).
6. At the end of the day, **Save diagnostics** and upload the ZIP.

If 1.8.1 fails to build or start, keep using 1.6.1 and send the error.

---

## Previous release notes (1.6.1)


## What 1.6.1 changes (from the 1.6.0 diagnostics)

Measured on 2 October with 1.6.0: mobile entry 10.3 s (was 13.4 s), online pickup 5.2 s (was 6.9 s), an existing customer (TTW1730110) went straight through. Remaining waste:

- **DET:** COSTAR still undid the first one or two PO# clicks (1.2 s mobile, 0.5 s online). 1.6.1 first lets COSTAR finish looking up the DET code (its description fills in), then clicks PO# once. A re-click is no longer triggered before COSTAR has processed the previous click.
- **Checkpoint saves:** 17 saves took 1.2 s (about 70 ms each). Checkpoint saves no longer force a write-through to disk. They still reach Windows before entry continues and survive the helper crashing; a power cut would also lose COSTAR's unsaved order. Status reports and the desk queue still force the write.
- **Pickup and completion:** while mobile entry is enabled, the worker checks the desk every second instead of every three, so new jobs start and "ready" reaches the phone about a second sooner on average.

Self-tests: **66 groups** (the storage test now also covers a checkpoint save without forced flush).

### Test it

1. Fresh **Tempe-Mobile-COSTAR-v1.6.1** folder inside RDP, **Start-RDP.cmd**. Title **1.6.1 - speed build**, **66 test groups passed**.
2. Run a few mobile jobs and online orders. Please include **TTW1730342** (existing customer, delivery) and one online order with **no Repair Order open**; neither was covered in the 1.6.0 runs.
3. **Save diagnostics** and upload the ZIP.

---

## Previous release notes (1.6.0)


## What 1.6.0 changes (from the 1.5.5 diagnostics)

- **Waits for COSTAR instead of guessing.** Before reading the screen or clicking, the helper sends Windows' do-nothing message to the Repair Order and continues the moment COSTAR answers. It no longer reads half-drawn screens while COSTAR is loading.
- **Existing customers no longer stop entry.** When the phone matches an existing account, COSTAR rebuilds the customer panel for about 2 seconds. That redraw is now treated as "still loading", not as an unknown layout. Billing and delivery fields are then compared one by one: matching values are left alone, different values are replaced, and entry continues with the items.
- **DET is about 1.5–2 s faster.** Leaving the item grid re-clicks PO# within a fraction of a second when COSTAR pulls focus back, instead of waiting out a 2-second timeout.
- **Mobile checkpoints:** one safety save per step instead of two, with the same resume guarantees. Progress saves every 2.5 s instead of 0.5 s (the desk only receives progress every 3 s). The redundant re-read before each step is skipped after the first step; every step still verifies the whole order afterwards.
- **Faster polling:** shorter waits in the lookup, startup and item loops, and 1 ms timer resolution during entry.
- **Retry on the same Repair Order.** If the open order already holds this order's customer (same phone), with PO#/comment empty or this order's and no items, entry continues: it re-checks the customer and compares/updates the details instead of stopping with "not empty".
- **Online orders open their own Repair Order.** With no Repair Order open, Fill clicks Add New itself, the same way mobile jobs do. One open, empty Branch 11 order is still used as before.
- **Mobile customer-popup recovery** now applies only to the phone, name and reference steps. An unexpected popup during items stops entry instead of being dismissed.
- **Diagnostics:** stop stage is reported correctly, checkpoint-save and COSTAR-wait times are measured, time between steps is itemised, and the layout fingerprint uses label positions only.

Self-tests: **66 groups**. Focus remains Tempe Branch 11.

### Test it

1. Extract into a fresh **Tempe-Mobile-COSTAR-v1.6.0** folder inside RDP and run **Start-RDP.cmd**. The title must show **1.6.0 - speed build** and the self-test report **66 test groups passed**.
2. Run real jobs, including at least one online order whose customer already exists in COSTAR (TTW1730342 is a good one) and one with no Repair Order open.
3. Click **Save diagnostics** and upload the ZIP.

If 1.6.0 fails to build or start, keep using 1.5.5 or 1.5.4 and send the error.

---

## Previous release notes (1.5.5)


## What 1.5.5 changes

1.5.5 is 1.5.4 plus measurement. **Entry behaviour is unchanged**: the same steps, waits, checks and timeouts run in the same order. It adds:

- **Per-run diagnostics** (`diagnostics.json`): time per stage, how long each wait loop ran and why it ended, screen reads, time spent sleeping, focus/Tab timings, which window took focus when a run stopped, and the stop category.
- **A COSTAR responsiveness probe**: a separate background thread sends Windows' do-nothing message (WM_NULL) to the Repair Order about every 50 ms and records how long COSTAR takes to answer. It never delays or blocks the entry thread.
- **Environment and layout fingerprint**: screen size, DPI, Repair Order window size, COSTAR file version and where known labels (PO#, ITEM, QTY OR HRS…) sit.
- **Save diagnostics** button (top row): builds one ZIP with `summary.txt`, `runs.csv` and the per-run files from `%LOCALAPPDATA%\TempeMobileCostar\diagnostics (before 2.4.0: TempeCostarAutofill\Diagnostics)`.
- **Report housekeeping**: each run now keeps only the ZIP (the duplicate folder is removed after zipping). Full reports older than 30 days and diagnostics older than 180 days are deleted automatically.

**Privacy:** diagnostics contain no values typed into or read from COSTAR fields. Step messages are masked (phone-like numbers and emails replaced), other applications' window titles are not recorded, and popup text is kept only for message-box-style popups. Order IDs (TTW…/MJC…) and SKUs are kept so runs can be matched. Open `summary.txt` before sharing if you want to check it. The full local entry reports still contain customer details and stay on this PC.

### 10-run test

1. Extract into a fresh **Tempe-Mobile-COSTAR-v1.5.5** folder inside RDP and run **Start-RDP.cmd**. The title must show **1.5.5 - diagnostics build** and the self-test report must show **65 test groups passed**.
2. Use it normally for about 10 real jobs. A mix of mobile jobs and online orders (pickup and delivery) is ideal. Work as you normally would — stops are useful data.
3. Click **Save diagnostics** and upload the `Tempe-COSTAR-Diagnostics-<date>.zip` it selects. No other files are needed.
4. Separately, if possible: run the existing **COSTAR Field Inspector** once on a **blank** Repair Order and upload its report. It shows whether COSTAR's fields have stable internal names.

If 1.5.5 fails to build or start, keep using your 1.5.4 folder and send the build error — 1.5.4 is untouched.

---

## Previous release notes (1.5.4)

One app inside RDP now contains **Mobile jobs** and **Online orders** tabs. Both use the same faster entry engine and the same selected Branch 11 COSTAR instance. The existing desk receiver stays outside RDP to connect the phone.

This complete package includes all dependencies, including ResourceBudget.cs (BoundedLog, LocalProcess and clipboard handling). It includes lowercase email entry, reduced background work and the mobile startup/recovery update. **Mobile starts paused, and clipboard auto-load starts off.**

## Update your working installation

1. Finish the current entry, then close the old RDP worker and standalone online autofill once.
2. Extract the whole ZIP into a **fresh folder inside RDP**. It contains **Tempe-Mobile-COSTAR-v1.5.4**. Use that folder as supplied, instead of mixing it with earlier patches. Previously imported settings are retained for the same Windows user. If your connection has not been imported, copy your existing `worker-connection.json` beside the new `Start-RDP.cmd`.
3. Run **Start-RDP.cmd**. It builds in your writable local user folder and runs the included self-tests for the new executable before opening the combined app. The title must show **1.5.4 - complete package**. Later launches reuse passing tests for the unchanged executable; Check-Build.cmd forces a fresh run.
4. The app opens paused. Click **Refresh COSTAR list**, then select the Branch 11 COSTAR you want to use. If only one is available it is selected automatically. With several, use the PID/window list and **Show selected COSTAR** to identify the right one.
5. For mobile jobs, click **Start / resume mobile**. For online orders, open the Online orders tab and use **Load copied order**, then **Fill Repair Order**. No closing/reopening of the helper is needed.

Your current desk receiver, website, certificates and phone pairing can stay as they are. Do not rerun Setup-Desk for this update. `Start-Online.cmd` is now an alias for the same combined app, opening its Online orders tab; launching it twice brings the existing app forward.

Builds and compiler output are under `%LOCALAPPDATA%\TempeMobileCostar\runtime`. This retains the local-build fix for redirected Desktops and UNC paths. A CMD UNC warning can still be displayed at initial launch; the compiler uses a local directory.

## Multiple COSTAR instances

- Only actual COSTAR main windows matching **COSTAR: 11 Tempe Tyres Tempe** in your current RDP session are offered. Browser subprocesses and other branches are excluded.
- Other COSTAR instances and their Repair Orders can stay open. They do not block the selected instance.
- The selected instance is checked by process, process start time, Windows session and main-window handle. Every Repair Order is checked for **Branch 11** again before entry.
- Selection is held for the complete entry. An unfinished mobile job remains tied to its original process and Repair Order; a retry never chooses a different instance. If the selected process closes, the helper stops and asks you to select again instead of silently moving to another one.
- Use a dedicated selected instance for automation. An open Repair Order in that instance blocks a new mobile order. If several Repair Orders are open within the same process, the online tab asks for one empty target; it does not guess which one to overwrite.
- During entry, leave the selected COSTAR visible and unobstructed. Switching to another application can stop entry. Keeping other instances open is supported; simultaneous typing into a different window during entry is not.

## Mobile jobs

Click **Start / resume mobile** after each app launch and keep the **Mobile jobs** tab selected to receive new mobile work. Until then the desk receiver may show the worker as offline/stopped. The app does not scan COSTAR or poll the desk receiver merely because it opened. The existing desk receiver still handles approval, Pinad mode, Retry, Next Order, Delete selected and Clear completed.

The worker enters phone first, keeps a matched COSTAR account/name, and fills a new name only if no match exists. It then enters:

**Wheels → tyres → M FB → optional WA/WAFR → DET → make/model → rego → odometer → optional M note.**

Mobile jobs keep COSTAR catalogue prices and existing addresses. Durable before/after checkpoints, submission IDs and duplicate protection are retained. This update keeps the v1.4 checkpoint step plan; older partial plans still stop for manual review.

Before filling a newly opened phone order, the worker waits for its customer fields and item grid to load. This targets the reported DESCRIPTION-label startup failure; the exact failing layout still requires its report if it persists.

For the existing failed job whose window was closed: check COSTAR for any manual entry, then use **Start this job again** (2.4.0; was **Reset unstarted job**) on the Mobile jobs tab. It only allows reset when the saved journal proves no field entry began and the original window is gone. It keeps an encrypted backup. Select Branch 11, start/resume mobile, then use **Retry selected** for the same job on the existing desk receiver outside RDP. A previously queued retry can start on resume. If reset is refused, keep its saved progress and send the relevant entry report; partial/uncertain jobs remain protected.

## Online orders

Selecting the **Online orders** tab pauses new mobile dispatch. A mobile entry already running is allowed to finish; online entry cannot start until it has finished. Switching back to Mobile jobs resumes dispatch if the worker is enabled.

1. Open a **new empty Branch 11 Repair Order in the selected COSTAR instance**.
2. Search/review your online order on the existing website and click **Send to COSTAR** as before.
3. Click **Load copied order** in the Online orders tab, check the preview, then click **Fill Repair Order**. Optional **Auto-load copied orders** watches new clipboard changes only while this tab is selected and entry is idle. It starts off and does not read an old clipboard merely when enabled. RDP may still need to fetch copied data when loading; leave auto-load off if redirected clipboard access is slow.
4. Review the completed order in COSTAR. Online completion leaves it open; normal staff controls handle saving, payment and invoicing. Close that Repair Order before returning the instance to mobile work.

The online flow retains its additional fields and rules:

| Area | Behaviour |
| --- | --- |
| Customer | Phone first. Dismiss the known not-found notice. Keep a matched COSTAR account and name even if the submitted name differs. |
| Billing | Use supplied online address/email fields, including clearing a stale second address line. |
| In-store fitting | Wheels, tyres, M FB when enabled, ordered WA/WAFR, then DET details. Keep the online date/time/rego comment and PO order reference. No odometer is invented when online data does not supply one. |
| Prices | Use online quantities and prices for complete product/service lines. Keep COSTAR descriptions. |
| Delivery/fitting partner | Separate billing and destination panels; contact, phones, email, Ship Via and instructions; freight using F/List; vehicle/rego using M C / TO SUIT; comment DFE. No in-store M FB or DET. |
| Incomplete package | Keep known SKU/quantity and its COSTAR unit price. Flag PACKAGE REVIEW; do not invent missing tyres or assign the full package price to one component. |
| Surcharge | COSTAR handles it; never add a duplicate surcharge line. Check the exact before/after-surcharge totals. |
| Discounts/services | Unmapped discounts or unknown service codes remain blocked. No mapping is guessed. |
| Payment note | Optional PAYING BY note is retained; it does not take payment. |

Customer and delivery email addresses are entered in **lowercase**. Other newly inserted text/codes use CAPITALS. Existing COSTAR account names and catalogue descriptions are kept as supplied by COSTAR. The bundled `OnlineOrders` files match your attached website/exporter; there is no website update required for this release.

## Speed changes

- Both tabs share the phone-first engine and consecutive detail entry. DET visits PO once, then each detail is committed without returning to PO.
- Item/memo reads scan the live item grid instead of every form field. Row handles, positions and values are rediscovered after layout changes; only the grid container identity is cached.
- Mobile verification reads mapped header fields live alongside the grid. Existing step comparison and durable checkpoints remain.
- Correct quantities are not re-entered, avoiding an unnecessary validation cycle.
- Diagnostic logs are buffered locally and flushed at stage boundaries. A redirected/network Desktop is not written to for every field.
- Mobile queue polling is now approximately **3 seconds plus request time**. A new job may take up to about 3 seconds longer to be picked up; the per-field entry engine keeps its existing timing.
- The UI timer displays cached status only. Target discovery is a single background operation when Refresh is clicked. Checks during mobile polling inspect only the selected PID and its windows, and stop while mobile is stopped, online is selected, or an entry is running.
- The online panel is created on its first visit. Clipboard reads are optional and limited to one order (200,000 characters) before allocating a managed copy.
- Each tab keeps at most 65,536 visible log characters and 16,384 pending log characters. Progress is batched instead of posting one UI event per field. Detailed entry reports remain on disk.

Phone lookup, product loading and validation still depend on COSTAR. There is no measured end-to-end speed claim for this build yet. An online fitting/delivery order contains more fields than a mobile card and can therefore take longer overall.

## Stop and reports

**Ctrl+Alt+F10** or **Stop all entry** stops the active mode and pauses mobile processing. Resume mobile explicitly when ready. The Online orders tab also has its own Stop button.

**Open entry reports** opens `%LOCALAPPDATA%\TempeMobileCostar\reports (before 2.4.0: TempeCostarAutofill\Reports)` inside RDP. Each run has a ZIP with controls, progress and `timing.json` (stage times, scan counts and skipped quantities). **Save worker report** exports connection/target/worker status. Reports may contain customer details; select the report for the relevant test. Never send pairing keys or `worker-connection.json` as diagnostics.

The app changes live COSTAR screens and cannot undo committed entries. It never selects Save/Sell/Print or takes payment. An uncertain popup, changed target, conflicting customer, unexpected row or total mismatch stops entry for review.

## Validation and setup

The ZIP contains source and Windows launchers, with no precompiled EXE. `Check-Build.cmd` compiles and runs **70 test groups** (64 in 1.5.4) without opening or modifying COSTAR. Normal launchers require passing tests for the current executable; unchanged successful builds reuse that result. Windows compilation, RAM/CPU use, the combined UI and live multiple-instance entry still need testing on your RDP PC; see `VALIDATION.md` and `TEST-PLAN.md`.

Settings, queue, certificates and mobile checkpoints retain their existing location at `%LOCALAPPDATA%\TempeMobileCostar`. Keep that folder when upgrading.

For an existing installation, no new setup is required. For a new installation, use `SETUP.md`. The desk receiver and the RDP app remain separate processes on their respective computers; the two entry apps inside RDP are now combined.
