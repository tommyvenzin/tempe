# Order Check (WIP vs retail picking) — board 1.6.4, reader 1.4.0

Added 2 October 2026. Separate package from the 1.6.1 helper (the helper ZIP was not touched).

## Why

A Repair Order only creates a retail picking slip (the tyres get "ordered") when the salesperson sets
Ship Via = SHOP, ticks Customer waiting, and the order date is **today**. ROs made on an earlier day keep
their old date, so the slip never prints. Order Check flags SHOP jobs with an amount and no slip.

## Architecture

| Part | Where | Notes |
|---|---|---|
| Reader `OrderCheck.exe` (C# 5, `Source/OrderCheck.cs`) | RDP session | Reads WIP grid `ultraGrid1` (Infragistics) via MSAA. Only 9 of 45 columns. Presses the WIP Search button via MSAA `accDoDefaultAction` (no focus or mouse). Below-normal priority, every 2 min, shop hours. Serves `GET /wip.json`, `POST /ack /unack /refresh` on `127.0.0.1:8795` (Host and Origin checked, POST needs `X-Order-Check: 1`). |
| Board `Board/Order_Check.html` | Chrome in the RDP session (file:// or GitHub Pages) | Gets WIP from the reader and picking from `my.tempetyres.com.au/retailpicking/history/` through the extension (needs bridge 1.0.2: `order_check.html` allowlisted). Loads 7 days, then today every 2 min; any doc without a slip gets one history search `?day=0&month=0&year=0&q=<doc>&searchin=Document`, cached 12 h. |
| Rules `Board/order-rules.js` | Board + Node tests | Picking parser (regex, no DOM), comment reader, status engine. |

Data source facts (from the 2 Oct probes): WIP grid exposes all 79 rows (not just visible ones) through
MSAA; it lists the active row twice (dedupe by doc); `PICKSTATUS` exists but is always empty.

## Team sharing (1.2.0): encrypted file on GitHub

Chosen over Firebase (kept as last resort in `Sharing/firebase-last-resort`) and the desk receiver.

- The **RDP board** (reader reachable, set up with a fine-grained token for the public repo
  `tommyvenzin/tempe-board-data`, Contents read/write only) gzips and encrypts `{meta, rows}` with
  AES-256-GCM (key: PBKDF2-SHA256, 600,000 rounds, salt `tempe-order-check|owner/repo`) and saves
  `order-check.json` as an orphan commit force-pushed to `main` (no history growth). It saves only when
  rows or problems change, at most once a minute, plus a heartbeat every 4 minutes.
- **Viewers** poll `raw.githubusercontent.com/.../order-check.json?t=` every minute (the CDN may add up to
  5 minutes), decrypt with the team passphrase stored on their device, and warn after 12 minutes stale.
- **Mark OK** stays on the RDP board (reader acks). Anyone can clear a job with a COSTAR comment:
  NO ORDER, SERVICE ONLY, ALIGNMENT ONLY, FIT ONLY, REPAIR ONLY, OWN TYRES, NOT NEEDED → "No order needed".
- 1.2.1 fixes (found on the first real run, 2 Oct evening): a board whose reader hadn't read yet
  shared an EMPTY list and overwrote the team board. Now: no sharing before a real read or when the list
  suddenly drops to zero; one sharing board at a time (6-minute lease checked through the GitHub API before
  each save; board id kept in localStorage across reloads); browsers without the extension always show the
  shared board (no direct reader fallback when sharing is on); the reader does its first read straight after
  starting even outside shop hours.
- 1.2.2 (first real board, 2 Oct): picker names were missing because the raw intranet HTML differs from a
  DOM copy; the picker is now read from the cell text and class matching tolerates quote style and extra
  attributes. Older picks show their date; "timed out" is left out of the summary line.
- 1.3.0 (Tommy's layout request): Order date, Total and Ship via columns removed; red rows say only the fix
  ("Put SHOP", "Incorrect date", "Tick Customer waiting") with the explanation on hover; other statuses use
  short phrases. HOLD in the comment is the advertised way to clear a job (amber "On hold"). The shared file
  no longer carries totals or Ship Via.
- 1.3.1: GitHub Pages caches files for up to 10 minutes, so phones kept old boards. Scripts now load with
  `?v=<version>`, the version shows in the header, and a team view reloads itself (once, fresh address) when the
  RDP board shares a newer version (retry after 10 minutes, never a loop). Operator-only notes ("You're using the
  WIP COSTAR window", shop hours, paused) are no longer shared with the team.
- 1.3.2: red fixes are shared as codes (shop/date/waiting) and every board renders "Put SHOP", "Incorrect date",
  "Tick Customer Waiting" itself (older RDP boards' sentences are translated). No hint text. Every board checks
  `order-check.js?check=<time>` 30 s after loading and every 10 minutes and reloads itself once when GitHub has a
  newer version, so after uploading files nothing needs a manual refresh.
- 1.3.2 also: a "$" in the comment means waiting for payment → On hold (unless the comment says PAID, e.g.
  "PAID TT" stays a normal job). Jobs still "checking" are never shared: at midnight tomorrow's bookings
  became today's, the 30-second timer re-evaluated and shared them mid-search, so the team saw "Checking
  picking history" for minutes while the RDP board had already resolved them. Now the timer searches
  first, the cycle repeats search rounds (40 per round), and sharing waits for the search (max 5 minutes).
- Removing someone = change the passphrase. The token and passphrase live in the RDP Chrome's storage.
- Tested with GitHub simulated (API calls, encryption, throttling, wrong or changed passphrase, tampering).
  Not yet run against real GitHub.

## 1.4.0: works with the COSTAR helper (3 Oct 2026)

- Reader: optional PO column, found by name (PO, PO #, PO No, PO Number, Customer PO, Cust PO, Purchase Order). It is read with the other columns and published as `po`; `poColumn` and the full WIP `columns` list are in wip.json. The reader window says "Helper tags use the "…" column" or "Helper tags off".
- Rules: `helperRef(po)` gives `{kind: online, ref: TTW…}` or `{kind: mobile, ref: MJC-…}`; `evaluate` adds `helper` to every result without changing its status.
- Board: "Online" / "Mobile" tag next to the document number; search matches the reference. Sharing carries only `{kind, ref}`, never raw PO numbers.
- Helper 1.9.0 uses `po` to refuse entering an online order that is already in WIP, reads `%LOCALAPPDATA%\TempeOrderCheck\settings.json` (`targetKey` = PID@local start ticks) to never type into Order Check's COSTAR, and auto-selects the other Tempe COSTAR.
- Helper online pickup comments (`REGO - DAY - ONLINE time`) read as "Waiting until <day>" (amber), which fits booked pickups.
- 15 C# self-test groups (adds PO column), 10 rules test groups.
- Not yet confirmed: the exact WIP PO column name. If the reader says "Helper tags off", send its column list (wip.json `columns`).

## 1.5.0 board: "Not picked" warning and the amount back (23 Oct 2026)

Board files only (Order_Check.html, order-check.js, order-rules.js, share.js). The reader in the helper is unchanged (1.4.0).

- **Not picked** (orange, sorted right after red, shown in the default view): the newest slip on a job (plus any slip
  printed within 2 minutes of it) has neither "Picked (n)" in the Picked column nor "HH:MM > Shop Driver (n)" in
  Progress, an hour after it printed (`NOT_PICKED_MINUTES = 60`; on the 2 Oct page 9 in 10 SHOP slips were picked
  within 40 min). Tommy: Picked and Shop Driver act the same way, either one means picked.
- Not flagged when the picking page says Completed, when COSTAR's Completed column says Yes, or when a newer slip
  replaced the old one (reprint, other brand). Mark OK clears it, unless the slip printed after the mark.
- The board shows a "not picked" chip, orange counts on the salesperson chips, the count in the tab title, and the
  sound plays for new ones. "What's happening" shows the slip and "printed 09:30" (or the day).
- Older days' picking pages are loaded once per page session, so a slip printed yesterday and picked today would look
  unpicked: a Not picked job whose newest slip is from an earlier day is searched again by document every 10 minutes
  (at most 10 per cycle) before it stays orange.
- **Amount** column is back (Tommy, 23 Oct: $30 can be a puncture repair, $70 an alignment, which need no order). The
  shared file carries `total` again; Ship Via and phone numbers are still never shared. On phones the amount sits next
  to the doc number.
- What's on the job can't be read without opening the RO: none of the 45 WIP columns has line details.
- Real 2 Oct data (32 WIP rows, 250 slips): nothing turns orange, every status unchanged.
- Tests: 11 rules groups (new "Slips nobody picked"), the GitHub sharing test checks the amount, and a browser run of
  the RDP board and a team view through a simulated GitHub (desktop and phone width, Mark OK and Undo on an orange job).
- Next helper release: take its `Website` files from the live tempe repo (board 1.6.4, including discord.js), not
  from an older package, or the upload puts an older board back.

## 1.6.0 board: Discord alerts (23 Oct 2026)

Board files only, plus one new file: `discord.js`. The reader in the helper is unchanged (1.4.0).

- Tommy chose Discord (WhatsApp can't post into groups without an Official Business Account). Setup: one server, a
  text channel `order-check` (Send Messages off for @everyone), a channel webhook. No bot and no commands.
- The RDP board posts through the "Tom does it all" extension (bridge 1.0.2 already allows any https destination), so
  nothing is installed on the PCs. Settings are on the RDP board: **Discord alerts** (webhook link, `INITIALS = Discord
  user ID` lines, "Show customer names in Discord" (off by default), Alerts on, Send test).
- One message per round of new problems (red Not ordered, orange Not picked): at most 10 lines and 1,400 characters,
  tagging the salesperson (`allowed_mentions` lists only those users, never @everyone), link previews off. Layout:
  see 1.6.3 (one message per salesperson) and 1.6.4 (cards).
- Lines are edited to ✅ when the job is fixed: "ordered 10:42", "picked 10:55 by X", "marked OK by X", "cleared: NO
  ORDER in comment", "HOLD in comment", "no longer in Work-in-Progress" (only after an unfiltered, fresh WIP read). A
  changed fix (Put SHOP → Incorrect date) edits the line. Edits never ping.
- New alerts only Monday to Saturday 7:00 to 18:30 (overnight ones go out together at 7:00), only from fresh data (WIP
  read in the last 10 min, picking in the last 6, no reader or picking error), only from the board that shares (not
  when another board holds the lease), and only from one tab (`orderCheck.discord.lock`, handed over on close).
- RDP Chrome storage: `orderCheck.discord` (settings), `orderCheck.discord.sent` (message ids and their lines;
  finished messages kept a week; a job still red after three weeks is posted again). A new webhook link starts fresh. A
  message someone deleted (404 Unknown Message) isn't posted again until the job changes. 429 waits a minute; other
  errors wait 5 minutes and show on the RDP board only.
- Tests: `test-discord.cjs` (7 groups); browser run with a fake Discord behind the fake extension: first batch, a fix
  edited to ✅, Send test, a wrong link, a wrong people line, two tabs sending once.

## 1.6.1 board: people left out (23 Oct 2026)

- Tommy: ST is the big boss, and MD, UBH and YTA don't work at Tempe any more, so their jobs are left out of Order
  Check altogether: the RDP board (rows, counts, salesperson buttons), the team view (it only gets what the RDP board
  shares) and Discord. Their open Discord lines are edited out of posted messages; a message left with nothing in it is
  deleted.
- One list on the RDP board: `orderCheck.leaveOut` in its Chrome storage, default `MD ST UBH YTA`, edited with the
  "Left out: …" link after the salesperson buttons (RDP board only). Taking someone off the list brings their jobs back,
  and they alert like any other.
- The Discord planner gets every job plus `ctx.leaveOut`, because a job missing from the list means it left WIP.
- Tests: Discord 8 groups, rules 12 groups; browser: upgrade from 1.6.0 (UBH's line edited out of an old message, MD's
  job not posted), team view without them, editing the list brings MD back and posts it.

## 1.6.2 board: clean Discord messages (23 Oct 2026)

- Tommy's layout: one line per salesperson ("MOR :", a tag when their Discord ID is listed, so it shows their
  nickname and pings them), then one line per job: `Doc# - Name - Amount - Comment - what's wrong` (the fix in bold,
  "Not picked (printed 09:52)" for orange). No emoji, no board link on alerts. Fixed jobs: `✅ ~~the line~~ ordered 12:35`.
- Customer names always go in (Tommy: the channel is for him, not public); the "Show customer names" option is gone.
  Comments go in too. Both are escaped so they can't format, link or mention anything.
- A salesperson's jobs stay together in one message (still at most 10 jobs / 1,400 characters per message).
  Messages posted by 1.6.0/1.6.1 are redrawn in the new layout the next time the board touches them (no new ping).
- Tests: Discord 9 groups (new: the clean layout and redrawing old messages); browser run prints the real messages.

## 1.6.3 board: one Discord message per salesperson (23 Oct 2026)

- Tommy's channel (screenshots, 12:51) mixed test messages, old-layout lines, long ✅ lines and the same salesperson
  repeated across messages. Now the channel shows only what's wrong right now, one message per salesperson:
  `DB :` (or their tag when their Discord ID is listed; Tommy keeps TOG → his own account) and then
  `Doc# - Name - Amount - Comment - **what's wrong**` lines.
- A new problem deletes that salesperson's message and posts their whole list again, so Discord notifies (and a tag
  pings). A fixed job's line is edited out without notifying; with nothing left the message is deleted. A list is only
  split past about 1,900 characters, each part with the heading.
- No test messages, links, ✅ lines or emoji. Save checks the webhook link with a GET and posts nothing; "Send test" is
  gone. The sent record is v2 (`persons`: message ids and contents, the jobs already announced, `cleanup`).
- Upgrade: every message 1.6.0–1.6.2 posted is deleted and the channel redrawn with silent messages
  (SUPPRESS_NOTIFICATIONS, once). The old "alerts are connected" test messages were never recorded, so they're deleted
  by hand.
- A salesperson's message deleted by hand in Discord isn't posted again until they have something new.
- Tests: Discord 7 groups (rewritten); browser: first round, last job fixed → message deleted, new job → list
  re-posted, Save posts nothing, upgrade deletes old messages and redraws quietly, two tabs send once.

## 1.6.4 board: a Discord card per salesperson (23 Oct 2026)

- Tommy: in future every salesperson checks the list, so each must find their own name at a glance ("without
  squinting"). Each salesperson's message is now a Discord card (embed): their initials as the bold title, a red bar
  (orange when every job is only "Not picked"), the job lines in Tommy's layout with a blank line between jobs.
  Separate cards keep salespeople apart.
- A listed salesperson's tag sits in the message text above their card (Tommy: TOG → his own account), so a new post
  pings them; edits never ping. Cards split only past about 3,800 characters, each part titled.
- No SUPPRESS_EMBEDS flag any more (it would hide the card). The sent record is v3; text messages from 1.6.3 (and
  older) are deleted and redrawn as cards with silent messages, once.
- Tests: Discord 8 groups (card payload: title, colour, text, tag, pings; 1.6.3 → cards); browser run prints the card
  payloads for the first round, a fix, a new job and the upgrade.

## Status rules

grey ($0 or Ship Via not SHOP/blank) → green (any slip for the doc; orange "Not picked" when the newest slip
has no pick an hour after printing) → amber (order date in future;
comment date in future; hold word) → checking (history not searched yet) → new (changed < 5 min) →
OK (Mark OK with matching signature) → red. Signature = Ship Via | order date | total | comment | Written By.

## Known gaps / next

- Service-only SHOP jobs show red until Mark OK. Level 2 would read RO lines.
- Target COSTAR window is remembered by PID + start time, so it is re-chosen after a COSTAR restart.
- Not yet run on Windows: confirm compile, 15 self-test groups, first read time, Search press.
