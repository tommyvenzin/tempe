// The RDP helper's eBay orders tab (2.5.0): on/off, the desk connection, COSTAR Sydney, the order
// being entered, the layout check and the log.
using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed partial class WorkerForm {
        EbayEngine ebay;
        readonly TabPage ebayPage=new TabPage("eBay orders");
        readonly Label ebayConnection=Ui.Text("",800),ebayTargetLine=Ui.Text("",800),ebayJobLine=Ui.Text("",800),ebayDetailLine=Ui.Hint("",800);
        readonly Button ebayToggle=Ui.PrimaryButton("Start eBay orders",200),ebayCheck=Ui.SecondaryButton("Check Sydney layout (types nothing)",300);
        readonly CheckBox ebayClose=Ui.Check("Close each Repair Order once it's in",AppSettings.Current.ebayClose);
        readonly RichTextBox ebayLog=Ui.Log();
        readonly BoundedLog ebayMessages=new BoundedLog();
        volatile bool ebayChecking;
        void EbayAppend(string text){ebayMessages.Add(text);}
        void BuildEbayPage() {
            ebayPage.BackColor=Ui.Canvas;ebayPage.Padding=new Padding(0);
            var layout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=4,Padding=new Padding(12),BackColor=Ui.Canvas};
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var card=Ui.Card();card.Dock=DockStyle.Top;
            var lines=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Surface};
            lines.Controls.Add(Ui.Title("eBay orders from the eBay PC → COSTAR Sydney"));
            lines.Controls.Add(ebayConnection);lines.Controls.Add(ebayTargetLine);lines.Controls.Add(ebayJobLine);lines.Controls.Add(ebayDetailLine);
            card.Controls.Add(lines);
            var buttons=Ui.Row();buttons.Margin=new Padding(0,10,0,6);buttons.Controls.Add(ebayToggle);buttons.Controls.Add(ebayCheck);
            ebayClose.Margin=new Padding(16,10,0,0);buttons.Controls.Add(ebayClose);
            ebayClose.CheckedChanged+=delegate {
                AppSettings.Current.ebayClose=ebayClose.Checked;AppSettings.Current.Save();
                EbayAppend(ebayClose.Checked?"Each eBay Repair Order is closed once it's in (left open when something needs checking by hand).":"eBay Repair Orders are left open after entry.");
            };
            layout.Controls.Add(card,0,0);layout.Controls.Add(buttons,0,1);layout.Controls.Add(ebayLog,0,2);
            layout.Controls.Add(Ui.Hint("Each eBay order sent with Send to COSTAR on the eBay PC goes straight into a NEW Repair Order in the Branch 1 (Sydney) COSTAR open in this session, then that Repair Order is closed (it stays in Work-in-Progress; left open when something needs checking by hand, or when the box above is unticked): phone first, PO# = eBay order number, comment EBAY DFE, Ship to = buyer (Ship Via DFE), Rebill to EBAY + Card#, Written By and Salesperson SA, then the lines spaced as in the example (item at the eBay price, F, M E, M BUY, M DFE). It waits while someone uses this PC or an online order is being entered. Leave COSTAR Sydney on Work-in-Progress. Ctrl+Alt+F10 stops entry.",820),0,3);
            ebayPage.Controls.Add(layout);
            ebayToggle.Click+=delegate{DeskForm.Attempt(ToggleEbay);};
            ebayCheck.Click+=delegate{DeskForm.Attempt(CheckSydneyLayout);};
        }
        void ToggleEbay() {
            if(ebay==null) throw new InvalidOperationException("eBay orders need the desk connection: import worker-connection.json and restart the helper.");
            if(ebay.Enabled){ebay.Stop(true);EbayAppend("eBay orders switched off. Orders sent from the eBay PC wait on the desk PC until you start again.");}
            else{ebay.Start();EbayAppend("eBay orders on: each one goes into a new Repair Order in COSTAR Branch "+ebay.Branch+" as soon as COSTAR is free and nobody is using this PC.");}
            UpdateStatus();
        }
        // On its own thread like an entry (the window stays responsive); one at a time.
        void CheckSydneyLayout() {
            if(ebay==null) throw new InvalidOperationException("eBay orders need the desk connection: import worker-connection.json and restart the helper.");
            Order.Require(!ebayChecking&&!coordinator.Busy,"Wait for the current entry to finish first.");
            ebayChecking=true;EbayAppend("Checking COSTAR Sydney's Repair Order layout (nothing is typed) ...");UpdateStatus();
            var thread=new Thread(delegate() {
                string result;
                try { result=ebay.CheckLayout(); } catch(Exception e) { result="NOT CHECKED: "+e.Message; }
                finally { ebayChecking=false; }
                foreach(var line in result.Split('\n')) if(line.Trim().Length>0) EbayAppend("Layout: "+line.TrimEnd('\r'));
            });
            thread.IsBackground=true;thread.SetApartmentState(ApartmentState.STA);thread.Start();
        }
        void UpdateEbayTab() {
            Ui.AppendColoured(ebayLog,ebayMessages.Drain());
            if(ebay==null) {
                Ui.SetText(ebayConnection,"eBay orders need the desk connection (worker-connection.json), like mobile jobs.");
                Ui.SetText(ebayTargetLine,"");Ui.SetText(ebayJobLine,"");Ui.SetText(ebayDetailLine,"");
                ebayToggle.Enabled=false;ebayCheck.Enabled=false;return;
            }
            int since=ebay.SecondsSinceContact;
            Ui.SetText(ebayConnection,ebay.Connection+(since>=0?" ("+(since<=1?"just now":since+" s ago")+")":"")+"  ·  "+(ebay.Enabled?"eBay orders ON":"eBay orders OFF"));
            var t=ebay.Target;
            Ui.SetText(ebayTargetLine,t!=null?"Goes into COSTAR "+t.Label+" · PID "+t.Pid:"COSTAR Branch "+ebay.Branch+" (Sydney): not found yet. Open it in this Remote Desktop session and leave it on Work-in-Progress.");
            string current=ebay.Current;
            Ui.SetText(ebayJobLine,current.Length>0?"Entering "+current:ebay.LastLine.Length>0?"Last: "+ebay.LastLine:"No eBay order yet.");
            Ui.SetText(ebayDetailLine,ebay.Detail);
            ebayToggle.Text=ebay.Enabled?"Stop eBay orders":"Start eBay orders";
            ebayToggle.Enabled=!ebay.Busy;
            ebayCheck.Enabled=!ebay.Busy&&!ebayChecking&&!coordinator.Busy;
        }
    }
}
