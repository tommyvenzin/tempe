// Repair Orders from the phone (2.6.0, Tommy 27 Oct). The phone lists COSTAR Tempe's Work-in-
// Progress, opens any Repair Order in it (the RDP helper opens it, reads it and closes it again) and
// sends changes straight in: customer details, car, products, quantities, prices, notes, Ship Via,
// Date In and Customer Waiting. To save, the helper opens the Repair Order again, checks it still
// holds what the phone was shown, types the changes, checks the result and closes it again.
// This file: what the phone sees and sends, the rules for every change, the expected result, and
// the desk's queue of phone requests. The COSTAR side is in RoWorker.cs and Runner.Ro.cs.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace TempeCostar {
    // One Work-in-Progress row (Order Check's columns).
    public sealed class RoListRow { public string doc,date,name,total,shipVia,comment,by,po,status; }
    // source: "costar" (read just now from COSTAR Tempe) or "order-check" (Order Check's last read
    // of its own WIP window, when COSTAR Tempe was busy).
    public sealed class RoList { public List<RoListRow> rows;public string readUtc,source,note; }
    // A filled line of the Repair Order, top to bottom. n: COSTAR's line number (0 when the lines
    // can't be counted). kind: item, note (M ...), det (DET) or car (DET's three notes).
    public sealed class RoLine { public int n;public string kind,code,description,qty,net,list; }
    public sealed class RoSnapshot {
        public string doc,readUtc,sig;
        public string account,name,phone,email,address,address2,suburb,state,postcode,po,comment;
        // customerWaiting: yes, no or "" (not readable).
        public string shipVia,dateIn,timeIn,writtenBy,customerWaiting;
        public string makeModel,rego,odometer;
        public bool det,counted;
        public int totalCents;
        // Lines with no item code but words or a price in them (a line COSTAR half took out): never
        // shown as lines, but counted, so a change can't leave one behind unnoticed.
        public int loose;
        public List<RoLine> lines;
        // What the phone can't change on this Repair Order, and why (field -> words).
        public Dictionary<string,string> cannot;
        // The longest text a box takes, where COSTAR says (field -> letters).
        public Dictionary<string,int> limits;
    }
    // A change to a line the phone was shown: its place in the snapshot's lines and its code (both
    // must still match). qty and price for items, text for notes; remove takes the line out.
    public sealed class RoLineEdit { public int index;public string code,qty,price,text;public bool remove; }
    // A new line: an item (code, optional quantity and price) or a note (M with words).
    public sealed class RoNewLine { public string kind,code,qty,price,text; }
    public sealed class RoEdit {
        public string schema,doc,baseSig;
        // Header boxes to change: name, phone, email, address, address2, suburb, state, postcode, po, comment.
        public Dictionary<string,string> header;
        // null: unchanged. dateIn yyyy-MM-dd; customerWaiting yes or no.
        public string shipVia,dateIn,customerWaiting,makeModel,rego,odometer;
        public List<RoLineEdit> lines;
        public List<RoNewLine> add;
        // 2.6.2: print the Job Card once the change is in and checked (not a change by itself).
        public bool print;
        internal const string Schema="tempe.ro-edit.v1";
        internal const int MaxAdds=8;
        internal static readonly string[] HeaderKeys={"name","phone","email","address","address2","suburb","state","postcode","po","comment"};
        internal static string Label(string key) {
            switch(key) {
                case "address2":return "second address line";case "po":return "PO#";case "phone":return "mobile phone";
                case "shipVia":return "Ship Via";case "dateIn":return "Date In";case "customerWaiting":return "Customer Waiting";
                case "makeModel":return "car make/model";case "rego":return "rego";case "odometer":return "odometer";
                default:return key;
            }
        }
        static readonly Regex Doc=new Regex(@"^[0-9A-Z][0-9A-Z-]{0,19}$"),Sig=new Regex(@"^[0-9A-F]{16}$");
        internal static bool IsDoc(string value) { return Doc.IsMatch(value??""); }
        internal static bool IsSig(string value) { return Sig.IsMatch(value??""); }
        // The value as COSTAR shows it once typed: upper case, but the email in lower case.
        internal static string Entry(string key,string value) { value=Order.Clean(value);return key=="email"?value.ToLowerInvariant():Order.EntryText(value); }
        static void Text(string value,string label,int limit) { Order.Safe(value,label,limit); }
        // One header box's value: its own rule.
        internal static void CheckHeader(string key,string value) {
            string v=Order.Clean(value),label=Label(key);
            Text(value,label,120);
            switch(key) {
                case "name":Order.Require(v.Length>0&&v.Length<=100,"The name can't be empty (100 letters at most).");break;
                case "phone":Order.Require(Regex.IsMatch(v,@"^\+?[\d ()-]+$")&&Regex.IsMatch(Order.Phone(v),@"^\d{8,15}$"),"The mobile phone must have 8 to 15 digits.");break;
                case "email":Order.Require(v.Length==0||(v.Length<=120&&Regex.IsMatch(v,@"^[^@\s]+@[^@\s]+\.[^@\s]+$")),"The email address isn't valid.");break;
                case "state":Order.Require(Regex.IsMatch(v.ToUpperInvariant(),@"^(|NSW|VIC|QLD|SA|WA|TAS|NT|ACT)$"),"The state must be NSW, VIC, QLD, SA, WA, TAS, NT or ACT.");break;
                case "postcode":Order.Require(Regex.IsMatch(v,@"^(\d{4})?$"),"The postcode must be 4 digits.");break;
                case "po":Order.Require(v.Length<=30&&Regex.IsMatch(v,@"^[A-Za-z0-9 #/._-]*$"),"The PO# takes letters, digits, spaces and # / . _ - (30 at most).");break;
                case "suburb":Order.Require(v.Length<=60,"The suburb is too long.");break;
                case "comment":Order.Require(v.Length<=80,"The comment is too long (80 letters at most).");break;
                case "address":case "address2":Order.Require(v.Length<=100,"The "+label+" is too long.");break;
                default:throw new InvalidOperationException("The phone sent a box the helper doesn't change ("+key+").");
            }
        }
        internal static bool IsQty(string value) {
            decimal q;
            return Regex.IsMatch(value??"",@"^\d{1,4}(\.\d{1,2})?$")&&Decimal.TryParse(value,NumberStyles.Number,CultureInfo.InvariantCulture,out q)&&q>0&&q<=9999;
        }
        internal static bool IsPrice(string value) { return Regex.IsMatch(value??"",@"^\d{1,6}(\.\d{1,2})?$"); }
        internal static bool IsDate(string value,out DateTime date) {
            return DateTime.TryParseExact(value??"","yyyy-MM-dd",CultureInfo.InvariantCulture,DateTimeStyles.None,out date)&&Math.Abs((date-DateTime.Today).TotalDays)<=400;
        }
        // Item codes a phone may add: COSTAR codes, not DET (the car section adds it) or a bare M (a note).
        internal static bool IsNewCode(string code) {
            string c=Order.Norm(code);
            return Regex.IsMatch(c,@"^[A-Z0-9][A-Z0-9 ._/-]{0,19}$")&&c!="DET"&&c!="M";
        }
        // The rules that need no Repair Order: what the desk checks before queueing it.
        internal void ValidateShape() {
            Order.Require(schema==Schema,"This change came from an older Repair Orders page. Reload the page and try again.");
            Order.Require(IsDoc(doc),"The Repair Order number isn't valid.");
            Order.Require(IsSig(baseSig),"Open the Repair Order again before changing it.");
            int count=0;
            if(header!=null) foreach(var pair in header) {
                Order.Require(HeaderKeys.Contains(pair.Key),"The phone sent a box the helper doesn't change ("+pair.Key+").");
                Order.Require(pair.Value!=null,"The "+Label(pair.Key)+" is missing.");
                CheckHeader(pair.Key,pair.Value);count++;
            }
            if(shipVia!=null) { Order.Require(Regex.IsMatch(shipVia,@"^[A-Za-z0-9 &/.-]{0,20}$"),"Ship Via takes letters, digits and & / . - (20 at most).");count++; }
            DateTime when;
            if(dateIn!=null) { Order.Require(IsDate(dateIn,out when),"Date In must be a date within a year of today.");count++; }
            if(customerWaiting!=null) { Order.Require(customerWaiting=="yes"||customerWaiting=="no","Customer Waiting must be yes or no.");count++; }
            if(makeModel!=null) { Text(makeModel,"car make/model",60);count++; }
            if(rego!=null) { Order.Require(Regex.IsMatch(rego,@"^[A-Za-z0-9 -]{0,15}$"),"The rego takes letters, digits, spaces and - (15 at most).");count++; }
            if(odometer!=null) { Order.Require(Regex.IsMatch(odometer,@"^\d{0,7}$"),"The odometer takes digits only (7 at most).");count++; }
            if(lines!=null) {
                Order.Require(lines.Count<=25,"Too many line changes.");
                var seen=new HashSet<int>();
                foreach(var l in lines) {
                    Order.Require(l!=null&&l.index>=0&&l.index<25&&seen.Add(l.index),"A line change is not valid.");
                    Order.Require(!String.IsNullOrWhiteSpace(l.code)&&Order.Norm(l.code).Length<=20,"A line change has no item code.");
                    if(l.remove) Order.Require(l.qty==null&&l.price==null&&l.text==null,"A line that is taken out can't be changed as well.");
                    else Order.Require(l.qty!=null||l.price!=null||l.text!=null,"A line change changes nothing.");
                    if(l.qty!=null) Order.Require(IsQty(l.qty),"Quantities are 0.01 to 9999 (two decimals at most).");
                    if(l.price!=null) Order.Require(IsPrice(l.price),"Prices are dollars and cents, up to $999,999.99.");
                    if(l.text!=null) { Text(l.text,"note",80);Order.Require(l.text.Trim().Length>0,"A note can't be empty: take the line out instead."); }
                    count++;
                }
            }
            if(add!=null) {
                Order.Require(add.Count<=MaxAdds,"Add "+MaxAdds+" lines at most at a time.");
                foreach(var a in add) {
                    Order.Require(a!=null&&(a.kind=="item"||a.kind=="note"),"A new line is not valid.");
                    if(a.kind=="item") {
                        Order.Require(IsNewCode(a.code),"New item codes are COSTAR codes (letters, digits, spaces and . _ / -), not DET or M.");
                        Order.Require(a.text==null,"An item has no note.");
                        // M codes (M FB ...) are COSTAR's own note lines: no quantity or price.
                        Order.Require(!Order.Norm(a.code).StartsWith("M ",StringComparison.Ordinal)||(a.qty==null&&a.price==null),Order.Norm(a.code)+" is a note line in COSTAR: it has no quantity or price.");
                        if(a.qty!=null) Order.Require(IsQty(a.qty),"Quantities are 0.01 to 9999 (two decimals at most).");
                        if(a.price!=null) Order.Require(IsPrice(a.price),"Prices are dollars and cents, up to $999,999.99.");
                    } else {
                        Order.Require(Order.Norm(a.code)=="M"&&a.qty==null&&a.price==null,"A new note is an M line with words.");
                        Text(a.text,"note",80);Order.Require(!String.IsNullOrWhiteSpace(a.text),"A new note has no words.");
                    }
                    count++;
                }
            }
            Order.Require(count>0,"Nothing to change.");
        }
        internal bool CarChange { get { return makeModel!=null||rego!=null||odometer!=null; } }
        // The rules against the Repair Order as it is now (the helper, after reading it again).
        internal void Validate(RoSnapshot now) {
            ValidateShape();
            Order.Require(now!=null&&now.doc==doc,"This change is for another Repair Order.");
            Order.Require(now.sig==baseSig,"CHANGED: Repair Order "+doc+" changed after the phone read it.");
            var cannot=now.cannot??new Dictionary<string,string>();
            Func<string,string> why=delegate(string key) { string w;return cannot.TryGetValue(key,out w)?w:null; };
            if(header!=null) foreach(var pair in header) {
                string w=why(pair.Key);Order.Require(w==null,"The "+Label(pair.Key)+" can't be changed from the phone: "+w);
                int limit;
                if(now.limits!=null&&now.limits.TryGetValue(pair.Key,out limit)&&limit>0) Order.Require(Entry(pair.Key,pair.Value).Length<=limit,"The "+Label(pair.Key)+" takes "+limit+" letters at most in COSTAR.");
            }
            foreach(var key in new[]{"shipVia","dateIn","customerWaiting"}) {
                bool asked=key=="shipVia"?shipVia!=null:key=="dateIn"?dateIn!=null:customerWaiting!=null;
                string w=why(key);if(asked) Order.Require(w==null,Label(key)+" can't be changed from the phone: "+w);
            }
            if(CarChange) { string w=why("car");Order.Require(w==null,"The car can't be changed from the phone: "+w); }
            var all=now.lines??new List<RoLine>();
            int removed=0;
            if(lines!=null) foreach(var l in lines) {
                Order.Require(l.index<all.Count&&Order.Norm(all[l.index].code)==Order.Norm(l.code),"Line "+(l.index+1)+" is not "+Order.Norm(l.code)+" any more. Open the Repair Order again.");
                var line=all[l.index];
                Order.Require(line.kind!="det"&&line.kind!="car","DET and the car notes are changed in the car section, never taken out here.");
                if(l.remove) { removed++;string w=why("remove");Order.Require(w==null,"Lines can't be taken out from the phone: "+w);continue; }
                Order.Require(l.text==null||line.kind=="note","Only note lines have words to change.");
                Order.Require((l.qty==null&&l.price==null)||line.kind=="item","Only item lines have a quantity and a price.");
                Order.Require(l.qty==null||line.qty.Length>0,"Line "+(l.index+1)+" ("+line.code+") has no quantity box in COSTAR.");
                Order.Require(l.price==null||(Order.Norm(line.code)=="F"?line.list:line.net).Length>0,"Line "+(l.index+1)+" ("+line.code+") has no price box in COSTAR.");
            }
            int adds=(add==null?0:add.Count)+(CarChange&&!now.det?4:0);
            if(adds>0) { string w=why("add");Order.Require(w==null,"Lines can't be added from the phone: "+w); }
            Order.Require(all.Count-removed+adds<=Grid.CostarLines,"COSTAR has "+Grid.CostarLines+" lines: take something out first.");
        }
        internal string ContentHash() { return Wire.Hash(Encoding.UTF8.GetBytes(Wire.Json(this))); }
        // What is being changed, in words (no customer details), for logs and the desk.
        internal string Summary() {
            var parts=new List<string>();
            if(header!=null&&header.Count>0) parts.Add(String.Join(", ",header.Keys.Select(Label).ToArray()));
            if(CarChange) parts.Add("car");
            if(shipVia!=null) parts.Add("Ship Via");
            if(dateIn!=null) parts.Add("Date In");
            if(customerWaiting!=null) parts.Add(customerWaiting=="yes"?"Customer Waiting ticked":"Customer Waiting unticked");
            if(lines!=null) {
                int taken=lines.Count(l=>l.remove),changed=lines.Count-taken;
                if(changed>0) parts.Add(changed+" line(s) changed");
                if(taken>0) parts.Add(taken+" line(s) taken out");
            }
            if(add!=null&&add.Count>0) parts.Add(add.Count+" line(s) added");
            return String.Join("; ",parts.ToArray());
        }
    }

    // Reading a Repair Order the helper opened, from its controls (no clicks, no typing).
    internal static class RoRead {
        static readonly string[] CarPrefixes={"MAKE/MODEL","REGO NO","ODOMETER"};
        internal static string Num(string text) {
            decimal n;string t=(text??"").Replace(",","").Trim();
            return Decimal.TryParse(t,NumberStyles.Number,CultureInfo.InvariantCulture,out n)?n.ToString("0.####",CultureInfo.InvariantCulture):Order.Norm(text);
        }
        internal static int Cents(string text) {
            decimal n;string t=(text??"").Replace("$","").Replace(",","").Trim();
            if(!Decimal.TryParse(t,NumberStyles.Number,CultureInfo.InvariantCulture,out n)) return -1;
            return Decimal.ToInt32(Decimal.Round(n*100,0,MidpointRounding.AwayFromZero));
        }
        // Two-digit days first, so a box that shows 07/10/2026 gets 07/11/2026 back, not 7/11/2026.
        static readonly string[] DateFormats={"dd/MM/yyyy","d/MM/yyyy","d/M/yyyy","dd/MM/yy","d/MM/yy","d/M/yy","dd-MM-yyyy","d-MM-yyyy","dd MMM yyyy","d MMM yyyy","ddd d MMM yyyy","ddd, d MMM yyyy","dddd, d MMMM yyyy","d MMMM yyyy","yyyy-MM-dd"};
        static readonly Regex TimePart=new Regex(@"\s+\d{1,2}:\d{2}(:\d{2})?(\s*[AaPp]\.?[Mm]\.?)?$");
        // The date a box shows and the format it shows it in (a time after the date is allowed and
        // ignored); false when it isn't a date.
        internal static bool ParseDate(string text,out DateTime date,out string format) {
            string t=TimePart.Replace(Regex.Replace(Order.Clean(text),@"\s+"," "),"");
            foreach(var f in DateFormats) if(DateTime.TryParseExact(t,f,CultureInfo.InvariantCulture,DateTimeStyles.None,out date)) { format=f;return true; }
            date=DateTime.MinValue;format=null;return false;
        }
        // The text to type for a new date: in the format the box shows now (dd/MM/yyyy if it shows
        // none), keeping a time that follows the date.
        internal static string DateText(string current,DateTime want) {
            DateTime d;string f;string text=Regex.Replace(Order.Clean(current),@"\s+"," ");
            var time=TimePart.Match(text);
            string date=want.ToString(ParseDate(current,out d,out f)?f:"dd/MM/yyyy",CultureInfo.InvariantCulture);
            return time.Success?date+time.Value:date;
        }
        internal static string DateKey(string text) { DateTime d;string f;return ParseDate(text,out d,out f)?d.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture):Order.Norm(text); }
        static bool CarNote(string code,string description) {
            string c=Order.Norm(code),d=Order.Norm(description);
            return (c=="M"&&(d.StartsWith("MAKE/MODEL:",StringComparison.Ordinal)||d.StartsWith("REGO NO:",StringComparison.Ordinal)))||(c=="M ODO"&&d.StartsWith("ODOMETER:",StringComparison.Ordinal));
        }
        internal static string Kind(string code) {
            string c=Order.Norm(code);
            if(c=="DET") return "det";
            if(c=="M"||c.StartsWith("M ",StringComparison.Ordinal)) return "note";
            return "item";
        }
        // The value of a DET note after its prefix ("MAKE/MODEL: X" -> "X").
        internal static string After(string description,string prefix) {
            string d=Order.Clean(description);
            return d.Length>prefix.Length+1?d.Substring(prefix.Length+1).Trim():"";
        }
        // The lines of the grid, with DET's notes marked as the car's (only with exactly one DET).
        internal static List<RoLine> Lines(List<ControlInfo> s,Grid g,bool counted) {
            var lines=new List<RoLine>();
            for(int i=0;i<g.Rows.Count;i++) {
                var r=g.Rows[i];if(r.Value.Length==0) continue;
                string code=Order.Norm(r.Value);
                var line=new RoLine {n=counted?i+1:0,code=code,kind=Kind(code),description="",qty="",net="",list=""};
                line.description=CellText(s,r,g.Description);
                if(line.kind=="item") { line.qty=CellText(s,r,g.Quantity);line.net=CellText(s,r,g.Net);line.list=CellText(s,r,g.ListPrice); }
                lines.Add(line);
            }
            if(lines.Count(l=>l.kind=="det")==1) foreach(var l in lines) if(l.kind=="note"&&CarNote(l.code,l.description)) l.kind="car";
            return lines;
        }
        // Lines without an item code that still hold words or a price (a quantity alone doesn't count:
        // an empty line may show one).
        internal static int Loose(List<ControlInfo> s,Grid g) {
            int n=0;
            foreach(var r in g.Rows) {
                if(r.Value.Length>0) continue;
                if(CellText(s,r,g.Description).Length>0||Priced(CellText(s,r,g.Net))||Priced(CellText(s,r,g.ListPrice))) n++;
            }
            return n;
        }
        static bool Priced(string text) { return !String.IsNullOrWhiteSpace(text)&&Cents(text)!=0; }
        static string CellText(List<ControlInfo> s,ControlInfo row,ControlInfo column) {
            try { var c=Selectors.Cell(s,row,column);return c.TextState=="read"?Order.Clean(c.Text):""; }
            catch(InvalidOperationException) { return ""; }
        }
        static bool Locked(ControlInfo c) { return c==null||!c.Enabled||(c.Style&0x800)!=0; }
        // The snapshot from a full read of the Repair Order. waiting: yes/no/"" with why ("" if read);
        // limitOf: the box's letter limit (0 unknown). dateKind: edit, combo, picker or "".
        internal static RoSnapshot Build(List<ControlInfo> s,string doc,string waiting,string waitingWhy,Func<ControlInfo,int> limitOf) {
            var h=Selectors.Header(s);var g=Selectors.ProductGrid(s);bool counted=g.Countable();
            var snap=new RoSnapshot {doc=doc,readUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture),cannot=new Dictionary<string,string>(),limits=new Dictionary<string,int>(),counted=counted};
            var fields=new Dictionary<string,ControlInfo> {{"name",h.Name},{"phone",h.Phone},{"email",h.Email},{"address",h.Address},{"address2",h.Address2},{"suburb",h.Suburb},{"state",h.State},{"postcode",h.Postcode},{"po",h.PO},{"comment",h.Comment}};
            snap.account=h.Account.Value;snap.name=h.Name.Value;snap.phone=h.Phone.Value;snap.email=h.Email.Value;snap.address=h.Address.Value;snap.address2=h.Address2.Value;
            snap.suburb=h.Suburb.Value;snap.state=h.State.Value;snap.postcode=h.Postcode.Value;snap.po=h.PO.Value;snap.comment=h.Comment.Value;
            foreach(var pair in fields) {
                if(Locked(pair.Value)) snap.cannot[pair.Key]="it is locked in COSTAR on this Repair Order.";
                int limit=limitOf==null?0:limitOf(pair.Value);if(limit>0&&limit<1000) snap.limits[pair.Key]=limit;
            }
            // A phone change makes COSTAR look the customer up, which may load another account: only on
            // a Repair Order without a customer account.
            if(snap.account.Length>0&&!snap.cannot.ContainsKey("phone")) snap.cannot["phone"]="this Repair Order is on COSTAR account "+snap.account+". Change the phone in COSTAR.";
            var ship=Selectors.ShipVia(s);
            snap.shipVia=ship==null?"":ship.Value;
            if(ship==null) snap.cannot["shipVia"]="the Ship Via box isn't showing (the Ship to tab may be hidden).";
            else if(Locked(ship)) snap.cannot["shipVia"]="it is locked in COSTAR on this Repair Order.";
            else { int limit=limitOf==null?0:limitOf(ship);if(limit>0&&limit<1000) snap.limits["shipVia"]=limit; }
            var time=Selectors.TimeIn(s);snap.timeIn=time==null?"":time.Value;
            string kind;var date=RoSelectors.DateIn(s,out kind);
            snap.dateIn=date==null?"":Order.Clean(date.Text);
            DateTime when;string format;
            if(date==null) snap.cannot["dateIn"]="no Date In box was found on this Repair Order.";
            else if(kind=="picker") snap.cannot["dateIn"]="Date In is a calendar box in COSTAR: change it there.";
            else if(Locked(date)) snap.cannot["dateIn"]="it is locked in COSTAR on this Repair Order.";
            else if(snap.dateIn.Length>0&&!ParseDate(snap.dateIn,out when,out format)) snap.cannot["dateIn"]="COSTAR shows it as \""+snap.dateIn+"\", which the helper can't read as a date.";
            var by=EbaySelectors.UnderLabel(s,"WRITTEN BY");snap.writtenBy=by==null?"":by.Value;
            snap.customerWaiting=waiting??"";
            if(snap.customerWaiting.Length==0||!String.IsNullOrEmpty(waitingWhy)) snap.cannot["customerWaiting"]=String.IsNullOrEmpty(waitingWhy)?"the Customer Waiting box couldn't be read.":waitingWhy;
            snap.lines=Lines(s,g,counted);snap.loose=Loose(s,g);
            snap.det=snap.lines.Count(l=>l.kind=="det")==1;
            int dets=snap.lines.Count(l=>l.kind=="det");
            if(dets>1) snap.cannot["car"]="this Repair Order has "+dets+" DET lines.";
            if(snap.det) {
                foreach(var prefix in CarPrefixes) {
                    var notes=snap.lines.Where(l=>l.kind=="car"&&Order.Norm(l.description).StartsWith(prefix+":",StringComparison.Ordinal)).ToList();
                    string value=notes.Count==1?After(notes[0].description,prefix):"";
                    if(notes.Count!=1&&!snap.cannot.ContainsKey("car")) snap.cannot["car"]="DET's "+prefix+" note is "+(notes.Count==0?"missing":"there "+notes.Count+" times")+".";
                    if(prefix=="MAKE/MODEL") snap.makeModel=value; else if(prefix=="REGO NO") snap.rego=value; else snap.odometer=value;
                }
            } else { snap.makeModel="";snap.rego="";snap.odometer=""; }
            snap.totalCents=Selectors.Total(s);
            snap.sig=Signature(snap);
            return snap;
        }
        // What the Repair Order holds, in one fingerprint: what the phone was shown must still be there
        // when its changes are typed. Time in, Written By and List prices are left out (not changed here).
        internal static string Signature(RoSnapshot s) {
            var b=new StringBuilder();
            Action<string> add=delegate(string v){b.Append(Order.Norm(v)).Append('|');};
            add(s.doc);
            foreach(var v in new[]{s.account,s.name,s.phone,s.email,s.address,s.address2,s.suburb,s.state,s.postcode,s.po,s.comment,s.shipVia}) add(v);
            add(DateKey(s.dateIn));add(s.customerWaiting);add(s.det?"DET":"-");
            b.Append(s.totalCents.ToString(CultureInfo.InvariantCulture)).Append('|');
            if(s.loose>0) b.Append("loose ").Append(s.loose.ToString(CultureInfo.InvariantCulture)).Append('|');
            foreach(var l in s.lines??new List<RoLine>()) {
                add(l.code);add(l.description);
                if(l.kind=="item") { add(Num(l.qty));b.Append(Cents(l.net).ToString(CultureInfo.InvariantCulture)).Append('|'); }
                b.Append(';');
            }
            return Wire.Hash(Encoding.UTF8.GetBytes(b.ToString())).Substring(0,16);
        }
    }

    internal static class RoSelectors {
        static readonly string[] DateLabels={"DATE IN","REPAIR DATE","DATE IN:","REPAIR DATE:"};
        // The Repair Order's Date In (or Repair Date) box: the box under its label. kind: edit (a text
        // box), combo (a drop-down with a text box inside; the text box is returned) or picker (a
        // calendar box; read only). Null when there is no such label or box.
        internal static ControlInfo DateIn(List<ControlInfo> s,out string kind) {
            kind="";
            var labels=s.Where(c=>c.Static&&DateLabels.Contains(Order.Norm(c.Peek))).ToList();
            if(labels.Count!=1) return null;
            var label=labels[0];int t=Math.Max(4,label.H/3);
            var under=s.Where(c=>c.Visible&&c.Parent==label.Parent&&c.RelativeBounds!=null&&Selectors.Near(c.X,label.X,t)&&Selectors.Near(c.Y,label.Y+label.H,t)&&c.Handle!=label.Handle).ToList();
            var edits=under.Where(c=>c.Edit).ToList();
            if(edits.Count==1) { kind="edit";return edits[0]; }
            var combos=under.Where(c=>c.Class.IndexOf("COMBOBOX",StringComparison.OrdinalIgnoreCase)>=0).ToList();
            if(combos.Count==1) {
                var inner=s.Where(c=>c.Edit&&c.Parent==combos[0].Handle).ToList();
                if(inner.Count==1) { kind="combo";return inner[0]; }
            }
            var pickers=under.Where(c=>c.Class.IndexOf("DATETIMEPICK",StringComparison.OrdinalIgnoreCase)>=0||c.Class.IndexOf("DATETIMEPICKER",StringComparison.OrdinalIgnoreCase)>=0).ToList();
            if(pickers.Count==1) { kind="picker";return pickers[0]; }
            return null;
        }
    }

    // What the Repair Order must hold after a change: the boxes asked for, the lines asked for (the old
    // ones in their order, the new ones wherever COSTAR put them), and nothing else moved.
    internal static class RoExpect {
        sealed class Want { internal string Code,Description,Qty;internal int Cents=-1;internal bool Item,Fresh,AnyDescription; }
        static int Price(string price) { return RoRead.Cents(price); }
        // Problems: what is not as asked. Notes: what COSTAR changed by itself (said, not a stop).
        internal static List<string> Check(RoSnapshot before,RoEdit edit,RoSnapshot after,List<string> notes) {
            var problems=new List<string>();
            Func<RoSnapshot,string,string> get=delegate(RoSnapshot s,string key) {
                switch(key) { case "name":return s.name;case "phone":return s.phone;case "email":return s.email;case "address":return s.address;case "address2":return s.address2;
                    case "suburb":return s.suburb;case "state":return s.state;case "postcode":return s.postcode;case "po":return s.po;case "comment":return s.comment;default:return ""; }
            };
            var asked=edit.header??new Dictionary<string,string>();
            foreach(var key in RoEdit.HeaderKeys) {
                string now=get(after,key),was=get(before,key);string value;
                if(asked.TryGetValue(key,out value)) {
                    bool same=key=="phone"?Order.Phone(now)==Order.Phone(value):key=="email"?Order.Clean(now)==RoEdit.Entry(key,value):Order.Norm(now)==Order.Norm(RoEdit.Entry(key,value));
                    if(!same) problems.Add("The "+RoEdit.Label(key)+" didn't keep the new value.");
                } else if(key=="name"||key=="phone") {
                    if(key=="phone"?Order.Phone(now)!=Order.Phone(was):Order.Norm(now)!=Order.Norm(was)) problems.Add("COSTAR changed the customer's "+RoEdit.Label(key)+".");
                } else if(Order.Norm(now)!=Order.Norm(was)) notes.Add("COSTAR also changed the "+RoEdit.Label(key)+".");
            }
            if(Order.Norm(after.account)!=Order.Norm(before.account)) problems.Add("COSTAR changed the customer account.");
            if(edit.shipVia!=null) { if(Order.Norm(after.shipVia)!=Order.Norm(edit.shipVia)) problems.Add("Ship Via didn't keep "+Order.Norm(edit.shipVia)+"."); }
            else if(Order.Norm(after.shipVia)!=Order.Norm(before.shipVia)) notes.Add("COSTAR also changed Ship Via.");
            if(edit.dateIn!=null) { if(RoRead.DateKey(after.dateIn)!=edit.dateIn) problems.Add("Date In didn't keep the new date."); }
            else if(RoRead.DateKey(after.dateIn)!=RoRead.DateKey(before.dateIn)) notes.Add("COSTAR also changed Date In.");
            if(edit.customerWaiting!=null&&after.customerWaiting!=edit.customerWaiting) problems.Add("Customer Waiting is not "+(edit.customerWaiting=="yes"?"ticked":"unticked")+".");
            if(edit.CarChange) {
                if(!after.det) problems.Add("The Repair Order has no DET line for the car.");
                else {
                    if(edit.makeModel!=null&&Order.Norm(after.makeModel)!=Order.Norm(edit.makeModel)) problems.Add("The car make/model didn't keep the new value.");
                    if(edit.rego!=null&&Order.Norm(after.rego)!=Order.Norm(edit.rego)) problems.Add("The rego didn't keep the new value.");
                    if(edit.odometer!=null&&Order.Norm(after.odometer)!=Order.Norm(edit.odometer)) problems.Add("The odometer didn't keep the new value.");
                }
            }
            string lineProblem=Lines(before,edit,after);
            if(lineProblem!=null) problems.Add(lineProblem);
            // A line COSTAR half took out (no code, its words or price still there) isn't one of the
            // lines above, but it is still on the Repair Order (and in its total).
            if(after.loose>before.loose) problems.Add("A line lost its item code but kept its words or price: check the lines in COSTAR.");
            // Nothing priced was asked to change: the total must be the same.
            var old=before.lines??new List<RoLine>();
            bool priced=(edit.lines!=null&&edit.lines.Any(l=>l.qty!=null||l.price!=null||(l.remove&&l.index<old.Count&&old[l.index].kind=="item")))
                ||(edit.add!=null&&edit.add.Any(a=>a.kind=="item"))||(edit.CarChange&&!before.det);
            if(!priced&&after.totalCents!=before.totalCents) problems.Add("COSTAR's total went from $"+(before.totalCents/100m).ToString("0.00",CultureInfo.InvariantCulture)+" to $"+(after.totalCents/100m).ToString("0.00",CultureInfo.InvariantCulture)+", though no price, quantity or item line was changed.");
            return problems;
        }
        static string Note(string prefix,string value) { return Order.Norm(prefix+":"+(String.IsNullOrWhiteSpace(value)?"":" "+value)); }
        // The old lines in their order (changed as asked, the ones taken out gone) and the new lines
        // anywhere among them: null when the Repair Order holds exactly that.
        internal static string Lines(RoSnapshot before,RoEdit edit,RoSnapshot after) {
            var kept=new List<Want>();var fresh=new List<Want>();
            var changes=new Dictionary<int,RoLineEdit>();
            if(edit.lines!=null) foreach(var l in edit.lines) changes[l.index]=l;
            var old=before.lines??new List<RoLine>();
            for(int i=0;i<old.Count;i++) {
                var l=old[i];RoLineEdit c;changes.TryGetValue(i,out c);
                if(c!=null&&c.remove) continue;
                var w=new Want {Code=Order.Norm(l.code),Description=Order.Norm(l.description),Item=l.kind=="item"};
                if(w.Item) { w.Qty=RoRead.Num(l.qty);w.Cents=RoRead.Cents(w.Code=="F"?l.list:l.net); }
                if(c!=null) {
                    if(c.qty!=null) w.Qty=RoRead.Num(c.qty);
                    if(c.price!=null) w.Cents=Price(c.price);
                    if(c.text!=null) w.Description=Order.Norm(c.text);
                }
                if(l.kind=="car") {
                    string d=Order.Norm(l.description);
                    if(d.StartsWith("MAKE/MODEL:",StringComparison.Ordinal)&&edit.makeModel!=null) w.Description=Note("MAKE/MODEL",edit.makeModel);
                    if(d.StartsWith("REGO NO:",StringComparison.Ordinal)&&edit.rego!=null) w.Description=Note("REGO NO",edit.rego);
                    if(d.StartsWith("ODOMETER:",StringComparison.Ordinal)&&edit.odometer!=null) w.Description=Note("ODOMETER",edit.odometer);
                }
                // A new quantity alone: COSTAR may price the item again for it (its own rule), so the price isn't judged.
                if(w.Item&&c!=null&&c.qty!=null&&c.price==null) w.Cents=-1;
                kept.Add(w);
            }
            if(edit.add!=null) foreach(var a in edit.add) {
                if(a.kind=="item") fresh.Add(new Want {Code=Order.Norm(a.code),Item=true,Fresh=true,AnyDescription=true,Qty=a.qty==null?null:RoRead.Num(a.qty),Cents=a.price==null?-1:Price(a.price)});
                else fresh.Add(new Want {Code="M",Description=Order.Norm(a.text),Fresh=true});
            }
            if(edit.CarChange&&!before.det) {
                fresh.Add(new Want {Code="DET",Fresh=true,AnyDescription=true});
                fresh.Add(new Want {Code="M",Description=Note("MAKE/MODEL",edit.makeModel),Fresh=true});
                fresh.Add(new Want {Code="M",Description=Note("REGO NO",edit.rego),Fresh=true});
                fresh.Add(new Want {Code="M ODO",Description=Note("ODOMETER",edit.odometer),Fresh=true});
            }
            var now=after.lines??new List<RoLine>();
            var memo=new Dictionary<long,bool>();
            if(Match(now,0,kept,0,fresh,0,memo)) return null;
            return "COSTAR's lines are not as asked. Expected "+String.Join(", ",kept.Select(w=>w.Code).ToArray())+(fresh.Count>0?" and new "+String.Join(", ",fresh.Select(w=>w.Code).ToArray()):"")+"; it shows "+String.Join(", ",now.Select(l=>Order.Norm(l.code)).ToArray())+".";
        }
        static bool Fits(Want w,RoLine l) {
            if(Order.Norm(l.code)!=w.Code) return false;
            string d=Order.Norm(l.description);
            if(w.AnyDescription) { if(w.Code!="DET"&&w.Item&&d.Length==0) return false; }
            else if(d!=w.Description) return false;
            if(w.Item) {
                if(w.Qty!=null&&RoRead.Num(l.qty)!=w.Qty) return false;
                if(w.Cents>=0&&RoRead.Cents(w.Code=="F"?l.list:l.net)!=w.Cents) return false;
            }
            return true;
        }
        static bool Match(List<RoLine> now,int i,List<Want> kept,int j,List<Want> fresh,int used,Dictionary<long,bool> memo) {
            if(i==now.Count) return j==kept.Count&&used==(1<<fresh.Count)-1;
            long key=((long)i*64+j)*8192+used;bool known;
            if(memo.TryGetValue(key,out known)) return known;
            bool ok=false;
            if(j<kept.Count&&Fits(kept[j],now[i])) ok=Match(now,i+1,kept,j+1,fresh,used,memo);
            for(int k=0;!ok&&k<fresh.Count;k++) if((used&(1<<k))==0&&Fits(fresh[k],now[i])) ok=Match(now,i+1,kept,j,fresh,used|(1<<k),memo);
            memo[key]=ok;return ok;
        }
    }

    // Words for the day log (shared as diagnostics): no customer details. What COSTAR said (quoted, or
    // after "said:"), account numbers and long numbers are left out; phones and emails as everywhere.
    internal static class RoText {
        internal static string ForLog(string message) {
            string m=Regex.Replace(message??"","\"[^\"]*\"","\"...\"");
            m=Regex.Replace(m,@"\b(It said|said|says|asked)\b:[^.]*","$1: ...",RegexOptions.IgnoreCase);
            m=Regex.Replace(m,@"\baccount\s+\S+","account ...",RegexOptions.IgnoreCase);
            m=Regex.Replace(m,@"\b[A-Za-z]{0,3}\d{5,}\b","#");
            return Sanitize.Text(m,400);
        }
    }

    // ---- The desk's queue of phone requests ------------------------------------------------
    // kind: list (read the WIP list), open (open, read and close a Repair Order), edit (open it, check
    // it, type the changes, check them, close it), close (close a Repair Order the helper left open
    // when a change stopped) or print (2.6.2: open it, read it, print its Job Card, close it). status:
    // queued, working, done or failed. Kept in memory only: a phone asks again after the desk restarts.
    // fresh (2.6.1, a list read): read just now (↻ on the phone), not Order Check's copy from minutes ago.
    public sealed class RoAsk { public string id,kind,doc;public RoEdit edit;public bool fresh; }
    public sealed class RoStatus {
        public string id,kind,doc,status,message,progress,waiting,updatedUtc;public int version;
        // typed: something was changed in COSTAR; leftOpen: the Repair Order is still open there.
        public bool typed,leftOpen;public RoSnapshot snapshot;public List<string> notes;
    }
    public sealed class RoTask { public string id,lease,kind,doc;public RoEdit edit;public bool fresh; }
    public sealed class RoReport {
        public string id,lease,status,message,progress;public int sequence;public bool typed,leftOpen;
        public RoSnapshot snapshot;public RoList list;public List<string> notes;
    }
    // working: the lease of the request the helper is doing right now ("" none); declined: a request it
    // was handed but can't start now (it waits again, with the reason); sequence: the helper's report
    // counter when it wrote this (a request it no longer works on is failed only by a later hello).
    // print (2.6.2): this RDP helper prints Job Cards (print requests, and edits with print).
    public sealed class RoHello { public string workerId,detail,working,declined,declineReason;public bool accepting,available,print;public RoReport report;public int waitMs,sequence; }
    // command: do (task) or wait. ack: the sequence of the report the desk took (the helper drops it).
    public sealed class RoReply { public string command;public RoTask task;public int ack,waitedMs;public bool held; }
    internal sealed class RoRequest {
        internal string Id,Kind,Doc,Hash,Status,Message="",Progress="",Lease,WorkerId;internal RoEdit Edit;
        internal DateTime Created,Updated;internal int Version,WorkerSequence;internal bool AwaitingWorker,Typed,LeftOpen,Fresh;
        internal RoSnapshot Snapshot;internal List<string> Notes=new List<string>();
        internal RoStatus View() {
            return new RoStatus {id=Id,kind=Kind,doc=Doc,status=Status,message=Message,progress=Progress,version=Version,typed=Typed,leftOpen=LeftOpen,
                updatedUtc=Updated.ToString("o",CultureInfo.InvariantCulture),snapshot=Snapshot==null?null:Wire.Copy(Snapshot),notes=new List<string>(Notes)};
        }
    }
    internal sealed class RoQueue {
        readonly object gate=new object();readonly List<RoRequest> requests=new List<RoRequest>();RoList list;
        internal event Action Changed;
        internal const int MaxWaiting=20,Keep=200;
        internal static readonly TimeSpan QueuedLimit=TimeSpan.FromMinutes(10),SilentLimit=TimeSpan.FromSeconds(90),KeepFinished=TimeSpan.FromHours(3);
        // The clock (tests move it).
        internal Func<DateTime> Clock=delegate { return DateTime.UtcNow; };
        static readonly Regex Id=new Regex(@"^RO-[0-9a-fA-F-]{36}$");
        static readonly string[] Kinds={"list","open","edit","close","print"};
        void Fire() { var changed=Changed;if(changed!=null){try{changed();}catch(Exception){}} }
        void Set(RoRequest r,string status,string message) { r.Status=status;r.Message=EbayText.Clean(message??"",2000);r.Version++;r.Updated=Clock(); }
        internal RoList List { get { lock(gate) return list==null?null:Wire.Copy(list); } }
        internal RoStatus Get(string id) { lock(gate) { var r=requests.FirstOrDefault(x=>x.Id==id);return r==null?null:r.View(); } }
        // The list request waiting or being read, if any.
        internal RoStatus PendingList { get { lock(gate) { var r=requests.FirstOrDefault(x=>x.Kind=="list"&&(x.Status=="queued"||x.Status=="working"));return r==null?null:r.View(); } } }
        internal int Waiting { get { lock(gate) return requests.Count(x=>x.Status=="queued"||x.Status=="working"); } }
        // The newest requests first, for the desk window.
        internal List<RoStatus> Recent(int n) { lock(gate) return requests.OrderByDescending(x=>x.Created).Take(n).Select(x=>{var s=x.View();s.snapshot=null;return s;}).ToList(); }
        internal RoStatus Submit(RoAsk ask) {
            Order.Require(ask!=null&&Id.IsMatch(ask.id??""),"The request has no valid ID. Reload the Repair Orders page.");
            Order.Require(Kinds.Contains(ask.kind),"Unknown Repair Order request.");
            if(ask.kind!="list") Order.Require(RoEdit.IsDoc(ask.doc),"The Repair Order number isn't valid.");
            if(ask.kind=="edit") { Order.Require(ask.edit!=null,"The change is missing.");ask.edit.ValidateShape();Order.Require(ask.edit.doc==ask.doc,"The change is for another Repair Order."); }
            else Order.Require(ask.edit==null,"Only a change carries changes.");
            string hash=ask.kind=="edit"?ask.edit.ContentHash():"";
            RoStatus result;
            lock(gate) {
                Expire(DateTime.MinValue);
                var old=requests.FirstOrDefault(x=>x.Id==ask.id);
                if(old!=null) {
                    if(old.Kind!=ask.kind||old.Doc!=(ask.kind=="list"?"":ask.doc)||old.Hash!=hash) throw new InvalidOperationException("CONFLICT: This request ID was already used for something else. Reload the page.");
                    return old.View();
                }
                // One WIP read at a time, one open (one print) per Repair Order: a second ask joins the first.
                var same=requests.FirstOrDefault(x=>(x.Status=="queued"||x.Status=="working")&&((ask.kind=="list"&&x.Kind=="list")||((ask.kind=="open"||ask.kind=="print")&&x.Kind==ask.kind&&x.Doc==ask.doc)));
                if(same!=null) {
                    // A list read still waiting is made a fresh one when a phone asks for that (2.6.1).
                    if(ask.kind=="list"&&ask.fresh&&!same.Fresh&&same.Status=="queued") { same.Fresh=true;same.Version++; }
                    return same.View();
                }
                if(ask.kind=="edit"||ask.kind=="close") {
                    var busy=requests.FirstOrDefault(x=>(x.Status=="queued"||x.Status=="working")&&(x.Kind=="edit"||x.Kind=="close")&&x.Doc==ask.doc);
                    Order.Require(busy==null,"Repair Order "+ask.doc+" already has a change waiting. Wait for it to finish.");
                }
                Order.Require(requests.Count(x=>x.Status=="queued"||x.Status=="working")<MaxWaiting,"Too many Repair Order requests are waiting on the desk PC.");
                var now=Clock();
                var r=new RoRequest {Id=ask.id,Kind=ask.kind,Doc=ask.kind=="list"?"":ask.doc,Hash=hash,Edit=ask.edit==null?null:Wire.Copy(ask.edit),Created=now,Fresh=ask.kind=="list"&&ask.fresh};
                Set(r,"queued","Waiting for the RDP helper");
                requests.Add(r);Prune();result=r.View();
            }
            Fire();return result;
        }
        void Prune() {
            var now=Clock();
            requests.RemoveAll(x=>(x.Status=="done"||x.Status=="failed")&&now-x.Updated>KeepFinished);
            int extra=requests.Count-Keep;
            if(extra>0) foreach(var gone in requests.Where(x=>x.Status=="done"||x.Status=="failed").OrderBy(x=>x.Updated).Take(extra).ToList()) requests.Remove(gone);
        }
        // Under gate. Requests nobody got to in time fail; so does one the helper stopped answering
        // about (lastWorker: when the helper last polled; MinValue: don't judge that now).
        bool Expire(DateTime lastWorker) {
            var now=Clock();bool changed=false;
            foreach(var r in requests) {
                if(r.Status=="queued"&&now-r.Created>QueuedLimit) { r.AwaitingWorker=false;Set(r,"failed","Not done: the RDP helper didn't get to it within "+(int)QueuedLimit.TotalMinutes+" minutes. Try again.");changed=true; }
                else if(r.Status=="working"&&lastWorker!=DateTime.MinValue&&now-lastWorker>SilentLimit) {
                    r.AwaitingWorker=false;
                    Set(r,"failed",r.Kind=="edit"?"The RDP helper stopped answering while changing Repair Order "+r.Doc+". Check it in COSTAR Tempe before trying again."+(Prints(r)?" Its Job Card may have printed: check the printer.":"")
                        :r.Kind=="print"?"The RDP helper stopped answering while printing the Job Card of Repair Order "+r.Doc+": it may have printed. Check the printer before printing it again."
                        :"The RDP helper stopped answering. Try again.");
                    if(r.Kind=="edit") r.Typed=true;
                    changed=true;
                }
            }
            return changed;
        }
        // From the phone routes: the time-outs, with when the helper was last in touch.
        internal void Tidy(DateTime lastWorker) { bool changed;lock(gate) changed=Expire(lastWorker);if(changed) Fire(); }
        // Whether list `a` was read before list `b` (both with a read time).
        internal static bool Older(RoList a,RoList b) {
            DateTimeOffset x,y;
            return b!=null&&DateTimeOffset.TryParse(a.readUtc??"",CultureInfo.InvariantCulture,DateTimeStyles.None,out x)&&DateTimeOffset.TryParse(b.readUtc??"",CultureInfo.InvariantCulture,DateTimeStyles.None,out y)&&x<y;
        }
        static bool Prints(RoRequest r) { return r.Kind=="print"||(r.Kind=="edit"&&r.Edit!=null&&r.Edit.print); }
        static RoReply Do(RoRequest r,int ack) { return new RoReply {command="do",ack=ack,task=new RoTask {id=r.Id,lease=r.Lease,kind=r.Kind,doc=r.Doc,edit=r.Edit==null?null:Wire.Copy(r.Edit),fresh=r.Fresh}}; }
        internal RoReply Poll(RoHello hello) {
            Order.Require(hello!=null,"Missing worker hello.");
            RoReply reply;bool changed=false;
            lock(gate) {
                int ack=0;
                if(hello.report!=null) {
                    var p=hello.report;ack=p.sequence;var r=p.id==null?null:requests.FirstOrDefault(x=>x.Id==p.id);
                    // A report for a request this desk no longer has, or for another lease, is taken (acked) and dropped.
                    if(r!=null&&r.WorkerId==hello.workerId&&Wire.Equal(r.Lease,p.lease)&&p.sequence>r.WorkerSequence) {
                        Order.Require(p.status=="working"||p.status=="done"||p.status=="failed","Invalid Repair Order worker status.");
                        r.WorkerSequence=p.sequence;r.AwaitingWorker=false;r.Typed|=p.typed;r.LeftOpen=p.leftOpen;
                        if(p.snapshot!=null) r.Snapshot=Wire.Copy(p.snapshot);
                        if(p.notes!=null) r.Notes=p.notes.Select(n=>EbayText.Clean(n,600)).Take(20).ToList();
                        if(r.Status=="working") { Set(r,p.status,p.message);r.Progress=EbayText.Clean(p.progress,1000); }
                        // 2.6.1: an older list (Order Check's copy from minutes ago) never replaces a newer one.
                        if(r.Kind=="list"&&p.status=="done"&&p.list!=null&&!Older(p.list,list)) list=Wire.Copy(p.list);
                        changed=true;
                    }
                }
                if(!String.IsNullOrEmpty(hello.declined)) {
                    var d=requests.FirstOrDefault(x=>x.Status=="working"&&x.AwaitingWorker&&x.WorkerId==hello.workerId&&Wire.Equal(x.Lease,hello.declined));
                    if(d!=null) {
                        string why=EbayText.Clean(String.IsNullOrWhiteSpace(hello.declineReason)?"the RDP helper could not start it yet":hello.declineReason.Trim(),400);
                        d.Lease=null;d.WorkerId=null;d.AwaitingWorker=false;Set(d,"queued",why.StartsWith("Waiting",StringComparison.OrdinalIgnoreCase)?why:"Waiting: "+why);changed=true;
                    }
                }
                if(hello.working!=null) {
                    string reported=hello.report==null?null:hello.report.lease;
                    foreach(var o in requests.Where(x=>x.Status=="working"&&!x.AwaitingWorker&&x.WorkerId==hello.workerId&&!Wire.Equal(x.Lease,hello.working)&&!Wire.Equal(x.Lease,reported)&&x.WorkerSequence<=hello.sequence).ToList()) {
                        Set(o,"failed",o.Kind=="edit"?"The RDP helper stopped while changing Repair Order "+o.Doc+" (it was closed or restarted). Check it in COSTAR Tempe before trying again."+(Prints(o)?" Its Job Card may have printed: check the printer.":"")
                            :o.Kind=="print"?"The RDP helper stopped while printing the Job Card of Repair Order "+o.Doc+" (it was closed or restarted): it may have printed. Check the printer before printing it again."
                            :"The RDP helper stopped (it was closed or restarted). Try again.");
                        if(o.Kind=="edit") o.Typed=true;
                        changed=true;
                    }
                }
                changed|=Expire(DateTime.MinValue);
                // 2.6.2: a Job Card print goes only to an RDP helper that says it prints. One that changed
                // version since the phone looked would read a print as an open, or type a change without its
                // print: the request fails with nothing done, and the phone no longer offers the print.
                if(!hello.print) foreach(var x in requests.Where(x=>x.Status=="queued"&&Prints(x)).ToList()) {
                    Set(x,"failed",x.Kind=="print"?"Job Card not printed: the RDP helper on the COSTAR PC doesn't print Job Cards now (it changed version). Nothing was done."
                        :"Not saved: the RDP helper on the COSTAR PC doesn't print Job Cards now (it changed version), so nothing was typed. Save again.");
                    changed=true;
                }
                var again=requests.FirstOrDefault(x=>x.Status=="working"&&x.AwaitingWorker&&x.WorkerId==hello.workerId);
                // Handed over but not taken yet, and the helper now doesn't print: not handed over again.
                if(again!=null&&!hello.print&&Prints(again)) {
                    again.AwaitingWorker=false;
                    Set(again,"failed",again.Kind=="print"?"Job Card not printed: the RDP helper on the COSTAR PC doesn't print Job Cards now (it changed version)."
                        :"Not saved: the RDP helper on the COSTAR PC doesn't print Job Cards now (it changed version). Check Repair Order "+again.Doc+" in COSTAR Tempe before saving again.");
                    changed=true;again=null;
                }
                if(again!=null) reply=Do(again,ack);
                else if(!hello.accepting||requests.Any(x=>x.Status=="working"&&x.WorkerId==hello.workerId)) reply=new RoReply {command="wait",ack=ack};
                else {
                    // A WIP read goes whenever the helper takes requests (it reads Order Check's copy when
                    // COSTAR is busy); opening and changing a Repair Order only when COSTAR Tempe is free.
                    var next=requests.Where(x=>x.Status=="queued"&&(x.Kind=="list"||x.Kind=="close"||hello.available)).OrderBy(x=>x.Kind=="list"?0:1).ThenBy(x=>x.Created).FirstOrDefault();
                    if(next==null) reply=new RoReply {command="wait",ack=ack};
                    else {
                        next.WorkerId=hello.workerId;next.Lease=Wire.Token();next.AwaitingWorker=true;next.WorkerSequence=0;
                        Set(next,"working",next.Kind=="list"?"The RDP helper is reading COSTAR's Work-in-Progress":next.Kind=="close"?"The RDP helper is closing Repair Order "+next.Doc:"The RDP helper is opening Repair Order "+next.Doc+" in COSTAR Tempe"+(next.Kind=="print"?" to print its Job Card":""));
                        next.Progress="";changed=true;reply=Do(next,ack);
                    }
                }
            }
            if(changed) Fire();
            return reply;
        }
    }
}
