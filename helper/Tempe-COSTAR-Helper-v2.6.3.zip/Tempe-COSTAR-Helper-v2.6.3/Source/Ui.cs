using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace TempeCostar {
    // 2.4.0 look: one quiet palette, flat buttons, cards and state chips, built from plain
    // WinForms controls (no designer, no third-party libraries). Everything here is static
    // helpers, so the forms stay readable and the layout survives any DPI (fonts scale; sizes
    // below are in points/pixels at 96 DPI and grow with the form's AutoScaleMode).
    internal static class Ui {
        internal static readonly Color Canvas=Color.FromArgb(243,244,246),Surface=Color.White,Line=Color.FromArgb(229,231,235),
            Ink=Color.FromArgb(31,41,55),Muted=Color.FromArgb(107,114,128),Primary=Color.FromArgb(37,99,235),PrimaryDark=Color.FromArgb(29,78,216),
            Success=Color.FromArgb(21,128,61),Warn=Color.FromArgb(180,83,9),Danger=Color.FromArgb(185,28,28),Gold=Color.FromArgb(245,158,11),
            Info=Color.FromArgb(3,105,161),SuccessBack=Color.FromArgb(220,252,231),WarnBack=Color.FromArgb(254,243,199),DangerBack=Color.FromArgb(254,226,226),InfoBack=Color.FromArgb(224,242,254);
        internal static readonly Font Base=new Font("Segoe UI",10F),Bold=new Font("Segoe UI",10F,FontStyle.Bold),Big=new Font("Segoe UI",13F,FontStyle.Bold),Small=new Font("Segoe UI",9F);

        internal static Button PrimaryButton(string text,int width=200) {
            var b=new Button { Text=text,Width=width,Height=38,FlatStyle=FlatStyle.Flat,BackColor=Primary,ForeColor=Color.White,Font=Bold,Margin=new Padding(0,0,8,0),UseVisualStyleBackColor=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowOnly,MinimumSize=new Size(width,38),Padding=new Padding(8,0,8,0) };
            b.FlatAppearance.BorderSize=0;b.FlatAppearance.MouseOverBackColor=PrimaryDark;b.FlatAppearance.MouseDownBackColor=PrimaryDark;
            b.EnabledChanged+=delegate { b.BackColor=b.Enabled?Primary:Line;b.ForeColor=b.Enabled?Color.White:Muted; };
            return b;
        }
        internal static Button SecondaryButton(string text,int width=160) {
            var b=new Button { Text=text,Width=width,Height=38,FlatStyle=FlatStyle.Flat,BackColor=Surface,ForeColor=Ink,Font=Base,Margin=new Padding(0,0,8,0),UseVisualStyleBackColor=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowOnly,MinimumSize=new Size(width,38),Padding=new Padding(8,0,8,0) };
            b.FlatAppearance.BorderColor=Line;b.FlatAppearance.BorderSize=1;b.FlatAppearance.MouseOverBackColor=Canvas;
            b.EnabledChanged+=delegate { b.ForeColor=b.Enabled?Ink:Muted; };
            return b;
        }
        internal static Button DangerButton(string text,int width=200) {
            var b=SecondaryButton(text,width);b.ForeColor=Danger;b.FlatAppearance.BorderColor=Danger;
            b.EnabledChanged+=delegate { b.ForeColor=b.Enabled?Danger:Muted;b.FlatAppearance.BorderColor=b.Enabled?Danger:Line; };
            return b;
        }
        // A coloured pill with short bold text: READY, FILLING, NEEDS YOU, ...
        internal static Label Chip(string text,Color back) {
            return new Label { Text=text,AutoSize=true,BackColor=back,ForeColor=Color.White,Font=Bold,Padding=new Padding(12,6,12,6),Margin=new Padding(0),TextAlign=ContentAlignment.MiddleCenter };
        }
        internal static void SetChip(Label chip,string text,Color back) {
            if(chip.Text!=text) chip.Text=text;
            if(chip.BackColor!=back) chip.BackColor=back;
        }
        // A white card with a thin border and inner padding; stacks its children top-down.
        internal static Panel Card(int padding=12) {
            var p=new Panel { BackColor=Surface,Padding=new Padding(padding),Margin=new Padding(0,0,0,10),AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink };
            p.Paint+=delegate(object sender,PaintEventArgs e) { using(var pen=new Pen(Line)) e.Graphics.DrawRectangle(pen,0,0,p.Width-1,p.Height-1); };
            return p;
        }
        internal static Label Title(string text) { return new Label { Text=text,AutoSize=true,Font=Bold,ForeColor=Ink,Margin=new Padding(0,0,0,4) }; }
        internal static Label Text(string text,int maxWidth=760) { return new Label { Text=text,AutoSize=true,Font=Base,ForeColor=Ink,MaximumSize=new Size(maxWidth,0),Margin=new Padding(0,0,0,4) }; }
        internal static Label Hint(string text,int maxWidth=760) { return new Label { Text=text,AutoSize=true,Font=Small,ForeColor=Muted,MaximumSize=new Size(maxWidth,0),Margin=new Padding(0,0,0,4) }; }
        internal static Label BigText(string text) { return new Label { Text=text,AutoSize=true,Font=Big,ForeColor=Ink,Margin=new Padding(0,0,0,2) }; }
        internal static FlowLayoutPanel Row(int height=46) {
            return new FlowLayoutPanel { AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,FlowDirection=FlowDirection.LeftToRight,WrapContents=true,Margin=new Padding(0,0,0,6),MinimumSize=new Size(0,height),Padding=new Padding(0) };
        }
        internal static FlowLayoutPanel Column() {
            return new FlowLayoutPanel { Dock=DockStyle.Fill,FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoScroll=true,Padding=new Padding(14),BackColor=Canvas };
        }
        internal static void SetText(Label label,string text) { if(label.Text!=text) label.Text=text; }
        internal static CheckBox Check(string text,bool on) { return new CheckBox { Text=text,Checked=on,AutoSize=true,Font=Base,ForeColor=Ink,Margin=new Padding(0,6,16,6) }; }

        // The activity log: a RichTextBox with coloured lines. Stops and failures in red,
        // finished orders in green, warnings in amber, everything else in ink. Bounded like the
        // old TextBox log (BoundedLog.VisibleLimit).
        internal static RichTextBox Log() {
            return new RichTextBox { ReadOnly=true,DetectUrls=false,Font=Base,ForeColor=Ink,BackColor=Surface,BorderStyle=BorderStyle.FixedSingle,ScrollBars=RichTextBoxScrollBars.Vertical,WordWrap=true,Dock=DockStyle.Fill,HideSelection=false };
        }
        internal static Color LineColor(string line) {
            switch(LogLines.Kind(line)) { case 1: return Danger; case 2: return Success; case 3: return Warn; default: return Ink; }
        }
        internal static void AppendColoured(RichTextBox box,string text) {
            if(String.IsNullOrEmpty(text)) return;
            if(box.TextLength+text.Length>BoundedLog.VisibleLimit) {
                // Drop the oldest half; the day log keeps everything. (A read-only box refuses the
                // deletion, so it is lifted for the moment.)
                string all=box.Text;
                int cut=Math.Min(all.Length,Math.Max(text.Length,all.Length/2));
                int lineEnd=cut>0&&cut<=all.Length?all.IndexOf('\n',cut-1):-1;
                bool readOnly=box.ReadOnly;box.ReadOnly=false;
                try { box.Select(0,lineEnd<0?cut:Math.Min(all.Length,lineEnd+1));box.SelectedText=""; } finally { box.ReadOnly=readOnly; }
            }
            foreach(string raw in text.Split('\n')) {
                string line=raw.TrimEnd('\r');
                if(line.Length==0) continue;
                box.SelectionStart=box.TextLength;box.SelectionLength=0;
                box.SelectionColor=LineColor(line);
                box.AppendText(line+Environment.NewLine);
            }
            box.SelectionStart=box.TextLength;box.ScrollToCaret();
        }
    }
}
