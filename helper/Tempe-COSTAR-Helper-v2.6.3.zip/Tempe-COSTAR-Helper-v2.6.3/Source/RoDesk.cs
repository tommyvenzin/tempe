// The desk receiver's Repair Orders tab (2.6.0): what the phones asked the RDP helper to do with
// COSTAR Tempe's Repair Orders, and how it went. The requests live in memory only.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed partial class DeskForm {
        RoQueue roQueue;
        readonly ListView roList=new ListView {View=View.Details,FullRowSelect=true,HideSelection=false,Font=Ui.Base,MultiSelect=false,Dock=DockStyle.Fill};
        readonly Label roLine=Ui.Text("",780),chipRo=Ui.Chip("RO",Ui.Muted);
        string roSignature="";
        void SetupRo() {
            roQueue=new RoQueue();
            api.UseRo(roQueue);
        }
        Control BuildRoPage() {
            var layout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Padding=new Padding(8),BackColor=Ui.Canvas};
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            roList.Columns.Add("Time",70);roList.Columns.Add("Request",110);roList.Columns.Add("RO",90);roList.Columns.Add("Status",90);roList.Columns.Add("Message",400);
            layout.Controls.Add(roLine,0,0);layout.Controls.Add(roList,0,1);
            layout.Controls.Add(Ui.Hint("Phones open Repair Orders from COSTAR Tempe's Work-in-Progress and send changes straight in (Repair_Orders.html on the phone). The RDP helper opens each Repair Order, checks it still holds what the phone was shown, types the changes, checks them and closes it again. A change that stops leaves the Repair Order open in COSTAR Tempe for you to check.",780),0,2);
            return layout;
        }
        static string Kind(RoStatus s) {
            switch(s.kind) { case "list":return "WIP list";case "open":return "Open";case "edit":return "Change";case "close":return "Close";default:return s.kind; }
        }
        void UpdateRo() {
            if(roQueue==null) return;
            var recent=roQueue.Recent(60);
            string signature=String.Join("|",recent.Select(r=>r.id+":"+r.version).ToArray());
            if(signature!=roSignature) {
                roSignature=signature;
                roList.BeginUpdate();roList.Items.Clear();
                foreach(var r in recent) {
                    DateTime at;string time=DateTime.TryParse(r.updatedUtc,CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out at)?at.ToLocalTime().ToString("HH:mm:ss",CultureInfo.InvariantCulture):"";
                    string message=r.status=="working"&&!String.IsNullOrEmpty(r.progress)?r.progress:r.message;
                    if(r.notes!=null&&r.notes.Count>0) message+="  CHECK: "+String.Join(" ",r.notes.ToArray());
                    var item=new ListViewItem(new[]{time,Kind(r),r.doc,r.status,message});
                    item.ForeColor=r.status=="failed"?Ui.Danger:r.status=="done"?(r.notes!=null&&r.notes.Count>0?Ui.Warn:Ui.Success):r.status=="working"?Ui.Info:Ui.Ink;
                    roList.Items.Add(item);
                }
                roList.EndUpdate();
            }
            bool connected,on,ready;string detail;api.RoSide(out connected,out on,out ready,out detail);
            int waiting=roQueue.Waiting;int since=api.SecondsSinceRoWorker;
            Ui.SetChip(chipRo,!connected?"RO: RDP OFFLINE":!on?"RO: OFF":waiting>0?"RO: "+waiting+" WAITING":"RO: ON",!connected?Ui.Muted:!on?Ui.Warn:waiting>0?Ui.Info:Ui.Success);
            var list=roQueue.List;string read="";
            if(list!=null) { DateTime at;if(DateTime.TryParse(list.readUtc,CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out at)) read="  ·  WIP list read "+at.ToLocalTime().ToString("HH:mm",CultureInfo.InvariantCulture)+" ("+(list.rows==null?0:list.rows.Count)+" ROs"+(list.source=="order-check"?", from Order Check":"")+")"; }
            Ui.SetText(roLine,(connected?"RDP helper (Repair Orders) in touch "+(since<=1?"now":since+" s ago")+"  ·  "+(on?(ready?"COSTAR Tempe free":detail):"switched off there"+(detail.Length==0?"":" ("+detail+")")):"RDP helper (Repair Orders) not in touch"+(since>=0?" for "+since+" s":""))+(waiting>0?"  ·  "+waiting+" waiting":"")+read);
        }
    }
}
