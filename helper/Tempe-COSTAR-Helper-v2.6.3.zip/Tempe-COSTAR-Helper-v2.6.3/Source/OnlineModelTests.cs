// The online-order model and selector checks that run at every start (MobileTests calls them).
// Moved out of AutofillForm in 2.4.0 so they need no WinForms.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace TempeCostar {
    internal static class OnlineModelTests {
        internal static void SelfTest() {
            Order.Require(Marshal.SizeOf(typeof(Native.Input))==(IntPtr.Size==8?40:28),"Unexpected Windows INPUT structure layout.");
            var searching=new ControlInfo { Class="WindowsForms10.STATIC.app.0.13965fa_r10_ad1",Visible=true,Enabled=true,TextState="read",Text="Searching..." };
            var lookupControls=new List<ControlInfo>{searching};
            Order.Require(Selectors.CustomerSearchInProgress(lookupControls) && !Selectors.CustomerNotFoundNotice(lookupControls),"The recorded Searching panel must be recognised separately from an acknowledgement.");
            searching.Visible=false;Order.Require(!Selectors.CustomerSearchInProgress(lookupControls),"A hidden search indicator must not keep the lookup waiting.");
            searching.Visible=true;searching.TextState="read-failed-or-timed-out";Order.Require(!Selectors.CustomerSearchInProgress(lookupControls),"Unreadable text must not be treated as a known search indicator.");
            searching.TextState="read";searching.Text="Customer Not found";
            lookupControls.Add(new ControlInfo { Class="Button",Visible=true,Enabled=true,TextState="read",Text="OK" });
            Order.Require(Selectors.CustomerNotFoundNotice(lookupControls) && !Selectors.CustomerSearchInProgress(lookupControls),"The known Customer Not found notice must be acknowledged.");
            lookupControls.Add(new ControlInfo { Class="Button",Visible=true,Enabled=true,TextState="read",Text="Cancel" });
            Order.Require(!Selectors.CustomerNotFoundNotice(lookupControls),"A dialog offering another decision must not be dismissed as an acknowledgement.");
            Order.Require(Selectors.CustomerCancelButton(lookupControls)==lookupControls[2],"Recovery must choose Cancel rather than an unknown OK action.");
            lookupControls.RemoveAt(2);searching.Text="Confirm customer deletion";
            Order.Require(!Selectors.CustomerNotFoundNotice(lookupControls),"An unfamiliar OK dialog must not be mistaken for Customer Not found.");
            Order.Require(Selectors.CustomerCancelButton(lookupControls)==null,"An unknown OK button must never be selected as Cancel.");
            lookupControls[1].Text="&Close";
            Order.Require(Selectors.CustomerCancelButton(lookupControls)==lookupControls[1],"The popup Close button must be recognised.");
            lookupControls[1].Enabled=false;Order.Require(Selectors.CustomerCancelButton(lookupControls)==null,"A disabled Close button must not be used.");
            lookupControls[1].Enabled=true;lookupControls[1].Text="Save";
            Order.Require(Selectors.CustomerCancelButton(lookupControls)==null,"A Save button must not be used to dismiss a popup.");
            var json=new JavaScriptSerializer();
            var sample=json.Deserialize<Order>("{\"schema\":1,\"createdUtc\":\"2026-09-26T00:00:00Z\",\"orderId\":\"TTW100\",\"customer\":{\"name\":\"TEST CUSTOMER\",\"phone\":\"0400000000\"},\"rego\":\"\",\"vehicle\":\"TEST VEHICLE\",\"pickupDate\":\"2026-09-26\",\"pickupTime\":\"10:30\",\"comment\":\"SATURDAY - ONLINE 10:30\",\"totalCents\":19000,\"lines\":[{\"kind\":\"product\",\"sourceSku\":\"TEST123\",\"code\":\"TEST123\",\"description\":\"TEST TYRE\",\"quantity\":1,\"unitCents\":14000,\"totalCents\":14000},{\"kind\":\"service\",\"sourceSku\":\"TEST123\",\"code\":\"WA\",\"description\":\"SERVICES: FRONT WHEEL ALIGNMENT\",\"quantity\":1,\"unitCents\":5000,\"totalCents\":5000}]}");
            sample.Validate(false); sample.lines[1].code="WAFR";
            bool rejected=false; try { sample.Validate(false); } catch(InvalidOperationException) { rejected=true; }
            Order.Require(rejected,"Service mapping self-test failed.");
            sample.lines[1].description=": SERVICES: FRONT AND REAR WHEEL ALIGNMENT";
            sample.Validate(false); sample.lines[1].code="WA";
            rejected=false; try { sample.Validate(false); } catch(InvalidOperationException) { rejected=true; }
            Order.Require(rejected,"Front and rear alignment must use WAFR, including an empty-SKU prefix.");
            sample.lines[1].description=": SERVICES: Front Wheel Alignment";
            sample.Validate(false); sample.lines[1].code="WAFR";
            rejected=false; try { sample.Validate(false); } catch(InvalidOperationException) { rejected=true; }
            Order.Require(rejected,"Front-only alignment must use WA, including an empty-SKU prefix.");
            sample.lines[1].code="WA"; sample.surchargeCents=95; sample.totalCents=19095; sample.Validate(false);
            Order.Require(sample.MatchesCostarTotal(19000) && sample.MatchesCostarTotal(19095) && !sample.MatchesCostarTotal(19001),"Pickup automatic-surcharge total check failed.");
            var rearAlignment=new OrderLine { kind="service",code="WAFR",description=": SERVICES: FRONT AND REAR WHEEL ALIGNMENT" };
            var wheel=new OrderLine { kind="product",code="WHEEL1",description="18x8.5 TEST WHEEL" };
            var secondWheel=new OrderLine { kind="product",code="WHEEL2",description="18x9.5 TEST WHEEL" };
            var tyre=new OrderLine { kind="product",code="TYRE1",description="TEST 275/65R17" };
            var secondTyre=new OrderLine { kind="product",code="TYRE2",description="TEST 35X12.5R17" };
            var sequence=new Order { schema=1,lines=new List<OrderLine>{rearAlignment,tyre,wheel,secondTyre,secondWheel} };
            Order.Require(sequence.ItemSteps(true).Select(step=>step.Code).SequenceEqual(new[]{"WHEEL1","WHEEL2","TYRE1","TYRE2","M FB","WAFR"}),"Pickup entry must put wheels and tyres before M FB, then alignment.");
            Order.Require(sequence.lines[0]==rearAlignment && sequence.ItemSteps(true)[0].Line==wheel,"Planning must preserve source lines and their original identities/prices.");
            Order.Require(sequence.ItemSteps(false).Select(step=>step.Code).SequenceEqual(new[]{"WHEEL1","WHEEL2","TYRE1","TYRE2","WAFR"}),"Turning off fitting must retain the product/alignment order.");
            sequence.lines[0]=sample.lines[1];
            Order.Require(sequence.ItemSteps(true).Last().Code=="WA","Front-only alignment must also follow M FB.");
            sequence.schema=2;sequence.type="delivery";
            Order.Require(sequence.ItemSteps(true).Select(step=>step.Code).SequenceEqual(new[]{"WHEEL1","WHEEL2","TYRE1","TYRE2","WA"}),"Delivery entry must not add the in-store M FB note.");
            sequence.schema=1;sequence.type=null;sequence.lines=new List<OrderLine>{rearAlignment};
            Order.Require(sequence.ItemSteps(true).Select(step=>step.Code).SequenceEqual(new[]{"WAFR"}),"Alignment-only orders must not invent a fitting note.");
            var delivery=new Order { schema=2,type="delivery",createdUtc="2026-09-28T00:00:00Z",orderId="TTW100",deliveryMethod="FITTING PARTNER",requiresReview=true,
                customer=new Customer { name="TEST CUSTOMER",phone="0400000000",streetAddress="1 TEST ROAD",suburb="TEST SUBURB",state="VIC",postcode="3150" },
                shipping=new Shipping { name="TEST PARTNER",streetAddress="2 TEST ROAD",suburb="TEST SUBURB",state="VIC",postcode="3169" },
                comment="DFE - PACKAGE REVIEW",freightCents=10000,totalCents=199500,
                lines=new List<OrderLine>{new OrderLine { kind="package",sourceSku="TEST123",code="TEST123",description="TEST WHEEL PACKAGE WITH TYRES",quantity=1,unitCents=189500,totalCents=189500 }} };
            delivery.Validate(false);delivery.requiresReview=false;delivery.comment="DFE";
            rejected=false;try { delivery.Validate(false); } catch(InvalidOperationException) { rejected=true; }
            Order.Require(rejected,"Incomplete package must require manual review.");
            delivery.orderId="TTW1730086"; delivery.deliveryMethod="WITHIN AUSTRALIA";
            delivery.lines=new List<OrderLine>{new OrderLine { kind="product",sourceSku="SM9188555",code="SM9188555",description="18X8.5 18X9.5 SIMMONS OM-1 HYPER DARK 5/120.65 P0",quantity=4,unitCents=35000,totalCents=140000 }};
            delivery.freightCents=12000; delivery.surchargeCents=760; delivery.totalCents=152760; delivery.Validate(false);
            Order.Require(delivery.MatchesCostarTotal(152000) && delivery.MatchesCostarTotal(152760),"Delivery total must allow COSTAR's automatic surcharge before or after application.");
            Order.Require(!delivery.MatchesCostarTotal(152001) && !delivery.MatchesCostarTotal(153520),"An unrelated difference or duplicate surcharge must not pass the total check.");
            delivery.totalCents=152761; rejected=false; try { delivery.Validate(false); } catch(InvalidOperationException) { rejected=true; }
            Order.Require(rejected,"Source total must still include the exact card surcharge.");
            delivery.totalCents=152760; delivery.surchargeCents=-760; rejected=false; try { delivery.Validate(false); } catch(InvalidOperationException) { rejected=true; }
            Order.Require(rejected,"Negative card surcharge must not pass validation.");
            delivery.surchargeCents=760; delivery.discountCents=100; delivery.totalCents=152660;
            rejected=false; try { delivery.Validate(false); } catch(InvalidOperationException) { rejected=true; }
            Order.Require(rejected,"Unmapped discounts must remain blocked.");
        }
    }
}
