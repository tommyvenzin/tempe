// eBay orders (2.5.0). The eBay PC's "404 But It's Found" extension sends an order to the desk
// receiver (HTTPS on the shop network, its own pairing key); the RDP helper takes it from there
// and enters it into a NEW Repair Order in the Sydney COSTAR (Branch 1), left open for review.
// This file: the order as sent, the plan of COSTAR lines, the desk's eBay queue and its wire types.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace TempeCostar {
    public sealed class EbayBuyer { public string name, phone, email, username; }
    public sealed class EbayAddress { public string street, street2, suburb, state, postcode; }
    public sealed class EbayItem { public string sku, itemId, title; public int quantity, unitCents; }
    public sealed class EbayOrder {
        public string schema, submissionId, createdUtc, orderNumber, orderDate, priceSource, sentFrom;
        public EbayBuyer buyer;
        public EbayAddress address;
        public List<EbayItem> items;
        public int freightCents, totalCents;
        internal const string Schema="tempe.ebay-order.v1";
        // Tommy, 23 Oct: the comment always stops at EBAY DFE; Written By and Salesperson SA;
        // Rebill to EBAY (COSTAR then fills EBAY PAYMENTS, its note and Terms 7INV by itself).
        internal const string Comment="EBAY DFE",Staff="SA",RebillCode="EBAY",ExpectedTerms="7INV";
        internal const int MaxItems=4;
        static readonly Regex Number=new Regex(@"^\d{2}-\d{5}-\d{5}$");
        internal static bool IsNumber(string value) { return Number.IsMatch(value??""); }
        internal static string SubmissionFor(string number) { return "EBY-"+number; }
        // What goes into Rebill to's Card#: the order number and the order date, as in the example RO.
        internal string CardNumber { get { return orderNumber+" "+orderDate; } }
        internal string Reference { get { return "EBAY "+orderNumber; } }
        internal string BuyerName { get { return Order.EntryText(buyer==null?"":Order.Clean(buyer.name)); } }
        static void Text(string value,string label,int limit,bool required) {
            Order.Safe(value,label,limit); Order.Require(!required || !String.IsNullOrWhiteSpace(value),"The eBay order has no "+label+".");
        }
        public void Validate() {
            Order.Require(schema==Schema,"This is not an eBay order from the 404 extension, or the extension is too old for this helper.");
            Order.Require(IsNumber(orderNumber),"The eBay order number is missing or not in the 12-34567-89012 form.");
            Order.Require(submissionId==SubmissionFor(orderNumber),"The eBay submission does not match its order number.");
            DateTimeOffset created;
            Order.Require(DateTimeOffset.TryParse(createdUtc,CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out created),"The eBay order has no send time.");
            DateTime sold;
            Order.Require(DateTime.TryParseExact(orderDate??"","dd/MM/yy",CultureInfo.InvariantCulture,DateTimeStyles.None,out sold),"The eBay order date must be dd/mm/yy.");
            Order.Require(sold<=created.UtcDateTime.AddDays(2) && sold>=created.UtcDateTime.AddDays(-400),"The eBay order date is out of range.");
            Order.Require(buyer!=null && address!=null && items!=null,"The eBay order needs the buyer, the address and the items.");
            Text(buyer.name,"buyer name",200,true); Text(buyer.phone,"buyer phone",30,true);
            Order.Require(Regex.IsMatch(buyer.phone,@"^\+?[\d ()-]+$") && Regex.IsMatch(Order.Phone(buyer.phone),@"^\d{8,15}$"),"The buyer's phone number is not valid.");
            Text(buyer.email,"buyer email",240,false);
            Order.Require(String.IsNullOrEmpty(buyer.email) || Regex.IsMatch(buyer.email,@"^[^@\s]+@[^@\s]+\.[^@\s]+$"),"The buyer's email is not valid.");
            Text(buyer.username,"eBay username",64,true);
            Order.Require(Regex.IsMatch(buyer.username,@"^[A-Za-z0-9._*-]{1,64}$"),"The eBay username has characters that can't go into COSTAR.");
            Text(address.street,"street",240,true); Text(address.street2,"second address line",240,false); Text(address.suburb,"suburb",120,true);
            Order.Require(Regex.IsMatch(address.state??"",@"^(NSW|VIC|QLD|SA|WA|TAS|NT|ACT)$"),"The state must be NSW, VIC, QLD, SA, WA, TAS, NT or ACT.");
            Order.Require(Regex.IsMatch(address.postcode??"",@"^\d{4}$"),"The postcode must be 4 digits.");
            Order.Require(items.Count>=1 && items.Count<=MaxItems,"The helper enters eBay orders with 1 to "+MaxItems+" items; enter this one by hand.");
            var ids=new HashSet<string>(StringComparer.Ordinal);long sum=0;
            foreach(var item in items) {
                Order.Require(item!=null,"An eBay item is missing.");
                Order.Require(Regex.IsMatch(item.sku??"",@"^[A-Z0-9][A-Z0-9._-]{0,39}$") && !Regex.IsMatch(item.sku,@"^(F|M|DET|WA|WAFR|SERVICES?|UNKNOWN|UNAVAILABLE)$"),
                    "Item "+(item.sku??"(no SKU)")+" is not a COSTAR item code (the eBay custom label must be the COSTAR code).");
                Order.Require(Regex.IsMatch(item.itemId??"",@"^\d{9,15}$"),"An eBay item number is missing.");
                Order.Require(ids.Add(item.itemId),"The same eBay item is listed twice.");
                Order.Require(item.quantity>=1 && item.quantity<=20,"The quantity of "+item.sku+" must be 1 to 20.");
                Order.Require(item.unitCents>=1 && item.unitCents<=10000000,"The price of "+item.sku+" is missing.");
                Text(item.title,"item title",300,false);
                sum+=(long)item.quantity*item.unitCents;
            }
            Order.Require(freightCents>=0 && freightCents<=1000000,"The freight amount is not valid.");
            Order.Require(totalCents>0 && totalCents<=100000000 && sum+freightCents==totalCents,"The items and freight don't add up to the eBay total.");
            Text(priceSource,"price source",40,false); Text(sentFrom,"sender",80,false);
            Order.Require(Plan().Count>0,"Nothing to enter.");
        }
        // Content only: a second click on Send (new send time) is the same order.
        internal string ContentHash() {
            var copy=Wire.Copy(this);copy.createdUtc=null;copy.sentFrom=null;
            return Wire.Hash(Encoding.UTF8.GetBytes(Wire.Json(copy)));
        }
        // The Repair Order's lines, spaced as in Tommy's example RO 07497644 (22 Oct): an empty line
        // between every entry. Items (eBay price), freight, one M E per item, M BUY, then M DFE (COSTAR's
        // own text; the consignment number is someone else's job).
        internal List<EbayLine> Plan() {
            var lines=new List<EbayLine>();int n=1;
            foreach(var it in items) {
                lines.Add(new EbayLine {Line=n,Kind="product",Code=it.sku,Quantity=it.quantity,UnitCents=it.unitCents,Label="Item "+it.sku,
                    Item=new OrderLine {kind="product",sourceSku=it.sku,code=it.sku,description=String.IsNullOrWhiteSpace(it.title)?it.sku:it.title,quantity=it.quantity,unitCents=it.unitCents,totalCents=it.quantity*it.unitCents}});
                n+=2;
            }
            if(freightCents>0) { lines.Add(new EbayLine {Line=n,Kind="freight",Code="F",Quantity=1,UnitCents=freightCents,Label="Freight"});n+=2; }
            foreach(var it in items) { lines.Add(new EbayLine {Line=n,Kind="note",Code="M E",Text="EBAY ITEM # "+it.itemId,Label="M E (eBay item "+it.itemId+")"});n+=2; }
            lines.Add(new EbayLine {Line=n,Kind="note",Code="M BUY",Text="EBAY BUYER NAME: "+Order.EntryText(buyer.username.Trim()),Label="M BUY (buyer name)"});n+=2;
            lines.Add(new EbayLine {Line=n,Kind="code",Code="M DFE",Label="M DFE"});
            Order.Require(n<=Grid.CostarLines,"This eBay order needs more than COSTAR's "+Grid.CostarLines+" lines.");
            return lines;
        }
        // The online-delivery engine's view of this order: billing and Ship to are the buyer,
        // PO# the eBay order number, comment EBAY DFE, Ship Via DFE.
        internal Order EngineOrder() {
            string phone=Order.Phone(buyer.phone),email=Order.Clean(buyer.email);
            string street=Order.EntryText(Order.Clean(address.street)),street2=Order.EntryText(Order.Clean(address.street2)),suburb=Order.EntryText(Order.Clean(address.suburb));
            return new Order {
                schema=2,type="delivery",deliveryMethod="EBAY",orderId=orderNumber,createdUtc=createdUtc,comment=Comment,vehicle="",rego="",store="",
                freightCents=freightCents,totalCents=totalCents,
                customer=new Customer {name=BuyerName,streetAddress=street,address2=street2,suburb=suburb,state=address.state,postcode=address.postcode,phone=phone,email=email},
                shipping=new Shipping {name=BuyerName,streetAddress=street,address2=street2,suburb=suburb,state=address.state,postcode=address.postcode,
                    contact="",businessPhone="",mobilePhone=phone,email=email,shipVia="DFE",instructions=""},
                lines=Plan().Where(l=>l.Item!=null).Select(l=>l.Item).ToList()
            };
        }
    }
    // One COSTAR line of an eBay order. Kind: product (code, quantity, eBay unit price), freight
    // (F with the eBay postage), note (code with this exact text) or code (COSTAR's own text).
    internal sealed class EbayLine {
        internal int Line,Quantity,UnitCents;
        internal string Kind,Code,Text,Label;
        internal OrderLine Item;
    }

    // One rule on both sides for words the RDP helper sends (messages, progress, details): any
    // control character becomes a space and the text is cut to its limit, so a report can never be
    // refused for its words (and resent forever).
    internal static class EbayText {
        internal static string Clean(string text,int limit) {
            var b=new StringBuilder(text??"");
            for(int i=0;i<b.Length;i++) if(Char.IsControl(b[i])) b[i]=' ';
            string clean=b.ToString();
            return clean.Length>limit?clean.Substring(0,limit):clean;
        }
    }
    // ---- The desk's eBay queue -------------------------------------------------------------
    // Statuses: queued (waiting for the RDP helper), entering, ready_for_review, failed, removed.
    // One receipt per eBay order number: the same order can never be queued twice.
    public sealed class EbayStatus { public string orderNumber,status,message,progress,updatedUtc,waiting;public int version;public bool typed; }
    public sealed class EbayReceipt {
        public EbayOrder order;public string hash,status,message,progress,lease,workerId,receivedUtc,updatedUtc;
        // fresh: use a NEW Repair Order (the earlier attempt is set aside). startAgain: Tommy chose
        // "Start again" on the desk after checking COSTAR, the only thing that lets the helper enter
        // an order its journal says it already entered. Both last until the helper's first report.
        // claimedOnce: handed to the RDP helper at least once (its details are fixed from then on).
        public int version,workerSequence;public bool awaitingWorker,fresh,startAgain,hidden,typed,claimedOnce;
        internal EbayStatus Status() { return new EbayStatus {orderNumber=order.orderNumber,status=status,message=message,progress=progress,updatedUtc=updatedUtc,version=version,typed=typed}; }
    }
    public sealed class EbayState { public List<EbayReceipt> orders=new List<EbayReceipt>(); }
    // typed: the helper has typed into COSTAR for this order (the desk then offers "Start again").
    public sealed class EbayReport { public string orderNumber,lease,status,message,progress;public int sequence;public bool typed; }
    // working: the lease of the order the helper is entering right now, "" when none (an order the
    // desk still has as entering for it, under another lease, was lost: it is marked stopped).
    // declined: the lease of an order handed over that the helper could not start (it waits again).
    // sequence: the helper's report counter when it wrote this hello (read after working and report).
    // An order is only taken as lost by a hello written after the desk's last report for it, so a
    // late, older poll can never mark an order being typed as stopped.
    public sealed class EbayHello { public string workerId,detail,working,declined,declineReason;public bool accepting,available;public EbayReport report;public int waitMs,sequence; }
    // command: enter, wait or forget (the report names an order this desk no longer has for that lease).
    // ack: the sequence of the report the desk applied (or dropped); the helper stops sending it.
    public sealed class EbayReply { public string command,lease;public EbayOrder order;public bool fresh,startAgain,held;public EbayStatus status;public int ack,waitedMs; }
    internal sealed class EbayQueue {
        readonly object gate=new object();readonly Action<EbayState> save;EbayState state;
        internal const int Keep=300;
        internal event Action Changed;
        internal EbayQueue(EbayState initial,Action<EbayState> persist) { state=initial??new EbayState();if(state.orders==null)state.orders=new List<EbayReceipt>();save=persist; }
        T Change<T>(Func<T> action) {
            T value;
            lock(gate) { var old=Wire.Copy(state);try {value=action();save(state);}catch {state=old;throw;} }
            var changed=Changed;if(changed!=null){try{changed();}catch(Exception){}}
            return value;
        }
        static string Now { get { return DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture); } }
        static void Set(EbayReceipt r,string status,string message) { r.status=status;r.message=message??"";r.version++;r.updatedUtc=Now; }
        EbayReceipt Find(string number) { return state.orders.FirstOrDefault(o=>o.order.orderNumber==number); }
        EbayReceipt Must(string number) { var r=Find(number);Order.Require(r!=null,"That eBay order is not on this desk.");return r; }
        internal List<EbayReceipt> List() { lock(gate) return Wire.Copy(state.orders); }
        internal EbayStatus Get(string number) { lock(gate) { var r=Find(number);return r==null?null:r.Status(); } }
        internal int Waiting { get { lock(gate) return state.orders.Count(o=>o.status=="queued"||o.status=="entering"); } }
        internal EbayStatus Submit(EbayOrder order) {
            Order.Require(order!=null,"No eBay order was sent.");order.Validate();string hash=order.ContentHash();
            return Change(delegate {
                var old=Find(order.orderNumber);
                if(old!=null) {
                    if(old.status=="removed") {
                        if(old.typed) {
                            // Partly typed into COSTAR before it was removed: a re-send never means a NEW
                            // Repair Order. The helper continues the one it stopped in only if nothing in
                            // it changed; otherwise it refuses and Tommy decides on the desk.
                            if(!Wire.Equal(old.hash,hash)) throw new InvalidOperationException("CONFLICT: eBay order "+order.orderNumber+" was partly entered in COSTAR Sydney before it was removed, and these details are different. Finish it in COSTAR by hand, or ask Tommy.");
                            old.lease=null;old.workerId=null;old.awaitingWorker=false;old.fresh=false;old.startAgain=false;old.hidden=false;old.receivedUtc=Now;
                            Set(old,"queued","Sent again after it was removed. It was partly entered before: the helper continues that Repair Order only if nothing in it changed");return old.Status();
                        }
                        // Nothing typed before: a new entry, in a NEW Repair Order. Not a Start again:
                        // if the helper's journal says it entered it, it still refuses.
                        old.order=Wire.Copy(order);old.hash=hash;old.lease=null;old.workerId=null;old.awaitingWorker=false;old.fresh=true;old.startAgain=false;old.hidden=false;old.typed=false;old.claimedOnce=false;old.receivedUtc=Now;
                        Set(old,"queued","Sent again after it was removed; waiting for the RDP helper");return old.Status();
                    }
                    if(Wire.Equal(old.hash,hash)) return old.Status();
                    // Changed before the helper ever took it: the newer details replace the older ones.
                    if(old.status=="queued" && !old.awaitingWorker && !old.claimedOnce && !old.typed) { old.order=Wire.Copy(order);old.hash=hash;Set(old,"queued","Updated details received; waiting for the RDP helper");return old.Status(); }
                    throw new InvalidOperationException("CONFLICT: eBay order "+order.orderNumber+" was already sent with different details ("+old.status.Replace('_',' ')+"). Ask Tommy to remove it on the desk PC first.");
                }
                Order.Require(state.orders.Count(o=>o.status=="queued"||o.status=="entering")<50,"Too many eBay orders are waiting on the desk PC.");
                var r=new EbayReceipt {order=Wire.Copy(order),hash=hash,receivedUtc=Now,version=0};
                Set(r,"queued","Waiting for the RDP helper");
                state.orders.Add(r);Prune();return r.Status();
            });
        }
        // Old finished receipts go first once there are more than Keep; waiting ones always stay.
        void Prune() {
            int extra=state.orders.Count-Keep;if(extra<=0) return;
            var gone=state.orders.Where(o=>o.status=="ready_for_review"||o.status=="removed").OrderBy(o=>o.updatedUtc,StringComparer.Ordinal).Take(extra).ToList();
            foreach(var g in gone) state.orders.Remove(g);
        }
        internal EbayStatus Retry(string number) { return Change(delegate {
            var r=Must(number);
            if(r.status=="failed") { r.lease=null;r.awaitingWorker=false;Set(r,"queued","Retry requested; the helper continues in the same Repair Order if nothing in it changed"); }
            return r.Status();
        }); }
        // The earlier attempt is set aside: the helper enters the order in a NEW Repair Order.
        internal EbayStatus StartAgain(string number) { return Change(delegate {
            var r=Must(number);Order.Require(r.status=="failed","Only a stopped eBay order can be started again.");
            r.lease=null;r.awaitingWorker=false;r.fresh=true;r.startAgain=true;r.typed=false;Set(r,"queued","Start again: a new Repair Order will be used");return r.Status();
        }); }
        // workerReachable: the RDP helper is in touch. An order it has taken is left alone while it is
        // (even before its first report: it may be typing); with the helper gone it can be closed here.
        internal EbayStatus MarkDone(string number,bool workerReachable) { return Change(delegate {
            var r=Must(number);
            Order.Require(r.status=="failed"||r.status=="queued"||(r.status=="entering"&&!workerReachable),r.status=="entering"?"The RDP helper is entering this order right now. Stop it there first.":"This eBay order is already finished or removed.");
            r.awaitingWorker=false;Set(r,"ready_for_review","Marked done by hand on the desk PC. Check it in COSTAR.");return r.Status();
        }); }
        internal EbayStatus Remove(string number,bool workerReachable) { return Change(delegate {
            var r=Must(number);
            Order.Require(r.status=="queued"||r.status=="failed"||(r.status=="entering"&&!workerReachable),r.status=="entering"?"The RDP helper is entering this order right now. Stop it there first.":"Only a waiting or stopped eBay order can be removed.");
            r.awaitingWorker=false;r.hidden=true;Set(r,"removed","Removed on the desk PC");return r.Status();
        }); }
        internal void Hide(string number) { Change(delegate { var r=Must(number);Order.Require(r.status=="ready_for_review","Only finished eBay orders can be hidden.");r.hidden=true;return true; }); }
        internal void HideFinished() { Change(delegate { foreach(var r in state.orders.Where(o=>o.status=="ready_for_review")) r.hidden=true;return true; }); }
        static EbayReply Enter(EbayReceipt r,int ack) { return new EbayReply {command="enter",order=Wire.Copy(r.order),lease=r.lease,fresh=r.fresh,startAgain=r.startAgain,status=r.Status(),ack=ack}; }
        internal EbayReply Poll(EbayHello hello) {
            Order.Require(hello!=null,"Missing worker hello.");
            return Change(delegate {
                int ack=0;
                if(hello.report!=null) {
                    var p=hello.report;ack=p.sequence;var r=p.orderNumber==null?null:Find(p.orderNumber);
                    // A report for an order this desk dropped, or for an older lease (retried since):
                    // nothing to apply; the helper forgets it.
                    if(r==null || r.workerId!=hello.workerId || !Wire.Equal(r.lease,p.lease)) return new EbayReply {command="forget",ack=ack,status=r==null?new EbayStatus {orderNumber=p.orderNumber,status="removed",message="Unknown to this desk"}:r.Status()};
                    if(p.sequence>r.workerSequence) {
                        Order.Require(p.status=="entering"||p.status=="failed"||p.status=="ready_for_review","Invalid eBay worker status.");
                        // The helper has the order from its first report on: its details are fixed from then.
                        r.workerSequence=p.sequence;r.awaitingWorker=false;r.fresh=false;r.startAgain=false;r.claimedOnce=true;r.typed|=p.typed;
                        // Finished, removed or marked done on the desk stays as it is.
                        if(r.status=="entering") { Set(r,p.status,p.message);r.progress=p.progress??""; }
                    }
                }
                // A claim the helper could not start (COSTAR Sydney not open, someone working, another
                // entry): back in line, saying why.
                if(!String.IsNullOrEmpty(hello.declined)) {
                    var d=state.orders.FirstOrDefault(o=>o.status=="entering"&&o.awaitingWorker&&o.workerId==hello.workerId&&Wire.Equal(o.lease,hello.declined));
                    if(d!=null) {
                        string why=EbayText.Clean(String.IsNullOrWhiteSpace(hello.declineReason)?"the RDP helper could not start it yet":hello.declineReason.Trim(),400);
                        d.lease=null;d.workerId=null;d.awaitingWorker=false;Set(d,"queued",why.StartsWith("Waiting",StringComparison.OrdinalIgnoreCase)?why:"Waiting: "+why);
                    }
                }
                // An order this helper took (and reported on) but is no longer entering: it was closed,
                // restarted or lost its record. Stopped, so Tommy can deal with it (never left stuck).
                if(hello.working!=null) {
                    string reported=hello.report==null?null:hello.report.lease;
                    foreach(var o in state.orders.Where(o=>o.status=="entering"&&!o.awaitingWorker&&o.workerId==hello.workerId&&!Wire.Equal(o.lease,hello.working)&&!Wire.Equal(o.lease,reported)&&o.workerSequence<=hello.sequence).ToList()) {
                        // It may have been typed into: Start again then warns, and Tommy checks COSTAR first.
                        o.typed=true;
                        Set(o,"failed","The RDP helper is no longer entering this eBay order (it was closed or restarted). Check COSTAR Sydney for it first: Retry continues only in the same, unchanged Repair Order; otherwise Mark done by hand, or Start again only if it is NOT in COSTAR.");
                    }
                }
                // A claim whose reply was lost comes back with the same lease, also to a helper that is
                // switched off (it hands it back) or busy with it (it ignores it): never stuck.
                var again=state.orders.FirstOrDefault(o=>o.status=="entering"&&o.awaitingWorker&&o.workerId==hello.workerId);
                if(again!=null) return Enter(again,ack);
                if(!hello.accepting) return new EbayReply {command="wait",ack=ack};
                if(state.orders.Any(o=>o.status=="entering"&&o.workerId==hello.workerId)) return new EbayReply {command="wait",ack=ack};
                if(!hello.available) return new EbayReply {command="wait",ack=ack};
                var next=state.orders.Where(o=>o.status=="queued").OrderBy(o=>o.receivedUtc,StringComparer.Ordinal).FirstOrDefault();
                if(next==null) return new EbayReply {command="wait",ack=ack};
                next.workerId=hello.workerId;next.lease=Wire.Token();next.awaitingWorker=true;next.workerSequence=0;
                Set(next,"entering","The RDP helper is opening a Repair Order in COSTAR Sydney");
                return Enter(next,ack);
            });
        }
    }
    // A 6-digit PIN shown on the desk for 10 minutes; the eBay PC's extension trades it once for
    // the eBay key. Five wrong tries close it.
    internal sealed class EbayPairing {
        readonly object gate=new object();string pin;DateTime until;int tries;
        internal const int Minutes=10,Tries=5;
        internal string Begin() {
            var bytes=new byte[4];using(var rng=RandomNumberGenerator.Create())rng.GetBytes(bytes);
            string code=((BitConverter.ToUInt32(bytes,0)%900000)+100000).ToString(CultureInfo.InvariantCulture);
            lock(gate) { pin=code;until=DateTime.UtcNow.AddMinutes(Minutes);tries=0; }
            return code;
        }
        internal bool Active { get { lock(gate) return pin!=null&&DateTime.UtcNow<until; } }
        internal void End() { lock(gate) pin=null; }
        internal bool Try(string candidate) {
            lock(gate) {
                if(pin==null||DateTime.UtcNow>=until) return false;
                tries++;
                if(Wire.Equal(candidate??"",pin)) { pin=null;return true; }
                if(tries>=Tries) pin=null;
                return false;
            }
        }
    }
}
