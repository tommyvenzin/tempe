// The desk receiver's eBay side (2.5.0): the eBay orders tab, the PIN pairing for the eBay PC's
// extension and the eBay queue file. The orders themselves are entered by the RDP helper.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed partial class DeskForm {
        EbayQueue ebayQueue;
        readonly ListView ebayList=new ListView {View=View.Details,FullRowSelect=true,HideSelection=false,Font=Ui.Base,MultiSelect=false,Dock=DockStyle.Fill};
        readonly Button ebayRetry=Ui.SecondaryButton("Retry",100),ebayStartAgain=Ui.SecondaryButton("Start again in a new RO",210),ebayMarkDone=Ui.SecondaryButton("Mark done by hand",170),
            ebayRemove=Ui.DangerButton("Remove",110),ebayHide=Ui.SecondaryButton("Hide finished",140),ebayPair=Ui.PrimaryButton("Pair eBay PC",150),ebayReset=Ui.SecondaryButton("Reset eBay pairing",170);
        readonly Label ebayLine=Ui.Text("",780),chipEbay=Ui.Chip("EBAY",Ui.Muted);
        string ebaySignature="";EbayPairForm pairForm;
        // Called once api exists: the eBay key, the queue file and the hooks.
        void SetupEbay() {
            if(String.IsNullOrEmpty(settings.ebayToken)) {
                settings.ebayToken=Wire.Token();
                try{PrivateFiles.Save(Path.Combine(folder,"settings.dat"),settings);}catch{settings.ebayToken=null;throw;}
                AppLog.Note("ebay_key_created","");
            }
            string file=Path.Combine(folder,"ebay.dat");EbayState saved=null;
            // An unreadable eBay list must not keep the receiver (and the phones) from starting.
            try { saved=PrivateFiles.Load<EbayState>(file); }
            catch(Exception e) {
                string aside=file+".unreadable-"+DateTime.Now.ToString("yyyyMMdd-HHmmss");
                try{File.Move(file,aside);}catch(Exception){}
                AppLog.Note("ebay_queue_unreadable",e.GetType().Name+"; kept as "+Path.GetFileName(aside));
            }
            ebayQueue=new EbayQueue(saved,delegate(EbayState s){PrivateFiles.Save(file,s);});
            api.UseEbay(ebayQueue);
            api.EbayIncoming=delegate(string number) {
                AppLog.Note("ebay_received",number);
                try{BeginInvoke(new Action(delegate{UpdateStatus();}));}catch(InvalidOperationException){}
            };
            api.EbayPaired=delegate(string unused) {
                AppLog.Note("ebay_paired","");
                try{BeginInvoke(new Action(delegate{if(pairForm!=null&&!pairForm.IsDisposed)pairForm.Paired();UpdateStatus();}));}catch(InvalidOperationException){}
            };
        }
        Control BuildEbayPage() {
            var layout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=4,Padding=new Padding(8),BackColor=Ui.Canvas};
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var actions=Ui.Row();
            foreach(var b in new[]{ebayRetry,ebayStartAgain,ebayMarkDone,ebayRemove,ebayHide}) actions.Controls.Add(b);
            ebayList.Columns.Add("eBay order",130);ebayList.Columns.Add("Buyer",170);ebayList.Columns.Add("Total",80,HorizontalAlignment.Right);ebayList.Columns.Add("Status",120);ebayList.Columns.Add("Message",330);
            var setup=Ui.Row();setup.Controls.Add(ebayPair);setup.Controls.Add(ebayReset);
            layout.Controls.Add(ebayLine,0,0);layout.Controls.Add(actions,0,1);layout.Controls.Add(ebayList,0,2);
            var foot=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Canvas};
            foot.Controls.Add(setup);
            foot.Controls.Add(Ui.Hint("eBay orders come from the eBay PC's 404 extension (Send to COSTAR) and are entered by the RDP helper into a new Repair Order in COSTAR Sydney (Branch 1), left open for review. The same eBay order number is never entered twice. Retry continues in the same Repair Order if nothing in it changed; Start again uses a new one (only if the first is NOT in COSTAR).",780));
            layout.Controls.Add(foot,0,3);
            ebayRetry.Click+=delegate{Attempt(delegate{ebayQueue.Retry(SelectedEbay());api.WakeEbay();UpdateStatus();});};
            ebayStartAgain.Click+=delegate{Attempt(EbayStartAgain);};
            ebayMarkDone.Click+=delegate{Attempt(EbayMarkDone);};
            ebayRemove.Click+=delegate{Attempt(EbayRemove);};
            ebayHide.Click+=delegate{Attempt(delegate{ebayQueue.HideFinished();UpdateStatus();});};
            ebayPair.Click+=delegate{Attempt(EbayPair);};
            ebayReset.Click+=delegate{Attempt(EbayResetPairing);};
            ebayList.SelectedIndexChanged+=delegate{lastEbayList=null;UpdateEbayButtons();};
            return layout;
        }
        string SelectedEbay(){Order.Require(ebayList.SelectedItems.Count==1,"Select an eBay order in the list first.");return (string)ebayList.SelectedItems[0].Tag;}
        EbayReceipt SelectedEbayReceipt(){string number=SelectedEbay();var r=ebayQueue.List().FirstOrDefault(o=>o.order.orderNumber==number);Order.Require(r!=null,"Select an eBay order first.");return r;}
        static string Money(int cents){return "$"+(cents/100m).ToString("0.00",CultureInfo.InvariantCulture);}
        void EbayStartAgain() {
            var r=SelectedEbayReceipt();
            string text=r.order.Reference+"  |  "+r.order.BuyerName+"\r\n\r\n"+(r.typed?"The helper had already typed part of this order into a Repair Order in COSTAR Sydney.":"The helper stopped before typing anything.")+
                "\r\n\r\nCheck COSTAR Sydney first. If this order is already there (part done), choose No: finish it there and use Mark done by hand.\r\n\r\nEnter it again from the start in a NEW Repair Order?";
            if(MessageBox.Show(this,text,"Start again",MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            ebayQueue.StartAgain(r.order.orderNumber);AppLog.Note("ebay_start_again",r.order.orderNumber);api.WakeEbay();UpdateStatus();
        }
        void EbayMarkDone() {
            var r=SelectedEbayReceipt();
            string text=r.order.Reference+"  |  "+r.order.BuyerName+"\r\n\r\nMark this eBay order as done by hand? Choose Yes only when it is finished in COSTAR Sydney.\r\n\r\nThe helper will not type anything for it.";
            if(MessageBox.Show(this,text,"Mark done by hand",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            ebayQueue.MarkDone(r.order.orderNumber,api.EbayConnected);AppLog.Note("ebay_mark_done",r.order.orderNumber);api.WakeEbay();UpdateStatus();
        }
        void EbayRemove() {
            var r=SelectedEbayReceipt();
            string text=r.order.Reference+"  |  "+r.order.BuyerName+"\r\n\r\nRemove this eBay order? It will not be entered. If it is half-entered in COSTAR Sydney, finish or close that Repair Order by hand.\r\n\r\nThe eBay PC can send it again later.";
            if(MessageBox.Show(this,text,"Remove eBay order",MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            ebayQueue.Remove(r.order.orderNumber,api.EbayConnected);AppLog.Note("ebay_remove",r.order.orderNumber);api.WakeEbay();UpdateStatus();
        }
        void EbayPair() {
            if(pairForm!=null&&!pairForm.IsDisposed){pairForm.Activate();return;}
            string pin=api.Pairing.Begin();AppLog.Note("ebay_pairing_open","");
            pairForm=new EbayPairForm(settings.address,settings.trustPort,pin);
            pairForm.FormClosed+=delegate{api.Pairing.End();pairForm=null;};
            pairForm.Show(this);
        }
        void EbayResetPairing() {
            if(MessageBox.Show(this,"Make a new eBay key? The eBay PC stops sending until it is paired again (Pair eBay PC). Orders already here are kept.","Reset eBay pairing",MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            string previous=settings.ebayToken;settings.ebayToken=Wire.Token();
            try{PrivateFiles.Save(Path.Combine(folder,"settings.dat"),settings);}catch{settings.ebayToken=previous;throw;}
            AppLog.Note("ebay_key_reset","");
            MessageBox.Show(this,"The old eBay key no longer works. Click Pair eBay PC and pair the eBay PC's extension again.","Reset eBay pairing");
        }
        void UpdateEbay() {
            if(ebayQueue==null)return;
            string selected=ebayList.SelectedItems.Count==1?(string)ebayList.SelectedItems[0].Tag:null;
            var all=ebayQueue.List();var shown=all.Where(o=>!o.hidden).OrderByDescending(o=>o.receivedUtc,StringComparer.Ordinal).Take(60).ToList();
            string signature=String.Join("|",shown.Select(o=>o.order.orderNumber+":"+o.status+":"+o.version).ToArray());
            if(signature!=ebaySignature) {
                ebaySignature=signature;
                ebayList.BeginUpdate();ebayList.Items.Clear();
                foreach(var o in shown) {
                    string status=o.status=="ready_for_review"?"In COSTAR":o.status.Replace('_',' ');
                    var item=new ListViewItem(new[]{o.order.orderNumber,o.order.BuyerName,Money(o.order.totalCents),status,o.message??""}){Tag=o.order.orderNumber};
                    item.ForeColor=o.status=="failed"?Ui.Danger:o.status=="ready_for_review"?((o.message??"").IndexOf("CHECK",StringComparison.Ordinal)>=0?Ui.Warn:Ui.Success):o.status=="entering"?Ui.Info:Ui.Ink;
                    ebayList.Items.Add(item);
                    if(o.order.orderNumber==selected)item.Selected=true;
                }
                ebayList.EndUpdate();
            }
            int waiting=all.Count(o=>o.status=="queued"||o.status=="entering"),failed=all.Count(o=>o.status=="failed");
            bool connected,on,ready;string detail;api.EbaySide(out connected,out on,out ready,out detail);
            Ui.SetChip(chipEbay,!connected?"EBAY: RDP OFFLINE":!on?"EBAY: OFF":failed>0?"EBAY: "+failed+" STOPPED":waiting>0?"EBAY: "+waiting+" WAITING":"EBAY: ON",
                !connected?Ui.Danger:!on?Ui.Warn:failed>0?Ui.Danger:waiting>0?Ui.Info:Ui.Success);
            int since=api.SecondsSinceEbayWorker;
            Ui.SetText(ebayLine,(connected?"RDP helper (eBay) in touch "+(since<=1?"now":since+" s ago")+"  ·  "+(on?(ready?"ready for the next order":(detail??"")):"eBay orders switched off there"+(String.IsNullOrEmpty(detail)?"":" ("+detail+")")):"RDP helper (eBay) not in touch"+(since>=0?" for "+since+" s":"")+"; orders wait here until it is back")+
                (waiting>0?"  ·  "+waiting+" waiting":"")+(api.Pairing.Active?"  ·  pairing open":""));
            lastEbayList=all;UpdateEbayButtons();
        }
        List<EbayReceipt> lastEbayList;
        void UpdateEbayButtons() {
            if(ebayQueue==null)return;
            var all=lastEbayList??ebayQueue.List();
            var choice=ebayList.SelectedItems.Count==1?all.FirstOrDefault(o=>o.order.orderNumber==(string)ebayList.SelectedItems[0].Tag):null;
            bool stranded=choice!=null&&choice.status=="entering"&&!api.EbayConnected;
            ebayRetry.Enabled=choice!=null&&choice.status=="failed";
            ebayStartAgain.Enabled=choice!=null&&choice.status=="failed";
            ebayMarkDone.Enabled=choice!=null&&(choice.status=="failed"||choice.status=="queued"||stranded);
            ebayRemove.Enabled=choice!=null&&(choice.status=="failed"||choice.status=="queued"||stranded);
            ebayHide.Enabled=all.Any(o=>o.status=="ready_for_review"&&!o.hidden);
        }
    }
    // Shown while the eBay PC pairs: the PIN, the address and the certificate step.
    internal sealed class EbayPairForm:Form {
        readonly Label status=Ui.Text("Waiting for the eBay PC ...",520);
        readonly System.Windows.Forms.Timer clock=new System.Windows.Forms.Timer {Interval=1000};
        readonly DateTime until=DateTime.UtcNow.AddMinutes(EbayPairing.Minutes);bool done;
        internal EbayPairForm(string address,int trustPort,string pin) {
            Text="Pair the eBay PC";ClientSize=new Size(600,470);StartPosition=FormStartPosition.CenterParent;FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;Font=Ui.Base;BackColor=Ui.Surface;
            var flow=new FlowLayoutPanel {Dock=DockStyle.Fill,FlowDirection=FlowDirection.TopDown,WrapContents=false,Padding=new Padding(18),BackColor=Ui.Surface,AutoScroll=true};
            flow.Controls.Add(Ui.Title("On the eBay PC (once):"));
            flow.Controls.Add(Ui.Text("1. In Chrome open  http://"+address+":"+trustPort+"/trust.cer  , open the downloaded file, then: Install Certificate → Current User → Place all certificates in the following store → Trusted Root Certification Authorities → Finish → Yes. Close and reopen Chrome.",540));
            flow.Controls.Add(Ui.Text("2. Click the 404 extension icon. Under \"Tommy's PC\" type this address and PIN, then Connect:",540));
            var addressLine=new Label {Text=address,AutoSize=true,Font=new Font("Segoe UI",20F,FontStyle.Bold),ForeColor=Ui.Ink,Margin=new Padding(0,8,0,0)};
            var pinLine=new Label {Text=pin.Substring(0,3)+" "+pin.Substring(3),AutoSize=true,Font=new Font("Consolas",34F,FontStyle.Bold),ForeColor=Ui.Primary,Margin=new Padding(0,4,0,8)};
            flow.Controls.Add(addressLine);flow.Controls.Add(pinLine);
            flow.Controls.Add(Ui.Hint("The PIN works once, for "+EbayPairing.Minutes+" minutes (5 tries). Keep it to yourselves: it lets a PC send eBay orders into COSTAR.",540));
            flow.Controls.Add(status);
            var close=Ui.SecondaryButton("Close",120);close.Click+=delegate{Close();};flow.Controls.Add(close);
            Controls.Add(flow);
            clock.Tick+=delegate {
                if(done)return;
                int left=(int)Math.Max(0,(until-DateTime.UtcNow).TotalSeconds);
                if(left==0){Ui.SetText(status,"The PIN has expired. Close this and click Pair eBay PC again.");status.ForeColor=Ui.Danger;clock.Stop();return;}
                Ui.SetText(status,"Waiting for the eBay PC ...  ("+(left/60)+":"+(left%60).ToString("00")+" left)");
            };
            Shown+=delegate{clock.Start();};
            FormClosed+=delegate{clock.Dispose();};
        }
        internal void Paired() { done=true;clock.Stop();Ui.SetText(status,"Paired. The eBay PC can send orders now. You can close this.");status.ForeColor=Ui.Success;status.Font=Ui.Bold; }
    }
}
