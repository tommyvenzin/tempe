// 2.6.3 (Tommy, 28 Oct: "it looks like its clicking instead of like native ... do you want to map it
// first?"): the Map button. It only reads COSTAR, never clicks, types, focuses or sends anything that
// changes it: every COSTAR window that shows (the one in front first), each control's kind, COSTAR's own
// words on it (customer words: their length only), its state, and what Windows or accessibility could do
// with it directly (a button's press, a tick box's tick, a tab's switch, a menu item, a list row's
// action, a keyboard shortcut). The map goes with Save diagnostics (maps/), for the next update to press
// what COSTAR allows directly instead of clicking with the mouse.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace TempeCostar {
    internal static class CostarMap {
        internal const string Schema="tempe.costar-map.v1";
        internal static string Folder { get { return Path.Combine(AppData.Diagnostics,"maps"); } }
        // Accessibility roles (Windows' numbers) by name, for the map's reader.
        static readonly Dictionary<int,string> RoleNames=new Dictionary<int,string> {
            {1,"title bar"},{2,"menu bar"},{3,"scroll bar"},{4,"grip"},{9,"window"},{10,"client"},{11,"menu"},{12,"menu item"},{13,"tooltip"},
            {15,"document"},{16,"pane"},{18,"dialog"},{20,"group"},{21,"separator"},{22,"toolbar"},{23,"status bar"},{24,"table"},{25,"column header"},
            {26,"row header"},{27,"column"},{28,"row"},{29,"cell"},{30,"link"},{33,"list"},{34,"list item"},{35,"outline"},{36,"outline item"},
            {37,"tab"},{38,"tab page"},{40,"picture"},{41,"label"},{42,"text box"},{43,"button"},{44,"tick box"},{45,"radio button"},{46,"combo box"},
            {47,"drop-down list"},{48,"progress bar"},{51,"slider"},{52,"spin button"},{56,"drop-down button"},{57,"menu button"},{60,"tab list"},
            {62,"split button"},{64,"outline button"}};
        internal static string RoleName(int role) { string n;return RoleNames.TryGetValue(role,out n)?n:"role "+role.ToString(CultureInfo.InvariantCulture); }
        // Roles whose names hold the customer's data (rows, cells, list items, text boxes): their length only.
        static readonly int[] DataRoles={28,29,34,36,42,46};
        // Words as the map keeps them. COSTAR's own words (buttons, ticks, tabs, menus, headings, labels) are
        // kept, with emails and long numbers masked; data (cells, rows, list items, text boxes, and
        // anything inside a table or list but its headings) as its length only.
        internal static string Words(int role,string words,bool inData) {
            words=(words??"").Trim();
            if(words.Length==0) return "";
            bool heading=role==25||role==26;
            if(!heading&&(inData||Array.IndexOf(DataRoles,role)>=0)) return Length(words);
            return Sanitize.Text(words,80);
        }
        internal static string Length(string words) { int n=(words??"").Trim().Length;return n==0?"":"["+n.ToString(CultureInfo.InvariantCulture)+" chars]"; }
        // Accessibility state flags worth knowing for a direct press, in words.
        internal static string StateWords(int state) {
            if(state<0) return "";
            var w=new List<string>();
            if((state&0x1)!=0) w.Add("greyed");
            if((state&0x2)!=0) w.Add("selected");
            if((state&0x4)!=0) w.Add("has the keyboard");
            if((state&0x8)!=0) w.Add("pressed");
            if((state&0x10)!=0) w.Add("ticked");
            if((state&0x20)!=0) w.Add("half ticked");
            if((state&0x40)!=0) w.Add("read-only");
            if((state&0x8000)!=0) w.Add("hidden");
            if((state&0x10000)!=0) w.Add("off screen");
            if((state&0x100000)!=0) w.Add("can take the keyboard");
            if((state&0x200000)!=0) w.Add("selectable");
            return String.Join(", ",w.ToArray());
        }
        // A Windows control's kind, from its class and style (a WinForms class is "WindowsForms10.<class>...").
        internal static string Kind(string cls,int style) {
            string c=(cls??"").ToUpperInvariant();
            if(c=="#32768") return "menu";
            if(c.Contains("BUTTON")) {
                switch(style&0xF) {
                    case 0: case 1: return "button";
                    case 2: case 3: case 5: case 6: return "tick box";
                    case 4: case 9: return "radio button";
                    case 7: return "group box";
                    case 0xB: return "button (drawn by COSTAR)";
                    default: return "button ("+(style&0xF).ToString(CultureInfo.InvariantCulture)+")";
                }
            }
            if(c.Contains("RICHEDIT")) return "text box";
            if(c.Contains("EDIT")) return (style&0x20)!=0?"password box":(style&0x800)!=0?"read-only text box":"text box";
            if(c.Contains("COMBOBOX")) return "drop-down";
            if(c.Contains("STATIC")) return "label";
            if(c.Contains("SYSTABCONTROL32")) return "tabs";
            if(c.Contains("TOOLBARWINDOW32")) return "toolbar";
            if(c.Contains("LISTBOX")||c.Contains("SYSLISTVIEW32")) return "list";
            if(c.Contains("SYSTREEVIEW32")) return "tree";
            if(c.Contains("SCROLLBAR")) return "scroll bar";
            if(c.Contains("MSCTLS_UPDOWN")) return "up/down arrows";
            if(c.Contains("SYSDATETIMEPICK32")) return "date box";
            if(c.Contains("MDICLIENT")) return "window area";
            if(c.StartsWith("WINDOWSFORMS10.WINDOW",StringComparison.Ordinal)) return "COSTAR panel";
            return "other";
        }
        // Whose words a Windows control shows as COSTAR's own (kept) or data (length only).
        static bool DataKind(string kind) { return kind.Contains("text box")||kind=="password box"||kind=="drop-down"||kind=="list"||kind=="tree"||kind=="date box"; }

        // ---- accessibility: one window's tree, read only ----
        internal sealed class Walk {
            internal readonly List<Dictionary<string,object>> Items=new List<Dictionary<string,object>>();
            internal int Budget=2500,MaxDepth=14,Seen,OriginX,OriginY;internal long TimeLimitMs=25000;internal bool Cut;
            internal readonly Stopwatch Clock=Stopwatch.StartNew();
        }
        // A list with more than this many children: its first 8 and last 2 are read (the rest are alike: counted).
        internal const int LongList=40;
        internal static Walk Accessible(Accessibility.IAccessible root,int originX,int originY,int budget,long timeLimitMs) {
            var w=new Walk {OriginX=originX,OriginY=originY,Budget=budget,TimeLimitMs=timeLimitMs};
            if(root!=null) Visit(w,null,root,"1",0,false);
            return w;
        }
        static void Visit(Walk w,Accessibility.IAccessible parent,object child,string path,int depth,bool inData) {
            if(w.Seen>=w.Budget||w.Clock.ElapsedMilliseconds>w.TimeLimitMs) { w.Cut=true;return; }
            w.Seen++;
            int role=Msaa.RoleOf(parent,child),state=Msaa.StateOf(parent,child);
            string name=Msaa.NameOf(parent,child),value=Msaa.ValueOf(parent,child),action=Msaa.ActionOf(parent,child),keys=Msaa.ShortcutOf(parent,child);
            int l,t,wd,ht;bool placed=Msaa.LocationOf(parent,child,out l,out t,out wd,out ht);
            var a=child as Accessibility.IAccessible;
            int count=0;if(a!=null) { try { count=a.accChildCount; } catch(Exception) { count=0; } }
            var item=new Dictionary<string,object> {{"path",path},{"role",role},{"kind",RoleName(role)}};
            string words=Words(role,name,inData);if(words.Length>0) item["name"]=words;
            if(!String.IsNullOrEmpty(value)) item["value"]=Length(value);
            if(state>=0) { item["state"]="0x"+state.ToString("X",CultureInfo.InvariantCulture);string sw=StateWords(state);if(sw.Length>0) item["stateWords"]=sw; }
            if(!String.IsNullOrEmpty(action)) item["action"]=Sanitize.Text(action,40);
            if(!String.IsNullOrEmpty(keys)) item["keys"]=Sanitize.Text(keys,40);
            if(placed&&(wd>0||ht>0)) item["rect"]=new[]{l-w.OriginX,t-w.OriginY,wd,ht};
            if(count>0) item["children"]=count;
            if(a==null) item["simple"]=true;
            w.Items.Add(item);
            if(a==null||depth>=w.MaxDepth||count<=0) return;
            bool data=inData||role==24||role==33||role==35;
            var kids=Msaa.Children(a,400);
            try {
                int n=kids.Count;
                for(int i=0;i<n;i++) {
                    if(n>LongList&&i>=8&&i<n-2) continue;
                    Visit(w,a,kids[i],path+"."+(i+1).ToString(CultureInfo.InvariantCulture),depth+1,data);
                    if(w.Cut) break;
                }
                if(n>LongList) item["read"]="the first 8 and last 2 of "+n.ToString(CultureInfo.InvariantCulture)+" (the rest alike)";
            } finally { foreach(var k in kids) Msaa.Release(k); }
        }

        // ---- the windows: Windows' own view of each control, read only ----
        internal static Dictionary<string,object> Controls(IntPtr window,int originX,int originY,out int count,out int pressable) {
            var list=new List<Dictionary<string,object>>();int seen=0,direct=0;bool busy=false;
            uint pid=Native.Pid(window);
            Native.EnumChildWindows(window,delegate(IntPtr h,IntPtr unused) {
                if(seen>=2000) return false;
                if(!Native.IsWindowVisible(h)||Native.Pid(h)!=pid) return true;
                seen++;
                string cls=Native.Class(h);int style=Native.GetWindowLong(h,-16);string kind=Kind(cls,style);
                Native.Rect r;Native.GetWindowRect(h,out r);
                var c=new Dictionary<string,object> {{"h",h.ToInt64()},{"parent",Native.GetParent(h).ToInt64()},{"class",cls},{"kind",kind},
                    {"id",Native.CtrlId(h)},{"style","0x"+style.ToString("X8",CultureInfo.InvariantCulture)},{"rect",new[]{r.Left-originX,r.Top-originY,r.Right-r.Left,r.Bottom-r.Top}},{"enabled",Native.IsWindowEnabled(h)}};
                // A COSTAR that doesn't answer within 90 ms: no more words read from this window (each would wait).
                if(kind!="password box"&&!busy) {
                    string text;var asked=Stopwatch.StartNew();bool read=Native.TryText(h,out text);
                    if(!read&&asked.ElapsedMilliseconds>=90) busy=true;
                    if(read&&!String.IsNullOrEmpty(text)) {
                        if(DataKind(kind)) c["text"]=Length(text);
                        else { string words=Order.Clean(text);c["words"]=words.Length<=40?Sanitize.Text(words,40):Length(words); }
                    }
                }
                // What Windows could do with it directly: a button window takes BM_CLICK (a press; a tick box's tick).
                if(kind=="button"||kind=="button (drawn by COSTAR)") { c["direct"]="press (BM_CLICK)";direct++; }
                else if(kind=="tick box"||kind=="radio button") {
                    c["direct"]="tick (BM_CLICK)";direct++;
                    UIntPtr check;if(!busy&&Native.SendNull(h,0xF0,UIntPtr.Zero,IntPtr.Zero,3,200,out check)!=IntPtr.Zero) c["check"]=(int)check.ToUInt64();   // BM_GETCHECK: read only
                }
                list.Add(c);return true;
            },IntPtr.Zero);
            count=seen;pressable=direct;
            var result=new Dictionary<string,object> {{"count",seen},{"items",list}};
            if(busy) result["wordsStopped"]="COSTAR didn't answer within 90 ms: the rest of this window's words weren't read";
            return result;
        }
        static readonly string[] SkipClasses={"SysShadow","tooltips_class32","IME","MSCTFIME UI","Default IME"};
        // COSTAR's windows that show now: the one in front first, then as Windows stacks them.
        internal static List<IntPtr> ShownWindows(out IntPtr front) {
            var pids=new Dictionary<uint,bool>();var found=new List<IntPtr>();IntPtr fg=Native.GetForegroundWindow();
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) {
                if(!Native.IsWindowVisible(w)) return true;
                uint pid=Native.Pid(w);bool costar;
                if(!pids.TryGetValue(pid,out costar)) { ProcessIdentity identity;costar=LocalProcess.IsNamed((int)pid,"COSTAR",out identity);pids[pid]=costar; }
                if(!costar||SkipClasses.Any(s=>Native.Class(w).IndexOf(s,StringComparison.OrdinalIgnoreCase)>=0)) return true;
                Native.Rect r;if(!Native.GetWindowRect(w,out r)||r.Right-r.Left<4||r.Bottom-r.Top<4) return true;
                found.Add(w);return found.Count<40;
            },IntPtr.Zero);
            front=found.Contains(fg)?fg:IntPtr.Zero;
            if(front!=IntPtr.Zero) { found.Remove(front);found.Insert(0,front); }
            return found.Take(12).ToList();
        }

        // ---- one map: every COSTAR window that shows, read; written to maps/ ----
        internal sealed class Result { internal string JsonPath,TextPath,Words="";internal int Windows,Controls,Pressable,Accessible;internal bool Cut; }
        internal static Result Run() {
            var clock=Stopwatch.StartNew();IntPtr front;var windows=ShownWindows(out front);
            Order.Require(windows.Count>0,"No COSTAR window shows on this PC: open COSTAR (and the screen to map), then press Map again.");
            var maps=new List<Dictionary<string,object>>();var result=new Result();var names=new List<string>();
            foreach(var w in windows) {
                if(clock.ElapsedMilliseconds>90000) { result.Cut=true;break; }
                Native.Rect r;if(!Native.GetWindowRect(w,out r)) continue;
                string caption=Sanitize.Text(Order.Clean(Native.Caption(w)),80);
                var focus=Native.Focus(w);
                var m=new Dictionary<string,object> {{"handle",w.ToInt64()},{"class",Native.Class(w)},{"caption",caption},{"front",w==front},
                    {"enabled",Native.IsWindowEnabled(w)},{"owner",Native.GetWindow(w,4).ToInt64()},{"rect",new[]{r.Left,r.Top,r.Right-r.Left,r.Bottom-r.Top}},
                    {"style","0x"+Native.GetWindowLong(w,-16).ToString("X8",CultureInfo.InvariantCulture)},{"menuMode",Native.InMenuMode(w)}};
                // A COSTAR window that doesn't answer within half a second isn't read (each read would wait on it).
                UIntPtr alive;
                if(Native.SendNull(w,0,UIntPtr.Zero,IntPtr.Zero,2,500,out alive)==IntPtr.Zero) { m["busy"]="COSTAR didn't answer within 0.5 s: not read";maps.Add(m);result.Windows++;names.Add(caption.Length>0?caption:Native.Class(w));continue; }
                if(focus!=IntPtr.Zero&&Native.Pid(focus)==Native.Pid(w)) m["keyboardAt"]=new Dictionary<string,object> {{"h",focus.ToInt64()},{"class",Native.Class(focus)},{"kind",Kind(Native.Class(focus),Native.GetWindowLong(focus,-16))}};
                int count,pressable;m["controls"]=Controls(w,r.Left,r.Top,out count,out pressable);
                Accessibility.IAccessible acc=null;Walk walk=null;
                try { acc=Msaa.FromWindowObject(w,0);walk=Accessible(acc,r.Left,r.Top,2500,25000); }   // OBJID_WINDOW: title and menu bars too
                catch(Exception e) { m["accessibleError"]=Sanitize.Text(e.Message,120); }
                finally { Msaa.Release(acc); }
                if(walk!=null) { m["accessible"]=walk.Items;m["accessibleRead"]=walk.Seen;if(walk.Cut) { m["accessibleCut"]=true;result.Cut=true; } result.Accessible+=walk.Seen; }
                maps.Add(m);result.Windows++;result.Controls+=count;result.Pressable+=pressable;
                names.Add(caption.Length>0?caption:Native.Class(w));
            }
            var doc=new Dictionary<string,object> {{"schema",Schema},{"version",AutofillForm.Version},{"atLocal",DateTimeOffset.Now.ToString("o",CultureInfo.InvariantCulture)},
                {"ms",clock.ElapsedMilliseconds},{"windows",maps}};
            Directory.CreateDirectory(Folder);
            string stamp=DateTime.Now.ToString("yyyyMMdd-HHmmss",CultureInfo.InvariantCulture),basePath=Path.Combine(Folder,"map-"+stamp);
            result.JsonPath=basePath+".json";result.TextPath=basePath+".txt";
            File.WriteAllText(result.JsonPath,Wire.Json(doc),new UTF8Encoding(false));
            File.WriteAllText(result.TextPath,Summary(maps),new UTF8Encoding(false));
            result.Words=String.Join(" | ",names.ToArray());
            AppLog.Note("costar_map",result.Windows+" windows, "+result.Controls+" controls, "+result.Accessible+" accessible objects in "+(clock.ElapsedMilliseconds/100/10.0).ToString("0.0",CultureInfo.InvariantCulture)+" s"+(result.Cut?" (cut short)":""));
            return result;
        }

        // ---- the reader's page: per window, what could be pressed, ticked, switched or chosen directly ----
        internal static string Summary(List<Dictionary<string,object>> windows) {
            var b=new StringBuilder();
            b.AppendLine("COSTAR map ("+AutofillForm.Version+", "+DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm",CultureInfo.InvariantCulture)+"). Read only: nothing was clicked, typed or changed. Customer words show as [N chars].");
            foreach(var m in windows) {
                b.AppendLine();
                b.AppendLine("== "+Str(m,"caption")+" ("+Str(m,"class")+")"+(Flag(m,"front")?" — in front":"")+(Flag(m,"menuMode")?" — a menu has the keyboard":""));
                var at=m.ContainsKey("keyboardAt")?m["keyboardAt"] as Dictionary<string,object>:null;
                if(at!=null) b.AppendLine("Keyboard at: "+Str(at,"kind")+" ("+Str(at,"class")+")");
                var controls=m.ContainsKey("controls")?m["controls"] as Dictionary<string,object>:null;
                var items=controls!=null&&controls.ContainsKey("items")?controls["items"] as List<Dictionary<string,object>>:new List<Dictionary<string,object>>();
                var kinds=items.GroupBy(c=>Str(c,"kind")).OrderByDescending(g=>g.Count()).Select(g=>g.Count()+" "+g.Key).ToArray();
                b.AppendLine("Windows' controls: "+(kinds.Length==0?"none":String.Join(", ",kinds)));
                foreach(var c in items.Where(c=>c.ContainsKey("direct")))
                    b.AppendLine("  "+Str(c,"kind")+" \""+Str(c,"words")+"\": "+Str(c,"direct")+(c.ContainsKey("check")?" (now "+Str(c,"check")+")":"")+(Flag(c,"enabled")?"":" — greyed"));
                var acc=m.ContainsKey("accessible")?m["accessible"] as List<Dictionary<string,object>>:null;
                if(acc==null) { b.AppendLine("Accessibility: "+(m.ContainsKey("accessibleError")?Str(m,"accessibleError"):"not read"));continue; }
                b.AppendLine("Accessibility: "+acc.Count+" objects read"+(Flag(m,"accessibleCut")?" (cut short: more there)":""));
                foreach(var o in acc) {
                    int role=o.ContainsKey("role")&&o["role"] is int?(int)o["role"]:-1;
                    bool action=o.ContainsKey("action"),keys=o.ContainsKey("keys");
                    bool list=role==24||role==33||role==35;
                    if(!(action||keys||list||role==25)) continue;
                    if(role==29||role==34||role==36||role==28) { if(!action) continue; }
                    b.AppendLine("  "+Str(o,"path")+" "+Str(o,"kind")+(o.ContainsKey("name")?" \""+Str(o,"name")+"\"":"")+
                        (action?": "+Str(o,"action"):"")+(keys?" ["+Str(o,"keys")+"]":"")+(o.ContainsKey("children")&&list?" — "+Str(o,"children")+" in it":"")+
                        (o.ContainsKey("read")?" (read "+Str(o,"read")+")":"")+(o.ContainsKey("stateWords")?" — "+Str(o,"stateWords"):""));
                }
            }
            return b.ToString();
        }
        static string Str(Dictionary<string,object> d,string key) { object v;return d!=null&&d.TryGetValue(key,out v)&&v!=null?Convert.ToString(v,CultureInfo.InvariantCulture):""; }
        static bool Flag(Dictionary<string,object> d,string key) { object v;return d!=null&&d.TryGetValue(key,out v)&&v is bool&&(bool)v; }
    }
}
