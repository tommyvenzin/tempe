using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    public sealed class WorkerJournal {
        public MobileJob job;public string lease;public MobileCheckpoint checkpoint;public WorkerReport report;
        // 2.4.0: the operator finished (or closed) this job's Repair Order by hand and released
        // it, so the later "close" command reports closed without touching COSTAR.
        public bool releasedByHand;
    }
    internal static class MobileRecovery {
        // A failed job whose journal is consistent (lease, report and checkpoint all belong to it).
        internal static bool Failed(WorkerJournal state) {
            return state!=null&&state.job!=null&&state.report!=null&&state.report.status=="failed"&&
                !String.IsNullOrWhiteSpace(state.lease)&&Wire.Equal(state.lease,state.report.lease)&&state.report.submissionId==state.job.submissionId&&
                state.checkpoint!=null&&state.checkpoint.submissionId==state.job.submissionId;
        }
        internal static bool CanReset(WorkerJournal state) {
            return Failed(state)&&MobileProof.Unstarted(state.checkpoint);
        }
        // 2.4.0: a failed job can always be started again (its progress set aside, with a backup)
        // or released (finished by hand). The operator confirms after checking COSTAR; the
        // dialog says whether fields were entered and whether the original window still exists.
        internal static MobileCheckpoint FreshCheckpoint(WorkerJournal state) {
            Order.Require(Failed(state),"Only a failed mobile job can be started again.");
            return new MobileCheckpoint {submissionId=state.job.submissionId,planVersion=MobileProof.PlanVersion};
        }
    }
    internal sealed class WorkerEngine : IDisposable {
        readonly EntryCoordinator coordinator;readonly WorkerSettings settings;readonly string journalPath;readonly object gate=new object();readonly Action<string> log;
        WorkerJournal state;Runner runner;volatile bool disposed,busy;int started;
        readonly Stopwatch progressClock=Stopwatch.StartNew();
        internal volatile bool Enabled;
        // The last COSTAR availability check, reused for 3 s (each check scans windows).
        DateTime availableAt=DateTime.MinValue;bool availableCache;string availableDetail="";
        internal string Connection="Desk PC: connecting ...",Detail="Select COSTAR and click Start / resume mobile.";
        // 2.4.0: when the desk last answered and how fast (shown in the window), and the request
        // in flight, which a new report or a Stop/Start interrupts so the desk hears at once.
        volatile int lastContactTick;internal volatile int RoundTripMs=-1;
        internal int SecondsSinceContact { get { int t=lastContactTick;return t==0?-1:unchecked(Environment.TickCount-t)/1000; } }
        volatile HttpWebRequest pending;volatile bool interrupted;readonly AutoResetEvent wake=new AutoResetEvent(false);
        internal bool Busy {get{return busy;}}
        internal WorkerEngine(WorkerSettings config,string folder,Action<string> notify,EntryCoordinator entries) {
            coordinator=entries;
            NetworkRules.Worker(config);settings=config;log=notify;journalPath=Path.Combine(folder,"journal.dat");
            state=PrivateFiles.Load<WorkerJournal>(journalPath);
            if(state!=null&&state.report!=null&&state.report.status=="injecting")Report("failed","The RDP worker restarted. Retry will reconcile the saved progress.","");
        }
        internal MobileCheckpoint PendingCheckpoint {get{lock(gate)return state!=null&&(state.report==null||state.report.status!="closed")?Wire.Copy(state.checkpoint):null;}}
        internal bool TargetPinned {get{lock(gate)return state!=null&&(state.report==null||state.report.status!="closed")&&state.checkpoint!=null&&(state.checkpoint.window!=0||state.checkpoint.opening);}}
        internal bool CanRelease {get{lock(gate)return MobileRecovery.Failed(state);}}
        internal bool CanStartAgain {get{lock(gate)return MobileRecovery.Failed(state);}}
        internal bool JobUnstarted {get{lock(gate)return state!=null&&MobileProof.Unstarted(state.checkpoint);}}
        internal bool JobWindowAlive {get{lock(gate)return state!=null&&state.checkpoint!=null&&state.checkpoint.window!=0&&!CostarWindows.OrderWindowGone(state.checkpoint);}}
        internal string PendingSummary {get{lock(gate)return state==null||state.job==null?"":state.job.Reference+" ("+(state.report==null||state.report.status==null?"no status":state.report.status.Replace('_',' '))+")";}}
        internal string DescribeJob() {
            lock(gate){Order.Require(MobileRecovery.Failed(state),"Only a failed mobile job can be released or started again.");return state.job.Reference+" — "+state.job.customer.name;}
        }
        void RequireIdle() { Order.Require(!busy&&!coordinator.Busy,"Wait for the current entry to finish first."); }
        // 2.4.0: the job was finished (or closed) by hand in COSTAR. The desk sees it as ready
        // for review and moves on with Next Order / Pinad; the close that follows touches nothing.
        internal void Release() {
            // Checked and switched off under the gate, so no job can start in between (Accept
            // re-checks Enabled under the same gate); nothing running is cancelled.
            lock(gate){RequireIdle();Order.Require(MobileRecovery.Failed(state),"Only a failed mobile job can be released.");Enabled=false;state.releasedByHand=true;}
            try { Report("ready_for_review","Released: finished by hand in COSTAR. The helper typed nothing.",""); }
            catch { lock(gate) { if(state!=null) state.releasedByHand=false; } throw; }
            AppLog.Note("mobile_released",PendingSummary);AppLog.Note("mobile_stop","released");
            Detail="Released. On the desk PC the job is ready for review; Next Order (or Pinad mode) moves on. Click Start / resume mobile to continue.";
        }
        // 2.4.0: set the saved progress aside (backup kept) so Retry on the desk enters the job
        // from the start in a new Repair Order. Was "Reset unstarted job" (unstarted jobs only).
        internal void StartAgain() {
            string backup;
            lock(gate) {
                RequireIdle();var fresh=MobileRecovery.FreshCheckpoint(state);Enabled=false;
                backup=Path.Combine(Path.GetDirectoryName(journalPath),"journal-before-reset-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,8)+".dat");
                File.Copy(journalPath,backup,false);
                var previous=state.checkpoint;bool released=state.releasedByHand;state.checkpoint=fresh;state.releasedByHand=false;
                try{Save();}catch{state.checkpoint=previous;state.releasedByHand=released;throw;}
            }
            AppLog.Note("mobile_start_again",PendingSummary);AppLog.Note("mobile_stop","start again");
            Detail="Progress set aside. Click Start / resume mobile, then Retry selected on the desk PC: the job is entered from the start in a new Repair Order.";
            log(Detail);log("Previous encrypted progress kept at: "+backup);Interrupt();
        }
        // The desk closed or removed the job this journal holds (2.4.0 desk): nothing left to do here.
        void Forget(WorkerReply reply) {
            string summary;
            lock(gate) {
                if(busy||state==null||reply==null||reply.status==null||state.job==null||state.job.submissionId!=reply.status.submissionId)return;
                summary=PendingSummaryUnlocked();
                try{File.Copy(journalPath,Path.Combine(Path.GetDirectoryName(journalPath),"journal-closed-on-desk-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,8)+".dat"),false);}catch(Exception){}
                state=null;
                try{File.Delete(journalPath);}catch(Exception){}
            }
            AppLog.Note("mobile_forgotten",summary);
            Detail="The desk PC closed "+summary+"; ready for the next job.";log(Detail);
        }
        string PendingSummaryUnlocked(){return state==null||state.job==null?"":state.job.Reference+" ("+(state.report==null||state.report.status==null?"no status":state.report.status.Replace('_',' '))+")";}
        // Ends the request in flight so the next one (with the new report or accepting flag) goes out now.
        void Interrupt(){interrupted=true;var r=pending;if(r!=null){try{r.Abort();}catch(Exception){}}wake.Set();}
        internal void Start(){if(disposed)return;if(!Enabled)AppLog.Note("mobile_start","");bool was=Enabled;Enabled=true;Connect();if(!was)Interrupt();}
        // 2.4.0: the poll loop runs from the moment the window opens, with accepting=false until
        // Start / resume mobile. So the desk shows the helper in touch (mobile off), a failed or
        // finished report reaches it without waiting for mobile to be switched on, and phones can
        // send cards that wait in the queue. Nothing is entered while mobile is off.
        internal void Connect(){if(disposed)return;if(Interlocked.Exchange(ref started,1)!=0)return;var t=new Thread(Loop);t.IsBackground=true;t.Start();}
        internal void Stop(){bool was=Enabled;if(Enabled)AppLog.Note("mobile_stop",disposed?"app closing":"");Enabled=false;var active=runner;if(active!=null)active.Cancel=true;if(was)Interrupt();}
        void Save(){PrivateFiles.Save(journalPath,state);}
        void SaveCheckpoint(){PrivateFiles.Save(journalPath,state,false);}
        void Report(string status,string message,string progress) {
            message=ReportText(message,2000);progress=ReportText(progress,1000);
            lock(gate) {
                if(state==null)return;
                int sequence=state.report==null?1:state.report.sequence+1;
                var previous=state.report;
                state.report=new WorkerReport {submissionId=state.job.submissionId,lease=state.lease,status=status,message=message,progress=progress,sequence=sequence};
                try{Save();}catch{state.report=previous;Enabled=false;throw;}
            }
            Detail=message;log(message);
            Interrupt();
        }
        static string ReportText(string text,int limit){text=Regex.Replace(text??"",@"[\x00-\x1f\x7f]"," ");return text.Length>limit?text.Substring(0,limit):text;}
        void Progress(string message){
            // Checkpoints are saved once per operation. The desk receives progress only
            // on the 3-second worker poll, so a progress save more often than that adds
            // disk work without showing anything sooner.
            if(progressClock.ElapsedMilliseconds<2500){Detail=message;log(message);return;}
            var timer=Stopwatch.StartNew();Report("injecting",message,message);progressClock.Restart();NoteSave(timer);
        }
        void Persist(MobileCheckpoint checkpoint){var timer=Stopwatch.StartNew();long copyMs;lock(gate){var previous=state.checkpoint;state.checkpoint=Wire.Copy(checkpoint);copyMs=timer.ElapsedMilliseconds;try{SaveCheckpoint();}catch{state.checkpoint=previous;Enabled=false;throw;}}NoteSave(timer,copyMs);}
        // Called on the entry thread only, so diagnostics stay single-threaded.
        void NoteSave(Stopwatch timer,long copyMs=0){var active=runner;if(active!=null&&active.Diag!=null){active.Diag.Persist(timer.ElapsedMilliseconds);active.Diag.SaveParts(copyMs,PrivateFiles.LastJsonMs,PrivateFiles.LastProtectMs,PrivateFiles.LastWriteMs,PrivateFiles.LastReplaceMs);}}
        WorkerReply Request(WorkerHello hello) {
            var request=(HttpWebRequest)WebRequest.Create(settings.baseUrl.TrimEnd('/')+"/api/worker/v1/poll");
            request.Method="POST";request.ContentType="application/json";request.Headers["Authorization"]="Bearer "+settings.token;request.AllowAutoRedirect=false;request.Proxy=null;
            // 2.4.0: a 2.4.0 desk may hold the request for up to waitMs before answering.
            request.Timeout=8000+hello.waitMs;request.ReadWriteTimeout=8000+hello.waitMs;
            request.ServicePoint.Expect100Continue=false;
            request.ServerCertificateValidationCallback=delegate(object sender,X509Certificate cert,X509Chain chain,System.Net.Security.SslPolicyErrors errors) {
                if(cert==null)return false;using(var c=new X509Certificate2(cert))return DateTime.Now>=c.NotBefore&&DateTime.Now<=c.NotAfter&&Wire.Equal(Wire.Hash(c.RawData),settings.certificateHash);
            };
            byte[] bytes=Encoding.UTF8.GetBytes(Wire.Json(hello));request.ContentLength=bytes.Length;
            pending=request;
            try {
                using(var output=request.GetRequestStream())output.Write(bytes,0,bytes.Length);
                try {using(var response=request.GetResponse())using(var input=response.GetResponseStream())using(var reader=new StreamReader(input,Encoding.UTF8))return Wire.Read<WorkerReply>(reader.ReadToEnd());}
                catch(WebException e) {
                    if(e.Response!=null)using(var input=e.Response.GetResponseStream())using(var reader=new StreamReader(input))throw new InvalidOperationException("Receiver rejected the request: "+reader.ReadToEnd());
                    throw;
                }
            } finally { pending=null; }
        }
        void Loop() {
            while(!disposed) {
                bool held=false;
                try {
                    string detail;bool available=false;
                    if(coordinator.Busy)detail=coordinator.Owner+" is filling COSTAR";
                    else if(!Enabled)detail="Mobile off on the RDP helper (jobs wait in the queue)";
                    else if(coordinator.MobilePaused)detail="Online Orders tab selected; mobile pickup paused";
                    else if(DateTime.UtcNow-availableAt<TimeSpan.FromSeconds(3)){available=availableCache;detail=availableDetail;}
                    else {available=CostarWindows.Available(coordinator.Selected,out detail);availableCache=available;availableDetail=detail;availableAt=DateTime.UtcNow;}
                    if(available&&CostarInputLock.LegacyOpen()){available=false;detail="Close the original online-order helper while using mobile injection";}
                    WorkerReport report;lock(gate)report=state==null?null:Wire.Copy(state.report);
                    // 2.4.0: while mobile is on, ask the desk to hold the request until something
                    // happens (a job, an approval, Next Order), up to 8 s. A 2.3.x desk ignores the
                    // field and answers at once, in which case the old 2 s / 3 s rhythm is kept.
                    bool accepting=Enabled&&!coordinator.MobilePaused;
                    // While COSTAR is not free (a Repair Order open, an online order typing) the hold is
                    // short, so the next availability check isn't delayed by it.
                    int waitMs=accepting&&!busy&&AppSettings.Current.longPoll?(available?8000:2000):0;
                    var clock=Stopwatch.StartNew();interrupted=false;
                    var reply=Request(new WorkerHello {workerId=settings.workerId,accepting=accepting,available=available,detail=detail,report=report,waitMs=waitMs,jobOptions=true});
                    held=reply!=null&&reply.held;
                    int waited=reply==null?0:Math.Max(0,reply.waitedMs);
                    RoundTripMs=(int)Math.Max(0,clock.ElapsedMilliseconds-waited);lastContactTick=Environment.TickCount==0?1:Environment.TickCount;
                    Connection="Desk PC connected";if(!busy)Detail=detail;AppLog.PollOk();
                    if(reply!=null&&reply.command=="forget")Forget(reply);
                    if(reply!=null&&!busy&&!disposed&&Enabled&&!coordinator.MobilePaused&&(reply.command=="inject"||reply.command=="close"))Accept(reply);
                } catch(Exception e) {
                    if(disposed)break;
                    // Our own interruption (a new report, Stop or Start): poll again at once.
                    if(interrupted){interrupted=false;continue;}
                    Connection="Desk PC not reachable: "+e.Message;AppLog.PollError(e.Message);
                }
                // A held reply means the desk answered as soon as something happened: ask again at
                // once. Otherwise every 2 s while mobile entry is on, 3 s while stopped or paused,
                // cut short by Interrupt (a new report, Stop, Start).
                // Never run window discovery on the UI thread or while stopped/online/busy.
                if(!disposed){int ms=held?100:Enabled&&!coordinator.MobilePaused?2000:3000;wake.WaitOne(ms);}
            }
        }
        void Accept(WorkerReply reply) {
            Order.Require(reply.job!=null&&!String.IsNullOrWhiteSpace(reply.lease),"Receiver omitted the assigned job.");reply.job.Validate();
            var entry=coordinator.TryBegin("Mobile job",true);if(entry==null)return;
            bool started=false;
            try {
                lock(gate) {
                    // Recheck after acquiring the gate: Stop/reset may have
                    // happened while the receiver request was in flight.
                    if(!Enabled||disposed)return;
                    if(state==null||state.job.submissionId!=reply.job.submissionId) {
                        Order.Require(reply.command=="inject"&&(state==null||(state.report!=null&&state.report.status=="closed")),"A different unfinished job is already in this worker's journal.");
                        var previous=state;
                        state=new WorkerJournal {job=Wire.Copy(reply.job),lease=reply.lease,checkpoint=new MobileCheckpoint {submissionId=reply.job.submissionId}};
                        try{Save();}catch{state=previous;Enabled=false;throw;}
                    } else Order.Require(Wire.Json(state.job)==Wire.Json(reply.job)&&Wire.Equal(state.lease,reply.lease),"The assigned job changed; entry refused.");
                    if(reply.command=="inject"&&state.report!=null&&state.report.status=="ready_for_review")return;
                    busy=true;
                }
                var thread=new Thread(delegate(){Run(reply.command,entry);});thread.IsBackground=true;thread.SetApartmentState(ApartmentState.STA);thread.Start();started=true;
            } finally {if(!started){busy=false;entry.Dispose();}}
        }
        void Run(string command,EntryLease entry) {
            CostarInputLock inputLock=null;var clock=Stopwatch.StartNew();string reference="";
            try {
                inputLock=new CostarInputLock();CostarWindows.Main(entry.Target);
                MobileJob job;MobileCheckpoint cp;lock(gate){job=Wire.Copy(state.job);cp=Wire.Copy(state.checkpoint);}
                reference=job.Reference;
                if(command!="close") AppLog.Note("mobile_job_start",reference+(cp.index>0||cp.pending>=0?" resume at step "+(cp.index+1):"")+DraftAge(job));
                if(command=="close") {
                    Order.Require(state.report!=null&&(state.report.status=="ready_for_review"||state.report.status=="closed"),"The current job is not ready to close.");
                    // A lost close acknowledgement must never close a later window. If the
                    // reviewed order's window is already gone (closed by hand, or COSTAR was
                    // closed or restarted) there is nothing to close in any COSTAR, so this is
                    // checked before requiring the job's original COSTAR to be selected.
                    bool released;lock(gate)released=state.releasedByHand;
                    if(released){Report("closed","Released by hand earlier; nothing to close.","");AppLog.Note("mobile_close_ok",reference+" released by hand");return;}
                    if(state.report.status=="closed"||CostarWindows.OrderWindowGone(cp)) {
                        bool gone=state.report.status!="closed";
                        Report("closed",gone?"The reviewed Repair Order was already closed (COSTAR closed or restarted). Make sure it was saved.":"Reviewed order closed","");
                        if(gone)AppLog.Note("mobile_close_ok",reference+" window already gone");
                        return;
                    }
                }
                if(cp.window!=0&&!(cp.processId==entry.Target.Pid&&cp.processStart==entry.Target.Started&&cp.sessionId==entry.Target.Session)) {
                    // 2.4.0: say what to do instead of failing the same way on every Retry.
                    bool gone=CostarWindows.PinnedProcessGone(cp);
                    if(gone)Enabled=false;
                    throw new InvalidOperationException(gone?
                        "The COSTAR this job was started in has closed or restarted, so its Repair Order is gone. Check COSTAR for "+reference+": if it is there, click Release job (finished by hand); if not, click Start this job again, then Retry selected on the desk PC.":
                        "This mobile job belongs to another COSTAR instance. Select its original instance in the list and Retry, or use Release job / Start this job again on the Mobile tab.");
                }
                if(command=="close") {
                    CostarWindows.ValidateTarget(cp);
                    runner=new Runner(cp.processId,Branches.OrLegacy(cp.branch),job.EngineOrder(),"",true,log,cp.window);
                    Order.Require(runner.Target.ToInt64()==cp.window,"A different Repair Order is open.");runner.CloseMobile(job,cp);
                    Report("closed","Reviewed order closed","");AppLog.Note("mobile_close_ok",reference);return;
                }
                Report("injecting","Checking COSTAR and saved progress","");
                coordinator.Progress.Begin("Mobile job",reference,0);
                long openMs=-1;
                if(cp.window==0) {
                    Order.Require(!cp.opening,"The previous Add New click has an uncertain result. Check COSTAR and send the worker report; another order will not be opened automatically.");
                    var openTimer=Stopwatch.StartNew();
                    var target=CostarWindows.OpenNew(entry.Target,delegate {cp.opening=true;Persist(cp);},delegate {return !Enabled||disposed;});
                    openMs=openTimer.ElapsedMilliseconds;
                    cp.window=target.ToInt64();cp.processId=(int)Native.Pid(target);
                    ProcessIdentity identity;Order.Require(LocalProcess.IsNamed(cp.processId,"COSTAR",out identity)&&identity.Started==entry.Target.Started&&identity.Session==entry.Target.Session,"COSTAR changed while opening the order. Check the partial order manually.");
                    cp.processStart=identity.Started;cp.sessionId=identity.Session;cp.branch=entry.Target.Branch;
                    cp.opening=false;Persist(cp);
                }
                if(!Native.IsWindow(new IntPtr(cp.window))) {
                    Enabled=false;
                    throw new InvalidOperationException(MobileProof.Unstarted(cp)?
                        "The original Repair Order window is closed. This job stopped before any fields were entered. Check COSTAR, then click Start this job again on the Mobile tab and Retry selected on the desk PC.":
                        "The original Repair Order window is closed and this job had entered fields. Check COSTAR for "+reference+": if it is there, click Release job (finished by hand); if not, click Start this job again, then Retry selected on the desk PC. Nothing is replaced automatically.");
                }
                CostarWindows.ValidateTarget(cp);
                runner=new Runner(cp.processId,Branches.OrLegacy(cp.branch),job.EngineOrder(),"",true,Progress,cp.window);
                runner.OnStage=coordinator.Progress.Stage;
                if(openMs>=0)runner.Diag.OpenNewMs=openMs;
                Order.Require(runner.Target.ToInt64()==cp.window,"The target Repair Order changed before entry.");
                if(!Enabled||disposed)runner.Cancel=true;
                runner.RunMobile(job,cp,Persist);
                // 2.5.1: a note COSTAR may not keep is said with the result, on the desk.
                // 2.6.2: what the phone's choices came to (ordered, Job Card printed) goes with it.
                Report("ready_for_review","READY FOR REVIEW"+(runner.JobNotes.Count>0?" · "+String.Join(" · ",runner.JobNotes.ToArray()):"")+(runner.Checks.Count>0?" CHECK BY HAND: "+String.Join(" ",runner.Checks.ToArray()):""),"");coordinator.Progress.End(true,reference+" ready for review");
                AppLog.Note("mobile_job_ready",reference+" in "+(clock.ElapsedMilliseconds/100/10.0).ToString("0.0",System.Globalization.CultureInfo.InvariantCulture)+" s run="+runner.Diag.RunId+(openMs>=0?" add-new="+openMs+"ms":""));
            } catch(Exception e) {
                try{if(runner!=null)runner.Diag.Stopped(e);}catch{}
                AppLog.Note(command=="close"?"mobile_close_failed":"mobile_job_failed",reference+" "+e.Message+(runner!=null?" run="+runner.Diag.RunId:""));
                if(command=="close") {Enabled=false;Detail="Close stopped: "+e.Message;log(Detail);}
                else {coordinator.Progress.End(false,reference+" stopped: "+e.Message);try{Report("failed",e.Message,"");}catch(Exception persistenceError){Enabled=false;Detail="Worker stopped: progress could not be saved. "+persistenceError.Message;log(Detail);}}
            } finally {
                try{if(runner!=null){runner.Dispose();log("COSTAR report: "+runner.ZipPath);}}
                catch(Exception e){Enabled=false;log("Report cleanup failed: "+e.Message);}
                finally{runner=null;try{if(inputLock!=null)inputLock.Dispose();}finally{busy=false;entry.Dispose();}}
            }
        }
        // How long ago the salesperson started this job card (includes their own typing time).
        static string DraftAge(MobileJob job) {
            DateTimeOffset created;
            if(!DateTimeOffset.TryParse(job.createdUtc,System.Globalization.CultureInfo.InvariantCulture,System.Globalization.DateTimeStyles.RoundtripKind,out created)) return "";
            return " card started "+Math.Max(0,(int)(DateTimeOffset.UtcNow-created).TotalSeconds)+" s ago";
        }
        public void Dispose(){disposed=true;Stop();}
    }
}
