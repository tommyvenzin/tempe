// Tempe Buffalo Fill 1.0.2 — background service worker.
// Talks only to the Tempe helper on this PC (127.0.0.1:8811-8840), every request and answer signed with the key the
// helper wrote into this extension's own folder (pair.json, read with the extension's own URL; never sent anywhere).
// It asks for a job only for the Create Consignment tab in front, only when that page is settled and blank, takes the
// job once, fills that same document in the page's own world (fill.js) and tells the helper what happened. What keeps
// the page from taking a job (not blank, or a page check that failed) is told to the helper too, so it can say why.
importScripts('fill.js');   // self.tempeBuffalo

const CREATE = 'https://portal.transvirtual.com/Portal/Consignment/Create';
const FIRST = 8811, PORTS = 30, SCHEMA = 1;
const VERSION = chrome.runtime.getManifest().version;
const CHROME = (((typeof navigator !== 'undefined' && navigator.userAgent) || '').match(/Chrome\/(\d+)/) || [])[1] || '?';
// A copy of the extension loaded from anywhere but the helper's folder has no pair.json, so it can't be paired.
const NOKEY = 'this copy of Tempe Buffalo Fill has no key (pair.json), so it can’t reach the helper. In chrome://extensions click Remove on it, ' +
  'then Load unpacked and choose the folder the helper keeps it in: %LOCALAPPDATA%\\TempeMobileCostar\\BuffaloFill (paste that into the folder box)';
let keyPromise = null, busy = false;
const state = { line: 'Starting.', helper: null, port: null, at: 0 };
// The last line survives the service worker being stopped (storage.session lasts until Chrome closes).
const note = line => { if (line === state.line) return; state.line = line; state.at = Date.now(); chrome.storage.session.set({ line: state.line, at: state.at }).catch(() => { }); };
const short = e => String((e && e.message) || e).slice(0, 100);
const restored = chrome.storage.session.get(['line', 'at']).then(s => { if (s.line && state.line === 'Starting.') { state.line = s.line; state.at = s.at || 0; } }).catch(() => { });

// ---- the key and the signatures (the helper's BuffaloLink computes the same) ----
const fromB64Url = s => { s = String(s || '').replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; const b = atob(s); return Uint8Array.from(b, c => c.charCodeAt(0)); };
const toB64Url = a => btoa(String.fromCharCode.apply(null, Array.from(a))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const hex = buf => Array.from(new Uint8Array(buf), b => b.toString(16).padStart(2, '0')).join('');
async function key() {
  if (!keyPromise) keyPromise = (async () => {
    // A file that isn't there makes Chrome's fetch fail outright ("Failed to fetch"), not answer 404.
    let r = null;
    try { r = await fetch(chrome.runtime.getURL('pair.json'), { cache: 'no-store' }); } catch (e) { }
    if (!r || !r.ok) throw new Error(NOKEY);
    let raw = null;
    try { raw = fromB64Url((await r.json()).key); } catch (e) { }
    if (!raw || raw.length !== 32) throw new Error('pair.json holds no usable key: start the Tempe helper (RDP) once, then click Reload on Tempe Buffalo Fill in chrome://extensions');
    return crypto.subtle.importKey('raw', raw, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  })().catch(e => { keyPromise = null; throw e; });
  return keyPromise;
}
const sha = async bytes => hex(await crypto.subtle.digest('SHA-256', bytes));
const mac = async text => hex(await crypto.subtle.sign('HMAC', await key(), new TextEncoder().encode(text)));

// One signed POST; throws unless the answer is signed by the helper that holds the key, for this port and this nonce.
async function call(port, path, value, timeoutMs) {
  const body = new TextEncoder().encode(JSON.stringify(value));
  const ts = String(Date.now()), nonce = toB64Url(crypto.getRandomValues(new Uint8Array(16)));
  const sig = await mac(['req', 'POST', '127.0.0.1:' + port, path, ts, nonce, await sha(body)].join('\n'));
  const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), timeoutMs || 4000);
  try {
    const r = await fetch('http://127.0.0.1:' + port + path, { method: 'POST', body, cache: 'no-store', credentials: 'omit', redirect: 'error', signal: ctl.signal,
      headers: { 'Content-Type': 'application/json', 'X-Tbf-Ts': ts, 'X-Tbf-Nonce': nonce, 'X-Tbf-Mac': sig } });
    const got = new Uint8Array(await r.arrayBuffer());
    const want = await mac(['resp', '127.0.0.1:' + port, nonce, String(r.status), await sha(got)].join('\n'));
    if ((r.headers.get('X-Tbf-Mac') || '') !== want) throw new Error('an answer not signed by this Windows user’s helper');
    return { status: r.status, json: JSON.parse(new TextDecoder().decode(got)) };
  } finally { clearTimeout(timer); }
}

// ---- finding this user's helper: the one port whose hello is signed with our key ----
let lastSearch = 0, searchWait = 1000;
// now: the popup asks, so search once even inside the wait (the wait itself is left as it is).
async function helperPort(now) {
  await key();   // no key: say so (the caller shows why), rather than search and call it "not running"
  const s = await chrome.storage.session.get('port');
  if (s.port) { state.port = s.port; return s.port; }
  if (!now && Date.now() - lastSearch < searchWait) return null;
  lastSearch = Date.now();
  const tries = [];
  for (let p = FIRST; p < FIRST + PORTS; p++) tries.push(call(p, '/buffalo/hello', { ext: VERSION, schema: SCHEMA, chrome: CHROME }, 1500).then(a => a.status === 200 && a.json.ok ? { p, a } : null).catch(() => null));
  const found = (await Promise.all(tries)).filter(Boolean);
  if (found.length !== 1) { searchWait = Math.min(Math.max(searchWait, 1000) * 2, 30000); note(found.length ? 'More than one helper answers for this key: none used.' : 'The Tempe helper (RDP) isn’t running or isn’t reachable.'); return null; }
  searchWait = 1000; state.helper = found[0].a.json.helper; state.port = found[0].p;
  await chrome.storage.session.set({ port: found[0].p });
  return found[0].p;
}
async function forget() { state.port = null; state.helper = null; await chrome.storage.session.remove('port'); }

// ---- a newer version in this folder (the helper copies it): reload once, when idle ----
const newer = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };
// Returns true when this extension isn't the version the helper ships (the helper then gives it no job).
async function versions(a) {
  if (!a || !a.extShipped || a.extShipped === VERSION) return false;
  if (a.extOnDisk === a.extShipped && newer(a.extOnDisk, VERSION)) {
    const s = await chrome.storage.local.get('reloadedFor');
    if (s.reloadedFor !== a.extOnDisk) { await chrome.storage.local.set({ reloadedFor: a.extOnDisk }); setTimeout(() => chrome.runtime.reload(), 300); return true; }
  }
  note('This extension is ' + VERSION + ' but the helper ships ' + a.extShipped + (a.extOnDisk !== a.extShipped ? ' (the helper couldn’t update this extension’s folder: see the helper)' : '') +
    ': in chrome://extensions click Reload on Tempe Buffalo Fill, then refresh the Buffalo page.');
  return true;
}

// ---- one tick from the Create Consignment tab in front ----
// Is the asking tab still the one in front, in the focused window? Asked again before the job is taken and before it's
// filled, since the probe takes a second or two.
async function inFront(sender) {
  try {
    const t = await chrome.tabs.get(sender.tab.id);
    if (!t || !t.active || t.windowId !== sender.tab.windowId) return false;
    const w = await chrome.windows.getLastFocused();
    return !!w && w.focused && w.id === t.windowId;
  } catch (e) { return false; }
}
// What keeps the page in front from taking a job, told to the helper in a signed hello (no job is asked for or given)
// so its line can say why: when it changes, else at most every 15 s. Only the extension's own words, never the page's
// boxes. Nothing is told without the key. Only a hello the helper answered counts as told; a remembered port that no
// longer answers (the helper restarted on another) is forgotten and the ports searched again (within the search's own
// back-off). The answer can say a newer version is in this extension's folder: reloaded as after a poll.
let told = { text: null, at: 0 };
async function tell(text) {
  if (text === told.text && Date.now() - told.at < 15000) return;
  try {
    for (let tries = 0; tries < 2; tries++) {
      const port = await helperPort();
      if (!port) return;
      let a = null;
      try { a = await call(port, '/buffalo/hello', { ext: VERSION, schema: SCHEMA, chrome: CHROME, problem: text }, 1500); } catch (e) { }
      if (a && a.status === 200 && a.json && a.json.ok) { told = { text: text, at: Date.now() }; state.helper = a.json.helper; await versions(a.json); return; }
      await forget();
    }
  } catch (e) { }
}
// A page check that didn't work: on the button's line and to the helper, with Chrome's version.
function trouble(text) { note('Buffalo page: ' + text + ' (Chrome ' + CHROME + ').'); tell(text + ' (Chrome ' + CHROME + ')'); }

// The fill's answer as it left it on the page, for when Chrome hands back nothing from the fill: read every half second
// for up to 25 s (the helper calls a fill silent 30 s after it was taken). null if the page is gone or never says.
async function answer(target, id) {
  const end = Date.now() + 25000;
  while (Date.now() < end) {
    let a = null;
    try { const [r] = await chrome.scripting.executeScript({ target, world: 'MAIN', func: self.tempeBuffalo, args: ['answer', { id: id }] }); a = r && r.result; }
    catch (e) { return null; }
    if (a && a.result && a.result.id === id) return a.result;
    await new Promise(r => setTimeout(r, 500));
  }
  return null;
}

// Settled: the same look (rows and moving boxes) with nothing loading, tick after tick, for 1.5 s. The fill checks
// again itself (watching for 2.5 s) before it writes anything.
let seen = { doc: null, sig: null, since: 0 }, loading = { doc: null, since: 0 };
async function tick(sender) {
  if (busy) return;
  busy = true;
  try {
    if (!sender.tab || !(await inFront(sender))) return;
    const target = { tabId: sender.tab.id, documentIds: [sender.documentId] };
    let look;
    try { const [res] = await chrome.scripting.executeScript({ target, world: 'MAIN', func: self.tempeBuffalo, args: ['look'] }); look = res && res.result; }
    catch (e) { trouble('Chrome wouldn’t run the page check (' + short(e) + ')'); return; }
    if (!look || typeof look !== 'object' || typeof look.ok !== 'boolean') { trouble('Chrome gave no answer from the page check'); return; }
    if (!look.ok) { trouble('the page check failed (' + String(look.error || 'no reason given').slice(0, 160) + ')'); return; }
    if (!look.quiet) {
      // Loading for more than 10 s (or its scripts never there) is told to the helper as well.
      const why = look.why || 'the Buffalo page is still loading';
      seen = { doc: null, sig: null, since: 0 }; if (loading.doc !== sender.documentId) loading = { doc: sender.documentId, since: Date.now() };
      note('Buffalo page: ' + why + '.'); if (Date.now() - loading.since > 10000) tell(why + ' (for more than 10 s)');
      return;
    }
    loading = { doc: null, since: 0 };
    if (seen.doc !== sender.documentId || seen.sig !== look.sig) seen = { doc: sender.documentId, sig: look.sig, since: Date.now() };
    if (Date.now() - seen.since < 1500) { note('Buffalo page: checking it has finished loading …'); return; }
    if (look.why) { note('Buffalo page: ' + look.why + '.'); tell(look.why); return; }
    if (!look.front || !(await inFront(sender))) return;
    let port;
    try { port = await helperPort(); }
    catch (e) { note('Buffalo page: blank and ready, but this extension can’t reach the helper (see above).'); return; }
    if (!port) return;
    let poll;
    try { poll = await call(port, '/buffalo/poll', { ext: VERSION, schema: SCHEMA, chrome: CHROME, tab: { settled: true, blank: true } }); }
    catch (e) { await forget(); note('Lost the helper (' + String(e.message || e).slice(0, 80) + ').'); return; }
    state.helper = poll.json.helper;
    if (await versions(poll.json)) return;
    const job = poll.json.job;
    if (!job) { note('Ready: click Fill Buffalo page in the helper.'); return; }
    if (job.schema !== SCHEMA || typeof job.id !== 'string') return;
    if (!(await inFront(sender))) return;
    const took = await call(port, '/buffalo/take', { ext: VERSION, id: job.id });
    if (!took.json.ok) return;
    note('Filling invoice ' + job.invoice + ' …');
    let result;
    if (!(await inFront(sender))) result = { id: job.id, outcome: 'refused', boxes: 0, rows: 0, left: [], why: 'the Buffalo tab was no longer in front; nothing filled: click Fill again with it in front' };
    else {
      let gone = false;
      try {
        const [r] = await chrome.scripting.executeScript({ target, world: 'MAIN', func: self.tempeBuffalo, args: ['fill', job] });
        result = r && r.result;
      } catch (e) {
        gone = true;
        result = { id: job.id, outcome: 'failed', boxes: 0, rows: 0, left: [], why: 'the Buffalo page changed before it could be filled (' + short(e) + ')' };
      }
      if (!gone && (!result || result.id !== job.id)) result = await answer(target, job.id);
    }
    if (!result || result.id !== job.id) result = { id: job.id, outcome: 'failed', boxes: 0, rows: 0, left: [], why: 'the Buffalo page gave no answer (Chrome ' + CHROME + ')' };
    note('Invoice ' + job.invoice + ': ' + result.outcome + (result.why ? ' — ' + result.why : '') + '.');
    try { await call(port, '/buffalo/result', { ext: VERSION, id: job.id, outcome: result.outcome, boxes: result.boxes | 0, rows: result.rows | 0, left: (result.left || []).slice(0, 30), why: String(result.why || '') }); }
    catch (e) { note(state.line + ' (the helper didn’t get the answer)'); }
  } catch (e) {
    note('Stopped: ' + String(e.message || e).slice(0, 120));
  } finally { busy = false; }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id || !msg) return;
  if (msg.t === 'status' && !sender.tab) {   // the popup
    (async () => {
      await restored;
      let k = 'ok';
      try { await key(); } catch (e) { k = String(e.message || e); }
      if (k === 'ok') {
        // Whatever is remembered, the popup says only what a signed hello says now: a remembered port that doesn't
        // answer is forgotten and the ports searched once more (the helper may be back on another one).
        const LOST = /isn’t running|isn’t reachable|Lost the helper|More than one helper/;
        let port = await helperPort(true), ok = false;
        for (let tries = 0; port && !ok && tries < 2; tries++) {
          try { const a = await call(port, '/buffalo/hello', { ext: VERSION, schema: SCHEMA, chrome: CHROME }, 1500); if (a.status === 200 && a.json.ok) { state.helper = a.json.helper; ok = true; } } catch (e) { }
          if (!ok) { await forget(); port = tries === 0 ? await helperPort(true) : null; }
        }
        if (ok && LOST.test(state.line)) note('Connected to the Tempe helper: open a blank Create Consignment page, then click Fill Buffalo page in the helper.');
        if (!ok && !LOST.test(state.line)) note('The Tempe helper (RDP) isn’t running or isn’t reachable.');
      }
      sendResponse({ version: VERSION, chrome: CHROME, key: k, port: state.port, helper: state.helper, line: state.line, at: state.at });
    })();
    return true;
  }
  if (msg.t === 'tick' && sender.tab && sender.frameId === 0 && typeof sender.url === 'string' && sender.url.indexOf(CREATE) === 0 && sender.documentId) tick(sender);
});

// After install or update: give already open Create pages the content script again (never reload a tab).
chrome.runtime.onInstalled.addListener(async () => {
  try {
    const tabs = await chrome.tabs.query({ url: CREATE + '*' });
    for (const t of tabs) chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['content.js'] }).catch(() => { });
  } catch (e) { }
});
