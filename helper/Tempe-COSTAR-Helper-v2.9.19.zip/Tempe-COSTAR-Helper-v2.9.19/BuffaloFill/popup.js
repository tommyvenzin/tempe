// Tempe Buffalo Fill 1.0.2 — the popup: is this user's helper found, and the last thing that happened (text only).
chrome.runtime.sendMessage({ t: 'status' }).then(s => {
  const helper = document.getElementById('helper'), line = document.getElementById('line');
  if (s.key !== 'ok') { helper.className = 'row bad'; helper.textContent = 'Not set up: ' + s.key; }
  else if (s.port) { helper.className = 'row ok'; helper.textContent = 'Connected to the Tempe helper' + (s.helper ? ' ' + s.helper.split(' - ')[0] : '') + ' (port ' + s.port + ').'; }
  else { helper.className = 'row bad'; helper.textContent = 'The Tempe helper (RDP) isn’t running or isn’t reachable on this PC.'; }
  line.textContent = s.line || '';
  document.getElementById('version').textContent = 'Version ' + s.version + (s.chrome ? ' · Chrome ' + s.chrome : '');
}).catch(e => { document.getElementById('helper').textContent = 'Error: ' + e; });
