// Tempe Buffalo Fill 1.0.2 — what runs in the Buffalo page's own world (chrome.scripting, world MAIN). It is passed to
// executeScript as a function, so it is self-contained (no outside names). It only ever types into the receiver boxes
// and item rows of a BLANK Create Consignment page and never presses Save, Print or anything else.
// Every job string is written as text (val / typeahead('val') / textContent), never as HTML or into a selector.

// One function holds every part (Chrome passes a function by its source alone):
//   tempeBuffalo('look')          the page as it is now, at once (no waiting, so nothing depends on Chrome waiting for
//                                 a promise); every error comes back as {ok: false, error} instead of no answer
//   tempeBuffalo('fill', job)     the fill (it waits for the page itself); its answer is also left on the page
//   tempeBuffalo('answer', {id})  that answer, read back at once (for when Chrome hands back nothing from the fill)
//   tempeBuffalo('probe')         the fill's own settled-and-blank check (waits up to 2.5 s)
function tempeBuffalo(mode, job) {

// An error as words, never throwing itself (the page's own scripts may throw anything).
function said(e) { try { return String((e && e.message) || e).slice(0, 160); } catch (x) { return 'an error that can’t be shown'; } }

// Why this isn't a blank Create Consignment page the fill may write to (null when it is). own: the fill's own marker and
// banner are already there (the fill's last check, right before it writes).
// Buffalo hides the form for an account on hold or one that can't create consignments.
function heldWhy($) {
  const form = document.getElementById('basic-form');
  if (form && (!$(form).is(':visible') || $('.accountHoldContactOffice:visible, .accountNotAllowConCreation:visible').length))
    return 'Buffalo isn’t showing the consignment form (is the account on hold?)';
  return null;
}
function blankWhy($, own) {
  const v = id => { const e = document.getElementById(id); return e ? String(e.value || '').trim() : null; };
  const empty = id => { const x = v(id); return x === '' || x === '0'; };
  const form = document.getElementById('basic-form');
  if (!form) return 'not a Create Consignment page';
  const held = heldWhy($); if (held) return held;
  if (!empty('IdConsignment')) return 'this consignment is already saved';
  if (!own && (form.hasAttribute('data-tempe-fill') || document.getElementById('tempe-buffalo-fill'))) return 'this page was already filled';
  for (const id of ['ReceiverName', 'ReceiverName-auto', 'ReceiverAddress', 'ReceiverAddress-auto', 'ReceiverAddress2', 'ReceiverIdSuburb-auto', 'ReceiverIdSuburb',
    'ReceiverIdAddressPoint', 'ConsignmentReceiverEmail', 'ConsignmentReceiverContact', 'ConsignmentReceiverPhone', 'ReceiverReference']) {
    if (v(id) === null) return 'the Buffalo page has changed (no ' + id + ')';
    if (!empty(id)) return 'the receiver isn’t blank';
  }
  if (v('ReceiverAutoCompleteCode') !== null && !empty('ReceiverAutoCompleteCode')) return 'the receiver isn’t blank';
  // The e-mail box Buffalo shows when it checks addresses: a box to type in and tokens beside it.
  const tf = document.getElementById('ConsignmentReceiverEmail-auto-tokenfield');
  if (tf && (String(tf.value || '').trim() !== '' || (v('ConsignmentReceiverEmail-auto') !== null && !empty('ConsignmentReceiverEmail-auto')) ||
    (tf.closest('.tokenfield') && tf.closest('.tokenfield').querySelector('.token')))) return 'the receiver isn’t blank';
  if (v('SpecialInstructions') !== null && !empty('SpecialInstructions')) return 'the special instructions aren’t blank';
  const ids = $('#GridItems').jqGrid('getDataIDs') || [];
  if (ids.length !== 1 || String(ids[0]).indexOf('new') !== 0) return 'the items grid isn’t a single empty row';
  for (const c of ['Reference', 'Qty', 'Description', 'Weight']) {
    const e = document.getElementById(ids[0] + '_' + c);
    if (!e) return 'the items grid isn’t in its empty starting state';
    if (String(e.value || '').trim() !== '') return 'the items grid isn’t blank';
  }
  return null;
}

// The page's moving parts in one string: its item rows and the boxes that change as it loads (the same string for
// 1.5 s, with nothing loading, is a settled page).
function sigOf($) {
  const ids = $('#GridItems').jqGrid('getDataIDs') || [];
  const vals = ['ReceiverName', 'ReceiverName-auto', 'ReceiverAddress', 'ReceiverAddress-auto', 'ReceiverIdSuburb', 'ReceiverIdAddressPoint', 'ConsignmentItemDescArray']
    .map(id => { const e = document.getElementById(id); return e ? e.value : '\u0000'; });
  return JSON.stringify([ids, vals]);
}
function loading($) { return !($.active === 0 && document.readyState === 'complete' && !document.querySelector('.Row_Items.loading')); }

// The page as it is now, without waiting (the background compares one look with the next for settled). Never throws:
// a check that fails comes back as {ok: false, error}. why: null for a blank page the fill may write to.
function lookBuffalo() {
  try {
    const $ = window.jQuery;
    if (!$ || !$.fn || !$.fn.jqGrid) return { ok: true, quiet: false, why: 'the Buffalo page has not loaded its scripts' };
    const held = heldWhy($); if (held) return { ok: true, quiet: true, sig: 'held', why: held };
    if (loading($)) return { ok: true, quiet: false, why: 'the Buffalo page is still loading' };
    const sig = sigOf($), why = blankWhy($, false);
    return { ok: true, quiet: true, sig: sig, why: why, front: document.visibilityState === 'visible' && document.hasFocus() };
  } catch (e) { return { ok: false, error: said(e) }; }
}

// The fill's answer, as it left it on the page (null until there is one for this job).
function answerFor(id) {
  try {
    const s = document.documentElement.getAttribute('data-tempe-fill-result');
    const r = s ? JSON.parse(s) : null;
    return { ok: true, result: r && typeof id === 'string' && r.id === id ? r : null };
  } catch (e) { return { ok: false, error: said(e) }; }
}

// Is this a settled, blank Create Consignment page? Watches for up to 2.5 s; settled = nothing loading and the same
// boxes and grid rows for 1.5 s.
async function probeBuffalo() {
  const $ = window.jQuery;
  const quiet = () => !!$ && !loading($);
  const sig = () => { try { return sigOf($); } catch (e) { return 'error'; } };
  if (!$ || !$.fn || !$.fn.jqGrid) return { settled: false, blank: false, why: 'the Buffalo page has not loaded its scripts' };
  let last = null, since = Date.now();
  const end = Date.now() + 2500;
  while (Date.now() < end) {
    const held = heldWhy($); if (held) return { settled: true, blank: false, why: held };
    const s = quiet() ? sig() : 'busy';
    if (s !== last) { last = s; since = Date.now(); }
    else if (s !== 'busy' && Date.now() - since >= 1500) break;
    await new Promise(r => setTimeout(r, 250));
  }
  const settled = last !== null && last !== 'busy' && Date.now() - since >= 1500;
  if (!settled) return { settled: false, blank: false, why: 'the Buffalo page is still loading' };
  const why = blankWhy($, false);
  // In front and in use: the background checks this again right before it takes a job.
  const front = document.visibilityState === 'visible' && document.hasFocus();
  return { settled: true, blank: why === null, why: why, front: front };
}

// The fill, always with an answer: one it gives, or, should a check before the writes throw, a refusal (nothing is typed
// before the writes, which have their own catch); the FILLING banner and the page's mark are taken away again. The
// answer is also left on the page (data-tempe-fill-result), where the background reads it if Chrome hands back nothing.
async function fillBuffalo(job) {
  let r;
  try { r = await fillPage(job); }
  catch (e) {
    const form = document.getElementById('basic-form');
    if (form && job && typeof job.id === 'string' && form.getAttribute('data-tempe-fill') === job.id) {
      form.removeAttribute('data-tempe-fill');
      const b = document.getElementById('tempe-buffalo-fill'); if (b && b.parentNode) b.parentNode.removeChild(b);
    }
    r = { id: job && job.id, outcome: 'refused', boxes: 0, rows: 0, left: [],
      why: 'the page check stopped (' + said(e) + '); nothing filled: open a new Create Consignment page and click Fill again' };
  }
  try { document.documentElement.setAttribute('data-tempe-fill-result', JSON.stringify(r)); } catch (e) { }
  return r;
}

// Fills the page from the job. Returns {id, outcome: filled | partial | refused | failed, boxes, rows, left: [...], why}.
async function fillPage(job) {
  const $ = window.jQuery;
  const result = { id: job && job.id, outcome: 'refused', boxes: 0, rows: 0, left: [], why: '' };
  const byId = id => document.getElementById(id);
  const norm = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim().toUpperCase();
  const RECEIVER = ['ReceiverName', 'ReceiverName-auto', 'ReceiverAddress', 'ReceiverAddress-auto', 'ReceiverAddress2', 'ReceiverIdSuburb-auto', 'ReceiverIdSuburb',
    'ReceiverIdAddressPoint', 'ConsignmentReceiverEmail', 'ConsignmentReceiverContact', 'ConsignmentReceiverPhone', 'ReceiverReference'];
  const KEEP = ['CustomerName', 'SenderName', 'SenderName-auto', 'SenderAddress', 'SenderAddress-auto', 'SenderAddress2', 'SenderIdSuburb', 'SenderIdSuburb-auto',
    'SenderIdAddressPoint', 'ConsignmentSenderEmail', 'ConsignmentSenderContact', 'ConsignmentSenderPhone', 'SenderReference', 'ConsignmentDate',
    'ConsignmentServiceType', 'SpecialInstructions', 'ConsignmentNumber', 'ConsignmentDeliveryCloseTime'];
  const keepState = () => KEEP.map(id => { const e = byId(id); return e ? (e.type === 'checkbox' ? String(e.checked) : String(e.value)) : '\u0000'; })
    .concat(['ConsignmentReceiverIsResidential', 'IsPickupRequest', 'IsPickupRequest2'].map(id => { const e = byId(id); return e ? String(e.checked) : '\u0000'; }));

  // ---- the banner: outside the form, text only ----
  let shown = { kind: '', title: '', lines: [] };
  const banner = (kind, title, lines) => {
    shown = { kind: kind, title: title, lines: (lines || []).slice() };
    let b = byId('tempe-buffalo-fill');
    if (!b) {
      b = document.createElement('div'); b.id = 'tempe-buffalo-fill'; b.setAttribute('role', 'status'); b.tabIndex = -1;
      const form = byId('basic-form'); form.parentNode.insertBefore(b, form);
    }
    const colours = { filling: ['#e8f0fe', '#1a4d8f'], ready: ['#e6f4ea', '#1e6b30'], partial: ['#fff4ce', '#7a4b00'], failed: ['#fdecea', '#a01818'] };
    const c = colours[kind] || colours.failed;
    b.style.cssText = 'margin:8px 0 12px;padding:10px 14px;border:2px solid ' + c[1] + ';background:' + c[0] + ';color:' + c[1] + ';font:14px/1.4 Arial,sans-serif;border-radius:4px';
    b.setAttribute('data-kind', kind);
    while (b.firstChild) b.removeChild(b.firstChild);
    const h = document.createElement('div'); h.style.fontWeight = 'bold'; h.textContent = title; b.appendChild(h);
    if (lines && lines.length) {
      const ul = document.createElement('ul'); ul.style.margin = '6px 0 0 18px'; ul.style.padding = '0';
      for (const l of lines) { const li = document.createElement('li'); li.textContent = String(l); ul.appendChild(li); }
      b.appendChild(ul);
    }
    return b;
  };
  const mark = (el, why) => { if (!el) return; el.style.outline = '2px solid #c00'; el.style.outlineOffset = '1px'; el.setAttribute('title', String(why)); };

  // ---- checks before anything is written ----
  const refuse = why => { result.outcome = 'refused'; result.why = why; return result; };
  if (!job || job.schema !== 1 || typeof job.id !== 'string') return refuse('the job is not one this extension understands');
  if (!$ || !$.fn || !$.fn.typeahead || !$.fn.jqGrid || typeof window.addRowClick !== 'function' || typeof window.hookTabOutCubic !== 'function')
    return refuse('the Buffalo page has changed (its scripts are not the ones this extension knows); nothing filled');
  for (const id of RECEIVER.concat(['basic-form', 'IdConsignment', 'CustomerName', 'GridItems', 'ConsignmentItemDescArray']))
    if (!byId(id)) return refuse('the Buffalo page has changed (no ' + id + '); nothing filled');
  const header = norm($('#jqgh_GridItems_Weight').text());
  if (header !== 'TOTAL WEIGHT(KGS)') return refuse('Buffalo’s Weight column now reads "' + header + '"; nothing filled');
  const model = ($('#GridItems').jqGrid('getGridParam', 'colModel') || []).map(c => c.name);
  if (model.slice(0, 4).join(',') !== 'Reference,Qty,Description,Weight') return refuse('Buffalo’s item columns have changed; nothing filled');
  const descs = {};
  for (const part of String(byId('ConsignmentItemDescArray').value || '').split(',')) {
    const d = part.split('|'); if (d.length === 5) descs[d[0]] = d.slice(1).map(Number);
  }
  for (const t of ['PAS', 'SUV', 'TRUCK', 'CARTON']) {
    if (!descs[t]) return refuse('Buffalo’s Description list has no ' + t + '; nothing filled');
    if (descs[t].some(n => n !== 0)) return refuse('Buffalo’s Description list now gives ' + t + ' default sizes; nothing filled');
  }
  const customer = norm($('#CustomerName option:selected').text());
  if (customer !== 'TEMPE TYRES NSW') return refuse('the Customer isn’t Tempe Tyres NSW; nothing filled');
  const emailTyped = !!byId('ConsignmentReceiverEmail-auto-tokenfield') || !!byId('IsValidateConsignmentCreationEmailEnabled');
  // Where an e-mail left for a person is outlined: the box Buffalo shows (its token box), not the hidden one behind it.
  const emailBox = () => { const tf = byId('ConsignmentReceiverEmail-auto-tokenfield'); return tf ? (tf.closest('.tokenfield') || tf) : byId('ConsignmentReceiverEmail'); };
  // The keyboard out of the form first: leaving a box can run the page's own handlers (a row added on leaving Weight),
  // which the checks below then see.
  const form = byId('basic-form');
  const blurForm = () => { const a = document.activeElement; if (a && a !== document.body && form.contains(a)) a.blur(); };
  blurForm();
  const blank = (await probeBuffalo());
  if (!blank.settled || !blank.blank) return refuse((blank.why || 'the page isn’t ready') + '; open a new Create Consignment page and click Fill again');
  // Still the tab showing (the background checked it was in front and in use before it took the job; the probe takes a
  // second or two). Only whether it shows: opening the extension's own button, say, takes the keyboard but not the tab.
  const frontWhy = () => document.visibilityState !== 'visible' ? 'the Buffalo tab is no longer showing' : null;
  if (frontWhy()) return refuse(frontWhy() + '; nothing filled: click Fill again with the page in front');

  // From here the page is marked and says FILLING, so nobody starts typing while the suburb is looked up; a refusal
  // before the writes takes both away again (nothing was written).
  const before = keepState();   // boxes the fill never touches: the same from here to the read-back
  form.setAttribute('data-tempe-fill', job.id);
  banner('filling', 'Tempe helper: FILLING invoice ' + job.invoice + ' — not finished. Don’t type here or save yet.', []);
  const TYPEAHEADS = '#ReceiverName-auto,#ReceiverAddress-auto,#ReceiverIdSuburb-auto';
  let picked = false; const onPick = () => { picked = true; };
  try { $(TYPEAHEADS).on('typeahead:selected typeahead:autocompleted', onPick); } catch (e) { }
  const unhook = () => { try { $(TYPEAHEADS).off('typeahead:selected typeahead:autocompleted', onPick); } catch (e) { } };
  const undo = why => { unhook(); form.removeAttribute('data-tempe-fill'); const b = byId('tempe-buffalo-fill'); if (b && b.parentNode) b.parentNode.removeChild(b); return refuse(why); };

  // ---- the suburb, looked up before any write (the page's own lookup) ----
  let place = null, placeWhy = job.suburb && job.suburb.unresolved;
  if (!placeWhy) {
    const ctl = new AbortController(); const timer = setTimeout(() => ctl.abort(), 8000);
    let list;
    try {
      const r = await fetch('/Portal/StandingData/SuburbAutocomplete?term=' + encodeURIComponent(job.suburb.suburb),
        { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' }, signal: ctl.signal, cache: 'no-store' });
      if (!r.ok || r.redirected || !/json/i.test(r.headers.get('content-type') || '')) throw new Error('reply');
      list = await r.json();
      if (!Array.isArray(list) || list.some(d => !d || !(Number.isInteger(d.IdSuburb) && d.IdSuburb > 0) || typeof d.Suburb !== 'string' ||
        typeof d.State !== 'string' || (typeof d.Postcode !== 'string' && typeof d.Postcode !== 'number') || typeof d.SuburbDisplay !== 'string')) throw new Error('shape');
    } catch (e) {
      clearTimeout(timer);
      return undo('Buffalo didn’t answer the suburb lookup (you may be logged out): log in, open a new Create Consignment page and click Fill again');
    }
    clearTimeout(timer);
    const hits = list.filter(d => norm(d.Suburb) === norm(job.suburb.suburb) && norm(d.State) === norm(job.suburb.state) && norm(d.Postcode) === norm(job.suburb.postcode));
    if (hits.length === 1) place = hits[0];
    else placeWhy = hits.length === 0 ? 'Buffalo’s list has no ' + job.suburb.suburb + ' ' + job.suburb.state + ' ' + job.suburb.postcode + ': pick it yourself'
      : 'Buffalo’s list has that suburb more than once: pick it yourself';
  }
  // The rows must add up (the helper's own rule, checked again).
  if (job.rowsReady && (!Array.isArray(job.rows) || job.rows.length === 0 || job.rows.some(r => !r || ['PAS', 'SUV', 'TRUCK', 'CARTON'].indexOf(r.description) < 0 ||
    !(r.qty > 0) || r.weight !== r.qty * r.unitKg || r.reference !== job.invoice))) return undo('the item rows in the job don’t add up; nothing filled');

  // ---- the last check, then the writes with no pause between them (nobody can type in between) ----
  blurForm();
  await new Promise(r => setTimeout(r, 300));   // the page's own leave-a-box handlers have their say
  blurForm();   // and once more, with no pause after it: a box clicked during the wait runs its handlers now, seen below
  const changedWhy = frontWhy() || blankWhy($, true) || (picked ? 'an address-book entry was picked' : null) ||
    (keepState().some((x, i) => x !== before[i]) ? 'a box the fill doesn’t touch changed' : null);
  if (changedWhy) return undo('the page changed while the fill was starting (' + changedWhy + '); nothing filled: open a new Create Consignment page and click Fill again');
  unhook();

  // ---- the writes: one pass, then the read-back ----
  const expect = {};   // id -> value the read-back must find
  const wrote = {};    // receiver boxes the fill put a value in: watched afterwards
  const left = [];
  // An address-book entry's hidden id and code aren't written: they must stay as they were (empty).
  for (const id of ['ReceiverIdAddressPoint', 'ReceiverAutoCompleteCode']) { const e = byId(id); if (e) { expect[id] = String(e.value); wrote[id] = true; } }
  try {
    const typeahead = (auto, hidden, v) => {
      $('#' + auto).typeahead('val', v);
      if (hidden) byId(hidden).value = v;
      $('span', 'label[name="' + auto + '"]').text(v);
      expect[auto] = v; if (hidden) expect[hidden] = v;
      if (v !== '') { wrote[auto] = true; if (hidden) wrote[hidden] = true; }
    };
    const plain = (id, v) => { $('#' + id).val(v).trigger('change'); $('span', 'label[name="' + id + '"]').text(v); expect[id] = v; if (v !== '') wrote[id] = true; };
    const leave = (label, ids, markEl, why) => {
      for (const id of ids) { if (id.slice(-5) === '-auto') $('#' + id).typeahead('val', ''); else byId(id).value = ''; expect[id] = ''; }
      mark(typeof markEl === 'string' ? byId(markEl) : markEl, why); left.push(label + ': ' + why);
    };
    const box = (label, b, fn, ids, markId) => {
      if (b && typeof b.value === 'string' && !b.unresolved) { fn(b.value); if (b.value !== '') result.boxes++; }
      else leave(label, ids, markId, (b && b.unresolved) || 'not given');
    };
    box('Name', job.name, v => typeahead('ReceiverName-auto', 'ReceiverName', v), ['ReceiverName-auto', 'ReceiverName'], 'ReceiverName-auto');
    box('Address', job.address1, v => typeahead('ReceiverAddress-auto', 'ReceiverAddress', v), ['ReceiverAddress-auto', 'ReceiverAddress'], 'ReceiverAddress-auto');
    byId('ReceiverAddress2').value = ''; expect.ReceiverAddress2 = '';
    if (place) {
      $('#ReceiverIdSuburb-auto').typeahead('val', place.SuburbDisplay);
      $('span', 'label[name="ReceiverIdSuburb-auto"]').text(place.SuburbDisplay);
      byId('ReceiverIdSuburb').value = String(place.IdSuburb);
      expect['ReceiverIdSuburb-auto'] = place.SuburbDisplay; expect.ReceiverIdSuburb = String(place.IdSuburb); result.boxes++;
      wrote['ReceiverIdSuburb-auto'] = true; wrote.ReceiverIdSuburb = true;
    } else leave('Suburb', ['ReceiverIdSuburb-auto', 'ReceiverIdSuburb'], 'ReceiverIdSuburb-auto', placeWhy || 'not given');
    if (emailTyped && job.email && job.email.value) leave('Email', ['ConsignmentReceiverEmail'], emailBox(), 'Buffalo’s email box needs typing here: ' + job.email.value);
    else box('Email', job.email, v => plain('ConsignmentReceiverEmail', v), ['ConsignmentReceiverEmail'], emailBox());
    box('Contact', job.contact, v => plain('ConsignmentReceiverContact', v), ['ConsignmentReceiverContact'], 'ConsignmentReceiverContact');
    box('Phone', job.phone, v => plain('ConsignmentReceiverPhone', v), ['ConsignmentReceiverPhone'], 'ConsignmentReceiverPhone');
    box('Reference', job.reference, v => plain('ReceiverReference', v), ['ReceiverReference'], 'ReceiverReference');

    // Item rows: all or nothing. The first row is whatever the page made; each further one by the page's own addRowClick.
    const rowIds = [];
    // 1.0.2 (Tommy, 26 Nov: "the reference under consignment items are not filled out, which it should be"): every row's
    // Reference is the Repair Order number, the invoice's own number, whatever the rows hold. When the rows are left for a
    // person, the first row still gets that Reference; its Qty, Description and Weight stay empty for them.
    const firstRow = String($('#GridItems').jqGrid('getDataIDs')[0]);
    let refOnly = false;
    if (job.rowsReady) {
      const grid = $('#GridItems');
      rowIds.push(grid.jqGrid('getDataIDs')[0]);
      for (let i = 1; i < job.rows.length; i++) {
        const was = grid.jqGrid('getDataIDs').slice();
        window.addRowClick();
        const now = grid.jqGrid('getDataIDs');
        const added = now.filter(x => was.indexOf(x) < 0);
        if (added.length !== 1 || now[now.length - 1] !== added[0]) throw new Error('a new item row didn’t appear as expected');
        rowIds.push(added[0]);
        if (document.activeElement && form.contains(document.activeElement)) document.activeElement.blur();
      }
      window.hookTabOutCubic();
      job.rows.forEach((row, i) => {
        const id = rowIds[i];
        for (const c of ['Reference', 'Qty', 'Description', 'Weight']) if (document.querySelectorAll('#' + id + '_' + c).length !== 1) throw new Error('item row ' + (i + 1) + ' has no single ' + c + ' box');
        byId(id + '_Reference').value = row.reference; byId(id + '_Description').value = row.description; byId(id + '_Weight').value = String(row.weight);
        $('#' + id + '_Qty').val(String(row.qty)).trigger('change');
        expect[id + '_Reference'] = row.reference; expect[id + '_Description'] = row.description; expect[id + '_Weight'] = String(row.weight); expect[id + '_Qty'] = String(row.qty);
        result.rows++;
      });
    } else {
      const ref = job.itemReference;
      if (typeof ref === 'string' && ref !== '' && ref === job.invoice) {
        for (const c of ['Reference', 'Qty', 'Description', 'Weight']) if (document.querySelectorAll('#' + firstRow + '_' + c).length !== 1) throw new Error('the first item row has no single ' + c + ' box');
        byId(firstRow + '_Reference').value = ref;
        expect[firstRow + '_Reference'] = ref;
        for (const c of ['Qty', 'Description', 'Weight']) expect[firstRow + '_' + c] = '';
        refOnly = true;
      }
      const why = (job.rowsWhy || []).join('; ');
      mark(byId('gbox_GridItems') || byId('GridItems'), (refOnly ? 'Item rows NOT filled (only the first row’s Reference): ' : 'Item rows NOT filled: ') + why);
      left.push(refOnly ? 'Item rows: only the first row’s Reference (the invoice number) is filled (' + why + '): add its Qty, Description and Weight, and any other rows, yourself'
        : 'Item rows: none filled (' + why + '): add every row yourself');
    }
    // Close every suggestion list; leave the keyboard on the banner, never in a box.
    try { $('#ReceiverName-auto,#ReceiverAddress-auto,#ReceiverIdSuburb-auto').typeahead('close'); } catch (e) { }
    $('.tt-dropdown-menu').hide(); $('.ui-autocomplete').hide();
    if (document.activeElement && form.contains(document.activeElement)) document.activeElement.blur();

    // ---- read back once the page has had its say ----
    const settleEnd = Date.now() + 6000;
    while (Date.now() < settleEnd && !($.active === 0)) await new Promise(r => setTimeout(r, 200));
    await new Promise(r => setTimeout(r, 1500));
    const wrong = [];
    for (const id of Object.keys(expect)) {
      const e = byId(id);
      const got = id.slice(-5) === '-auto' ? String($('#' + id).typeahead('val')) : (e ? String(e.value) : '\u0000');
      if (got !== expect[id]) wrong.push(id);
    }
    const nowIds = $('#GridItems').jqGrid('getDataIDs');
    if (job.rowsReady && nowIds.join(',') !== rowIds.join(',')) wrong.push('the item rows');
    if (!job.rowsReady && (nowIds.length !== 1 || String(nowIds[0]) !== firstRow || ['Reference', 'Qty', 'Description', 'Weight'].some(c => {
      const e = byId(nowIds[0] + '_' + c); return !e || e.value !== (c === 'Reference' && refOnly ? job.itemReference : '');
    }))) wrong.push(refOnly ? 'the first item row' : 'the empty item row');
    const after = keepState();
    const moved = KEEP.concat(['ConsignmentReceiverIsResidential', 'IsPickupRequest', 'IsPickupRequest2']).filter((id, i) => before[i] !== after[i]);
    if (wrong.length || moved.length) {
      result.outcome = 'failed';
      result.why = (wrong.length ? 'Buffalo changed ' + wrong.join(', ') + ' after the fill' : '') + (wrong.length && moved.length ? '; ' : '') +
        (moved.length ? 'boxes the fill must not touch changed (' + moved.join(', ') + ')' : '');
      result.left = left;
      banner('failed', 'Tempe helper: FILL STOPPED PART WAY for invoice ' + job.invoice + ' — do not Save this page.', [result.why, 'Open a new Create Consignment page and click Fill again, or type it all yourself.']);
      return result;
    }
    result.left = left;
    const notReady = !job.ready || left.length > 0;
    result.outcome = notReady ? 'partial' : 'filled';
    if (notReady) {
      const lines = left.slice();
      for (const s of (job.stops || [])) lines.push(s);
      if (job.notes && job.notes.length) lines.push('Note line' + (job.notes.length > 1 ? 's ' : ' ') + job.notes.join(', ') + ': read ' + (job.notes.length > 1 ? 'them' : 'it') + ' on the invoice');
      banner('partial', 'NOT READY — filled what was ready from invoice ' + job.invoice + ' (' + (job.unresolvedCount || 0) + ' item' + (job.unresolvedCount === 1 ? '' : 's') +
        ' unresolved in the helper). Finish the highlighted boxes, check everything against the invoice, then Save it yourself.', lines);
    } else {
      const lines = [];
      if (job.notes && job.notes.length) lines.push('Note line' + (job.notes.length > 1 ? 's ' : ' ') + job.notes.join(', ') + ': read ' + (job.notes.length > 1 ? 'them' : 'it') + ' on the invoice');
      banner('ready', 'ALL FILLED by the Tempe helper from invoice ' + job.invoice + ' — check every box against the invoice, then Save it yourself.', lines);
    }
    // The grid moves the keyboard into a new row a moment after adding it: take it out again and leave it on the banner,
    // so a Tab can't run a suggestion list or add a row.
    if (document.activeElement && form.contains(document.activeElement)) document.activeElement.blur();
    try { byId('tempe-buffalo-fill').focus({ preventScroll: true }); } catch (e) { }
    // Afterwards: a box the fill put a value in that changes (an address-book pick) is pointed out; the person's choice
    // is never undone. Boxes left for the person aren't watched: typing or picking there is what the banner asks for.
    // A NOT READY banner keeps its title and its list; the warning goes on top of it.
    const watched = Object.keys(expect).filter(id => wrote[id]);
    const stamp = job.id; let ticks = 0, warned = false, watch = null;
    const warn = () => {
      if (warned) return; warned = true; if (watch) clearInterval(watch);
      const b = byId('tempe-buffalo-fill'); if (!b || b.getAttribute('data-kind') === 'failed') return;
      const msg = 'A receiver box the Tempe helper filled has changed since (an address-book pick?): check every receiver box against the invoice before saving.';
      if (shown.kind === 'partial') banner('partial', shown.title, [msg].concat(shown.lines));
      else banner('failed', 'CHECK THE RECEIVER — a box changed after the Tempe helper filled invoice ' + job.invoice + ' (an address-book pick?): check every receiver box against the invoice before saving.', shown.lines);
    };
    const picks = ['ReceiverName-auto', 'ReceiverAddress-auto', 'ReceiverIdSuburb-auto'].filter(id => wrote[id]).map(id => '#' + id).join(',');
    try { if (picks) $(picks).on('typeahead:selected typeahead:autocompleted', warn); } catch (e) { }
    watch = setInterval(() => {
      if (++ticks > 900 || form.getAttribute('data-tempe-fill') !== stamp) { clearInterval(watch); return; }
      for (const id of watched) { const e = byId(id); const got = id.slice(-5) === '-auto' ? String($('#' + id).typeahead('val')) : (e ? String(e.value) : ''); if (got !== expect[id]) { warn(); return; } }
    }, 2000);
    return result;
  } catch (e) {
    result.outcome = 'failed'; result.why = 'the fill stopped: ' + said(e); result.left = left;
    try { banner('failed', 'Tempe helper: FILL STOPPED PART WAY for invoice ' + job.invoice + ' — do not Save this page.', [result.why, 'Open a new Create Consignment page and click Fill again, or type it all yourself.']); } catch (e2) { }
    return result;
  }
}

if (mode === 'look') return lookBuffalo();
if (mode === 'answer') return answerFor(job && job.id);
if (mode === 'fill') return fillBuffalo(job);
if (mode === 'probe') return probeBuffalo();
return { ok: false, error: 'unknown mode' };
}

if (typeof self !== 'undefined') self.tempeBuffalo = tempeBuffalo;
