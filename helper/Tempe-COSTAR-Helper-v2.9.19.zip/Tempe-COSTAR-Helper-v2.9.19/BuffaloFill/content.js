// Tempe Buffalo Fill 1.0.2 — on Buffalo's Create Consignment page only. It just says "this page is in front" once a
// second (and on focus); the background does the rest. It never reads or writes the page and never holds the key.
(() => {
  const token = Math.random().toString(36).slice(2) + Date.now().toString(36);
  document.documentElement.setAttribute('data-tempe-buffalo-fill-script', token);
  let timer = null;
  const alive = () => {
    try { return !!(chrome.runtime && chrome.runtime.id) && document.documentElement.getAttribute('data-tempe-buffalo-fill-script') === token; }
    catch (e) { return false; }
  };
  const stop = () => { clearInterval(timer); window.removeEventListener('focus', tick); document.removeEventListener('visibilitychange', tick); };
  function tick() {
    if (!alive()) { stop(); return; }
    if (document.visibilityState !== 'visible' || !document.hasFocus()) return;
    try { const p = chrome.runtime.sendMessage({ t: 'tick' }); if (p && p.catch) p.catch(() => { }); }
    catch (e) { stop(); }
  }
  timer = setInterval(tick, 1000);
  window.addEventListener('focus', tick);
  document.addEventListener('visibilitychange', tick);
  tick();
})();
