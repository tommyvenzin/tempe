param([switch]$CheckOnly, [switch]$PassThru)
$ErrorActionPreference = 'Stop'
$stage = 'Create local build folder'
$startupLog = $null
try {
    if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) { throw 'Windows did not provide LOCALAPPDATA for this user.' }
    $appFolder = Join-Path $env:LOCALAPPDATA 'TempeMobileCostar'
    [IO.Directory]::CreateDirectory($appFolder) | Out-Null
    $startupLog = Join-Path $appFolder ('startup-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + $PID + '.txt')
    @('Tempe helper 2.9.19 startup', ('Source: ' + $PSScriptRoot), ('Local data: ' + $appFolder)) | Set-Content -LiteralPath $startupLog -Encoding UTF8
    $stage = 'Read helper source files'
    $requiredSources = @('AccountTests.cs','AppData.cs','AuPlaceData.cs','AuStates.cs','CostarMap.cs','CostarSession.cs','DesktopUi.cs','Diagnostics.cs','Direct.cs','EbayDesk.cs','EbayModel.cs','EbayTab.cs','EbayTests.cs','EbayWorker.cs','InvoiceLive.cs','InvoiceModel.cs','InvoiceBuffalo.cs','InvoiceTab.cs','InvoiceTests.cs','LocalHttp.cs','MobileModel.cs','MobileRunner.cs','MobileTests.cs','Native.cs','NewAccount.cs','OnlineAuto.cs','OnlineModelTests.cs','OnlineTab.cs','OrderCheck.cs','OrderModel.cs','Program.cs','ResourceBudget.cs','RoDesk.cs','RoModel.cs','RoTab.cs','RoTests.cs','RoWorker.cs','Runner.cs','Runner.Customer.cs','Runner.Ebay.cs','Runner.Grid.cs','Runner.NewAccount.cs','Runner.Online.cs','Runner.Popups.cs','Runner.Print.cs','Runner.Ro.cs','RunsByItself.cs','Ui.cs','Unattended.cs','Updater.cs','Wholesale.cs','WholesaleDiscord.cs','WholesaleForm.cs','WholesaleSpeed.cs','WholesaleState.cs','WholesaleTab.cs','WholesaleTests.cs','WholesaleView.cs','Worker.cs')
    $sourceRoot = Join-Path $PSScriptRoot 'Source'
    $missingSources = @($requiredSources | Where-Object { !(Test-Path -LiteralPath (Join-Path $sourceRoot $_) -PathType Leaf) })
    if ($missingSources.Count -gt 0) { throw ('The helper folder is incomplete. Missing Source files: ' + ($missingSources -join ', ') + '. Extract the complete v2.9.19 ZIP into a fresh folder and run Start-RDP.cmd from there.') }
    $sourceFiles = @($requiredSources | ForEach-Object { Get-Item -LiteralPath (Join-Path $sourceRoot $_) })
    # 2.9.15: the invoice read is a dry run that can't sell. No Invoice*.cs file may name a press, key, click, close,
    # keyboard-focus, text-setting or selling call (the same list as InvoiceSourceGuard.Patterns in InvoiceLive.cs; each
    # pattern is written so it doesn't match its own text). It also allows only read members of the classes that can press
    # COSTAR (Native, Runner, CostarWindows, WholesaleOrderReader; none of Msaa, Win, RoWip, RoEngine ...), no using-alias,
    # and only one message: WM_VSCROLL through the scroll P/Invoke (plus the WM_NULL ping).
    $stage = 'Check the invoice read cannot press, type or sell'
    $invoiceForbidden = @('\bDirec[t]\s*\.','BM_CLIC[K]','(?i)\b0x0*F[5]\b','KeyNo[w]',
        '\bNative\s*\.\s*(?:Ke[y]|Clic[k]|DoubleClic[k]|RightClic[k]|Whee[l]|Chor[d]|BringToFron[t]|SetForegroundWindo[w]|ShowWindo[w]|WriteMessag[e])',
        'DoubleClic[k]','SendInpu[t]','keybd_even[t]','mouse_even[t]','WM_CLOS[E]','CloseWindo[w]','(?i)\b0x0*1[0]\b','WM_SETTEX[T]',
        '(?i)\b0x0*[C]\b','SetFocu[s]','accDoDefaultActio[n]','(?i)\bsel[l]\w*\s*\(','\bSetTex[t]\s*\(','SetWindowTex[t]','PostMessag[e]',
        'SendKey[s]','(?i)MOUSEWHEE[L]','(?i)\bWM_(?:KEY|SYSKEY|CHAR|[LRM]BUTTON|COMMAN[D])','ShowTa[b]','PressLate[r]',
        '\bRoWi[p]\s*\.\s*(?:Ope[n]|Fron[t]|PressSearc[h]|ClearFilte[r])','\bDoDefaul[t]','SelectChil[d]','accSelec[t]','\busin[g]\s+\w+\s*=',
        '\bNativ[e]\s*\.\s*(?!(?:Caption|Class|EnumChildWindows|EnumWindows|Focus|GetGUIThreadInfo|GetParent|GetWindowThreadProcessId|GuiInfo|GetWindow|GetWindowLong|GetWindowRect|IsWindow|IsWindowEnabled|IsWindowVisible|NotePointer|Pid|Rect|SendNull|TryText|UserActiveWithin)\b)\w',
        '\bRunne[r]\s*\.\s*(?!Decoration\b)\w','\bCostarWindow[s]\s*\.\s*(?!IsCostar\b)\w',
        '\bWholesaleOrderReade[r]\s*\.\s*(?!(?:Beside|Snapshot|Tab)\b)\w',
        '\b(?:Msa[a]|Wi[n]|RoWi[p]|RoEngin[e]|WipScree[n]|WipScrol[l]|WipSearc[h]|CostarWipScree[n]|Costa[r]|WholesaleRu[n]|GridReade[r]|Unattende[d])\s*\.\s*\w',
        '\btypeo[f]\s*\(\s*(?:Native|Msaa|Direct|Runner|RoWip|RoEngine|Win|Costar|CostarWindows|WholesaleOrderReader)\s*\)',
        '\bGetMetho[d]\s*\(|\bInvokeMembe[r]\b|CreateDelegat[e]|GetDelegateForFunctionPointe[r]',
        '\bexter[n]\s+[\w.]+\s+(?!(?:ScrollMessag[e]|GetScrollInf[o])\s*\()\w+\s*\(','EntryPoin[t]\s*=\s*\x22(?!SendMessageTimeoutW\x22)',
        '\bScrollMessag[e]\s*\((?!\s*IntPtr\s+h\s*,\s*uint\s+msg\s*,)(?!\s*grid\s*,\s*WmVScrol[l]\s*,)','\bWmVScrol[l]\s*=\s*(?!0x0115\b)',
        '\bSendNul[l]\s*\(\s*[^,()]+,\s*(?!0\s*,)')
    foreach ($invoiceFile in @(Get-ChildItem -LiteralPath $sourceRoot -Filter 'Invoice*.cs' -File)) {
        $invoiceText = [IO.File]::ReadAllText($invoiceFile.FullName)
        $invoiceHits = @($invoiceForbidden | Where-Object { [regex]::IsMatch($invoiceText, $_) })
        if ($invoiceHits.Count -gt 0) { throw ($invoiceFile.Name + ' names a call the invoice dry run must never make (pattern ' + ($invoiceHits -join ' ') + '). The build was stopped; COSTAR was not changed.') }
    }
    $stage = 'Read helper source files'
    $resourceSource = Join-Path $PSScriptRoot 'Source\qr.js'
    $websiteFiles = @(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'Website') -File -Recurse | Sort-Object FullName)
    # 2.9.17: the Tempe Buffalo Fill extension's files travel with the build (the helper copies them to the fixed folder Chrome loads).
    $buffaloFiles = @(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'BuffaloFill') -File -ErrorAction SilentlyContinue | Sort-Object FullName)
    if ($sourceFiles.Count -eq 0 -or !(Test-Path -LiteralPath $resourceSource) -or $websiteFiles.Count -eq 0 -or $buffaloFiles.Count -eq 0) { throw 'Extract the complete helper ZIP, including Source, Website and BuffaloFill.' }
    $fingerprintInputs = @($sourceFiles.FullName) + @($resourceSource, $PSCommandPath) + @($websiteFiles.FullName) + @($buffaloFiles.FullName)
    $fingerprint = ($fingerprintInputs | ForEach-Object { (Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash }) -join ''
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $buildId = ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($fingerprint)))).Replace('-', '').Substring(0, 20) }
    finally { $sha.Dispose() }
    # A source-specific local directory avoids network execution and overwriting
    # the EXE of an older helper that is still open. Settings are stored elsewhere.
    $runtimeFolder = Join-Path $appFolder ('runtime\' + $buildId)
    $bin = Join-Path $runtimeFolder 'bin'
    $localSource = Join-Path $runtimeFolder 'Source'
    $stage = 'Copy build files to the local user folder'
    [IO.Directory]::CreateDirectory($bin) | Out-Null
    [IO.Directory]::CreateDirectory($localSource) | Out-Null
    foreach ($sourceFile in $sourceFiles) { Copy-Item -LiteralPath $sourceFile.FullName -Destination (Join-Path $localSource $sourceFile.Name) -Force }
    Copy-Item -LiteralPath $resourceSource -Destination (Join-Path $localSource 'qr.js') -Force
    $localWebsite = Join-Path $runtimeFolder 'Website'
    [IO.Directory]::CreateDirectory($localWebsite) | Out-Null
    foreach ($websiteFile in $websiteFiles) {
        $websiteRoot = (Join-Path $PSScriptRoot 'Website').TrimEnd('\')
        $relative = $websiteFile.FullName.Substring($websiteRoot.Length).TrimStart('\')
        $destination = Join-Path $localWebsite $relative
        [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($destination)) | Out-Null
        Copy-Item -LiteralPath $websiteFile.FullName -Destination $destination -Force
    }
    $localBuffalo = Join-Path $runtimeFolder 'BuffaloFill'
    [IO.Directory]::CreateDirectory($localBuffalo) | Out-Null
    foreach ($buffaloFile in $buffaloFiles) { Copy-Item -LiteralPath $buffaloFile.FullName -Destination (Join-Path $localBuffalo $buffaloFile.Name) -Force }
    Write-Host ('Local build folder: ' + $runtimeFolder)
    ('Build: ' + $runtimeFolder) | Add-Content -LiteralPath $startupLog -Encoding UTF8
    $stage = 'Locate the Windows C# compiler'
    $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
    if (!(Test-Path $compiler)) { $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe' }
    if (!(Test-Path $compiler)) { throw 'The Windows .NET Framework compiler is unavailable. Send this message; no software has been installed.' }
    $sources = @($requiredSources | ForEach-Object { Join-Path $localSource $_ })
    $resource = Join-Path $localSource 'qr.js'
    $exe = Join-Path $bin 'TempeMobile.exe'
    $stamp = Join-Path $bin 'build.sha256'
    if (!(Test-Path $exe) -or !(Test-Path $stamp) -or ([IO.File]::ReadAllText($stamp) -ne $fingerprint)) {
        $stage = 'Compile the helper locally'
        $refs = @('System.dll','System.Core.dll','System.Windows.Forms.dll','System.Drawing.dll','System.Web.dll','System.Web.Extensions.dll','System.Security.dll','System.IO.Compression.dll','System.IO.Compression.FileSystem.dll','Accessibility.dll')
        $arguments = @('/nologo','/target:winexe','/platform:anycpu','/langversion:5','/codepage:65001',('/out:' + $exe),('/resource:' + $resource + ',TempeQR.js'))
        $arguments += $refs | ForEach-Object { '/reference:' + $_ }
        Push-Location -LiteralPath $bin
        try {
            & $compiler @arguments @sources | Tee-Object -FilePath (Join-Path $bin 'compiler-output.txt') | Out-Host
            if ($LASTEXITCODE -ne 0) { throw ('The C# compiler exited with code ' + $LASTEXITCODE + '. See compiler-output.txt in the local bin folder and the error above.') }
        } finally { Pop-Location }
        [IO.File]::WriteAllText($stamp, $fingerprint)
    }
    $stage = 'Run the Windows self-tests'
    $report = Join-Path $bin 'self-test-results.txt'
    $testStamp = Join-Path $bin 'self-test.sha256'
    $exeHash = (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash
    $needsTest = $CheckOnly -or !(Test-Path -LiteralPath $testStamp) -or !(Test-Path -LiteralPath $report)
    if (!$needsTest) { $needsTest = [IO.File]::ReadAllText($testStamp) -ne $exeHash }
    if ($needsTest) {
        if (Test-Path -LiteralPath $testStamp) { Remove-Item -LiteralPath $testStamp -Force }
        if (Test-Path -LiteralPath $report) { Remove-Item -LiteralPath $report -Force }
        $test = Start-Process -FilePath $exe -WorkingDirectory $bin -ArgumentList @('--self-test', ('"' + $report + '"')) -PassThru -Wait
        try {
            if (!(Test-Path -LiteralPath $report)) { throw ('The self-test process exited with code ' + $test.ExitCode + ' without a report. Windows may have blocked startup; check the exact error with IT.') }
            Get-Content -LiteralPath $report | Out-Host
            if ($test.ExitCode -ne 0) { throw 'Self-tests failed. COSTAR was not changed.' }
            [IO.File]::WriteAllText($testStamp, $exeHash)
        } finally { $test.Dispose() }
    } else { Write-Host 'Reusing passing self-tests for this unchanged executable. Check-Build.cmd forces a fresh run.' }
    'Build and self-tests passed.' | Add-Content -LiteralPath $startupLog -Encoding UTF8
    Write-Host ('Build and self-tests passed. Report: ' + $report) -ForegroundColor Green
    if ($PassThru) { [pscustomobject]@{ Executable=$exe; Bin=$bin; Root=$runtimeFolder; Report=$report; StartupLog=$startupLog } }
} catch {
    $message = 'Startup failed during "' + $stage + '": ' + $_.Exception.Message
    if ($startupLog) {
        try { @($message, $_.ScriptStackTrace) | Add-Content -LiteralPath $startupLog -Encoding UTF8 } catch { }
        $message += [Environment]::NewLine + 'Startup report: ' + $startupLog
    }
    throw $message
}
