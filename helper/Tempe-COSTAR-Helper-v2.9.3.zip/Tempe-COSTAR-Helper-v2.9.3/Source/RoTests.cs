// Self-tests for Repair Orders from the phone (2.6.0): reading a Repair Order from its controls, the
// rules for a change, the check of the result, the desk's queue and its routes. Never opens, clicks
// or types into COSTAR. Made-up customers and cars.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace TempeCostar {
    internal static class RoTests {
        static void Check(bool value,string message){if(!value)throw new InvalidOperationException(message);}
        static void Reject(Action action,string message,string contains=null) {
            string error=null;try{action();}catch(InvalidOperationException e){error=e.Message;}
            Check(error!=null,message);
            if(contains!=null) Check(error.Contains(contains),message+" (said: "+error+")");
        }
        const string ST="WindowsForms10.STATIC.app.0.1",ED="WindowsForms10.EDIT.app.0.1",WN="WindowsForms10.Window.8.app.0.1",CB="WindowsForms10.COMBOBOX.app.0.1",DT="WindowsForms10.SysDateTimePick32.app.0.1";
        static ControlInfo Mk(long h,long parent,string cls,int x,int y,int w,int hh,string text) {
            return new ControlInfo {Handle=h,Parent=parent,Class=cls,Visible=true,Enabled=true,Bounds=new[]{x,y,w,hh},RelativeBounds=new[]{x,y,w,hh},Text=text,TextState="read"};
        }
        // A made-up Repair Order: the customer panel, Time In / Date In / Written By, Ship to, the 25
        // lines (lines[n] = code, description, quantity, net) and the total.
        sealed class Fixture {
            internal string Account="",Name="TEST CUSTOMER",Phone="0400000001",Email="test.customer@example.com",Address="1 TEST STREET",Address2="",Suburb="TESTVILLE",State="NSW",Postcode="2999",Po="",Comment="WAITING FOR TYRES";
            internal string ShipVia="",TimeIn="8:30 am",DateIn="27/10/2026",DateKind="edit",WrittenBy="TV",Total="$650.00";
            internal Dictionary<int,string[]> Lines=Standard();
            internal int NameStyle;
        }
        static Dictionary<int,string[]> Standard() {
            return new Dictionary<int,string[]> {
                {1,new[]{"W43116","WINRUN 265/70R16 112T MAXCLAW A/T","4","140.00"}},
                {2,new[]{"WA","WHEEL ALIGNMENT FRONT","1","89.00"}},
                // M codes are COSTAR's note lines (M FB: its fitting and balancing words).
                {3,new[]{"M FB","FITTING & BALANCING","",""}},
                {6,new[]{"DET","DETAILS","",""}},
                {7,new[]{"M","MAKE/MODEL: TOYOTA HILUX","",""}},
                {8,new[]{"M","REGO NO: ABC123","",""}},
                {9,new[]{"M ODO","ODOMETER: 40631","",""}},
                {10,new[]{"M","CALL BEFORE FITTING","",""}}
            };
        }
        static List<ControlInfo> Ro(Fixture f) {
            var s=new List<ControlInfo>();
            s.Add(Mk(1,100,ST,20,60,150,18,"ACCOUNT# / NAME"));
            s.Add(Mk(2,100,ED,20,79,60,20,f.Account));var name=Mk(3,100,ED,85,79,250,20,f.Name);name.Style=f.NameStyle;s.Add(name);
            s.Add(Mk(4,100,ED,20,100,315,20,f.Address));s.Add(Mk(5,100,ED,20,121,315,20,f.Address2));
            s.Add(Mk(6,100,ED,20,142,200,20,f.Suburb));s.Add(Mk(7,100,ED,225,142,40,20,f.State));s.Add(Mk(8,100,ED,270,142,65,20,f.Postcode));
            s.Add(Mk(9,100,ST,20,170,80,18,"MOBILE PH"));s.Add(Mk(10,100,ED,20,189,120,20,f.Phone));
            s.Add(Mk(11,100,ST,150,170,60,18,"EMAIL"));s.Add(Mk(12,100,ED,150,189,185,20,f.Email));
            s.Add(Mk(13,100,ST,350,170,40,18,"PO#"));s.Add(Mk(14,100,ED,350,189,100,20,f.Po));
            s.Add(Mk(15,100,ST,20,220,70,18,"COMMENT"));s.Add(Mk(16,100,ED,95,220,300,20,f.Comment));
            s.Add(Mk(30,150,ST,460,60,60,18,"TIME IN"));s.Add(Mk(31,150,CB,460,79,90,22,""));s.Add(Mk(32,31,ED,463,81,70,18,f.TimeIn));
            s.Add(Mk(33,150,ST,560,60,60,18,"DATE IN"));
            if(f.DateKind=="edit") s.Add(Mk(34,150,ED,560,79,90,20,f.DateIn));
            else if(f.DateKind=="combo") { s.Add(Mk(34,150,CB,560,79,90,22,""));s.Add(Mk(35,34,ED,563,81,70,18,f.DateIn)); }
            else if(f.DateKind=="picker") s.Add(Mk(34,150,DT,560,79,90,20,f.DateIn));
            s.Add(Mk(36,150,ST,660,60,80,18,"WRITTEN BY"));s.Add(Mk(37,150,ED,660,79,60,20,f.WrittenBy));
            s.Add(Mk(40,200,ST,500,170,70,18,"SHIP VIA"));s.Add(Mk(41,200,ED,500,189,100,20,f.ShipVia));
            s.Add(Mk(20,300,ST,69,341,79,27,"ITEM"));s.Add(Mk(21,300,ST,223,341,87,27,"DESCRIPTION"));s.Add(Mk(22,300,ST,728,341,45,27,"QTY OR HRS"));s.Add(Mk(23,300,ST,769,341,56,26,"LIST"));s.Add(Mk(24,300,ST,873,341,56,27,"NET"));
            for(int i=0;i<25;i++) {
                int y=369+19*i;long panel=500+i,b=1000+10*i;string[] v;if(!f.Lines.TryGetValue(i+1,out v))v=new[]{"","","",""};
                s.Add(Mk(panel,300,WN,37,y,1010,20,""));
                s.Add(Mk(b,panel,ED,72,y,155,20,v[0]));s.Add(Mk(b+1,panel,ED,225,y,480,20,v[1]));
                // A note line has no quantity or price boxes.
                if(RoRead.Kind(v[0])=="item"&&v[0].Length>0) { s.Add(Mk(b+2,panel,ED,728,y,40,20,v[2]));s.Add(Mk(b+3,panel,ED,769,y,56,20,v[3]));s.Add(Mk(b+4,panel,ED,873,y,56,20,v[3])); }
            }
            s.Add(Mk(50,400,ST,900,860,60,18,"TAX IN"));s.Add(Mk(51,400,ST,900,878,80,18,f.Total));
            return s;
        }
        static RoSnapshot Read(Fixture f,string waiting="no") { return RoRead.Build(Ro(f),"07497644",waiting,"",null); }
        static RoEdit Edit(RoSnapshot snap) { return new RoEdit {schema=RoEdit.Schema,doc=snap.doc,baseSig=snap.sig}; }
        static RoAsk Ask(string kind,string doc=null,RoEdit edit=null) { return new RoAsk {id="RO-"+Guid.NewGuid().ToString(),kind=kind,doc=doc,edit=edit}; }
        // print: a 2.6.2 helper always says it prints Job Cards.
        static RoHello Hello(RoReport report=null,bool accepting=true,bool available=true,string working=null,int sequence=1000,bool print=true) {
            return new RoHello {workerId="test-worker",accepting=accepting,available=available,report=report,working=working,sequence=sequence,print=print};
        }
        static RoReport Report(RoReply r,string status,int sequence,RoSnapshot snapshot=null,RoList list=null) {
            return new RoReport {id=r.task.id,lease=r.task.lease,status=status,message=status,progress="",sequence=sequence,snapshot=snapshot,list=list};
        }
        static HttpInput Request(string method,string path,string token,string origin=null,object body=null) {
            var r=new HttpInput {method=method,path=path,body=body==null?"":Wire.Json(body),headers=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase)};
            if(token!=null)r.headers["authorization"]="Bearer "+token;
            if(origin!=null)r.headers["origin"]=origin;
            if(body!=null)r.headers["content-type"]="application/json";
            return r;
        }
        static T Body<T>(HttpOutput o){return Wire.Read<T>(Encoding.UTF8.GetString(o.bytes));}
        // A made-up COSTAR Work-in-Progress list (2.6.1): rows of cells answering through the same
        // accessibility interface as COSTAR's grid, a heading row, the active row listed a second time, rows
        // with a place only while in view (from place Top), and a wheel moving PerNotch rows a notch: at once,
        // one queued notch for each accessibility call (Queue "call"), one every 12 ms on its own (Queue
        // "time"), or BurstLen at a time with PauseMs between (Queue "burst"), as COSTAR or the remote desktop
        // might pass them on. PastEnd: the list scrolls on past its last row (a grid's "scroll to last item")
        // instead of stopping with it at the bottom. Rows are kept by place: the row at place p is order[p],
        // the same until Reorder (COSTAR sorting its list again); objects made before a Reorder (and with
        // StaleOld, before a wheel turn) keep answering as things were when they were made.
        sealed class FakeWip : IDisposable {
            internal int Rows=130,View=28,Top=0,PerNotch=3,Active=-1,Wheels,Clicks,WrongFrom=-1,LastClickRow=-1,BurstLen=4,PauseMs=0,FlakyEvery=0,Roots,HeadRows=1;
            internal const int RowH=20;
            internal Native.Rect Box=new Native.Rect {Left=100,Top=100,Right=1100,Bottom=100+RowH+28*RowH+20};
            internal string[] Columns={"Order Date","Name","Document #","Doc Total","Ship Via","Comment","Written By","Status","PO"};
            internal bool ActiveTwice=true,SelectScrolls,Focused,FocusOnClick=true,WrongChild,RemakeOnWheel,OffscreenPlaced,NoHeading,StaleOld,DupOnlyPlaced,PastEnd,ReorderOnPastClick,Reordered,DocAtTells=true;
            // 2.6.5: the keyboard given to the list directly (KeyboardGiven: how often; TakesKeyboard: it stays
            // there); SelectIgnored: a selection through accessibility does nothing; AlsoSelected: another row
            // that stays selected whatever is chosen (-1: none).
            internal bool TakesKeyboard=true,SelectIgnored;internal int KeyboardGiven,AlsoSelected=-1;
            // 2.6.5 RealStates: selected and active apart, as COSTAR's list shows them (the maps of 28 Oct): Active
            // is the selected row (a click, or a selection through accessibility), Current the active row (the one
            // Enter opens: a click, or its "Activate"). Only the active row is marked focused, and only while the
            // list has the keyboard (NoFocusMark: never); every other row offers "Activate", the active one nothing
            // (NoActions: no row offers anything). ActivateIgnored: "Activate" does nothing. ActivateGate: the
            // last look before "Activate" (null: go). SelectActivates: a selection through accessibility makes the
            // row the active one too; ActivateThrowsWhenActive: "Activate" on the active row fails (it offers none).
            internal bool RealStates,NoFocusMark,NoActions,ActivateIgnored,SelectActivates,ActivateThrowsWhenActive;internal int Current=-1,Activations;internal Func<string> ActivateGate;
            internal string Queue="";
            internal int Generation;
            readonly object gate=new object();int queued,sinceBurst,calls;long pauseUntil;System.Threading.Timer timer;int[] order;
            readonly System.Diagnostics.Stopwatch clock=System.Diagnostics.Stopwatch.StartNew();
            readonly Dictionary<int,int> topAt=new Dictionary<int,int>();
            readonly Dictionary<int,int[]> orderAt=new Dictionary<int,int[]>();
            internal string Doc(int i) { return "0910"+(1000+i).ToString(CultureInfo.InvariantCulture); }
            internal string Value(int row,int col) {
                switch(Columns[col]) {
                    case "Document #": return Doc(row);
                    case "Order Date": return "27/10/2026";
                    case "Name": return "TEST CUSTOMER "+row.ToString(CultureInfo.InvariantCulture);
                    case "Doc Total": return "$"+(100+row).ToString(CultureInfo.InvariantCulture)+".00";
                    case "PO": return row%2==0?"TTW"+(1730000+row).ToString(CultureInfo.InvariantCulture):"";
                    default: return "";
                }
            }
            internal int Pending { get { lock(gate) return Math.Abs(queued); } }
            int TopNow { get { lock(gate) return Top; } }
            int MaxTop { get { return Math.Max(0,PastEnd?Rows-1:Rows-View); } }
            int[] OrderNow { get { lock(gate) { if(order==null) order=Enumerable.Range(0,Rows).ToArray();return order; } } }
            // The row at place `pos` as objects made at generation `gen` see it.
            internal int RowOf(int pos,int gen) { lock(gate) { int[] o;if(gen==Generation||!orderAt.TryGetValue(gen,out o)) o=OrderNow;return pos>=0&&pos<o.Length?o[pos]:-1; } }
            internal int PlaceOf(int row) { return Array.IndexOf(OrderNow,row); }
            internal bool Shown(int pos,int top) { return pos>=top&&pos<top+View&&pos<Rows; }
            // Rows show below the column headings (HeadRows rows tall).
            internal int RowTop(int pos,int top) { return Box.Top+HeadRows*RowH+(pos-top)*RowH; }
            void Move(int notches) { lock(gate) { Top=Math.Max(0,Math.Min(MaxTop,Top-notches*PerNotch)); } }
            // One queued notch goes through (Queue "call": on every accessibility call).
            internal void Pump() { lock(gate) { if(queued==0) return;int n=queued>0?1:-1;queued-=n;Move(n); } }
            void Burst() { lock(gate) { long now=clock.ElapsedMilliseconds;if(now<pauseUntil||queued==0) return;int n=queued>0?1:-1;queued-=n;Move(n);if(++sinceBurst>=BurstLen) { sinceBurst=0;pauseUntil=now+PauseMs; } } }
            // Every notch still on its way goes through: as COSTAR does before a click that came after them.
            internal void Drain() { lock(gate) { while(queued!=0) { int n=queued>0?1:-1;queued-=n;Move(n); } } }
            internal void Wheel(int notches) {
                Wheels++;
                if(RemakeOnWheel||StaleOld) NewGeneration();
                if(Queue=="") { Move(notches);return; }
                lock(gate) queued+=notches;
                if(timer==null&&Queue=="time") timer=new System.Threading.Timer(delegate { Pump(); },null,12,12);
                if(timer==null&&Queue=="burst") timer=new System.Threading.Timer(delegate { Burst(); },null,12,12);
            }
            void NewGeneration() { lock(gate) { topAt[Generation]=Top;orderAt[Generation]=OrderNow;Generation++; } }
            // COSTAR sorts its list again: every row one place up, the first one last.
            internal void Reorder() {
                NewGeneration();
                lock(gate) { var o=OrderNow;var n=new int[o.Length];for(int p=0;p<o.Length;p++) n[p]=o[(p+1)%o.Length];order=n;Reordered=true; }
            }
            internal int TopOf(int gen) { lock(gate) { int t;return gen!=Generation&&StaleOld&&topAt.TryGetValue(gen,out t)?t:Top; } }
            // The row a click at p lands on now (-1: none).
            internal int RowAt(Native.Point p) { int top=TopNow;var o=OrderNow;for(int i=0;i<o.Length;i++) if(Shown(i,top)&&p.Y>=RowTop(i,top)&&p.Y<RowTop(i,top)+RowH) return o[i];return -1; }
            internal void Select(int row) { Active=row;int pos=PlaceOf(row);if(SelectScrolls&&pos>=0&&!Shown(pos,TopNow)) lock(gate) Top=Math.Max(0,Math.Min(MaxTop,pos-View/2)); }
            // FlakyEvery: one cell value or place in that many can't be read (accessibility busy).
            internal bool Flaky() { if(FlakyEvery<=0) return false;lock(gate) return ++calls%FlakyEvery==0; }
            internal Accessibility.IAccessible Root() { Roots++;return new FakeAcc(this,"client",-1,-1,Generation,false); }
            public void Dispose() { var t=timer;timer=null;if(t!=null) t.Dispose(); }
        }
        sealed class FakeAcc : Accessibility.IAccessible {
            // pos: a row's or cell's place in the list (FakeWip.RowOf gives the row there).
            readonly FakeWip w;readonly string kind;readonly int pos,col,gen;readonly bool dup;int lastAsked;
            internal FakeAcc(FakeWip w,string kind,int pos,int col,int gen,bool dup) { this.w=w;this.kind=kind;this.pos=pos;this.col=col;this.gen=gen;this.dup=dup; }
            // Objects from before the rows were made again: they fail (RemakeOnWheel), or answer with the
            // places they had (StaleOld).
            bool Dead { get { if(w.Queue=="call") w.Pump();return gen!=w.Generation&&w.RemakeOnWheel&&(kind=="row"||kind=="cell"); } }
            int Row { get { return w.RowOf(pos,gen); } }
            List<object> Kids() {
                var k=new List<object>();
                if(kind=="client") k.Add(new FakeAcc(w,"table",-1,-1,gen,false));
                else if(kind=="table") {
                    if(!w.NoHeading) k.Add(new FakeAcc(w,"heading",-1,-1,w.Generation,false));
                    for(int i=0;i<w.Rows;i++) k.Add(new FakeAcc(w,"row",i,-1,w.Generation,false));
                    if(w.ActiveTwice&&w.Active>=0) { int at=w.PlaceOf(w.Active);if(at>=0) k.Add(new FakeAcc(w,"row",at,-1,w.Generation,true)); }
                } else if(kind=="heading") { for(int c=0;c<w.Columns.Length;c++) k.Add(new FakeAcc(w,"header",-1,c,gen,false)); }
                else if(kind=="row") { for(int c=0;c<w.Columns.Length;c++) k.Add(new FakeAcc(w,"cell",pos,c,gen,dup)); }
                return k;
            }
            object Accessibility.IAccessible.accParent { get { return null; } }
            int Accessibility.IAccessible.accChildCount { get { var d=Dead;return Kids().Count; } }
            object Accessibility.IAccessible.get_accChild(object varChild) {
                if(Dead) throw new InvalidOperationException("gone");
                int i=Convert.ToInt32(varChild,CultureInfo.InvariantCulture);var k=Kids();
                // WrongChild (from place WrongFrom on): a cell asked for on its own (not in a 1, 2, 3 ... walk) is its neighbour.
                bool walk=i==lastAsked+1;lastAsked=i;
                if(i<1||i>k.Count) return null;
                if(kind=="row"&&w.WrongChild&&pos>=w.WrongFrom&&!walk) return k[i%k.Count];
                return k[i-1];
            }
            string Accessibility.IAccessible.get_accName(object varChild) { return kind=="cell"||kind=="header"?w.Columns[col]:kind=="row"?"Row "+pos.ToString(CultureInfo.InvariantCulture):""; }
            string Accessibility.IAccessible.get_accValue(object varChild) {
                if(Dead) throw new InvalidOperationException("gone");
                if(kind!="cell") return null;
                if(w.Flaky()) throw new InvalidOperationException("busy");
                return w.Value(Row,col);
            }
            string Accessibility.IAccessible.get_accDescription(object varChild) { return ""; }
            object Accessibility.IAccessible.get_accRole(object varChild) { return kind=="client"?10:kind=="table"?24:kind=="heading"||kind=="row"?28:kind=="header"?25:29; }
            object Accessibility.IAccessible.get_accState(object varChild) {
                if(w.RealStates) { if(kind!="row") return 0;int r=Row;return (r==w.Active||r==w.AlsoSelected?0x2:0)|(r==w.Current&&w.Focused&&!w.NoFocusMark?0x4:0); }
                return kind=="row"&&Row==w.Active?0x6:kind=="row"&&Row==w.AlsoSelected?0x2:0;
            }
            string Accessibility.IAccessible.get_accHelp(object varChild) { return ""; }
            int Accessibility.IAccessible.get_accHelpTopic(out string pszHelpFile,object varChild) { pszHelpFile="";return 0; }
            string Accessibility.IAccessible.get_accKeyboardShortcut(object varChild) { return ""; }
            object Accessibility.IAccessible.accFocus { get { return null; } }
            object Accessibility.IAccessible.accSelection { get { return null; } }
            string Accessibility.IAccessible.get_accDefaultAction(object varChild) { return w.RealStates&&!w.NoActions&&kind=="row"&&Row!=w.Current?"Activate":""; }
            void Accessibility.IAccessible.accSelect(int flagsSelect,object varChild) { if(kind=="row"&&!w.SelectIgnored) { w.Select(Row);if(w.RealStates&&w.SelectActivates) w.Current=Row; } }
            void Accessibility.IAccessible.accLocation(out int pxLeft,out int pyTop,out int pcxWidth,out int pcyHeight,object varChild) {
                pxLeft=0;pyTop=0;pcxWidth=0;pcyHeight=0;
                if(Dead) throw new InvalidOperationException("gone");
                if(kind=="heading") { pxLeft=w.Box.Left+2;pyTop=w.Box.Top;pcxWidth=900;pcyHeight=w.HeadRows*FakeWip.RowH;return; }
                if(kind!="cell"&&kind!="row") return;
                if(w.Flaky()) throw new InvalidOperationException("busy");
                // DupOnlyPlaced: the active row has a place only through its second listing.
                if(w.DupOnlyPlaced&&Row==w.Active&&!dup) return;
                int top=w.TopOf(gen);
                // Rows out of view have no place, or (OffscreenPlaced) one above or below the list.
                if(w.Shown(pos,top)||w.OffscreenPlaced) { pxLeft=w.Box.Left+2+(col<0?0:col*100);pyTop=w.RowTop(pos,top);pcxWidth=col<0?900:100;pcyHeight=FakeWip.RowH; }
            }
            object Accessibility.IAccessible.accNavigate(int navDir,object varStart) { return null; }
            object Accessibility.IAccessible.accHitTest(int xLeft,int yTop) { return null; }
            void Accessibility.IAccessible.accDoDefaultAction(object varChild) {
                if(Dead) throw new InvalidOperationException("gone");
                if(kind!="row") return;
                if(w.ActivateThrowsWhenActive&&Row==w.Current) throw new InvalidOperationException("no default action");
                w.Activations++;if(w.RealStates&&!w.ActivateIgnored) w.Current=Row;
            }
            void Accessibility.IAccessible.set_accName(object varChild,string pszName) { }
            void Accessibility.IAccessible.set_accValue(object varChild,string pszValue) { }
        }
        // 2.6.4: a made-up COSTAR window as Windows' accessibility shows it. Every box is a window with Windows'
        // own frame parts (title, menu and scroll bars, a size grip) that don't show; a toolbar with its buttons;
        // a tab page behind another. Asked: state questions; OtherAsked: any other question; Changed: anything
        // that would change COSTAR (a press, a selection, a new name or value).
        sealed class FakeNode : Accessibility.IAccessible {
            internal readonly int Role,State;internal readonly string Name,Action;internal readonly List<FakeNode> Kids=new List<FakeNode>();
            internal int Asked,OtherAsked,Changed;
            // 2.6.5: a press that COSTAR comes back from only once Block is set (the window it opened closed), or that fails.
            internal System.Threading.ManualResetEvent Block;internal Exception Throws;internal int Pressed;
            internal FakeNode(int role,string name,int state,string action) { Role=role;Name=name;State=state;Action=action; }
            internal FakeNode Add(params FakeNode[] kids) { Kids.AddRange(kids);return this; }
            // 2.9.0: where it is (else 110,120 20x20, as before).
            internal int[] At;internal bool Unplaced;
            internal FakeNode Place(int x,int y,int w,int h) { At=new[]{x,y,w,h};return this; }
            internal IEnumerable<FakeNode> All() { yield return this;foreach(var k in Kids) foreach(var n in k.All()) yield return n; }
            internal IEnumerable<FakeNode> Under() { foreach(var k in Kids) foreach(var n in k.All()) yield return n; }
            const int H=0x8000;
            static FakeNode Bar() { return new FakeNode(3,"Vertical",H,"").Add(new FakeNode(43,"Line up",H,"Press"),new FakeNode(43,"Page up",H,"Press"),new FakeNode(39,"Position",H,""),new FakeNode(43,"Page down",H,"Press"),new FakeNode(43,"Line down",H,"Press")); }
            // A COSTAR box: the window around it with Windows' frame parts, none showing.
            internal static FakeNode Box(int role,string name,string action) {
                return new FakeNode(9,name,0,"").Add(new FakeNode(1,"",H,"").Add(new FakeNode(43,"Minimize",H,"Press"),new FakeNode(43,"Close",H,"Press")),
                    new FakeNode(2,"Application",H,""),new FakeNode(role,name,0,action),Bar(),Bar(),new FakeNode(4,"",H,""));
            }
            object Accessibility.IAccessible.accParent { get { return null; } }
            int Accessibility.IAccessible.accChildCount { get { OtherAsked++;return Kids.Count; } }
            object Accessibility.IAccessible.get_accChild(object varChild) { OtherAsked++;int i=Convert.ToInt32(varChild,CultureInfo.InvariantCulture);return i>=1&&i<=Kids.Count?Kids[i-1]:null; }
            string Accessibility.IAccessible.get_accName(object varChild) { OtherAsked++;return Name; }
            string Accessibility.IAccessible.get_accValue(object varChild) { OtherAsked++;return Role==42?"TEST CUSTOMER":null; }
            string Accessibility.IAccessible.get_accDescription(object varChild) { OtherAsked++;return ""; }
            object Accessibility.IAccessible.get_accRole(object varChild) { OtherAsked++;return Role; }
            object Accessibility.IAccessible.get_accState(object varChild) { Asked++;return State; }
            string Accessibility.IAccessible.get_accHelp(object varChild) { OtherAsked++;return ""; }
            int Accessibility.IAccessible.get_accHelpTopic(out string pszHelpFile,object varChild) { OtherAsked++;pszHelpFile="";return 0; }
            string Accessibility.IAccessible.get_accKeyboardShortcut(object varChild) { OtherAsked++;return Name=="Print"?"Alt+p":""; }
            object Accessibility.IAccessible.accFocus { get { OtherAsked++;return null; } }
            object Accessibility.IAccessible.accSelection { get { OtherAsked++;return null; } }
            string Accessibility.IAccessible.get_accDefaultAction(object varChild) { OtherAsked++;return Action; }
            void Accessibility.IAccessible.accSelect(int flagsSelect,object varChild) { Changed++; }
            void Accessibility.IAccessible.accLocation(out int pxLeft,out int pyTop,out int pcxWidth,out int pcyHeight,object varChild) {
                OtherAsked++;
                if(Unplaced) throw new InvalidOperationException("made up: no place");
                if(At!=null) { pxLeft=At[0];pyTop=At[1];pcxWidth=At[2];pcyHeight=At[3]; } else { pxLeft=110;pyTop=120;pcxWidth=20;pcyHeight=20; }
            }
            object Accessibility.IAccessible.accNavigate(int navDir,object varStart) { OtherAsked++;return null; }
            object Accessibility.IAccessible.accHitTest(int xLeft,int yTop) { OtherAsked++;return null; }
            void Accessibility.IAccessible.accDoDefaultAction(object varChild) {
                if(Throws!=null) throw Throws;
                System.Threading.Interlocked.Increment(ref Pressed);Changed++;
                if(Block!=null) Block.WaitOne(10000);
            }
            void Accessibility.IAccessible.set_accName(object varChild,string pszName) { Changed++; }
            void Accessibility.IAccessible.set_accValue(object varChild,string pszValue) { Changed++; }
        }
        sealed class FakeScreen : IWipScreen {
            readonly FakeWip w;internal readonly List<string> Said=new List<string>();
            internal FakeScreen(FakeWip w) { this.w=w; }
            public Native.Rect Box() { return w.Box; }
            public bool ListAt(Native.Point p) { return p.X>=w.Box.Left&&p.X<w.Box.Right&&p.Y>=w.Box.Top&&p.Y<w.Box.Bottom; }
            public bool ListHasKeyboard() { return w.Focused; }
            public string KeyboardAt() { return w.Focused?"the list":"a made-up box"; }
            public void Ready() { }
            public void Click(Native.Point p) { Check(ListAt(p),"A click outside the list.");w.Clicks++;int r=w.RowAt(p);w.LastClickRow=r;if(r>=0) { w.Select(r);w.Current=r; }if(w.FocusOnClick) w.Focused=true; }
            // Called once the row is in view, before the last looks: ReorderOnPastClick sorts the list again there.
            public void PastClick() { if(w.ReorderOnPastClick&&!w.Reordered) w.Reorder(); }
            public void Wheel(Native.Point p,int notches) { Check(ListAt(p)&&w.Focused,"The wheel was turned while the list didn't have the keyboard.");w.Wheel(notches); }
            public void GiveKeyboard() { w.KeyboardGiven++;if(w.TakesKeyboard) w.Focused=true; }
            // As COSTAR's: the row looked up afresh, its "Activate" pressed on a thread of its own after the last look.
            public bool Activate(WipScan scan,string doc) {
                var act=Direct.Act(delegate(out object child,out string why) { child=null;return scan.FreshTargetRow(out why); },w.ActivateGate);
                return RoWip.Activated(act,Direct.Went(act,5000,400),null,doc);
            }
            public void Say(string words) { Said.Add(words); }
            public WipScan Scan(string doc) { return WipScan.From(w.Root,w.Box,doc,false); }
            // What accessibility finds at the point (before any notch still on its way): the number of the row
            // there, or nothing it can tell (DocAtTells off).
            public string DocAt(Native.Point p,WipScan scan) { if(!w.DocAtTells) return null;int r=w.RowAt(p);return r<0?null:w.Doc(r); }
        }
        // Opens row `target` of a made-up list as the helper does (read, bring into view, aim, what
        // accessibility finds at the point) and checks the point it would double-click: that row's, with no
        // wheel notch still on its way.
        static RoOpenTimes FakeOpen(FakeWip w,int target,out bool oneCell) {
            var screen=new FakeScreen(w);var times=new RoOpenTimes();WipScan scan=null;
            try {
                scan=screen.Scan(w.Doc(target));times.Took(scan);
                Check(scan.Target>=0&&scan.Lines.Count==w.Rows,"The made-up list must be read with one line a row ("+scan.Lines.Count+").");
                var listed=scan.TargetRow();
                Check(listed.doc==w.Doc(target)&&listed.name==w.Value(target,1)&&listed.total==w.Value(target,3)&&(listed.po??"")==w.Value(target,8),"The wanted row's values: "+listed.name+" "+listed.total+" "+listed.po);
                var point=RoWip.Aim(screen,ref scan,w.Doc(target),times,false,null);
                Check(w.Pending==0,"A wheel notch was still on its way when the row was aimed at ("+w.Pending+").");
                RoWip.CheckPoint(screen,point,scan,w.Doc(target),times);
                Check(w.RowAt(point)==target,"The double click would land on row "+w.RowAt(point)+", not "+target+".");
                oneCell=scan.OneCell;
                return times;
            } finally { if(scan!=null) scan.Dispose(); }
        }
        // One open of row `target` that may stop (nothing opened: what it said) but must never aim at another
        // row. COSTAR works through every notch still on its way before a double click that comes after them,
        // so the click lands where the list is once they are all through.
        static string Attempt(FakeWip w,int target) {
            var screen=new FakeScreen(w);var times=new RoOpenTimes();WipScan scan=null;
            try {
                scan=screen.Scan(w.Doc(target));
                if(scan.Target<0) return "stopped: not in the first read";
                var point=RoWip.Aim(screen,ref scan,w.Doc(target),times,false,null);
                RoWip.CheckPoint(screen,point,scan,w.Doc(target),times);
                w.Drain();int land=w.RowAt(point);
                return land==target?"ok":"WRONG: the double click lands on row "+land+" ("+times.How+", "+w.Wheels+" turns)";
            } catch(InvalidOperationException e) { return "stopped: "+e.Message; }
            finally { if(scan!=null) scan.Dispose(); }
        }
        sealed class OpenRun { internal string Name;internal Func<FakeWip> Make;internal int Target;internal bool MustGetThere; }
        // Opens that must get there (FakeOpen), side by side; then each one's own check (Then), or (Fails) the
        // words its stop must have.
        sealed class OpenCase { internal string Name,Fails;internal Func<FakeWip> Make;internal int Target;internal Action<FakeWip,RoOpenTimes,bool> Then; }
        static void RunOpens(List<OpenCase> cases) {
            var lists=new FakeWip[cases.Count];var times=new RoOpenTimes[cases.Count];var cells=new bool[cases.Count];var errors=new string[cases.Count];var threads=new List<Thread>();
            for(int i=0;i<cases.Count;i++) {
                int at=i;
                var th=new Thread(delegate() {
                    try { lists[at]=cases[at].Make();bool one;times[at]=FakeOpen(lists[at],cases[at].Target,out one);cells[at]=one; }
                    catch(Exception e) { errors[at]=e.GetType().Name+": "+e.Message; }
                    finally { if(lists[at]!=null) lists[at].Dispose(); }
                });
                th.IsBackground=true;th.Start();threads.Add(th);
            }
            foreach(var th in threads) Check(th.Join(120000),"An open of a made-up list didn't end within 2 minutes.");
            var failed=new List<string>();
            for(int i=0;i<cases.Count;i++) {
                var c=cases[i];
                try {
                    if(c.Fails!=null) Check(errors[i]!=null&&errors[i].StartsWith("InvalidOperationException: ",StringComparison.Ordinal)&&errors[i].Contains(c.Fails),"must stop, saying \""+c.Fails+"\" ("+(errors[i]??"it didn't stop")+").");
                    else Check(errors[i]==null,errors[i]);
                    if(c.Then!=null) c.Then(lists[i],times[i],cells[i]);
                } catch(InvalidOperationException e) { failed.Add(c.Name+": "+e.Message); }
            }
            Check(failed.Count==0,String.Join(" | ",failed.ToArray()));
        }
        // Runs the opens side by side (each with its own list; the made-up wheel works on its own timer).
        static string[] RunAll(List<OpenRun> runs) {
            var results=new string[runs.Count];var threads=new List<Thread>();
            for(int i=0;i<runs.Count;i++) {
                int at=i;
                var th=new Thread(delegate() {
                    try { using(var w=runs[at].Make()) results[at]=Attempt(w,runs[at].Target); }
                    catch(Exception e) { results[at]="FAILED: "+e.GetType().Name+": "+e.Message; }
                });
                th.IsBackground=true;th.Start();threads.Add(th);
            }
            foreach(var th in threads) Check(th.Join(120000),"An open of a made-up list didn't end within 2 minutes.");
            return results;
        }
        // A made-up print form like COSTAR's of 27 Oct ("Print RepairOrder ..."): headings Print, Qty, eMail,
        // Add copy, Document, To and Show internal memos?; four rows (Job Card, (COPY) Invoice, Freight Label,
        // Delivery Docket), each a Print box, a quantity box, an eMail box, a + button, its name and a To
        // list; Show internal memos? on the Job Card's line; OK, Cancel and Back.
        sealed class PrintFixture {
            internal string JobCardName="Job Card",EmailHeading="eMail",OkText="OK",QtyHeading="Qty";internal bool ExtraJobCard,StrayEmail,NoTicks,NoQtyBox,NumberBox,QtyLabel;
            internal const long Memos=990,Ok=991,Cancel=992;
            readonly HashSet<long> ticks=new HashSet<long>();readonly List<long> order=new List<long>();
            internal long PrintBox(int row) { return 700+row; }
            internal long EmailBox(int row) { return 720+row; }
            internal long QtyBox(int row) { return 710+row; }
            // Index of a tick box in "Print x4, eMail x4" order, -1 for any other.
            internal int Index(long handle) { return order.IndexOf(handle); }
            internal bool IsTick(ControlInfo c) { return ticks.Contains(c.Handle); }
            const string CB="WindowsForms10.COMBOBOX.app.0.1",BT="WindowsForms10.BUTTON.app.0.1";
            internal List<ControlInfo> Controls() {
                var s=new List<ControlInfo>();ticks.Clear();order.Clear();
                s.Add(Mk(600,500,ST,33,76,26,15,"Print"));if(QtyHeading.Length>0) s.Add(Mk(601,500,ST,88,76,20,15,QtyHeading));
                if(EmailHeading.Length>0) s.Add(Mk(602,500,ST,129,76,34,15,EmailHeading));
                s.Add(Mk(603,500,ST,303,76,30,28,"Add copy"));s.Add(Mk(604,500,ST,491,76,64,15,"Document"));s.Add(Mk(605,500,ST,568,76,18,15,"To"));s.Add(Mk(606,500,ST,851,76,90,28,"Show internal memos?"));
                string[] names={JobCardName,"(COPY) Invoice","Freight Label","Delivery Docket"};
                int rows=ExtraJobCard?5:4;
                for(int i=0;i<rows;i++) {
                    int y=110+i*34;string name=i<4?names[i]:"Job Card";
                    s.Add(Mk(PrintBox(i),500,BT,38,y,13,13,""));s.Add(Mk(EmailBox(i),500,BT,139,y,13,13,""));
                    // The quantity: an edit box; a number box (its frame, its edit box and its arrows); or only a label.
                    if(QtyLabel) s.Add(Mk(QtyBox(i),500,ST,83,y-1,25,15,"1"));
                    else if(!NoQtyBox) s.Add(Mk(QtyBox(i),NumberBox?760+i:500,ED,NumberBox?85:83,y-3,NumberBox?18:25,20,"1"));
                    if(NumberBox) { s.Add(Mk(760+i,500,"WindowsForms10.Window.8.app.0.1",83,y-3,25,20,""));s.Add(Mk(770+i,760+i,"WindowsForms10.Window.8.app.0.1",101,y-3,7,20,"")); }
                    s.Add(Mk(730+i,500,BT,306,y-3,22,20,"+"));s.Add(Mk(740+i,500,ST,558-7*name.Length,y-1,7*name.Length,15,name));s.Add(Mk(750+i,500,CB,568,y-3,268,21,""));
                    if(!NoTicks) { ticks.Add(PrintBox(i));ticks.Add(EmailBox(i)); }
                }
                for(int i=0;i<4;i++) order.Add(PrintBox(i));for(int i=0;i<4;i++) order.Add(EmailBox(i));
                s.Add(Mk(Memos,500,BT,886,110,13,13,""));if(!NoTicks) ticks.Add(Memos);
                if(StrayEmail) { s.Add(Mk(799,500,BT,139,320,13,13,""));if(!NoTicks) ticks.Add(799); }
                s.Add(Mk(780,500,ST,12,240,140,16,"* Sent / Printed"));
                s.Add(Mk(Ok,500,BT,370,279,100,28,OkText));s.Add(Mk(Cancel,500,BT,708,279,100,28,"Cancel"));s.Add(Mk(993,500,BT,8,38,30,30,"Back"));
                return s;
            }
        }
        internal static void Cases(Action<string,Action> Case) {
            Case("Repair Orders: a Repair Order is read from its boxes and lines (DET and the car, what can't be changed, the fingerprint)",()=>{
                var f=new Fixture();var snap=Read(f);
                Check(snap.name=="TEST CUSTOMER"&&snap.phone=="0400000001"&&snap.suburb=="TESTVILLE"&&snap.comment=="WAITING FOR TYRES"&&snap.dateIn=="27/10/2026"&&snap.timeIn=="8:30 am"&&snap.writtenBy=="TV","Header boxes were not read.");
                Check(snap.counted&&snap.lines.Count==8&&String.Join(",",snap.lines.Select(l=>l.n.ToString(CultureInfo.InvariantCulture)).ToArray())=="1,2,3,6,7,8,9,10","Lines and their numbers were not read.");
                Check(String.Join(",",snap.lines.Select(l=>l.kind).ToArray())=="item,item,note,det,car,car,car,note","Line kinds: "+String.Join(",",snap.lines.Select(l=>l.kind).ToArray()));
                Check(snap.det&&snap.makeModel=="TOYOTA HILUX"&&snap.rego=="ABC123"&&snap.odometer=="40631","The car was not read from DET's notes.");
                Check(snap.lines[0].qty=="4"&&snap.lines[0].net=="140.00"&&snap.totalCents==65000,"Quantity, price or total.");
                Check(snap.customerWaiting=="no"&&!snap.cannot.ContainsKey("phone")&&!snap.cannot.ContainsKey("dateIn")&&!snap.cannot.ContainsKey("add")&&!snap.cannot.ContainsKey("shipVia"),"A cash Repair Order must be fully changeable: "+String.Join("; ",snap.cannot.Select(p=>p.Key+"="+p.Value).ToArray()));
                Check(RoEdit.IsSig(snap.sig)&&Read(new Fixture()).sig==snap.sig,"The fingerprint must be 16 hex digits and the same for the same Repair Order.");
                var g=new Fixture();g.TimeIn="9:00 am";g.WrittenBy="SA";Check(Read(g).sig==snap.sig,"Time In and Written By are not part of the fingerprint.");
                g=new Fixture();g.Lines[1]=new[]{"W43116","WINRUN 265/70R16 112T MAXCLAW A/T","2","140.00"};Check(Read(g).sig!=snap.sig,"A new quantity must change the fingerprint.");
                g=new Fixture();g.Comment="DONE";Check(Read(g).sig!=snap.sig,"A new comment must change the fingerprint.");
                Check(Read(new Fixture(),"yes").sig!=snap.sig,"Customer Waiting is part of the fingerprint.");
                g=new Fixture();g.Account="C10023";Check(Read(g).cannot["phone"].Contains("C10023"),"A Repair Order on an account must not take a phone change.");
                g=new Fixture();g.NameStyle=0x800;Check(Read(g).cannot["name"].Contains("locked"),"A read-only box must be marked.");
                g=new Fixture();g.DateKind="picker";Check(Read(g).cannot["dateIn"].Contains("calendar"),"A calendar box can't be typed into.");
                g=new Fixture();g.DateKind="combo";g.DateIn="07/10/2026";var combo=Read(g);Check(combo.dateIn=="07/10/2026"&&!combo.cannot.ContainsKey("dateIn"),"A drop-down date box must be read.");
                g=new Fixture();g.DateKind="none";Check(Read(g).cannot.ContainsKey("dateIn"),"No date box must be marked.");
                Check(Read(new Fixture(),"").cannot.ContainsKey("customerWaiting"),"An unreadable Customer Waiting must be marked.");
                g=new Fixture();g.Lines.Remove(6);g.Lines.Remove(7);g.Lines.Remove(8);g.Lines.Remove(9);
                var nodet=Read(g);Check(!nodet.det&&nodet.makeModel==""&&nodet.lines.All(l=>l.kind!="car"),"Without DET there is no car.");
                g=new Fixture();g.Lines[12]=new[]{"DET","DETAILS","",""};Check(Read(g).cannot.ContainsKey("car"),"Two DETs: the car can't be changed.");
            });
            Case("Repair Orders: the wanted row is scrolled to in a few wheel turns, every notch of a turn accounted for before the next, whatever a notch moves and wherever the list ends (2.6.1)",()=>{
                Check(WipScroll.Turn(100,0,200)==1&&WipScroll.Turn(100,3,200)==20&&WipScroll.Turn(10,3,200)==4&&WipScroll.Turn(1,3,200)==1,"Notches a turn: one until a notch is measured, then to the middle of the view, 20 at most.");
                Check(WipScroll.Turn(60,3,40)==13&&WipScroll.Turn(36,3,37)==12&&WipScroll.Turn(36,3,36)==11&&WipScroll.Turn(60,3,2)==1&&WipScroll.Turn(60,28,30)==1&&WipScroll.Turn(60,3,0)==1,"Turns stay a row short of the list's end (as seen: it may be a row out); one notch when not even that fits.");
                Check(WipScroll.Expect(1,0,200)==1&&WipScroll.Expect(20,3,200)==60&&WipScroll.Expect(1,3,2)==2,"Rows a turn must move before it counts as come through.");
                Check(WipScroll.Accounted(0,3,1,200)==3&&WipScroll.Accounted(0,200,1,200)==0&&WipScroll.Accounted(0,3,2,200)==-1,"The first notch measures a notch, unless it took the list to its end.");
                Check(WipScroll.Accounted(3,60,20,200)==3&&WipScroll.Accounted(3,57,20,200)==-1&&WipScroll.Accounted(3,63,20,200)==-1,"A turn must move exactly its notches: fewer (some still on the way) or more (an earlier one late) stops.");
                Check(WipScroll.Accounted(3,2,1,2)==3&&WipScroll.Accounted(3,3,1,2)==3&&WipScroll.Accounted(3,1,1,0)==3&&WipScroll.Accounted(3,4,1,2)==-1&&WipScroll.Accounted(3,0,1,2)==-1&&WipScroll.Accounted(3,40,14,40)==-1,"One notch comes through whole or not at all: any move of up to a notch's rows is all of it (the list may end sooner), more is not that notch.");
                // Made-up lists: n rows, v in view, a notch moving k rows (Windows' setting may not be what the
                // list does), the list stopping with its last row at the bottom or going on past it; every row,
                // from the top and from the end, with the open's own steps (turn, all of it through, look).
                int worst=0,usual=0;
                foreach(int n in new[]{1,2,30,130,260}) foreach(int v in new[]{5,28}) foreach(int k in new[]{1,3,5,v}) foreach(bool pastEnd in new[]{false,true}) foreach(bool fromEnd in new[]{false,true}) {
                    int maxTop=Math.Max(0,pastEnd?n-1:n-v);
                    for(int target=0;target<n;target++) {
                        int top=fromEnd?Math.Max(0,n-v):0,per=0,turns=0;string stop=null;
                        while(stop==null) {
                            int last=Math.Min(n-1,top+v-1);
                            if(target>=top&&target<=last) break;
                            if(turns>=WipScroll.MaxSteps) { stop="more than "+WipScroll.MaxSteps+" turns";break; }
                            int rows=(top+last)/2-target;bool up=rows>0;int room=up?top:n-1-last;
                            if(rows==0||room==0) { stop="nowhere to go";break; }
                            int notches=WipScroll.Turn(Math.Abs(rows),per,room),expect=WipScroll.Expect(notches,per,room);
                            int now=Math.Max(0,Math.Min(maxTop,top+(up?-1:1)*notches*k)),moved=Math.Abs(now-top);
                            turns++;
                            if(moved<expect) { stop="moved "+moved+" rows of "+expect;break; }
                            int next=WipScroll.Accounted(per,moved,notches,room);
                            if(next<0) { stop="scrolled "+moved+" rows for "+notches+" notches";break; }
                            per=next;top=now;
                        }
                        Check(stop==null,"Row "+target+" of "+n+" ("+v+" in view, "+k+" a notch"+(pastEnd?", past the end":"")+(fromEnd?", from the end":"")+"): "+stop+".");
                        worst=Math.Max(worst,turns);if(n<=130&&v==28&&k>=3) usual=Math.Max(usual,turns);
                    }
                }
                Check(usual<=4&&worst<=15,"Rows must be reached in at most 4 wheel turns in a list like Tempe's (took "+usual+"), 15 in any (took "+worst+").");
            });
            Case("Repair Orders: a made-up Work-in-Progress list is read one cell a row, its row brought into view and aimed at, with the wheel turned only while the list has the keyboard (2.6.1)",()=>{
                // The opens go side by side (each with its own made-up list), then each is checked.
                var opens=new List<OpenCase>();
                Action<string,int,Func<FakeWip>,Action<FakeWip,RoOpenTimes,bool>> open=(n,tg,make,then)=>opens.Add(new OpenCase {Name=n,Target=tg,Make=make,Then=then});
                open("in view",50,()=>new FakeWip {Top=40},(w,t,one)=>Check(t.How=="in view"&&w.Wheels==0&&w.Clicks==0&&one&&t.Hit=="this one"&&t.Scans==1,"A row in view is opened with nothing else touched ("+t.How+", "+t.Hit+", "+t.Scans+" reads)."));
                open("far down",120,()=>new FakeWip(),(w,t,one)=>Check(w.Clicks==1&&w.Wheels>=2&&w.Wheels<=4&&t.How.StartsWith("brought into view",StringComparison.Ordinal)&&t.Clicked,"A row far down: one click for the keyboard, a notch to measure, then a few turns ("+w.Clicks+" clicks, "+w.Wheels+" turns, "+t.How+")."));
                open("far up",3,()=>new FakeWip {Top=102,Focused=true},(w,t,one)=>Check(w.Clicks==0&&w.Wheels>=2&&w.Wheels<=4,"A row far up from the end, the list holding the keyboard: no click ("+w.Clicks+", "+w.Wheels+")."));
                open("selected",99,()=>new FakeWip {SelectScrolls=true},(w,t,one)=>Check(t.How=="in view once selected"&&w.Wheels==0&&w.Clicks==0,"A list that scrolls to the selected row needs no wheel ("+t.How+")."));
                open("one row a notch",129,()=>new FakeWip {PerNotch=1,Focused=true},(w,t,one)=>Check(w.Wheels<=8,"One row a notch: 20 rows a turn ("+w.Wheels+" turns)."));
                open("a page a notch",129,()=>new FakeWip {PerNotch=28,Focused=true},(w,t,one)=>Check(w.Wheels<=4,"A page a notch ("+w.Wheels+" turns)."));
                foreach(bool pastEnd in new[]{false,true}) foreach(int target in new[]{127,129}) {
                    bool past=pastEnd;
                    open("to the end",target,()=>new FakeWip {PastEnd=past,Focused=true},(w,t,one)=>Check(w.Wheels<=4,"To the end of a list that "+(past?"scrolls past its last row":"stops at it")+" ("+w.Wheels+" turns)."));
                }
                open("past the end, a page a notch",39,()=>new FakeWip {PastEnd=true,PerNotch=28,Focused=true,Rows=40},null);
                open("one notch a look",129,()=>new FakeWip {Queue="call",Focused=true},(w,t,one)=>Check(w.Wheels<=4,"Notches COSTAR works through while accessibility is asked: all through before the row is aimed at ("+w.Wheels+" turns)."));
                open("rows made again",110,()=>new FakeWip {RemakeOnWheel=true},(w,t,one)=>Check(t.Scans>=2&&t.How.StartsWith("brought into view",StringComparison.Ordinal),"Rows made again after a turn (old objects fail): the list is read again ("+t.Scans+" reads)."));
                open("old objects",110,()=>new FakeWip {StaleOld=true},(w,t,one)=>Check(t.Scans>=2,"Rows made again after a turn (old objects keep their old places): looked at with new objects ("+t.Scans+" reads)."));
                open("active row",60,()=>new FakeWip {Active=60,Top=50},null);
                open("active row placed twice",60,()=>new FakeWip {Active=60,Top=50,DupOnlyPlaced=true},(w,t,one)=>Check(t.How=="in view","The active row, placed only through its second listing, is in view at that place ("+t.How+")."));
                open("rows out of view placed",0,()=>new FakeWip {OffscreenPlaced=true,Top=100},(w,t,one)=>Check(w.Wheels>=2&&w.Wheels<=4&&w.Top==0,"Up to the first row, rows out of view placed above or below the list ("+w.Wheels+" turns)."));
                open("placed where the headings are",0,()=>new FakeWip {OffscreenPlaced=true,NoHeading=true,Top=100,Focused=true},(w,t,one)=>Check(w.Top==0,"Up to the first row when the row above the view is placed where the headings are, and the list doesn't say where they are ("+w.Wheels+" turns)."));
                open("placed over the scroll bar",129,()=>new FakeWip {OffscreenPlaced=true,Focused=true},(w,t,one)=>Check(w.Top==102,"Down to the last row with the row below the view placed over the scroll bar ("+w.Wheels+" turns)."));
                // Column headings two rows tall, rows out of view placed: the row just above the view is placed
                // behind the headings, so it isn't in view (a double click there would be on a heading).
                open("behind the headings",49,()=>new FakeWip {HeadRows=2,View=27,OffscreenPlaced=true,Top=50,Focused=true},(w,t,one)=>Check(w.Wheels>=1&&t.How.StartsWith("brought into view",StringComparison.Ordinal),"The row behind the headings is scrolled into view first ("+t.How+")."));
                open("wrong cell",20,()=>new FakeWip {WrongChild=true,WrongFrom=0,Top=10},(w,t,one)=>Check(!one,"A cell asked for on its own that isn't the Document # cell: every cell is read."));
                open("wrong cell further down",50,()=>new FakeWip {WrongChild=true,WrongFrom=20,Top=40},(w,t,one)=>Check(!one,"Cells that go wrong further down are caught too: every cell is read."));
                open("wrong cell, scrolled",120,()=>new FakeWip {WrongChild=true,WrongFrom=0,Focused=true},(w,t,one)=>Check(!one&&w.Wheels>=2,"Every cell read, and scrolled: the row looked at again the same way ("+w.Wheels+" turns)."));
                opens.Add(new OpenCase {Name="no keyboard",Target=120,Make=()=>new FakeWip {FocusOnClick=false},Fails="keyboard",
                    Then=(w,t,one)=>Check(w.Wheels==0&&w.Clicks==1,"No wheel turn without the keyboard: one click, then it stops ("+w.Clicks+").")});
                // COSTAR sorts its list again between the looks: objects from before still answer as things were.
                // The row at the wanted row's place is looked at with new objects, so the list is read again and
                // the double click goes to the right row (accessibility at the point telling nothing here).
                open("sorted again",50,()=>new FakeWip {Top=40,ReorderOnPastClick=true,DocAtTells=false},(w,t,one)=>Check(w.Reordered&&t.Scans==2&&t.Hit=="can't tell","The list sorted again just before the double click: read again, aimed at the row's new place ("+t.Scans+" reads, "+t.Hit+")."));
                open("sorted again after scrolling",120,()=>new FakeWip {Focused=true,ReorderOnPastClick=true,DocAtTells=false},(w,t,one)=>Check(w.Reordered,"The same after scrolling."));
                RunOpens(opens);
                using(var w=new FakeWip {HeadRows=2,View=27,OffscreenPlaced=true,Top=50}) {
                    var head=WipScan.From(w.Root,w.Box,w.Doc(49),false);
                    try { Check(head.HeadBottom==w.Box.Top+2*FakeWip.RowH&&head.First==50,"The headings' bottom is read; the row behind them isn't in view ("+head.HeadBottom+", first in view "+head.First+")."); } finally { head.Dispose(); }
                }
                // What accessibility finds at the point, just before the double click.
                using(var w=new FakeWip {Top=40}) {
                    var screen=new FakeScreen(w);var times=new RoOpenTimes();var scan=screen.Scan(w.Doc(50));
                    try {
                        var right=RoWip.Point(scan.TargetLine);var wrong=new Native.Point {X=right.X,Y=right.Y+FakeWip.RowH};
                        RoWip.CheckPoint(screen,right,scan,w.Doc(50),times);Check(times.Hit=="this one","The wanted row at the point: "+times.Hit);
                        Reject(()=>RoWip.CheckPoint(screen,wrong,scan,w.Doc(50),times),"Another Repair Order at the point must stop the open.","Repair Order "+w.Doc(51)+" under the point");
                        Check(times.Hit=="another","Said in the day log ("+times.Hit+").");
                        w.DocAtTells=false;RoWip.CheckPoint(screen,wrong,scan,w.Doc(50),times);Check(times.Hit=="can't tell","Nothing told at the point: the looks before stand ("+times.Hit+").");
                    } finally { scan.Dispose(); }
                }
                using(var none=new FakeWip()) { var missing=WipScan.From(none.Root,none.Box,"09999999",false);try { Check(missing.Target<0&&missing.Lines.Count==130,"A document not in the list is not found."); } finally { missing.Dispose(); } }
                Check(WipSearch.Needed(true,false,null,null)&&WipSearch.Needed(false,false,true,TimeSpan.Zero),"Search when the list shows nothing or hasn't the Repair Order.");
                Check(WipSearch.Needed(false,true,false,TimeSpan.Zero),"Search when Order Check's recent copy doesn't have it (finished meanwhile?).");
                Check(!WipSearch.Needed(false,true,true,null),"No Search when Order Check's recent copy has it.");
                Check(!WipSearch.Needed(false,true,null,TimeSpan.FromMinutes(4))&&WipSearch.Needed(false,true,null,TimeSpan.FromMinutes(11))&&WipSearch.Needed(false,true,null,null),"Without a recent copy: Search unless one was pressed in the last 10 minutes.");
                var times2=new RoOpenTimes {ScanMs=640,Rows=130,Scans=1,OneCell=true,SearchMs=-1,How="brought into view with 3 wheel turns",RevealMs=420,Wheels=3,Notches=34,WindowMs=1800,TotalMs=3100};
                Check(times2.ToString()=="list read 0.6 s (130 rows, one cell each), no Search, row brought into view with 3 wheel turns 0.4 s (34 notches), COSTAR opened it in 1.8 s, 3.1 s in all","The day log line: "+times2);
                times2.Hit="this one";times2.Clicked=true;
                Check(times2.ToString().Contains("(34 notches, one click to give the list the wheel), at the point: this one, COSTAR opened it"),"The day log line with the click and the point: "+times2);
            });
            Case("Repair Orders: notches COSTAR works through late (one a look, on a timer, in bursts with pauses), rows made again, a list sorted again, reads that fail: an open may stop, but never aims at another row (2.6.1)",()=>{
                var runs=new List<OpenRun>();
                Action<string,int,bool,Func<FakeWip>> add=(n,tg,must,make)=>runs.Add(new OpenRun {Name=n,Target=tg,MustGetThere=must,Make=make});
                foreach(var tc in new[]{new[]{0,129},new[]{102,5},new[]{0,77},new[]{60,10},new[]{102,30}}) {
                    int top=tc[0],target=tc[1];
                    add("one notch a look, row "+target+" from "+top,target,true,()=>new FakeWip {Queue="call",Top=top,Focused=true});
                    add("a notch every 12 ms, row "+target+" from "+top,target,false,()=>new FakeWip {Queue="time",Top=top,Focused=true});
                }
                foreach(int pause in new[]{150,600}) foreach(var tc in new[]{new[]{0,102},new[]{102,5},new[]{0,129}}) {
                    int top=tc[0],target=tc[1],p=pause;
                    add("4 notches then a "+p+" ms pause, row "+target+" from "+top,target,false,()=>new FakeWip {Queue="burst",BurstLen=4,PauseMs=p,Top=top,Focused=true});
                }
                add("bursts, past the list's end, row 129",129,false,()=>new FakeWip {Queue="burst",BurstLen=4,PauseMs=300,PastEnd=true,Focused=true});
                add("bursts, rows made again after each turn",110,false,()=>new FakeWip {Queue="burst",BurstLen=4,PauseMs=300,RemakeOnWheel=true,Focused=true});
                add("a notch every 12 ms, old objects keeping their places",110,false,()=>new FakeWip {Queue="time",StaleOld=true,Focused=true});
                add("bursts, the list sorted again before the last looks",120,false,()=>new FakeWip {Queue="burst",BurstLen=4,PauseMs=300,ReorderOnPastClick=true,DocAtTells=false,Focused=true});
                foreach(int every in new[]{97,401}) foreach(var tc in new[]{new[]{0,120},new[]{40,50}}) {
                    int top=tc[0],target=tc[1],e=every;
                    add("one read in "+e+" fails, row "+target+" from "+top,target,false,()=>new FakeWip {Queue="time",FlakyEvery=e,Top=top,Focused=true});
                }
                var results=RunAll(runs);
                var bad=new List<string>();int ok=0,timed=0,timedOk=0;
                for(int i=0;i<runs.Count;i++) {
                    string r=results[i]??"no result";
                    if(r=="ok") ok++;
                    if(!r.StartsWith("stopped: ",StringComparison.Ordinal)&&r!="ok") bad.Add(runs[i].Name+": "+r);
                    else if(runs[i].MustGetThere&&r!="ok") bad.Add(runs[i].Name+" must get there: "+r);
                    if(runs[i].Name.StartsWith("a notch every",StringComparison.Ordinal)||runs[i].Name.StartsWith("4 notches",StringComparison.Ordinal)) { timed++;if(r=="ok") timedOk++; }
                }
                Check(bad.Count==0,String.Join(" | ",bad.ToArray()));
                Check(timedOk*2>=timed,"Most opens with late notches must still get there ("+timedOk+" of "+timed+"): "+String.Join(" | ",Enumerable.Range(0,runs.Count).Where(i=>results[i]!="ok").Select(i=>runs[i].Name+": "+results[i]).ToArray()));
            });
            Case("Repair Orders: Date In is read in the box's own format and written back the same way",()=>{
                DateTime d;string f;
                Check(RoRead.ParseDate("07/10/2026",out d,out f)&&f=="dd/MM/yyyy"&&d==new DateTime(2026,10,7),"dd/MM/yyyy");
                Check(RoRead.ParseDate("7/10/2026",out d,out f)&&f=="d/MM/yyyy","d/MM/yyyy");
                Check(RoRead.ParseDate("27 Oct 2026",out d,out f)&&d==new DateTime(2026,10,27),"27 Oct 2026");
                Check(RoRead.ParseDate("27/10/2026 10:21 AM",out d,out f)&&d==new DateTime(2026,10,27),"A time after the date is ignored.");
                Check(!RoRead.ParseDate("next week",out d,out f)&&!RoRead.ParseDate("",out d,out f),"Words are not a date.");
                Check(RoRead.DateText("07/10/2026",new DateTime(2026,11,3))=="03/11/2026"&&RoRead.DateText("7/10/2026",new DateTime(2026,11,3))=="3/11/2026","The new date must follow the box's format.");
                Check(RoRead.DateText("",new DateTime(2026,11,3))=="03/11/2026","An empty box gets dd/MM/yyyy.");
                Check(RoRead.DateText("27/10/2026 10:21 AM",new DateTime(2026,11,3))=="03/11/2026 10:21 AM","A time after the date is kept.");
                Check(RoRead.DateKey("7/10/2026")=="2026-10-07"&&RoRead.DateKey("07/10/2026")=="2026-10-07","The date key.");
            });
            Case("Repair Date (2.6.9, 29 Oct 11:34: \"box not found\" on a phone job): COSTAR's own date box under the label is found, read only, and its date read in COSTAR's formats",()=>{
                // The 28 Oct maps: Repair Date [389,108,95,15] over a COSTAR panel [389,123,95,21] (no edit box), Auth Date
                // and its panel lower down, Invoice Date in a panel of its own; all in one panel [389,107,95,224].
                Func<List<ControlInfo>> layout=()=>new List<ControlInfo>{
                    Mk(10,1,WN,389,107,95,224,""),
                    Mk(11,10,ST,389,108,95,15,"Repair Date"),Mk(12,10,WN,389,123,95,21,""),
                    Mk(13,10,ST,389,144,95,15,"Auth Date"),Mk(14,10,WN,389,159,95,21,""),
                    Mk(15,10,WN,389,179,95,37,""),Mk(16,15,ST,389,180,95,15,"Invoice Date"),Mk(17,15,WN,389,195,95,21,"")};
                string kind;var s=layout();
                Check(RoSelectors.DateIn(s,out kind)==null,"No edit box, combo box or date picker there: DateIn finds none (as on the PC).");
                var panel=RoSelectors.DatePanel(s);Check(panel!=null&&panel.Handle==12,"The panel right under Repair Date: "+(panel==null?"none":panel.Handle.ToString()));
                var dateIn=layout();dateIn[1].Text="Date In";Check(RoSelectors.DatePanel(dateIn).Handle==12,"Date In (another COSTAR's words) the same.");
                var two=layout();two.Add(Mk(18,10,WN,390,124,95,21,""));Check(RoSelectors.DatePanel(two)==null,"Two boxes under the label: neither.");
                var hidden=layout();hidden[2].Visible=false;Check(RoSelectors.DatePanel(hidden)==null,"A hidden box: none.");
                var none=layout();none.RemoveAt(1);Check(RoSelectors.DatePanel(none)==null,"No Repair Date label: none.");
                var labels=layout();labels.Add(Mk(19,1,ST,600,108,95,15,"Repair Date"));Check(RoSelectors.DatePanel(labels)==null,"Two Repair Date labels: none.");
                var elsewhere=layout();elsewhere.Add(Mk(20,99,WN,389,123,95,21,""));elsewhere.Add(Mk(21,10,"WindowsForms10.BUTTON.app.0.1",390,123,40,21,""));
                Check(RoSelectors.DatePanel(elsewhere).Handle==12,"Only a COSTAR panel in the label's own panel counts (not another panel's box, not a button).");
                // Its date: COSTAR's ways of writing one (the Work-in-Progress list's \"29 Oct 2026\" first); within 20 years only.
                DateTime d,today=DateTime.Today;
                foreach(string f in new[]{"dd MMM yyyy","d MMM yyyy","dd/MM/yyyy","d/MM/yyyy","dd-MMM-yyyy","dd-MMM-yy","dd.MM.yyyy","yyyyMMdd","ddMMyyyy"})
                    Check(RoSelectors.CostarDate(today.ToString(f,CultureInfo.InvariantCulture),out d)&&d==today,f+" read: "+today.ToString(f,CultureInfo.InvariantCulture));
                Check(RoSelectors.CostarDate(" "+today.ToString("dd MMM yyyy",CultureInfo.InvariantCulture)+" ",out d)&&d==today,"Spaces round it.");
                var sept=new DateTime(today.Year,9,29);
                Check(RoSelectors.CostarDate("29 Sept "+today.Year,out d)&&d==sept&&RoSelectors.CostarDate("29-Sept-"+today.Year,out d)&&d==sept,"September written \"Sept\" (some Windows set for Australia).");
                Check(RoSelectors.CostarDate(today.AddDays(-3).ToString("dd MMM yyyy",CultureInfo.InvariantCulture),out d)&&d==today.AddDays(-3),"Another day is read as that day (then said: not today).");
                foreach(string bad in new[]{"01 Jan 1900","31 Dec 2099","[number]","","Repair Date","12345678","99/99/9999"})
                    Check(!RoSelectors.CostarDate(bad,out d)&&d==DateTime.MinValue,"Not a date: "+bad);
                Check(!RoSelectors.CostarDate(null,out d),"Nothing: not a date.");
            });
            Case("Repair Orders: the phone's change is checked before anything is typed",()=>{
                var snap=Read(new Fixture());
                var e=Edit(snap);e.header=new Dictionary<string,string>{{"comment","fitted, call customer"},{"email","New.Address@Example.com"}};
                e.shipVia="SHOP";e.dateIn=DateTime.Today.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture);e.customerWaiting="yes";e.rego="XYZ789";
                e.lines=new List<RoLineEdit>{new RoLineEdit{index=0,code="W43116",qty="2",price="135.50"},new RoLineEdit{index=7,code="M",text="call when done"},new RoLineEdit{index=1,code="WA",remove=true}};
                e.add=new List<RoNewLine>{new RoNewLine{kind="item",code="VALVE",qty="4",price="5"},new RoNewLine{kind="note",code="M",text="key in the box"}};
                e.ValidateShape();e.Validate(snap);
                Check(e.Summary().Contains("comment")&&e.Summary().Contains("2 line(s) added")&&!e.Summary().Contains("fitted"),"The summary names what changes, never the words.");
                Func<RoEdit> copy=()=>Wire.Copy(e);
                Action<Action<RoEdit>,string,string> bad=(change,message,contains)=>{var x=copy();change(x);Reject(()=>{x.ValidateShape();x.Validate(snap);},message,contains);};
                bad(x=>x.schema="tempe.ro-edit.v0","An old page's change must be refused.","older");
                bad(x=>x.doc="07 497","A bad Repair Order number.","number");
                bad(x=>x.baseSig="abc","A change without the fingerprint.",null);
                bad(x=>{x.header=null;x.shipVia=null;x.dateIn=null;x.customerWaiting=null;x.rego=null;x.lines=null;x.add=null;},"Nothing to change.","Nothing");
                bad(x=>x.header["account"]="C1","The account is not changed from the phone.","doesn't change");
                bad(x=>x.header["phone"]="12345","A short phone.","8 to 15");
                bad(x=>x.header["state"]="XX","A state.","state");
                bad(x=>x.header["postcode"]="123","A postcode.","4 digits");
                bad(x=>x.header["email"]="not-an-email","An email.","email");
                bad(x=>x.header["name"]="  ","An empty name.","name");
                bad(x=>x.header["comment"]="line\u0007bell","Control characters.",null);
                bad(x=>x.lines[0].qty="0","Quantity 0.","Quantities");
                bad(x=>x.lines[0].qty="1.234","Three decimals.","Quantities");
                bad(x=>x.lines[0].price="-1","A negative price.","Prices");
                bad(x=>x.lines[0].price="12.345","Three decimals in a price.","Prices");
                bad(x=>x.lines[2].qty="1","A line taken out and changed.","taken out");
                bad(x=>x.add[0].code="DET","DET is added through the car.","not DET");
                bad(x=>x.add[0].code="M","A bare M is a note.","not DET or M");
                bad(x=>x.add[1].text=" ","A note without words.","no words");
                bad(x=>{for(int i=0;i<RoEdit.MaxAdds;i++)x.add.Add(new RoNewLine{kind="note",code="M",text="x"});},"Too many new lines.","at most");
                bad(x=>x.dateIn=DateTime.Today.AddYears(3).ToString("yyyy-MM-dd",CultureInfo.InvariantCulture),"A date years away.","within a year");   // 2.9.3: not a fixed year (2030 was within 400 days from 27 Nov 2028)
                bad(x=>x.dateIn="27/10/2026","A date in the wrong form.","Date In");
                bad(x=>x.customerWaiting="maybe","Customer Waiting yes/no.","yes or no");
                bad(x=>x.rego="ABC!23","A rego with symbols.","rego");
                bad(x=>x.odometer="40k","An odometer with letters.","digits");
                bad(x=>x.shipVia="SHOP\u0001","Ship Via with a control character.","Ship Via");
                // Against the Repair Order as it is now.
                bad(x=>x.baseSig="0123456789ABCDEF","A Repair Order that changed after the phone read it.","CHANGED:");
                bad(x=>x.lines[0].code="W99999","A line that moved.","not W99999");
                bad(x=>x.lines.Add(new RoLineEdit{index=3,code="DET",remove=true}),"DET can't be taken out.","car section");
                bad(x=>x.lines.Add(new RoLineEdit{index=4,code="M",remove=true}),"A car note can't be taken out.","car section");
                bad(x=>x.lines.Add(new RoLineEdit{index=4,code="M",text="MAKE/MODEL: X"}),"A car note is changed in the car section.","car section");
                bad(x=>{x.lines[1]=new RoLineEdit{index=7,code="M",qty="2"};},"A note has no quantity.","Only item lines");
                bad(x=>{x.lines[1]=new RoLineEdit{index=0,code="W43116",text="hello"};x.lines.RemoveAt(0);},"An item has no words to change.","Only note lines");
                var onAccount=new Fixture();onAccount.Account="C10023";var acc=Read(onAccount);
                var p=Edit(acc);p.header=new Dictionary<string,string>{{"phone","0400 111 222"}};Reject(()=>p.Validate(acc),"A phone change on an account Repair Order.","account");
                var full=new Fixture();for(int i=11;i<=25;i++) full.Lines[i]=new[]{"M","NOTE "+i,"",""};for(int i=4;i<=5;i++) full.Lines[i]=new[]{"M","NOTE "+i,"",""};
                var fullSnap=Read(full);Check(fullSnap.lines.Count==25,"The full fixture has 25 lines.");
                var more=Edit(fullSnap);more.add=new List<RoNewLine>{new RoNewLine{kind="note",code="M",text="one more"}};Reject(()=>more.Validate(fullSnap),"A 26th line.","25 lines");
                more.lines=new List<RoLineEdit>{new RoLineEdit{index=24,code="M",remove=true}};more.Validate(fullSnap);
                var limited=Read(new Fixture());limited.limits["name"]=10;var lim=Edit(limited);lim.header=new Dictionary<string,string>{{"name","A VERY LONG CUSTOMER NAME"}};
                Reject(()=>lim.Validate(limited),"COSTAR's letter limit.","10 letters");
                var noDate=new Fixture();noDate.DateKind="picker";var nd=Read(noDate);var de=Edit(nd);de.dateIn=DateTime.Today.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture);
                Reject(()=>de.Validate(nd),"Date In in a calendar box.","calendar");
                var nocar=new Fixture();nocar.Lines.Remove(6);nocar.Lines.Remove(7);nocar.Lines.Remove(8);nocar.Lines.Remove(9);var nc=Read(nocar);
                var car=Edit(nc);car.makeModel="Ford Ranger";car.Validate(nc);
            });
            Case("Repair Orders: the result must be what was asked (old lines in order, new ones anywhere, nothing else moved)",()=>{
                var before=Read(new Fixture());
                var e=Edit(before);e.header=new Dictionary<string,string>{{"comment","fitted"}};e.shipVia="SHOP";e.customerWaiting="yes";e.rego="XYZ789";
                e.lines=new List<RoLineEdit>{new RoLineEdit{index=0,code="W43116",qty="2"},new RoLineEdit{index=1,code="WA",price="95"},new RoLineEdit{index=7,code="M",text="call when done"}};
                e.add=new List<RoNewLine>{new RoNewLine{kind="item",code="VALVE",qty="4",price="5"},new RoNewLine{kind="note",code="M",text="key in the box"}};
                Func<Fixture> applied=()=>{
                    var f=new Fixture();f.Comment="FITTED";f.ShipVia="SHOP";f.Total="$999.00";
                    f.Lines[1]=new[]{"W43116","WINRUN 265/70R16 112T MAXCLAW A/T","2","140.00"};
                    f.Lines[2]=new[]{"WA","WHEEL ALIGNMENT FRONT","1","95.00"};
                    f.Lines[4]=new[]{"VALVE","TYRE VALVE","4","5.00"};
                    f.Lines[8]=new[]{"M","REGO NO: XYZ789","",""};
                    f.Lines[10]=new[]{"M","CALL WHEN DONE","",""};
                    f.Lines[11]=new[]{"M","KEY IN THE BOX","",""};
                    return f;
                };
                var notes=new List<string>();
                var ok=RoExpect.Check(before,e,Read(applied(),"yes"),notes);
                Check(ok.Count==0&&notes.Count==0,"The applied change must pass: "+String.Join(" | ",ok.ToArray()));
                var f2=applied();f2.Lines[1]=new[]{"W43116","WINRUN 265/70R16 112T MAXCLAW A/T","4","140.00"};
                Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Any(p=>p.Contains("lines are not as asked")),"A quantity that didn't stay must be found.");
                f2=applied();f2.Lines[12]=new[]{"F","FREIGHT","1","10.00"};
                Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Any(p=>p.Contains("lines")),"A line nobody asked for must be found.");
                f2=applied();f2.Lines.Remove(4);f2.Lines[12]=new[]{"VALVE","TYRE VALVE","4","5.00"};
                Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Count==0,"A new item may go anywhere.");
                f2=applied();f2.Name="SOMEONE ELSE";Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Any(p=>p.Contains("name")),"The customer must not change by itself.");
                f2=applied();f2.Account="C99";Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Any(p=>p.Contains("account")),"The account must not change by itself.");
                f2=applied();f2.Postcode="2044";notes.Clear();
                Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Count==0&&notes.Any(n=>n.Contains("postcode")),"A box COSTAR changed by itself is said, not a stop.");
                Check(RoExpect.Check(before,e,Read(applied(),"no"),notes).Any(p=>p.Contains("Customer Waiting")),"Customer Waiting must be as asked.");
                f2=applied();f2.ShipVia="POST";Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Any(p=>p.Contains("Ship Via")),"Ship Via must be as asked.");
                f2=applied();f2.Lines[8]=new[]{"M","REGO NO: ABC123","",""};Check(RoExpect.Check(before,e,Read(f2,"yes"),notes).Count>0,"The rego must be as asked.");
                // Taking a line out: the lines under it move up.
                var r=Edit(before);r.lines=new List<RoLineEdit>{new RoLineEdit{index=1,code="WA",remove=true}};
                var gone=new Fixture();gone.Lines.Remove(2);
                Check(RoExpect.Check(before,r,Read(gone),notes).Count==0,"A line taken out (lines left in place).");
                var shifted=new Fixture();shifted.Lines=new Dictionary<int,string[]>();foreach(var pair in Standard()) if(pair.Key!=2) shifted.Lines[pair.Key>2?pair.Key-1:pair.Key]=pair.Value;
                Check(RoExpect.Check(before,r,Read(shifted),notes).Count==0,"A line taken out (lines moved up).");
                Check(RoExpect.Check(before,r,Read(new Fixture()),notes).Count>0,"A line that is still there must be found.");
                // A car on a Repair Order without DET: DET and its three notes come in as new lines.
                var bare=new Fixture();bare.Lines=new Dictionary<int,string[]>{{1,new[]{"W43116","WINRUN","4","140.00"}}};var b=Read(bare);
                var c=Edit(b);c.makeModel="Ford Ranger";c.rego="DEF456";
                var withCar=new Fixture();withCar.Lines=new Dictionary<int,string[]>{{1,new[]{"W43116","WINRUN","4","140.00"}},{3,new[]{"DET","DETAILS","",""}},{4,new[]{"M","MAKE/MODEL: FORD RANGER","",""}},{5,new[]{"M","REGO NO: DEF456","",""}},{6,new[]{"M ODO","ODOMETER:","",""}}};
                Check(RoExpect.Check(b,c,Read(withCar),notes).Count==0,"DET and its notes for a new car.");
                // The same item twice: the new one may be above the old one, with another quantity.
                var twice=Edit(before);twice.add=new List<RoNewLine>{new RoNewLine{kind="item",code="W43116",qty="1"}};
                var t=new Fixture();t.Lines[1]=new[]{"W43116","WINRUN 265/70R16 112T MAXCLAW A/T","1","140.00"};t.Lines[2]=new[]{"W43116","WINRUN 265/70R16 112T MAXCLAW A/T","4","140.00"};t.Lines[3]=new[]{"WA","WHEEL ALIGNMENT FRONT","1","89.00"};t.Lines[4]=new[]{"M FB","FITTING & BALANCING","",""};
                Check(RoExpect.Check(before,twice,Read(t),notes).Count==0,"The same code twice is matched either way round.");
                // A line that only lost its code (its words and price still there) is not "taken out".
                var cleared=new Fixture();cleared.Lines[2]=new[]{"","WHEEL ALIGNMENT FRONT","1","89.00"};var half=Read(cleared);
                Check(half.loose==1&&half.lines.All(l=>l.code!="WA")&&half.sig!=Read(gone).sig,"A line without its code must be counted (and in the fingerprint).");
                Check(RoExpect.Check(before,r,half,notes).Any(p=>p.Contains("item code")),"A line that only lost its code must stop the change.");
                // Nothing priced asked: the total must stay.
                var words=Edit(before);words.header=new Dictionary<string,string>{{"comment","fitted"}};
                var same=new Fixture();same.Comment="FITTED";Check(RoExpect.Check(before,words,Read(same),notes).Count==0,"A comment change with the same total passes.");
                var moved=new Fixture();moved.Comment="FITTED";moved.Total="$700.00";
                Check(RoExpect.Check(before,words,Read(moved),notes).Any(p=>p.Contains("total went from $650.00 to $700.00")),"A total that moved with nothing priced asked must stop.");
                var note=Edit(before);note.lines=new List<RoLineEdit>{new RoLineEdit{index=7,code="M",remove=true}};
                var noteGone=new Fixture();noteGone.Lines.Remove(10);noteGone.Total="$600.00";
                Check(RoExpect.Check(before,note,Read(noteGone),notes).Any(p=>p.Contains("total")),"Taking a note out must not move the total.");
            });
            Case("Repair Orders: only this line's own question is answered; the number counts only where nobody types; no customer words in the day log",()=>{
                var yn=new List<string>{"YES","NO"};
                foreach(var q in new[]{"Delete this line?","Are you sure you want to delete this item?","Remove the selected row?","Delete line?","This line will be deleted. Continue?","Delete this line from the Repair Order?"})
                    Check(Runner.YesToRemove(q,yn,true),"Not answered: "+q);
                foreach(var q in new[]{"Delete line 3?","DELETE ITEM W43116?","Do you want to delete this line?","Remove this product?","Are you sure you want to remove the current row?"})
                    Check(Runner.YesToRemove(q,yn,true),"Not answered: "+q);
                foreach(var q in new[]{"Remove the special order for this item?","Delete all lines?","This item has been invoiced. Delete this line?","Save changes before deleting this line?","Delete this item and its stock allocation?","Delete this line and email the customer?","Close the Repair Order?","Print the job card?","The line has been deleted.",
                    "Delete selected rows?","Delete this line and its linked fitting line?","This line is on order from the supplier. Delete this line?","This item has been received. Delete this line?","The item is reserved for job 1234. Delete this item?","Delete these lines?","Are you sure?"})
                    Check(!Runner.YesToRemove(q,yn,true),"Answered although it isn't only about this line: "+q);
                Check(!Runner.YesToRemove("Delete this line?",new List<string>{"OK"},true)&&!Runner.YesToRemove("Delete this line?",new List<string>{"YES","NO","CANCEL"},true)&&!Runner.YesToRemove("Delete this line?",new List<string>{"OK","CANCEL"},true),"Only exactly Yes and No.");
                Check(!Runner.YesToRemove("Delete this line?",yn,false),"Only a question the Repair Order owns.");
                // The number: in a label or a read-only box, never in a box anybody types into.
                var plain=Ro(new Fixture());Check(!Runner.NumberShown(plain,"07497644"),"The fixture shows no number.");
                var label=Ro(new Fixture());label.Add(Mk(60,150,ST,800,60,90,18,"07497644"));Check(Runner.NumberShown(label,"07497644"),"A label with the number.");
                var digits=Ro(new Fixture());digits.Add(Mk(60,150,ST,800,60,120,18,"RO # 7497644"));Check(Runner.NumberShown(digits,"07497644"),"The number without its leading zero.");
                var fixedBox=Ro(new Fixture());var box=Mk(61,150,ED,800,90,90,20,"07497644");box.Style=0x800;fixedBox.Add(box);Check(Runner.NumberShown(fixedBox,"07497644"),"A read-only box with the number.");
                var typedBox=Ro(new Fixture());typedBox.Add(Mk(62,150,ED,800,90,90,20,"07497644"));Check(!Runner.NumberShown(typedBox,"07497644"),"A box anybody types into doesn't count.");
                var f=new Fixture();f.Comment="WARRANTY FOR 07497644";Check(!Runner.NumberShown(Ro(f),"07497644"),"A comment naming the number doesn't count.");
                f=new Fixture();f.Po="07497644";Check(!Runner.NumberShown(Ro(f),"07497644"),"The PO# doesn't count.");
                f=new Fixture();f.Lines[11]=new[]{"M","SEE RO 07497644","",""};Check(!Runner.NumberShown(Ro(f),"07497644"),"A note line naming the number doesn't count.");
                // 2.6.1: the number in the box beside COSTAR's RepairOrder label: another number there stops it.
                var other=Ro(new Fixture());Check(Runner.OtherNumberShown(other,"07497644")==null,"No RepairOrder label: nothing to compare.");
                other.Add(Mk(70,150,ST,800,30,90,18,"RepairOrder"));other.Add(Mk(71,150,ED,895,29,90,20,"07497650"));
                Check(Runner.OtherNumberShown(other,"07497644")=="07497650","Another number beside the RepairOrder label.");
                var same=Ro(new Fixture());same.Add(Mk(70,150,ST,800,30,90,18,"Repair Order"));same.Add(Mk(71,150,ED,895,29,90,20,"7497644"));
                Check(Runner.OtherNumberShown(same,"07497644")==null,"The same number (without its leading zero) beside the label.");
                var away=Ro(new Fixture());away.Add(Mk(70,150,ST,800,30,90,18,"RepairOrder"));away.Add(Mk(71,150,ED,895,60,90,20,"07497650"));away.Add(Mk(72,150,ED,700,29,90,20,"07497651"));
                Check(Runner.OtherNumberShown(away,"07497644")==null,"A number on another line, or to the left, isn't the label's.");
                var near=Ro(new Fixture());near.Add(Mk(70,150,ST,800,30,90,18,"RepairOrder"));near.Add(Mk(71,150,ED,895,29,90,20,"07497644"));near.Add(Mk(72,150,ED,1000,29,90,20,"07497650"));
                Check(Runner.OtherNumberShown(near,"07497644")==null,"The box nearest the label is the one.");
                var empty=Ro(new Fixture());empty.Add(Mk(70,150,ST,800,30,90,18,"RepairOrder"));empty.Add(Mk(71,150,ED,895,29,90,20,""));empty.Add(Mk(72,150,ED,1000,29,90,20,"07497650"));
                Check(Runner.OtherNumberShown(empty,"07497644")==null,"The box beside the label without a number: nothing told (not a number further along).");
                // The day log: no customer words, accounts or numbers.
                string said=RoText.ForLog("COSTAR showed a message instead of opening Repair Order 07497644: \"JOHN CITIZEN owes $50\". Nothing was answered.");
                Check(!said.Contains("JOHN")&&!said.Contains("07497644")&&said.Contains("Nothing was answered"),"COSTAR's words left the log: "+said);
                string account=RoText.ForLog("COSTAR matched the new phone to customer account C10023. Check the Repair Order at the PC.");
                Check(!account.Contains("C10023")&&account.Contains("Check the Repair Order"),"An account number reached the log: "+account);
                Check(!RoText.ForLog("call 0412 345 678 or a@b.com").Contains("345"),"A phone number reached the log.");
                Check(RoText.ForLog("It said: CUSTOMER SMITH IS ON HOLD. Stopped.").IndexOf("SMITH",StringComparison.Ordinal)<0,"Words after said: reached the log.");
            });
            Case("Repair Orders: the desk queue hands out one request at a time, takes reports, and never leaves a request stuck",()=>{
                var q=new RoQueue();var now=new DateTime(2026,10,27,1,0,0,DateTimeKind.Utc);q.Clock=()=>now;int fired=0;q.Changed+=()=>fired++;
                var snap=Read(new Fixture());
                Reject(()=>q.Submit(new RoAsk{id="12",kind="list"}),"A request needs an ID.","ID");
                Reject(()=>q.Submit(Ask("delete","07497644")),"Unknown kinds are refused.","Unknown");
                Reject(()=>q.Submit(Ask("open","07 497")),"A bad RO number.","number");
                Reject(()=>q.Submit(Ask("open","07497644",Edit(snap))),"Only a change carries changes.","Only");
                var list=q.Submit(Ask("list"));Check(list.status=="queued"&&fired==1,"A list request waits for the helper.");
                Check(q.Submit(Ask("list")).id==list.id,"A second list request joins the first.");
                var freshAsk=Ask("list");freshAsk.fresh=true;Check(q.Submit(freshAsk).id==list.id,"↻ joins the list request waiting, and makes it a fresh read (2.6.1).");
                var clearAsk=Ask("list");clearAsk.clear=true;Check(q.Submit(clearAsk).id==list.id,"Clear COSTAR's filter joins the list request waiting too (2.6.11).");
                var open=q.Submit(Ask("open","07497644"));Check(q.Submit(Ask("open","07497644")).id==open.id,"A second open of the same RO joins the first.");
                var again=Ask("open","07497645");var first=q.Submit(again);Check(q.Submit(again).id==first.id,"The same ID sent again is the same request.");
                var clash=Wire.Copy(again);clash.doc="07497646";Reject(()=>q.Submit(clash),"An ID used for something else.","CONFLICT");
                // COSTAR busy: the list is read anyway (Order Check's copy), opening waits.
                var r1=q.Poll(Hello(null,true,false,""));Check(r1.command=="do"&&r1.task.kind=="list"&&r1.task.lease.Length>20,"The list goes first, even while COSTAR is busy.");
                Check(r1.task.fresh,"The helper is told the list must be read just now.");
                Check(r1.task.clear,"And that COSTAR's own search boxes are to be cleared first (2.6.11).");
                Check(Wire.Read<RoTask>(Wire.Json(r1.task)).clear&&!Wire.Read<RoTask>("{\"id\":\"a\",\"kind\":\"list\",\"fresh\":true}").clear,"The clear travels in the task; an older desk's task reads as no clear.");
                var clearOnly=new RoQueue();clearOnly.Clock=()=>now;var c=Ask("list");c.clear=true;clearOnly.Submit(c);var rc=clearOnly.Poll(Hello(null,true,false,""));
                Check(rc.command=="do"&&rc.task.clear&&rc.task.fresh,"A clear on its own is a fresh read too.");
                // A list read being done now wouldn't clear: a clear asked meanwhile waits as a read of its own, after it.
                var w=new RoQueue();w.Clock=()=>now;var plain=w.Submit(Ask("list"));var rw=w.Poll(Hello(null,true,false,""));
                var c2=Ask("list");c2.clear=true;var second=w.Submit(c2);
                Check(rw.task.id==plain.id&&!rw.task.clear&&second.id!=plain.id&&second.status=="queued","A clear asked while a plain list read is being done waits as a read of its own.");
                var c3=Ask("list");c3.clear=true;Check(w.Submit(c3).id==second.id&&w.Submit(Ask("list")).id==plain.id,"Another clear joins it; a plain read joins the one being done.");
                var wc=new RoQueue();wc.Clock=()=>now;var c4=Ask("list");c4.clear=true;var clearing=wc.Submit(c4);var rwc=wc.Poll(Hello(null,true,false,""));
                var c5=Ask("list");c5.clear=true;Check(rwc.task.clear&&wc.Submit(c5).id==clearing.id,"A clear joins a list read that is clearing already.");
                var rwAgain=w.Poll(Hello(null,true,false,rw.task.lease));
                Check(rwAgain.command=="do"&&rwAgain.task.id==plain.id&&rwAgain.task.lease==rw.task.lease,"Until the helper answers, the read being done is the one handed out (the clear isn't).");
                Check(w.Poll(Hello(Report(rw,"working",2),true,false,rw.task.lease)).command=="wait","Nothing else is handed out while the first read is being done.");
                var rw2=w.Poll(Hello(Report(rw,"done",3,null,new RoList{readUtc="2026-10-27T01:00:00Z",rows=new List<RoListRow>()}),true,false,""));
                Check(rw2.command=="do"&&rw2.task.id==second.id&&rw2.task.clear,"Then the clear is handed out.");
                Func<string,RoList> at=u=>new RoList{readUtc=u};
                Check(RoQueue.Older(at("2026-10-27T02:57:00Z"),at("2026-10-27T02:59:00Z"))&&!RoQueue.Older(at("2026-10-27T03:00:00Z"),at("2026-10-27T02:59:00Z"))&&!RoQueue.Older(at("x"),at("2026-10-27T02:59:00Z"))&&!RoQueue.Older(at("2026-10-27T02:57:00Z"),null),"An older list (Order Check's copy) never replaces a newer one on the desk.");
                Check(q.Poll(Hello(null,true,false,r1.task.lease)).command=="do"&&q.Poll(Hello(null,true,false,r1.task.lease)).task.lease==r1.task.lease,"An unanswered claim is handed out again with the same lease.");
                var rows=new RoList{rows=new List<RoListRow>{new RoListRow{doc="07497644",name="TEST CUSTOMER"}},readUtc="x",source="costar"};
                var w1=q.Poll(Hello(Report(r1,"working",1),true,false,r1.task.lease));Check(w1.command=="wait"&&w1.ack==1,"While the helper works on one request, nothing else is handed out.");
                var d1=q.Poll(Hello(Report(r1,"done",2,null,rows),true,false,""));
                Check(d1.ack==2&&q.Get(list.id).status=="done"&&q.List.rows.Count==1&&d1.command=="wait","A finished list is kept for the phones; opening still waits for COSTAR.");
                Check(q.Get(open.id).status=="queued","The open waits while COSTAR is busy.");
                var r2=q.Poll(Hello(null,true,true,""));Check(r2.command=="do"&&r2.task.kind=="open"&&r2.task.doc=="07497644","COSTAR free: the oldest open is handed out.");
                var dec=q.Poll(new RoHello{workerId="test-worker",accepting=true,available=false,working="",declined=r2.task.lease,declineReason="someone is using the COSTAR PC",sequence=1000});
                Check(q.Get(open.id).status=="queued"&&q.Get(open.id).message=="Waiting: someone is using the COSTAR PC"&&dec.command=="wait","A declined request waits again with the reason.");
                var r3=q.Poll(Hello(null,true,true,""));Check(r3.task.id==open.id&&r3.task.lease!=r2.task.lease,"A declined request comes back with a new lease.");
                var r3b=q.Poll(Hello(Report(r3,"done",3,snap),true,true,""));
                var st=q.Get(open.id);Check(st.status=="done"&&st.snapshot!=null&&st.snapshot.sig==snap.sig,"The snapshot reaches the phone.");
                Check(r3b.command=="do"&&r3b.task.doc=="07497645","The next open follows at once.");
                // A report for an old lease, or an unknown request, is acked and dropped.
                var stale=q.Poll(Hello(new RoReport{id=open.id,lease=r2.task.lease,status="failed",sequence=4},true,false,""));
                Check(stale.ack==4&&q.Get(open.id).status=="done","A stale report must not change a finished request.");
                Check(q.Poll(Hello(new RoReport{id="RO-00000000-0000-0000-0000-000000000000",lease="x",status="done",sequence=5},true,false,"")).ack==5,"An unknown request's report is acked.");
                q.Poll(Hello(Report(r3b,"done",6,snap),true,false,""));Check(q.Get(first.id).status=="done","The second open is done.");
                // A change: the helper restarts while typing it.
                var e=Edit(snap);e.customerWaiting="yes";var change=q.Submit(Ask("edit",snap.doc,e));
                Reject(()=>q.Submit(Ask("edit",snap.doc,e)),"Two changes to one RO at once.","already has a change");
                var r4=q.Poll(Hello(null,true,true,""));Check(r4.task.kind=="edit"&&r4.task.edit.customerWaiting=="yes"&&r4.task.edit.baseSig==snap.sig,"The change goes to the helper as sent.");
                q.Poll(Hello(Report(r4,"working",7),true,true,r4.task.lease,7));
                q.Poll(Hello(null,true,true,"",6));Check(q.Get(change.id).status=="working","An older hello can't end a request the helper reported on later.");
                q.Poll(Hello(null,true,true,"",8));
                var lost=q.Get(change.id);Check(lost.status=="failed"&&lost.typed&&lost.message.Contains("Check it in COSTAR"),"A change the helper stopped working on fails, marked as maybe typed.");
                // Time-outs: queued too long, or the helper silent while working.
                var late=q.Submit(Ask("close","07497644"));now=now.AddMinutes(11);q.Tidy(now);
                Check(q.Get(late.id).status=="failed"&&q.Get(late.id).message.Contains("10 minutes"),"A request nobody got to fails after 10 minutes.");
                var o2=q.Submit(Ask("open","07497650"));var r5=q.Poll(Hello(null,true,true,""));q.Poll(Hello(Report(r5,"working",9),true,true,r5.task.lease,9));
                q.Tidy(now.AddSeconds(-30));Check(q.Get(o2.id).status=="working","Still in touch: still working.");
                q.Tidy(now.AddSeconds(-100));Check(q.Get(o2.id).status=="failed","A silent helper's request fails.");
                // Switched off: nothing handed out.
                q.Submit(Ask("open","07497651"));Check(q.Poll(Hello(null,false,true,"")).command=="wait","Repair Orders switched off: wait.");
                for(int i=0;i<RoQueue.MaxWaiting-1;i++) q.Submit(Ask("open","0749"+(7700+i).ToString(CultureInfo.InvariantCulture)));
                Reject(()=>q.Submit(Ask("open","07499999")),"Too many waiting.","Too many");
                now=now.AddHours(5);q.Tidy(DateTime.MinValue);
                Check(q.Recent(500).Count<=RoQueue.Keep,"Old requests go.");
            });
            Case("Receiver Repair Order routes: the phone key and origin, list, requests and status; the worker route; health",()=>{
                var settings=new ReceiverSettings {address="192.168.1.2",phoneToken="phone-test",workerToken="worker-test",workerId="test-worker",ebayToken="ebay-test",webUrl="https://example.com/Fitment_Planner.html"};
                var api=new ReceiverApi(settings,new JobQueue(null,s=>{}),Path.GetTempPath(),()=>false,id=>{});
                const string root="/api/mobile/v1/ro";
                Check(api.Handle(Request("GET",root+"/list","phone-test")).status==400,"Before the queue exists the routes say so.");
                var q=new RoQueue();api.UseRo(q);
                Check(api.Handle(Request("GET",root+"/list",null)).status==401&&api.Handle(Request("GET",root+"/list","ebay-test")).status==401&&api.Handle(Request("GET",root+"/list","worker-test")).status==401,"Only the phone key opens the Repair Order routes.");
                Check(api.Handle(Request("GET",root+"/list","phone-test","https://evil.example")).status==403,"Another website may not use them.");
                Check(api.Handle(Request("GET",root+"/list","phone-test","chrome-extension://abcdefghijklmnopabcdefghijklmnop")).status==403,"The eBay extension may not use them.");
                var empty=api.Handle(Request("GET",root+"/list","phone-test","https://example.com"));
                Check(empty.status==200&&empty.headers["Access-Control-Allow-Origin"]=="https://example.com","The paired website reads the list.");
                var view=Body<Dictionary<string,object>>(empty);var helper=(Dictionary<string,object>)view["helper"];
                Check(view["list"]==null&&!(bool)helper["connected"]&&((string)helper["waiting"]).Contains("not running"),"No list yet, helper not in touch.");
                var ask=Ask("list");var posted=api.Handle(Request("POST",root+"/requests","phone-test","https://example.com",ask));
                var ps=Body<RoStatus>(posted);Check(posted.status==200&&ps.status=="queued"&&ps.waiting.Contains("not running"),"A request is taken and says why it waits.");
                Check(api.Handle(Request("GET",root+"/requests/"+ask.id,"phone-test")).status==200&&api.Handle(Request("GET",root+"/requests/RO-11111111-1111-1111-1111-111111111111","phone-test")).status==404,"Status, and 404 for an unknown request.");
                var bad=Ask("open","07497644");bad.edit=new RoEdit();Check(api.Handle(Request("POST",root+"/requests","phone-test",null,bad)).status==400,"A malformed request is refused.");
                Check(api.Handle(Request("POST","/api/worker/v1/ro","phone-test",null,Hello())).status==401&&api.Handle(Request("POST","/api/worker/v1/ro","worker-test",null,new RoHello{workerId="intruder"})).status==400,"The worker route needs the worker key and ID.");
                Check(api.Handle(Request("GET","/api/worker/v1/ro","worker-test")).status==400,"The worker route takes POST only.");
                var claim=Body<RoReply>(api.Handle(Request("POST","/api/worker/v1/ro","worker-test",null,Hello(null,true,false,""))));
                Check(claim.command=="do"&&claim.task.id==ask.id,"The worker route hands the request out.");
                var health=Body<Dictionary<string,object>>(api.Handle(Request("GET","/api/mobile/v1/health","phone-test")));
                Check((bool)health["ro"]&&(bool)health["roConnected"]&&(bool)health["roOn"]&&!(bool)health["roReady"],"Health tells the phone about Repair Orders.");
                var done=Hello(new RoReport{id=ask.id,lease=claim.task.lease,status="done",message="47 Repair Orders",sequence=1,list=new RoList{rows=new List<RoListRow>{new RoListRow{doc="07497644"}},readUtc="2026-10-27T01:00:00Z",source="costar"}},true,false,"");
                done.detail="COSTAR\u0085 busy "+new string('x',600);
                api.Handle(Request("POST","/api/worker/v1/ro","worker-test",null,done));
                var read=Body<Dictionary<string,object>>(api.Handle(Request("GET",root+"/list","phone-test")));
                Check(read["list"]!=null&&read["refresh"]==null,"The list reaches the phone.");
                Check(!api.RoDetail.Any(Char.IsControl)&&api.RoDetail.Length<=400,"Words from the helper are cleaned.");
                settings.phoneToken="";Check(api.Handle(Request("GET",root+"/list","")).status==401,"An empty key never matches.");
            });
            Case("Receiver Repair Order worker poll: a held poll wakes when a phone asks",()=>{
                var settings=new ReceiverSettings {address="192.168.1.2",phoneToken="phone-test",workerToken="worker-test",workerId="test-worker"};
                var api=new ReceiverApi(settings,new JobQueue(null,s=>{}),Path.GetTempPath(),()=>false,id=>{});var q=new RoQueue();api.UseRo(q);
                var hello=Hello(null,true,true,"");hello.waitMs=3000;
                RoReply reply=null;var t=new Thread(()=>{reply=Body<RoReply>(api.Handle(Request("POST","/api/worker/v1/ro","worker-test",null,hello)));});
                var clock=System.Diagnostics.Stopwatch.StartNew();t.Start();Thread.Sleep(300);
                var ask=Ask("open","07497644");api.Handle(Request("POST","/api/mobile/v1/ro/requests","phone-test",null,ask));
                Check(t.Join(5000)&&reply!=null&&reply.command=="do"&&reply.held&&clock.ElapsedMilliseconds<2500,"The held poll must answer as soon as the request arrives.");
            });
            Case("Receiver reads bigger bodies on the Repair Order worker route with the worker key only (the WIP list)",()=>{
                var settings=new ReceiverSettings {address="192.168.1.2",phoneToken="phone-test",workerToken="worker-test",workerId="test-worker"};
                var api=new ReceiverApi(settings,new JobQueue(null,s=>{}),Path.GetTempPath(),()=>false,id=>{});
                Func<string,string,int,bool> fits=(path,key,size)=>{
                    string body=new string('x',size);
                    var raw=Encoding.ASCII.GetBytes("POST "+path+" HTTP/1.1\r\nHost: 192.168.1.2:8790\r\nContent-Type: application/json\r\n"+(key==null?"":"Authorization: Bearer "+key+"\r\n")+"Content-Length: "+size+"\r\n\r\n"+body);
                    try { LocalServer.Read(new MemoryStream(raw),api.LargeBody);return true; } catch(InvalidOperationException) { return false; }
                };
                Check(fits("/api/worker/v1/ro","worker-test",200000)&&!fits("/api/worker/v1/ro","worker-test",1048577),"The Repair Order worker route takes up to 1 MB.");
                Check(!fits("/api/worker/v1/ro",null,70000)&&!fits("/api/worker/v1/ro","phone-test",70000),"Without the worker key it stays at 64 KB (nothing big is buffered for a stranger).");
                Check(!fits("/api/worker/../mobile/v1/ro/requests","worker-test",70000)&&!fits("/api/worker/v1/ro/../../mobile/v1/ro/requests","worker-test",70000),"A path that only starts like the worker route stays at 64 KB.");
                Check(!fits("/api/mobile/v1/ro/requests","phone-test",70000)&&fits("/api/mobile/v1/ro/requests","phone-test",60000),"Phone routes stay at 64 KB.");
                Check(!fits("/api/worker/v1/poll","worker-test",70000),"The other worker routes stay at 64 KB.");
            });
            Case("Job Card printing (2.6.2): the print form read from its labels and tick boxes; OK only with exactly the Job Card ticked to print and nothing to email; the form must be this Repair Order's",()=>{
                var f=new PrintFixture();
                string problem;var map=PrintForm.Read(f.Controls(),f.IsTick,out problem);
                Check(map!=null&&problem==null,"The print form as on 27 Oct must be read: "+problem);
                Check(map.Rows.Count==4&&map.JobCard!=null&&map.JobCard.Name=="JOB CARD"&&map.Rows[1].Name=="(COPY) INVOICE"&&map.Rows[2].Name=="FREIGHT LABEL"&&map.Rows[3].Name=="DELIVERY DOCKET","Its four documents, the Job Card first: "+String.Join(", ",map.Rows.Select(r=>r.Name).ToArray()));
                Check(map.JobCard.Print.Handle==f.PrintBox(0)&&map.JobCard.Email.Handle==f.EmailBox(0)&&map.JobCard.Qty!=null&&map.JobCard.Qty.Handle==f.QtyBox(0),"The Job Card's own Print and eMail boxes and quantity.");
                Check(map.Rows.All(r=>r.Print.Handle!=PrintFixture.Memos&&r.Email.Handle!=PrintFixture.Memos),"Show internal memos? is in neither column.");
                Check(map.Ok!=null&&map.Ok.Handle==PrintFixture.Ok&&map.Cancel!=null&&map.Cancel.Handle==PrintFixture.Cancel,"OK and Cancel.");
                Func<string,Func<ControlInfo,bool?>> states=delegate(string ticks) { return c=>{ int i=f.Index(c.Handle);return i<0?(bool?)null:ticks[i]=='1'; }; };
                Func<ControlInfo,string> one=q=>"1";
                // Ticks as "Print x4, eMail x4": COSTAR's default (Invoice), and what the helper leaves for OK.
                Check(PrintForm.Wrong(map,states("01000000"),one)=="the Job Card isn't ticked to print","COSTAR's default (the Invoice) isn't OK'd.");
                Check(PrintForm.Wrong(map,states("11000000"),one)=="the Invoice is still ticked to print","The Invoice must be unticked.");
                Check(PrintForm.Wrong(map,states("10100000"),one)=="the Freight Label is still ticked to print","No other document printed.");
                Check(PrintForm.Wrong(map,states("10001000"),one)=="the Job Card is ticked to email"&&PrintForm.Wrong(map,states("10000100"),one)=="the Invoice is ticked to email","Nothing emailed.");
                Check(PrintForm.Wrong(map,states("10000000"),one)==null,"Exactly the Job Card, to print: OK.");
                Check(PrintForm.Wrong(map,states("10000000"),q=>"2")=="the Job Card's quantity is 2, not 1"&&PrintForm.Wrong(map,states("10000000"),q=>"")=="the Job Card's quantity is empty, not 1","One Job Card.");
                Check(PrintForm.Wrong(map,c=>(bool?)null,one)!=null,"Ticks that can't be read: no OK.");
                // Forms that aren't that clear are not used.
                var g=new PrintFixture();g.JobCardName="Job Card";g.ExtraJobCard=true;Check(PrintForm.Read(g.Controls(),g.IsTick,out problem)==null&&problem.Contains("2 Job Card rows"),"Two Job Card rows: "+problem);
                g=new PrintFixture();g.JobCardName="Work Sheet";Check(PrintForm.Read(g.Controls(),g.IsTick,out problem)==null&&problem.Contains("no Job Card"),"No Job Card row: "+problem);
                g=new PrintFixture();g.EmailHeading="";Check(PrintForm.Read(g.Controls(),g.IsTick,out problem)==null&&problem.Contains("columns"),"No eMail column: "+problem);
                g=new PrintFixture();g.StrayEmail=true;Check(PrintForm.Read(g.Controls(),g.IsTick,out problem)==null&&problem.Contains("tick boxes"),"A tick box under eMail without its row: "+problem);
                g=new PrintFixture();g.OkText="Print";Check(PrintForm.Read(g.Controls(),g.IsTick,out problem)==null&&problem.Contains("OK"),"No OK button: "+problem);
                g=new PrintFixture();g.NoTicks=true;Check(PrintForm.Read(g.Controls(),g.IsTick,out problem)==null,"Boxes accessibility doesn't call tick boxes: not used.");
                // The Job Card's quantity is checked, never assumed: no Qty column, or no box for it, isn't clear.
                g=new PrintFixture();g.QtyHeading="";Check(PrintForm.Read(g.Controls(),g.IsTick,out problem)==null&&problem.Contains("Qty"),"No Qty column: "+problem);
                g=new PrintFixture();g.NoQtyBox=true;Check(PrintForm.Read(g.Controls(),g.IsTick,out problem)==null&&problem.Contains("quantity"),"No quantity box: "+problem);
                g=new PrintFixture();g.NumberBox=true;var nb=PrintForm.Read(g.Controls(),g.IsTick,out problem);
                Check(nb!=null&&nb.JobCard.Qty!=null&&nb.JobCard.Qty.Handle==g.QtyBox(0),"A number box: its own edit box is the quantity: "+problem);
                g=new PrintFixture();g.QtyLabel=true;var ql=PrintForm.Read(g.Controls(),g.IsTick,out problem);
                Check(ql!=null&&ql.JobCard.Qty!=null&&ql.JobCard.Qty.Handle==g.QtyBox(0)&&PrintForm.Wrong(ql,states("10000000"),q=>q.Text)==null,"A quantity shown only as words is read: "+problem);
                var noQty=PrintForm.Read(f.Controls(),f.IsTick,out problem);noQty.JobCard.Qty=null;
                Check(PrintForm.Wrong(noQty,states("10000000"),one)=="the Job Card's quantity couldn't be read"&&PrintForm.Wrong(map,states("10000000"),q=>null)=="the Job Card's quantity couldn't be read","No quantity box, or its words can't be read: no OK.");
                // The title: this Repair Order's number.
                Check(PrintForm.TitleNumber("Print RepairOrder 07490123")=="07490123"&&PrintForm.TitleNumber("Print Repair Order 7490123")=="7490123"&&PrintForm.TitleNumber("Print RepairOrder")=="","The print form's title and number.");
                Check(PrintForm.TitleNumber("Print Invoice 07490123")==null&&PrintForm.TitleNumber("RepairOrder  Branch 11 Tempe Tyres Tempe")==null&&PrintForm.TitleNumber("Print RepairOrder 07490123 and more")==null,"Other windows aren't the print form.");
                Check(PrintForm.SameNumber("07490123","7490123")&&!PrintForm.SameNumber("07490123","07490124")&&!PrintForm.SameNumber("","07490123"),"The same Repair Order number, leading zeros aside.");
                // The Repair Order's number beside its RepairOrder label (a phone job prints its own).
                var ro=Ro(new Fixture());ro.Add(Mk(70,150,ST,800,30,90,18,"RepairOrder"));ro.Add(Mk(71,150,ED,895,29,90,20,"07490123"));
                Check(Runner.NumberBox(ro)!=null&&Runner.NumberBox(ro).Handle==71,"The box beside the RepairOrder label.");
                ro.Add(Mk(72,150,ST,800,400,90,18,"Repair Order"));Check(Runner.NumberBox(ro)==null,"Two RepairOrder labels: not clear.");
                Check(Runner.NumberBox(Ro(new Fixture()))==null,"No RepairOrder label.");
            });
            Case("The phone's choices with SUBMIT TO COSTAR (2.6.2): ordered and printed only when chosen, older phones as before; the desk passes them on and says what the RDP helper does",()=>{
                Func<MobileOptions,MobileJob> job=o=>new MobileJob {
                    schema="tempe.mobile-jobcard.v1",submissionId="MJC-33333333-3333-4333-8333-333333333333",draftId="22222222-2222-4222-8222-222222222222",createdUtc="2026-10-27T06:00:00.000Z",
                    customer=new MobileCustomer{name="TEST CUSTOMER",mobile="0400000000"},vehicle=new MobileVehicle{registration="TEST123",makeModel="TEST CAR",odometer=1},
                    products=new List<MobileProduct>{new MobileProduct{type="tyre",sku="TESTTYRE",description="TEST TYRE",quantity=4}},fittingCode="M FB",additionalNotes="",options=o};
                var old=job(null);old.Validate();Check(old.Ordering&&!old.PrintingJobCard,"An older phone (no choices): ordered as before, nothing printed.");
                var both=job(new MobileOptions{order=true,printJobCard=true});both.Validate();Check(both.Ordering&&both.PrintingJobCard,"Both ticked.");
                var neither=job(new MobileOptions{order=false,printJobCard=false});neither.Validate();Check(!neither.Ordering&&!neither.PrintingJobCard,"Both unticked: not ordered, not printed.");
                Reject(()=>job(new MobileOptions{order=true}).Validate(),"A choice left out is refused.","choices");
                var back=Wire.Read<MobileJob>(Wire.Json(both));Check(back.options!=null&&back.options.order==true&&back.options.printJobCard==true&&Wire.Json(back)==Wire.Json(both),"The choices survive the desk and the journal unchanged.");
                Check(Wire.Read<MobileJob>("{\"schema\":\"x\",\"options\":{\"order\":false,\"printJobCard\":true}}").options.printJobCard==true,"The phone's JSON is read.");
                Check(Runner.OrderNote(true,true,true)=="Ordered: Ship Via SHOP, Customer Waiting ticked, Repair Date today."&&Runner.OrderNote(true,false,true).StartsWith("Ordered in part (Ship Via SHOP, Customer Waiting); by hand: Repair Date today",StringComparison.Ordinal)&&Runner.OrderNote(false,false,false).StartsWith("Not ordered",StringComparison.Ordinal),"What the order came to, for the phone.");
                // The desk: the choices go to the RDP helper as sent; health says whether that helper does them.
                var settings=new ReceiverSettings {address="192.168.1.2",phoneToken="phone-test",workerToken="worker-test",workerId="test-worker"};
                var q=new JobQueue(null,s=>{});var api=new ReceiverApi(settings,q,Path.GetTempPath(),()=>true,id=>{});
                Func<bool> options=()=>(bool)Body<Dictionary<string,object>>(api.Handle(Request("GET","/api/mobile/v1/health","phone-test")))["jobOptions"];
                Check(!options(),"No RDP helper in touch: no choices offered.");
                api.Handle(Request("POST","/api/worker/v1/poll","worker-test",null,new WorkerHello{workerId="test-worker",accepting=true,available=true}));
                Check(!options(),"An older RDP helper (it doesn't say it does them): no choices offered.");
                api.Handle(Request("POST","/api/worker/v1/poll","worker-test",null,new WorkerHello{workerId="test-worker",accepting=true,available=true,jobOptions=true}));
                Check(options(),"A 2.6.2 RDP helper: the phone offers the choices.");
                var posted=api.Handle(Request("POST","/api/mobile/v1/jobs","phone-test",null,neither));Check(posted.status==200,"The job with its choices is taken.");
                var assigned=Body<WorkerReply>(api.Handle(Request("POST","/api/worker/v1/poll","worker-test",null,new WorkerHello{workerId="test-worker",accepting=true,available=true,jobOptions=true})));
                Check(assigned.command=="inject"&&assigned.job.options!=null&&assigned.job.options.order==false&&assigned.job.options.printJobCard==false,"The RDP helper gets the choices as sent.");
                var other=Wire.Copy(neither);other.options.printJobCard=true;
                Check(api.Handle(Request("POST","/api/mobile/v1/jobs","phone-test",null,other)).status==409,"The same submission with other choices is a conflict, never a second job.");
                // An RDP helper that doesn't do the choices (it changed version since the phone looked): a job whose
                // choices it would ignore isn't handed to it; one with the old behaviour's choices is.
                Func<string,MobileOptions,MobileJob> withId=(id,o)=>{var j=job(o);j.submissionId=id;return j;};
                var q5=new JobQueue(null,s=>{});
                q5.Submit(withId("MJC-44444444-4444-4444-8444-444444444444",new MobileOptions{order=false,printJobCard=false}),true);
                var older=new WorkerHello{workerId="test-worker",accepting=true,available=true};
                var w1=q5.Poll(older);var failed=q5.Get("MJC-44444444-4444-4444-8444-444444444444");
                Check(w1.command=="wait"&&failed.status=="failed"&&failed.message.Contains("can't do this job's choices"),"Order unticked and an RDP helper that doesn't do the choices: not entered, said why: "+failed.message);
                q5.Retry("MJC-44444444-4444-4444-8444-444444444444");
                var w2=q5.Poll(new WorkerHello{workerId="test-worker",accepting=true,available=true,jobOptions=true});
                Check(w2.command=="inject"&&w2.job.options.order==false,"Retried once the RDP helper does them: entered with its choices.");
                var q6=new JobQueue(null,s=>{});q6.Submit(withId("MJC-55555555-5555-4555-8555-555555555555",new MobileOptions{order=true,printJobCard=true}),true);
                Check(q6.Poll(older).command=="wait"&&q6.Get("MJC-55555555-5555-4555-8555-555555555555").status=="failed","Print the Job Card and an RDP helper that doesn't print: not entered.");
                var q7=new JobQueue(null,s=>{});q7.Submit(withId("MJC-66666666-6666-4666-8666-666666666666",new MobileOptions{order=true,printJobCard=false}),true);
                Check(q7.Poll(older).command=="inject","Order alone (what every RDP helper does): entered by any RDP helper, as before.");
                var q8=new JobQueue(null,s=>{});q8.Submit(withId("MJC-77777777-7777-4777-8777-777777777777",null),true);
                Check(q8.Poll(older).command=="inject","An older phone's job (no choices): as before.");
                var q9=new JobQueue(null,s=>{});q9.Submit(withId("MJC-88888888-8888-4888-8888-888888888888",new MobileOptions{order=false,printJobCard=true}),true);
                Check(q9.Poll(new WorkerHello{workerId="test-worker",accepting=true,available=true,jobOptions=true}).command=="inject","Handed to a 2.6.2 RDP helper.");
                var w9=q9.Poll(older);var stoppedJob=q9.Get("MJC-88888888-8888-4888-8888-888888888888");
                Check(w9.command=="wait"&&stoppedJob.status=="failed"&&stoppedJob.message.StartsWith("Stopped",StringComparison.Ordinal),"Not taken yet, and the RDP helper no longer does the choices: not handed over again: "+stoppedJob.message);
            });
            Case("Map COSTAR screen (2.6.3): COSTAR read, never changed; customer words as their length only; buttons, ticks, tabs, headings and keys kept; long lists read in a sample",()=>{
                Check(CostarMap.Words(43,"Print",false)=="Print"&&CostarMap.Words(44,"Job Card",false)=="Job Card"&&CostarMap.Words(37,"Ship to",false)=="Ship to","COSTAR's own words are kept.");
                Check(CostarMap.Words(29,"TEST CUSTOMER 5",false)=="[15 chars]"&&CostarMap.Words(42,"0400000001",false)=="[10 chars]"&&CostarMap.Words(41,"Anything",true)=="[8 chars]","Cells, text boxes and anything in a list: their length only.");
                Check(CostarMap.Words(25,"Name",true)=="Name"&&CostarMap.Words(43,"",false)=="","Column headings are kept, in a list too; nothing for no words.");
                Check(CostarMap.Words(41,"test.customer@example.com 0400000001",false)=="[email] [number]","Emails and long numbers in a label are masked: "+CostarMap.Words(41,"test.customer@example.com 0400000001",false));
                Check(CostarMap.Kind("WindowsForms10.BUTTON.app.0.1",0x50010000)=="button"&&CostarMap.Kind("WindowsForms10.BUTTON.app.0.1",0x50010003)=="tick box"&&CostarMap.Kind("Button",0x50000007)=="group box"&&CostarMap.Kind("WindowsForms10.BUTTON.app.0.1",0x5001000B)=="button (drawn by COSTAR)"&&CostarMap.Kind("Button",0x50000009)=="radio button","Buttons, tick boxes, radio buttons and groups by their style.");
                Check(CostarMap.Kind("WindowsForms10.EDIT.app.0.1",0x50010080)=="text box"&&CostarMap.Kind("Edit",0x50010820)=="password box"&&CostarMap.Kind("Edit",0x50010880)=="read-only text box"&&CostarMap.Kind("#32768",0)=="menu"&&CostarMap.Kind("WindowsForms10.Window.8.app.0.1",0)=="COSTAR panel"&&CostarMap.Kind("WindowsForms10.STATIC.app.0.1",0)=="label","Text boxes, menus, labels and COSTAR's own panels.");
                Check(CostarMap.StateWords(0x100014)=="has the keyboard, ticked, can take the keyboard"&&CostarMap.StateWords(-1)=="","States in words.");
                // The made-up Work-in-Progress list, read through the same accessibility calls.
                var w=new FakeWip();var root=new FakeAcc(w,"client",-1,-1,w.Generation,false);
                var walk=CostarMap.Accessible(root,w.Box.Left,w.Box.Top,2500,20000);
                Check(!walk.Cut&&walk.Seen>20&&walk.Seen<200,"A 130-row list is read in a sample: "+walk.Seen+" objects.");
                var table=walk.Items.First(i=>(int)i["role"]==24);
                Check((int)table["children"]==131&&((string)table["read"]).Contains("of 131"),"The table says how many rows it has and which were read: "+table["read"]);
                var headers=walk.Items.Where(i=>(int)i["role"]==25).Select(i=>(string)i["name"]).ToList();
                Check(headers.SequenceEqual(w.Columns),"Column headings by name: "+String.Join(",",headers.ToArray()));
                Check(walk.Items.Where(i=>i.ContainsKey("value")).All(i=>System.Text.RegularExpressions.Regex.IsMatch((string)i["value"],@"^\[\d+ chars\]$")),"Cell values as their length only.");
                string json=Wire.Json(walk.Items);
                Check(!json.Contains("TEST CUSTOMER")&&!json.Contains("09101")&&!json.Contains("TTW"),"No customer name, Repair Order number or PO# in the map.");
                Check(w.Active==-1&&w.Clicks==0&&w.Wheels==0&&w.Focused==false,"Nothing selected, clicked, scrolled or focused while mapping.");
                // The reader's page.
                var shown=new Dictionary<string,object> {{"caption","RepairOrder"},{"class","WindowsForms10.Window.8.app.0.1"},{"front",true},{"accessible",walk.Items},
                    {"controls",new Dictionary<string,object> {{"count",1},{"items",new List<Dictionary<string,object>> {new Dictionary<string,object> {{"kind","button"},{"words","Print"},{"direct","press (BM_CLICK)"},{"enabled",true}}}}}}};
                var page=CostarMap.Summary(new List<Dictionary<string,object>> {shown});
                Check(page.Contains("button \"Print\": press (BM_CLICK)")&&page.Contains("table")&&page.Contains("131 in it")&&page.Contains("headings: "+String.Join(", ",w.Columns))&&page.Contains("read: 10 row, 81 cell")&&!page.Contains("TEST CUSTOMER"),"The page lists what can be pressed, the list, its headings in one line and its rows and cells counted:\n"+page);
                // A budget: cut, said.
                var tight=CostarMap.Accessible(new FakeAcc(w,"client",-1,-1,w.Generation,false),0,0,5,20000);
                Check(tight.Cut&&tight.Seen==5,"A budget stops the read and says so.");
            });
            Case("Map COSTAR screen (2.6.4): what doesn't show isn't read (one question each); Windows' frame parts not opened; the toolbar reached; only the COSTAR in front read",()=>{
                // A Repair Order as Tommy's first map met it: 120 boxes and a Next # button, each with its own hidden
                // frame parts, then a tab page behind another, then the toolbar. 2.6.3 spent its 2,500 on the hidden parts.
                var client=new FakeNode(10,"RepairOrder",0,"");
                for(int i=0;i<120;i++) client.Add(FakeNode.Box(42,"",""));
                client.Add(FakeNode.Box(43,"Next #","Press"));
                for(int i=0;i<3;i++) client.Add(FakeNode.Box(43,"","Press"));   // a line's own button, three lines
                var behind=new FakeNode(38,"Notes",0x8000,"").Add(FakeNode.Box(42,"",""));
                client.Add(new FakeNode(9,"",0,"").Add(new FakeNode(60,"",0,"").Add(new FakeNode(37,"Ship to",0x2,"Switch"),new FakeNode(37,"Notes",0,"Switch"))),behind);
                var toolbar=new FakeNode(22,"Toolbar",0,"").Add(new FakeNode(43,"Save",0x100000,"Press"),new FakeNode(43,"Print",0,"Press"),new FakeNode(43,"Close",0x1,"Press"));
                client.Add(new FakeNode(9,"Toolbar",0,"").Add(new FakeNode(1,"",0x8000,"").Add(new FakeNode(43,"Close",0x8000,"Press")),toolbar,new FakeNode(3,"",0x8000,"")));
                var title=new FakeNode(1,"RepairOrder",0,"").Add(new FakeNode(43,"Minimize",0,"Press"),new FakeNode(43,"Close",0,"Press"));
                var system=new FakeNode(2,"System",0,"").Add(new FakeNode(12,"System",0,"Execute"));
                var root=new FakeNode(9,"RepairOrder",0,"").Add(system,title,new FakeNode(2,"Application",0x8000,""),client,new FakeNode(3,"Vertical",0x8000,""),new FakeNode(4,"",0,""));
                var walk=CostarMap.Accessible(root,100,100,2500,20000);
                var names=walk.Items.Where(i=>i.ContainsKey("name")).Select(i=>(string)i["name"]).ToList();
                Check(!walk.Cut&&names.Contains("Print")&&names.Contains("Save")&&names.Contains("Next #"),"The toolbar is reached within 2.6.3's budget ("+walk.Seen+" kept, "+walk.Hidden+" hidden).");
                var hidden=root.All().Where(n=>(n.State&0x8000)!=0).ToList();
                var visitedHidden=hidden.Where(n=>n.Asked>0).ToList();
                Check(visitedHidden.All(n=>n.Asked==1&&n.OtherAsked==0)&&walk.Hidden==visitedHidden.Count&&walk.Hidden==124*5+1+2+2,"A part that doesn't show is asked one question (its state), nothing else: "+walk.Hidden+" such parts.");
                Check(hidden.SelectMany(n=>n.Under()).All(n=>n.Asked==0&&n.OtherAsked==0),"Nothing under a part that doesn't show is asked (its buttons, a tab page's boxes).");
                Check(walk.Items.All(i=>!i.ContainsKey("stateWords")||!((string)i["stateWords"]).Contains("hidden")),"Nothing hidden is kept in the map.");
                Check(title.Under().Concat(system.Under()).All(n=>n.Asked==0&&n.OtherAsked==0)&&walk.Frames==3&&walk.Items.Count(i=>i.ContainsKey("frame"))==3,"Windows' frame parts that show (title bar, system menu, size grip) are kept, never opened.");
                Check(walk.Visited==walk.Seen+walk.Hidden&&walk.Seen==walk.Items.Count,"Every object asked is either kept or counted as hidden.");
                Check(root.All().All(n=>n.Changed==0),"Nothing pressed, selected or changed.");
                Check(!Wire.Json(walk.Items).Contains("TEST CUSTOMER"),"Box values as their length only.");
                // The reader's page.
                var shown=new Dictionary<string,object> {{"caption","RepairOrder"},{"class","WindowsForms10.Window.8.app.0.1"},{"costar",1},{"front",true},{"accessible",walk.Items},{"accessibleHidden",walk.Hidden},
                    {"controls",new Dictionary<string,object> {{"count",3},{"items",new List<Dictionary<string,object>> {
                        new Dictionary<string,object> {{"kind","button (drawn by COSTAR)"},{"words",""},{"direct","press (BM_CLICK)"},{"enabled",true}},
                        new Dictionary<string,object> {{"kind","button (drawn by COSTAR)"},{"words",""},{"direct","press (BM_CLICK)"},{"enabled",true}},
                        new Dictionary<string,object> {{"kind","button (drawn by COSTAR)"},{"words","CustWaiting"},{"direct","press (BM_CLICK)"},{"enabled",true}}}}}}};
                var other=new Dictionary<string,object> {{"caption","COSTAR: 1 Branch"},{"class","WindowsForms10.Window.8.app.0.1"},{"costar",2},{"front",false},{"listedOnly","another COSTAR open in this session: listed, not read"}};
                var page=CostarMap.Summary(new List<Dictionary<string,object>> {shown,other});
                Check(page.Contains("toolbar \"Toolbar\" — 3 in it")&&page.Contains("button \"Print\": Press [Alt+p]")&&page.Contains("button \"Close\": Press — greyed")&&page.Contains("tab \"Ship to\": Switch — selected")&&page.Contains("button \"Next #\": Press"),"The page has the toolbar's buttons, their keys and states, and the tabs:\n"+page);
                Check(page.Contains("button (drawn by COSTAR) \"\": press (BM_CLICK) (x2)")&&page.Contains("\"CustWaiting\": press (BM_CLICK)")&&!page.Contains("\"CustWaiting\": press (BM_CLICK) (x"),"The same button many times: once, counted; a button once: no count.");
                Check(!page.Contains("Minimize")&&!page.Contains("Line down")&&!page.Contains("\"System\"")&&!page.Contains("can take the keyboard")&&page.Contains("button \"Save\": Press")&&page.Contains(walk.Hidden+" parts that don't show not read"),"No frame parts or everyday states on the page; the hidden parts counted.");
                Check(page.Contains(" button: Press (x3)")&&page.Split('\n').Count(x=>x.Contains(" button: Press"))==1,"The same accessible button on every line: once, counted.");
                Check(page.Contains("COSTAR: 1 Branch")&&page.Contains("another COSTAR open in this session: listed, not read"),"Another COSTAR's window: listed, not read.");
                // Which windows are read: the COSTAR in front (first), up to the most; the others listed.
                List<int> read,listed;
                CostarMap.Plan(new uint[]{5,5,7,5,9,7},12,out read,out listed);
                Check(read.SequenceEqual(new[]{0,1,3})&&listed.SequenceEqual(new[]{2,4,5}),"The COSTAR in front read, the other COSTARs listed.");
                CostarMap.Plan(new uint[]{5,5,7,5},2,out read,out listed);
                Check(read.SequenceEqual(new[]{0,1})&&listed.SequenceEqual(new[]{2,3}),"Past the most: listed.");
                CostarMap.Plan(new uint[0],12,out read,out listed);
                Check(read.Count==0&&listed.Count==0,"No COSTAR window: nothing.");
            });
            Case("Map COSTAR screen (2.9.0): a customer's words shown as labels (the Cashier's Customer row, a message box) as their length only, in accessibility too",()=>{
                // The Cashier window after Sell, made up: Customer, the customer's name, Terms, the terms' words on one
                // row; captions below.
                Func<int,int,int,int,string,CostarMap.LabelSeen> lab=(x,y,wd,ht,words)=>new CostarMap.LabelSeen {X=x,Y=y,W=wd,H=ht,Words=words,Item=new Dictionary<string,object> {{"words",words}}};
                var customer=lab(22,42,97,25,"Customer");var name=lab(121,44,225,21,"TEST & SON TYRES PTY LTD");var terms=lab(359,44,78,20,"Terms");var termsWords=lab(442,44,229,21,"TEST TERMS 7 DAYS");
                var below=lab(23,67,97,20,"Balance");var belowRight=lab(121,67,120,20,"TEST WORDS");var leftOf=lab(2,44,18,20,"TEST");
                var cashier=new List<CostarMap.LabelSeen> {customer,name,terms,termsWords,below,belowRight,leftOf};
                var hide=CostarMap.Private(cashier,false);
                Check(hide.Contains(name)&&hide.Count==1,"Right of Customer on its row, up to Terms: the name, as its length ("+hide.Count+" hidden).");
                Check(!hide.Contains(customer)&&!hide.Contains(terms)&&!hide.Contains(termsWords)&&!hide.Contains(below)&&!hide.Contains(belowRight)&&!hide.Contains(leftOf),"Customer, Terms and the terms' words (COSTAR's), the rows below and what's left of Customer: kept.");
                var code=lab(121,44,60,21,"TEST1234");var rest=lab(185,44,160,21,"TEST & SON");
                hide=CostarMap.Private(new List<CostarMap.LabelSeen> {customer,rest,code,terms,termsWords},false);
                Check(hide.Contains(code)&&hide.Contains(rest)&&hide.Count==2,"A name in two labels before Terms: both hidden.");
                var contact=lab(560,44,60,20,"Contact");var person=lab(625,44,140,20,"JOHN TEST");var account=lab(770,44,60,20,"Account");var code2=lab(835,44,80,20,"TEST01");
                hide=CostarMap.Private(new List<CostarMap.LabelSeen> {customer,name,terms,termsWords,contact,person,account,code2},false);
                Check(hide.Contains(name)&&hide.Contains(person)&&hide.Contains(code2)&&hide.Count==3,"Past Terms on the row: a contact's name and an account code hidden too; Terms' own words, Contact and Account kept.");
                var tall=lab(121,40,225,30,"TEST TALL NAME");var higher=lab(121,30,225,21,"TEST HIGHER");var deep=lab(121,42,225,60,"TEST DEEP NAME");
                hide=CostarMap.Private(new List<CostarMap.LabelSeen> {lab(22,42,97,25,"Customer:"),tall,higher,deep},false);
                Check(hide.Contains(tall)&&hide.Contains(deep)&&!hide.Contains(higher),"\"Customer:\" too; taller labels on its row hidden (one 60 px high from its top too), one a row above kept.");
                Check(CostarMap.Private(new List<CostarMap.LabelSeen> {lab(22,42,97,25,"Account#"),lab(121,44,225,21,"Platinum")},false).Count==0,"No Customer label: nothing hidden.");
                var memo=new List<CostarMap.LabelSeen> {lab(19,54,347,28,"TEST MEMO: CALL BEFORE FITTING")};
                Check(CostarMap.Private(memo,true).Count==1&&CostarMap.Private(memo,false).Count==0,"A message box's words: hidden whatever they are; another window's label: kept.");
                Check(CostarMap.Norm(" Test &  Son\r\nTyres: ")=="TEST SON TYRES"&&CostarMap.Norm(null)=="","Words compared without &, extra spaces or a colon, in upper case.");
                // A control's words: 40 at most; a label's longer ones remembered for accessibility.
                var masked=new HashSet<string>(StringComparer.Ordinal);
                string longWords="TEST MEMO WORDS THAT RUN ON PAST FORTY CHARACTERS IN ALL";
                Check(CostarMap.ControlWords("label","Order Date",masked)=="Order Date"&&masked.Count==0,"A short label's words kept.");
                Check(CostarMap.ControlWords("label",longWords,masked)=="["+longWords.Length+" chars]"&&masked.Contains(CostarMap.Norm(longWords)),"A long label's words: their length, remembered.");
                Check(CostarMap.ControlWords("radio button","Open a personal service file for this new cash customer",masked)=="[55 chars]"&&masked.Count==1,"A long button's words: their length, not remembered (COSTAR's).");
                // Accessibility: the label's window and the label itself (its "&" gone) as their length; the rest kept.
                masked.Add(CostarMap.Norm(name.Words));
                var client=new FakeNode(10,"Cashier",0,"").Add(new FakeNode(9,"TEST & SON TYRES PTY LTD",0,"").Add(new FakeNode(41,"TEST  SON TYRES PTY LTD",0,"")),
                    new FakeNode(9,"Customer",0,"").Add(new FakeNode(41,"Customer",0,"")),new FakeNode(9,"Terms",0,"").Add(new FakeNode(41,"Terms",0,"")),
                    new FakeNode(41,longWords.ToLowerInvariant(),0,""),new FakeNode(43,"OK",0,"Press"));
                var walk=CostarMap.Accessible(new FakeNode(9,"Cashier",0,"").Add(client),0,0,2500,20000,masked);
                var names=walk.Items.Where(i=>i.ContainsKey("name")).Select(i=>(string)i["name"]).ToList();
                Check(names.Contains("[24 chars]")&&names.Contains("[23 chars]")&&names.Contains("["+longWords.Length+" chars]"),"The name in the label's window and in the label, and the long words: their length ("+String.Join(", ",names.ToArray())+").");
                Check(names.Contains("Customer")&&names.Contains("Terms")&&names.Contains("OK")&&names.Contains("Cashier"),"COSTAR's own words kept.");
                string json=Wire.Json(walk.Items);
                Check(!json.Contains("SON TYRES")&&!json.ToUpperInvariant().Contains("TEST MEMO"),"No customer words in the map.");
                var plain=CostarMap.Accessible(new FakeNode(9,"Cashier",0,"").Add(new FakeNode(41,"Customer",0,"")),0,0,2500,20000);
                Check(plain.Items.Any(i=>i.ContainsKey("name")&&(string)i["name"]=="Customer"),"Without masked words: as before.");
                // Accessibility by itself (the controls' words not read: COSTAR slow): its labels by their places, and the
                // box MSAA names after the label before it.
                var own=new HashSet<string>(StringComparer.Ordinal);
                var cashierTree=new FakeNode(9,"Cashier",0,"").Place(0,0,1034,365).Add(new FakeNode(10,"Cashier",0,"").Place(8,31,1018,326).Add(
                    new FakeNode(9,"Customer",0,"").Place(22,42,97,25).Add(new FakeNode(41,"Customer",0,"").Place(22,42,97,25)),
                    new FakeNode(9,"TEST & SON TYRES PTY LTD",0,"").Place(121,44,225,21).Add(new FakeNode(41,"TEST  SON TYRES PTY LTD",0,"").Place(122,45,223,19)),
                    new FakeNode(9,"TEST  SON TYRES PTY LTD",0,"").Place(121,67,225,22).Add(new FakeNode(10,"TEST  SON TYRES PTY LTD",0,"").Place(121,67,225,22)),
                    new FakeNode(9,"Terms",0,"").Place(359,44,78,20).Add(new FakeNode(41,"Terms",0,"").Place(359,44,78,20)),
                    new FakeNode(41,"TEST TERMS 7 DAYS",0,"").Place(443,45,227,19),new FakeNode(41,"Balance",0,"").Place(23,89,97,20),
                    new FakeNode(41,longWords,0,"").Place(23,300,400,20),new FakeNode(43,"Cancel",0,"Press").Place(892,320,127,28),
                    new FakeNode(41,"TEST WORDS ONE",0,"").Place(121,250,120,20),new FakeNode(43,"Test words one",0,"Press").Place(600,250,100,20),
                    new FakeNode(33,"TEST  SON TYRES PTY LTD",0,"").Place(121,90,225,60),new FakeNode(41,"TEST LONG WORDS IN A LABEL THAT CANNOT BE PLACED AT ALL",0,"") {Unplaced=true}));
                own.Add(CostarMap.Norm("TEST WORDS ONE"));
                var alone=CostarMap.Accessible(cashierTree,0,0,2500,20000,own);
                var aloneNames=alone.Items.Where(i=>i.ContainsKey("name")).Select(i=>(string)i["name"]).ToList();
                string aloneJson=Wire.Json(alone.Items);
                Check(!aloneJson.Contains("SON TYRES")&&!aloneJson.Contains("TEST MEMO")&&!aloneJson.Contains("CANNOT BE PLACED")&&aloneNames.Count(n=>n=="[24 chars]")==1&&aloneNames.Count(n=>n=="[23 chars]")==4&&aloneNames.Contains("[14 chars]"),"The name (its label, the label's window, the box and the list named after it), the long labels (placed or not) and a label hidden in the controls: their length ("+String.Join(", ",aloneNames.ToArray())+").");
                Check(aloneNames.Contains("Customer")&&aloneNames.Contains("Terms")&&aloneNames.Contains("TEST TERMS 7 DAYS")&&aloneNames.Contains("Balance")&&aloneNames.Contains("Cancel")&&aloneNames.Contains("Cashier")&&aloneNames.Contains("Test words one"),"COSTAR's own words kept: the captions, the terms' words, and a button with a hidden label's words (COSTAR's buttons, ticks, tabs, menus and headings never repeat a label).");
                Check(own.Contains(CostarMap.Norm(name.Words))&&own.Contains(CostarMap.Norm(longWords)),"What accessibility hid goes back for the controls.");
                var memoTree=new FakeNode(9,"Point-of-sale Memo!",0,"").Place(0,0,403,153).Add(new FakeNode(18,"Point-of-sale Memo!",0,"").Add(
                    new FakeNode(9,"TEST MEMO",0,"").Place(19,54,347,28).Add(new FakeNode(41,"TEST MEMO",0,"") {Unplaced=true}),new FakeNode(43,"OK",0,"Press").Place(305,112,75,23)));
                var memoWalk=CostarMap.Accessible(memoTree,0,0,2500,20000,null,true);
                var memoNames=memoWalk.Items.Where(i=>i.ContainsKey("name")).Select(i=>(string)i["name"]).ToList();
                Check(!Wire.Json(memoWalk.Items).Contains("TEST MEMO")&&memoNames.Contains("OK")&&memoNames.Contains("Point-of-sale Memo!"),"A message box's words, short ones too and one accessibility can't place: their length; its title and OK kept ("+String.Join(", ",memoNames.ToArray())+").");
            });
            Case("Direct presses (2.6.5): a Repair Order opened from Work-in-Progress without the mouse (its row the active one); accessibility presses never late, never twice, the last look right before them",()=>{
                // The wanted row far down the list, the list without the keyboard: selected and made the active row
                // through accessibility, the keyboard given to the list, a fresh read shows it the active row and the
                // only selected one. No click, no wheel.
                var w=new FakeWip {RealStates=true,Current=7};var screen=new FakeScreen(w);var times=new RoOpenTimes();WipScan scan=null;
                try {
                    scan=screen.Scan(w.Doc(120));times.Took(scan);
                    bool ok=RoWip.SelectForEnter(screen,ref scan,w.Doc(120),times);
                    Check(ok&&w.Active==120&&w.Current==120&&w.Activations==1&&w.Clicks==0&&w.Wheels==0&&w.KeyboardGiven==1&&w.Focused&&times.Direct&&times.How=="made the active row directly"&&scan.TargetLine.Doc==w.Doc(120),"Ready for Enter with nothing clicked or scrolled ("+ok+", active "+w.Active+", "+w.Activations+" activations, "+w.Clicks+" clicks, "+w.Wheels+" turns, keyboard given "+w.KeyboardGiven+").");
                    Check(times.ToString().Contains("opened without the mouse"),"The day log says how: "+times);
                } finally { if(scan!=null) scan.Dispose(); }
                Func<FakeWip,int,string> ready=delegate(FakeWip x,int target) {
                    var sc=new FakeScreen(x);var t=new RoOpenTimes();WipScan sn=null;
                    try { sn=sc.Scan(x.Doc(target));return RoWip.SelectForEnter(sc,ref sn,x.Doc(target),t)?"enter":"mouse"; }
                    finally { if(sn!=null) sn.Dispose(); }
                };
                var held=new FakeWip {Focused=true};
                Check(ready(held,60)=="enter"&&held.KeyboardGiven==0,"A list that has the keyboard already isn't given it again.");
                var refuses=new FakeWip {TakesKeyboard=false};
                Check(ready(refuses,60)=="mouse"&&refuses.Clicks==0&&refuses.Wheels==0,"A list that doesn't keep the keyboard: the mouse way (nothing pressed).");
                var two=new FakeWip {AlsoSelected=5};
                Check(ready(two,60)=="mouse","Another row still selected (Enter could open it): the mouse way.");
                var deaf=new FakeWip {SelectIgnored=true};
                Check(ready(deaf,60)=="mouse","A list that doesn't take the selection: the mouse way.");
                var scrolls=new FakeWip {SelectScrolls=true};
                Check(ready(scrolls,99)=="enter"&&scrolls.Wheels==0,"A list that scrolls to the selected row: Enter, no wheel.");
                // Selected and active apart (Enter opens the active row): the wanted row made the active one too.
                var real=new FakeWip {RealStates=true,Current=7};
                Check(ready(real,120)=="enter"&&real.Current==120&&real.Active==120&&real.Activations==1&&real.Clicks==0,"Selected and active apart: the wanted row made the active one, then Enter (active "+real.Current+", selected "+real.Active+").");
                var stuck=new FakeWip {RealStates=true,Current=7,ActivateIgnored=true};
                Check(ready(stuck,120)=="mouse"&&stuck.Active==120&&stuck.Current==7&&stuck.Clicks==0,"The wanted row selected but another still the active row (Enter would open that one): the mouse way.");
                var stuckUnmarked=new FakeWip {RealStates=true,Current=7,ActivateIgnored=true,NoFocusMark=true};
                Check(ready(stuckUnmarked,120)=="mouse","The same with no row marked focused: the other active row told by its action (the wanted row still offers Activate).");
                var unmarked=new FakeWip {RealStates=true,Current=7,NoFocusMark=true};
                Check(ready(unmarked,120)=="enter","No row marked focused: the active row told by its action (the only row not offering Activate).");
                var mute=new FakeWip {RealStates=true,Current=7,NoFocusMark=true,NoActions=true};
                Check(ready(mute,120)=="mouse","Neither mark nor actions tell which row is active: the mouse way.");
                Func<FakeWip,string> stops=delegate(FakeWip x) { try { return "went on: "+ready(x,120); } catch(InvalidOperationException e) { return e.Message; } };
                var busy=new FakeWip {RealStates=true,Current=7,ActivateGate=()=>Direct.PcInUse};
                string said=stops(busy);
                Check(said.StartsWith("Someone used the COSTAR PC",StringComparison.Ordinal)&&busy.Activations==0&&busy.Current==7&&busy.Clicks==0&&busy.Wheels==0,"The last look before Activate sees someone at the PC: the open stops there, nothing activated, clicked or scrolled ("+said+").");
                var covered=new FakeWip {RealStates=true,Current=7,ActivateGate=()=>RoWip.MainNotFree};
                said=stops(covered);
                Check(said.Contains("wasn't in front and free")&&covered.Activations==0&&covered.Clicks==0,"COSTAR's main window not in front and free at the last look: the open stops, nothing pressed ("+said+").");
                var already=new FakeWip {RealStates=true,Current=7,SelectActivates=true,ActivateThrowsWhenActive=true};
                Check(ready(already,120)=="enter"&&already.Current==120&&already.Activations==0,"A selection that makes the row the active one already: no Activate pressed (it offers none), then Enter.");
                var moved=new FakeWip {RealStates=true,Current=7};var msc=new FakeScreen(moved);WipScan mscan=null;
                try {
                    mscan=msc.Scan(moved.Doc(120));moved.Reorder();
                    Check(!msc.Activate(mscan,moved.Doc(120))&&moved.Activations==0,"The list sorted again before Activate: the row looked up afresh isn't that Repair Order, nothing activated.");
                } finally { if(mscan!=null) mscan.Dispose(); }
                // Accessibility presses (Print, a row's Activate): on a thread of their own, waited for, never late.
                var print=new FakeNode(43,"Print",0,"Press") {Block=new System.Threading.ManualResetEvent(false)};
                var act=Direct.Act(delegate(out object child,out string why) { child=null;why=null;return print; });
                string went=Direct.Went(act,3000,300);
                Check(went=="pressed"&&print.Pressed==1,"A press that opens a window (COSTAR comes back once it closes): pressed, once ("+went+").");
                print.Block.Set();
                var gone=Direct.Act(delegate(out object child,out string why) { child=null;why="Print isn't there";return null; });
                Check(Direct.Went(gone,3000,300)=="not pressed"&&gone.FindError=="Print isn't there","Not found: not pressed, and why.");
                var slow=new FakeNode(43,"Print",0,"Press");
                var late=Direct.Act(delegate(out object child,out string why) { child=null;why=null;System.Threading.Thread.Sleep(900);return slow; });
                Check(Direct.Went(late,200,300)=="not pressed","Found too late: given up.");
                System.Threading.Thread.Sleep(1500);
                Check(slow.Pressed==0,"Given up means never pressed (no late press after a click): "+slow.Pressed);
                var broken=new FakeNode(43,"Print",0,"Press") {Throws=new InvalidOperationException("refused")};
                var failed=Direct.Act(delegate(out object child,out string why) { child=null;why=null;return broken; });
                Check(Direct.Went(failed,3000,300)=="failed"&&failed.PressError=="refused","A press that fails: failed (nothing more pressed after it).");
                // The last look, on the press's own thread right before it: a no is never pressed, and says why.
                var guarded=new FakeNode(43,"Print",0,"Press");
                var stopped=Direct.Act(delegate(out object child,out string why) { child=null;why=null;return guarded; },()=>"someone is using the COSTAR PC");
                Check(Direct.Went(stopped,3000,300)=="not pressed"&&stopped.FindError=="someone is using the COSTAR PC"&&guarded.Pressed==0,"The last look says no: never pressed ("+guarded.Pressed+"), and why: "+stopped.FindError);
                var looked=0;var go=new FakeNode(43,"Print",0,"Press");
                var fine=Direct.Act(delegate(out object child,out string why) { child=null;why=null;System.Threading.Thread.Sleep(300);return go; },()=>{ looked++;return null; });
                Check(Direct.Went(fine,3000,300)=="pressed"&&go.Pressed==1&&looked==1,"The last look after the finding (however long that took), once: pressed once.");
                // A tick box pressed directly: what follows it.
                Check(Direct.AfterPress(1,true,true)=="done"&&Direct.AfterPress(0,false,false)=="done"&&Direct.AfterPress(-1,true,true)=="done","Showing what's wanted: done.");
                Check(Direct.AfterPress(1,false,true)=="click"&&Direct.AfterPress(-1,true,false)=="click","Answered (or never sent) and reading unchanged: one real click.");
                Check(Direct.AfterPress(0,false,true)=="leave"&&Direct.AfterPress(1,null,true)=="leave"&&Direct.AfterPress(0,null,false)=="leave"&&Direct.AfterPress(-1,null,true)=="leave","Not answered yet, or can't be read: no second press.");
            });
            Case("The day log (2.6.6): nothing from the self-tests' made-up lists (they read like failed opens); a box that lost the keyboard before its words is a focus stop",()=>{
                // On the PC the self-tests run as --self-test (Build.ps1, after every update): the day log is off then.
                bool selfTest=Array.IndexOf(Environment.GetCommandLineArgs(),"--self-test")>=0;
                Check(!selfTest||AppLog.Off,"The self-tests run with the day log off.");
                bool was=AppLog.Off;int before=AppLog.Skipped;
                try {
                    AppLog.Off=true;
                    AppLog.Note("ro_open_direct","made-up: its row didn't become the active and only selected one");
                    Check(AppLog.Skipped>before,"Off: the note was left out of the day log.");
                } finally { AppLog.Off=was; }
                Check(StopCategory.Of("The customer phone field lost focus before its words went in.",false)=="focus_failed","Lost focus before its words: "+StopCategory.Of("The customer phone field lost focus before its words went in.",false));
                Check(StopCategory.Of("The field lost focus before validation.",false)=="commit_failed","Lost focus before validation stays commit_failed.");
                Check(StopCategory.Of("The REGO NO note lost focus before it could be confirmed.",false)=="focus_failed"&&StopCategory.Of("The ODOMETER note lost focus before a key press. Check the ODOMETER note: an extra letter may be at its end.",false)=="focus_failed","A note that lost the keyboard before its key press is a focus stop.");
            });
            Case("A Repair Order left open in COSTAR closed first for the phone (2.6.7): never one held for review, one COSTAR asks something on, an online order's, or while someone uses the PC; its number and PO# read from its labels",()=>{
                // What stays open, first reason first. seen: what was read (null: not read yet).
                Func<string,RoPeek.Seen> read=delegate(string p) { return new RoPeek.Seen {Doc="07000123",Po=p}; };
                Check(RoEngine.KeepOpen(false,null,true,null)==null&&RoEngine.KeepOpen(false,null,true,read("ABC1"))==null&&RoEngine.KeepOpen(false,null,true,read(""))==null,"Nothing held, nothing asked, nobody at the PC, not an online order's: closed first.");
                string held=RoEngine.KeepOpen(true,"COSTAR is asking something on it",false,read("TTW0000414"));
                Check(held!=null&&held.Contains("waiting for review"),"A phone job's or an online order's Repair Order held for review stays: "+held);
                string asked=RoEngine.KeepOpen(false,"COSTAR is asking something on it",false,read("TTW0000414"));
                Check(asked!=null&&asked.StartsWith("COSTAR is asking something on it",StringComparison.Ordinal)&&asked.Contains("Answer it at the PC"),"COSTAR asking something on it: stays, nothing answered: "+asked);
                string busy=RoEngine.KeepOpen(false,null,false,read("TTW0000414"));
                Check(busy!=null&&busy.Contains("nobody has used the PC for "+RoEngine.CloseQuietSeconds+" s"),"Someone used the PC: stays until it has been quiet (nothing read meanwhile): "+busy);
                string online=RoEngine.KeepOpen(false,null,true,read("TTW0000414"));
                Check(online!=null&&online.Contains("online order TTW0000414"),"An online order's PO#: stays, maybe waiting for review: "+online);
                Check(RoEngine.KeepOpen(false,null,true,read("ttw0000414"))!=null,"An online order's PO# in small letters too.");
                Check(RoEngine.KeepOpen(false,null,true,read("TTW0000414-2"))==null&&RoEngine.KeepOpen(false,null,true,read("TTW"))==null,"Only an online order's number counts as one.");
                string unread=RoEngine.KeepOpen(false,null,true,new RoPeek.Seen());
                Check(unread!=null&&unread.Contains("didn't answer"),"Its PO# couldn't be read: stays (it might be an online order's): "+unread);
                int closeQuiet=RoEngine.CloseQuietSeconds,quiet=RoEngine.QuietSeconds;Check(closeQuiet>=quiet,"Closing waits at least as long as anything else does.");
                // Its number (beside the RepairOrder label) and PO#, from a made-up Repair Order.
                Func<string,bool,List<ControlInfo>> window=delegate(string po,bool number) {
                    var s=Ro(new Fixture {Po=po});
                    if(number) { s.Add(Mk(60,150,ST,700,20,90,18,"RepairOrder"));var box=Mk(61,150,ED,795,20,90,20,"07000123");box.Style=0x800;s.Add(box); }
                    return s;
                };
                Func<ControlInfo,string> words=delegate(ControlInfo c) { return c.Text; };
                var seen=RoPeek.Find(window("TTW0000414",true),words);
                Check(seen.Doc=="07000123"&&seen.Po=="TTW0000414","Its number and PO# read: "+seen.Doc+" / "+seen.Po);
                seen=RoPeek.Find(window("",false),words);
                Check(seen.Doc==null&&seen.Po=="","No RepairOrder label: no number; an empty PO#.");
                var odd=window("ABC1",true);odd.RemoveAll(c=>c.Handle==13);
                seen=RoPeek.Find(odd,words);
                Check(seen.Doc=="07000123"&&seen.Po==null,"No PO# label: no PO# (nothing guessed).");
                var label=window("ABC1",true);label.Find(c=>c.Handle==61).Text="RO 7";
                Check(RoPeek.Find(label,words).Doc==null,"A box beside the label that isn't a number: no number.");
            });
            Case("A Repair Order left open closed first for a new phone job too (2.6.10): the same rules as the phone's Repair Orders; never one held for a person (with why) or an eBay order's; a job waits a while for a quiet moment, never for ever",()=>{
                Func<string,RoPeek.Seen> read=delegate(string p) { return new RoPeek.Seen {Doc="07000123",Po=p}; };
                Check(WorkerEngine.KeepOpen(null,null,true,null)==null&&WorkerEngine.KeepOpen(null,null,true,read("ABC1"))==null&&WorkerEngine.KeepOpen(null,null,true,read(""))==null,"Nothing held, nothing asked, nobody at the PC, not an online or eBay order's: closed first.");
                string held=WorkerEngine.KeepOpen("the phone job waiting for review: press Next Order on the desk PC",null,true,read("ABC1"));
                Check(held=="it is the phone job waiting for review: press Next Order on the desk PC","Held for a person: stays, with why: "+held);
                Check(WorkerEngine.KeepOpen("x","COSTAR is asking something on it",false,read("TTW0000414"))=="it is x","Held comes first.");
                string asked=WorkerEngine.KeepOpen(null,"COSTAR is asking something on it",true,read("ABC1"));
                Check(asked!=null&&asked.Contains("Answer it at the PC"),"COSTAR asking something on it: stays, nothing answered: "+asked);
                string busy=WorkerEngine.KeepOpen(null,null,false,null);
                Check(busy!=null&&busy.Contains("nobody has used the PC for "+RoEngine.CloseQuietSeconds+" s"),"Someone used the PC: stays until it has been quiet: "+busy);
                string online=WorkerEngine.KeepOpen(null,null,true,read("TTW0000414"));
                Check(online!=null&&online.Contains("online order TTW0000414"),"An online order's PO#: stays: "+online);
                string ebay=WorkerEngine.KeepOpen(null,null,true,read(" 12-34567-89012 "));
                Check(ebay!=null&&ebay.Contains("eBay order 12-34567-89012")&&ebay.Contains("Finish or close it at the PC"),"An eBay order's PO#: stays: "+ebay);
                Check(WorkerEngine.KeepOpen(null,null,true,read("12-34567-8901"))==null&&WorkerEngine.KeepOpen(null,null,true,read("12345678901"))==null,"Only an eBay order number's form counts as one.");
                Check(RoEngine.KeepOpen(false,null,true,read("12-34567-89012"))==null,"The phone's Repair Orders (COSTAR Tempe only) as in 2.6.7.");
                string unread=WorkerEngine.KeepOpen(null,null,true,new RoPeek.Seen());
                Check(unread!=null&&unread.Contains("didn't answer"),"Its PO# couldn't be read: stays: "+unread);
                Check(WorkerEngine.CloseWaitSeconds>=RoEngine.CloseQuietSeconds*5&&WorkerEngine.CloseWaitSeconds<=120,"A started job waits a while for a quiet moment, never for ever: "+WorkerEngine.CloseWaitSeconds+" s.");
                // "Start this job again" keeps the Repair Order it set aside for the job's new start (a field the
                // journal reads back; older journals don't have it).
                var j=Wire.Read<WorkerJournal>(Wire.Json(new WorkerJournal {setAside=new List<MobileCheckpoint>{new MobileCheckpoint {window=4242,processId=7}}}));
                Check(j.setAside!=null&&j.setAside.Count==1&&j.setAside[0].window==4242&&j.setAside[0].processId==7,"The set-aside Repair Order is kept in the journal.");
                Check(Wire.Read<WorkerJournal>("{\"releasedByHand\":false}").setAside==null,"An older journal reads without it.");
            });
            Case("Add new only on Work-in-Progress (2.6.8): COSTAR Sydney left on \"Orders yet to be filled\" (wholesale orders) is never asked for a new order; the list title read, said, and nothing else from its labels",()=>{
                // The title over the main window's list: the topmost wide label, the leftmost when level (29 Oct 01:05
                // map: the title [208,67] spans the list; a wide status line lower down; search labels too narrow to count).
                Func<int,int,string,Tuple<int,int,string>> at=(top,left,words)=>Tuple.Create(top,left,words);
                var wide=new List<Tuple<int,int,string>>{at(287,216,"Some status words"),at(75,216,"Orders yet to be filled")};
                Check(CostarWindows.Title(wide)=="Orders yet to be filled","The list title is the topmost wide label: "+CostarWindows.Title(wide));
                Check(CostarWindows.Title(new List<Tuple<int,int,string>>{at(75,645,"Later"),at(75,216,"Work-in-Progress")})=="Work-in-Progress","Two level: the leftmost.");
                Check(CostarWindows.Title(new List<Tuple<int,int,string>>())==""&&CostarWindows.Title(new List<Tuple<int,int,string>>{at(75,216,"  "),at(287,216,"Orders yet to be filled")})=="","No wide label, or an empty one on top: nothing read (never a lower label).");
                Check(CostarWindows.TitleWidth>235&&CostarWindows.TitleWidth<1713,"Wide: more than the search labels (235 px), less than the title on the PC (1713 px).");
                // Only COSTAR's own short words: anything longer or odd (a customer's words in a label) is never said.
                Check(CostarWindows.TitleWords("  Orders yet to be filled ")=="Orders yet to be filled"&&CostarWindows.TitleWords("Work-in-Progress")=="Work-in-Progress","Titles kept (trimmed).");
                Check(CostarWindows.TitleWords("")==null&&CostarWindows.TitleWords(null)==null&&CostarWindows.TitleWords(new string('A',41))==null&&CostarWindows.TitleWords("Order #12345")==null&&CostarWindows.TitleWords("12345")==null,"Empty, over 40 letters, other characters, a number: not a title.");
                string unnamed=CostarWindows.Title(new List<Tuple<int,int,string>>{at(75,216,"Order #12345")});
                Check(unnamed==CostarWindows.UnnamedList&&CostarWindows.OtherList(unnamed),"A title that isn't plain words: another list all the same.");
                // Another list: refused at once. Work-in-Progress named but not found (loading), or nothing read (busy): looked at again.
                Check(CostarWindows.OtherList("Orders yet to be filled")&&CostarWindows.OtherList("Quotes"),"Another list's title: another list.");
                Check(!CostarWindows.OtherList("Work-in-Progress")&&!CostarWindows.OtherList("work-in-progress")&&!CostarWindows.OtherList("")&&!CostarWindows.OtherList(new string('A',41)),"Work-in-Progress itself, or nothing readable: not another list (waited for).");
                Check(CostarWindows.WipWaitMs>=3000&&CostarWindows.WipWaitMs<=30000,"A busy COSTAR is waited for a while, never for ever.");
                string sydney=CostarWindows.NotOnWip("Branch 1 (SYDNEY)","Orders yet to be filled");
                Check(sydney.Contains("\"Orders yet to be filled\", not Work-in-Progress")&&sydney.Contains("Put it back on Work-in-Progress")&&sydney.Contains("Branch 1 (SYDNEY)"),"Says which COSTAR, what it shows and what to do: "+sydney);
                string busy=CostarWindows.NotOnWip("Branch 11 (TEMPE)",""),loading=CostarWindows.NotOnWip("Branch 11 (TEMPE)","Work-in-Progress");
                Check(busy.Contains("isn't answering")&&loading.Contains("isn't ready yet"),"Nothing read: not answering. Named but not found: not ready yet.");
                string odd=CostarWindows.NotOnWip("Branch 1 (SYDNEY)",unnamed);
                Check(!odd.Contains("12345")&&odd.Contains("is showing another list, not Work-in-Progress"),"A title that isn't plain words is never repeated: "+odd);
                // The stop is counted as its own kind, and never read as an open Repair Order the phone may close first.
                foreach(string m in new[]{sydney,busy,loading,odd}) {
                    Check(StopCategory.Of(m+". Add new was not pressed.",false)=="not_on_wip","Its own stop category: "+StopCategory.Of(m+". Add new was not pressed.",false));
                    Check(!m.StartsWith("A Repair Order is open",StringComparison.Ordinal),"Not the open-Repair-Order wait (2.6.7 close-first).");
                }
                Check(StopCategory.Of("COSTAR's all-branch customer search did not finish within 15 s. Check the search window, then retry.",false)=="customer_lookup","Other stops keep their kind.");
            });
            Case("Repair Orders print the Job Card (2.6.2): a print request (no change), or with a change; one print per Repair Order at a time; the helper says it prints",()=>{
                var q=new RoQueue();var snap=Read(new Fixture());
                Reject(()=>q.Submit(Ask("print",null)),"A print needs a Repair Order.","number");
                var e=Edit(snap);e.print=true;Reject(()=>q.Submit(Ask("print",snap.doc,e)),"A print carries no change.","Only");
                var p1=q.Submit(Ask("print",snap.doc));Check(p1.status=="queued"&&p1.kind=="print","A print request waits for the helper.");
                Check(q.Submit(Ask("print",snap.doc)).id==p1.id,"A second print of the same Repair Order joins the first (never two prints).");
                var only=Edit(snap);only.print=true;Reject(()=>q.Submit(Ask("edit",snap.doc,only)),"Print alone isn't a change: a change needs something to change.","Nothing");
                var with=Edit(snap);with.customerWaiting="yes";with.print=true;var w=q.Submit(Ask("edit",snap.doc,with));
                var without=Wire.Copy(with);without.print=false;Check(with.ContentHash()!=without.ContentHash(),"Print is part of the change's fingerprint (an ID can't be sent again without it).");
                var r1=q.Poll(Hello(null,true,true,""));Check(r1.task.kind=="print"&&r1.task.doc==snap.doc&&r1.task.edit==null,"The print goes to the helper.");
                var r2=q.Poll(Hello(Report(r1,"done",1),true,true,""));Check(r2.task.kind=="edit"&&r2.task.edit.print,"A change with print goes with its print flag.");
                // A helper that doesn't print (it changed version since the phone looked): a print never goes to it.
                var q2=new RoQueue();var lone=q2.Submit(Ask("print",snap.doc));var r3=q2.Poll(Hello(null,true,true,"",1000,false));
                Check(r3.command=="wait"&&q2.Get(lone.id).status=="failed"&&q2.Get(lone.id).message.Contains("doesn't print Job Cards"),"A print isn't handed to a helper that doesn't print: it fails, nothing done: "+q2.Get(lone.id).message);
                var q3=new RoQueue();var pw=Edit(snap);pw.customerWaiting="yes";pw.print=true;var e3=q3.Submit(Ask("edit",snap.doc,pw));var r4=q3.Poll(Hello(null,false,false,"",1000,false));
                Check(r4.command=="wait"&&q3.Get(e3.id).status=="failed"&&!q3.Get(e3.id).typed&&q3.Get(e3.id).message.StartsWith("Not saved",StringComparison.Ordinal),"Nor a change with its print (even while the helper is busy): nothing typed, said why.");
                var q4=new RoQueue();var np=Edit(snap);np.customerWaiting="yes";var e4=q4.Submit(Ask("edit",snap.doc,np));var r5=q4.Poll(Hello(null,true,true,"",1000,false));
                Check(r5.command=="do"&&r5.task.id==e4.id&&!r5.task.edit.print,"A change without print goes to any helper, as before.");
                var q6=new RoQueue();var handed=q6.Submit(Ask("print",snap.doc));
                Check(q6.Poll(Hello(null,true,true,"",1000,true)).task.id==handed.id,"Handed to a helper that prints.");
                var r6=q6.Poll(Hello(null,true,true,"",1000,false));
                Check(r6.command=="wait"&&q6.Get(handed.id).status=="failed","Not taken yet, and the helper no longer prints: not handed over again: "+q6.Get(handed.id).message);
                var settings=new ReceiverSettings {address="192.168.1.2",phoneToken="phone-test",workerToken="worker-test",workerId="test-worker"};
                var api=new ReceiverApi(settings,new JobQueue(null,s=>{}),Path.GetTempPath(),()=>false,id=>{});api.UseRo(new RoQueue());
                Func<bool> prints=()=>(bool)((Dictionary<string,object>)Body<Dictionary<string,object>>(api.Handle(Request("GET","/api/mobile/v1/ro/list","phone-test")))["helper"])["print"];
                Check(!prints(),"No helper in touch: no print offered.");
                api.Handle(Request("POST","/api/worker/v1/ro","worker-test",null,new RoHello{workerId="test-worker",accepting=true,available=true}));
                Check(!prints(),"An older helper: no print offered.");
                api.Handle(Request("POST","/api/worker/v1/ro","worker-test",null,new RoHello{workerId="test-worker",accepting=true,available=true,print=true}));
                Check(prints()&&(bool)Body<Dictionary<string,object>>(api.Handle(Request("GET","/api/mobile/v1/health","phone-test")))["roPrint"],"A 2.6.2 helper: the phone offers Print the Job Card.");
                // 2.6.11: Clear COSTAR's filter is offered only when the helper says it clears it.
                Func<bool> clears=()=>(bool)((Dictionary<string,object>)Body<Dictionary<string,object>>(api.Handle(Request("GET","/api/mobile/v1/ro/list","phone-test")))["helper"])["clears"];
                Check(!clears(),"A helper before 2.6.11: no clear offered.");
                api.Handle(Request("POST","/api/worker/v1/ro","worker-test",null,new RoHello{workerId="test-worker",accepting=true,available=true,print=true,clears=true}));
                Check(clears(),"A 2.6.11 helper: the phone offers Clear COSTAR's filter.");
            });
        }
    }
}
