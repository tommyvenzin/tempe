using System;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    // COSTAR shows its branch in every window title: "COSTAR:  11 Tempe Tyres Tempe   v5.7.6.0
    // (sql-Server:Tempe)" for the main window, "RepairOrder Branch 11 Tempe Tyres Tempe" for an
    // order. Until 2.3.0 only Branch 11 was accepted. Now any branch open in this session can be
    // selected, and every Repair Order the helper touches must belong to the selected branch.
    internal static class Branches {
        static readonly Regex MainPattern=new Regex(@"^COSTAR:\s*(\d{1,3})\s+(\S.*)$",RegexOptions.IgnoreCase);
        static readonly Regex OrderPattern=new Regex(@"^RepairOrder\s+Branch\s+(\d{1,3})(?=\s|$)",RegexOptions.IgnoreCase);
        static readonly Regex VersionTail=new Regex(@"\s+v\d+(?:\.\d+)+.*$",RegexOptions.IgnoreCase);
        static readonly Regex StateTail=new Regex(@"\s+(?:NSW|VIC|QLD|SA|WA|TAS|NT|ACT)$");
        static int Number(Match m) { int n; return m.Success&&Int32.TryParse(m.Groups[1].Value,NumberStyles.Integer,CultureInfo.InvariantCulture,out n)&&n>0?n:0; }
        // Branch number in a COSTAR main-window title, or 0 if it is not one.
        internal static int OfMain(string title) { return Number(MainPattern.Match(title??"")); }
        // "Tempe Tyres Tempe" from the main-window title (without the version and server).
        internal static string NameOfMain(string title) {
            var m=MainPattern.Match(title??"");
            return m.Success?Regex.Replace(VersionTail.Replace(m.Groups[2].Value,""),@"\s+"," ").Trim():"";
        }
        // Branch number in a Repair Order title, or 0 if it is not one.
        internal static int OfOrder(string title) { return Number(OrderPattern.Match(title??"")); }
        internal static bool MainTitle(string title,int branch) { return branch>0 && OfMain(title)==branch; }
        internal static bool OrderTitle(string title,int branch) { return branch>0 && OfOrder(title)==branch; }
        // Before 2.3.0 everything was Branch 11, so a saved job without a branch is Branch 11.
        internal static int OrLegacy(int branch) { return branch>0?branch:11; }
        // The place in a branch name: "Tempe Tyres Tempe" -> "TEMPE".
        internal static string Place(string branchName) {
            string n=Order.Norm(branchName);
            if(n.StartsWith("TEMPE TYRES ",StringComparison.Ordinal)) n=n.Substring(12).Trim();
            return n;
        }
        // Does an online order's store ("Tempe NSW") belong to this branch ("Tempe Tyres Tempe")?
        // Strict: the store's place must equal the branch's place. Anything else is confirmed by
        // a person before entry.
        internal static bool StoreMatches(string store,string branchName) {
            string s=StateTail.Replace(Order.Norm(store),"").Trim(),b=Place(branchName);
            Func<string,string> squash=delegate(string v){return Regex.Replace(v,"[^A-Z0-9]","");};
            return s.Length>0 && b.Length>0 && squash(s)==squash(b);
        }
    }
    internal sealed class CostarInstance {
        internal readonly int Pid,Session,Branch;
        internal readonly long MainWindow,Started;
        internal readonly string Title,BranchName;
        internal CostarInstance(int pid,long window,long started,int session,string title) {
            Pid=pid;MainWindow=window;Started=started;Session=session;Title=title;
            Branch=Branches.OfMain(title);BranchName=Branches.NameOfMain(title);
        }
        internal bool Same(CostarInstance other) { return other!=null && Pid==other.Pid && MainWindow==other.MainWindow && Started==other.Started && Session==other.Session && Branch==other.Branch; }
        // "Branch 11 (Tempe)" for messages.
        internal string Label { get { string place=Branches.Place(BranchName); return "Branch "+Branch+(place.Length>0?" ("+place+")":""); } }
        public override string ToString() { return Label+" | PID "+Pid+" | Window "+MainWindow+" | "+Title+(OrderCheckLink.IsWipWindow(this)?" | Order Check's WIP window (not used for entry)":""); }
    }
    // What the helper is doing right now, for the window's header (2.4.0): who is entering what,
    // which stage of how many, since when, and how the last entry ended. Written from the entry
    // threads, read by the UI timer; copies only, so no lock is held across UI work.
    internal sealed class EntryProgress {
        internal sealed class View { internal string Owner="",Reference="",Stage="",LastLine="";internal int Step,Steps;internal DateTime Started,LastAt;internal bool LastOk=true,Active; }
        readonly object gate=new object();readonly View state=new View();
        internal void Begin(string owner,string reference,int steps) { lock(gate) { state.Owner=owner??"";state.Reference=reference??"";state.Steps=steps;state.Step=0;state.Stage="Starting";state.Started=DateTime.Now;state.Active=true; } }
        internal void Stage(string stage,int step,int steps) { lock(gate) { if(!state.Active) return;state.Stage=stage??"";state.Step=step;if(steps>0) state.Steps=steps; } }
        internal void End(bool ok,string line) { lock(gate) { if(!state.Active) return;state.Active=false;state.Owner="";state.Stage="";state.LastOk=ok;state.LastLine=line??"";state.LastAt=DateTime.Now; } }
        internal View Read() { lock(gate) return new View { Owner=state.Owner,Reference=state.Reference,Stage=state.Stage,LastLine=state.LastLine,Step=state.Step,Steps=state.Steps,Started=state.Started,LastAt=state.LastAt,LastOk=state.LastOk,Active=state.Active }; }
    }
    // UI selection, mobile dispatch and online entry share this gate. A lease
    // freezes the selected instance until the entire run (including cleanup) ends.
    internal sealed class EntryCoordinator {
        internal readonly EntryProgress Progress=new EntryProgress();
        readonly object gate=new object();CostarInstance selected;EntryLease active;bool paused;DateTime lastReleased=DateTime.MinValue;
        internal CostarInstance Selected {get{lock(gate)return selected;}}
        internal bool Busy {get{lock(gate)return active!=null;}}
        internal string Owner {get{lock(gate)return active==null?"":active.Owner;}}
        // MobilePaused: the Online orders tab is showing. 2.9.3 (Tommy, 9 Nov: "This should never happen, it is mobile for
        // a reason"): it holds phone jobs and phone Repair Orders back only while someone is using the PC (a person's key or
        // mouse within OnlineHoldMs, the helper's own typing neither counting nor hiding theirs: Native.MsSinceInput;
        // unknown: held, as before); an Online tab left open on a PC nobody is using holds nothing back. SinceInputMs:
        // tests give their own.
        internal bool MobilePaused {get{lock(gate)return paused;}set{lock(gate)paused=value;}}
        internal const int OnlineHoldMs=120000;
        internal Func<long> SinceInputMs=delegate { return Native.MsSinceInput(); };
        internal static bool Holds(long msSinceInput) { return msSinceInput<0||msSinceInput<OnlineHoldMs; }
        internal bool MobileHeld { get { bool p;lock(gate)p=paused;return p&&Holds(SinceInputMs()); } }
        internal void Select(CostarInstance target) {lock(gate){Order.Require(active==null,"Wait for the current entry to finish before changing COSTAR.");selected=target;}}
        internal EntryLease TryBegin(string owner,bool mobile) {
            lock(gate) {
                if(active!=null || selected==null || (mobile&&paused&&Holds(SinceInputMs())))return null;
                active=new EntryLease(this,selected,owner);return active;
            }
        }
        // 2.5.0: eBay orders go into their own COSTAR (Branch 1, Sydney), whichever one is selected
        // for mobile and online orders. Still one entry at a time, through the same gate.
        internal EntryLease TryBegin(string owner,CostarInstance target) {
            lock(gate) {
                if(active!=null || target==null)return null;
                active=new EntryLease(this,target,owner);return active;
            }
        }
        // 2.6.3: the map (read only) holds COSTAR for its few seconds, so nothing is typed meanwhile; it
        // needs no COSTAR selected (Target may be null).
        internal EntryLease TryBeginRead(string owner) {
            lock(gate) {
                if(active!=null)return null;
                active=new EntryLease(this,selected,owner);return active;
            }
        }
        // The COSTAR the running entry types into (null when idle).
        internal CostarInstance ActiveTarget {get{lock(gate)return active==null?null:active.Target;}}
        internal void Release(EntryLease lease) {lock(gate){if(Object.ReferenceEquals(active,lease)){active=null;lastReleased=DateTime.UtcNow;}}}
        // 2.8.1: when the last entry (or read of COSTAR by the helper) ended, UTC: an order from the Tempe Orders page is
        // checked only against a read of COSTAR that began after it.
        internal DateTime LastReleasedUtc {get{lock(gate)return lastReleased;}}
    }
    internal sealed class EntryLease:IDisposable {
        readonly EntryCoordinator coordinator;
        internal readonly CostarInstance Target;internal readonly string Owner;
        internal EntryLease(EntryCoordinator owner,CostarInstance target,string name){coordinator=owner;Target=target;Owner=name;}
        public void Dispose(){coordinator.Release(this);}
    }
    internal sealed class CostarInputLock:IDisposable {
        internal const string Name=@"Local\TempeCostarAutofill_v01";
        readonly Mutex mutex;bool held;
        internal CostarInputLock() {
            mutex=new Mutex(false,Name);
            try {
                try{held=mutex.WaitOne(0);}catch(AbandonedMutexException){held=true;}
                Order.Require(held,"Another COSTAR helper is entering data or the old standalone autofill is open. Close the old helper and try again.");
            } catch {mutex.Dispose();throw;}
        }
        public void Dispose(){if(held){held=false;mutex.ReleaseMutex();}mutex.Dispose();}
        internal static bool LegacyOpen(){Mutex m;try{if(Mutex.TryOpenExisting(Name,out m)){m.Dispose();return true;}}catch(UnauthorizedAccessException){return true;}return false;}
    }
}
