// 2.6.5 (Tommy, 28 Oct: "it looks like its clicking instead of like native", then "full gas no brakes"):
// COSTAR's buttons, tick boxes, tabs and boxes pressed directly, the way COSTAR's own code does it, instead
// of moving the mouse over them. From the maps of 28 Oct (CostarMap, claude/10-COSTAR-Map-Notes.md): COSTAR
// is WinForms; its buttons and tick boxes are button windows that take BM_CLICK (their own click: the helper
// already pressed Search, Cancel and Yes that way); its toolbars are drawn (ToolStrip): their buttons are
// pressed through accessibility; its tabs are a Windows tab control; a box gets the keyboard with Windows'
// SetFocus. Keys stay real keys (Tab, Enter, Escape, Delete, the note's letter): COSTAR needs them as they
// are (25 Oct: a note is only kept after a real key press). Every direct press is checked by what it does;
// the mouse is the fallback only where a second press can't do harm, and nothing is pressed twice that
// could open or print twice. Taking a Repair Order line out is left as in 2.6.4 (the review of 28 Oct: the
// line menu's Delete may act on lines selected before). Off (Files & settings): the mouse, as in 2.6.4.
// 2.6.6 (28 Oct, a car change from the phone): the boxes of the Repair Order's item lines (item code, words,
// quantity, price, the note lines) are clicked again, as in 2.6.4: COSTAR's item lines follow the line that is
// clicked, and took the keyboard back from a note line given it directly (Runner.Focus: grid).
using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace TempeCostar {
    internal static class Direct {
        // On unless switched off on the Files & settings tab (AppSettings.directPresses).
        internal static volatile bool On=true;
        // The last look's answer when somebody is at the COSTAR PC (it stops what was to be pressed).
        internal const string PcInUse="someone is using the COSTAR PC";
        internal const uint BmClick=0xF5,TcmSetCurFocus=0x1330,TcmGetItemCount=0x1304;
        [DllImport("user32.dll")] static extern IntPtr SetFocus(IntPtr h);
        [DllImport("user32.dll")] static extern bool AttachThreadInput(uint from,uint to,bool attach);
        [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
        [DllImport("user32.dll",EntryPoint="PostMessageW")] static extern bool PostMessage(IntPtr h,uint msg,UIntPtr w,IntPtr l);
        [StructLayout(LayoutKind.Sequential)] struct Msg { public IntPtr h;public uint msg;public UIntPtr w;public IntPtr l;public uint time;public Native.Point p; }
        [DllImport("user32.dll",EntryPoint="PeekMessageW")] static extern bool PeekMessage(out Msg m,IntPtr h,uint min,uint max,uint remove);

        // The keyboard to h without the mouse: Windows' SetFocus from COSTAR's own input queue, joined to it
        // for that moment (as Windows' own accessibility tools do), on a thread of its own so a COSTAR that
        // doesn't answer can't hold the helper. COSTAR sees what it sees after a click into the box: the box
        // it leaves is checked and left, the new one entered. False when it didn't come back within ms (or
        // couldn't be done); the caller checks where the keyboard is either way. The wait ends at a Stop
        // (cancelled). COSTAR answering late (a question of its own while the box it leaves is checked): the
        // keyboard goes there once that is answered, as after a click on the box.
        internal static bool Focus(IntPtr h,int ms,Func<bool> cancelled=null) {
            uint pid;uint target=Native.GetWindowThreadProcessId(h,out pid);
            if(target==0) return false;
            bool done=false;
            var th=new Thread(delegate() {
                try {
                    Msg m;PeekMessage(out m,IntPtr.Zero,0,0,0);   // this thread's input queue (joining needs one)
                    uint me=GetCurrentThreadId();
                    if(!AttachThreadInput(me,target,true)) return;
                    try { SetFocus(h);done=true; }
                    finally { AttachThreadInput(me,target,false); }
                } catch(Exception) { }
            });
            th.IsBackground=true;th.Start();
            var timer=System.Diagnostics.Stopwatch.StartNew();
            while(!th.Join(Math.Max(1,Math.Min(50,ms-(int)timer.ElapsedMilliseconds)))) {
                if(timer.ElapsedMilliseconds>=ms||(cancelled!=null&&cancelled())) return false;
            }
            return done;
        }
        // What follows a direct press of a tick box (sent: as Press returns; now: the tick read after it, null
        // when it couldn't be read): "done" (it shows `want`), "click" (COSTAR took the press and the tick reads
        // unchanged: one real click may follow), "leave" (it may still change: the press wasn't answered, or the
        // tick can't be read: no second press).
        internal static string AfterPress(int sent,bool? now,bool want) {
            if(now==want) return "done";
            if(sent==0||now==null) return "leave";
            return "click";
        }
        // BM_CLICK sent: the button's own click, for one that doesn't open anything (a tick box). 1 COSTAR
        // answered (the click went), 0 not within ms (it may still go: no second press then), -1 not sent.
        internal static int Press(IntPtr h,int ms) {
            if(!Native.IsWindow(h)) return -1;
            UIntPtr result;
            IntPtr r=Native.SendNull(h,BmClick,UIntPtr.Zero,IntPtr.Zero,0x0002,(uint)Math.Max(1,ms),out result);
            if(r!=IntPtr.Zero) return 1;
            return Marshal.GetLastWin32Error()==1460?0:-1;   // ERROR_TIMEOUT: still on its way
        }
        // BM_CLICK posted: for a button that opens, closes or prints (a sent one would wait for all of that).
        // True when it is on its way.
        internal static bool PressLater(IntPtr h) { return Native.IsWindow(h)&&PostMessage(h,BmClick,UIntPtr.Zero,IntPtr.Zero); }
        // A tab of a Windows tab control shown: TCM_SETCURFOCUS, which tells COSTAR as a click on the tab does
        // (TCN_SELCHANGING, TCN_SELCHANGE). True when the tab control answered.
        internal static bool ShowTab(IntPtr strip,int index,int ms) {
            if(!Native.IsWindow(strip)||index<0) return false;
            UIntPtr result;
            return Native.SendNull(strip,TcmSetCurFocus,new UIntPtr((uint)index),IntPtr.Zero,0x0002,(uint)Math.Max(1,ms),out result)!=IntPtr.Zero;
        }

        // Accessibility's default action ("Press", "Check", "Switch") on an object `find` returns, all on a
        // thread of its own: COSTAR may come back from a press only once the window it opened closes (the
        // print form, a question). find: the object (with child, a simple child's number, or null) or null
        // when it isn't there (why: its reason); called on that thread, the objects released there.
        // State: 0 looking for it, 1 pressed (the action went to COSTAR), 2 given up (it never will be).
        // Refused: the last look's no (its reason), kept apart from FindError so nothing writes over it.
        internal sealed class Pending {
            internal int State;internal volatile string FindError,PressError,Refused;internal volatile bool Returned;
            internal readonly ManualResetEvent Ready=new ManualResetEvent(false);
        }
        internal delegate Accessibility.IAccessible Finder(out object child,out string why);
        // gate: checked on that thread just before the press (null: go; else why not: never pressed), so the
        // last look is right before it however long finding it took (nobody at the PC, COSTAR in front and
        // free ...).
        internal static Pending Act(Finder find,Func<string> gate=null) {
            var a=new Pending();
            var th=new Thread(delegate() {
                Accessibility.IAccessible acc=null;object child=null;
                try {
                    string why;acc=find(out child,out why);
                    if(acc==null) { if(Thread.VolatileRead(ref a.State)==0) a.FindError=why??"not found";return; }
                    string stop=gate==null?null:gate();
                    if(stop!=null) { a.Refused=stop;if(Thread.VolatileRead(ref a.State)==0) a.FindError=stop;return; }
                    if(Interlocked.CompareExchange(ref a.State,1,0)!=0) return;   // given up meanwhile: never pressed
                    a.Ready.Set();
                    try { if(child==null) acc.accDoDefaultAction(0); else acc.accDoDefaultAction(child);a.Returned=true; }
                    catch(Exception e) { a.PressError=e.Message; }
                } catch(Exception e) { int st=Thread.VolatileRead(ref a.State);if(st==1) a.PressError=e.Message; else if(st==0) a.FindError=e.Message; }
                finally { a.Ready.Set();Msaa.Release(child);Msaa.Release(acc); }
            });
            th.IsBackground=true;
            // Accessibility calls from a thread of the multi-threaded apartment (as Search's press since 2.6.1).
            try { th.SetApartmentState(ApartmentState.MTA); } catch(PlatformNotSupportedException) { }   // the self-tests' runtime
            th.Start();
            return a;
        }
        // What came of an Act: "pressed" (found within findMs and its action went to COSTAR without failing
        // within failMs: it may still be running, with a window it opened open), "not pressed" (not found,
        // greyed, or given up in time: nothing went to COSTAR; FindError says why), "failed" (the press itself
        // failed: whether COSTAR did anything can't be told, so nothing more is pressed).
        internal static string Went(Pending a,int findMs,int failMs) {
            if(!a.Ready.WaitOne(findMs)&&Interlocked.CompareExchange(ref a.State,2,0)==0) { if(a.FindError==null) a.FindError="not found within "+(findMs/100/10.0).ToString("0.0",System.Globalization.CultureInfo.InvariantCulture)+" s";return "not pressed"; }
            if(Thread.VolatileRead(ref a.State)!=1) return "not pressed";
            var timer=System.Diagnostics.Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<failMs&&!a.Returned&&a.PressError==null) Thread.Sleep(20);
            return a.PressError==null?"pressed":"failed";
        }
    }
}
