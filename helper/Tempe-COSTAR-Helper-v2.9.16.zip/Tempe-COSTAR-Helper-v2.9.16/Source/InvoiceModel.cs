// 2.9.15 "Invoice read (dry run)" (spec of 20 Nov 2026): the CORE. Reads a COSTAR Invoice window that staff have already
// opened, from a snapshot of its controls (every box's text read by the live side, InvoiceLive.cs), so its information can
// prepare Buffalo (freight carrier) delivery labels. READ + PREPARE ONLY: nothing here sells, saves, types, books, submits
// or prints; Sold stays a permanently disabled button (InvoiceDryRun.SellingEnabled). Pure: the self-tests
// (InvoiceTests.cs) give it a made-up Invoice window built from the real map's geometry (map-20261103-144735.json, the
// only Invoice ever mapped: "Invoice  Branch 1  Tempe Tyres Sydney", 1074 x 1040).
// The layout is matched by COSTAR's labels and relative geometry (a label above its box, a box right of its label, a
// line's box under its heading by x), never by absolute pixel constants alone:
//  - Identity: the box right of the "Invoice" label (the number), the "(Order WO...)" label (the source order), the status
//    label under "Invoice" ("Open"), the caption (branch number and name).
//  - Header: Order Date / Ship Date / Invoice Date (COSTAR date panels: their window text, never guessed), Terms,
//    Salesperson, Written By, Time in, Promised (drop-downs: their inner edit), PO#, Comment (right of its label), the
//    price-level label right of the Account# / Name label.
//  - X: the customer frame (COSTAR's labels; the address, suburb, state and postcode boxes have none: described honestly).
//  - Y: the Ship to page, readable only while it is the selected tab (hidden pages aren't visible to Windows); never
//    switched. Its Account# and Name boxes have no COSTAR label.
//  - Lines: one heading panel ("#", Item, Description, Size / Complete?, Qty or Hrs, List, Disc, Net, Tax, &TaxIn), 25 line
//    panels with a number label each; boxes matched to headings by x; the headingless line total right of Tax; the two
//    narrow boxes behind the Item kept as hidden extra values; a note line's 600+ px words box. More than 25 lines: the
//    live side pages the grid's own scroll bar and Merge joins the screens by COSTAR's line number (never guessed).
//  - Totals: the panel holding "Tax In": amounts under their headings by x overlap.
// Privacy: customer words (names, addresses, phones, emails, notes) are only ever in Review/Buffalo (shown in the helper's
// own window, copied by a person's click). LogLine and the incomplete reasons carry counts, states, COSTAR's own labels and
// the invoice number only.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace TempeCostar {
    // The dry-run guarantee (1): selling is off and can't be switched on at run time.
    internal static class InvoiceDryRun { internal const bool SellingEnabled=false; }

    // One field read off the invoice. Section: "X","Y","Header","Identity","Totals". Label: COSTAR's own text
    // (CostarLabel) or an honest description. Value: exact, outer-trimmed only; null when not read. State: "read",
    // "empty", "not read" (Why says why). Role: a fixed key (x.account, y.shipvia, header.po ...). Other: a labelled box
    // the spec doesn't name ("other field"). Why may also annotate a read value (a date panel's window text).
    internal sealed class InvoiceField {
        public string Section;public string Label;public bool CostarLabel;public string Value;public string State;public string Why;
        public string Role;public bool Other;
    }
    // One invoice line. Number: COSTAR's line number (its label). Item: outer-trimmed only; ItemRaw: as read. Kind:
    // "product","freight" (Item F),"possible-freight" (freight words, Item not F),"note". Unread: columns not read.
    internal sealed class InvoiceLine {
        public int Number;public string Item;public string ItemRaw;public string Description;public string Size;public string Qty;public string List;public string Disc;public string Net;public string Tax;public string LineTotal;public string Note;
        public List<string> Hidden=new List<string>();public string Kind;public List<string> Unread=new List<string>();
    }
    // One screen of lines. ScrollPos / ScrollMax: set by the live side from the grid's scroll bar (ScrollMax: the highest
    // position the bar can reach, nMax - max(nPage,1) + 1). Numbers: every line number label seen, filled or empty.
    internal sealed class InvoicePage {
        public List<InvoiceLine> Lines=new List<InvoiceLine>();public int ScrollPos;public bool ScrollEnabled;public int ScrollMax;public string Fingerprint;
        public List<int> Numbers=new List<int>();
    }
    internal sealed class InvoiceRead {
        public string Number;public string SourceOrder;public string Status;public int Branch;public string BranchName;public string Caption;
        public List<InvoiceField> Fields=new List<InvoiceField>();public List<InvoiceLine> Lines=new List<InvoiceLine>();public bool LinesComplete;public string LinesWhy;
        public List<InvoiceField> Totals=new List<InvoiceField>();public string FreightState;public string FreightText;public List<string> Problems=new List<string>();
        public bool YShown;public string YWhy;public bool Complete;public string Fingerprint;
        // Beyond the contract: why the read is incomplete (no customer words), observations, the lines-vs-total check,
        // the raw "(Order ...)" label, a refusal (message + a code for the log), the number of line labels read.
        public List<string> Incomplete=new List<string>();public List<string> Observations=new List<string>();public string CrossCheck;
        public string SourceOrderRaw;public string Refused;public string RefusedCode;public int LinesSeen;
    }

    internal static class InvoiceReader {
        internal const int ReadOnly=0x800;     // ES_READONLY
        internal const int Multiline=0x4;      // ES_MULTILINE
        // COSTAR's line headings (whitespace normalised: "Qty   or Hrs" is QTY OR HRS). "Warr" and "Credit Reason" are inside
        // an opened line's own panel, never headings.
        static readonly string[] Columns={"ITEM","DESCRIPTION","SIZE","QTY OR HRS","LIST","DISC","NET","TAX"};
        static readonly Regex CaptionRule=new Regex(@"^Invoice\s+Branch\s+(\d{1,3})\s+(.*)$",RegexOptions.CultureInvariant);
        static readonly Regex OrderLabel=new Regex(@"^\(\s*Order\s+([^)]*?)\s*\)$",RegexOptions.CultureInvariant|RegexOptions.IgnoreCase);

        internal static bool IsInvoiceCaption(string caption,out int branch,out string branchName) {
            branch=0;branchName=null;
            var m=CaptionRule.Match(caption??"");
            if(!m.Success) return false;
            branch=Int32.Parse(m.Groups[1].Value,CultureInfo.InvariantCulture);branchName=m.Groups[2].Value.Trim();
            return true;
        }
        // The live side gives the window's caption here (Parse only sees the controls).
        internal static void SetCaption(InvoiceRead r,string caption) {
            int b;string name;r.Caption=caption;
            if(IsInvoiceCaption(caption,out b,out name)) { r.Branch=b;r.BranchName=name; }
        }
        // A result the live side refuses (nothing prepared): message shown, code logged.
        internal static InvoiceRead Refusal(string code,string message) {
            return new InvoiceRead {Refused=message,RefusedCode=code,Complete=false,FreightState="unreadable"};
        }
        // The live side's own reason the read is incomplete (no customer words: the run's own words).
        internal static void MarkIncomplete(InvoiceRead r,string why) {
            if(r==null||String.IsNullOrEmpty(why)) return;
            if(!r.Incomplete.Contains(why)) r.Incomplete.Add(why);
            r.Complete=false;
        }
        // The "Expected invoice #" check: null when fine (nothing typed in the box, or exactly the number read).
        internal static string ExpectedProblem(InvoiceRead r,string expected) {
            string want=(expected??"").Trim();
            if(want.Length==0) return null;
            if(r==null||r.Number==null) return "The open invoice's number could not be read, so it can't be checked against "+want+": nothing was prepared.";
            return String.Equals(r.Number,want,StringComparison.Ordinal)?null:InvoicePreview.NotExpected(r.Number,want);
        }

        // ---- small helpers ----
        static bool Near(int a,int b,int t) { return Math.Abs(a-b)<=t; }
        static string Norm(string s) { return Order.Norm(s); }
        static string Safe(Func<ControlInfo,string> text,ControlInfo c) {
            if(c==null) return null;
            try { return text(c); } catch(Exception) { return null; }
        }
        static string Words(ControlInfo c,Func<ControlInfo,string> text) { string p=c.Peek;return p??Safe(text,c); }
        static bool Has(ControlInfo c,string part) { return c.Class!=null&&c.Class.IndexOf(part,StringComparison.OrdinalIgnoreCase)>=0; }
        static bool IsBox(ControlInfo c) { return c.Visible&&!c.Password&&Has(c,"EDIT")&&c.RelativeBounds!=null&&c.W>20&&c.H>10; }
        static bool IsCombo(ControlInfo c) { return c.Visible&&Has(c,"COMBOBOX")&&c.RelativeBounds!=null&&c.W>20&&c.H>10; }
        static bool IsLabel(ControlInfo c) { return c.Static&&c.RelativeBounds!=null; }
        // A COSTAR panel with no child windows (a date panel draws its own date).
        static bool IsLeafPanel(List<ControlInfo> s,ControlInfo c) {
            return c.Visible&&c.RelativeBounds!=null&&Has(c,".Window.")&&c.W>20&&c.H>10&&!s.Any(x=>x.Parent==c.Handle);
        }
        static List<ControlInfo> Labels(List<ControlInfo> s,Func<ControlInfo,string> text,string words,long parent) {
            return s.Where(c=>IsLabel(c)&&(parent==0||c.Parent==parent)&&Norm(Words(c,text))==words).ToList();
        }
        // The box directly under a label (same rule as EbaySelectors.UnderLabel / Selectors.Under, also taking a drop-down
        // and, when panels is set, a date panel): same parent first, then by place alone. null: none or more than one.
        static ControlInfo Under(List<ControlInfo> s,ControlInfo l,bool panels) {
            int t=Math.Max(4,l.H/3);
            Func<ControlInfo,bool> kind=delegate(ControlInfo c) { return !Object.ReferenceEquals(c,l)&&(IsBox(c)||IsCombo(c)||(panels&&IsLeafPanel(s,c))); };
            var same=s.Where(c=>kind(c)&&c.Parent==l.Parent&&Near(c.X,l.X,t)&&Near(c.Y,l.Y+l.H,t)).ToList();
            if(same.Count==1) return same[0];
            if(same.Count>1) return null;
            var any=s.Where(c=>kind(c)&&Near(c.X,l.X,t+2)&&Near(c.Y,l.Y+l.H,t+2)).ToList();
            if(any.Count==1) return any[0];
            // A drop-down's inner edit sits a few px inside it: the drop-down when exactly one holds them all.
            var combos=any.Select(c=>IsCombo(c)?c:s.FirstOrDefault(p=>p.Handle==c.Parent&&IsCombo(p))).Where(c=>c!=null).Distinct().ToList();
            return combos.Count==1&&any.All(c=>c==combos[0]||c.Parent==combos[0].Handle)?combos[0]:null;
        }
        // The words of a box: a drop-down's inner edit when it has exactly one, else its own.
        static string BoxText(List<ControlInfo> s,ControlInfo box,Func<ControlInfo,string> text) {
            if(box==null) return null;
            if(IsCombo(box)) {
                var inner=s.Where(c=>c.Parent==box.Handle&&c.Visible&&!c.Password&&Has(c,"EDIT")).ToList();
                if(inner.Count==1) return Safe(text,inner[0]);
            }
            return Safe(text,box);
        }
        static InvoiceField Field(string section,string role,string label,bool costar,string value,string notReadWhy) {
            var f=new InvoiceField {Section=section,Role=role,Label=label,CostarLabel=costar};
            if(value==null) { f.State="not read";f.Why=notReadWhy??"could not be read"; }
            else { f.Value=value.Trim();f.State=f.Value.Length==0?"empty":"read"; }
            return f;
        }
        static InvoiceField BoxField(List<ControlInfo> s,Func<ControlInfo,string> text,HashSet<long> used,string section,string role,string label,bool costar,ControlInfo box,string missing) {
            if(box==null) return Field(section,role,label,costar,null,missing);
            used.Add(box.Handle);
            foreach(var c in s.Where(c=>c.Parent==box.Handle)) used.Add(c.Handle);
            string v=BoxText(s,box,text);
            return Field(section,role,label,costar,v,v==null?"its box could not be read":null);
        }
        // A field under its COSTAR label (exactly one label with these words; parent 0: anywhere).
        static InvoiceField Labelled(List<ControlInfo> s,Func<ControlInfo,string> text,HashSet<long> used,HashSet<long> usedLabels,string section,string role,string words,string fallbackLabel,long parent,bool panels) {
            var ls=Labels(s,text,words,parent);
            if(ls.Count!=1) return Field(section,role,fallbackLabel,true,null,ls.Count==0?"its label \""+fallbackLabel+"\" wasn't found":"its label \""+fallbackLabel+"\" shows "+ls.Count+" times");
            usedLabels.Add(ls[0].Handle);
            string label=(Words(ls[0],text)??fallbackLabel).Trim();
            var box=Under(s,ls[0],panels);
            return BoxField(s,text,used,section,role,label,true,box,"no box under its label");
        }

        // ---- the whole read ----
        internal static InvoiceRead Parse(List<ControlInfo> s,Func<ControlInfo,string> text,string selectedTab,List<InvoicePage> pages,string pagingWhy) {
            var r=new InvoiceRead();
            if(s==null) s=new List<ControlInfo>();
            var used=new HashSet<long>();var usedLabels=new HashSet<long>();
            Identity(r,s,text,used,usedLabels);
            Header(r,s,text,used,usedLabels);
            XFields(r,s,text,used,usedLabels);
            YFields(r,s,text,selectedTab,used,usedLabels);
            OtherFields(r,s,text,selectedTab,used,usedLabels);
            Totals(r,s,text);
            Lines(r,s,text,pages,pagingWhy);
            Freight(r);
            CrossCheck(r);
            Compare(r);
            Completeness(r);
            r.Fingerprint=Fingerprint(s,text);
            return r;
        }

        static void Identity(InvoiceRead r,List<ControlInfo> s,Func<ControlInfo,string> text,HashSet<long> used,HashSet<long> usedLabels) {
            var ls=Labels(s,text,"INVOICE",0);
            ControlInfo box=null;string why=null;
            if(ls.Count!=1) why=ls.Count==0?"the \"Invoice\" label wasn't found":"the \"Invoice\" label shows "+ls.Count+" times";
            else {
                usedLabels.Add(ls[0].Handle);
                box=Beside(s.Where(IsBox).ToList(),ls[0]);
                if(box==null) why="no box right of the \"Invoice\" label";
            }
            var number=BoxField(s,text,used,"Identity","identity.number",ls.Count==1?(Words(ls[0],text)??"Invoice").Trim():"Invoice",true,box,why);
            if(number.State=="empty") { number.State="not read";number.Why="the number box is empty";number.Value=null; }
            r.Fields.Add(number);r.Number=number.Value;
            // The source order: "(Order WO4305893)".
            var orders=s.Where(c=>IsLabel(c)&&OrderLabel.IsMatch((Words(c,text)??"").Trim())).ToList();
            if(orders.Count==1) {
                usedLabels.Add(orders[0].Handle);
                string raw=(Words(orders[0],text)??"").Trim();r.SourceOrderRaw=raw;
                r.SourceOrder=OrderLabel.Match(raw).Groups[1].Value.Trim();
                r.Fields.Add(Field("Identity","identity.order","Source order (from COSTAR's label \""+raw+"\")",false,r.SourceOrder,null));
            } else r.Fields.Add(Field("Identity","identity.order","Source order (COSTAR's \"(Order ...)\" label)",false,null,orders.Count==0?"no \"(Order ...)\" label shows":"\"(Order ...)\" shows "+orders.Count+" times"));
            // The status label under "Invoice" ("Open").
            if(ls.Count==1) {
                var l=ls[0];
                var st=s.Where(c=>IsLabel(c)&&!Object.ReferenceEquals(c,l)&&c.Parent==l.Parent&&Near(c.X,l.X,4)&&c.Y>l.Y+4&&c.Y<=l.Y+l.H+12).ToList();
                if(st.Count==1) { usedLabels.Add(st[0].Handle);string v=Words(st[0],text);r.Fields.Add(Field("Identity","identity.status","Status (COSTAR's label under \"Invoice\")",false,v,"its label could not be read"));r.Status=v==null?null:v.Trim(); }
                else r.Fields.Add(Field("Identity","identity.status","Status (COSTAR's label under \"Invoice\")",false,null,st.Count==0?"no status label under \"Invoice\"":"several labels under \"Invoice\""));
            } else r.Fields.Add(Field("Identity","identity.status","Status (COSTAR's label under \"Invoice\")",false,null,"the \"Invoice\" label wasn't found"));
        }
        // The nearest box on the label's line, to its right (as WholesaleOrderReader.Beside: 8 px, 400 px at most).
        static ControlInfo Beside(List<ControlInfo> boxes,ControlInfo label) {
            int ly=label.Y+label.H/2,lr=label.X+label.W;ControlInfo best=null;
            foreach(var c in boxes) {
                if(Object.ReferenceEquals(c,label)||!c.Visible||c.RelativeBounds==null) continue;
                if(Math.Abs(c.Y+c.H/2-ly)>8||c.X<lr-4||c.X>lr+400) continue;
                if(best==null||c.X<best.X) best=c;
            }
            return best;
        }
        static void Header(InvoiceRead r,List<ControlInfo> s,Func<ControlInfo,string> text,HashSet<long> used,HashSet<long> usedLabels) {
            // COSTAR's date panels: their window text (the 3 Nov map: each a panel of its own under its label).
            foreach(var d in new[]{new[]{"header.orderdate","ORDER DATE","Order Date"},new[]{"header.shipdate","SHIP DATE","Ship Date"},new[]{"header.invoicedate","INVOICE DATE","Invoice Date"}}) {
                var ls=Labels(s,text,d[1],0);
                if(ls.Count!=1) { r.Fields.Add(Field("Header",d[0],d[2],true,null,ls.Count==0?"its label wasn't found":"its label shows "+ls.Count+" times"));continue; }
                usedLabels.Add(ls[0].Handle);
                string label=(Words(ls[0],text)??d[2]).Trim();
                var box=Under(s,ls[0],true);
                if(box==null) { r.Fields.Add(Field("Header",d[0],label,true,null,"not read (date panel): nothing found under its label"));continue; }
                used.Add(box.Handle);
                string v=BoxText(s,box,text);
                if(IsBox(box)||IsCombo(box)) { r.Fields.Add(Field("Header",d[0],label,true,v,"its box could not be read"));continue; }
                // A date panel: read only when it gives words; never guessed.
                if(v==null||v.Trim().Length==0) r.Fields.Add(Field("Header",d[0],label,true,null,"not read (date panel)"));
                else { var f=Field("Header",d[0],label,true,v,null);f.Why="from COSTAR's date panel (its window text)";r.Fields.Add(f); }
            }
            r.Fields.Add(Labelled(s,text,used,usedLabels,"Header","header.terms","TERMS","Terms",0,false));
            r.Fields.Add(Labelled(s,text,used,usedLabels,"Header","header.salesperson","SALESPERSON","Salesperson",0,false));
            r.Fields.Add(Labelled(s,text,used,usedLabels,"Header","header.writtenby","WRITTEN BY","Written By",0,false));
            r.Fields.Add(Labelled(s,text,used,usedLabels,"Header","header.timein","TIME IN","Time in",0,false));
            r.Fields.Add(Labelled(s,text,used,usedLabels,"Header","header.promised","PROMISED","Promised",0,false));
            r.Fields.Add(Labelled(s,text,used,usedLabels,"Header","header.po","PO#","PO#",0,false));
            // Comment: the box right of its label (Selectors.FieldRightOf's rule).
            var cl=Labels(s,text,"COMMENT",0);
            if(cl.Count==1) {
                usedLabels.Add(cl[0].Handle);var l=cl[0];int mid=l.Y+l.H/2;
                var boxes=s.Where(c=>IsBox(c)&&c.X>=l.X+l.W-6&&c.X<=l.X+l.W+40&&Math.Abs(c.Y+c.H/2-mid)<=6).ToList();
                r.Fields.Add(BoxField(s,text,used,"Header","header.comment",(Words(l,text)??"Comment").Trim(),true,boxes.Count==1?boxes[0]:null,boxes.Count==0?"no box right of its label":"several boxes right of its label"));
            } else r.Fields.Add(Field("Header","header.comment","Comment",true,null,cl.Count==0?"its label wasn't found":"its label shows "+cl.Count+" times"));
        }
        // X's anchor: the one "Account#   ...   Name" label.
        static ControlInfo AccountLabel(List<ControlInfo> s,Func<ControlInfo,string> text) {
            var ls=s.Where(c=>IsLabel(c)&&Norm(Words(c,text)).StartsWith("ACCOUNT#",StringComparison.Ordinal)&&Norm(Words(c,text)).EndsWith("NAME",StringComparison.Ordinal)).ToList();
            return ls.Count==1?ls[0]:null;
        }
        internal static readonly string[] Unlabelled={"address line 1","address line 2","suburb","state","postcode"};
        static string NoLabel(string what) { return "(no COSTAR label: "+what+")"; }
        // The customer block (X or Y) from its account box: name beside it, two address lines under the name, the
        // suburb / state / postcode row (Selectors.Header / Delivery geometry, but never throwing: a field it can't place is
        // "not read" with why).
        static void Block(InvoiceRead r,List<ControlInfo> s,Func<ControlInfo,string> text,HashSet<long> used,string section,long parent,int anchorX,int rowY,int t,string accountLabel,bool accountCostar,string nameLabel,bool nameCostar,string missing) {
            string p=section.ToLowerInvariant()+".";
            var boxes=s.Where(c=>IsBox(c)&&c.Parent==parent).ToList();
            ControlInfo account=null,name=null,a1=null,a2=null,sub=null,state=null,post=null;
            string why=missing;
            if(why==null) {
                var first=boxes.Where(c=>Near(c.Y,rowY,t)).OrderBy(c=>c.X).ToList();
                if(first.Count==2&&first[0].W<first[1].W&&Near(first[0].X,anchorX,t)) { account=first[0];name=first[1]; }
                else why="its Account# / Name boxes are not laid out as expected ("+first.Count+" boxes on that row)";
            }
            if(name!=null) {
                var l1=boxes.Where(c=>Near(c.X,anchorX,t)&&Near(c.Y,name.Y+name.H,t)&&c.W>name.W).ToList();if(l1.Count==1) a1=l1[0];
                if(a1!=null) { var l2=boxes.Where(c=>Near(c.X,anchorX,t)&&Near(c.Y,a1.Y+a1.H,t)&&Near(c.W,a1.W,t)).ToList();if(l2.Count==1) a2=l2[0]; }
                int cityY=a2!=null?a2.Y+a2.H:a1!=null?a1.Y+2*a1.H:name.Y+3*name.H;
                var city=boxes.Where(c=>Near(c.Y,cityY,t)).OrderBy(c=>c.X).ToList();
                if(city.Count==3&&Near(city[0].X,anchorX,t)&&city[0].W>city[1].W&&city[2].W>city[1].W) { sub=city[0];state=city[1];post=city[2]; }
            }
            string w=why??"not found where COSTAR puts it";
            r.Fields.Add(BoxField(s,text,used,section,p+"account",accountLabel,accountCostar,account,w));
            r.Fields.Add(BoxField(s,text,used,section,p+"name",nameLabel,nameCostar,name,w));
            r.Fields.Add(BoxField(s,text,used,section,p+"addr1",NoLabel(Unlabelled[0]),false,a1,w));
            r.Fields.Add(BoxField(s,text,used,section,p+"addr2",NoLabel(Unlabelled[1]),false,a2,w));
            r.Fields.Add(BoxField(s,text,used,section,p+"suburb",NoLabel(Unlabelled[2]),false,sub,w));
            r.Fields.Add(BoxField(s,text,used,section,p+"state",NoLabel(Unlabelled[3]),false,state,w));
            r.Fields.Add(BoxField(s,text,used,section,p+"postcode",NoLabel(Unlabelled[4]),false,post,w));
        }
        static readonly string[][] Contacts={new[]{"contact","CONTACT","Contact"},new[]{"busph","BUS PH","Bus Ph"},new[]{"homeph","HOME PH","Home Ph"},new[]{"email","EMAIL","eMail"},new[]{"mobile","MOBILE PH","Mobile Ph"},new[]{"fax","FAX","Fax"}};
        static void XFields(InvoiceRead r,List<ControlInfo> s,Func<ControlInfo,string> text,HashSet<long> used,HashSet<long> usedLabels) {
            var a=AccountLabel(s,text);
            if(a==null) {
                Block(r,s,text,used,"X",0,0,0,4,"Account#",true,"Name",true,"X's \"Account# ... Name\" label wasn't found");
                foreach(var c in Contacts) r.Fields.Add(Field("X","x."+c[0],c[2],true,null,"X's \"Account# ... Name\" label wasn't found"));
                return;
            }
            usedLabels.Add(a.Handle);
            var words=Regex.Split((Words(a,text)??"").Trim(),@"\s+");
            int t=Math.Max(4,a.H/3);
            Block(r,s,text,used,"X",a.Parent,a.X,a.Y+a.H,t,words[0],true,words[words.Length-1],true,null);
            foreach(var c in Contacts) r.Fields.Add(Labelled(s,text,used,usedLabels,"X","x."+c[0],c[1],c[2],a.Parent,false));
            // The price level: the label right of the Account# label, on its line ("Platinum").
            var lv=s.Where(c=>IsLabel(c)&&!Object.ReferenceEquals(c,a)&&c.Parent==a.Parent&&Near(c.Y,a.Y,3)&&c.X>a.X+20).ToList();
            if(lv.Count==1) { usedLabels.Add(lv[0].Handle);r.Fields.Add(Field("Header","header.pricelevel","Price level label",false,Words(lv[0],text),"its label could not be read")); }
            else r.Fields.Add(Field("Header","header.pricelevel","Price level label",false,null,lv.Count==0?"no label right of Account#":"several labels right of Account#"));
        }
        static readonly string[][] Shipping={new[]{"shipvia","SHIP VIA","Ship Via"},new[]{"shipterms","SHIPTERMS","ShipTerms"},new[]{"instructions","SHIPPING INSTRUCTIONS","Shipping Instructions"}};
        internal const string YAccount="Account# (no COSTAR label; same place as X's)",YName="Name (no COSTAR label; same place as X's)";
        static void YFields(InvoiceRead r,List<ControlInfo> s,Func<ControlInfo,string> text,string selectedTab,HashSet<long> used,HashSet<long> usedLabels) {
            var vias=Labels(s,text,"SHIP VIA",0);
            string why=null;
            if(selectedTab!=null) {
                if(Norm(selectedTab)!="SHIP TO") why=InvoicePreview.YNotShown(selectedTab.Trim());
                else if(vias.Count!=1) why="not read: the Ship to page's boxes were not found (its Ship Via label shows "+vias.Count+" times)";
            } else {
                if(EbaySelectors.OnShipToTab(s)&&vias.Count==1) r.Observations.Add("COSTAR's selected tab could not be told; Y was read because the Ship to page's Ship Via label is showing.");
                else why="not read: the Ship to page is not showing (its Ship Via label wasn't found) – click Ship to in COSTAR, then press Read again";
            }
            if(why!=null) {
                r.YShown=false;r.YWhy=why;
                foreach(var f in YList()) r.Fields.Add(Field("Y",f[0],f[1],f[2]=="1",null,why));
                return;
            }
            r.YShown=true;
            var via=vias[0];usedLabels.Add(via.Handle);long parent=via.Parent;int t=Math.Max(4,via.H/3);
            // Y's first row: the topmost boxes of the Ship to page at Ship Via's x (X's Account# row when X was found).
            var xa=r.Fields.FirstOrDefault(f=>f.Role=="x.account");
            var boxes=s.Where(c=>IsBox(c)&&c.Parent==parent&&Near(c.X,via.X,t)).OrderBy(c=>c.Y).ToList();
            ControlInfo xAccount=null;
            var a=AccountLabel(s,text);if(a!=null) xAccount=s.FirstOrDefault(c=>IsBox(c)&&c.Parent==a.Parent&&Near(c.X,a.X,Math.Max(4,a.H/3))&&Near(c.Y,a.Y+a.H,Math.Max(4,a.H/3)));
            int rowY=xAccount!=null&&xa!=null?xAccount.Y:boxes.Count>0?boxes[0].Y:-1000;
            Block(r,s,text,used,"Y",parent,via.X,rowY,t,YAccount,false,YName,false,boxes.Count==0?"the Ship to page shows no boxes":null);
            foreach(var c in Contacts) r.Fields.Add(Labelled(s,text,used,usedLabels,"Y","y."+c[0],c[1],c[2],parent,false));
            foreach(var c in Shipping) r.Fields.Add(Labelled(s,text,used,usedLabels,"Y","y."+c[0],c[1],c[2],parent,false));
        }
        // Y's fields in order: role, label, COSTAR's label ("1") or a description ("0").
        static List<string[]> YList() {
            var l=new List<string[]>{new[]{"y.account",YAccount,"0"},new[]{"y.name",YName,"0"}};
            for(int i=0;i<Unlabelled.Length;i++) l.Add(new[]{"y."+new[]{"addr1","addr2","suburb","state","postcode"}[i],NoLabel(Unlabelled[i]),"0"});
            foreach(var c in Contacts) l.Add(new[]{"y."+c[0],c[2],"1"});
            foreach(var c in Shipping) l.Add(new[]{"y."+c[0],c[2],"1"});
            return l;
        }
        // Labelled boxes the spec doesn't name, in the header / X / Y area (above the lines' headings): "<label>: <value>",
        // so nothing available is silently dropped.
        static void OtherFields(InvoiceRead r,List<ControlInfo> s,Func<ControlInfo,string> text,string selectedTab,HashSet<long> used,HashSet<long> usedLabels) {
            // The lines start at their headings' panel (its labels: "#", Item ... at y 340).
            var heads=s.Where(c=>IsLabel(c)&&Norm(Words(c,text))=="ITEM").ToList();
            int top=Int32.MaxValue;
            foreach(var h in heads) foreach(var c in s.Where(c=>IsLabel(c)&&c.Parent==h.Parent)) top=Math.Min(top,c.Y);
            var a=AccountLabel(s,text);var via=Labels(s,text,"SHIP VIA",0);
            var byHandle=new Dictionary<long,ControlInfo>();foreach(var c in s) byHandle[c.Handle]=c;
            Func<ControlInfo,long,bool> inside=delegate(ControlInfo c,long frame) {
                if(frame==0) return false;long p=c.Parent;
                for(int i=0;i<10&&p!=0;i++) { if(p==frame) return true;ControlInfo up;if(!byHandle.TryGetValue(p,out up)) return false;p=up.Parent; }
                return false;
            };
            // The tab control's pages (Ship to / Rebill to / Contacts / Notes): only the Ship to page is read (as Y); a box on
            // another page is that tab's, never a header field.
            var tabControls=s.Where(c=>c.Visible&&Has(c,"SysTabControl32")).Select(c=>c.Handle).ToList();
            bool otherTab=false;
            foreach(var l in s.Where(c=>IsLabel(c)&&c.Y<top&&c.Y>=0&&!usedLabels.Contains(c.Handle)).OrderBy(c=>c.Y).ThenBy(c=>c.X)) {
                string words=Words(l,text);if(words==null||words.Trim().Length==0) continue;
                var box=Under(s,l,true);
                if(box==null||used.Contains(box.Handle)) continue;
                bool inTab=tabControls.Any(t=>inside(box,t)||inside(l,t));
                bool onShipTo=r.YShown&&via.Count==1&&inside(box,via[0].Parent);
                if(inTab&&!onShipTo) { otherTab=true;continue; }
                string section=a!=null&&inside(box,a.Parent)?"X":via.Count==1&&inside(box,via[0].Parent)?"Y":"Header";
                if(section=="Y"&&!r.YShown) continue;
                var f=BoxField(s,text,used,section,"other",words.Trim(),true,box,null);f.Other=true;r.Fields.Add(f);
            }
            if(otherTab) r.Observations.Add("COSTAR's "+(String.IsNullOrEmpty(selectedTab)?"selected":selectedTab.Trim())+" tab shows boxes of its own: they were not read (only the Ship to page is read, as Y).");
        }

        // ---- totals ----
        static void Totals(InvoiceRead r,List<ControlInfo> s,Func<ControlInfo,string> text) {
            var taxIn=Labels(s,text,"TAX IN",0);
            if(taxIn.Count!=1) { r.Totals.Add(Field("Totals","totals.taxin","Tax In",true,null,taxIn.Count==0?"the totals' \"Tax In\" label wasn't found":"\"Tax In\" shows "+taxIn.Count+" times"));return; }
            var h=taxIn[0];
            var panel=s.Where(c=>IsLabel(c)&&c.Parent==h.Parent).ToList();
            var heads=panel.Where(c=>Near(c.Y,h.Y,3)).OrderBy(c=>c.X).ToList();
            var amounts=panel.Where(c=>c.Y>=h.Y+h.H-4&&!heads.Contains(c)).OrderBy(c=>c.X).ToList();
            var found=new Dictionary<ControlInfo,ControlInfo>();
            foreach(var m in amounts) {
                // Blank (read, nothing in it): skipped. Not read (null): kept, as not read, under its heading.
                string v=Words(m,text);if(v!=null&&v.Trim().Length==0) continue;
                ControlInfo best=null;int overlap=0;
                foreach(var hd in heads) { int o=Math.Min(m.X+m.W,hd.X+hd.W)-Math.Max(m.X,hd.X);if(o>overlap) { overlap=o;best=hd; } }
                string label=best==null?null:(Words(best,text)??"").Trim();
                if(best==null||label.Length==0) { var f=Field("Totals","totals.unlabelled","unlabelled total at x="+m.X.ToString(CultureInfo.InvariantCulture),false,v,"the amount there could not be read");r.Totals.Add(f);continue; }
                if(found.ContainsKey(best)) { r.Problems.Add("Totals: two amounts under \""+label+"\"");continue; }
                found[best]=m;
            }
            foreach(var hd in heads) {
                string label=(Words(hd,text)??"").Trim();if(label.Length==0) continue;
                ControlInfo m;
                if(found.TryGetValue(hd,out m)) r.Totals.Add(Field("Totals","totals."+Norm(label).Replace(" ","").ToLowerInvariant(),label,true,Words(m,text),"the amount under it could not be read"));
                else if(Norm(label)!="TOTALS") r.Totals.Add(Field("Totals","totals."+Norm(label).Replace(" ","").ToLowerInvariant(),label,true,"",null));
            }
            // Unlabelled ones last, by x.
            var un=r.Totals.Where(f=>f.Role=="totals.unlabelled").ToList();foreach(var f in un) { r.Totals.Remove(f);r.Totals.Add(f); }
        }
        // An amount as COSTAR shows it: InvariantCulture, commas, $, a minus (leading or trailing) allowed.
        internal static bool Money(string raw,out decimal value) {
            value=0;if(raw==null) return false;
            string t=raw.Trim().Replace("$","").Replace(",","").Replace(" ","");
            if(t.Length==0) return false;
            return Decimal.TryParse(t,NumberStyles.AllowLeadingSign|NumberStyles.AllowTrailingSign|NumberStyles.AllowDecimalPoint,CultureInfo.InvariantCulture,out value);
        }
        internal static string Amount(decimal d) { return d.ToString("0.00",CultureInfo.InvariantCulture); }

        // ---- lines ----
        // One screen of lines; null (and why) when the grid isn't an Invoice grid.
        internal static InvoicePage Page(List<ControlInfo> s,Func<ControlInfo,string> text,out string why) {
            why=null;
            if(s==null) { why="no controls were read";return null; }
            var groups=s.Where(c=>IsLabel(c)&&Array.IndexOf(Columns,Norm(Words(c,text)))>=0).GroupBy(c=>c.Parent)
                .Where(g=>g.Count(c=>Norm(Words(c,text))=="ITEM")==1&&g.Any(c=>Norm(Words(c,text))=="QTY OR HRS")).ToList();
            if(groups.Count!=1) { why=groups.Count==0?"the invoice's line headings (Item, Qty or Hrs) weren't found":"the line headings show "+groups.Count+" times";return null; }
            var head=new Dictionary<string,ControlInfo>(StringComparer.Ordinal);
            foreach(var c in groups[0]) { string k=Norm(Words(c,text));head[k]=head.ContainsKey(k)?null:c; }
            Func<string,ControlInfo> H=delegate(string k) { ControlInfo c;return head.TryGetValue(k,out c)?c:null; };
            ControlInfo item=H("ITEM"),desc=H("DESCRIPTION"),qty=H("QTY OR HRS");
            if(item==null||desc==null||qty==null) { why="the invoice's line headings are not as expected (Item, Description, Qty or Hrs)";return null; }
            var page=new InvoicePage();
            var bars=s.Where(c=>c.Visible&&Has(c,"SCROLLBAR")&&c.RelativeBounds!=null&&c.H>200&&c.X>qty.X).ToList();
            page.ScrollEnabled=bars.Any(c=>c.Enabled);
            var numbers=s.Where(c=>IsLabel(c)&&Regex.IsMatch((Words(c,text)??"").Trim(),@"^\d{1,3}$")&&c.X<item.X&&c.X>item.X-60&&c.Y>item.Y).ToList();
            if(numbers.Count==0) { why="the invoice's line numbers weren't found";return null; }
            // Every line must be known by its COSTAR number: a label in the number column that can't be read or isn't a
            // number, or an Item box with no number label beside it, fails the screen (a line lost at the end of the list
            // would otherwise still leave 1..N without gaps).
            foreach(var c in s.Where(c=>IsLabel(c)&&c.X<item.X&&c.X>item.X-60&&c.Y>item.Y)) {
                string w=Words(c,text);
                if(w==null) { why="a line number label could not be read (at y="+c.Y.ToString(CultureInfo.InvariantCulture)+")";return null; }
                if(w.Trim().Length>0&&!Regex.IsMatch(w.Trim(),@"^\d{1,3}$")) { why="a label in the line number column isn't a line number (at y="+c.Y.ToString(CultureInfo.InvariantCulture)+")";return null; }
            }
            foreach(var b in s.Where(c=>IsBox(c)&&Math.Abs(c.X-(item.X+2))<=4&&c.Y>item.Y))
                if(!numbers.Any(l=>l.Parent==b.Parent&&Math.Abs(b.Y-l.Y)<=4)) { why="a line's Item box (at y="+b.Y.ToString(CultureInfo.InvariantCulture)+") has no line number label";return null; }
            var seen=new HashSet<int>();
            var tax=H("TAX");
            var cols=new List<KeyValuePair<string,ControlInfo>>();
            foreach(var k in new[]{"ITEM","DESCRIPTION","SIZE","QTY OR HRS","LIST","DISC","NET","TAX"}) cols.Add(new KeyValuePair<string,ControlInfo>(k,H(k)));
            var sb=new StringBuilder();
            foreach(var label in numbers.OrderBy(c=>Int32.Parse((Words(c,text)??"").Trim(),CultureInfo.InvariantCulture))) {
                int n=Int32.Parse((Words(label,text)??"").Trim(),CultureInfo.InvariantCulture);
                if(!seen.Add(n)) { why="line "+n+" shows twice on one screen";return null; }
                page.Numbers.Add(n);
                var row=s.Where(c=>IsBox(c)&&c.Parent==label.Parent&&Math.Abs(c.Y-label.Y)<=4).ToList();
                var taken=new HashSet<ControlInfo>();var line=new InvoiceLine {Number=n};
                var problems=new List<string>();
                Func<ControlInfo,int,List<ControlInfo>> at=delegate(ControlInfo h,int x) { return h==null?new List<ControlInfo>():row.Where(b=>Math.Abs(b.X-x)<=4).ToList(); };
                // Each column: its box (null: none), and whether it was read.
                var values=new Dictionary<string,string>(StringComparer.Ordinal);var present=new Dictionary<string,bool>(StringComparer.Ordinal);
                ControlInfo descBox=null;
                foreach(var kv in cols) {
                    var bs=kv.Value==null?new List<ControlInfo>():at(kv.Value,kv.Value.X+2);
                    foreach(var b in bs) taken.Add(b);
                    if(bs.Count>1) { present[kv.Key]=true;values[kv.Key]=null;problems.Add("two boxes under "+ColumnName(kv.Key));continue; }
                    present[kv.Key]=bs.Count==1;
                    if(kv.Key=="DESCRIPTION"&&bs.Count==1) descBox=bs[0];
                    values[kv.Key]=bs.Count==1?Safe(text,bs[0]):"";
                }
                // The line total: COSTAR gives it no heading; its box starts right of Tax's heading (the &TaxIn button above it).
                var totals=tax==null?new List<ControlInfo>():row.Where(b=>Math.Abs(b.X-(tax.X+tax.W+1))<=4&&!taken.Contains(b)).ToList();
                foreach(var b in totals) taken.Add(b);
                present["TOTAL"]=totals.Count>=1;values["TOTAL"]=totals.Count==1?Safe(text,totals[0]):totals.Count==0?"":null;
                if(totals.Count>1) problems.Add("two boxes where the line total is");
                bool note=descBox!=null&&(descBox.W>=600||((descBox.Style&Multiline)!=0&&descBox.W>=600));
                string itemRaw=values["ITEM"];
                line.ItemRaw=itemRaw;line.Item=itemRaw==null?null:itemRaw.Trim();
                // Empty: nothing in the Item and nothing in any other column (the narrow boxes behind the Item don't count).
                bool empty=itemRaw!=null&&itemRaw.Trim().Length==0&&values.Where(kv=>kv.Key!="ITEM").All(kv=>kv.Value!=null&&kv.Value.Trim().Length==0);
                if(empty) { sb.Append(n).Append("=\n");continue; }
                bool othersEmpty=values.Where(kv=>kv.Key!="ITEM").All(kv=>kv.Value!=null&&kv.Value.Trim().Length==0);
                if(itemRaw==null&&othersEmpty&&!note) {
                    // Only the Item box, and it couldn't be read: filled or empty can't be told.
                    line.Kind="product";line.Unread.Add("Item");
                } else if(note) {
                    line.Kind="note";string words=values["DESCRIPTION"];
                    line.Note=words==null?null:words.Trim();if(words==null) line.Unread.Add("Note");
                    if(itemRaw==null) line.Unread.Add("Item");
                } else {
                    foreach(var kv in cols) {
                        string name=ColumnName(kv.Key);string v=values[kv.Key];
                        if(kv.Value==null) { line.Unread.Add(name);problems.Add("no "+name+" heading on the invoice");continue; }
                        if(!present[kv.Key]) { line.Unread.Add(name);problems.Add("no "+name+" box");continue; }
                        if(v==null) line.Unread.Add(name);
                    }
                    if(!present["TOTAL"]) { line.Unread.Add("Line total");problems.Add("no line total box"); }
                    else if(values["TOTAL"]==null) line.Unread.Add("Line total");
                    Func<string,string> trim=delegate(string k) { string v=values[k];return v==null||!present[k]?null:v.Trim(); };
                    line.Description=trim("DESCRIPTION");line.Size=trim("SIZE");line.Qty=trim("QTY OR HRS");line.List=trim("LIST");line.Disc=trim("DISC");line.Net=trim("NET");line.Tax=trim("TAX");line.LineTotal=trim("TOTAL");
                    line.Kind=Kind(line);
                }
                // Hidden extra values: the other boxes on the line's row (the narrow ones behind the Item).
                foreach(var b in row.Where(b=>!taken.Contains(b)).OrderBy(b=>b.X)) {
                    string v=Safe(text,b);
                    if(v==null) line.Hidden.Add("x="+b.X.ToString(CultureInfo.InvariantCulture)+": (could not be read)");
                    else if(v.Trim().Length>0) line.Hidden.Add("x="+b.X.ToString(CultureInfo.InvariantCulture)+": "+v.Trim());
                }
                foreach(var p in problems.Distinct()) line.Hidden.Add("problem: "+p);
                page.Lines.Add(line);
                sb.Append(n).Append('=').Append(Signature(line)).Append('\n');
            }
            page.Fingerprint=Hash(sb.ToString());
            return page;
        }
        internal static string ColumnName(string key) {
            switch(key) {
                case "ITEM": return "Item";case "DESCRIPTION": return "Description";case "SIZE": return "Size";case "QTY OR HRS": return "Qty or Hrs";
                case "LIST": return "List";case "DISC": return "Disc";case "NET": return "Net";case "TAX": return "Tax";default: return "Line total";
            }
        }
        // F (the project's rule: "Item F -> freight"); the wholesale freight words with no tyre size: possible freight.
        internal static string Kind(InvoiceLine l) {
            if(l.Kind=="note") return "note";
            if(l.Item!=null&&String.Equals(l.Item.Trim(),"F",StringComparison.OrdinalIgnoreCase)) return "freight";
            return WholesaleRules.KindOf(l.Item??"",l.Size??"",l.Description??"")=="freight"?"possible-freight":"product";
        }
        // Everything read on a line, for comparing two screens.
        static string Signature(InvoiceLine l) {
            var parts=new[]{l.Kind,l.ItemRaw,l.Description,l.Size,l.Qty,l.List,l.Disc,l.Net,l.Tax,l.LineTotal,l.Note,String.Join("\u0002",l.Hidden),String.Join(",",l.Unread)};
            return String.Join("\u0001",parts.Select(p=>p??"\u0003"));
        }
        // The screens joined by COSTAR's line number: a number seen twice must read the same, the numbers must be 1..N
        // without gaps, the scroll position must move between screens; anything else: false and why (never guessed).
        internal static bool Merge(List<InvoicePage> pages,out List<InvoiceLine> merged,out string why) {
            merged=new List<InvoiceLine>();why=null;
            if(pages==null||pages.Count==0||pages.Any(p=>p==null)) { why="no screen of lines was read";return false; }
            var sig=new Dictionary<int,string>();var lines=new Dictionary<int,InvoiceLine>();
            HashSet<int> before=null;Dictionary<int,string> beforeSig=null;
            for(int k=0;k<pages.Count;k++) {
                var p=pages[k];var mine=new Dictionary<int,string>();
                var numbers=p.Numbers!=null&&p.Numbers.Count>0?p.Numbers:p.Lines.Select(l=>l.Number).ToList();
                foreach(var n in numbers) mine[n]="";
                foreach(var l in p.Lines) { if(mine.ContainsKey(l.Number)&&mine[l.Number].Length>0) { why="line "+l.Number+" shows twice on screen "+(k+1);return false; } mine[l.Number]=Signature(l); }
                if(k>0) {
                    var prev=pages[k-1];
                    if(p.ScrollEnabled&&prev.ScrollEnabled&&p.ScrollPos<=prev.ScrollPos) { why="lines 26+ could not be read: the scroll position did not move between screens "+k+" and "+(k+1);return false; }
                    if(before.SetEquals(mine.Keys)&&mine.Any(kv=>beforeSig[kv.Key]!=kv.Value)) { why="lines 26+ could not be read: the line numbers did not change after a scroll while the lines' contents did";return false; }
                    if(before.SetEquals(mine.Keys)) { why="lines 26+ could not be read: the lines did not change after a scroll (screen "+(k+1)+")";return false; }
                }
                foreach(var kv in mine) {
                    string old;
                    if(sig.TryGetValue(kv.Key,out old)) { if(old!=kv.Value) { why="line "+kv.Key+" read differently on two pages";return false; } continue; }
                    sig[kv.Key]=kv.Value;
                    var l=p.Lines.FirstOrDefault(x=>x.Number==kv.Key);if(l!=null) lines[kv.Key]=l;
                }
                before=new HashSet<int>(mine.Keys);beforeSig=mine;
            }
            var all=sig.Keys.OrderBy(n=>n).ToList();
            for(int i=0;i<all.Count;i++) if(all[i]!=i+1) { why="the line numbers are not 1 to "+all[all.Count-1]+" without gaps: line "+(i+1)+" is missing";return false; }
            var last=pages[pages.Count-1];
            if(pages.Count>1&&last.ScrollEnabled&&last.ScrollMax>0&&last.ScrollPos<last.ScrollMax) { why="lines 26+ could not be read: the scroll bar did not reach its end";return false; }
            merged=all.Where(n=>lines.ContainsKey(n)).Select(n=>lines[n]).ToList();
            return true;
        }
        static void Lines(InvoiceRead r,List<ControlInfo> s,Func<ControlInfo,string> text,List<InvoicePage> pages,string pagingWhy) {
            if(pages==null||pages.Count==0) {
                string w;var p=Page(s,text,out w);
                if(p==null) { r.LinesComplete=false;r.LinesWhy=w;return; }
                pages=new List<InvoicePage>{p};
            }
            List<InvoiceLine> merged;string why;
            bool ok=Merge(pages,out merged,out why);
            r.LinesSeen=pages.Where(p=>p!=null).SelectMany(p=>p.Numbers!=null&&p.Numbers.Count>0?p.Numbers:p.Lines.Select(l=>l.Number).ToList()).Distinct().Count();
            if(!ok) { r.Lines=pages[0]==null?new List<InvoiceLine>():pages[0].Lines.ToList();r.LinesComplete=false;r.LinesWhy=why;return; }
            r.Lines=merged;r.LinesComplete=true;
            if(pagingWhy!=null) { r.LinesComplete=false;r.LinesWhy=pagingWhy.StartsWith("lines",StringComparison.OrdinalIgnoreCase)?pagingWhy:"lines 26+ could not be read: "+pagingWhy; }
            else if(pages.Count==1&&pages[0].ScrollEnabled) { r.LinesComplete=false;r.LinesWhy="lines 26+ could not be read: the line grid's scroll bar is on (more lines than show) but only the first screen was read"; }
        }

        // ---- freight, the lines-vs-total check, X vs Y ----
        static void Freight(InvoiceRead r) {
            var f=r.Lines.Where(l=>l.Kind=="freight").ToList();
            // Lines whose Item wasn't read: any of them could be an F line.
            var unread=r.Lines.Where(l=>l.Kind!="note"&&(l.Item==null||l.Unread.Contains("Item"))).Select(l=>l.Number.ToString(CultureInfo.InvariantCulture)).ToList();
            string unreadText=unread.Count==0?null:"the Item of "+(unread.Count==1?"line ":"lines ")+String.Join(", ",unread)+" could not be read, so another F line can't be ruled out";
            string partText=r.LinesComplete?null:"the lines are incomplete ("+(r.LinesWhy??"not read")+"), so more F lines may exist";
            if(f.Count==0) {
                if(!r.LinesComplete) { r.FreightState="unreadable";r.FreightText="Freight could not be read: the lines are incomplete ("+(r.LinesWhy??"not read")+") and no F line was among those read"; }
                else if(unread.Count>0) { r.FreightState="unreadable";r.FreightText="Freight could not be read: the Item of "+(unread.Count==1?"line ":"lines ")+String.Join(", ",unread)+" could not be read, so an F line can't be ruled out"; }
                else { r.FreightState="none";r.FreightText="No freight entry: no F line among all "+r.Lines.Count+" lines read"; }
                return;
            }
            var bad=new List<string>();var amounts=new List<KeyValuePair<InvoiceLine,decimal>>();
            foreach(var l in f) {
                decimal d;
                if(l.LineTotal==null) bad.Add("line "+l.Number+"'s Line total could not be read");
                else if(l.LineTotal.Trim().Length==0) bad.Add("line "+l.Number+"'s Line total is empty");
                else if(!Money(l.LineTotal,out d)) bad.Add("line "+l.Number+"'s Line total is not a number");
                else amounts.Add(new KeyValuePair<InvoiceLine,decimal>(l,d));
            }
            if(bad.Count>0) { r.FreightState="unreadable";r.FreightText="Freight could not be read: "+String.Join("; ",bad);return; }
            string which=(amounts.Count==1?"line ":"lines ")+String.Join(", ",amounts.Select(kv=>kv.Key.Number.ToString(CultureInfo.InvariantCulture)));
            if(amounts.All(kv=>kv.Value==0)) {
                // Zero is only stated when no other F line can be hiding (a later one could carry the charge).
                if(partText!=null||unreadText!=null) { r.FreightState="unreadable";r.FreightText="Freight could not be read: the F line read ("+which+") shows 0.00, but "+(partText??unreadText);return; }
                r.FreightState="zero";r.FreightText="Freight: 0.00 – an F line exists with amount zero ("+which+")";return;
            }
            r.FreightState="amount";
            r.FreightText="Freight: "+String.Join("; ",amounts.Select(kv=>kv.Key.LineTotal+" (line "+kv.Key.Number.ToString(CultureInfo.InvariantCulture)+", Item F)"));
            if(partText!=null) r.FreightText+=" – among the lines read only: "+partText;
            else if(unreadText!=null) r.FreightText+=" – "+unreadText;
        }
        static void CrossCheck(InvoiceRead r) {
            var taxIn=r.Totals.FirstOrDefault(t=>t.Role=="totals.taxin");var taxOut=r.Totals.FirstOrDefault(t=>t.Role=="totals.taxout");
            decimal total;
            if(taxIn==null||taxIn.Value==null||!Money(taxIn.Value,out total)) { r.CrossCheck="the lines could not be checked against the invoice total: its Tax In total "+(taxIn==null||taxIn.Value==null?"was not read":taxIn.Value.Length==0?"is empty":"is not a number");r.Problems.Add(r.CrossCheck);return; }
            decimal sum=0;var notRead=new List<int>();var empty=new List<int>();var notNumber=new List<int>();
            foreach(var l in r.Lines.Where(l=>l.Kind!="note")) {
                decimal d;
                if(l.LineTotal==null) notRead.Add(l.Number);
                else if(l.LineTotal.Trim().Length==0) empty.Add(l.Number);
                else if(Money(l.LineTotal,out d)) sum+=d;
                else notNumber.Add(l.Number);
            }
            if(notRead.Count+empty.Count+notNumber.Count>0) {
                var why=new List<string>();
                Func<List<int>,string> of=delegate(List<int> n) { return "the Line total of "+(n.Count==1?"line ":"lines ")+String.Join(", ",n); };
                if(notRead.Count>0) why.Add(of(notRead)+" was not read");
                if(empty.Count>0) why.Add(of(empty)+" is empty");
                if(notNumber.Count>0) why.Add(of(notNumber)+" is not a number");
                r.CrossCheck="the lines could not be added up: "+String.Join("; ",why);r.Problems.Add(r.CrossCheck);return;
            }
            if(sum==total) { r.CrossCheck="lines add up to the invoice total ("+Amount(total)+")";return; }
            decimal outTotal;
            if(taxOut!=null&&Money(taxOut.Value,out outTotal)&&sum==outTotal) { r.CrossCheck="lines add up to the invoice's Tax Out total ("+Amount(outTotal)+"), not its Tax In total ("+Amount(total)+")";r.Problems.Add(r.CrossCheck);return; }
            r.CrossCheck="lines add up to "+Amount(sum)+", invoice total is "+Amount(total)+": some lines may be missing or unread";
            r.Problems.Add(r.CrossCheck);
        }
        static readonly string[] Same={"account","name","addr1","addr2","suburb","state","postcode","contact","busph","homeph","email","mobile","fax"};
        static void Compare(InvoiceRead r) {
            if(!r.YShown) return;
            bool all=true;
            foreach(var k in Same) {
                var x=r.Fields.FirstOrDefault(f=>f.Role=="x."+k);var y=r.Fields.FirstOrDefault(f=>f.Role=="y."+k);
                if(x==null||y==null||x.Value==null||y.Value==null||!String.Equals(x.Value,y.Value,StringComparison.Ordinal)) { all=false;break; }
            }
            if(all) r.Observations.Add("Y is the same as X (an observation only: both are kept as read).");
        }
        static void Completeness(InvoiceRead r) {
            if(r.Number==null) r.Incomplete.Add("the invoice number could not be read");
            foreach(var sec in new[]{"X","Y"}) {
                if(sec=="Y"&&!r.YShown) { r.Incomplete.Add("Y (Ship to) "+r.YWhy);continue; }
                var miss=r.Fields.Where(f=>f.Section==sec&&!f.Other&&f.State=="not read").Select(f=>f.CostarLabel?f.Label:f.Label.Replace("(no COSTAR label: ","").TrimEnd(')')).ToList();
                if(miss.Count>0) r.Incomplete.Add(sec+": "+miss.Count+" field"+(miss.Count==1?"":"s")+" not read ("+String.Join(", ",miss)+")");
            }
            if(!r.LinesComplete) r.Incomplete.Add(r.LinesWhy??"the lines could not be read");
            foreach(var l in r.Lines.Where(l=>l.Unread.Count>0)) r.Incomplete.Add("line "+l.Number+": "+String.Join(", ",l.Unread)+" not read");
            foreach(var l in r.Lines) foreach(var h in l.Hidden.Where(h=>h.StartsWith("problem: ",StringComparison.Ordinal))) r.Problems.Add("line "+l.Number+": "+h.Substring(9));
            foreach(var l in r.Lines.Where(l=>l.Kind=="possible-freight")) r.Problems.Add("line "+l.Number+" may be freight by its words (its Item isn't F): review it");
            foreach(var l in r.Lines.Where(l=>l.Kind!="note"&&l.Item!=null&&l.Item.Length==0)) r.Problems.Add("line "+l.Number+" has no Item");
            r.Complete=r.Incomplete.Count==0;
        }

        // ---- the fingerprint ----
        // Everything showing in the window (each control's class, place, enabled and words), so any box typed in or any
        // line appearing changes it. A hash: the words themselves are never kept in it.
        internal static string Fingerprint(List<ControlInfo> s,Func<ControlInfo,string> text) {
            var parts=new List<string>();
            foreach(var c in s??new List<ControlInfo>()) {
                if(!c.Visible||c.RelativeBounds==null) continue;
                string v=Has(c,"BUTTON")?c.Peek:Safe(text,c);
                parts.Add((c.Class??"")+"@"+String.Join(",",c.RelativeBounds.Select(n=>n.ToString(CultureInfo.InvariantCulture)))+(c.Enabled?"":"!")+"="+(v??"\u0003"));
            }
            parts.Sort(StringComparer.Ordinal);
            return Hash(String.Join("\n",parts));
        }
        static string Hash(string s) {
            using(var sha=SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(s))).Replace("-","").ToLowerInvariant();
        }
    }

    // 2.9.16 (Tommy, 24 Nov 2026): how Tempe fills a Buffalo booking (the TransVirtual portal, account Tempe Tyres NSW).
    // Only two parts are filled: Receiver Information and Consignment Items; the sender, service level and the rest stay
    // as Buffalo fills them. Receiver: everything from Y (Ship to): name, the first address line only (Address 2 blank),
    // suburb, email, contact, phone (Mobile Ph, else Bus Ph, else Home Ph), reference = the Repair Order number (the
    // invoice's own number, 07xxxxxx, as on Buffalo's bookings). Items: one row per type, its Reference the Repair Order
    // number, Qty summed, Total Weight = Qty x the type's kg. The types are Buffalo's own Description list entries: PAS
    // (passenger, 8 kg), SUV (15 kg), TRUCK (40 kg), CARTON (20 kg). A tyre on a 17.5, 19.5 or 22.5 rim is TRUCK; else by
    // its width in mm: 215 or less PAS, over 215 SUV. A wheel is one CARTON each; a small box (nuts, bolts, locks, valves,
    // caps, plugs ...) is one CARTON for its line, whatever its qty. A plain charge or service (every word a charge's,
    // TYRE / WHEEL / & or a number: TYRE DISPOSAL LEVY, FIT & BAL) has nothing to send; freight (Item F) isn't an item.
    // A line is counted only on positive evidence; anything else is UNRESOLVED, never guessed (seven reviews of 2.9.16:
    // a wrong count in a freight booking is the failure to avoid). A tyre's or a wheel's line is counted only when it
    // names one item, once: no part's, service's, goods' or wheel's words beside a tyre's size, no tyre or package beside a
    // wheel's size, no set or count words (SET, PAIR, PACK, X4, (4 PCS)), no second item joined on (WITH, +, &, ON,
    // MOUNTED, COMBO; INC VALVE, INC CENTRE CAPS, M+S and BLACK & MACHINED are fine), not a credit, return, hire, quote or
    // back order, not a negative line, one tyre size only, and a wheel shown to be a wheel (a rim size, a wheel's word or
    // a finish: a stud pattern alone could be a hub ring). A truck size the wholesale rules don't read (9.5R17.5, 11 R22.5)
    // is TRUCK only when every other word is a plain truck tyre's (TYRE, STEER, DRIVE, a load index, a ply rating).
    // Fourth review: C/W, INC, PLUS or a spaced / joining a second item, a tyre's name on a wheel's line, a wheel's or a
    // tyre's word as the goods on a part's line (KING KAOS WHEEL + NUTS, 4X4 TYRE + VALVE, WHEEL & TYRE KIT), a lock ring,
    // side ring or run-flat insert, a press-on tyre's three-part size (21X7X15), more count words (4@$250, 2PC, 4 OFF) and
    // drop-ship or to-come words are UNRESOLVED too; so is a fitting, balancing, changeover, nitrogen or labour charge beside
    // tyres or wheels (sent fitted?).
    internal sealed class BuffaloLine {
        public int Number;public string Description;public string Type;public int Qty;public bool Unresolved;public string How;
        // A fitting, balancing, changeover, nitrogen or labour charge (nothing to send itself); a wheel's line counted as cartons.
        public bool Fitting,Wheel;
    }
    internal static class BuffaloRules {
        internal const string Pas="PAS",Suv="SUV",Truck="TRUCK",Carton="CARTON";
        internal static readonly string[] Types={Pas,Suv,Truck,Carton};
        internal const int WidestPas=215;
        internal static int Kg(string type) { return type==Pas?8:type==Suv?15:type==Truck?40:type==Carton?20:0; }
        const RegexOptions Opt=RegexOptions.CultureInvariant;
        // A truck tyre's size: a 17.5, 19.5 or 22.5 rim after R or - (11R22.5, 11 R22.5, 295/80R22.5, 245/70R19.5,
        // 9.5R17.5, 8-19.5, 295/80R22,5).
        static readonly Regex TruckRim=new Regex(@"(?<![0-9.,])[0-9]{1,3}(?:[.,][0-9]{1,2})?(?:/[0-9]{2}(?:[.,][0-9])?)?\s?(?:Z?R\s?F?|-\s?)((?:17|19|22)[.,]5)(?![0-9])",Opt);
        // A width in mm: 205/55R16, 205/55-16, P225/60R16, LT245/75R16, 245/45ZR18, 225/45 R17, 225/45RF17, 195R15C, 195 R15
        // (never a load index's 112/109S, a load index, speed rating and ply's 121R 10PR, a flotation size's 10.50R15, a
        // dotless 750-16 or a truck rim's 17.5 / 22,5).
        static readonly Regex Width=new Regex(@"(?<![0-9./,])([1-3][0-9]{2})(?:/[0-9]{2}(?:[.,][0-9])?\s?(?:Z?R\s?F?|-\s?)[0-9]{2}|\s?R[0-9]{2}(?!\s?P(?:R|LY)))(?![0-9]|[.,][0-9])",Opt);
        // A wheel's rim size (17X8, 22.5X8.25, 13X4.5).
        static readonly Regex RimSize=new Regex(@"(?<![0-9.,])(?:1[2-9]|2[0-6])(?:[.,][0-9]{1,2})?\s?X\s?(?:[3-9]|1[0-4])(?:[.,][0-9]{1,2})?(?![0-9])",Opt);
        // A wheel's word or finish.
        static readonly Regex WheelEvidence=new Regex(@"(?<![A-Z])(?:WHEELS?|RIMS?|ALLOYS?|MAGS?|SIMMONS|STEEL|BLACK|SATIN|MATTE|GLOSS|CHROME|SILVER|BRONZE|GUNMETAL|POLISHED|MACHINED|MILLED|BEADLOCK)(?![A-Z])",Opt);
        // A small box's part: nuts, bolts, locks, studs, spacers, adaptors, valves, caps, sensors, weights, a kit, plugs,
        // hub rings and spigots ...
        // (A ring only as a hub ring, a spigot, centring, centre or poly ring, a ring named by its bores, or an O-ring: a truck's
        // lock ring or side ring isn't one.)
        static readonly Regex SmallBox=new Regex(@"(?<![A-Z])(?:NUTS?|BOLTS?|LOCKS?|LOCKING|STUDS?|SPACERS?|ADAPT[A-Z]*|VALVES?|STEMS?|CAPS?|SENSORS?|TPMS|WASHERS?|O\s?-?\s?RINGS?|(?:CENTRING|CENTERING|CENTRE|CENTER|POLY|PLASTIC|ALLOY)\s?(?:BORE\s+)?RINGS?|RINGS?(?=\s?[0-9]{2,3}[.,][0-9]\s?(?:-|/|TO)\s?[0-9]{2,3})|KEYS?|SOCKETS?|INSERTS?|WEIGHTS?|KITS?|PLUGS?|PATCH(?:ES)?|STRINGS?|HUBS?|HUBCENTRIC|CENTRIC|SPIGOTS?|CONVERTERS?)(?![A-Z])",Opt);
        // A truck rim's lock ring, side ring or split rim, a beadlock ring, a run-flat insert: neither a wheel nor a small box.
        static readonly Regex BigRing=new Regex(@"(?<![A-Z])(?:LOCK(?:ING)?\s?-?RINGS?|LOCKRINGS?|SIDE\s?-?RINGS?|SPLIT\s?-?RIMS?|BEAD\s?-?LOK[A-Z]*|BEAD\s?-?LOCK[A-Z]*(?!\s+(?:BOLTS?|NUTS?|SCREWS?|WASHERS?)(?![A-Z])(?!.*(?:KIT|RING|INSERT|BAND)))|(?:RUN\s?-?FLATS?|RUNFLATS?)(?!\s+(?:TPMS\s+)?(?:SENSORS?|VALVES?)(?![A-Z])(?!.*(?:KIT|RING|INSERT|BAND)))|R/F|RF\s+(?:KITS?|INSERTS?|BANDS?)|VFI)(?![A-Z])",Opt);
        // A run-flat word on a wheel's line (TYRON RUN FLAT BAND 16X7); a split rim (with a ring named, it's RimRing's question).
        static readonly Regex RunFlat=new Regex(@"(?<![A-Z])(?:RUN\s?-?FLATS?|RUNFLATS?|R/F|VFI)(?![A-Z])",Opt),SplitRim=new Regex(@"(?<![A-Z])SPLIT\s?-?RIMS?(?![A-Z])",Opt);
        // A single ALLOY or MAG named first with something joined on (17 INCH ALLOY C/W CENTRE RINGS, MAG & CENTRE RINGS): the goods.
        static readonly Regex AlloyJoined=new Regex(@"(?<![A-Z])(?:ALLOY|MAG)(?![A-Z])(?=(?:\s+[0-9]{2}\s?(?:INCH|IN)?)?\s*(?:C\s?/\s?W|WITH|W/|INC[A-Z]*\.?|\+|&|AND)(?![A-Z]))",Opt);
        // The small-box ring words (a hub, spigot, centring, centre, poly, plastic or alloy ring, a ring named by its bores, an
        // O-ring); any other ring on a part's line is a loose ring.
        static readonly Regex SmallRing=new Regex(@"(?<![A-Z])(?:O\s?-?\s?|HUB\s?-?\s?(?:CENTRIC\s?)?|SPIGOT\s?-?\s?|(?:CENTRING|CENTERING|CENTRE|CENTER|CENTRIC|POLY|PLASTIC|ALLOY|SEAL|SEALING|VALVE|SPACER|GROMMET|RUBBER)\s?(?:BORE\s+)?)RINGS?(?![A-Z])|(?<![A-Z])RINGS?(?=\s?[0-9]{2,3}[.,][0-9]\s?(?:-|/|TO)\s?[0-9]{2,3})",Opt);
        // On a small box's line, a wheel's or tyre's word that only says what the part is for (WHEEL NUTS, MAG WHEEL NUTS,
        // TYRE VALVE, TRUCK TYRE VALVE, TYRE REPAIR KIT, WHEEL BEARING KIT); any other wheel's or tyre's word names the goods.
        static readonly Regex PartFor=new Regex(@"(?<![A-Z])(?:(?:MAG|ALLOY|STEEL|TRUCK|TRAILER)\s+)?(?:WHEEL|RIM|TYRE|TIRE)\s+(?:(?:LUG|LOCK|LOCKING|CENTRE|CENTER|HUB|BALANCE|BALANCING|PRESSURE|REPAIR|PUNCTURE|VALVE)\s+)*(?:NUTS?|BOLTS?|LOCKS?|STUDS?|SPACERS?|ADAPT[A-Z]*|VALVES?|STEMS?|CAPS?|SENSORS?|WEIGHTS?|PLUGS?|PATCH(?:ES)?|STRINGS?|KEYS?|SOCKETS?|WASHERS?|BEARINGS?|RINGS?|(?:REPAIR|PUNCTURE)\s+KITS?)(?![A-Z])",Opt);
        static readonly Regex RimRing=new Regex(@"(?<![A-Z])(?:LOCK(?:ING)?\s?-?RINGS?|LOCKRINGS?|SIDE\s?-?RINGS?)(?![A-Z])",Opt);
        // A run-flat band on a tyre's line (TYRON RUN FLAT BAND 265/75R16).
        static readonly Regex TyreBand=new Regex(@"(?<![A-Z])(?:TYRON|BANDS?)(?![A-Z])",Opt);
        static readonly Regex Ring=new Regex(@"(?<![A-Z])RINGS?(?![A-Z])",Opt),Mm=new Regex(@"(?<![0-9.])[0-9]{1,3}(?:\.[0-9])?\s?MM(?![A-Z])",Opt);
        static readonly Regex WheelOrTyreWord=new Regex(@"(?<![A-Z])(?:WHEELS?|RIMS?|TYRES?|TIRES?|W\s?&\s?T)(?![A-Z])",Opt);
        // Any service's or charge's word: on a tyre's, a wheel's, a small box's or a truck size's line it only ever makes it
        // UNRESOLVED (PROGRAMMABLE is a sensor's word, not a service's).
        static readonly Regex Service=new Regex(@"(?<![A-Z])(?:FIT|FITTING|FITTED|BAL|BALANC[A-Z]*|ALIGN[A-Z]*|ROTAT[A-Z]*|DISPOSAL|LEVY|LABOU?R|SERVICES?|REPAIRS?|REGROOV[A-Z]*|SIPING|SIPED|PUNCTURES?|NITROGEN|CHANGEOVER|STORAGE|MOUNTING|DEMOUNT[A-Z]*|SURCHARGE|FEES?|CHARGES?|ROUNDING|DISCOUNTS?|DEPOSIT|INSPECT[A-Z]*|RESET|PROGRAM(?:MING|MED|S)?|RELEARN|REPLACE[A-Z]*|INSTALL[A-Z]*|REMOV[A-Z]*|CHECKS?|POWDER|COAT[A-Z]*|REFURB[A-Z]*|STRAIGHTEN[A-Z]*|WELD[A-Z]*|PAINT[A-Z]*|DIAMOND|RESTOR[A-Z]*)(?![A-Z])",Opt);
        // Not a service: the wheel brand WELD RACING, nitrogen valve caps.
        static readonly Regex NotService=new Regex(@"(?<![A-Z])(?:WELD\s+RACING|NITROGEN\s+(?:VALVE\s+)?CAPS?|MIXED\s+SERVICE)(?![A-Z])",Opt);
        // A fitting, balancing, changeover, nitrogen or labour charge's words: beside tyres or wheels, they may have been sent fitted.
        static readonly Regex FitWords=new Regex(@"(?<![A-Z])(?:FIT|FITTED|FITTING|BAL|BALANC[A-Z]*|MOUNT|MOUNTED|MOUNTING|CHANGEOVER|NITROGEN|LABOU?R)(?![A-Z])",Opt);
        // On a small box's line: REPAIR / PUNCTURE beside a kit, plugs, patches or strings are goods (TYRE REPAIR PLUGS), and
        // BALANCE / BALANCING WEIGHTS are weights.
        static readonly Regex RepairGoods=new Regex(@"(?<![A-Z])(?:KITS?|PLUGS?|PATCH(?:ES)?|STRINGS?)(?![A-Z])",Opt);
        static readonly Regex RepairWords=new Regex(@"(?<![A-Z])(?:REPAIRS?|PUNCTURES?)(?![A-Z])",Opt);
        static readonly Regex BalanceWeights=new Regex(@"(?<![A-Z])BALANC[A-Z]*\s+(?=WEIGHTS?(?![A-Z]))",Opt);
        // Not a sale of goods that ship with this consignment: a credit, refund, return, hire, loan, quote, back order (B/O,
        // BO, TO COME, ETA, PRE ORDER, OWING, INDENT), a drop ship or direct from the supplier, warranty, a casing.
        static readonly Regex NotSale=new Regex(@"(?<![A-Z])(?:CREDITS?|REFUNDS?|RETURN(?:ED|S)?|HIRE|LOAN|CUSTOMER|SUPPLIED|QUOTES?|QUOTATION|B/O|B/ORD(?:ER)?|BO|B\.\s?O\.?|BACK\s?-?\s?ORDERS?|BACKORDER(?:ED|S)?|TO\s+(?:COME|FOLLOW)|ETA|PRE\s?-?ORDER(?:ED|S)?|OWING|INDENT|DROP\s?-?SHIP(?:PED|PING|S)?|DIRECT\s+(?:FROM|EX|SHIP[A-Z]*)|WARRANTY|CLAIMS?|CASINGS?|EXCHANGE|SAMPLES?|DEMO)(?![A-Z])",Opt);
        // A set or a count in the words (SET OF 4, PAIR, 4 PACK, X4, 4X, (4), 4 TYRES, 4@$250, 2PC, 4 OFF, QTY 4): the qty
        // may not be the count.
        static readonly Regex CountWords=new Regex(@"(?<![A-Z])(?:SETS?|PAIRS?|PCS|PIECES?|PK|PACKS?|COMBOS?)(?![A-Z])|(?<![0-9A-Z.])X\s?[0-9]{1,2}(?![0-9.X/])|\(\s*[0-9]{1,2}\s*\)|(?<![0-9.])[0-9]{1,2}\s?(?:WHEELS|TYRES|TIRES|RIMS)(?![A-Z])"+
            @"|(?<![0-9A-Z.])[0-9]{1,2}\s?@|(?<![0-9A-Z./])[0-9]{1,2}\s?X\s?(?=(?:LT|P)?[1-3][0-9]{2}/)|(?<![A-Z])(?:TWO|THREE|FOUR|FIVE|SIX|EIGHT|TEN|TWELVE)(?![A-Z])(?!\s?-?(?:TONE|SPOKES?|SEASONS?|LUGS?|PLY|WAY)(?![A-Z]))|\*\s?[0-9](?![0-9])|\*\s?[0-9]{2}(?![0-9A-Z])|(?<![0-9.])(?:[0-9]{2}|[04-9])\s?PC(?:E|ES)?(?![A-Z])|(?<![0-9.])[123]\s?PC(?:E|ES)?(?![A-Z])(?!\s+(?:FORGED|MODULAR|CONSTRUCTION|DESIGN)(?![A-Z]))|(?<![0-9A-Z./+\-])[0-9]{1,2}\s?(?:OFF(?![A-Z])|X(?![0-9A-Z]))|(?<![A-Z])QTY\s?:?\s?[0-9]",Opt);
        // On a wheel's line, 2PR is a pair (on a tyre's line, 8PR is a ply rating).
        static readonly Regex WheelPair=new Regex(@"(?<![0-9.])[0-9]{1,2}\s?PRS?(?![A-Z])",Opt);
        // Just an X and a count after a size (205/55R16 X4): a count, though the wholesale rules may read 16 X4 as a rim.
        static readonly Regex XCount=new Regex(@"(?<![0-9A-Z.])X\s?[0-9]{1,2}(?![0-9.X/])",Opt);
        // A second item joined on (WITH, AND, ON, MOUNTED, COMBO, W/, &, + before a word; not an offset's +20, nor a tyre's
        // W/L white letters or W/W white wall).
        static readonly Regex Connector=new Regex(@"(?<![A-Z])(?:WITH|AND|ON|MOUNTED|COMBO)(?![A-Z])|(?<![A-Z])W/(?!\s?[LW](?![A-Z]))|&|\+(?=\s*[A-Z])",Opt);
        // More joining words (fourth review): C/W (complete with), INC / INCL / INCLUDING once the parts they may name are
        // taken out, PLUS before a word (a tyre model's PLUS at the end or before its size or XL is fine), a spaced slash.
        static readonly Regex Joiner=new Regex(@"(?<![A-Z])(?:C\s?/\s?W|INC(?:L|LUDING|LUDES|LUDED)?\.?)(?![A-Z])(?!\.?\s*GST(?![A-Z]))|(?<![A-Z])PLUS(?=\s+(?!(?:XL|EL|SL|RF|RFT|LT|TL|MO|RUN|FLAT)(?![A-Z]))[A-Z])|\s/\s",Opt);
        // A tyre's brand or tread name on a wheel's line (KING KAOS 17X8 6/139.7 BFG KO2): a package.
        static readonly Regex TyreName=new Regex(@"(?<![A-Z0-9])(?:BFG|BF\s?GOODRICH|GOODRICH|KO2|KM2|KM3|TOYO|(?<!MINI\s)COOPER|STT|MICHELIN|BRIDGESTONE|DUELER|GOODYEAR|(?<!(?:JEEP|SUIT|SUITS|FITS|FOR|S/T|JK|JL|TJ|YJ)\s)(?<!/)WRANGLER(?!\s?(?:JK|JL|TJ|YJ)(?![A-Z]))(?!\s?/)|DURATRAC|YOKOHAMA|GEOLANDAR|FALKEN|WILDPEAK|MAXXIS|HANKOOK|DYNAPRO|KUMHO|NITTO|PIRELLI|CONTINENTAL|DUNLOP|GRANDTREK|FEDERAL|NANKANG|NEXEN|KENDA|BAJA\s+(?:BOSS|LEGEND|CLAW|ATZ|MTZ)|ATZ|MTZ|DEEGAN|AT3|A/T|M/T|H/T|R/T|X/T)(?![A-Z0-9])",Opt);
        // A press-on band or solid tyre: a three-part size (21X7X15, 16X6X10.5) or its words.
        static readonly Regex PressOn=new Regex(@"(?<![0-9.,])(?:[0-9]{1,2}(?:[.,][0-9]{1,2})?X[0-9]{1,2}(?:[.,][0-9]{1,2})?X[0-9]{1,2}|[12][0-9]\s?X\s?[0-9]{1,2}(?:[.,][0-9]{1,2})?\s?X\s?[0-9]{1,2}(?:[.,][0-9]{1,3})?(?![0-9]))",Opt),
            PressOnWords=new Regex(@"(?<![A-Z])(?:SOLID|SOLIDEAL|POB|PRESS\s?-?ON)(?![A-Z])",Opt),PressOnPob=new Regex(@"(?<![A-Z])(?:POB|PRESS\s?-?ON)(?![A-Z])",Opt),
            RealWheel=new Regex(@"(?<![A-Z])(?:WHEELS?|RIMS?|ALLOYS?|MAGS?)(?![A-Z])|(?<![0-9])[0-9]{1,2}\s?STUDS?(?![A-Z])",Opt);
        // A wheel's stud pattern, spaced or not (6/139.7, 6 X 139.7, 6 / 139.7): a real stud count and PCD, taken out once.
        static readonly Regex StudPattern=new Regex(@"(?<![0-9.])(?:4\s?[X/]\s?(?:98|100|108|110|114(?:[.,]3)?|130)|5\s?[X/]\s?(?:100|105|108|110|112|114(?:[.,]3)?|115|118|120|127|130|135|139(?:[.,]7)?|150|160|165(?:[.,]1)?)|6\s?[X/]\s?(?:114(?:[.,]3)?|115|120|125|127|130|132|135|139(?:[.,]7)?)|8\s?[X/]\s?(?:165(?:[.,]1)?|170|180|200))(?![0-9])",Opt);
        // A rim size of 14 inches or more whose width is a whole 3, 4 or 5 (17 X 4): left in, so a count (X 4) is still seen.
        static readonly Regex NarrowRim=new Regex(@"^(?:1[4-9]|2[0-6])\s?X\s?[3-5]$",Opt);
        // Joining words that don't add an item: M+S, M&S, ON/OFF, ON & OFF, W/ KEVLAR, a model's + (PRIMACY 4+ XL, 050+ XL, ENERGY
        // SAVER+, SUV+), a year's + (SUIT HILUX 2015+),
        // a two-tone finish (BLACK & MACHINED, BLACK W/ MILLED WINDOWS, GOLD WITH POLISHED LIP).
        const string Finish="BLACK|GLOSS|MATTE|SATIN|CHROME|SILVER|BRONZE|GUNMETAL|POLISHED|MACHINED|MILLED|BRUSHED|GREY|GRAY|WHITE|GOLD|RED|TITANIUM|COPPER|GRAPHITE|BLUE|GREEN|ORANGE";
        static readonly Regex Harmless=new Regex(@"M\s?\+\s?S(?![A-Z])|(?<![A-Z])M\s?&\s?S(?![A-Z])|(?<![A-Z])ON\s?(?:/|&|AND|-)\s?OFF(?![A-Z])|(?<![A-Z])(?:W/|WITH)\s?KEVLAR(?![A-Z])|\+(?=\s*(?:XL|EL|SL|RF|RFT)(?![A-Z]))|(?<![A-Z])(?:SAVER|SUV|CROSSCLIMATE)\+(?![A-Z0-9])|(?<![0-9])(?:19|20)[0-9]{2}\+(?![A-Z0-9])|(?<![A-Z])(?:GRABBER|BMW)\s+X\s?[0-9]{1,2}(?![0-9])|(?<![A-Z])(?:"+Finish+@")\s?(?:&|AND|W/|WITH|/)\s?(?:"+Finish+@")(?:\s+(?:FACE|LIP|WINDOWS?|SPOKES?|ACCENTS?))?(?![A-Z])",Opt);
        // The words of a plain charge or service (nothing to send), and the words that may stand beside them.
        static readonly HashSet<string> ChargeWords=new HashSet<string>(StringComparer.Ordinal) {"LEVY","LABOUR","LABOR","FEE","FEES","CHARGE","CHARGES","SURCHARGE","ROUNDING","DISCOUNT","DISCOUNTS","DEPOSIT","DISPOSAL","FIT","FITTING","FITTED","BAL","BALANCE","BALANCED","BALANCING","ALIGN","ALIGNED","ALIGNMENT","ROTATION","ROTATE","ROTATED","MOUNT","MOUNTED","MOUNTING","DEMOUNTING","CHANGEOVER","PUNCTURE","REPAIR","REPAIRED","REPAIRS","SERVICE","SERVICES","INSPECTION","INSPECTED","NITROGEN","FILL","STORAGE","ENVIRONMENTAL","ENVIRO","STEWARDSHIP","TSA","RECYCLING","ADMIN","CARD","CREDIT","MERCHANT","HR","HRS","HOUR","HOURS"};
        static readonly HashSet<string> Filler=new HashSet<string>(StringComparer.Ordinal) {"TYRE","TYRES","TIRE","TIRES","WHEEL","WHEELS","TRUCK","4X4","4WD","AND","PER","EACH","EA","OF","THE","A","X","ON","FOR","IN","Y","N","YES","NO","COMPLETE","COMPLETED","DONE"};
        static readonly Regex Numeric=new Regex(@"^\$?[0-9][0-9.,]*$|^[0-9]/[0-9]$",Opt),SizeToken=new Regex(@"^[1-3][0-9]{2}\.?[2-9][05]\.?(?:1[0-9]|2[0-6])$",Opt),TruckRimToken=new Regex(@"^(?:17|19|22)[.,]5$",Opt),LetterSlash=new Regex(@"(?<=[A-Z])/(?=[A-Z])",Opt),WidthToken=new Regex(@"^[1-3][0-9]{2}$",Opt),AspectToken=new Regex(@"^[2-9][05]$",Opt);
        // The words a truck tyre's line may hold beside its size, when the wholesale rules don't read the size.
        static readonly HashSet<string> TruckWords=new HashSet<string>(StringComparer.Ordinal) {"TYRE","TYRES","TIRE","TIRES","TRUCK","STEER","DRIVE","TRAILER","ALL","POSITION","RADIAL","TUBELESS","TL","HD","LT","REGIONAL","HIGHWAY","NEW"};
        static readonly Regex TruckToken=new Regex(@"^(?:[0-9]{2,3}(?:/[0-9]{2,3})?[A-Z]|[0-9]{1,2}P(?:R|LY))$",Opt);
        // Goods that aren't a tyre, a wheel or a small box: consumables, tools, machines, accessories (BEADS: balancing
        // beads; a wheel's BEAD GRIP is a model's name).
        static readonly Regex Goods=new Regex(@"(?<![A-Z])(?:PASTE|LUBE|LUBRICANTS?|BEADS|SEALERS?|MACHINES?|RACKS?|BAGS?|TOOLS?|BARS?|LAMPS?|GENERATORS?|PLATES?|BALANCERS?|CHANGERS?|COMPRESSORS?|GAUGES?|SEALANTS?|CEMENT|GLUE|BRUSH(?:ES)?|STANDS?|JACKS?|LIFTS?|CHAINS?|COVERS?|SOCKS?|STRAPS?|CARRIERS?|LEVERS?|INFLAT[A-Z]*|CHOCKS?|PUMPS?|HOSES?|CAGES?|AXLES?|SPRINGS?|SUSPENSION|BRAKES?|DRUMS?|HITCH(?:ES)?|COUPLINGS?|WINCH(?:ES)?|TRAILER\s+KITS?|HAMMERS?|MALLETS?|PLIERS|WRENCH(?:ES)?|SPANNERS?|DOLLY|DOLLIES|TROLLEYS?|BREAKERS?|SPREADERS?|MONITORS?)(?![A-Z])",Opt);
        static readonly Regex FlapOrTube=new Regex(@"(?<![A-Z0-9])(?:(?:MUD)?FLAPS?|RIM\s?BANDS?|TUBES?)(?![A-Z0-9])",Opt);
        // A wheel or a package named on a tyre's line (not a tyre's "RIM PROTECTOR", "RIM-PROTECTOR", "RIM GUARD").
        static readonly Regex WheelOrPackage=new Regex(@"(?<![A-Z])(?:(?:WHEELS?|ALLOYS?|MAGS?|SIMMONS|PACKAGES?|PKGS?|PACKS?|COMBOS?|ASSEMBL[A-Z]*|ASSY)(?![A-Z])|RIMS?(?![A-Z])(?![\s-]?(?:PROT|GUARD|FLANGE)))",Opt);
        // A wheel or a package named as the goods on a part's line (WHEEL NUTS and WHEEL LOCKS stay parts).
        static readonly Regex WheelSubject=new Regex(@"(?<![A-Z0-9])(?:WHEELS|RIMS|ALLOYS|MAGS|PACKAGES?|PKGS?|ASSEMBL[A-Z]*|ASSY|(?:STEEL|ALLOY|MAG|TRAILER|SPARE)\s+(?:WHEEL|RIM)S?|[0-9]{1,2}\s?STUDS?)(?![A-Z])",Opt);
        // A tyre or a package named on a wheel's line.
        static readonly Regex TyreOrPackage=new Regex(@"(?<![A-Z])(?:TYRES?|TIRES?|PACKAGES?|PKGS?|PACKS?|ASSEMBL[A-Z]*|ASSY)(?![A-Z])",Opt);
        // What a wheel's line may carry and still be wheels: its stud count (6 STUD) and what comes with it (INC CENTRE
        // CAPS, WITH HUB RINGS, W/ CAPS); a tyre's line: INC VALVE.
        static readonly Regex StudCount=new Regex(@"(?<![0-9])[0-9]{1,2}\s?STUDS?(?![A-Z])",Opt);
        static readonly Regex WithParts=new Regex(@"(?<![A-Z])(?:INC(?:L|LUDING|LUDES)?\.?|WITH|W/|C\s?/\s?W|\+)\s*(?:(?:CENTRE|CENTER|HUB|LUG|WHEEL|CHROME|BLACK|LOCKING|LOCK|SPIGOT)\s+)*(?:CAPS?|RINGS?|NUTS?|BOLTS?|VALVES?|LOCKS?)(?![A-Z])",Opt);
        static readonly Regex WithValve=new Regex(@"(?<![A-Z])(?:INC(?:L|LUDING|LUDES)?\.?|WITH|W/|C\s?/\s?W|\+)\s*(?:NEW\s+)?VALVES?(?![A-Z])",Opt);
        const string OnTyre="a tyre's size with a part's, service's, goods' or wheel's words: can't tell";
        const string Package="a wheel and a tyre on one line (a package?): Tempe's rules don't say";
        const string RingWhy="a lock ring, side ring, split rim, beadlock or run-flat insert: Tempe's rules don't cover them";
        const string PressOnWhy="a three-part size (21X7X15) or a press-on or solid tyre's words: Tempe's rules don't say";
        const string PartWith="a part's words with a wheel's, tyre's, package's or goods' words: can't tell";
        const string NotSaleWhy="a credit, return, hire, loan, quote, warranty or back order's words: check what ships";
        const string MoreThanOne="the line may hold a set, a pair or more than one item (SET, PAIR, PACK, X4, WITH, +, &, ON ...): check what and how many ship";

        // A tyre's type by its size (Size and Description): TRUCK on a 17.5, 19.5 or 22.5 rim; else PAS up to 215 mm wide,
        // SUV over 215. Null (how says why) when no size gives a type, or the line holds two different sizes.
        internal static string TyreType(string size,string description,out string how) {
            var sizes=new List<string>();string type=null;how=null;
            foreach(var t in new[]{size,description}) {
                string w=WholesaleRules.Words(t);
                foreach(Match m in TruckRim.Matches(w)) { sizes.Add(Same(m.Value));type=Truck;how="a "+m.Groups[1].Value.Replace(',','.')+" rim"; }
                foreach(Match m in Width.Matches(w)) {
                    int mm=Int32.Parse(m.Groups[1].Value,CultureInfo.InvariantCulture);sizes.Add(Same(m.Value));
                    if(type==null) { type=mm>WidestPas?Suv:Pas;how=mm.ToString(CultureInfo.InvariantCulture)+" mm wide"+(mm>WidestPas?", over 215":", 215 or less"); }
                }
            }
            var distinct=sizes.Distinct(StringComparer.Ordinal).ToList();
            if(distinct.Count==1) return type;
            how=distinct.Count==0?"a tyre whose size has no width in mm and no 17.5, 19.5 or 22.5 rim":"two tyre sizes on one line ("+String.Join(", ",distinct)+"): a pair or a staggered set?";
            return null;
        }
        // One size however it's written: no spaces, ZR as R, RF as R, a decimal comma as a dot.
        static string Same(string size) { return Regex.Replace(size.Replace(',','.'),@"\s|Z(?=R)|(?<=R)F","",Opt); }
        // A plain charge or service: at least one charge's word, and every word a charge's, TYRE / WHEEL / & ... or a number.
        internal static bool NothingToSend(string words) {
            var tokens=Tokens(LetterSlash.Replace(words??""," "));
            for(int i=0;i<tokens.Count;i++) if(SizeToken.IsMatch(tokens[i])||TruckRimToken.IsMatch(tokens[i])||(i+1<tokens.Count&&WidthToken.IsMatch(tokens[i])&&AspectToken.IsMatch(tokens[i+1]))) return false;
            return tokens.Any(t=>ChargeWords.Contains(t))&&tokens.All(t=>ChargeWords.Contains(t)||Filler.Contains(t)||Numeric.IsMatch(t));
        }
        static List<string> Tokens(string words) { return Regex.Split(words??"",@"[^A-Z0-9.$/]+").Select(t=>t.Trim('.','/')).Where(t=>t.Length>0).ToList(); }
        // A truck tyre's line the wholesale rules don't read: every word beside its size a truck tyre's.
        static bool TruckOnly(string words) {
            var tokens=Tokens(TruckRim.Replace(words??""," "));
            return tokens.Any(t=>t=="TYRE"||t=="TYRES"||t=="TIRE"||t=="TIRES")&&tokens.All(t=>TruckWords.Contains(t)||TruckToken.IsMatch(t));
        }
        // One invoice line (not a note) for Buffalo: its type and Qty, or nothing to send, or UNRESOLVED (How says which).
        internal static BuffaloLine Classify(InvoiceLine l) {
            var x=new BuffaloLine {Number=l.Number,Description=l.Description};
            if(l.Kind=="freight") { x.How="freight (Item F): not an item";return x; }
            if(l.Kind=="possible-freight") return Unsure(x,"POSSIBLE FREIGHT (by its words, not confirmed): not an item if it is freight; check it");
            if(l.Item==null||l.Description==null||l.Size==null||l.Qty==null) return Unsure(x,"its Item, Description, Size or Qty wasn't read");
            string kind=WholesaleRules.KindOf(l.Item,l.Size,l.Description),type=null,how;bool perLine=false;
            string w=WholesaleRules.Words(l.Size)+" "+WholesaleRules.Words(l.Description);
            string wv=NotService.Replace(w," ");
            bool service=Service.IsMatch(wv),goods=Goods.IsMatch(w),notSale=NotSale.IsMatch(w),tyreSize=WholesaleRules.Tyre(l.Size,l.Description);
            switch(kind) {
                case "tyre": {
                    string wt=Harmless.Replace(WithValve.Replace(w," ")," ");
                    if(notSale) how=NotSaleWhy;
                    else if(PressOnWords.IsMatch(w)||PressOn.IsMatch(w)) how=PressOnWhy;
                    else if(SmallBox.IsMatch(wt)||Ring.IsMatch(wt)||TyreBand.IsMatch(wt)||service||goods||WheelOrPackage.IsMatch(w)) how=OnTyre;
                    else if(CountWords.IsMatch(wt)||Connector.IsMatch(wt)||Joiner.IsMatch(wt)) how=MoreThanOne;
                    else type=TyreType(l.Size,l.Description,out how);
                    break;
                }
                case "wheel": {
                    // The parts that come with it, its stud count and finish taken out; then its rim size (17 X 8 isn't a count).
                    string wp0=Harmless.Replace(StudCount.Replace(WithParts.Replace(w," ")," ")," ");
                    string wp=StudPattern.Replace(RimSize.Replace(wp0,m=>NarrowRim.IsMatch(m.Value)?m.Value:" ")," ",1);
                    if(PressOn.IsMatch(w)||PressOnPob.IsMatch(w)||(PressOnWords.IsMatch(w)&&!StudPattern.IsMatch(w)&&!RealWheel.IsMatch(w))) how=PressOnWhy;
                    else if(RimRing.IsMatch(w)||(SplitRim.IsMatch(w)&&Ring.IsMatch(w))) how="a wheel's line with a lock ring or side ring: a split-rim wheel (a carton each) or loose rings? Staff decide";
                    else if(RunFlat.IsMatch(w)||TyreBand.IsMatch(w)) how=RingWhy;
                    else if(tyreSize&&XCount.IsMatch(wp0)) how=MoreThanOne;
                    else if(tyreSize||TyreOrPackage.IsMatch(w)||TruckRim.IsMatch(w)||Width.IsMatch(w)) how=Package;
                    else if(notSale) how=NotSaleWhy;
                    else if(SmallBox.IsMatch(wp)||Ring.IsMatch(wp)||service||goods) how="a wheel's size or stud pattern with a part's, service's or goods' words (nuts, spacers, caps, hub rings ...): a wheel or a small box?";
                    else if(CountWords.IsMatch(wp)||WheelPair.IsMatch(wp)||Connector.IsMatch(wp)||Joiner.IsMatch(wp)) how=MoreThanOne;
                    else if(TyreName.IsMatch(wp)) how=Package;
                    else if(!RimSize.IsMatch(w)&&(!WheelEvidence.IsMatch(w)||Mm.IsMatch(wp))) how="a stud pattern with no rim size, wheel's word or finish (a hub ring, a spigot, an adaptor?): not shown to be a wheel";
                    else { type=Carton;how="wheels: one carton each";x.Wheel=true; }
                    break;
                }
                case "tube": how="a tube: Tempe's rules don't cover tubes";break;
                default: {
                    // "other" (and "unsure"): a plain charge, a small box, a truck tyre the wholesale rules don't read, or UNRESOLVED.
                    string truckHow=null;bool truck=TruckRim.IsMatch(w)&&TyreType(l.Size,l.Description,out truckHow)==Truck;
                    if(FlapOrTube.IsMatch(w)) how="a flap, rim band or tube: Tempe's rules don't cover them";
                    else if(NothingToSend(w)) { x.How="a charge or service: nothing to send";x.Fitting=FitWords.IsMatch(w);return x; }
                    else if(BigRing.IsMatch(w)) how=RingWhy;
                    else if(Ring.IsMatch(SmallRing.Replace(w," "))) how="a ring that isn't a hub, spigot, centre or O-ring (a lock ring, a side ring?): Tempe's rules don't cover it";
                    else if(SmallBox.IsMatch(w)) {
                        string ws=BalanceWeights.Replace(RepairGoods.IsMatch(wv)?RepairWords.Replace(wv," "):wv,"");
                        if(notSale) how=NotSaleWhy;
                        else if(Service.IsMatch(ws)) how="a part's words and a service's: can't tell";
                        else if(truck||tyreSize||Width.IsMatch(w)) how=OnTyre;
                        else if(goods||WheelSubject.IsMatch(PartFor.Replace(w," "))||WheelOrTyreWord.IsMatch(PartFor.Replace(w," "))||AlloyFirst(w)) how=PartWith;
                        else { type=Carton;perLine=true;how="a small box: one carton for the line"; }
                    }
                    else if(truck&&!tyreSize&&!notSale&&TruckOnly(w)) { type=Truck;how=truckHow+" (a truck size)"; }
                    else if(truck) how="a truck size on a line the wholesale rules don't read as a tyre: check it (a truck tyre is TRUCK)";
                    else how=kind=="unsure"?"the wholesale rules can't tell what it is (a tyre or a wheel?)":"not a tyre, wheel, small box or plain charge Tempe's rules know";
                    break;
                }
            }
            if(type==null) return Unsure(x,how);
            if(Negative(l.LineTotal)||Negative(l.Net)) { x.Wheel=false;return Unsure(x,type+" ("+how+"), but the line is negative (a credit or a return?): check what ships"); }
            decimal q;
            if(!Decimal.TryParse(l.Qty.Trim(),NumberStyles.AllowDecimalPoint,CultureInfo.InvariantCulture,out q)||q<=0) return Unsure(x,type+" ("+how+"), but its qty "+Q(l.Qty)+" isn't a number above 0");
            if(perLine) { x.Type=type;x.Qty=1;x.How=type+" x 1 ("+how+"; COSTAR qty "+l.Qty.Trim()+")";return x; }
            if(q!=Decimal.Truncate(q)||q>9999) return Unsure(x,type+" ("+how+"), but its qty "+Q(l.Qty)+" isn't a whole number from 1 to 9999");
            x.Type=type;x.Qty=(int)q;x.How=type+" x "+x.Qty.ToString(CultureInfo.InvariantCulture)+" ("+how+")";
            return x;
        }
        // Below 0, or a credit written another way: in brackets (360.00), with CR, or with a Unicode minus.
        static bool Negative(string v) {
            decimal t;if(String.IsNullOrEmpty(v)) return false;
            if(InvoiceReader.Money(v,out t)) return t<0;
            return v.IndexOf('(')>=0||v.IndexOf('−')>=0||v.ToUpperInvariant().Contains("CR");
        }
        // A single ALLOY or MAG with something joined on and no part's word before it (WHEEL NUT MAG C/W WASHER is a part).
        static bool AlloyFirst(string w) { var m=AlloyJoined.Match(w);return m.Success&&!SmallBox.IsMatch(w.Substring(0,m.Index)); }
        static BuffaloLine Unsure(BuffaloLine x,string why) { x.Unresolved=true;x.Wheel=false;x.How="UNRESOLVED – "+why;return x; }
        static string Q(string v) { return v==null?"(not read)":"\""+v+"\""; }
    }

    // All the wording: the review shown in the big box, the Buffalo details (shown and copied exactly), the status line
    // and the log line (counts only).
    internal static class InvoicePreview {
        internal const string ReadComplete="Read complete — data prepared for review";
        internal const string NothingChanged="Not sold, not booked, nothing changed in COSTAR.";
        internal const string NoneOpen="No COSTAR Invoice is open: open the invoice in COSTAR, then press Read.";
        internal const string AllFilled="ALL FILLED IN BY TEMPE'S BUFFALO RULES – check them against the invoice, then enter them in Buffalo yourself (nothing was sent).";
        internal static string Several(IEnumerable<string> numbers) {
            var l=(numbers??new string[0]).Select(n=>n??"(number not read)").ToList();
            return l.Count+" COSTAR Invoices are open ("+String.Join(", ",l)+"): type the one to read in Expected invoice #, then press Read.";
        }
        internal static string Over(string title) { return "Something is open over the invoice in COSTAR ("+(title??"")+"): close it, then press Read."; }
        internal static string NotExpected(string read,string expected) { return "The open invoice is "+read+", not "+expected+": nothing was prepared."; }
        internal static string YNotShown(string tab) { return "not read: COSTAR is showing the "+tab+" tab – click Ship to in COSTAR, then press Read again"; }

        internal static string Status(InvoiceRead r) {
            if(r==null) return "";
            if(r.Refused!=null) return r.Refused;
            if(Done(r)) return ReadComplete+". "+NothingChanged;
            return "Read INCOMPLETE — "+String.Join("; ",Reasons(r))+"; nothing changed in COSTAR.";
        }
        static bool Done(InvoiceRead r) { return r.Complete&&r.Incomplete.Count==0; }
        // Why the read is incomplete: the core's reasons, plus the run's own "press Read again" ones (a caller that set
        // Complete=false and added its reason to Problems instead of InvoiceReader.MarkIncomplete); else every problem.
        internal static List<string> Reasons(InvoiceRead r) {
            var l=r.Incomplete.ToList();
            foreach(var p in r.Problems.Where(p=>p!=null&&p.EndsWith("press Read again",StringComparison.Ordinal))) if(!l.Contains(p)) l.Add(p);
            if(l.Count==0&&!Done(r)) l.AddRange(r.Problems.Where(p=>!String.IsNullOrEmpty(p)).Distinct());
            if(l.Count==0&&!Done(r)) l.Add("not every part was read");
            return l;
        }
        internal static string LogKind(InvoiceRead r) {
            return r==null||r.Refused!=null?"invoice_dry_run_refused":Done(r)?"invoice_dry_run":"invoice_dry_run_incomplete";
        }
        // Counts, states and the invoice number only (the number when it looks like one: letters, digits, - and /).
        internal static string LogLine(InvoiceRead r) {
            if(r==null) return "";
            string number=r.Number==null?"-":Regex.IsMatch(r.Number,@"^[A-Za-z0-9/-]{1,20}$")?r.Number:"(unusual)";
            if(r.Refused!=null) return "invoice="+number+" refused="+(r.RefusedCode??"refused");
            var b=new StringBuilder();
            b.Append("invoice=").Append(number).Append(" branch=").Append(r.Branch.ToString(CultureInfo.InvariantCulture))
             .Append(" lines=").Append(r.Lines.Count.ToString(CultureInfo.InvariantCulture)).Append(" freight=").Append(r.FreightState??"-")
             .Append(" complete=").Append(r.Complete&&r.Incomplete.Count==0?"yes":"no").Append(" unresolved=").Append(Unresolved(r).ToString(CultureInfo.InvariantCulture))
             .Append(" products=").Append(r.Lines.Count(l=>l.Kind=="product")).Append(" possible_freight=").Append(r.Lines.Count(l=>l.Kind=="possible-freight"))
             .Append(" notes=").Append(r.Lines.Count(l=>l.Kind=="note")).Append(" skus=").Append(r.Lines.Where(l=>l.Kind!="note"&&!String.IsNullOrEmpty(l.Item)).Select(l=>l.Item).Distinct(StringComparer.Ordinal).Count())
             .Append(" y_read=").Append(r.YShown?"yes":"no");
            if(r.Incomplete.Count>0) b.Append(" why=").Append(String.Join("; ",r.Incomplete));
            return b.ToString();
        }

        static string Q(string v) { return v==null?"(not read)":"\""+v+"\""; }
        static string Pad(string s,int n) { s=s??"";return s.Length>=n?s+" ":s+new string(' ',n-s.Length); }
        static string FieldValue(InvoiceField f) {
            if(f.State=="not read") return "not read ("+(f.Why??"could not be read")+")";
            return Q(f.Value)+(f.State=="empty"?" (empty)":"")+(f.Why!=null?"  ["+f.Why+"]":"");
        }
        static string Get(InvoiceRead r,string role) { var f=r.Fields.FirstOrDefault(x=>x.Role==role);return f==null?null:f.Value; }
        const string NL="\r\n";

        // The Buffalo details: exactly what the Buffalo box shows and Copy puts on the clipboard. 2.9.16: filled by Tempe's
        // rules (BuffaloRules, Tommy 24 Nov 2026): only Receiver Information (all from Y, the Ship to tab) and Consignment
        // Items; the rest stays as Buffalo fills it. What the rules don't cover, or what wasn't read, is UNRESOLVED and the
        // text ends NOT READY FOR BOOKING with their count (counted as they're written, never from the text, so customer
        // words can't change it); with none it ends AllFilled (still for a person to check and enter). A read whose lines
        // don't add up to the invoice total (a line may be missing) is UNRESOLVED too.
        internal static string Buffalo(InvoiceRead r) { int k;return Buffalo(r,out k); }
        internal static int Unresolved(InvoiceRead r) { int k;Buffalo(r,out k);return k; }
        static string Buffalo(InvoiceRead r,out int unresolved) {
            unresolved=0;
            if(r==null||r.Refused!=null) return "";
            int k=0;
            var b=new StringBuilder();
            b.Append("BUFFALO DETAILS — preview for a person to check (nothing was sent to Buffalo)").Append(NL);
            b.Append("Invoice ").Append(String.IsNullOrEmpty(r.Number)?"(number not read)":r.Number).Append(", branch ").Append(r.Branch>0?r.Branch.ToString(CultureInfo.InvariantCulture)+" "+(r.BranchName??""):"(not read)").Append(NL);
            b.Append("Fill in only Receiver Information and Consignment Items; leave Sender, Service Level and the rest as Buffalo fills them.").Append(NL);
            string reference=String.IsNullOrEmpty(r.Number)?null:r.Number;
            b.Append(NL).Append("RECEIVER INFORMATION (everything from the Ship to tab, Y)").Append(NL);
            if(!r.YShown) { b.Append("  UNRESOLVED – the Ship to tab: ").Append(r.YWhy??"not read").Append(NL);k++; }
            else {
                Row(b,"Name",Needed(r,"y.name",ref k));
                Row(b,"Address",Needed(r,"y.addr1",ref k));
                var second=r.Fields.FirstOrDefault(f=>f.Role=="y.addr2");
                Row(b,"Address 2","(leave blank)"+(second!=null&&!String.IsNullOrEmpty(second.Value)?"   [Ship to's second line "+Q(second.Value)+" isn't used]":""));
                int before=k;string suburb=Needed(r,"y.suburb",ref k);
                var stateField=r.Fields.FirstOrDefault(f=>f.Role=="y.state");var postField=r.Fields.FirstOrDefault(f=>f.Role=="y.postcode");
                string state=stateField==null?null:stateField.Value,postcode=postField==null?null:postField.Value;
                bool stateUnread=stateField==null||stateField.State=="not read",postUnread=postField==null||postField.State=="not read";
                string place=((state??"")+" "+(postcode??"")).Trim();
                // Each box's gap said as it is: not read, or empty (both when both are).
                string stateGap=stateUnread?"wasn't read":String.IsNullOrEmpty(state)?"is empty":null,postGap=postUnread?"wasn't read":String.IsNullOrEmpty(postcode)?"is empty":null;
                string gap=stateGap==null&&postGap==null?null:stateGap!=null&&postGap!=null&&stateGap==postGap?"Ship to's state and postcode "+(stateGap=="is empty"?"are empty":"weren't read"):stateGap!=null&&postGap!=null?"Ship to's state "+stateGap+" and its postcode "+postGap:stateGap!=null?"Ship to's state "+stateGap:"Ship to's postcode "+postGap;
                string hint=k>before?"":gap!=null?"   ["+gap+(place.Length>0?" (it shows "+place+")":"")+": check you pick the right one in Buffalo's list]":"   [Ship to also shows "+place+": pick that one in Buffalo's list]";
                Row(b,"Suburb",suburb+hint);
                Row(b,"Email",Optional(r,"y.email",ref k));
                Row(b,"Contact",Optional(r,"y.contact",ref k));
                Row(b,"Phone",Phone(r,ref k));
            }
            if(reference==null) k++;
            Row(b,"Reference",reference==null?"UNRESOLVED – the invoice's number wasn't read":reference+"   [the Repair Order number: the invoice's own number]");
            b.Append(NL).Append("CONSIGNMENT ITEMS (one row per type; Reference = the Repair Order number; Total Weight = Qty x PAS 8, SUV 15, TRUCK 40, CARTON 20 kg)").Append(NL);
            var counted=r.Lines.Where(l=>l.Kind!="note").Select(BuffaloRules.Classify).ToList();
            var items=counted.Where(x=>x.Type!=null).ToList();
            b.Append("  ").Append(Pad("Reference",12)).Append(Pad("Qty",6)).Append(Pad("Description",14)).Append("Total Weight (kg)").Append(NL);
            foreach(var type in BuffaloRules.Types) {
                int qty=items.Where(x=>x.Type==type).Sum(x=>x.Qty);
                if(qty==0) continue;
                b.Append("  ").Append(Pad(reference??"(not read)",12)).Append(Pad(qty.ToString(CultureInfo.InvariantCulture),6)).Append(Pad(type,14))
                 .Append((qty*BuffaloRules.Kg(type)).ToString(CultureInfo.InvariantCulture)).Append(NL);
            }
            if(items.Count==0) b.Append("  (no item rows)").Append(NL);
            if(items.Count==0&&!counted.Any(x=>x.Unresolved)&&r.LinesComplete) { b.Append("  UNRESOLVED – nothing on the invoice to send (no tyre, wheel or small box)").Append(NL);k++; }
            if(counted.Count>0) b.Append("  How each line was counted:").Append(NL);
            foreach(var x in counted) { b.Append("    line ").Append(x.Number.ToString(CultureInfo.InvariantCulture)).Append(" ").Append(Q(x.Description)).Append(": ").Append(x.How).Append(NL);if(x.Unresolved) k++; }
            // A note isn't an item, but its words may change what ships (its words stay in the review, not here).
            var notes=r.Lines.Where(l=>l.Kind=="note").Select(l=>l.Number.ToString(CultureInfo.InvariantCulture)).ToList();
            if(notes.Count==1) b.Append("  Note line ").Append(notes[0]).Append(": not an item; read it on the invoice in case it changes what ships").Append(NL);
            else if(notes.Count>1) b.Append("  Note lines ").Append(String.Join(", ",notes)).Append(": not items; read them on the invoice in case they change what ships").Append(NL);
            // A fitting, balancing, changeover, nitrogen or labour charge beside tyres or wheels: they may have gone fitted, which
            // Tempe's rules don't cover.
            var fit=counted.FirstOrDefault(x=>x.Fitting);
            if(fit!=null&&items.Any(x=>x.Type!=BuffaloRules.Carton||x.Wheel)) { b.Append("  UNRESOLVED – line ").Append(fit.Number.ToString(CultureInfo.InvariantCulture)).Append(" ").Append(Q(fit.Description)).Append(" is a fitting, balancing, changeover, nitrogen or labour charge beside tyres or wheels: were they sent fitted (a wheel and tyre package)? Tempe's rules don't say how to book them").Append(NL);k++; }
            if(!r.LinesComplete) { b.Append("  UNRESOLVED – the lines are INCOMPLETE: ").Append(r.LinesWhy).Append(NL);k++; }
            else if(!LinesAddUp(r)) { b.Append("  UNRESOLVED – ").Append(r.CrossCheck??"the lines weren't checked against the invoice total").Append(" (a line may be missing: check the rows against the invoice)").Append(NL);k++; }
            b.Append(NL).Append("Freight on the invoice (a charge, never a weight): ").Append(r.FreightText??"not read").Append(NL);
            if(r.YShown) {
                var viaField=r.Fields.FirstOrDefault(f=>f.Role=="y.shipvia");string via=viaField==null?null:viaField.Value;
                if(!String.IsNullOrEmpty(via)) b.Append("Ship Via on Ship to: ").Append(Q(via)).Append(WholesaleRules.ShipViaBuf(via)?" (starts with BUF: a Buffalo order in the wholesale rules)":" (doesn't start with BUF: check this order goes by Buffalo)").Append(NL);
                else b.Append("Ship Via on Ship to: ").Append(via==null?"(not read)":"(empty)").Append(" – check this order goes by Buffalo").Append(NL);
            }
            if(!Done(r)) { b.Append("UNRESOLVED – the read is INCOMPLETE: ").Append(String.Join("; ",Reasons(r))).Append(NL);k++; }
            b.Append(NL).Append(k==0?AllFilled:"NOT READY FOR BOOKING – "+k.ToString(CultureInfo.InvariantCulture)+(k==1?" item unresolved":" items unresolved")).Append(NL);
            unresolved=k;
            return b.ToString();
        }
        // Every line was read: they add up to the invoice's Tax In total. Adding up to its Tax Out total isn't enough: the
        // only mapped invoice's line totals include GST, so lines worth the GST could be missing (the 2.9.16 review).
        static bool LinesAddUp(InvoiceRead r) {
            return r.CrossCheck!=null&&r.CrossCheck.StartsWith("lines add up to the invoice total (",StringComparison.Ordinal);
        }
        static void Row(StringBuilder b,string name,string value) { b.Append("  ").Append(Pad(name+":",12)).Append(value).Append(NL); }
        // A receiver box Buffalo needs (name, address, suburb): its value, or UNRESOLVED when it wasn't read or is empty.
        static string Needed(InvoiceRead r,string role,ref int k) {
            var f=r.Fields.FirstOrDefault(x=>x.Role==role);
            if(f==null||f.State=="not read") { k++;return "UNRESOLVED – not read"+(f!=null&&f.Why!=null?" ("+f.Why+")":""); }
            if(String.IsNullOrEmpty(f.Value)) { k++;return "UNRESOLVED – empty on Ship to"; }
            return f.Value;
        }
        // A receiver box that may be blank (email, contact): its value, blank when Ship to has none, UNRESOLVED when unread.
        static string Optional(InvoiceRead r,string role,ref int k) {
            var f=r.Fields.FirstOrDefault(x=>x.Role==role);
            if(f==null||f.State=="not read") { k++;return "UNRESOLVED – not read"+(f!=null&&f.Why!=null?" ("+f.Why+")":""); }
            return String.IsNullOrEmpty(f.Value)?"(none on Ship to: leave blank)":f.Value;
        }
        // The phone: Mobile Ph, else Bus Ph, else Home Ph (Tommy, 24 Nov). One that wasn't read before the one used: can't tell.
        static string Phone(InvoiceRead r,ref int k) {
            foreach(var p in new[]{new[]{"y.mobile","Mobile Ph"},new[]{"y.busph","Bus Ph"},new[]{"y.homeph","Home Ph"}}) {
                var f=r.Fields.FirstOrDefault(x=>x.Role==p[0]);
                if(f==null||f.State=="not read") { k++;return "UNRESOLVED – Ship to's "+p[1]+" wasn't read"; }
                if(!String.IsNullOrEmpty(f.Value)) return f.Value+"   [from "+p[1]+"]";
            }
            return "(no phone on Ship to: leave blank)";
        }

        // The full review shown in the big box: identity, header, X, Y, lines (exact SKUs), freight, totals, problems,
        // then the Buffalo details verbatim (so what Copy puts on the clipboard is what's shown).
        internal static string Review(InvoiceRead r) {
            if(r==null) return "";
            var b=new StringBuilder();
            b.Append("INVOICE READ (dry run: read only) — ").Append(NothingChanged).Append(NL);
            b.Append(Status(r)).Append(NL);
            if(r.Refused!=null) { b.Append("Nothing was prepared.").Append(NL);return b.ToString(); }
            b.Append(NL).Append("IDENTITY").Append(NL);
            foreach(var f in r.Fields.Where(f=>f.Section=="Identity")) b.Append("  ").Append(Pad(f.Label,48)).Append(FieldValue(f)).Append(NL);
            b.Append("  ").Append(Pad("Branch (from the window title)",48)).Append(r.Branch>0?r.Branch.ToString(CultureInfo.InvariantCulture)+"  "+Q(r.BranchName):"not read (no Invoice window title given)").Append(NL);
            b.Append(NL).Append("HEADER").Append(NL);
            foreach(var f in r.Fields.Where(f=>f.Section=="Header")) b.Append("  ").Append(Pad(f.Label+(f.Other?" (other field)":""),48)).Append(FieldValue(f)).Append(NL);
            b.Append(NL).Append("X — the customer frame (left)").Append(NL);
            foreach(var f in r.Fields.Where(f=>f.Section=="X")) b.Append("  ").Append(Pad(f.Label+(f.Other?" (other field)":""),48)).Append(FieldValue(f)).Append(NL);
            b.Append(NL).Append("Y — the Ship to tab").Append(NL);
            if(!r.YShown) b.Append("  ").Append(r.YWhy).Append(NL);
            else foreach(var f in r.Fields.Where(f=>f.Section=="Y")) b.Append("  ").Append(Pad(f.Label+(f.Other?" (other field)":""),48)).Append(FieldValue(f)).Append(NL);
            foreach(var o in r.Observations) b.Append("  Note: ").Append(o).Append(NL);
            b.Append(NL).Append("LINES (").Append(r.Lines.Count).Append(" read, ").Append(r.LinesComplete?"all lines":"INCOMPLETE: "+r.LinesWhy).Append(")").Append(NL);
            b.Append("  ").Append(Pad("#",4)).Append(Pad("Kind",17)).Append(Pad("Item (exact)",22)).Append(Pad("Description",36)).Append(Pad("Size / Complete?",19))
             .Append(Pad("Qty or Hrs",11)).Append(Pad("List",10)).Append(Pad("Disc",8)).Append(Pad("Net",10)).Append(Pad("Tax",5)).Append("Line total (no COSTAR heading)").Append(NL);
            Func<string,string> cell=delegate(string v) { return v==null?"(not read)":v; };
            foreach(var l in r.Lines) {
                string kind=l.Kind=="freight"?"FREIGHT":l.Kind=="possible-freight"?"POSSIBLE FREIGHT":l.Kind=="note"?"NOTE":"product";
                b.Append("  ").Append(Pad(l.Number.ToString(CultureInfo.InvariantCulture),4)).Append(Pad(kind,17)).Append(Pad(l.Item==null?"(not read)":"\""+l.Item+"\"",22));
                if(l.Kind=="note") b.Append("(note text below)");
                else b.Append(Pad(cell(l.Description),36)).Append(Pad(cell(l.Size),19)).Append(Pad(cell(l.Qty),11)).Append(Pad(cell(l.List),10)).Append(Pad(cell(l.Disc),8)).Append(Pad(cell(l.Net),10)).Append(Pad(cell(l.Tax),5)).Append(cell(l.LineTotal));
                b.Append(NL);
                if(l.Kind=="note") b.Append("        note: ").Append(l.Note==null?"(not read)":l.Note.Replace("\r\n","\n").Replace("\n",NL+"              ")).Append(NL);
                if(l.ItemRaw!=null&&l.ItemRaw!=l.Item) b.Append("        Item as read (raw): \"").Append(l.ItemRaw).Append("\"").Append(NL);
                foreach(var h in l.Hidden) b.Append("        hidden extra value ").Append(h).Append(NL);
                if(l.Unread.Count>0) b.Append("        not read: ").Append(String.Join(", ",l.Unread)).Append(NL);
                foreach(var col in new[]{l.List,l.Disc,l.Net,l.LineTotal}) { decimal d;if(col!=null&&col.Length>0&&!InvoiceReader.Money(col,out d)) { b.Append("        \"").Append(col).Append("\" is not a number").Append(NL); } }
            }
            b.Append(NL).Append("FREIGHT (separate from products; the lines above are unchanged)").Append(NL);
            foreach(var l in r.Lines.Where(l=>l.Kind=="freight"))
                b.Append("  line ").Append(l.Number).Append(" (Item F): Item ").Append(Q(l.Item)).Append(", Description ").Append(Q(l.Description)).Append(", Qty ").Append(Q(l.Qty)).Append(", Net ").Append(Q(l.Net)).Append(", Line total ").Append(Q(l.LineTotal)).Append(", Tax ").Append(Q(l.Tax)).Append(NL);
            foreach(var l in r.Lines.Where(l=>l.Kind=="possible-freight"))
                b.Append("  line ").Append(l.Number).Append(" POSSIBLE FREIGHT (by its words, not confirmed; also kept as a product line for review): Item ").Append(Q(l.Item)).Append(", Description ").Append(Q(l.Description)).Append(", Line total ").Append(Q(l.LineTotal)).Append(NL);
            b.Append("  freight service text (from Y Ship Via / ShipTerms): ").Append(r.YShown?"Ship Via "+Q(Get(r,"y.shipvia"))+", ShipTerms "+Q(Get(r,"y.shipterms")):"(Y not read)").Append(" — never an amount, never a weight").Append(NL);
            b.Append("  ").Append(r.FreightText??"Freight could not be read").Append(NL);
            b.Append(NL).Append("TOTALS").Append(NL);
            foreach(var t in r.Totals) { decimal d;b.Append("  ").Append(Pad(t.Label,48)).Append(FieldValue(t)).Append(t.Value!=null&&t.Value.Length>0&&!InvoiceReader.Money(t.Value,out d)?" (not a number)":"").Append(NL); }
            b.Append("  Check: ").Append(r.CrossCheck??"(not done)").Append(NL);
            b.Append(NL).Append("PROBLEMS / MISSING / AMBIGUOUS").Append(NL);
            var all=r.Incomplete.Concat(r.Problems).Distinct().ToList();
            if(all.Count==0) b.Append("  none").Append(NL);
            foreach(var p in all) b.Append("  - ").Append(p).Append(NL);
            b.Append(NL).Append("==== BUFFALO DETAILS (what Copy puts on the clipboard) ====").Append(NL);
            b.Append(Buffalo(r));
            return b.ToString();
        }
    }
}
