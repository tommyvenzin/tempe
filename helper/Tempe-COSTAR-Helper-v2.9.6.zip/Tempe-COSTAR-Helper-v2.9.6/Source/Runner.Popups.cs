// The entry engine, part 6 (2.6.11): COSTAR's notices over an order, answered with their one OK.
// Tommy, 2 Nov: "some customer may have notes popped up before we can access to repair order ... it cant be
// ignored, we have to press OK"; "Some customer have more than 1 pop up, so make sure both are cleared";
// "apply those pop up skips on all the orders". Seen on an account customer's Repair Order: the customer's
// Notes (a COSTAR window titled "Notes", with New / Colour / Delete, the notes, and one button: OK), then a
// message box "Point-of-sale Memo!" with its words and OK. Until 2.6.10 any such window stopped the entry
// (or the phone's Repair Order request) for a person to answer.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;

namespace TempeCostar {
    internal sealed partial class Runner {
        // Said with the result (the phone, the desk, the eBay PC): the customer's Notes answered. A memo's words go
        // with the things to check by hand (Checks): they're for the person (an instruction about the account, say).
        internal readonly List<string> Notices=new List<string>();
        int popupsAnswered;
        const int MostPopups=6;
        // The notices whose OK went: each waited for while it closes, never pressed again (2.6.11).
        readonly PressedNotices pressedNotices=new PressedNotices();readonly Stopwatch noticeClock=Stopwatch.StartNew();
        // What a COSTAR window over the order is, from its title, class and buttons alone: "notes" (the customer's
        // Notes: never read, they hold card details), "memo" (a Point-of-sale Memo), "notice" (another message
        // box with one OK), or null (anything else: a question with choices, a window with other buttons, the
        // Customer Not found notice (the customer lookup answers that one itself), the Repair Order...). Pure.
        internal static string PopupKind(string title,string cls,IList<string> buttons,string words) {
            if(buttons==null||buttons.Count!=1||Order.Norm(buttons[0]).Replace("&","")!="OK") return null;
            string t=Order.Clean(title);cls=cls??"";
            if(t.Equals("Notes",StringComparison.OrdinalIgnoreCase)) return cls.StartsWith("WindowsForms10.Window",StringComparison.OrdinalIgnoreCase)?"notes":null;
            if(cls!="#32770") return null;
            // A message box always has words: none read (COSTAR busy) is not known well enough to answer (it could be
            // Customer Not found, which the lookup must see for itself).
            if(Order.Norm(words).Length==0||Order.Norm(words).Contains("NOT FOUND")) return null;
            return t.StartsWith("Point-of-sale Memo",StringComparison.OrdinalIgnoreCase)?"memo":"notice";
        }
        // A button's name for PopupKind: a greyed one, or one whose text couldn't be read, is "?" (never OK). Pure.
        internal static string ButtonName(bool enabled,string text) { return enabled&&text!=null?text:"?"; }
        // A memo's words for the person: numbers (3 digits or more) and emails taken out, 160 letters.
        internal static string MemoWords(string words) {
            // Every run of digits holding 3 or more (with spaces, dashes, slashes or dots between) goes: a card number
            // with its expiry and code, a phone, an account or amount. Two-digit numbers stay.
            string w=Regex.Replace(Order.Norm(words),@"\d[\d \-/.]*\d",m=>m.Value.Count(Char.IsDigit)>=3?"[number]":m.Value);
            w=Regex.Replace(w,@"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}","[email]");
            return w.Length>160?w.Substring(0,160)+"...":w;
        }
        // Whether the window is this order's own (owned, directly or through other owned windows, by its Repair
        // Order window): another order's notes are never touched. (A window of COSTAR's from before the run that is
        // owned by this Repair Order is still this order's: the phone's Repair Orders make their Runner after the
        // Repair Order, and its Notes, have shown.)
        bool OwnedByOrder(IntPtr window) {
            var owner=window;
            for(int i=0;i<16&&owner!=IntPtr.Zero;i++) { owner=Native.GetWindow(owner,4);if(owner==root) return true; }
            return false;
        }
        // 2.9.4: COSTAR's Document Already Open (by title alone): its words are never dumped.
        internal static bool IsInUseWindow(IntPtr window) { return window!=IntPtr.Zero&&Order.Clean(Native.Caption(window)).Equals(DocumentInUse.Title,StringComparison.OrdinalIgnoreCase); }
        // Whether a window is the customer's Notes (by title alone): its contents are never read or dumped, even
        // when it can't be answered.
        internal static bool IsNotesWindow(IntPtr window) {
            return window!=IntPtr.Zero&&Order.Clean(Native.Caption(window)).Equals("Notes",StringComparison.OrdinalIgnoreCase)&&Native.Class(window).StartsWith("WindowsForms10.Window",StringComparison.OrdinalIgnoreCase);
        }
        // A Point-of-sale Memo (a message box): its words may hold card details, so it is never dumped either.
        internal static bool IsMemoWindow(IntPtr window) {
            return window!=IntPtr.Zero&&Native.Class(window)=="#32770"&&Order.Clean(Native.Caption(window)).StartsWith("Point-of-sale Memo",StringComparison.OrdinalIgnoreCase);
        }
        // The window in front answered with its OK when it is one of COSTAR's notices over this order. True:
        // answered (gone), or its OK went and it is being waited for (the caller looks again; after
        // PressedNotices.CloseMs the run stops). False: not such a notice, or its OK couldn't be sent (nothing pressed).
        bool AnswerPopup(IntPtr front) {
            if(front==IntPtr.Zero||front==root||!Native.IsWindow(front)||!Native.IsWindowVisible(front)||Native.Pid(front)!=pid) return false;
            if(Native.Caption(front).StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase)||!OwnedByOrder(front)) return false;
            // A notice whose OK went is known by its window alone (not read again: COSTAR may be busy closing it):
            // waited for, never pressed again, never cancelled. Ones gone since are forgotten.
            pressedNotices.Sweep(delegate(long w) { var h=new IntPtr(w);return Native.IsWindow(h)&&Native.IsWindowVisible(h); });
            string pressedKind;string look=pressedNotices.Look(front.ToInt64(),noticeClock.ElapsedMilliseconds,out pressedKind);
            if(look!=null) {
                Order.Require(look=="wait","COSTAR's "+(pressedKind=="notes"?"Notes":"notice")+" over the order stayed open after its OK was pressed. Nothing more was pressed: close it at the PC, then retry.");
                Pause(100);return true;
            }
            string title=Native.Caption(front),cls=Native.Class(front);
            var buttons=new List<IntPtr>();var names=new List<string>();var statics=new List<string>();
            Native.EnumChildWindows(front,delegate(IntPtr h,IntPtr unused) {
                if(!Native.IsWindowVisible(h)) return true;
                string c=Native.Class(h),t;
                // A greyed button isn't one to press: the window is then not known well enough.
                if(c.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0) { buttons.Add(h);names.Add(ButtonName(Native.IsWindowEnabled(h),Native.TryText(h,out t)?t:null)); }
                else if(cls=="#32770"&&c.IndexOf("STATIC",StringComparison.OrdinalIgnoreCase)>=0&&Native.TryText(h,out t)&&Order.Clean(t).Length>0) statics.Add(Order.Clean(t));
                return buttons.Count+statics.Count<40;
            },IntPtr.Zero);
            string kind=PopupKind(title,cls,names,String.Join(" ",statics.ToArray()));
            if(kind==null) return false;
            Order.Require(popupsAnswered<MostPopups,"COSTAR keeps showing notices over the order ("+popupsAnswered+" answered with OK). Look at COSTAR before retrying.");
            // Its own OK (BM_CLICK sent; a message box's OK closes it as it returns). Nothing else is pressed. Not sent
            // at all (the button went): nothing pressed, the caller's usual way. Sent (answered or not): remembered,
            // never pressed again; what COSTAR showed is said from now on, however long it takes to close.
            int sent=Direct.Press(buttons[0],1500);Diag.Pressed();
            if(sent<0) { Diag.EventRaw("popup_ok",kind+" \""+Sanitize.Text(title,40)+"\": OK couldn't be pressed");return false; }
            pressedNotices.Pressed(front.ToInt64(),noticeClock.ElapsedMilliseconds,kind);popupsAnswered++;
            string note=kind=="notes"?"COSTAR showed the customer's Notes before the order (OK pressed): see them in COSTAR if you need to."
                :"COSTAR showed "+(kind=="memo"?"a Point-of-sale Memo":"a notice \""+Sanitize.Text(title,40)+"\"")+": \""+MemoWords(String.Join(" ",statics.ToArray()))+"\" (OK pressed).";
            var list=kind=="notes"?Notices:Checks;
            if(!list.Contains(note)) list.Add(note);
            var gone=Stopwatch.StartNew();
            while(Native.IsWindow(front)&&Native.IsWindowVisible(front)&&gone.ElapsedMilliseconds<(sent==0?3000:2000)) Pause(25);
            bool closed=!Native.IsWindow(front)||!Native.IsWindowVisible(front);
            if(closed) pressedNotices.Gone(front.ToInt64());
            Diag.EventRaw("popup_ok",kind+" \""+Sanitize.Text(title,40)+"\": "+(closed?"closed":"still showing")+" ("+(sent==1?"OK pressed":"OK unanswered")+")");
            if(closed) Say("Answered COSTAR's "+(kind=="notes"?"Notes":kind=="memo"?"Point-of-sale Memo":"notice")+" with OK.");
            return true;
        }
        long inUseNotPressed;
        // 2.9.4: the usual look right before a press it makes for the phone (RoEngine: nobody used the PC since the open).
        internal Action BeforePress;
        // 2.9.4: the Repair Order being opened is open on another PC: COSTAR's OK pressed, the phone told
        // (RoInUseException). Only COSTAR's own window over this Repair Order; nothing happens for any other window,
        // and nothing is pressed when it changed in between (looked at again next time round).
        void InUse(IntPtr front) {
            if(front==IntPtr.Zero||front==root||Native.Pid(front)!=pid||!OwnedByOrder(front)) return;
            string words;IntPtr ok=DocumentInUse.Read(front,out words);
            if(ok==IntPtr.Zero) return;
            int answered=DocumentInUse.Answer(front,ok,delegate { Check(false);var before=BeforePress;if(before!=null) before();return true; });
            if(answered<0) {
                if(inUseNotPressed!=front.ToInt64()) { inUseNotPressed=front.ToInt64();Diag.EventRaw("ro_in_use","Document Already Open: OK not pressed; looked at again"); }
                return;
            }
            Diag.Pressed();
            Diag.EventRaw("ro_in_use","Document Already Open: "+(answered==1?"OK pressed, it closed":"OK pressed, still showing")+"; COSTAR's words "+words.Length+" letters");
            Order.Require(answered==1,"COSTAR's \"Document Already Open\" stayed open after its OK was pressed. Nothing more was pressed: close it at the PC (Repair Order "+roDoc+" is open on another PC).");
            Say("Repair Order "+roDoc+" is open on another PC: COSTAR's Document Already Open answered with OK.");
            throw new RoInUseException(roDoc,words);
        }
        // The Notes answered, for the result ("" when none).
        internal string NoticeWords(string separator) { return Notices.Count==0?"":String.Join(separator,Notices.ToArray()); }
    }

    // 2.9.4 (Tommy, 9 Nov 10:45: "the mobile repair order will stop if document is open on another pc, can it tells
    // me instead and automatically press ok? by pressing ok, it will go to the repair order screen so I can keep using
    // it"): COSTAR's "Document Already Open", mapped 9 Nov 10:43: a COSTAR window of its own with that title, owned by
    // the Repair Order being opened, its words in two labels, and two buttons, OK (with the keyboard) and Retry. Its OK
    // is pressed, never Retry; its words go to the phone only, never to a log.
    internal static class DocumentInUse {
        internal const string Title="Document Already Open";
        // Pure: that window, from its title, class and buttons (both usable: a greyed or unread one is "?").
        internal static bool Is(string title,string cls,IList<string> buttons) {
            if(buttons==null||buttons.Count!=2||!Order.Clean(title).Equals(Title,StringComparison.OrdinalIgnoreCase)||!(cls??"").StartsWith("WindowsForms10.Window",StringComparison.OrdinalIgnoreCase)) return false;
            var names=buttons.Select(b=>Order.Norm(b).Replace("&","")).OrderBy(b=>b,StringComparer.Ordinal).ToList();
            return names[0]=="OK"&&names[1]=="RETRY";
        }
        // Its OK and its words (the labels, top first) when the window is that one; zero (and no words) otherwise.
        internal static IntPtr Read(IntPtr window,out string words) {
            words="";
            if(window==IntPtr.Zero||!Native.IsWindow(window)||!Native.IsWindowVisible(window)) return IntPtr.Zero;
            // Its title first: any other window (a Repair Order being built, say) isn't read at all.
            if(!Order.Clean(Native.Caption(window)).Equals(Title,StringComparison.OrdinalIgnoreCase)) return IntPtr.Zero;
            var names=new List<string>();var labels=new List<Tuple<int,int,string>>();IntPtr ok=IntPtr.Zero;
            Native.EnumChildWindows(window,delegate(IntPtr h,IntPtr unused) {
                if(!Native.IsWindowVisible(h)) return true;
                string c=Native.Class(h),t;
                if(c.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0) {
                    string name=Runner.ButtonName(Native.IsWindowEnabled(h),Native.TryText(h,out t)?t:null);names.Add(name);
                    if(Order.Norm(name).Replace("&","")=="OK") ok=h;
                } else if(c.IndexOf("STATIC",StringComparison.OrdinalIgnoreCase)>=0&&Native.TryText(h,out t)&&Order.Clean(t).Length>0) {
                    Native.Rect r;bool got=Native.GetWindowRect(h,out r);labels.Add(Tuple.Create(got?r.Top:0,got?r.Left:0,Order.Clean(t)));
                }
                return names.Count+labels.Count<20;
            },IntPtr.Zero);
            if(!Is(Native.Caption(window),Native.Class(window),names)||ok==IntPtr.Zero) return IntPtr.Zero;
            words=Words(labels.OrderBy(x=>x.Item1).ThenBy(x=>x.Item2).Select(x=>x.Item3));
            return ok;
        }
        // Pure: COSTAR's words for the phone, on one line, 300 letters at most.
        internal static string Words(IEnumerable<string> labels) { return EbayText.Clean(String.Join(" ",(labels??new string[0]).Where(x=>!String.IsNullOrWhiteSpace(x)).ToArray()),300).Replace("\"","'"); }
        // How long a pressed OK is given to close the window (as a notice's, PressedNotices.CloseMs).
        internal const int CloseMs=6000;
        // OK pressed once, the window looked at again right before (still that window, its OK the same one, usable) and
        // then ready (the caller's usual look: nobody at the PC, not stopped; it may throw). 1: it closed; 0: pressed,
        // still showing after CloseMs; -1: not pressed (it changed, or the press couldn't be sent).
        internal static int Answer(IntPtr window,IntPtr ok,Func<bool> ready) {
            string again;
            if(Read(window,out again)!=ok||!Native.IsWindowEnabled(window)||!Native.IsWindowEnabled(ok)) return -1;
            if(ready!=null&&!ready()) return -1;
            int sent=Direct.Press(ok,1500);
            if(sent<0) return -1;
            var gone=Stopwatch.StartNew();
            while(Native.IsWindow(window)&&Native.IsWindowVisible(window)&&gone.ElapsedMilliseconds<CloseMs) System.Threading.Thread.Sleep(25);
            return !Native.IsWindow(window)||!Native.IsWindowVisible(window)?1:0;
        }
        // Pure: what is said of it, for the phone (words: with COSTAR's) or the helper's own log (without): what the phone
        // asked for (kind: open, edit, print) can't be done until it's closed there, and what is left in COSTAR.
        internal static string Message(RoInUseException e,bool leftOpen,string kind,bool words) {
            string done=kind=="edit"?"changed":kind=="print"?"printed":"opened",left=leftOpen?"form":e.Left;
            return "Repair Order "+e.Doc+" is open on another PC, so it can't be "+done+" from the phone until it's closed there. The helper pressed OK on COSTAR's \"Document Already Open\"."
                +(words&&e.Said.Length>0?" COSTAR said: \""+e.Said+"\"":"")
                +(left=="form"?" COSTAR left a Repair Order window open: close it at the PC (nothing was changed)."
                    :left=="busy"?" Nothing was changed, but COSTAR is still showing something: check it at the PC before the next one."
                    :" Nothing was changed, and COSTAR is ready for the next one.");
        }
    }
    // 2.9.4: the Repair Order is open on another PC (DocumentInUse), its OK pressed. Said: COSTAR's words, for the phone
    // only (the message itself goes to the logs).
    // Left: what is left in COSTAR after its OK: "" nothing, "form" the form COSTAR was opening it in (it couldn't be
    // closed), "busy" COSTAR's main window not usable yet.
    internal sealed class RoInUseException : InvalidOperationException {
        internal readonly string Doc,Said,Left;
        internal bool LeftOpen { get { return Left.Length>0; } }
        internal RoInUseException(string doc,string said,string left="") : base("Repair Order "+doc+" is open on another PC (COSTAR showed \"Document Already Open\": the helper pressed its OK).") { Doc=doc??"";Said=said??"";Left=left??""; }
    }

    // 2.6.11: the notices whose OK went, each with when and its kind. One still showing is waited for (CloseMs from
    // its press), never pressed again and never cancelled; one gone (closed or hidden) is forgotten, so a window
    // shown again later is a new notice. Several at once are all remembered. Pure: the time is given.
    internal sealed class PressedNotices {
        sealed class Press { internal long At;internal string Kind; }
        readonly Dictionary<long,Press> pressed=new Dictionary<long,Press>();
        internal const int CloseMs=6000;
        internal int Count { get { return pressed.Count; } }
        internal void Pressed(long window,long nowMs,string kind) { pressed[window]=new Press {At=nowMs,Kind=kind}; }
        internal void Gone(long window) { pressed.Remove(window); }
        // null: its OK hasn't gone (it may be answered); "wait": it has, give it time; "stop": CloseMs on, still there.
        internal string Look(long window,long nowMs,out string kind) {
            Press p;kind=null;
            if(!pressed.TryGetValue(window,out p)) return null;
            kind=p.Kind;return nowMs-p.At<CloseMs?"wait":"stop";
        }
        internal void Sweep(Func<long,bool> showing) { foreach(long w in pressed.Keys.ToList()) if(!showing(w)) pressed.Remove(w); }
    }
}
