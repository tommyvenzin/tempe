// The RDP helper window's Repair Orders card (2.6.0), on the Mobile jobs tab: on/off, the desk
// connection, what it is doing, and a Repair Order it left open.
using System;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed partial class WorkerForm {
        RoEngine ro;
        readonly Label roLine=Ui.Text("",800),roDetailLine=Ui.Hint("",800);
        readonly CheckBox roToggle=Ui.Check("Repair Orders from the phone: open, change and close them in COSTAR Tempe",AppSettings.Current.roOn);
        bool syncingRo;
        void BuildRoCard(FlowLayoutPanel lines) {
            var title=Ui.Title("Repair Orders from the phone");title.Margin=new Padding(0,14,0,2);
            lines.Controls.Add(title);lines.Controls.Add(roLine);lines.Controls.Add(roDetailLine);lines.Controls.Add(roToggle);
            roToggle.CheckedChanged+=delegate {
                if(syncingRo||ro==null) return;
                if(roToggle.Checked) { ro.Start();Append("Repair Orders from the phone on: they are opened and changed in COSTAR Tempe when it is free and nobody is using this PC."); }
                else { ro.Stop(true);Append("Repair Orders from the phone switched off. Phones' requests wait on the desk PC."); }
                UpdateStatus();
            };
        }
        void UpdateRoCard() {
            if(ro==null) {
                Ui.SetText(roLine,"Repair Orders from the phone need the desk connection (worker-connection.json), like mobile jobs.");
                Ui.SetText(roDetailLine,"");roToggle.Enabled=false;return;
            }
            if(roToggle.Checked!=ro.Enabled) { syncingRo=true;try{roToggle.Checked=ro.Enabled;}finally{syncingRo=false;} }
            int since=ro.SecondsSinceContact;string left=ro.LeftOpen;
            Ui.SetText(roLine,ro.Connection+(since>=0?" ("+(since<=1?"just now":since+" s ago")+")":"")+"  ·  "+(ro.Enabled?"Repair Orders ON":"Repair Orders OFF")+
                (ro.Current.Length>0?"  ·  "+ro.Current:ro.LastLine.Length>0?"  ·  Last: "+ro.LastLine:""));
            Ui.SetText(roDetailLine,(left.Length>0?"Repair Order "+left+" was left open after a change stopped: check it in COSTAR and close it (or close it from the phone).  ":"")+ro.Detail);
            roToggle.Enabled=true;
        }
    }
}
