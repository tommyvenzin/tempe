// Wholesale orders, stage 1: a dry run (helper 2.9.0; Tommy, 29 Oct - 3 Nov: claude/20-Wholesale-Order-Plan.md).
// On a button on the RDP helper's Wholesale tab: COSTAR Sydney (Branch 1) is put on "Orders yet to be filled" (its
// left-hand menu's Wholesale Order) and searched; the BUF orders whose Comment and ShipDate say they're to be done are
// opened one at a time, oldest first; COSTAR's notices over each are answered with OK (the customer's Notes looked at
// for card details first: only yes/no is kept); its Terms, Comment and lines are read; and it is closed again with
// nothing typed. Then Repair Order (Work-in-Progress) again, for eBay orders. It shows what it WOULD do (Tommy, 3 Nov:
// "open order, check terms, check notes, check stock, if everything ok, sell and cancel, if not ok, put on
// comments"): sell (Sell, then Cancel), a comment (CHECK STOCK; NO CARD DETAILS for a CASH order without card
// details), or leave the order alone (and why). Nothing is typed, sold or changed. Sydney's stock of each tyre line is
// read on the line's stock panel (the 3 Nov maps): the line clicked open (one click into its read-only words), ThisBr
// "= Avail" read, this order's own tyres added back (they're in COSTAR's Commit); the order is read again before it's
// closed, and left open if anything changed (closing saves).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    // A row of "Orders yet to be filled", as COSTAR lists it.
    internal sealed class WholesaleRow { internal string Doc="",OrderDate="",ShipDate="",Name="",Comment="",By="",Po="",PoTotal="",ShipVia="",Source=""; }
    // A line of a wholesale Order. Available: Sydney's ThisBr "= Avail" (null: not read; StockWhy: why, when it was tried);
    // NonStocking: COSTAR says the item isn't stocked. Panel: the line's own panel.
    internal sealed class WholesaleLine {
        internal int Number;internal string Item="",Description="",Size="",OrderQty="",BackOrder="",ShipQty="",StockWhy;internal bool Note,Tyre,NonStocking;internal int? Available;
        // Opens: the line's words box when it's read-only (what's clicked to open the line; 0: none such, not clicked).
        // Open: the line is the open one (its panel at least twice its item box's height: 20 px closed, 160 open on the
        // 3 Nov maps; by the boxes, so the PC's display scaling doesn't matter).
        internal long Panel,Opens;internal bool Open;
    }
    // What the Order window showed. Number, Terms, Comment: null when they couldn't be read.
    internal sealed class WholesaleOrderView {
        internal string Number,Terms,Comment,Problem;internal bool NotesMarker,MoreLines;
        internal readonly List<WholesaleLine> Lines=new List<WholesaleLine>();
    }
    // What the helper would do: "sell" (Sell, then Cancel), "comment" (Words added to the end of the Comment), "leave"
    // (Why), or "stock" (everything else is fine, but a tyre's stock couldn't be checked: Why says which and why).
    internal sealed class WholesaleVerdict { internal string Action="leave",Words="",Why=""; }
    // One listed order and what came of looking at it. Skip: why it wasn't opened (null: it was, or will be).
    internal sealed class WholesaleLook {
        internal WholesaleRow Row;internal string Skip;internal bool Opened;internal string Number,Terms,OrderComment,Problem;
        internal bool? Card;internal bool NotesShown,NotesMarker,MoreLines;
        // The tab showing over the order's header (Ship to, Rebill to, Contacts, Notes): with Notes showing, the
        // "Notes" marker over its caption doesn't show (the 30 Oct maps). null: it couldn't be read.
        internal string Tab;
        internal readonly List<string> Memos=new List<string>();internal readonly List<WholesaleLine> Lines=new List<WholesaleLine>();
        // What each Notes window over the order said: card details there (true), not (false), couldn't be read (null).
        internal readonly List<bool?> NotesRead=new List<bool?>();
        // The stock read: a line clicked (LinesOpened); the order then read again and found as before (Checked), or
        // what changed (Changed: the order is left open, closing would save it).
        internal bool LinesOpened,Checked;internal string Changed;
        // Left open by the run (null: closed, or not opened): unchanged, or its tyre lines clicked / found changed.
        // ChangedValues: for the tab only (never the day log), what the changed box showed before and after.
        internal string LeftOpen,ChangedValues;
        internal WholesaleVerdict Verdict;
    }

    // The rules (pure: the self-tests check them with made-up orders).
    internal static class WholesaleRules {
        // Always COSTAR Sydney, Branch 1 (Tommy, 30 Oct: "always sydney branch 1").
        internal const int Branch=1;
        internal const string ListTitle="Orders yet to be filled";
        // Enough stock: more than 4 Available (Tommy, 30 Oct: "more than 4 Available, not on hand"; "its obvious, more than 4").
        internal const int MoreThan=4;
        internal const string ShortWords="CHECK STOCK";
        // A CASH order without card details gets a comment too (Tommy, 3 Nov: "if not ok, put on comments"). The words
        // were put to him on 3 Nov; NO CARD DETAILS until he says otherwise.
        internal const string NoCardWords="NO CARD DETAILS";
        // Orders opened in one run at most (oldest first); the rest wait for the next press.
        internal const int MostPerRun=30;
        // The Comment words an order is done with (Tommy, 30 Oct: "we have to check the BUFFALLO, WWW and blank"; Mona:
        // "SOMETIMES IT WILL SAY WWW BUFF OR WWW"; 3 Nov: BUF, BUFF and WWW BUFFALO count the same). Any other words:
        // someone is already doing it (B/O, AWAITING TT, GAT, NO STOCK..., AT 11, a date, CHECK STOCK ...).
        static readonly string[] Processed={"","WWW","BUF","BUFF","BUFFALO","WWW BUF","WWW BUFF","WWW BUFFALO"};
        internal static string Words(string s) { return Regex.Replace((s??"").ToUpperInvariant(),@"\s+"," ").Trim(); }
        internal static bool CommentToDo(string comment) { return Array.IndexOf(Processed,Words(comment))>=0; }
        // The order's own Ship Via is BUF... (BUFRIV, BUFWEST, BUFF, BUFFAR, BUFNEWC, BUFGLBN; Mona: "WHAT WE NEED TO
        // PROCESS IS BUF").
        internal static bool ShipViaBuf(string shipVia) { return Words(shipVia).StartsWith("BUF",StringComparison.Ordinal); }
        // A COSTAR date as yyyy-MM-dd: "" when empty, null when it can't be read.
        internal static string DateIso(string text) {
            string t=(text??"").Trim();if(t.Length==0) return "";
            string iso=TempeOrderCheck.Text.IsoDate(t);return iso.Length>0?iso:null;
        }
        // Why a BUF order on the list isn't opened (null: it is). today: Sydney's date, yyyy-MM-dd. A ShipDate after today
        // waits (Tommy, 3 Nov: "something like at11, leave it for now").
        internal static string Screen(WholesaleRow r,string today) {
            if(!ShipViaBuf(r.ShipVia)) return "not BUF";
            if(!CommentToDo(r.Comment)) return "Comment \""+Shown(r.Comment)+"\": someone is on it";
            string ship=DateIso(r.ShipDate);
            if(ship==null) return "ShipDate \""+Shown(r.ShipDate)+"\" can't be read";
            if(ship.Length>0&&String.CompareOrdinal(ship,today)>0) return "ShipDate "+Shown(r.ShipDate)+" is after today: left for now";
            return null;
        }
        internal static string Shown(string s) { string t=Regex.Replace(s??"",@"\s+"," ").Trim();return t.Length>40?t.Substring(0,40)+"...":t; }
        // Oldest first: by Order Date, then by number (an empty or unreadable date last).
        internal static List<WholesaleRow> Oldest(IEnumerable<WholesaleRow> rows) {
            return rows.OrderBy(r=>{ string d=DateIso(r.OrderDate);return String.IsNullOrEmpty(d)?"9999":d; }).ThenBy(r=>r.Doc,StringComparer.Ordinal).ToList();
        }
        // COSTAR's Term Codes (Tommy, 2 Nov 09:22). All go ahead but CASH without card details (09:24: "you only have to
        // leave alone cash with no card details, we process the rest"); one that's empty, unreadable or not among these:
        // the helper can't tell, so the order is left alone.
        internal static readonly string[] TermCodes={"1INV","7INV","7ST","14INV","14ST","21INV","21ST","30INV","30ST","60INV","60ST","CASH","COD","EOM"};
        internal static string TermCode(string terms) { var m=Regex.Match(Words(terms),@"^[A-Z0-9]+");return m.Success?m.Value:""; }
        // Card details (Tommy, 2 Nov: "normally 16 digits in groups, plus expiry date and CVV"): in one note, a card
        // number (13-19 digits, alone or in groups of 4 (or 4-6-5) split by spaces or dashes, passing the card check
        // digit) and an expiry (M/YY, MM/YY, MM/YYYY, MM-YY, or EXP followed by MMYY; a year 20-39: not a price "12.50"
        // or a date "2/11"). The words are looked at here only: the answer (yes/no) is all that is kept; they are never
        // kept, logged, shown or sent.
        // base: the number as written; tail: a short group after four groups of 4 (a 17-19 digit card, or the CVV).
        static readonly Regex CardNumber=new Regex(@"(?<![0-9])(?:(?<base>[0-9]{13,19})|(?<base>[0-9]{4}(?:[ \-]{1,2}[0-9]{4}){3})(?<tail>[ \-]{1,2}[0-9]{1,3}(?![0-9/]))?|(?<base>[0-9]{4}[ \-]{1,2}[0-9]{6}[ \-]{1,2}[0-9]{5}))(?![0-9])",RegexOptions.CultureInvariant);
        static readonly Regex Expiry=new Regex(@"(?<![0-9/.\-])(?:0?[1-9]|1[0-2])\s?[/\-]\s?(?:20[2-3][0-9]|[2-3][0-9])(?![0-9/.\-])|EXP[A-Z]*[\s:.]*(?:0[1-9]|1[0-2])\s?[/\-]?\s?(?:20[2-3][0-9]|[2-3][0-9])(?![0-9])",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant);
        // 2.9.2: a window over the order not read in full, so COSTAR may still be making it (looked at again for a moment
        // before the run stops): no button, a button greyed or its words unread ("?" from Runner.ButtonName), or a message
        // box with no words read or some unread. One read in full that the dry run doesn't answer stops the run at once.
        internal static bool NotReadYet(string cls,IList<string> buttons,int words,int unread) {
            if(buttons==null||buttons.Count==0||buttons.Contains("?")) return true;
            return cls=="#32770"&&(words==0||unread>0);
        }
        internal static bool CardDetails(IEnumerable<string> notes) {
            foreach(var n in notes??new string[0]) {
                string t=n??"";
                if(!Expiry.IsMatch(t)) continue;
                foreach(Match m in CardNumber.Matches(t)) {
                    string whole=Regex.Replace(m.Value,"[^0-9]",""),first=Regex.Replace(m.Groups["base"].Value,"[^0-9]","");
                    if(Luhn(whole)||Luhn(first)) return true;
                }
            }
            return false;
        }
        // Card details for the order: from the Notes that popped up (any with them: yes; else any unreadable: can't
        // tell; else no). None popped up: no card details, unless the order may have notes all the same (marker: its
        // "Notes" marker shows, or the Notes tab is showing (the marker then doesn't), or that can't be told): they
        // didn't pop up, so they weren't read.
        internal static bool MayHaveNotes(bool marker,string tab) { return marker||tab==null||Words(tab)=="NOTES"; }
        internal static bool? CardFrom(IList<bool?> notesRead,bool marker) {
            if(notesRead!=null&&notesRead.Count>0) return notesRead.Any(x=>x==true)?true:notesRead.Any(x=>x==null)?(bool?)null:false;
            return marker?(bool?)null:false;
        }
        // The card check digit (Luhn).
        internal static bool Luhn(string digits) {
            if(digits==null||digits.Length<13||digits.Length>19) return false;
            int sum=0;bool twice=false;
            for(int i=digits.Length-1;i>=0;i--) { int d=digits[i]-'0';if(d<0||d>9) return false;if(twice) { d*=2;if(d>9) d-=9; }sum+=d;twice=!twice; }
            return sum%10==0;
        }
        // A tyre's size ("205/55R16", "245/45ZR18", "LT245/75R16", "265/70-16", "31X10.50R15", "7.50R16", "7.00-16",
        // "195R15", "11R22.5"; a tube "7.50-16" counts too: its stock is checked as well). A line is a tyre when its Size or its Description holds one (Tommy, 2 Nov: "only check tyres":
        // wheels, tubes, freight, fitting and note lines aren't checked). A wheel "17X8.0 5/114.3" isn't.
        static readonly Regex TyreSize=new Regex(@"(?<![0-9])(?:[0-9]{3}/[0-9]{2}(?:\.[0-9])?\s?(?:Z?R\s?F?|-\s?)[0-9]{2}(?:\.[0-9])?|[0-9]{2}(?:\.[0-9]{1,2})?X[0-9]{1,2}(?:\.[0-9]{1,2})?\s?Z?R\s?[0-9]{2}(?:\.[0-9])?|[0-9]{1,2}\.[0-9]{2}\s?(?:-|R)\s?[0-9]{2}(?:\.[0-9])?|[0-9]{2,3}R[0-9]{2}(?:\.[0-9])?)(?![0-9])",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant);
        internal static bool Tyre(string size,string description) { return TyreSize.IsMatch(Words(size))||TyreSize.IsMatch(Words(description)); }
        internal static bool Enough(int available) { return available>MoreThan; }
        // A tyre line's stock as the rule counts it (Tommy, 3 Nov: this order's own tyres are inside COSTAR's Commit, so
        // ThisBr "= Avail" is what's left after this order; "Add this order's qty back"): "= Avail" plus this order's
        // Order Qty of that item, on every line it's on. null: not read, or an Order Qty that can't be read (why).
        internal static int? Have(WholesaleLook l,WholesaleLine x,out string why) {
            why=null;
            if(x.Available==null) return null;
            int own=0;
            foreach(var y in l.Lines.Where(y=>!y.Note&&y.Item==x.Item)) {
                string q=(y.OrderQty??"").Replace(",","").Trim();decimal n;
                if(!Decimal.TryParse(q,NumberStyles.AllowDecimalPoint,CultureInfo.InvariantCulture,out n)||n>=100000m) { why="line "+y.Number+"'s Order Qty "+(q.Length==0?"is empty":"reads \""+Shown(q)+"\"");return null; }
                own+=(int)Math.Floor(n);
            }
            return x.Available.Value+own;
        }
        // A tyre line's stock in words (the tab, and why).
        internal static string StockWords(WholesaleLook l,WholesaleLine x) {
            if(x.NonStocking) return "not stocked in Sydney (NON-STOCKING)";
            if(x.Available==null) return "stock not read"+(x.StockWhy!=null?": "+x.StockWhy:"");
            string why;int? have=Have(l,x,out why);
            if(have==null) return "= Avail "+x.Available.Value+" in Sydney, but "+why;
            return "= Avail "+x.Available.Value+" in Sydney + "+(have.Value-x.Available.Value)+" on this order = "+have.Value;
        }
        // The Comment with words added to its end (Tommy, 30 Oct: "add to the end").
        internal static string WithWords(string comment,string words) { string c=(comment??"").Trim();return c.Length==0?words:c+" "+words; }
        // What would be done with an order that was opened and read: its Comment again, Terms, then the Notes (CASH),
        // then the stock of every tyre line; the first that isn't OK decides.
        internal static WholesaleVerdict Decide(WholesaleLook l) {
            var v=new WholesaleVerdict();
            if(l.Problem!=null) { v.Why=l.Problem;return v; }
            // The order's own Comment as it is now (the list's was read at the start of the run).
            if(l.OrderComment==null) { v.Why="its Comment couldn't be read";return v; }
            if(!CommentToDo(l.OrderComment)) { v.Why="its Comment now says \""+Shown(l.OrderComment)+"\": someone is on it";return v; }
            if(l.Terms==null) { v.Why="its Terms couldn't be read";return v; }
            string code=TermCode(l.Terms);
            if(code.Length==0) { v.Why="its Terms are empty (the helper can't tell)";return v; }
            if(Array.IndexOf(TermCodes,code)<0) { v.Why="its Terms \""+Shown(l.Terms)+"\" aren't one of COSTAR's codes";return v; }
            if(code=="CASH") {
                if(l.Card==null) { v.Why=l.NotesShown?"CASH, and the customer's Notes couldn't be read":"CASH, and the order may have Notes that didn't pop up: check them by hand";return v; }
                if(l.Card==false) { v.Action="comment";v.Words=NoCardWords;v.Why="CASH, no card details in the customer's Notes";return v; }
            }
            if(l.MoreLines) { v.Why="it has more lines than show (over 25): check it by hand";return v; }
            var items=l.Lines.Where(x=>!x.Note&&x.Item.Length>0).ToList();
            if(items.Count==0) { v.Why="no item lines were read";return v; }
            var tyres=items.Where(x=>x.Tyre).ToList();
            string terms=code=="CASH"?"CASH with card details":"Terms "+code;
            if(tyres.Count==0) { v.Action="sell";v.Why=terms+"; no tyre lines (only tyres are checked)";return v; }
            // A tyre COSTAR doesn't stock in Sydney (NON-STOCKING!) has none available: short (Tommy, 3 Nov: "Yes, comment
            // CHECK STOCK"). Each counted with this order's own tyres added back (Have).
            var have=new Dictionary<WholesaleLine,int?>();
            foreach(var x in tyres) { string unused;have[x]=x.NonStocking?null:Have(l,x,out unused); }
            var unread=tyres.Where(x=>!x.NonStocking&&have[x]==null).ToList();
            var shortOf=tyres.Where(x=>x.NonStocking||(have[x]!=null&&!Enough(have[x].Value))).ToList();
            if(shortOf.Count>0) {
                v.Action="comment";v.Words=ShortWords;
                v.Why=String.Join(", ",shortOf.Select(x=>"line "+x.Number+" "+x.Item+": "+StockWords(l,x)).ToArray());
                return v;
            }
            if(unread.Count>0) { v.Action="stock";v.Why=terms+"; "+String.Join(", ",unread.Select(x=>"line "+x.Number+" ("+x.Item+"): "+StockWords(l,x)).ToArray());return v; }
            v.Action="sell";v.Why=terms+"; every tyre has more than "+MoreThan+" in Sydney (\"= Avail\" plus this order's own)";
            return v;
        }
        // For the tab: what it would do.
        internal static string Plain(WholesaleVerdict v) {
            if(v==null) return "";
            switch(v.Action) {
                case "sell": return "Would SELL (Sell, then Cancel): "+v.Why;
                case "comment": return "Would add \""+v.Words+"\" to the Comment: "+v.Why;
                case "stock": return "Stock not checked: "+v.Why;
                default: return "Would leave it alone: "+v.Why;
            }
        }
        // The open's words (shared with Repair Orders) for a wholesale Order.
        internal static string Message(string s) {
            if(s==null) return null;
            return s.Replace("COSTAR's Work-in-Progress list","COSTAR's wholesale list").Replace("COSTAR's Work-in-Progress","COSTAR's wholesale list")
                .Replace("Work-in-Progress","the wholesale list").Replace("Repair Orders","Orders").Replace("Repair Order","Order");
        }
    }

    // "Orders yet to be filled" read through accessibility (an Infragistics list, as Work-in-Progress: rows and cells,
    // each cell named by its column, its value the data).
    internal static class WholesaleList {
        static readonly string[] Required={"Document #","Order Date","ShipDate","Comment","Ship Via"};
        // A column by its exact name; of two cells with that name, the one that shows (COSTAR's rows hold 30 cells,
        // 11 of them shown: the 29 Oct map).
        internal static List<WholesaleRow> Read(Func<Accessibility.IAccessible> root) {
            var rows=new List<WholesaleRow>();var owned=new List<object>();
            Accessibility.IAccessible client=null,table=null;
            try {
                client=root();
                table=Msaa.Role(client)==Msaa.RoleTable?client:Msaa.FindTable(client,3);
                Order.Require(table!=null,"COSTAR's wholesale list isn't showing a table. Press Search in COSTAR, then try again.");
                Dictionary<string,int> columns=null;var seen=new HashSet<string>(StringComparer.Ordinal);
                foreach(object o in Msaa.Children(table,5000)) {
                    owned.Add(o);
                    var row=o as Accessibility.IAccessible;
                    if(row==null||Msaa.RoleOf(table,o)!=Msaa.RoleRow) continue;
                    var cells=Msaa.Children(row,80);
                    try {
                        if(cells.Count==0||Msaa.RoleOf(row,cells[0])==25) continue;   // the column headings
                        if(columns==null) {
                            columns=new Dictionary<string,int>(StringComparer.Ordinal);var shown=new Dictionary<string,bool>(StringComparer.Ordinal);
                            for(int i=0;i<cells.Count;i++) {
                                string k=Msaa.NameOf(row,cells[i]).Trim();if(k.Length==0) continue;
                                int st=Msaa.StateOf(row,cells[i]);bool visible=st<0||(st&0x8000)==0;
                                if(!columns.ContainsKey(k)||(!shown[k]&&visible)) { columns[k]=i;shown[k]=visible; }
                            }
                            foreach(var need in Required) Order.Require(columns.ContainsKey(need),"COSTAR's wholesale list has no \""+need+"\" column: put its usual columns back, then try again.");
                        }
                        var map=columns;var line=row;var all=cells;
                        Func<string,string> cell=delegate(string name) { int i;return map.TryGetValue(name,out i)&&i<all.Count?Order.Clean(Msaa.ValueOf(line,all[i])):""; };
                        var r=new WholesaleRow {Doc=Order.Norm(cell("Document #")),OrderDate=cell("Order Date"),ShipDate=cell("ShipDate"),Name=cell("Name"),Comment=cell("Comment"),By=cell("Written By"),Po=cell("PO"),PoTotal=cell("PO Total"),ShipVia=cell("Ship Via"),Source=cell("Source")};
                        if(r.Doc.Length>0&&RoEdit.IsDoc(r.Doc)&&seen.Add(r.Doc)) rows.Add(r);
                    } finally { foreach(var c in cells) Msaa.Release(c); }
                }
            } finally {
                foreach(var o in owned) Msaa.Release(o);
                if(table!=null&&!Object.ReferenceEquals(table,client)) Msaa.Release(table);
                Msaa.Release(client);
            }
            return rows;
        }
    }

    // The wholesale Order window read from its controls (the 29 and 30 Oct maps, claude/13-Wholesale-Order-Notes.md):
    // its number beside the "Order" label, Terms under its label, the Comment box right of its label, the "Notes" marker
    // (the order has notes), and the lines: each line's panel holds its number label and its boxes, matched to the
    // headings by place (Item, Description, Size, Order Qty, Back order, Ship Qty/Hrs). Pure: the self-tests give a
    // made-up window. text: a box's words (read on demand; null when it can't be read).
    internal static class WholesaleOrderReader {
        internal const int ReadOnly=0x800;   // ES_READONLY: a box nothing can be typed into
        internal static WholesaleOrderView Parse(List<ControlInfo> s,Func<ControlInfo,string> text) {
            var v=new WholesaleOrderView();
            v.Number=Number(s,text);
            var terms=EbaySelectors.UnderLabel(s,"TERMS");
            if(terms!=null) { string t=text(terms);if(t!=null) v.Terms=Order.Clean(t); }
            var comment=Selectors.FieldRightOf(s,"COMMENT");
            if(comment!=null) { string t=text(comment);if(t!=null) v.Comment=Order.Clean(t); }
            v.NotesMarker=s.Any(c=>c.Static&&Order.Norm(c.Peek)=="NOTES");
            var row=HeadingRow(s);
            Func<string,ControlInfo> heading=delegate(string words) { ControlInfo c;return row!=null&&row.TryGetValue(words,out c)?c:null; };
            ControlInfo item=heading("ITEM"),description=heading("DESCRIPTION"),size=heading("SIZE"),orderQty=heading("ORDER QTY"),backOrder=heading("BACK ORDER"),shipQty=heading("SHIP QTY/HRS");
            if(item==null||description==null||size==null||orderQty==null) { v.Problem="the order's line headings weren't found (not a wholesale Order?)";return v; }
            // More lines than show: the lines' scroll bar is on.
            v.MoreLines=s.Any(c=>c.Visible&&c.Enabled&&c.Class.IndexOf("SCROLLBAR",StringComparison.OrdinalIgnoreCase)>=0&&c.H>200&&c.X>orderQty.X);
            var numbers=s.Where(c=>c.Static&&c.TextState=="read"&&Regex.IsMatch((c.Text??"").Trim(),@"^\d{1,2}$")&&c.X<item.X&&c.X>item.X-60&&c.Y>item.Y).ToList();
            foreach(var label in numbers.OrderBy(c=>Int32.Parse(c.Text.Trim(),CultureInfo.InvariantCulture))) {
                var boxes=s.Where(c=>c.Edit&&c.Parent==label.Parent).ToList();
                Func<ControlInfo,ControlInfo> under=delegate(ControlInfo h) {
                    if(h==null) return null;var l=boxes.Where(b=>Math.Abs(b.X-(h.X+2))<=4).ToList();
                    return l.Count==1?l[0]:null;
                };
                var itemBox=under(item);if(itemBox==null) continue;
                string code=text(itemBox);
                if(code==null) { v.Problem="line "+label.Text.Trim()+"'s item couldn't be read";return v; }
                if(Order.Clean(code).Length==0) continue;
                var line=new WholesaleLine {Number=Int32.Parse(label.Text.Trim(),CultureInfo.InvariantCulture),Item=Order.Norm(code),Panel=label.Parent};
                var panel=s.FirstOrDefault(c=>c.Handle==label.Parent);line.Open=panel!=null&&itemBox.H>0&&panel.H>=2*itemBox.H;
                var desc=under(description);line.Opens=desc!=null&&(desc.Style&ReadOnly)!=0?desc.Handle:0;
                // A note line (its box spans the line): its words aren't read (they could hold anything).
                if(desc!=null&&desc.W>=600) { line.Note=true;v.Lines.Add(line);continue; }
                Func<ControlInfo,string> words=delegate(ControlInfo b) { if(b==null) return "";string t=text(b);return t==null?null:Order.Clean(t); };
                line.Description=words(desc);line.Size=words(under(size));line.OrderQty=words(under(orderQty));line.BackOrder=words(under(backOrder));line.ShipQty=words(under(shipQty));
                if(line.Description==null||line.Size==null||line.OrderQty==null||line.BackOrder==null||line.ShipQty==null) { v.Problem="line "+line.Number+" couldn't be read";return v; }
                line.Tyre=WholesaleRules.Tyre(line.Size,line.Description);
                v.Lines.Add(line);
            }
            if(numbers.Count==0) v.Problem="the order's line numbers weren't found";
            return v;
        }
        // Sydney's stock on a line (the 3 Nov maps): once the line has been the open one, its panel holds a panel
        // ("Frame1") with a stock panel: labels On hand, - Commit, = Avail, On Order down its left, a heading "ThisBr
        // OtherBrs", and a read-only box for each row in each column (ThisBr under the heading's left edge, OtherBrs
        // beside it). On a Sydney order ThisBr is Sydney. 2.9.1: a "NON-STOCKING!" label is in every opened line's panel,
        // under the stock panel, which covers it (Tommy's 17:09 map: Sydney's numbers showing over it; 2.9.0 took every
        // tyre for non-stocking): COSTAR doesn't stock the item only when the label shows (nothing over it). Found: the
        // stock panel is there, or NON-STOCKING! shows; then Available, or NonStocking, or a Problem.
        internal sealed class StockRead { internal bool Found,NonStocking;internal int? Available;internal string Problem; }
        internal static StockRead Stock(List<ControlInfo> s,long linePanel,Func<ControlInfo,string> text) {
            var r=Read(s,linePanel,text);
            if(r.Problem!=null) r.NonStocking=false;   // a problem is never taken for NON-STOCKING
            return r;
        }
        static StockRead Read(List<ControlInfo> s,long linePanel,Func<ControlInfo,string> text) {
            var r=new StockRead();
            var byHandle=new Dictionary<long,ControlInfo>();foreach(var c in s) byHandle[c.Handle]=c;
            Func<ControlInfo,bool> inLine=delegate(ControlInfo c) {
                long p=c.Parent;
                for(int i=0;i<8&&p!=0;i++) { if(p==linePanel) return true;ControlInfo up;if(!byHandle.TryGetValue(p,out up)) return false;p=up.Parent; }
                return false;
            };
            var mine=s.Where(c=>c.Handle!=linePanel&&inLine(c)).ToList();
            r.NonStocking=mine.Any(c=>c.Static&&Order.Norm(c.Peek)=="NON-STOCKING!"&&!Covered(s,c,linePanel));
            var avail=mine.Where(c=>c.Static&&Order.Norm(c.Peek)=="= AVAIL").ToList();
            if(avail.Count==0) { r.Found=r.NonStocking;return r; }   // the line hasn't been the open one (or shows NON-STOCKING! alone)
            r.Found=true;
            if(avail.Count!=1) { r.Problem="its stock panel shows \"= Avail\" "+avail.Count+" times";return r; }
            var label=avail[0];
            var heading=mine.Where(c=>c.Static&&c.Parent==label.Parent&&Regex.Replace(Order.Norm(c.Peek),@"\s+","")=="THISBROTHERBRS").ToList();
            if(heading.Count!=1) { r.Problem="its stock panel's ThisBr heading wasn't found";return r; }
            var thisBr=mine.Where(c=>c.Parent==label.Parent&&c.Class.IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)>=0&&Math.Abs(c.Y-label.Y)<=4&&Math.Abs(c.X-heading[0].X)<=4).ToList();
            if(thisBr.Count!=1) { r.Problem="its ThisBr \"= Avail\" box wasn't found";return r; }
            string t=text(thisBr[0]);
            if(t==null) { r.Problem="its ThisBr \"= Avail\" couldn't be read";return r; }
            t=t.Trim();
            if(t.Length==0) { if(!r.NonStocking) r.Problem="its ThisBr \"= Avail\" is empty";return r; }
            decimal d;
            if(!Decimal.TryParse(t.Replace(",",""),NumberStyles.AllowLeadingSign|NumberStyles.AllowDecimalPoint,CultureInfo.InvariantCulture,out d)) { r.Problem="its ThisBr \"= Avail\" reads \""+WholesaleRules.Shown(t)+"\"";return r; }
            if(d>=1000000m||d<=-1000000m) { r.Problem="its ThisBr \"= Avail\" reads a number too big to be stock";return r; }
            if(r.NonStocking) { r.NonStocking=false;r.Problem="its stock panel shows a number and NON-STOCKING! both";return r; }
            r.Available=(int)Math.Floor(d);
            return r;
        }
        // Whether something showing above c covers its middle: at c's level, or at any of its panels' up to (not past)
        // top, a sibling that comes before it in Windows' order (the snapshot's: higher up). Not in the snapshot: covered.
        internal static bool Covered(List<ControlInfo> s,ControlInfo c,long top) {
            int mx=c.X+c.W/2,my=c.Y+c.H/2;var n=c;
            for(int depth=0;depth<8&&n!=null;depth++) {
                int at=s.IndexOf(n);if(at<0) return true;
                for(int i=0;i<at;i++) { var o=s[i];if(o.Parent==n.Parent&&o.Visible&&mx>=o.X&&mx<o.X+o.W&&my>=o.Y&&my<o.Y+o.H) return true; }
                if(n.Parent==top) break;
                long up=n.Parent;n=s.FirstOrDefault(x=>x.Handle==up);
            }
            return false;
        }
        // The lines' headings: the labels of one panel holding exactly one Item and an Order Qty (the 3 Nov map: all in the
        // lines' panel); a word twice in it: not taken. null: no such panel.
        internal static Dictionary<string,ControlInfo> HeadingRow(List<ControlInfo> s) {
            var rows=s.Where(c=>c.Static&&Array.IndexOf(Columns,Order.Norm(c.Peek))>=0).GroupBy(c=>c.Parent)
                .Where(g=>g.Count(c=>Order.Norm(c.Peek)=="ITEM")==1&&g.Any(c=>Order.Norm(c.Peek)=="ORDER QTY")).ToList();
            if(rows.Count!=1) return null;
            var d=new Dictionary<string,ControlInfo>(StringComparer.Ordinal);
            foreach(var c in rows[0]) { string k=Order.Norm(c.Peek);d[k]=d.ContainsKey(k)?null:c; }
            return d;
        }
        // The order's number: the box beside its one "Order" label (null: not there, or not read).
        internal static string Number(List<ControlInfo> s,Func<ControlInfo,string> text) {
            var box=NumberBox(s);string t=box==null?null:text(box);
            return t==null?null:Order.Norm(t);
        }
        internal static ControlInfo NumberBox(List<ControlInfo> s) {
            var labels=s.Where(c=>c.Static&&Order.Norm(c.Peek)=="ORDER").ToList();
            return labels.Count==1?Beside(s.Where(IsBox).ToList(),labels[0]):null;
        }
        static bool IsBox(ControlInfo c) { return !c.Password&&c.Class.IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)>=0; }
        // What reading the stock mustn't change (the 3 Nov review): every line's own boxes, by line number and column
        // heading (a note line's words box left out: its words aren't read), the order's number, Comment and Terms, and
        // the totals (the labels beside Tax In). Not the stock panels inside the lines: they come and go as lines open.
        // A box that can't be read counts as null.
        static readonly string[] Columns={"ITEM","DESCRIPTION","SIZE","ORDER QTY","BACK ORDER","SHIP QTY/HRS","LIST","DISC","NET","TAX"};
        internal static Dictionary<string,string> Fingerprint(List<ControlInfo> s,Func<ControlInfo,string> text) {
            var f=new Dictionary<string,string>(StringComparer.Ordinal);
            var number=NumberBox(s);f["the order's number"]=number==null?null:text(number);
            var terms=EbaySelectors.UnderLabel(s,"TERMS");f["Terms"]=terms==null?null:text(terms);
            var comment=Selectors.FieldRightOf(s,"COMMENT");f["Comment"]=comment==null?null:text(comment);
            var row=HeadingRow(s);ControlInfo itemHead;
            if(row==null||!row.TryGetValue("ITEM",out itemHead)||itemHead==null) { f["the lines"]=null;return f; }
            var heads=row.Values.Where(h=>h!=null).ToList();var item=new List<ControlInfo> {itemHead};
            var numbers=s.Where(c=>c.Static&&c.TextState=="read"&&Regex.IsMatch((c.Text??"").Trim(),@"^\d{1,2}$")&&c.X<item[0].X&&c.X>item[0].X-60&&c.Y>item[0].Y).ToList();
            foreach(var label in numbers) {
                string line="line "+label.Text.Trim();
                foreach(var box in s.Where(c=>c.Parent==label.Parent&&!c.Password&&c.Class.IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)>=0&&c.W>20&&c.H>10&&c.W<600).OrderBy(c=>c.X)) {
                    var head=heads.Where(h=>Math.Abs(box.X-(h.X+2))<=4).ToList();
                    string key=line+" "+(head.Count==1?Order.Norm(head[0].Peek):"box at "+box.X.ToString(CultureInfo.InvariantCulture));
                    while(f.ContainsKey(key)) key+="+";
                    f[key]=text(box);
                }
            }
            var taxIn=s.Where(c=>c.Static&&Order.Norm(c.Peek)=="TAX IN").ToList();
            if(taxIn.Count==1) foreach(var c in s.Where(x=>x.Static&&x.Parent==taxIn[0].Parent)) f["the totals at "+c.X.ToString(CultureInfo.InvariantCulture)+","+c.Y.ToString(CultureInfo.InvariantCulture)]=c.Peek;
            else f["the totals"]=null;
            return f;
        }
        // What's different after (null: nothing): a box changed or gone, or a line that wasn't there before.
        internal static string Changed(Dictionary<string,string> before,Dictionary<string,string> after) {
            foreach(var kv in before) {
                string now;
                if(!after.TryGetValue(kv.Key,out now)) return kv.Key+" (gone)";
                if(!String.Equals(kv.Value,now,StringComparison.Ordinal)) return kv.Key;
            }
            var lines=new HashSet<string>(before.Keys.Where(k=>k.StartsWith("line ",StringComparison.Ordinal)).Select(k=>k.Split(' ')[1]));
            foreach(var kv in after) if(kv.Key.StartsWith("line ",StringComparison.Ordinal)&&!lines.Contains(kv.Key.Split(' ')[1])&&!String.IsNullOrEmpty(kv.Value)) return kv.Key+" (new)";
            return null;
        }
        // The nearest control on the label's line, to its right (400 px at most).
        static ControlInfo Beside(List<ControlInfo> s,ControlInfo label) {
            int ly=label.Y+label.H/2,lr=label.X+label.W;ControlInfo best=null;
            foreach(var c in s) {
                if(Object.ReferenceEquals(c,label)||!c.Visible||c.RelativeBounds==null) continue;
                if(Math.Abs(c.Y+c.H/2-ly)>8||c.X<lr-4||c.X>lr+400) continue;
                if(best==null||c.X<best.X) best=c;
            }
            return best;
        }
        // The window's controls (labels read at once, boxes on demand), as the phone's Repair Orders read one.
        internal static List<ControlInfo> Snapshot(IntPtr window) {
            var s=new List<ControlInfo>();
            Native.Rect rb;Order.Require(Native.GetWindowRect(window,out rb),"The order's window closed.");
            UIntPtr answer;Order.Require(Native.SendNull(window,0,UIntPtr.Zero,IntPtr.Zero,0x0002,3000,out answer)!=IntPtr.Zero,"COSTAR isn't answering (the order may still be loading).");
            uint owner=Native.Pid(window);var handles=new List<IntPtr>();
            Native.EnumChildWindows(window,delegate(IntPtr h,IntPtr unused) { if(Native.Pid(h)==owner&&Native.IsWindowVisible(h)) handles.Add(h);return handles.Count<4000; },IntPtr.Zero);
            foreach(var h in handles) {
                Native.Rect box;if(!Native.GetWindowRect(h,out box)) continue;
                var c=new ControlInfo {Handle=h.ToInt64(),Root=window.ToInt64(),Parent=Native.GetParent(h).ToInt64(),Class=Native.Class(h),Style=Native.GetWindowLong(h,-16),Visible=true,Enabled=Native.IsWindowEnabled(h),
                    Bounds=new[]{box.Left,box.Top,box.Right-box.Left,box.Bottom-box.Top},RelativeBounds=new[]{box.Left-rb.Left,box.Top-rb.Top,box.Right-box.Left,box.Bottom-box.Top},TextState="not-read"};
                c.Password=c.Class.IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)>=0&&(c.Style&0x20)!=0;
                string t;if(c.Static&&Native.TryText(h,out t)) { c.Text=t;c.TextState="read"; }
                s.Add(c);
            }
            return s;
        }
        internal static string Text(ControlInfo c) { string t;return c!=null&&!c.Password&&Native.TryText(new IntPtr(c.Handle),out t)?t:null; }
        // The tab showing over the order's header: its page tab marked selected (the 29 Oct map: "Ship to" selected).
        // null when it can't be told.
        internal static string Tab(List<ControlInfo> s) {
            var strips=s.Where(c=>c.Visible&&c.Class.IndexOf("SysTabControl32",StringComparison.OrdinalIgnoreCase)>=0).ToList();
            if(strips.Count!=1) return null;
            return SelectedTab(delegate { return Msaa.FromWindow(new IntPtr(strips[0].Handle)); });
        }
        internal static string SelectedTab(Func<Accessibility.IAccessible> root) {
            Accessibility.IAccessible top=null;var owned=new List<object>();
            try {
                top=root();var level=new List<Accessibility.IAccessible>{top};string found=null;int selected=0,seen=0;
                for(int depth=0;depth<4&&level.Count>0&&seen<200;depth++) {
                    var next=new List<Accessibility.IAccessible>();
                    foreach(var parent in level) foreach(object o in Msaa.Children(parent,40)) {
                        seen++;owned.Add(o);
                        if(Msaa.RoleOf(parent,o)==Msaa.RolePageTab) { int st=Msaa.StateOf(parent,o);if(st>=0&&(st&0x2)!=0) { selected++;found=Msaa.NameOf(parent,o).Trim(); } }
                        else { var a=o as Accessibility.IAccessible;if(a!=null) next.Add(a); }
                    }
                    level=next;
                }
                return selected==1&&found.Length>0?found:null;
            } catch(Exception) { return null; }
            finally { foreach(var o in owned) Msaa.Release(o);Msaa.Release(top); }
        }
    }

    // The customer's Notes (the window COSTAR shows over an order): whether they hold card details. Its list (the 30 Oct
    // map): a grid whose rows hold cells named "<column> Row<n>"; the Note cells' values are the notes. true / false;
    // null when its notes couldn't be read. The words never leave this function.
    // 2.9.2 (the review): read whole or not at all. A call COSTAR doesn't answer (a name, a note's words, how many
    // objects there are), more objects than are read (Budget in all, Under under one, Levels deep: the 4 Nov map's
    // Notes have 86 with one note, 8 more a note) or no rows: can't tell, never "no". COSTAR's lists give their rows
    // out of view too (the Work-in-Progress list), so a long list is read whole. Windows' own frame parts (title bars,
    // scroll bars, the system menu: CostarMap.Frame) hold no notes and aren't opened, as the map does; a name is read
    // only where it tells (a column heading, a cell, a menu bar).
    internal static class WholesaleNotes {
        internal const int Budget=600,Under=100,Levels=16,AgainMs=500;
        internal static bool? Card(Func<Accessibility.IAccessible> root) { int rows;return Card(root,out rows); }
        // rows: how many notes were read (0 unless the answer is yes or no).
        internal static bool? Card(Func<Accessibility.IAccessible> root,out int rows) {
            var notes=new List<string>();bool column=false;int found=0;rows=0;
            Accessibility.IAccessible top=null;var owned=new List<object>();
            try {
                top=root();
                var level=new List<Accessibility.IAccessible>{top};int seen=0;
                for(int depth=0;level.Count>0;depth++) {
                    if(depth>=Levels) return null;
                    var next=new List<Accessibility.IAccessible>();
                    foreach(var parent in level) {
                        foreach(object o in Kids(parent)) {
                            owned.Add(o);
                            if(++seen>Budget) return null;
                            int role=Role(parent,o);string name=role==25||role==29||role==2?Name(parent,o).Trim():"";
                            if(CostarMap.Frame(role,name)) continue;
                            bool note=name.StartsWith("Note",StringComparison.OrdinalIgnoreCase)&&!name.StartsWith("Notes",StringComparison.OrdinalIgnoreCase);
                            if(role==25&&note) column=true;
                            else if(role==29&&note) { found++;notes.Add(Value(parent,o)); }
                            else { var a=o as Accessibility.IAccessible;if(a!=null) next.Add(a); }
                        }
                    }
                    level=next;
                }
                // No rows: the list not filled yet (COSTAR shows the Notes because there are some): can't tell (2.9.2).
                if(!column||found==0) return null;
                rows=found;
                return WholesaleRules.CardDetails(notes);
            } catch(Exception) { rows=0;return null; }
            finally { notes.Clear();foreach(var o in owned) Msaa.Release(o);Msaa.Release(top); }
        }
        // "No" only when a second read AgainMs later agrees, with as many notes (COSTAR may still be adding them: a note
        // added since with card details is yes; more notes without, or a read that fails, can't tell). Yes or can't tell
        // at the first read stand. again: waits, then whether COSTAR answers (not answering: can't tell, no second read,
        // so nothing waits on a COSTAR gone busy).
        internal static bool? Settled(Func<Accessibility.IAccessible> root,Func<bool> again) {
            int first,second;
            bool? a=Card(root,out first);
            if(a!=false) return a;
            if(!again()) return null;
            bool? b=Card(root,out second);
            return Agree(a,first,b,second);
        }
        internal static bool? Agree(bool? a,int first,bool? b,int second) {
            if(a!=false) return a;
            if(b==true) return true;
            return b==false&&first==second?(bool?)false:null;
        }
        // A parent's children, every one of them, or an exception (more than Under, fewer got than it has, an empty one, or
        // COSTAR not answering). Strict, unlike Msaa's, which give nothing or "" for a call that fails and put a child's
        // number in for one that can't be got (WinForms then answers for the parent: the second review). All at once
        // (AccessibleChildren), else one by one (the self-tests' made-up objects), each one there.
        static List<object> Kids(Accessibility.IAccessible parent) {
            int n=parent.accChildCount;
            if(n<0||n>Under) throw new InvalidOperationException("Too many objects to read.");
            var list=Msaa.All(parent,n);
            try {
                if(list.Count==0) for(int i=1;i<=n;i++) list.Add(parent.get_accChild(i));
                if(list.Count!=n||list.Contains(null)) throw new InvalidOperationException("Not every object read.");
                return list;
            } catch(Exception) { foreach(var o in list) Msaa.Release(o);throw; }
        }
        static int Role(Accessibility.IAccessible parent,object child) { var a=child as Accessibility.IAccessible;object r=a!=null?a.get_accRole(0):parent.get_accRole(child);return r is int?(int)r:-1; }
        static string Name(Accessibility.IAccessible parent,object child) { var a=child as Accessibility.IAccessible;object n=a!=null?a.get_accName(0):parent.get_accName(child);return n as string??""; }
        static string Value(Accessibility.IAccessible parent,object child) { var a=child as Accessibility.IAccessible;object v=a!=null?a.get_accValue(0):parent.get_accValue(child);return v as string??""; }
    }

    // COSTAR's left-hand menu (an outline: Wholesale Order, Quotation, Repair Order, Invoice, Branch Transfer, Payment,
    // Stock Check; the 29 Oct maps, Tommy's 30 Oct screenshots): an item found by its name and pressed through
    // accessibility (its action is Press), as COSTAR's toolbar buttons are.
    internal static class CostarMenu {
        // The item named `name` (any case) in the outline, for Direct.Act: the item's own object (child null), or the
        // outline with the item's number (child); null with why not.
        internal static Accessibility.IAccessible Find(Accessibility.IAccessible root,string name,out object child,out string why) {
            child=null;why=null;string want=WholesaleRules.Words(name);
            var level=new List<Accessibility.IAccessible>{root};var owned=new List<object>();int seen=0;Accessibility.IAccessible outline=null;
            try {
                for(int depth=0;depth<5&&level.Count>0&&outline==null&&seen<400;depth++) {
                    var next=new List<Accessibility.IAccessible>();
                    foreach(var parent in level) {
                        foreach(object o in Msaa.Children(parent,60)) {
                            seen++;var a=o as Accessibility.IAccessible;
                            if(a!=null&&outline==null&&Msaa.RoleOf(parent,o)==35) { outline=a;continue; }
                            owned.Add(o);if(a!=null) next.Add(a);
                        }
                        if(outline!=null||seen>=400) break;
                    }
                    level=next;
                }
                if(outline==null) { why="COSTAR's left-hand menu wasn't found";return null; }
                object found=null;int count=0;
                foreach(object o in Msaa.Children(outline,60)) {
                    if(Msaa.RoleOf(outline,o)==43&&WholesaleRules.Words(Msaa.NameOf(outline,o))==want) { count++;if(found==null) { found=o;continue; } }
                    Msaa.Release(o);
                }
                if(count!=1) { Msaa.Release(found);why=count==0?"\""+name+"\" isn't in COSTAR's left-hand menu (is its group closed?)":"\""+name+"\" is in COSTAR's left-hand menu "+count+" times";return null; }
                var item=found as Accessibility.IAccessible;
                if(item!=null) return item;   // the outline is released below
                child=found;var keep=outline;outline=null;return keep;
            } finally { foreach(var o in owned) Msaa.Release(o);Msaa.Release(outline); }
        }
    }


    // The dry run itself (on a thread of its own; Cancel stops it).
    internal sealed class WholesaleRun {
        readonly EntryCoordinator coordinator;readonly Action<string> say;
        internal volatile bool Cancel;
        readonly object gate=new object();readonly List<WholesaleLook> looks=new List<WholesaleLook>();
        internal volatile string Summary="",Stopped="";internal volatile bool Done;
        // Until Run has ended (from before its thread starts, so it can't be started twice).
        internal volatile bool Running=true;
        internal volatile int Listed,Buf;
        // An order the run left open in COSTAR Sydney (it is then not closed, and the list isn't put back, by the run).
        volatile string leftOpen;
        // COSTAR Sydney's Order and Repair Order windows (shown or hidden) when the run began: any other one later is
        // an order shown or being made.
        HashSet<long> windowsAtStart=new HashSet<long>();
        HashSet<long> NewWindows(CostarInstance t) {
            var now=RoWip.AllOrders(t,RoListKind.Wholesale);now.UnionWith(RoWip.AllOrders(t,RoListKind.Wip));
            now.ExceptWith(windowsAtStart);return now;
        }
        internal WholesaleRun(EntryCoordinator entries,Action<string> progress) { coordinator=entries;say=progress; }
        internal List<WholesaleLook> Looks { get { lock(gate) return looks.ToList(); } }
        void Say(string words) { try { say(words); } catch(Exception) { } }
        // The words of the open (shared with Repair Orders), for a wholesale Order.
        void SayOpen(string words) { Say(WholesaleRules.Message(words)); }
        bool Cancelled() { return Cancel; }
        // COSTAR Sydney: exactly one COSTAR on Branch 1 in this session (never Order Check's window).
        internal static CostarInstance Sydney() {
            var mine=CostarWindows.Choices().Where(c=>c.Branch==WholesaleRules.Branch&&!OrderCheckLink.IsWipWindow(c)).ToList();
            Order.Require(mine.Count==1,mine.Count==0?"No COSTAR on Branch 1 (Sydney) is open in this Remote Desktop session (or it's on another branch). Put COSTAR Sydney on Branch 1, then try again."
                :mine.Count+" COSTARs on Branch 1 are open: leave one, then try again.");
            return mine[0];
        }
        // Nobody may use the PC while the dry run works in COSTAR (from the quiet moment it began with).
        static bool Used(RoOpenWatch watch) { return watch.UserActive||Native.UserActiveWithin((int)Math.Min(600000,watch.Clock.ElapsedMilliseconds+1000)); }
        static void Quiet(RoOpenWatch watch,string what) {
            if(!Used(watch)) return;
            watch.UserActive=true;
            AppLog.Note("wholesale_user_active",what+": "+Native.LastInputSeen());
            throw new InvalidOperationException("Someone used the COSTAR PC while the dry run was "+what+", so it stopped there (nothing more pressed). Try again and leave the PC alone until it's done.");
        }
        internal void Run() {
            var clock=Stopwatch.StartNew();EntryLease lease=null;CostarInputLock input=null;CostarInstance t=null;IntPtr main=IntPtr.Zero;RoOpenWatch watch=null;
            try {
                try {
                    t=Sydney();
                    Say("Wholesale dry run in COSTAR "+t.Label+": nothing is typed, sold or changed. Leave the PC alone until it's done.");
                    // A quiet moment first (the button was just clicked): 3 s with nobody at the PC, within 30 s.
                    var waiting=Stopwatch.StartNew();
                    while(Native.UserActiveWithin(3000)) {
                        Order.Require(!Cancel,"Stopped.");
                        Order.Require(waiting.ElapsedMilliseconds<30000,"Someone kept using the PC, so the dry run didn't start. Try again and leave the PC alone.");
                        Thread.Sleep(200);
                    }
                    lease=coordinator.TryBegin("The wholesale dry run",t);
                    Order.Require(lease!=null,(coordinator.Owner.Length>0?coordinator.Owner:"Something")+" is using COSTAR: try again when it's done.");
                    coordinator.Progress.Begin("The wholesale dry run","COSTAR Sydney",0);
                    input=new CostarInputLock();
                    watch=new RoOpenWatch();
                    main=CostarWindows.Main(t);
                    Order.Require(RoWip.Shown(t,RoListKind.Wip).Count==0&&RoWip.Shown(t,RoListKind.Wholesale).Count==0,"A Repair Order or an Order is open in COSTAR Sydney. Close it, then try again (the dry run opens orders one at a time).");
                    windowsAtStart=RoWip.AllOrders(t,RoListKind.Wholesale);windowsAtStart.UnionWith(RoWip.AllOrders(t,RoListKind.Wip));
                    Quiet(watch,"starting");RoWip.Front(main,Cancelled);
                    // The list: Wholesale Order in the left-hand menu, unless it shows already.
                    var h=TempeOrderCheck.WipScreen.Locate(main,WholesaleRules.ListTitle);
                    if(h==null) { Menu(main,"Wholesale Order",watch);h=AwaitList(main,WholesaleRules.ListTitle); }
                    Order.Require(h!=null,"COSTAR Sydney didn't show \""+WholesaleRules.ListTitle+"\" after Wholesale Order was pressed.");
                    Order.Require(h.Search!=IntPtr.Zero,"COSTAR's wholesale list has no Search button that can be pressed.");
                    bool? filled=FilledTicked(h);
                    Order.Require(filled!=null,"Whether \"Include Filled Orders\" is ticked on COSTAR's wholesale list couldn't be read: try again.");
                    Order.Require(filled==false,"\"Include Filled Orders\" is ticked on COSTAR's wholesale list. Untick it, then try again.");
                    // A search left at the PC (for example "buf" in Comment / Ship Via) is emptied, then Search.
                    string boxes;string filter=RoWip.KnownFilter(h,Cancelled,out boxes);
                    Order.Require(filter!=null,"COSTAR didn't answer when its search boxes were looked at: try again.");
                    if(filter.Length>0) {
                        Quiet(watch,"clearing the list's search");
                        string why=RoWip.ClearFilter(h,Cancelled,delegate{Quiet(watch,"clearing the list's search");});
                        Order.Require(why==null,"COSTAR's wholesale list is filtered at the PC ("+boxes+") and it couldn't be cleared ("+why+"). Clear it at the PC (Clear), then try again.");
                        Say("COSTAR's wholesale list was filtered ("+boxes+"): cleared.");
                    }
                    Quiet(watch,"searching the list");
                    Say("Searching COSTAR's wholesale list.");
                    RoWip.PressSearch(h,Cancelled);
                    var rows=WholesaleList.Read(delegate { return Msaa.FromWindow(h.Grid); });
                    string today=DateTime.Now.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture);
                    var buf=WholesaleRules.Oldest(rows.Where(r=>WholesaleRules.ShipViaBuf(r.ShipVia)));
                    Listed=rows.Count;Buf=buf.Count;
                    var todo=new List<WholesaleLook>();
                    foreach(var r in buf) {
                        var l=new WholesaleLook {Row=r,Skip=WholesaleRules.Screen(r,today)};
                        if(l.Skip==null&&todo.Count>=WholesaleRules.MostPerRun) l.Skip="more than "+WholesaleRules.MostPerRun+" to open: the next press";
                        if(l.Skip==null) todo.Add(l);
                        lock(gate) looks.Add(l);
                    }
                    Say(rows.Count+" orders listed, "+buf.Count+" BUF, "+todo.Count+" to open.");
                    AppLog.Note("wholesale_list",rows.Count+" listed, "+buf.Count+" BUF, "+todo.Count+" to open");
                    int at=0;
                    foreach(var l in todo) {
                        Order.Require(!Cancel,"Stopped.");
                        at++;coordinator.Progress.Stage("Order "+l.Row.Doc,at,todo.Count);
                        LookAt(t,l,watch);
                    }
                    // Back to Repair Order (Work-in-Progress), so eBay orders keep going (Tommy, 2 Nov: "yes for now if you can").
                    BackToRepairOrder(main,watch);
                    Done=true;
                    Summary=Count()+" ("+(clock.ElapsedMilliseconds/1000)+" s). Nothing was typed, sold or changed.";
                    AppLog.Note("wholesale_dry_run",Count());
                    coordinator.Progress.End(true,"Wholesale dry run done");
                } catch(Exception e) {
                    string why=e is OperationCanceledException?"Stopped.":e.Message;
                    AppLog.Note("wholesale_dry_run_stopped",e.GetType().Name+": "+RoText.ForLog(why));
                    string after=Restore(t,main,watch);
                    Stopped=why+after;Summary="Stopped: "+why+after;
                    if(lease!=null) coordinator.Progress.End(false,"Wholesale dry run stopped");
                }
            } finally {
                try { if(input!=null) input.Dispose(); }
                finally { if(lease!=null) lease.Dispose();Running=false; }
            }
        }
        // After a stop: COSTAR Sydney put back on Work-in-Progress (Repair Order), unless a person stopped it, someone
        // used the PC, or an order is open there: then the person is told to. Words added to the stop ("" when there's
        // nothing to say).
        string Restore(CostarInstance t,IntPtr main,RoOpenWatch watch) {
            const string Back=" COSTAR Sydney may still show its wholesale list: press Repair Order in its left-hand menu (eBay orders wait until it shows Work-in-Progress).";
            if(t==null||main==IntPtr.Zero||watch==null) return "";
            try {
                if(TempeOrderCheck.WipScreen.Locate(main)!=null) return "";
                // Not with any Order or Repair Order window there, shown or still being made.
                if(Cancel||leftOpen!=null||Used(watch)||NewWindows(t).Count>0) return Back;
                BackToRepairOrder(main,watch);
                return TempeOrderCheck.WipScreen.Locate(main)!=null?" COSTAR Sydney is back on Work-in-Progress.":Back;
            } catch(Exception) { return Back; }
        }
        internal string Count() {
            var all=Looks;int opened=all.Count(x=>x.Opened);
            Func<string,int> n=a=>all.Count(x=>x.Verdict!=null&&x.Verdict.Action==a);
            return Listed+" listed, "+Buf+" BUF, "+opened+" opened: would sell "+n("sell")+", would add a comment to "+n("comment")+", stock not checked "+n("stock")+", would leave "+n("leave");
        }
        // Wholesale Order / Repair Order pressed in the left-hand menu, with the last look just before (COSTAR's main
        // window in front and free, nobody at the PC).
        void Menu(IntPtr main,string name,RoOpenWatch watch) {
            Order.Require(!Cancel,"Stopped.");
            Quiet(watch,"pressing "+name);RoWip.Front(main,Cancelled);
            Say("Pressing "+name+" in COSTAR's left-hand menu.");
            var act=Direct.Act(delegate(out object child,out string why) {
                var root=Msaa.FromWindow(main);
                try { return CostarMenu.Find(root,name,out child,out why); } finally { Msaa.Release(root); }
            },delegate {
                if(Native.GetForegroundWindow()!=main||!Native.IsWindowEnabled(main)) return RoWip.MainNotFree;
                if(Used(watch)) return Direct.PcInUse;
                return null;
            });
            string went=Direct.Went(act,8000,600);
            if(act.Refused==Direct.PcInUse) Quiet(watch,"pressing "+name);
            Order.Require(went=="pressed",name+" couldn't be pressed in COSTAR's left-hand menu ("+(act.Refused??act.FindError??act.PressError??went)+"). Check COSTAR Sydney.");
            AppLog.Note("wholesale_menu",name);
        }
        // The list with that title, once it shows (15 s at most).
        TempeOrderCheck.WipHandles AwaitList(IntPtr main,string title) {
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<15000) {
                Order.Require(!Cancel,"Stopped.");
                var h=TempeOrderCheck.WipScreen.Locate(main,title);
                if(h!=null) return h;
                Thread.Sleep(250);
            }
            return null;
        }
        void BackToRepairOrder(IntPtr main,RoOpenWatch watch) {
            if(TempeOrderCheck.WipScreen.Locate(main)!=null) return;
            Menu(main,"Repair Order",watch);
            if(AwaitList(main,"Work-in-Progress")==null) Say("COSTAR Sydney didn't show Work-in-Progress after Repair Order was pressed: put it back by hand (eBay orders wait until it is).");
        }
        // "Include Filled Orders" (a tick box on the list's search panel): accessibility's word on it (null: can't tell).
        static bool? FilledTicked(TempeOrderCheck.WipHandles h) {
            IntPtr box=IntPtr.Zero;int found=0;
            foreach(IntPtr c in TempeOrderCheck.Win.Children(h.Pane)) {
                if(!Native.IsWindowVisible(c)||Native.Class(c).IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)<0) continue;
                string words;if(Native.TryText(c,out words)&&Order.Norm(words).Replace("&","")=="INCLUDE FILLED ORDERS") { box=c;found++; }
            }
            if(found!=1) return null;
            Accessibility.IAccessible a=null;
            try { a=Msaa.FromWindow(box);if(Msaa.Role(a)!=44) return null;object st=a.get_accState(0);return st is int?(((int)st)&0x10)!=0:(bool?)null; }
            catch(Exception) { return null; }
            finally { Msaa.Release(a); }
        }
        // One order: opened from the list; its number checked as soon as it can be read; COSTAR's notices over it
        // answered; read; and closed again as it was, only when it was read through, nobody has used the PC and Stop
        // wasn't pressed (closing an Order saves it). Anything else leaves it open, unchanged, for a person.
        void LookAt(CostarInstance t,WholesaleLook l,RoOpenWatch watch) {
            string doc=l.Row.Doc,want=Order.Norm(doc);var times=new RoOpenTimes();RoListRow listed;bool selected;IntPtr window;
            try { window=RoWip.Open(t,doc,Cancelled,SayOpen,watch,times,out listed,out selected,RoListKind.Wholesale); }
            catch(Exception e) {
                // It may have opened all the same, or be opening (a window COSTAR is still making counts): left as it is.
                bool open=false;
                try { open=NewWindows(t).Count>0; } catch(Exception) { open=true; }
                if(open) { leftOpen=doc;l.LeftOpen="unchanged (it opened as the dry run stopped)"; }
                string why=e is OperationCanceledException?"Stopped.":WholesaleRules.Message(e.Message);
                throw new InvalidOperationException(why+(open?" An Order is open in COSTAR Sydney (unchanged): close it there.":""));
            }
            l.Opened=true;bool done=false;
            try {
                // Its number, as soon as it shows (the customer's Notes may be over it, the order still blank behind them):
                // another order's is never answered, read or closed.
                string early=null;var looking=Stopwatch.StartNew();
                while(looking.ElapsedMilliseconds<3000) {
                    Order.Require(!Cancel,"Stopped.");
                    try { early=WholesaleOrderReader.Number(WholesaleOrderReader.Snapshot(window),WholesaleOrderReader.Text); }
                    catch(InvalidOperationException) { early=null; }   // COSTAR busy (still loading it): not read yet
                    if(!String.IsNullOrEmpty(early)) break;
                    Thread.Sleep(250);
                }
                Order.Require(String.IsNullOrEmpty(early)||early==want,"The order that opened shows number "+early+", not "+doc+". The dry run stopped: check COSTAR Sydney.");
                // Still a BUF order with a Comment to do, as listed when it was opened (it may have changed meanwhile).
                string problem=null;
                if(listed!=null&&(!WholesaleRules.ShipViaBuf(listed.shipVia)||!WholesaleRules.CommentToDo(listed.comment))) problem="it changed in the list meanwhile (Comment \""+WholesaleRules.Shown(listed.comment)+"\", Ship Via "+WholesaleRules.Shown(listed.shipVia)+")";
                Notices(window,l,watch);
                var s=WholesaleOrderReader.Snapshot(window);
                var view=WholesaleOrderReader.Parse(s,WholesaleOrderReader.Text);
                Order.Require(view.Number!=null&&view.Number==want,"The order that opened shows "+(view.Number==null?"no number that could be read":"number "+view.Number)+", not "+doc+". The dry run stopped: check COSTAR Sydney.");
                string tab=WholesaleOrderReader.Tab(s);
                // A notice that came late (after the order showed) is answered too, before the order is closed.
                Notices(window,l,watch);
                l.Number=view.Number;l.Terms=view.Terms;l.OrderComment=view.Comment;l.NotesMarker=view.NotesMarker;l.MoreLines=view.MoreLines;l.Tab=tab;
                l.Lines.AddRange(view.Lines);
                l.Problem=problem??view.Problem;
                l.Card=WholesaleRules.CardFrom(l.NotesRead,WholesaleRules.MayHaveNotes(view.NotesMarker,tab));
                // The stock last, and only when everything else is fine (Tommy, 3 Nov: "check terms, check notes, check stock").
                if(WholesaleRules.Decide(l).Action=="stock") ReadStock(window,l,watch);
                l.Verdict=WholesaleRules.Decide(l);
                Say("Order "+doc+": "+WholesaleRules.Plain(l.Verdict));
                AppLog.Note("wholesale_order",doc+": "+l.Verdict.Action+(l.Verdict.Words.Length>0?" ("+l.Verdict.Words+")":""));
                done=true;
            } catch(Exception e) {
                // A stop after a line was clicked, before the order was read again, says so (closing would save what the
                // click did); a change found says what changed already.
                string words=e is OperationCanceledException?"Stopped.":e.Message;
                if(l.LinesOpened&&!l.Checked&&l.Changed==null&&words.IndexOf(Clicked(doc),StringComparison.Ordinal)<0) throw new InvalidOperationException(words+" "+Clicked(doc),e);
                throw;
            } finally {
                bool person=Cancel||Used(watch);
                string blocker=Runner.CloseBlocker(window);
                // Lines clicked: the keyboard still out of them right before the close (WinForms checks the box that has
                // it while the window closes: a line's would be checked inside the close, after the order was read again).
                string keyboard=done&&l.LinesOpened?KeyboardNow(window):"out";
                if(keyboard!="out") { l.Checked=false;AppLog.Note("wholesale_lines_left","Order "+doc+": the keyboard was back in "+keyboard+" before the close"); }
                bool shut=done&&!person&&blocker==null&&keyboard=="out"&&RoEngine.CloseWindow(window);
                if(!shut) {
                    leftOpen=doc;
                    // Unchanged, unless its tyre lines were clicked open and it wasn't read again since (or was found changed).
                    string state=l.Changed!=null?"opening its tyre lines changed "+l.Changed+": check it before closing it (closing saves)"
                        :l.LinesOpened&&!l.Checked?"its tyre lines were clicked open to read the stock: check them before closing it (closing saves)":null;
                    l.LeftOpen=state??"unchanged";
                    string note=state==null?", unchanged":" ("+state+")";
                    string why=person?(Cancel?"Stopped":"Someone used the COSTAR PC")+": Order "+doc+" is open in COSTAR Sydney"+note+": close it there."
                        :blocker!=null?"Order "+doc+" couldn't be closed ("+blocker+")"+(state==null?"":" ("+state+")")+": answer it and close the order at the PC."
                        :done&&keyboard!="out"?"COSTAR put the keyboard back into Order "+doc+"'s lines ("+keyboard+") before it could be closed, so it was left open ("+state+").":done?"COSTAR didn't close Order "+doc+" (it may be asking something): answer it at the PC.":"Order "+doc+" was left open in COSTAR Sydney"+note+": close it there.";
                    if(done) throw new InvalidOperationException(why);
                    Say(why);
                }
            }
        }
        static string Clicked(string doc) { return "Order "+doc+"'s tyre lines were clicked open to read the stock: check them before closing it (closing saves)."; }
        // Sydney's stock of each tyre line (Tommy, 2 Nov: "by expanding the tyre line"): the line clicked once, as a person
        // opens it (COSTAR's lines follow the mouse, not a box given the keyboard: the Repair Order notes of 28 Oct), into
        // its words (a read-only box: nothing can be typed there), then the stock panel COSTAR shows for it read
        // (WholesaleOrderReader.Stock). A line that can't be clicked or read says why (the order is then left alone).
        // At the end the order's number box (read-only) is clicked so COSTAR leaves the last line as it leaves the others,
        // and the order is read again: anything different from before (a line's box, Comment, Terms, the totals) or a new
        // COSTAR window, and the order is left open for a person (closing it saves).
        void ReadStock(IntPtr window,WholesaleLook l,RoOpenWatch watch) {
            uint pid=Native.Pid(window);
            var before=WholesaleOrderReader.Fingerprint(WholesaleOrderReader.Snapshot(window),WholesaleOrderReader.Text);
            var shown=TopWindows(pid);
            long clicked=0;int clickedLine=0;
            foreach(var want in l.Lines.Where(x=>x.Tyre&&!x.Note&&x.Available==null&&!x.NonStocking).ToList()) {
                Order.Require(!Cancel,"Stopped.");
                long panel=ReadLine(window,want,l,watch,shown);
                if(panel!=0) { clicked=panel;clickedLine=want.Number; }
                AppLog.Note("wholesale_stock",l.Row.Doc+" line "+want.Number+": "+(want.NonStocking?"non-stocking":want.Available!=null?want.Available.Value.ToString(CultureInfo.InvariantCulture)+" available":"not read"));
            }
            if(!l.LinesOpened) return;
            string left=LeaveLines(window,l,watch,shown);
            if(left!=null) {
                AppLog.Note("wholesale_lines_left","Order "+l.Row.Doc+": not left ("+left+")");
                throw new InvalidOperationException("COSTAR didn't leave Order "+l.Row.Doc+"'s last tyre line ("+left+"), so the order wasn't read again or closed. "+Clicked(l.Row.Doc));
            }
            // For the day log: whether COSTAR closed the last line clicked (its panel back to one row) once it was left.
            Native.Rect last;
            if(clicked!=0&&Native.GetWindowRect(new IntPtr(clicked),out last)) AppLog.Note("wholesale_lines_left","Order "+l.Row.Doc+": line "+clickedLine+(last.Bottom-last.Top<=25?" closed":" still open ("+(last.Bottom-last.Top).ToString(CultureInfo.InvariantCulture)+" px high)")+" once the keyboard left the lines");
            string changed=null;bool busy=false;Dictionary<string,string> after=null;
            for(int i=0;i<3;i++) {
                if(i>0) Thread.Sleep(500);
                try { busy=false;after=WholesaleOrderReader.Fingerprint(WholesaleOrderReader.Snapshot(window),WholesaleOrderReader.Text);changed=WholesaleOrderReader.Changed(before,after); }
                catch(InvalidOperationException) { busy=true;changed="the order"; }
                if(changed==null) break;
            }
            Order.Require(!busy,"Order "+l.Row.Doc+" couldn't be read again after its tyre lines were opened (COSTAR busy). The dry run stopped and left it open: check its lines before closing it (closing saves).");
            var opened=TopWindows(pid);opened.ExceptWith(shown);
            if(changed==null&&opened.Count>0) changed="the screen (COSTAR opened another window)";
            if(changed!=null) {
                l.Changed=changed;
                string was,now;
                if(after!=null&&before.TryGetValue(changed,out was)&&after.TryGetValue(changed,out now)) l.ChangedValues=changed+" showed \""+WholesaleRules.Shown(was??"(unreadable)")+"\", then \""+WholesaleRules.Shown(now??"(unreadable)")+"\"";
                AppLog.Note("wholesale_order_changed","Order "+l.Row.Doc+": "+changed);
                throw new InvalidOperationException("Opening Order "+l.Row.Doc+"'s tyre lines to read the stock changed "+changed+" in COSTAR. The dry run stopped and left the order open: check it before closing it (closing saves).");
            }
            l.Checked=true;
        }
        // The keyboard taken out of the lines (as the Repair Order code leaves them: LeaveGrid): the order's number box (a
        // read-only box showing the order's number) clicked, until the keyboard has stayed out of the lines (on that box, or
        // wherever COSTAR passes it in the order outside them) 300 ms; 3 clicks at most. null: left; else why not.
        string LeaveLines(IntPtr window,WholesaleLook l,RoOpenWatch watch,HashSet<long> shown) {
            string why="the order's number box wasn't found";
            for(int attempt=1;attempt<=3;attempt++) {
                Order.Require(!Cancel,"Stopped.");
                var s=WholesaleOrderReader.Snapshot(window);var number=WholesaleOrderReader.NumberBox(s);var row=WholesaleOrderReader.HeadingRow(s);
                var head=row==null?null:row.Values.FirstOrDefault(x=>x!=null);
                if(head==null) return "the lines' panel wasn't found";
                if(number==null) return why;
                string shows=WholesaleOrderReader.Text(number);
                if(shows==null||Order.Norm(shows)!=l.Number) return "the order's number box doesn't show its number";
                var box=new IntPtr(number.Handle);
                if(KeyboardAt(window,head.Parent)!="out") {
                    bool click;why=ClickInto(window,box,"the order's number",l,watch,null,shown,out click);
                    if(why!=null) { Notices(window,l,watch);Thread.Sleep(500);continue; }   // busy, moving, covered: again
                }
                Notices(window,l,watch);
                var held=Stopwatch.StartNew();string at="out";
                while(held.ElapsedMilliseconds<300&&at=="out") { at=KeyboardAt(window,head.Parent);if(at=="out") Thread.Sleep(30); }
                if(at=="out") return null;
                why="the keyboard went back to "+at;
            }
            return why;
        }
        // Where COSTAR's keyboard is for the order: "out" (in the order, outside its lines' panel), "the lines", "another
        // window" or "nowhere" (by the windows' parents, never their words).
        static string KeyboardAt(IntPtr window,long lines) {
            var f=Native.Focus(window);
            if(f==IntPtr.Zero) return "nowhere";
            var p=f;
            for(int i=0;i<40&&p!=IntPtr.Zero;i++) {
                if(p.ToInt64()==lines) return "the lines";
                if(p==window) return "out";
                p=Native.GetAncestor(p,1);   // GA_PARENT: the parent, never an owner
            }
            return "another window";
        }
        // The same right before the order is closed (a fresh read of where the lines are). Anything that can't be told: not out.
        static string KeyboardNow(IntPtr window) {
            try {
                var row=WholesaleOrderReader.HeadingRow(WholesaleOrderReader.Snapshot(window));var head=row==null?null:row.Values.FirstOrDefault(x=>x!=null);
                return head==null?"a place that couldn't be told (the lines' panel wasn't found)":KeyboardAt(window,head.Parent);
            } catch(Exception) { return "a place that couldn't be told (COSTAR busy)"; }
        }
        // One tyre line: found again (opening another line moves the lines under it), its stock panel read as COSTAR shows
        // it, else the line clicked once and its panel waited for. Returns the line's panel when it was clicked (else 0).
        long ReadLine(IntPtr window,WholesaleLine want,WholesaleLook l,RoOpenWatch watch,HashSet<long> shown) {
            var now=Again(window,want);
            if(now==null) { want.StockWhy="the line wasn't found again";return 0; }
            WholesaleOrderReader.StockRead r;long clicked=0;
            if(!now.Open) {
                if(now.Opens==0) { want.StockWhy="its words box isn't read-only, so it wasn't clicked";return 0; }
                bool click;
                string why=ClickInto(window,new IntPtr(now.Opens),"line "+want.Number,l,watch,delegate { var a=Again(window,want);return a!=null&&a.Open; },shown,out click);
                if(click) clicked=now.Panel;
                if(why!=null) { want.StockWhy=why;Notices(window,l,watch);return clicked; }
                r=Settled(window,want,2500);
                // Anything COSTAR showed as the line opened (the Notes, a memo: answered; anything else stops), then once more;
                // NON-STOCKING too, after that wait (a stock panel that came late would cover it): only a lasting one counts.
                Notices(window,l,watch);
                if(!Good(r)||r.NonStocking) r=Settled(window,want,1500);
                want.StockWhy=r.Found?r.Problem:"the line didn't open";
            } else {
                r=Settled(window,want,2500);   // open already: read twice alike (its number may still be coming; not clicked)
                want.StockWhy=r.Found?r.Problem:"its stock panel didn't show";
            }
            want.Available=r.Available;want.NonStocking=r.NonStocking;
            return clicked;
        }
        static bool Good(WholesaleOrderReader.StockRead r) { return r.Found&&r.Problem==null&&(r.Available!=null||r.NonStocking); }
        // The line as the order shows it now (by its number and item), or null.
        static WholesaleLine Again(IntPtr window,WholesaleLine want) {
            try { return WholesaleOrderReader.Parse(WholesaleOrderReader.Snapshot(window),WholesaleOrderReader.Text).Lines.FirstOrDefault(x=>x.Number==want.Number&&x.Item==want.Item&&!x.Note); }
            catch(InvalidOperationException) { return null; }   // COSTAR busy
        }
        // The line's stock panel as it shows now, while the line is open (COSTAR busy, the line not found or closed: not there).
        static WholesaleOrderReader.StockRead ReadNow(IntPtr window,WholesaleLine want) {
            try {
                var s=WholesaleOrderReader.Snapshot(window);
                var now=WholesaleOrderReader.Parse(s,WholesaleOrderReader.Text).Lines.FirstOrDefault(x=>x.Number==want.Number&&x.Item==want.Item&&!x.Note);
                return now==null||!now.Open?new WholesaleOrderReader.StockRead():WholesaleOrderReader.Stock(s,now.Panel,WholesaleOrderReader.Text);
            } catch(InvalidOperationException) { return new WholesaleOrderReader.StockRead(); }
        }
        // The stock as two reads 200 ms apart agree (a number shown while the panel fills isn't taken): looked for until
        // it shows (ms at most; a second second to agree).
        WholesaleOrderReader.StockRead Settled(IntPtr window,WholesaleLine want,int ms) {
            var timer=Stopwatch.StartNew();WholesaleOrderReader.StockRead last=null;
            while(true) {
                Order.Require(!Cancel,"Stopped.");
                var r=ReadNow(window,want);
                if(Good(r)) {
                    if(last!=null&&last.NonStocking==r.NonStocking&&last.Available==r.Available) return r;
                    last=r;
                    if(timer.ElapsedMilliseconds>=ms+1000) return new WholesaleOrderReader.StockRead {Found=true,Problem="its ThisBr \"= Avail\" kept changing"};
                } else {
                    last=null;
                    if(timer.ElapsedMilliseconds>=ms) return r;
                }
                Thread.Sleep(200);
            }
        }
        // One click into a read-only box of the order (a line's words; its number), as a person would: with the order in
        // front and enabled, COSTAR answering, nothing over the order, the box read-only, showing, still where it was
        // 150 ms before and under the point, no click just before (so it can't make a double click), no key held, nobody
        // at the PC, Stop not pressed, and (open: the line opened meanwhile) not needed after all. null: clicked (clicked
        // true) or not needed; else why not.
        Stopwatch sinceClick;
        string ClickInto(IntPtr window,IntPtr box,string what,WholesaleLook l,RoOpenWatch watch,Func<bool> open,HashSet<long> shown,out bool clicked) {
            clicked=false;uint pid=Native.Pid(window);
            NoNewWindow(window,pid,shown,l);
            Native.BringToFront(window);
            var waited=Stopwatch.StartNew();
            while(Native.GetForegroundWindow()!=window&&waited.ElapsedMilliseconds<2000) Thread.Sleep(25);
            if(Native.GetForegroundWindow()!=window||!Native.IsWindowEnabled(window)) return "the order didn't come in front (a window over it?), so "+what+" wasn't clicked";
            UIntPtr answer;
            if(Native.SendNull(window,0,UIntPtr.Zero,IntPtr.Zero,0x0002,250,out answer)==IntPtr.Zero) return "COSTAR was busy, so "+what+" wasn't clicked";
            if(Over(window,pid).Count>0) return "a window was over the order, so "+what+" wasn't clicked";
            if(!ReadOnlyBox(box)) return what+"'s box changed, so it wasn't clicked";
            Native.Rect r,again;
            if(!Native.GetWindowRect(box,out r)||r.Right-r.Left<=20||r.Bottom-r.Top<=10) return what+" isn't showing, so it wasn't clicked";
            Thread.Sleep(150);
            if(!Native.GetWindowRect(box,out again)||again.Left!=r.Left||again.Top!=r.Top||again.Right!=r.Right||again.Bottom!=r.Bottom) return what+" was still moving, so it wasn't clicked";
            if(open!=null&&open()) return null;   // it opened meanwhile: no click needed
            var p=new Native.Point {X=(r.Left+r.Right)/2,Y=r.Top+Math.Min(10,(r.Bottom-r.Top)/2)};
            if(sinceClick!=null) { int wait=Native.DoubleClickMs()+60-(int)sinceClick.ElapsedMilliseconds;if(wait>0) Thread.Sleep(Math.Min(wait,2000)); }
            Native.NoModifiers();Quiet(watch,"clicking "+what+" in Order "+l.Row.Doc);
            Order.Require(!Cancel,"Stopped.");
            NoNewWindow(window,pid,shown,l);
            if(Native.GetForegroundWindow()!=window||!Native.IsWindowEnabled(window)||Over(window,pid).Count>0||Native.WindowFromPoint(p)!=box||!ReadOnlyBox(box)) return what+" was covered, so it wasn't clicked";
            l.LinesOpened=true;   // before the click: one that went only part way may still have landed
            Native.ClickNow(p);sinceClick=Stopwatch.StartNew();clicked=true;
            AppLog.Note("wholesale_line_click",l.Row.Doc+" "+what);
            return null;
        }
        // A box of COSTAR's that shows and can't be typed into (an EDIT with ES_READONLY).
        static bool ReadOnlyBox(IntPtr box) {
            return Native.IsWindow(box)&&Native.IsWindowVisible(box)&&Native.Class(box).IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)>=0&&(Native.GetWindowLong(box,-16)&WholesaleOrderReader.ReadOnly)!=0;
        }
        // Since the stock read began, COSTAR showed no window of its own that isn't over the order (those go through
        // Notices); one did: the run stops, the order left open.
        static void NoNewWindow(IntPtr window,uint pid,HashSet<long> shown,WholesaleLook l) {
            if(shown==null) return;
            var now=TopWindows(pid);now.ExceptWith(shown);now.ExceptWith(Over(window,pid).Select(w=>w.ToInt64()));
            if(now.Count==0) return;
            if(!l.LinesOpened) throw new InvalidOperationException("COSTAR opened another window while Order "+l.Row.Doc+"'s stock was being read (nothing had been clicked in it yet). The dry run stopped: look at COSTAR Sydney.");
            l.Changed="the screen (COSTAR opened another window)";
            throw new InvalidOperationException("COSTAR opened another window while Order "+l.Row.Doc+"'s tyre lines were being read. The dry run stopped and left the order open: check it before closing it (closing saves).");
        }
        // COSTAR's windows showing (its notices over the order, and anything else it opens).
        static HashSet<long> TopWindows(uint pid) {
            var found=new HashSet<long>();
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) { if(Native.Pid(w)==pid&&Native.IsWindowVisible(w)&&!Runner.Decoration(w)) found.Add(w.ToInt64());return true; },IntPtr.Zero);
            return found;
        }
        // COSTAR's notices over the order answered with their OK, one after the other (Tommy, 2 Nov: "cant be ignored, we
        // have to press OK"; "Some customer have more than 1 pop up, so make sure both are cleared"): only the customer's
        // Notes (looked at for card details just before) and a Point-of-sale Memo. Anything else stops the run with
        // nothing pressed in it. Done once the order has been free (nothing over it, enabled, COSTAR answering) for 1.5 s.
        // 2.9.2: one not read in full yet (no button, one greyed or unread, a message's words unread: COSTAR still making
        // it, as the customer's Notes right after a memo in the 4 Nov 02:09 run) is looked at again until 5 s after it was
        // first seen (UnknownNotice; day log wholesale_notice_wait, counts only); one read in full that isn't the Notes or
        // a memo stops the run at once, as before.
        void Notices(IntPtr window,WholesaleLook l,RoOpenWatch watch) {
            uint pid=Native.Pid(window);var clock=Stopwatch.StartNew();var free=Stopwatch.StartNew();var pressed=new PressedNotices();
            var unknown=new UnknownNotice();
            Func<long,bool> showing=delegate(long w) { var x=new IntPtr(w);return Native.IsWindow(x)&&Native.IsWindowVisible(x); };
            while(true) {
                Order.Require(!Cancel,"Stopped.");
                Order.Require(Native.IsWindow(window),"Order "+l.Row.Doc+" closed by itself.");
                var over=Over(window,pid);string waiting=null;
                pressed.Sweep(showing);unknown.Sweep(showing);
                if(over.Count==0) {
                    UIntPtr answer;
                    bool idle=Native.SendNull(window,0,UIntPtr.Zero,IntPtr.Zero,0x0002,250,out answer)!=IntPtr.Zero;
                    if(!idle||!Native.IsWindowEnabled(window)) free.Restart();
                    else if(free.ElapsedMilliseconds>=1500) return;
                } else {
                    free.Restart();
                    // The one in front, if it's one of them; a window under another (greyed while the other shows) waits.
                    var fg=Native.GetForegroundWindow();
                    var front=over.Contains(fg)&&Native.IsWindowEnabled(fg)?fg:over.FirstOrDefault(Native.IsWindowEnabled);
                    if(front!=IntPtr.Zero) {
                        string kind;string look=pressed.Look(front.ToInt64(),clock.ElapsedMilliseconds,out kind);
                        if(look!=null) Order.Require(look=="wait","COSTAR's "+(kind=="notes"?"Notes":"Point-of-sale Memo")+" over Order "+l.Row.Doc+" stayed open after its OK was pressed. Nothing more was pressed: close it at the PC.");
                        else {
                            bool notYet;string shape;string stop=Answer(front,l,watch,pressed,clock,out notYet,out shape);
                            if(stop!=null) {
                                bool firstLook;bool now=unknown.Stop(front.ToInt64(),clock.ElapsedMilliseconds,notYet,out firstLook);
                                if(firstLook&&notYet) AppLog.Note("wholesale_notice_wait",l.Row.Doc+": "+shape+"; looked at again for up to "+UnknownNotice.UnknownMs/1000+" s");
                                if(now) AppLog.Note("wholesale_notice_stop",l.Row.Doc+": "+shape);
                                Order.Require(!now,stop);
                                waiting=stop;
                            }
                        }
                    }
                }
                Order.Require(clock.ElapsedMilliseconds<20000,waiting??"Order "+l.Row.Doc+" wasn't ready within 20 s of opening (COSTAR busy, or a window over it). Check COSTAR Sydney.");
                Thread.Sleep(100);
            }
        }
        // A window over the order as the dry run reads it: Runner.PopupKind's kind (notes, memo, notice or null), its
        // buttons and a message box's words. notYet (2.9.2): not read in full (WholesaleRules.NotReadYet); shape: what was
        // seen, counts only (for the day log: never a word of the window).
        static string Look(IntPtr front,out List<IntPtr> buttons,out List<string> statics,out bool notYet,out string shape) {
            string title=Native.Caption(front),cls=Native.Class(front);
            var b=new List<IntPtr>();var names=new List<string>();var s=new List<string>();int unread=0;
            Native.EnumChildWindows(front,delegate(IntPtr c,IntPtr unused) {
                if(!Native.IsWindowVisible(c)) return true;
                string k=Native.Class(c),words;
                if(k.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0) { b.Add(c);names.Add(Runner.ButtonName(Native.IsWindowEnabled(c),Native.TryText(c,out words)?words:null)); }
                else if(cls=="#32770"&&k.IndexOf("STATIC",StringComparison.OrdinalIgnoreCase)>=0) { if(!Native.TryText(c,out words)) unread++;else if(Order.Clean(words).Length>0) s.Add(Order.Clean(words)); }
                return b.Count+s.Count<40;
            },IntPtr.Zero);
            buttons=b;statics=s;
            notYet=WholesaleRules.NotReadYet(cls,names,s.Count,unread);
            int grey=names.Count(n=>n=="?");
            shape=(Runner.IsNotesWindow(front)?"the Notes":Runner.IsMemoWindow(front)?"a Point-of-sale Memo":cls=="#32770"?"a message":"a window")+": "+names.Count+" button"+(names.Count==1?"":"s")+", "+grey+" greyed or unread"+(cls=="#32770"?", "+s.Count+" words read, "+unread+" unread":"");
            return Runner.PopupKind(title,cls,names,String.Join(" ",s.ToArray()));
        }
        // Answered with its OK: null. Otherwise why, nothing pressed in it; notYet: not read in full yet (looked at again
        // for a moment before the run stops); shape: what was seen, counts only.
        string Answer(IntPtr front,WholesaleLook l,RoOpenWatch watch,PressedNotices pressed,Stopwatch clock,out bool notYet,out string shape) {
            List<IntPtr> buttons;List<string> statics;
            string what=Look(front,out buttons,out statics,out notYet,out shape),title=Native.Caption(front);
            // Only the two Tommy named (2 Nov): another message, even with one OK, is a person's to answer.
            // COSTAR's words are quoted with any quote in them made a ' (the day log leaves out what's quoted).
            if(what==null&&Runner.IsNotesWindow(front)) return "COSTAR's Notes over Order "+l.Row.Doc+" couldn't be answered (no single OK to press, or COSTAR too busy to read it). Nothing was pressed in them: answer them at the PC.";
            if(what==null&&Runner.IsMemoWindow(front)) return "COSTAR's Point-of-sale Memo over Order "+l.Row.Doc+" couldn't be answered (no single OK to press, or its words couldn't be read). Nothing was pressed in it: answer it at the PC.";
            if(what!="notes"&&what!="memo") return "COSTAR showed "+(what=="notice"?"a message":"a window")+" over Order "+l.Row.Doc+" (\""+Sanitize.Text(title,40).Replace("\"","'")+"\""+(what=="notice"?": \""+Runner.MemoWords(String.Join(" ",statics.ToArray())).Replace("\"","'")+"\"":"")+") that the dry run doesn't answer. Nothing was pressed in it: answer it at the PC.";
            // A memo with some of its words unread (the second review): looked at again, never answered half read.
            if(notYet) return "COSTAR's "+(what=="notes"?"Notes":"Point-of-sale Memo")+" over Order "+l.Row.Doc+" couldn't be read in full. Nothing was pressed in "+(what=="notes"?"them: answer them":"it: answer it")+" at the PC.";
            Order.Require(l.NotesRead.Count+l.Memos.Count<6,"COSTAR keeps showing notices over Order "+l.Row.Doc+". Look at COSTAR Sydney.");
            bool? card=null;
            if(what=="notes") {
                // Card details looked for (yes/no only), before its OK, once COSTAR answers (it may still be filling the
                // list; not answering in 2 s: looked at again), "no" only from two reads that agree (2.9.2).
                if(!Answering(front,2000)) { notYet=true;shape="the Notes: COSTAR not answering";return "COSTAR's Notes over Order "+l.Row.Doc+" couldn't be answered (COSTAR too busy). Nothing was pressed in them: answer them at the PC."; }
                var notes=front;
                card=WholesaleNotes.Settled(delegate { return Msaa.FromWindow(notes); },delegate { Thread.Sleep(WholesaleNotes.AgainMs);return Answering(notes,2000); });
            }
            // Looked at again just before its OK goes (2.9.2, the review): still enabled (no window of COSTAR's over it),
            // still the same kind with the same one OK, Stop not pressed; else looked at again (nothing pressed).
            bool same=false;
            if(Native.IsWindowEnabled(front)) {
                List<IntPtr> again;List<string> words;bool notYetAgain;string shapeAgain;
                same=Look(front,out again,out words,out notYetAgain,out shapeAgain)==what&&again.Count==1&&again[0]==buttons[0];
            }
            if(!same) { notYet=true;shape=(what=="notes"?"the Notes":"a Point-of-sale Memo")+": changed while looked at";return "COSTAR's "+(what=="notes"?"Notes":"Point-of-sale Memo")+" over Order "+l.Row.Doc+" changed while being looked at. Nothing was pressed: answer "+(what=="notes"?"them":"it")+" at the PC."; }
            Order.Require(!Cancel,"Stopped.");
            if(what=="notes") { l.NotesRead.Add(card);l.NotesShown=true; }
            else l.Memos.Add("Point-of-sale Memo: "+Runner.MemoWords(String.Join(" ",statics.ToArray())));
            Quiet(watch,"answering COSTAR's "+(what=="notes"?"Notes":"Point-of-sale Memo")+" over Order "+l.Row.Doc);
            int sent=Direct.Press(buttons[0],1500);
            Order.Require(sent>=0,"The OK of COSTAR's "+(what=="notes"?"Notes":"Point-of-sale Memo")+" over Order "+l.Row.Doc+" couldn't be pressed. Answer it at the PC.");
            pressed.Pressed(front.ToInt64(),clock.ElapsedMilliseconds,what);
            AppLog.Note("wholesale_notice",l.Row.Doc+": "+what+" (OK pressed)");
            Say("Order "+l.Row.Doc+": COSTAR's "+(what=="notes"?"Notes":"Point-of-sale Memo")+" answered with OK.");
            return null;
        }
        // Whether COSTAR answers a window within ms (WM_NULL, 250 ms at a time).
        static bool Answering(IntPtr w,int ms) {
            var t=Stopwatch.StartNew();UIntPtr r;
            while(true) {
                if(Native.SendNull(w,0,UIntPtr.Zero,IntPtr.Zero,0x0002,250,out r)!=IntPtr.Zero) return true;
                if(t.ElapsedMilliseconds>=ms) return false;
                Thread.Sleep(100);
            }
        }
        // COSTAR's windows over the order: shown, of its process, owned by it (directly or through others).
        static List<IntPtr> Over(IntPtr window,uint pid) {
            var found=new List<IntPtr>();
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) {
                if(w==window||Native.Pid(w)!=pid||!Native.IsWindowVisible(w)||Runner.Decoration(w)) return true;
                var o=Native.GetWindow(w,4);
                for(int i=0;i<16&&o!=IntPtr.Zero;i++,o=Native.GetWindow(o,4)) if(o==window) { found.Add(w);break; }
                return true;
            },IntPtr.Zero);
            return found;
        }
    }

    // 2.9.2: the windows over the order the dry run couldn't answer, each with when it was first seen. One not read in
    // full yet (COSTAR may still be making it: the 4 Nov 02:09 run, the customer's Notes right after a memo, their OK
    // unreadable while COSTAR filled them) is looked at again until UnknownMs after it was first seen; one read in full
    // that the dry run doesn't answer stops the run at once, as before. Each window keeps its own time (two taking turns
    // in front don't start each other again); one gone (closed or hidden) is forgotten. Nothing is ever pressed in any
    // of them. Pure: the time is given.
    internal sealed class UnknownNotice {
        internal const int UnknownMs=5000;
        readonly Dictionary<long,long> first=new Dictionary<long,long>();
        internal int Count { get { return first.Count; } }
        // Whether the run stops now; firstLook: this window looked at for the first time (for the day log).
        internal bool Stop(long window,long nowMs,bool notYet,out bool firstLook) {
            long since;firstLook=!first.TryGetValue(window,out since);
            if(firstLook) { since=nowMs;first[window]=nowMs; }
            return !notYet||nowMs-since>=UnknownMs;
        }
        internal void Sweep(Func<long,bool> showing) { foreach(long w in first.Keys.ToList()) if(!showing(w)) first.Remove(w); }
    }
}
