// 2.9.8 "Wholesale speed test" (Tommy, 15 Nov 2026 02:52: "Build the next version as one combined dry-run update with a
// way to compare the speed improvements ... the comparison should establish the results"). How the wholesale dry run
// works through orders is a preset (WholesaleSpeed): the 2.9.7 approach (the baseline, the default until a test picks
// another), each improvement on its own, all four together, and two ways of using COSTAR's own search (by order
// number; the list filtered to BUF). The speed test (WholesaleSpeedTest) runs the same orders through each preset in
// turn, in the wholesale helper's own session, and times every stage (WholesaleTimes, WholesalePassTimes); its report
// (SpeedReport) says what was measured, what wasn't, and which preset was fastest with the same results. Still a dry
// run throughout: orders are opened, read and closed; nothing is typed into them, sold or changed. Search words go
// only into the list's own search boxes (Tommy: "Entering search criteria is acceptable navigation during the dry run").
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace TempeCostar {
    // A way of working through orders. Public fields: kept in wholesale-settings.json (the key is what's kept).
    //  - directRow: the order's row read at the place the pass's list read found it (its number checked; anywhere
    //    else: the list read whole, as before), not the whole 351-row list twice.
    //  - readyChecks: after a tyre line's stock is read, after the lines are left, and right after the order is read,
    //    a check that nothing is over the order and COSTAR answers, instead of waiting for 1.5 s of quiet (the one
    //    after the order opens stays: Notes come late).
    //  - leanList: the list read for each row's Document # and Ship Via, and its dates and Comment only when BUF.
    //  - shortTimers: the box-still check 80 ms (150), the second stock read 100 ms after the first (200), the keyboard
    //    held out of the lines 150 ms (300).
    //  - byNumber: each order found by its number in the list's Document # search box (Search pressed for each).
    //  - bufFilter: the list searched with BUF in its Comment / Ship Via box (Ship Via is still checked on each order).
    public sealed class WholesaleSpeed {
        public string key="baseline";
        public bool directRow,readyChecks,leanList,shortTimers,byNumber,bufFilter;
        internal const int AfterOpenMs=1500;
        internal int AfterMs { get { return readyChecks?0:1500; } }
        internal int BoxStillMs { get { return shortTimers?80:150; } }
        internal int SettleMs { get { return shortTimers?100:200; } }
        internal int HoldMs { get { return shortTimers?150:300; } }
        internal static readonly string[] Keys={"baseline","direct","ready","lean","timers","all","all-number","all-buf"};
        internal static WholesaleSpeed Preset(string key) {
            var s=new WholesaleSpeed {key=key??"baseline"};
            switch(s.key) {
                case "direct": s.directRow=true;break;
                case "ready": s.readyChecks=true;break;
                case "lean": s.leanList=true;break;
                case "timers": s.shortTimers=true;break;
                case "all": s.directRow=s.readyChecks=s.leanList=s.shortTimers=true;break;
                case "all-number": s.byNumber=s.readyChecks=s.leanList=s.shortTimers=true;break;
                case "all-buf": s.directRow=s.readyChecks=s.leanList=s.shortTimers=s.bufFilter=true;break;
                default: s.key="baseline";break;
            }
            return s;
        }
        internal static WholesaleSpeed Baseline() { return Preset("baseline"); }
        internal string Name { get { return NameOf(key); } }
        internal static string NameOf(string key) {
            switch(key) {
                case "direct": return "Find the row directly";
                case "ready": return "Ready checks, not 1.5 s waits";
                case "lean": return "Read only the list columns needed";
                case "timers": return "Shorter stability timers";
                case "all": return "All four improvements";
                case "all-number": return "All four, search by order number";
                case "all-buf": return "All four, list filtered to BUF";
                default: return "2.9.7 approach (baseline)";
            }
        }
    }

    // One order's stages (ms; -1: not reached). search: its number searched for (byNumber); find: the list read for its
    // row and the row made the active one; open: Enter to the window showing; notes: COSTAR's Notes and memos answered
    // and the quiet waits before reading; read: the order read; stock: its tyre lines clicked and read; verify: the lines
    // left and the order read again; close: closing it; total: the whole look, from finding to closed.
    public sealed class WholesaleTimes {
        public long search,find=-1,open=-1,notes,read,stock,verify,close=-1,total;
        public int scans,rows,fallbacks,selectTries,lines,settleReads,changing,lateNotices,leaveTries,popups,firstPopupMs=-1;
        public bool hinted;
        internal static string S(long ms) { return ms<0?"-":(ms/100/10.0).ToString("0.0",CultureInfo.InvariantCulture); }
        internal long Find { get { return search+Math.Max(0,find); } }
        // For the day log (wholesale_times): numbers only.
        internal string Line(string doc) {
            return doc+": find "+S(Find)+" s ("+(search>0?"searched by number, ":"")+scans+" list read"+(scans==1?"":"s")+" of "+rows+" row"+(rows==1?"":"s")+(hinted?", at its known place":"")+(fallbacks>0?", read whole after all "+fallbacks+"x":"")+")"
                +", open "+S(open)+" s, notes "+S(notes)+" s"+(popups>0?" ("+popups+" answered, the first "+S(firstPopupMs)+" s after it showed)":"")
                +", read "+S(read)+" s, stock "+S(stock)+" s ("+lines+" line"+(lines==1?"":"s")+", "+settleReads+" read"+(settleReads==1?"":"s")+(changing>0?", "+changing+" changing":"")+")"
                +", verify "+S(verify)+" s"+(lateNotices>0?" ("+lateNotices+" notice"+(lateNotices==1?"":"s")+" after a click)":"")+(leaveTries>1?" ("+leaveTries+" tries to leave the lines)":"")+", close "+S(close)+" s, total "+S(total)+" s";
        }
    }
    // A pass's list (ms): quiet (waiting for nobody at the PC), listing (the list showing, its search boxes checked),
    // filter (BUF put in its search box, an order's number taken out), search (Search pressed until the list held still),
    // read (the list read), restore (the run's search words emptied at the end); total: the whole pass.
    public sealed class WholesalePassTimes {
        public long quiet,listing,filter,search,read,restore,total;public int rows,buf;public bool lean,leanFellBack,filtered;
        internal long Refresh { get { return filter+search+read; } }
        internal string Line() {
            Func<long,string> s=WholesaleTimes.S;
            return "quiet "+s(quiet)+", listing "+s(listing)+(filtered?", BUF filter "+s(filter):"")+", search "+s(search)+", read "+s(read)+" s ("+rows+" rows, "+buf+" BUF"+(lean?(leanFellBack?", read whole after all":", needed columns only"):"")+"), total "+s(total)+" s";
        }
    }

    // The list's own search boxes ("Advanced Search": Name/Contact, Document #, Cust PO #, Phone, Order Date, Written
    // By, Comment / Ship Via, Source; the 29 Oct maps, claude/13-Wholesale-Order-Notes.md): a box found by its label,
    // its words set with WM_SETTEXT (no keyboard: nothing reaches anything else) and read back.
    internal static class WholesaleSearchBox {
        internal const string DocumentLabel="DOCUMENT",CommentLabel="COMMENTSHIPVIA";
        internal sealed class Part { internal string Text;internal Native.Rect Rect;internal IntPtr Handle; }
        internal static string Letters(string s) { return new string((s??"").ToUpperInvariant().Where(Char.IsLetter).ToArray()); }
        // Pure: the box whose label (left of it on its row: middles within 10 px, the label ending at most 8 px past
        // the box's left) reads `label` in letters only ("Document #": DOCUMENT); zero unless exactly one.
        internal static IntPtr Pick(List<Part> labels,List<Part> boxes,string label) {
            IntPtr found=IntPtr.Zero;int n=0;
            foreach(var b in boxes) {
                int mid=(b.Rect.Top+b.Rect.Bottom)/2,gap=int.MaxValue;Part best=null;
                foreach(var x in labels) {
                    int g=Math.Abs((x.Rect.Top+x.Rect.Bottom)/2-mid);
                    if(g<=10&&x.Rect.Right<=b.Rect.Left+8&&g<gap&&(x.Text??"").Trim().Length>0) { gap=g;best=x; }
                }
                if(best!=null&&Letters(best.Text)==label) { found=b.Handle;n++; }
            }
            return n==1?found:IntPtr.Zero;
        }
        internal static IntPtr Find(TempeOrderCheck.WipHandles h,string label) {
            var labels=new List<Part>();var boxes=new List<Part>();
            foreach(IntPtr c in TempeOrderCheck.Win.Children(h.Pane)) {
                if(!Native.IsWindowVisible(c)) continue;
                string cls=Native.Class(c);
                bool edit=cls.IndexOf(".EDIT.",StringComparison.OrdinalIgnoreCase)>=0,stat=cls.IndexOf(".STATIC.",StringComparison.OrdinalIgnoreCase)>=0;
                if(!edit&&!stat) continue;
                Native.Rect r;if(!Native.GetWindowRect(c,out r)) continue;
                string t=null;if(stat&&!Native.TryText(c,out t)) continue;
                if(edit) boxes.Add(new Part {Rect=r,Handle=c});else labels.Add(new Part {Text=t,Rect=r,Handle=c});
            }
            return Pick(labels,boxes,label);
        }
        // Null: the box shows `text` now; else why not.
        internal static string Set(IntPtr box,string text) {
            if(box==IntPtr.Zero) return "the search box wasn't found";
            UIntPtr result;
            if(Native.WriteMessage(box,0x000C,UIntPtr.Zero,text??"",2,3000,out result)==IntPtr.Zero) return "COSTAR didn't take the search words";
            for(var t=Stopwatch.StartNew();t.ElapsedMilliseconds<2000;Thread.Sleep(50)) { string now;if(Native.TryText(box,out now)&&(now??"").Trim()==(text??"").Trim()) return null; }
            return "the search box didn't show the words";
        }
        internal static string Text(IntPtr box) { string t;return box!=IntPtr.Zero&&Native.TryText(box,out t)?t:null; }
        // The list's search as COSTAR's boxes show it (RoWip.KnownFilter: "Comment / Ship Via = BUF") is the run's own BUF
        // filter alone. Pure.
        internal static bool OnlyBuf(string filter) {
            if(String.IsNullOrEmpty(filter)||filter.IndexOf(", ",StringComparison.Ordinal)>=0) return false;
            int eq=filter.LastIndexOf(" = ",StringComparison.Ordinal);
            return eq>0&&Letters(filter.Substring(0,eq))==CommentLabel&&filter.Substring(eq+3).Trim().ToUpperInvariant()=="BUF";
        }
    }

    // What the speed test keeps (Diagnostics\speed\speed-*.json, beside the report's words): numbers, order numbers,
    // the helper's tags and each tyre line's Sydney stock; never a customer's words, staff's Comment words or Notes.
    public sealed class SpeedOrderResult {
        // outcome: sell, flag, leave, skip (once opened), locked, not listed, not opened, left open, stopped. extra: a test
        // beyond the sample ("wrong place": its row looked for at another order's place; "not on the list": a made-up
        // number). fp: a fingerprint of the order as read (its Terms, Comment and lines), to tell a real change apart.
        public string doc="",outcome="",tags="",stock="",fp="",extra="";
        public int tyres,wheels,others,unsure,notes,memos,problems;
        public WholesaleTimes times=new WholesaleTimes();
    }
    // durationMs: the pass from start to end; testsMs: the planned tests beside the orders and the run's search words
    // emptied at the end (left out of the "whole" time); missedBuf (the BUF filter): BUF orders listed in the whole list
    // before and after it that the filtered list didn't show (-1: not checked).
    public sealed class SpeedArmResult {
        public string key="",name="",stopped="";public long durationMs,testsMs;public int missedBuf=-1;
        public WholesalePassTimes list=new WholesalePassTimes();
        public List<SpeedOrderResult> orders=new List<SpeedOrderResult>();
    }
    public sealed class SpeedTestFile {
        public int schema=1;public string version="",started="",finished="",best="",stopped="";public int size,listed,buf;
        public List<string> sample=new List<string>();
        public List<SpeedArmResult> arms=new List<SpeedArmResult>();
    }

    internal static class SpeedResults {
        // The orders of a test: the ones asked for first (if they're BUF orders a pass would open now), then the rest
        // spread over the list (every k-th of those, top to bottom), `size` in all, in the list's order. Pure.
        internal static List<string> Choose(IList<WholesaleRow> rows,string today,int size,IEnumerable<string> asked) {
            var open=rows.Where(r=>WholesaleRules.ShipViaBuf(r.ShipVia)&&WholesaleRules.Screen(r,today).Why==null).OrderBy(r=>r.Pos).ToList();
            var picked=new List<WholesaleRow>();
            foreach(var d in asked??new string[0]) { string n=Order.Norm(d);var r=open.FirstOrDefault(x=>x.Doc==n);if(r!=null&&!picked.Contains(r)&&picked.Count<size) picked.Add(r); }
            var rest=open.Where(r=>!picked.Contains(r)).ToList();int need=Math.Min(size-picked.Count,rest.Count);
            for(int i=0;i<need;i++) picked.Add(rest.ElementAt((int)((long)i*rest.Count/need)));
            return picked.OrderBy(r=>r.Pos).Select(r=>r.Doc).ToList();
        }
        // The BUF orders a filtered pass (i) didn't show that the whole list showed in the nearest pass before it and the
        // nearest after it (so an order filled or added between them doesn't count); -1: no such passes either side. Pure.
        internal static int Missed(List<HashSet<string>> whole,List<HashSet<string>> filtered,int i) {
            if(i<0||i>=filtered.Count||filtered[i]==null) return -1;
            HashSet<string> before=null,after=null;
            for(int k=i-1;k>=0&&before==null;k--) if(k<whole.Count) before=whole[k];
            for(int k=i+1;k<whole.Count&&after==null;k++) after=whole[k];
            if(before==null||after==null) return -1;
            return before.Count(d=>after.Contains(d)&&!filtered[i].Contains(d));
        }
        internal static SpeedOrderResult From(WholesaleLook l) {
            var o=new SpeedOrderResult {doc=l.Row.Doc,extra=l.Extra??"",times=l.Times};
            var v=l.Verdict;
            if(l.Locked) o.outcome="locked";
            else if(v!=null) { o.outcome=v.Action;o.tags=WholesaleComment.TagText(v.Tags);o.problems=v.Problems.Count; }
            else if(l.LeftOpen!=null) o.outcome="left open";
            else if(l.Skip!=null) o.outcome=l.Skip.StartsWith("no longer on COSTAR's list",StringComparison.Ordinal)?"not listed":"not opened";
            else o.outcome=l.Opened?"stopped":"not reached";
            var items=l.Lines.Where(x=>!x.Note&&x.Item.Length>0).ToList();
            o.tyres=items.Count(x=>x.Kind=="tyre");o.wheels=items.Count(x=>x.Kind=="wheel");o.unsure=items.Count(x=>x.Kind=="unsure");
            o.others=items.Count-o.tyres-o.wheels-o.unsure;
            o.notes=l.NotesRead.Count;o.memos=l.Memos.Count;
            o.stock=String.Join(",",items.Where(x=>x.Kind=="tyre").Select(x=>x.Number.ToString(CultureInfo.InvariantCulture)+":"+(x.NonStocking?"NS":x.Available.HasValue?x.Available.Value.ToString(CultureInfo.InvariantCulture):"?")).ToArray());
            o.fp=l.Opened?Wire.Hash(Encoding.UTF8.GetBytes((l.Terms??"")+"|"+(l.OrderComment??"")+"|"+WholesaleRules.Print(items)+"|"+(l.Card==true?"card":l.Card==false?"no card":"?"))).Substring(0,12):"";
            return o;
        }
    }

    // The report (pure: the self-tests check it). The baseline runs first and again last: an order whose two baseline
    // reads agree must read the same with every approach (a difference is the approach's: unexplained, not reliable);
    // one whose two baseline reads differ changed in COSTAR during the test (stock sold or received, the order edited),
    // so a difference is explained.
    internal static class SpeedReport {
        internal static long Median(List<long> v) {
            if(v.Count==0) return -1;
            var s=v.OrderBy(x=>x).ToList();
            return s.Count%2==1?s[s.Count/2]:(s[s.Count/2-1]+s[s.Count/2])/2;
        }
        static string S(long ms) { return WholesaleTimes.S(ms); }
        static string Clock(long ms) { if(ms<0) return "-";long s=(ms+500)/1000;return (s/60).ToString(CultureInfo.InvariantCulture)+":"+(s%60).ToString("00",CultureInfo.InvariantCulture); }
        static readonly string[] Read={"sell","flag","leave","skip"};
        static bool WasRead(SpeedOrderResult o) { return o!=null&&Read.Contains(o.outcome); }
        // The orders that count for a preset's speed: from the sample (no extra test), opened and read through.
        internal static List<SpeedOrderResult> Counted(SpeedArmResult a) { return a.orders.Where(o=>o.extra.Length==0&&WasRead(o)).ToList(); }
        internal static long MedianMs(SpeedArmResult a) { return Median(Counted(a).Select(o=>o.times.total).ToList()); }
        internal static long SlowestMs(SpeedArmResult a) { var c=Counted(a);return c.Count==0?-1:c.Max(o=>o.times.total); }
        internal static long StageMs(SpeedArmResult a,Func<WholesaleTimes,long> stage) { return Median(Counted(a).Select(o=>Math.Max(0,stage(o.times))).ToList()); }
        internal static long WholeMs(SpeedArmResult a) { return Math.Max(0,a.durationMs-a.testsMs); }
        // Tries again on the orders of the sample: the row made the active one again, the lines left again, a stock
        // figure read again after it changed.
        internal static int Retries(SpeedArmResult a) { return a.orders.Where(o=>o.extra.Length==0).Sum(o=>Math.Max(0,o.times.selectTries-1)+Math.Max(0,o.times.leaveTries-1)+o.times.changing); }
        // Read the same: the same result (what it would do, its tags), stock, kinds of lines and fingerprint.
        internal static bool Same(SpeedOrderResult o,SpeedOrderResult b) {
            return o.outcome==b.outcome&&o.tags==b.tags&&o.stock==b.stock&&o.fp==b.fp&&o.tyres==b.tyres&&o.wheels==b.wheels&&o.others==b.others&&o.unsure==b.unsure;
        }
        static SpeedOrderResult Of(SpeedArmResult a,string doc) { return a==null?null:a.orders.FirstOrDefault(x=>x.extra.Length==0&&x.doc==doc); }
        // An order (o) against the first baseline's read (b) and the last baseline's (last; null: none, or o is it):
        // "same"; "changed" (COSTAR changed meanwhile: the two baselines differ; open on another PC at the time; gone from
        // the list for the last baseline too; with only the first baseline, a different stock or order); "unexplained"
        // (a different read while the baselines agree: not reliable); "missing" (the baseline read it, this didn't);
        // "" (the baseline didn't read it).
        internal static string Compare(SpeedOrderResult o,SpeedOrderResult b,SpeedOrderResult last) {
            if(!WasRead(b)) return "";
            if(!WasRead(o)) {
                if(o!=null&&o.outcome=="locked") return "changed";
                bool gone=o!=null&&(o.outcome=="not listed"||o.outcome=="not opened");
                return gone&&last!=null&&!WasRead(last)?"changed":"missing";
            }
            if(Same(o,b)||(WasRead(last)&&Same(o,last))) return "same";
            if(WasRead(last)) return Same(b,last)?"unexplained":"changed";
            return o.stock!=b.stock||o.fp!=b.fp?"changed":"unexplained";
        }
        internal static SpeedArmResult First(SpeedTestFile f) { return f.arms.FirstOrDefault(a=>a.key=="baseline"); }
        // The 2.9.7 approach's median an order: the faster of its two passes (first and last), so an approach isn't
        // taken for faster because COSTAR had warmed up by its turn.
        internal static long BaselineMs(SpeedTestFile f) {
            var b0=First(f);var bl=Last(f);long m=b0==null?-1:MedianMs(b0),l=bl==null?-1:MedianMs(bl);
            return m<0?l:l<0?m:Math.Min(m,l);
        }
        internal static SpeedArmResult Last(SpeedTestFile f) { var b0=First(f);return f.arms.LastOrDefault(a=>a.key=="baseline"&&!Object.ReferenceEquals(a,b0)); }
        internal static Dictionary<string,int> Tally(SpeedArmResult a,SpeedArmResult b0,SpeedArmResult bLast) {
            var t=new Dictionary<string,int>(StringComparer.Ordinal) {{"same",0},{"changed",0},{"unexplained",0},{"missing",0}};
            var last=Object.ReferenceEquals(a,bLast)?null:bLast;
            foreach(var b in b0.orders.Where(x=>x.extra.Length==0)) { string c=Compare(Of(a,b.doc),b,Of(last,b.doc));if(c.Length>0) t[c]++; }
            return t;
        }
        // The planned tests beside the orders passed: "wrong place" read the same order as its own look did, after reading
        // the list whole; "not on the list" opened nothing.
        internal static bool ExtrasPassed(SpeedArmResult a) {
            foreach(var o in a.orders.Where(x=>x.extra.Length>0)) {
                if(o.extra=="wrong place") { var own=Of(a,o.doc);if(!(WasRead(o)&&o.times.fallbacks>0&&WasRead(own)&&own.outcome==o.outcome&&own.tags==o.tags&&own.fp==o.fp)) return false; }
                if(o.extra=="not on the list"&&o.outcome!="not listed") return false;
            }
            return true;
        }
        internal static bool Reliable(SpeedArmResult a,SpeedTestFile f) {
            var b0=First(f);if(b0==null) return false;
            if(a.stopped.Length>0||a.orders.Any(o=>o.outcome=="left open"||o.outcome=="stopped")) return false;
            if(a.list.filtered&&a.missedBuf!=0) return false;
            var t=Tally(a,b0,Last(f));
            return t["unexplained"]==0&&t["missing"]==0&&ExtrasPassed(a)&&Counted(a).Count>0;
        }
        // The fastest reliable approach (not the baseline): the lowest median an order, then the shortest pass; "baseline"
        // when none is both reliable and faster than the first baseline.
        internal static string Best(SpeedTestFile f) {
            var b0=First(f);if(b0==null||Counted(b0).Count==0) return "baseline";
            var ok=f.arms.Where(a=>a.key!="baseline"&&Reliable(a,f)).OrderBy(a=>MedianMs(a)).ThenBy(a=>WholeMs(a)).ToList();
            return ok.Count>0&&MedianMs(ok[0])>=0&&MedianMs(ok[0])<BaselineMs(f)?ok[0].key:"baseline";
        }
        static string Pad(string s,int n) { s=s??"";return s.Length>=n?s:s+new string(' ',n-s.Length); }
        internal static string Text(SpeedTestFile f) {
            var b=new StringBuilder();var b0=First(f);var bLast=Last(f);
            b.AppendLine("WHOLESALE SPEED TEST, "+f.started+" to "+f.finished+" (helper "+f.version+"). Dry run: orders opened, read and closed; nothing typed into them, sold or changed.");
            if(f.stopped.Length>0) b.AppendLine("STOPPED: "+f.stopped);
            b.AppendLine("Orders: "+f.sample.Count+" ("+String.Join(", ",f.sample.ToArray())+"), of "+f.buf+" BUF in a list of "+f.listed+".");
            if(b0!=null) {
                var c=Counted(b0);
                b.AppendLine("In them (as the baseline read them): "+c.Count(o=>o.tyres==0)+" with no tyre line, "+c.Count(o=>o.tyres==1)+" with 1, "+c.Count(o=>o.tyres==2)+" with 2, "+c.Count(o=>o.tyres>=3)+" with 3 or more; Notes on "+c.Count(o=>o.notes>0)+", a memo on "+c.Count(o=>o.memos>0)+"; wheels on "+c.Count(o=>o.wheels>0)+"; other items on "+c.Count(o=>o.others>0)+"; can't-tell lines on "+c.Count(o=>o.unsure>0)+".");
            }
            b.AppendLine();
            b.AppendLine("List: the list searched and read. Order: one order from finding it to closing it. Whole: the pass, without the planned tests beside the orders. As 2.9.7: orders read as the baseline read them (or changed in COSTAR meanwhile), ! = read differently with nothing changed. Retries: a row made active again, the lines left again, a stock figure read again after it changed. Read whole: times the list was read in full after all.");
            b.AppendLine(Pad("Approach",36)+Pad("List",8)+Pad("Order: median / slowest",25)+Pad("Whole",8)+Pad("vs 2.9.7",10)+Pad("As 2.9.7",10)+Pad("Stops",7)+Pad("Retries",9)+Pad("Read whole",12)+"Locked");
            long m0=BaselineMs(f);int n=b0==null?0:Counted(b0).Count;
            foreach(var a in f.arms) {
                long m=MedianMs(a);var t=b0==null?null:Tally(a,b0,bLast);
                string vs=m0>0&&m>=0?((m-m0)*100/m0).ToString("+0;-0;0",CultureInfo.InvariantCulture)+"%":"-";
                string same=t==null?"-":(t["same"]+t["changed"])+"/"+n+(t["unexplained"]>0?" !"+t["unexplained"]:"");
                int stops=(a.stopped.Length>0?1:0)+a.orders.Count(o=>o.outcome=="left open"||o.outcome=="stopped");
                int unplanned=a.orders.Where(o=>o.extra.Length==0).Sum(o=>o.times.fallbacks),planned=a.orders.Where(o=>o.extra.Length>0).Sum(o=>o.times.fallbacks);
                b.AppendLine(Pad(a.name,36)+Pad(S(a.list.Refresh)+" s",8)+Pad(S(m)+" / "+S(SlowestMs(a))+" s",25)+Pad(Clock(WholeMs(a)),8)+Pad(vs,10)+Pad(same,10)+Pad(stops.ToString(CultureInfo.InvariantCulture),7)+Pad(Retries(a).ToString(CultureInfo.InvariantCulture),9)+Pad(unplanned+(planned>0?" (+"+planned+" test)":""),12)+a.orders.Count(o=>o.outcome=="locked"));
            }
            b.AppendLine();
            b.AppendLine("Where an order's time goes (median, s):");
            b.AppendLine(Pad("Approach",36)+Pad("find",7)+Pad("open",7)+Pad("notes",7)+Pad("read",7)+Pad("stock",7)+Pad("verify",8)+"close");
            foreach(var a in f.arms) b.AppendLine(Pad(a.name,36)+Pad(S(StageMs(a,x=>x.Find)),7)+Pad(S(StageMs(a,x=>x.open)),7)+Pad(S(StageMs(a,x=>x.notes)),7)+Pad(S(StageMs(a,x=>x.read)),7)+Pad(S(StageMs(a,x=>x.stock)),7)+Pad(S(StageMs(a,x=>x.verify)),8)+S(StageMs(a,x=>x.close)));
            b.AppendLine();
            string best=Best(f);var ba=f.arms.FirstOrDefault(a=>a.key==best);
            if(best=="baseline"||ba==null) b.AppendLine("Best reliable: the 2.9.7 approach (no other was both faster and reliable in this test).");
            else b.AppendLine("BEST RELIABLE: "+WholesaleSpeed.NameOf(best)+": "+S(MedianMs(ba))+" s an order (2.9.7: "+S(m0)+" s); the list in "+S(ba.list.Refresh)+" s (2.9.7: "+(b0==null?"-":S(b0.list.Refresh))+" s); every order read as the baseline read it (or changed in COSTAR meanwhile).");
            if(b0!=null&&m0>0) {
                long sum=0;bool all=true;
                foreach(var k in new[]{"direct","ready","lean","timers"}) { var a=f.arms.FirstOrDefault(x=>x.key==k);if(a==null||MedianMs(a)<0) { all=false;continue; } sum+=m0-MedianMs(a); }
                var both=f.arms.FirstOrDefault(x=>x.key=="all");
                if(all&&both!=null&&MedianMs(both)>=0) b.AppendLine("The four improvements on their own save "+S(sum)+" s an order between them; all four together "+S(m0-MedianMs(both))+" s ("+(m0-MedianMs(both)>=sum?"they add up":"they overlap: some of the same time")+"). The list (not an order's time): "+S(b0.list.Refresh)+" s with 2.9.7, "+S(both.list.Refresh)+" s with all four.");
            }
            if(b0!=null&&bLast!=null&&MedianMs(bLast)>=0&&MedianMs(b0)>0) { long first=MedianMs(b0),again=MedianMs(bLast);b.AppendLine("The 2.9.7 approach first and again at the end: "+S(first)+" s and "+S(again)+" s an order: "+(Math.Abs(again-first)*10<=first?"COSTAR's speed held steady through the test.":"COSTAR's speed changed during the test: compare with care.")+" (2.9.7's figure above is the faster of the two.)"); }
            foreach(var k in new[]{"all-number","all-buf"}) { var a=f.arms.FirstOrDefault(x=>x.key==k);if(a!=null&&b0!=null) b.AppendLine(a.name+": "+S(MedianMs(a))+" s an order, the list "+S(a.list.Refresh)+" s"+(Reliable(a,f)?"":" (NOT reliable in this test: see below)")+"."); }
            foreach(var a in f.arms.Where(x=>x.list.filtered)) b.AppendLine(a.missedBuf<0?"The BUF filter: not checked against the whole list (the test didn't read it before and after).":a.missedBuf==0?"The BUF filter: the filtered list showed every BUF order the whole list showed before and after it ("+a.list.buf+" BUF).":"The BUF filter MISSED "+a.missedBuf+" BUF order"+(a.missedBuf==1?"":"s")+" that the whole list showed before and after it: NOT RELIABLE.");
            b.AppendLine();
            // What the test exercised, and what it didn't meet.
            var every=f.arms.SelectMany(a=>a.orders).ToList();
            var wrong=f.arms.Where(a=>a.orders.Any(o=>o.extra=="wrong place")).ToList();var ghost=every.Where(o=>o.extra=="not on the list").ToList();
            if(wrong.Count>0) b.AppendLine("A row not at its known place ("+wrong.Count+" test"+(wrong.Count==1?"":"s")+"): "+(wrong.All(ExtrasPassedWrong)?"the list was read whole and the same order read.":"NOT handled as it should be (see the JSON)."));
            if(ghost.Count>0) b.AppendLine("An order no longer on the list ("+ghost.Count+" test"+(ghost.Count==1?"":"s")+"): "+(ghost.All(o=>o.outcome=="not listed")?"skipped, nothing opened.":"NOT handled as it should be (see the JSON)."));
            var popped=every.Where(o=>o.times.firstPopupMs>=0).ToList();int late=every.Sum(o=>o.times.lateNotices),changing=every.Sum(o=>o.times.changing),locked=every.Count(o=>o.outcome=="locked");
            if(popped.Count>0) b.AppendLine("Notes and memos: "+every.Sum(o=>o.times.popups)+" answered; an order's first came "+S(popped.Min(o=>(long)o.times.firstPopupMs))+" to "+S(popped.Max(o=>(long)o.times.firstPopupMs))+" s after it showed; "+(late==0?"none after a tyre line was clicked.":late+" after a tyre line was clicked (answered by the next check)."));
            b.AppendLine(changing==0?"Stock panels: no figure changed between two reads (none was caught still filling in).":"Stock panels: a figure changed between two reads "+changing+" time"+(changing==1?"":"s")+" (caught still filling in, read again): "+String.Join(", ",f.arms.Where(a=>a.orders.Sum(o=>o.times.changing)>0).Select(a=>a.name+" "+a.orders.Sum(o=>o.times.changing)).ToArray())+".");
            if(locked>0) b.AppendLine("Open on another PC: "+locked+" time"+(locked==1?"":"s")+" (skipped, as it should be).");
            var untested=new List<string>();
            if(locked==0) untested.Add("an order open on another PC (open one of the test's orders at another PC while a test runs to see it)");
            if(late==0) untested.Add("a Notes or memo coming after a tyre line was clicked");
            if(changing==0) untested.Add("a stock panel still filling in");
            if(popped.Count==0) untested.Add("Notes or a memo popping up");
            if(untested.Count>0) b.AppendLine("Not met in this test: "+String.Join("; ",untested.ToArray())+".");
            if(b0!=null) {
                var notes=new List<string>();
                foreach(var a in f.arms.Where(x=>!Object.ReferenceEquals(x,b0))) {
                    var last=Object.ReferenceEquals(a,bLast)?null:bLast;
                    foreach(var bo in b0.orders.Where(x=>x.extra.Length==0)) {
                        var o=Of(a,bo.doc);string c=Compare(o,bo,Of(last,bo.doc));
                        if(c=="changed") notes.Add(a.name+", "+bo.doc+": changed in COSTAR meanwhile ("+(o==null?"":o.outcome=="locked"?"open on another PC":o.outcome=="not listed"||o.outcome=="not opened"?"gone from the list":"stock "+bo.stock+" then "+o.stock)+")");
                        else if(c=="unexplained") notes.Add(a.name+", "+bo.doc+": read differently with nothing changed ("+bo.outcome+" "+bo.tags+" stock "+bo.stock+", then "+o.outcome+" "+o.tags+" stock "+o.stock+"): NOT RELIABLE");
                        else if(c=="missing") notes.Add(a.name+", "+bo.doc+": not read ("+(o==null?"not reached":o.outcome)+")");
                    }
                }
                b.AppendLine(notes.Count==0?"Results: every approach read every order as the baseline did.":"Results: "+String.Join("; ",notes.ToArray())+".");
            }
            b.AppendLine();
            b.AppendLine("To use the best: Approach, then \""+WholesaleSpeed.NameOf(best)+"\" (from the next pass). To go back at any time: Back to 2.9.7.");
            b.AppendLine("Not part of this test (it needs another Windows login or COSTAR session): two wholesale sessions checking the list side by side.");
            return b.ToString();
        }
        static bool ExtrasPassedWrong(SpeedArmResult a) { return ExtrasPassed(new SpeedArmResult {orders=a.orders.Where(o=>o.extra!="not on the list").ToList()}); }
    }

    // The speed test itself (on a thread of its own, in the wholesale helper's session; Cancel stops it after the order
    // in hand): the list read once to choose the orders; then, one after another, a pass over those orders with each
    // preset: the baseline first and again last (anything that changed with the time of day shows), the four
    // improvements one at a time, all four together, all four with COSTAR's search by order number, all four with the
    // list filtered to BUF. Planned tests beside the orders: a row looked for at another order's place (it must be read
    // whole and the right order opened) with the direct row on its own and with all four; a made-up order number (not
    // on the list: nothing opened) with all four and with the search by number. What it keeps: nothing of the normal
    // checking (no previews, no Discord message per order), so it can be run again at once and doesn't change it.
    internal sealed class WholesaleSpeedTest {
        internal static readonly string[] Plan={"baseline","direct","ready","lean","timers","all","all-number","all-buf","baseline"};
        internal const string Ghost="ZZ0000000";
        readonly EntryCoordinator coordinator;readonly Action<string> say;readonly Func<string> session;readonly WholesaleDiscord discord;
        readonly int size;readonly List<string> asked;
        internal volatile bool Cancel;internal volatile bool Running=true;internal volatile string Status="Starting ...";
        volatile WholesaleRun current;
        internal string ReportText="",ReportFile="",BestKey="";
        List<HashSet<string>> bufSeen,filteredSeen;
        internal WholesaleSpeedTest(EntryCoordinator entries,Action<string> progress,Func<string> sessionCheck,WholesaleDiscord channel,int orders,IEnumerable<string> include) {
            coordinator=entries;say=progress;session=sessionCheck;discord=channel;size=Math.Max(2,Math.Min(30,orders));asked=(include??new string[0]).Where(x=>!String.IsNullOrWhiteSpace(x)).ToList();
        }
        internal WholesaleRun Current { get { return current; } }
        // Stopped after the order in hand (closed as usual); no further approach is run.
        internal void Stop() { Cancel=true;var r=current;if(r!=null) r.Finish=true; }
        void Say(string words) { try { say(words); } catch(Exception) { } }
        internal void Run() {
            var file=new SpeedTestFile {version=AutofillForm.Version,started=DateTime.Now.ToString("yyyy-MM-dd HH:mm",CultureInfo.InvariantCulture)};
            // Each pass's BUF orders as its list showed them: the whole list's (null for a filtered pass), the filtered list's.
            bufSeen=new List<HashSet<string>>();filteredSeen=new List<HashSet<string>>();
            try {
                AppLog.Note("wholesale_speed_start",size+" orders");
                Status="Speed test: reading the list to choose "+size+" orders ...";Say(Status);
                var look=new WholesaleRun(coordinator,say,new WholesaleOptions {Speed=WholesaleSpeed.Baseline,ListOnly=true,StayOnList=true,Session=session});
                current=look;look.Run();
                Order.Require(look.Stopped.Length==0,look.Stopped);
                Order.Require(!Cancel,"Stopped.");
                var rows=look.LastRows??new List<WholesaleRow>();
                file.listed=rows.Count;file.buf=rows.Count(r=>WholesaleRules.ShipViaBuf(r.ShipVia));
                file.sample=SpeedResults.Choose(rows,DateTime.Now.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture),size,asked);file.size=file.sample.Count;
                Order.Require(file.sample.Count>=2,"Fewer than 2 BUF orders a pass would open are on the list now: nothing to compare.");
                Say("Speed test orders: "+String.Join(", ",file.sample.ToArray())+".");
                var left=asked.Select(x=>Order.Norm(x)).Where(x=>!file.sample.Contains(x)).Distinct().ToList();
                if(left.Count>0) Say("Not in the test (not a BUF order a pass would open now, or more than "+size+" asked for): "+String.Join(", ",left.ToArray())+".");
                for(int i=0;i<Plan.Length;i++) {
                    Order.Require(!Cancel,"Stopped.");
                    var speed=WholesaleSpeed.Preset(Plan[i]);
                    Status="Speed test "+(i+1)+" of "+Plan.Length+": "+speed.Name+(i==Plan.Length-1?" (again)":"")+" ...";Say(Status);
                    var how=new WholesaleOptions {Speed=delegate { return speed; },Only=file.sample,StayOnList=true,RestoreList=true,Session=session,
                        WrongPlace=speed.key=="direct"||speed.key=="all",Ghost=speed.key=="all"||speed.key=="all-number"?Ghost:null};
                    var run=new WholesaleRun(coordinator,say,how);current=run;
                    var clock=Stopwatch.StartNew();run.Run();
                    var arm=new SpeedArmResult {key=speed.key,name=speed.Name+(i==Plan.Length-1?" (again)":""),stopped=run.Stopped,durationMs=clock.ElapsedMilliseconds,list=run.PassTimes??new WholesalePassTimes()};
                    foreach(var l in run.Looks.Where(x=>x.Opened||x.Locked||x.Extra!=null||file.sample.Contains(x.Row.Doc))) arm.orders.Add(SpeedResults.From(l));
                    arm.testsMs=arm.list.restore+arm.orders.Where(o=>o.extra.Length>0).Sum(o=>o.times.total);
                    file.arms.Add(arm);
                    var listedBuf=run.LastRows??new List<WholesaleRow>();
                    bufSeen.Add(arm.list.filtered?null:new HashSet<string>(listedBuf.Where(r=>WholesaleRules.ShipViaBuf(r.ShipVia)).Select(r=>r.Doc),StringComparer.Ordinal));
                    filteredSeen.Add(arm.list.filtered?new HashSet<string>(listedBuf.Where(r=>WholesaleRules.ShipViaBuf(r.ShipVia)).Select(r=>r.Doc),StringComparer.Ordinal):null);
                    AppLog.Note("wholesale_speed_arm",speed.key+": "+arm.orders.Count+" orders, median "+WholesaleTimes.S(SpeedReport.MedianMs(arm))+" s, list "+WholesaleTimes.S(arm.list.Refresh)+" s"+(arm.stopped.Length>0?", stopped: "+RoText.ForLog(arm.stopped):""));
                    // An order left open in COSTAR, someone at the PC, or the session gone: the test ends here (a person's turn).
                    Order.Require(run.LeftOpen==null,"Order "+run.LeftOpen+" was left open in COSTAR Sydney: close it there, then run the test again.");
                    Order.Require(!run.Stopped.StartsWith("Someone ",StringComparison.Ordinal),run.Stopped);
                    string gone=session==null?null:session();
                    Order.Require(gone==null,gone??"");
                    Order.Require(!Cancel,"Stopped.");
                    for(var w=Stopwatch.StartNew();w.ElapsedMilliseconds<2000&&!Cancel;) Thread.Sleep(100);
                }
            } catch(Exception e) {
                file.stopped=e is OperationCanceledException?"Stopped.":e.Message;
                AppLog.Note("wholesale_speed_stopped",RoText.ForLog(file.stopped));
            } finally {
                file.finished=DateTime.Now.ToString("HH:mm",CultureInfo.InvariantCulture);
                try {
                    for(int i=0;i<file.arms.Count&&i<filteredSeen.Count;i++) file.arms[i].missedBuf=SpeedResults.Missed(bufSeen,filteredSeen,i);
                    file.best=SpeedReport.Best(file);BestKey=file.arms.Count>0?file.best:"";
                    ReportText=SpeedReport.Text(file);
                    string folder=Path.Combine(RunDiagnostics.Root,"speed");Directory.CreateDirectory(folder);
                    string stamp=DateTime.Now.ToString("yyyyMMdd-HHmmss",CultureInfo.InvariantCulture);
                    File.WriteAllText(Path.Combine(folder,"speed-"+stamp+".json"),Wire.Json(file),new UTF8Encoding(false));
                    ReportFile=Path.Combine(folder,"speed-"+stamp+".txt");File.WriteAllText(ReportFile,ReportText,new UTF8Encoding(false));
                    AppLog.Note("wholesale_speed_done","best "+file.best+(file.stopped.Length>0?", stopped":""));
                    if(discord!=null&&file.arms.Count>0) {
                        var b0=SpeedReport.First(file);var ba=file.arms.FirstOrDefault(a=>a.key==file.best);
                        string m0=WholesaleTimes.S(b0==null?-1:SpeedReport.MedianMs(b0));
                        discord.Say("speed-"+stamp,"**DRY RUN** · Wholesale speed test "+(file.stopped.Length>0?"stopped early":"done")+" ("+file.sample.Count+" orders): "+(file.best=="baseline"||ba==null?"no approach was both faster and reliable (2.9.7: "+m0+" s an order).":"best reliable: "+WholesaleSpeed.NameOf(file.best)+", "+WholesaleTimes.S(SpeedReport.MedianMs(ba))+" s an order (2.9.7: "+m0+" s).")+" The report is in the wholesale helper.");
                    }
                } catch(Exception e) { AppLog.Note("wholesale_speed_report_failed",e.GetType().Name);if(ReportText.Length==0) ReportText="The speed test's report couldn't be made: "+e.Message; }
                Status=file.stopped.Length>0?"Speed test stopped: "+file.stopped:"Speed test done.";
                Running=false;
            }
        }
    }
}
