param([ValidateSet('Desk','RDP','Online')][string]$Mode = 'Desk', [switch]$NoHandOver)
$ErrorActionPreference = 'Stop'
# Auto-update (2.2.0+): the helper installs newer versions under
# %LOCALAPPDATA%\TempeMobileCostar\packages and points current.txt at the newest one.
# An older package folder hands over to it, so existing folders and shortcuts start the
# newest installed version. A missing or broken pointer never stops this version starting.
function Get-PackageVersion([string]$Folder) {
    try { return [version]((Get-Content -LiteralPath (Join-Path $Folder 'VERSION.txt') -ErrorAction Stop | Select-Object -First 1).Trim()) }
    catch { return [version]'0.0.0' }
}
if (-not $NoHandOver) {
    try {
        $pointer = Join-Path $env:LOCALAPPDATA 'TempeMobileCostar\packages\current.txt'
        if (Test-Path -LiteralPath $pointer) {
            $target = ((Get-Content -LiteralPath $pointer | Select-Object -First 1) + '').Trim()
            $here = (Resolve-Path -LiteralPath $PSScriptRoot).Path.TrimEnd('\')
            if ($target -and (Test-Path -LiteralPath (Join-Path $target 'Launch.ps1')) -and ($target.TrimEnd('\') -ne $here) -and
                ((Get-PackageVersion $target) -gt (Get-PackageVersion $PSScriptRoot))) {
                Write-Host ('Starting the newer installed helper: ' + $target)
                & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File (Join-Path $target 'Launch.ps1') -Mode $Mode -NoHandOver
                exit $LASTEXITCODE
            }
        }
    } catch { }
}
$stage = 'Build and self-tests'
$runtime = $null
try {
    $runtime = & (Join-Path $PSScriptRoot 'Build.ps1') -PassThru
    if (!$runtime -or !(Test-Path -LiteralPath $runtime.Executable)) { throw 'Build did not provide an executable path.' }
    $exe = $runtime.Executable
    if ($Mode -eq 'RDP' -or $Mode -eq 'Online') {
        $stage = 'Import the supplied worker connection file'
        $connection = Join-Path $PSScriptRoot 'worker-connection.json'
        if (Test-Path -LiteralPath $connection) { Copy-Item -LiteralPath $connection -Destination (Join-Path $runtime.Bin 'worker-connection.json') -Force }
        $modeArgument = if ($Mode -eq 'Online') { '--online' } else { '--worker' }
    }
    else { $modeArgument = '--desk' }
    $stage = 'Start the ' + $Mode + ' helper'
    Start-Process -FilePath $exe -WorkingDirectory $runtime.Bin -ArgumentList $modeArgument
} catch {
    $message = 'Launch failed during "' + $stage + '": ' + $_.Exception.Message
    if ($runtime -and $runtime.StartupLog) {
        try { $message | Add-Content -LiteralPath $runtime.StartupLog -Encoding UTF8 } catch { }
        $message += [Environment]::NewLine + 'Startup report: ' + $runtime.StartupLog
    }
    Write-Host $message -ForegroundColor Red
    exit 1
}
