console.log("F_alt_tab.js loaded successfully");

/* =========================
   Shared helpers
   ========================= */

const EXTENSION_BRIDGE_TIMEOUT_MS = 20000;
let extensionFetchRequestCounter = 0;

function fetchViaExtension(targetUrl, options = {}) {
    return new Promise((resolve, reject) => {
        const requestId =
            `general-fetch-${Date.now()}-${++extensionFetchRequestCounter}`;

        let settled = false;

        const cleanup = () => {
            window.removeEventListener("message", handleBridgeResponse);
            window.clearTimeout(timeoutId);
        };

        const finish = (callback, value) => {
            if (settled) return;
            settled = true;
            cleanup();
            callback(value);
        };

        const handleBridgeResponse = (event) => {
            if (event.source !== window) return;

            const data = event.data;
            if (
                !data ||
                data.source !== "GENERAL_FETCH_BRIDGE" ||
                data.type !== "GENERAL_FETCH_RESPONSE" ||
                data.id !== requestId
            ) {
                return;
            }

            const result = data.result;

            if (!result?.ok) {
                finish(
                    reject,
                    new Error(result?.error || "Chrome Fetch Bridge request failed")
                );
                return;
            }

            if (
                typeof result.status === "number" &&
                (result.status < 200 || result.status >= 400)
            ) {
                finish(
                    reject,
                    new Error(
                        `${result.status} ${result.statusText || "HTTP error"}`
                    )
                );
                return;
            }

            finish(resolve, result);
        };

        const timeoutId = window.setTimeout(() => {
            finish(
                reject,
                new Error(
                    "Chrome Fetch Bridge did not respond. Check that the extension is enabled and 'Allow access to file URLs' is turned on."
                )
            );
        }, EXTENSION_BRIDGE_TIMEOUT_MS);

        window.addEventListener("message", handleBridgeResponse);

        window.postMessage({
            source: "LOCAL_HELPER_PAGE",
            type: "GENERAL_FETCH_REQUEST",
            id: requestId,
            url: targetUrl,
            options,
        }, "*");
    });
}

function decodeHtmlEntities(text) {
    const textarea = document.createElement("textarea");
    textarea.innerHTML = String(text || "");
    return textarea.value;
}

function unwrapPreResponse(text) {
    const raw = String(text || "");
    const doc = new DOMParser().parseFromString(raw, "text/html");
    const preText = doc.querySelector("pre")?.textContent;
    return preText ? preText : raw;
}

function looksLikeCaptchaPage(html) {
    const text = String(html || "").toLowerCase();
    return (
        text.includes("verify you are human") ||
        text.includes("verification required") ||
        text.includes("g-recaptcha") ||
        text.includes("/captcha-verify") ||
        text.includes("captcha") && text.includes("recaptcha")
    );
}

function looksLikeBlockedPage(html) {
    const text = String(html || "").toLowerCase();
    return (
        looksLikeCaptchaPage(text) ||
        text.includes("access denied") ||
        text.includes("you have been blocked") ||
        text.includes("temporarily blocked") ||
        text.includes("blocked by")
    );
}

function looksLikeJinaResponse(text) {
    const raw = unwrapPreResponse(text);
    return (
        raw.includes("Markdown Content:") ||
        raw.includes("URL Source:") ||
        raw.includes("Title: Buy New") ||
        raw.includes("[**")
    );
}

async function fetchTextWithFallback(targetUrl) {
    const viaPc = window.TempeCostarClient?.isPaired();
    console.log(viaPc ? "Fetching through paired PC receiver:" : "Fetching through Chrome extension:", targetUrl);

    const result = viaPc
        ? await window.TempeCostarClient.fetchTyres(targetUrl)
        : await fetchViaExtension(targetUrl, { method: "GET", cache: "no-store" });

    const text = String(result.text || "");

    if (!text.trim()) {
        throw new Error("empty-response");
    }

    const hasProducts = text.includes("product-container");

    if (!hasProducts && looksLikeBlockedPage(text)) {
        throw new Error("captcha-or-blocked-response");
    }

    return {
        text,
        proxyBase: viaPc ? "pc-receiver" : "chrome-extension",
        isJina: false,
        status: result.status,
        finalUrl: result.finalUrl || targetUrl,
    };
}

async function fetchHtmlWithFallback(targetUrl) {
    const result = await fetchTextWithFallback(targetUrl);
    return result.text;
}

function normalizeAbsoluteUrl(url) {
    if (!url || url === "#") return "#";
    if (/^https?:\/\//i.test(url)) return url.replace(/^http:\/\//i, "https://");
    return new URL(url, "https://tempetyres.com.au").href;
}

function escapeHtml(text) {
    return String(text ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function escapeJsSingle(text) {
    return String(text ?? "")
        .replace(/\\/g, "\\\\")
        .replace(/'/g, "\\'")
        .replace(/\n/g, " ")
        .replace(/\r/g, " ");
}

function extractSkuFromProductUrl(url) {
    if (!url || url === "#") return "";

    try {
        const clean = decodeURIComponent(url.split("?")[1] || url);
        const last = clean
            .split("-")
            .pop()
            ?.replace(/[^a-z0-9]/gi, "")
            .trim();

        // Tempe commonly leaves the SKU at the end of the product URL even
        // when the hidden tyresku input disappears for On Order / OOS items.
        // Requiring at least one digit avoids treating words such as
        // "runflat" as an SKU.
        if (
            last &&
            last.length >= 4 &&
            last.length <= 20 &&
            /\d/.test(last)
        ) {
            return last.toUpperCase();
        }
    } catch {}

    return "";
}

function copySKU(sku) {
    if (!sku || sku === "No SKU" || sku === "No SKU available" || sku === "JINA-N/A") return;

    navigator.clipboard.writeText(sku)
        .then(() => {
            const toast = document.createElement("div");
            toast.textContent = `Copied: ${sku}`;
            toast.style.position = "fixed";
            toast.style.bottom = "20px";
            toast.style.right = "20px";
            toast.style.padding = "8px 12px";
            toast.style.background = "#16a34a";
            toast.style.color = "white";
            toast.style.borderRadius = "6px";
            toast.style.fontSize = "14px";
            toast.style.opacity = "0";
            toast.style.transition = "opacity 0.3s ease";
            toast.style.zIndex = "9999";
            document.body.appendChild(toast);

            requestAnimationFrame(() => {
                toast.style.opacity = "1";
            });

            setTimeout(() => {
                toast.style.opacity = "0";
                setTimeout(() => toast.remove(), 300);
            }, 800);
        })
        .catch((err) => console.error("Copy failed", err));
}

async function selectTyreForFitment(tyre) {
    try {
        // Other existing pages may also load F_alt_tab.js without the new script tag.
        if (!window.TempeJobCard) {
            window.tempeJobCardLoad ||= new Promise((resolve, reject) => {
                const script = document.createElement("script");
                script.src = "./jobcard-shared.js";
                script.onload = resolve;
                script.onerror = () => reject(new Error("Upload jobcard-shared.js beside this page."));
                document.head.appendChild(script);
            });
            await window.tempeJobCardLoad;
        }
        return await window.TempeJobCard.addProduct({
            type: "tyre", sku: tyre.sku,
            description: [tyre.make, tyre.model].filter(Boolean).join(" "),
        });
    } catch (error) {
        if (window.TempeJobCard) window.TempeJobCard.toast(error.message);
        else alert(error.message);
        return null;
    }
}

function handleSkuInputEnter(e) {
    if (e.key === "Enter") {
        e.preventDefault();

        // Clipboard copy is triggered directly from the physical Enter keypress.
        copyCurrentTempeSearchLinksImmediate();

        checkPrices({ copyLink: false });

        // Keep keyboard focus on the tyre-size box after Enter.
        // Tab then follows the browser's normal/native tab order.
        const tyreInput = e.currentTarget;
        if (tyreInput && typeof tyreInput.focus === "function") {
            try {
                tyreInput.focus({ preventScroll: true });
            } catch {
                tyreInput.focus();
            }
        }
    }
}

function handleSkuInputDone(e) {
    if (e.target.value.trim()) {
        checkPrices();
    }
}

function getStockColor(stockStatus) {
    if (!stockStatus) return "transparent";
    const lower = stockStatus.toLowerCase();

    if (lower.includes("out of stock")) return "#4b1113";
    if (lower.includes("on order")) return "#1a1a1d";
    if (lower.match(/\b[1-4]\s*in stock\b/)) return "#4b2a12";
    if (lower.match(/\b[5-8]\s*in stock\b/)) return "#3b3a16";
    if (lower.includes("8+ in stock") || lower.includes("in stock")) return "#123524";

    return "transparent";
}

function isAvailableStock(stockText) {
    if (!stockText) return false;
    const lower = stockText.toLowerCase();

    if (lower.includes("out of stock")) return false;
    if (lower.includes("on order")) return false;
    if (lower.includes("no status")) return false;
    if (lower.includes("no stock")) return false;

    if (lower.includes("in stock")) return true;
    if (/\d+/.test(lower)) return true;

    return false;
}

/* =========================
   Product parsers
   ========================= */

function parseTempetyresHtmlProducts(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const items = doc.querySelectorAll(".product-container");

    return Array.from(items).map((item) => {
        const make = item.querySelector(".brand-name b")?.textContent.trim() || "No make";
        const size = item.querySelector(".sub-heading-ty-2")?.textContent.trim() || "";
        const pattern = item.querySelector(".sub-heading-ty-3")?.textContent.trim() || "";
        const model = `${size} ${pattern}`.trim() || "No model";
        const rawPrice = item.querySelector(".sale-price span")?.textContent.trim() || "0";
        const price = parseFloat(rawPrice.replace(/[^\d.]/g, "")) || 0;
        const stock = item.querySelector(".stocklevel-small .stock-label")?.textContent.trim() || "On Order";
        const linkEl = item.querySelector(".image-container a");
        const link = linkEl ? normalizeAbsoluteUrl(linkEl.getAttribute("href")) : "#";

        const hiddenSku = item.querySelector("input[name='tyresku']")?.value?.trim() || "";
        const urlSku = extractSkuFromProductUrl(link);
        const sku = hiddenSku || urlSku || "No SKU";

        return {
            make,
            brand: make,
            model,
            pattern,
            price,
            stock,
            sku,
            link,
            source: "html",
        };
    });
}

function getNearestProductLinkFromJina(lines, brandIndex) {
    for (let i = brandIndex; i >= Math.max(0, brandIndex - 5); i--) {
        const line = lines[i] || "";
        const match = line.match(/\]\((https?:\/\/[^)\s"]*tyreproducts\?[^)\s"]*)/i);
        if (match) return normalizeAbsoluteUrl(match[1]);
    }
    return "#";
}

function parseJinaMarkdownProducts(text) {
    let raw = unwrapPreResponse(text);
    raw = decodeHtmlEntities(raw);

    const content = raw.includes("Markdown Content:")
        ? raw.split("Markdown Content:").slice(1).join("Markdown Content:")
        : raw;

    const lines = content
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter(Boolean);

    const products = [];

    for (let i = 0; i < lines.length; i++) {
        const brandMatch = lines[i].match(/^\[\*\*(.+?)\*\*\]\(/);
        if (!brandMatch) continue;

        const make = brandMatch[1].trim();
        if (!make || make.length > 40) continue;

        let j = i + 1;
        while (j < lines.length && /^(SALE|\$\d+\s*EA|SOLD|OUT)$/i.test(lines[j])) j++;

        const sizeLine = lines[j] || "";
        if (!/(LT)?\d{3}\/?\d{2}R\d{2}/i.test(sizeLine)) continue;

        const pattern = lines[j + 1] || "No pattern";

        let stock = "No stock";
        let priceText = "";

        for (let k = j + 2; k < Math.min(lines.length, j + 12); k++) {
            const line = lines[k];

            if (/^(\d+\+?\s+IN STOCK(?:\s+NOW)?|ON ORDER|OUT OF STOCK|\d+\s+IN STOCK)$/i.test(line)) {
                stock = line.replace(/\s+NOW$/i, "").trim();
                continue;
            }

            if (/^\$\s*(\d+(?:\.\d+)?|TBC)$/i.test(line)) {
                priceText = line;
                break;
            }
        }

        const price = priceText.toUpperCase().includes("TBC")
            ? 0
            : parseFloat(priceText.replace(/[^\d.]/g, "")) || 0;

        const link = getNearestProductLinkFromJina(lines, i);
        const sku = extractSkuFromProductUrl(link) || "JINA-N/A";
        const model = `${sizeLine} ${pattern}`.trim();

        products.push({
            make,
            brand: make,
            model,
            pattern,
            price,
            stock,
            sku,
            link,
            source: "jina",
        });
    }

    return products;
}

function buildTempeTyreSearchUrl(size) {
    const cleanSize = String(size || "").trim();

    if (!cleanSize || ![5, 7].includes(cleanSize.length)) {
        return "";
    }

    const width = cleanSize.slice(0, 3);
    const diameter = cleanSize.slice(-2);
    const profile = cleanSize.length === 7
        ? cleanSize.slice(3, 5)
        : "Not%20Specified";

    return `https://www.tempetyres.com.au/tyres?TyreWidth=${width}&TyreProfile=${profile}&TyreDiameter=${diameter}`;
}

function getTempeSearchUrlsFromQueries(queries) {
    return [...new Set(
        queries
            .map(buildTempeTyreSearchUrl)
            .filter(Boolean)
    )];
}

function showTempeLinkCopiedToast(count) {
    const toast = document.createElement("div");
    toast.textContent = count === 1
        ? "Tempe link copied"
        : `${count} Tempe links copied`;
    toast.style.position = "fixed";
    toast.style.bottom = "20px";
    toast.style.right = "20px";
    toast.style.padding = "8px 12px";
    toast.style.background = "#16a34a";
    toast.style.color = "white";
    toast.style.borderRadius = "6px";
    toast.style.fontSize = "14px";
    toast.style.opacity = "0";
    toast.style.transition = "opacity 0.3s ease";
    toast.style.zIndex = "9999";
    document.body.appendChild(toast);

    requestAnimationFrame(() => {
        toast.style.opacity = "1";
    });

    setTimeout(() => {
        toast.style.opacity = "0";
        setTimeout(() => toast.remove(), 300);
    }, 800);
}

function legacyCopyText(text) {
    // Remember where keyboard focus was before the temporary clipboard
    // textarea steals it.
    const previousActiveElement = document.activeElement;

    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.setAttribute("readonly", "");
    textarea.style.position = "fixed";
    textarea.style.left = "-9999px";
    textarea.style.top = "0";
    textarea.style.opacity = "0";

    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();

    let copied = false;

    try {
        copied = document.execCommand("copy");
    } catch (error) {
        console.error("Legacy clipboard copy failed", error);
    }

    textarea.remove();

    // Restore the element that had focus before copying.
    if (
        previousActiveElement &&
        typeof previousActiveElement.focus === "function"
    ) {
        try {
            previousActiveElement.focus({ preventScroll: true });
        } catch {
            previousActiveElement.focus();
        }
    }

    return copied;
}

function copyTempeSearchLinksImmediate(queries) {
    const urls = getTempeSearchUrlsFromQueries(queries);
    if (!urls.length) return false;

    const text = urls.join("\n");

    // execCommand is intentionally tried first here because it runs
    // synchronously inside the user's Enter/click gesture.
    if (legacyCopyText(text)) {
        showTempeLinkCopiedToast(urls.length);
        return true;
    }

    // Modern clipboard API as a fallback.
    if (navigator.clipboard?.writeText) {
        navigator.clipboard.writeText(text)
            .then(() => showTempeLinkCopiedToast(urls.length))
            .catch((error) => console.error("Could not copy Tempe search link", error));

        return true;
    }

    return false;
}

function getCurrentSizeQueries() {
    return document.getElementById("skuInput")
        .value
        .trim()
        .split("\n")
        .map((line) => line.trim())
        .filter((query) => [5, 7].includes(query.length));
}

function copyCurrentTempeSearchLinksImmediate() {
    return copyTempeSearchLinksImmediate(getCurrentSizeQueries());
}

function extractProductAnalytics(html) {
    const raw = String(html || "");

    // Look specifically inside dataLayer.push({...}) objects describing a
    // product page. Tempe exposes both the real product identifier and, for
    // some products such as Bridgestone, the useful hidden price here.
    const pushes = raw.matchAll(/dataLayer\.push\(\s*\{([\s\S]*?)\}\s*\);/gi);

    for (const match of pushes) {
        const block = match[1] || "";

        if (!/['"]ecomm_pagetype['"]\s*:\s*['"]product['"]/i.test(block)) {
            continue;
        }

        const valueMatch = block.match(
            /['"]ecomm_totalvalue['"]\s*:\s*['"]([\d,.]+)['"]/i
        );

        const productIdMatch = block.match(
            /['"]ecomm_prodid['"]\s*:\s*\[\s*['"]([^'"]+)['"]\s*\]/i
        );

        const hiddenPrice = valueMatch
            ? Number.parseFloat(valueMatch[1].replace(/,/g, ""))
            : null;

        const sku = productIdMatch
            ? String(productIdMatch[1] || "").trim().toUpperCase()
            : "";

        return {
            hiddenPrice: Number.isFinite(hiddenPrice) ? hiddenPrice : null,
            sku,
        };
    }

    return {
        hiddenPrice: null,
        sku: "",
    };
}

async function mapWithSmallConcurrency(items, concurrency, worker) {
    const safeConcurrency = Math.max(
        1,
        Math.min(concurrency, items.length || 1)
    );

    const results = new Array(items.length);
    let index = 0;

    async function runWorker() {
        while (index < items.length) {
            const current = index++;
            results[current] = await worker(items[current], current);
        }
    }

    await Promise.all(
        Array.from({ length: safeConcurrency }, () => runWorker())
    );

    return results;
}

async function enrichProductDetails(products) {
    const jobs = products
        .map((item, index) => ({ item, index }))
        .filter(({ item }) => {
            const make = String(item?.make || item?.brand || "")
                .trim()
                .toLowerCase();

            const needsBridgestonePrice = make === "bridgestone";
            const needsSku =
                !item?.sku ||
                item.sku === "No SKU" ||
                item.sku === "No SKU available" ||
                item.sku === "JINA-N/A";

            return (
                item?.link &&
                item.link !== "#" &&
                (needsBridgestonePrice || needsSku)
            );
        });

    if (!jobs.length) {
        return products;
    }

    await mapWithSmallConcurrency(
        jobs,
        4,
        async ({ item, index }) => {
            try {
                const productHtml = await fetchHtmlWithFallback(item.link);
                const analytics = extractProductAnalytics(productHtml);

                const make = String(item?.make || item?.brand || "")
                    .trim()
                    .toLowerCase();

                const updated = { ...item };

                // Recover SKU from ecomm_prodid whenever the listing page did
                // not expose one. If analytics does not contain it, keep the
                // URL-derived SKU as the next fallback.
                if (
                    !updated.sku ||
                    updated.sku === "No SKU" ||
                    updated.sku === "No SKU available" ||
                    updated.sku === "JINA-N/A"
                ) {
                    const urlSku = extractSkuFromProductUrl(updated.link);
                    updated.sku =
                        analytics.sku ||
                        urlSku ||
                        "SKU unavailable";
                }

                // For Bridgestone, always preserve the public/listing price and
                // override the working price with ecomm_totalvalue when found.
                if (
                    make === "bridgestone" &&
                    Number.isFinite(analytics.hiddenPrice)
                ) {
                    updated.originalPrice = Number(item.price || 0);
                    updated.price = analytics.hiddenPrice;
                    updated.bridgestoneHiddenPrice = true;
                }

                products[index] = updated;
            } catch (error) {
                console.warn(
                    `Could not enrich product details for ${item.sku || item.link}:`,
                    error
                );

                // Even if the product-page request fails, use a URL-derived SKU
                // rather than leaving "No SKU" on screen when possible.
                if (
                    !item.sku ||
                    item.sku === "No SKU" ||
                    item.sku === "No SKU available" ||
                    item.sku === "JINA-N/A"
                ) {
                    const urlSku = extractSkuFromProductUrl(item.link);
                    if (urlSku) {
                        products[index] = {
                            ...item,
                            sku: urlSku,
                        };
                    }
                }
            }
        }
    );

    return products;
}

async function fetchTyreProductsBySize(size) {
    if (!size || ![5, 7].includes(size.length)) {
        return {
            products: [],
            manualUrl: "",
            error: "Invalid size",
        };
    }

    const targetUrl = buildTempeTyreSearchUrl(size);

    try {
        const result = await fetchTextWithFallback(targetUrl);
        const products = result.isJina
            ? parseJinaMarkdownProducts(result.text)
            : parseTempetyresHtmlProducts(result.text);

        const finalProducts = products.length
            ? products
            : parseJinaMarkdownProducts(result.text);

        // Bridgestone public/listing prices can be hidden (0) or intentionally
        // different from the product analytics value. For Bridgestone only,
        // load each product page and override with ecomm_totalvalue.
        await enrichProductDetails(finalProducts);

        return {
            products: finalProducts,
            manualUrl: targetUrl,
            error: finalProducts.length ? "" : "No products parsed",
        };
    } catch (err) {
        console.error(`Failed to fetch tyre size ${size}:`, err);
        return {
            products: [],
            manualUrl: targetUrl,
            error: err.message || "Failed to fetch",
        };
    }
}

function renderManualFallbackRow(query, manualUrl, message = "Could not load results automatically") {
    return `<tr>
        <td colspan="5">
            ${escapeHtml(message)} for <strong>${escapeHtml(query)}</strong>.<br>
            Manual link: <a href="${manualUrl}" target="_blank" style="color:#93c5fd;">Open Tempe Tyres search</a>
        </td>
    </tr>`;
}

function renderFAltProductRow(item) {
    const make = item.make || item.brand || "No make";
    const model = item.model || item.pattern || "No model";
    const price = Number(item.price || 0);
    const originalPrice = Number(item.originalPrice ?? price);
    const stock = item.stock || "No stock";
    const sku = item.sku || "SKU unavailable";
    const link = item.link || "#";

    const safeStockAttr = escapeHtml(stock);
    const safeSku = escapeJsSingle(sku);
    const safeMake = escapeJsSingle(make);
    const safeModel = escapeJsSingle(model);
    const safeLink = escapeJsSingle(link);

    const skuDisplay = sku === "JINA-N/A"
        ? `<span title="Jina result does not expose the exact hidden SKU">JINA-N/A</span>`
        : escapeHtml(sku);

    return `<tr 
        style="background:${getStockColor(stock)};"
        data-stock="${safeStockAttr}"
    >
        <td>${escapeHtml(make)}</td>

        <td>
            <a href="${link}" target="_blank" style="color:#93c5fd; text-decoration:none;">
                ${escapeHtml(model)}
            </a>
            <span style="opacity:0.8; font-size:0.9em;"> (${escapeHtml(stock)})</span>
        </td>

        <td>
            ${item.bridgestoneHiddenPrice
                ? `<div style="text-decoration:line-through; opacity:0.55;">$${originalPrice.toFixed(2)}</div>
                   <div style="font-weight:700;">$${price.toFixed(2)}</div>`
                : `$${price.toFixed(2)}`}
        </td>

        <td onclick="copySKU('${safeSku}')" style="cursor:pointer; color:#60a5fa;">
            ${skuDisplay}
        </td>

        <td>
            <button
                type="button"
                data-jobcard-product="${escapeHtml(JSON.stringify({ sku, make, model }))}"
                onclick="selectTyreForFitment(JSON.parse(this.dataset.jobcardProduct));"
            >
                Add Tyre
            </button>
        </td>
    </tr>`;
}

/* =========================
   TYRES TINDER
   ========================= */

let savedTinderResults = {};
let activeTinderResults = {};

function cloneTinderResults(data) {
    return Object.fromEntries(
        Object.entries(data || {}).map(([brand, sets]) => [
            brand,
            {
                front: [...(sets.front || [])],
                rear: [...(sets.rear || [])],
            },
        ])
    );
}

function tinderItemMatches(item, keyword) {
    if (!item) return false;

    return [
        item.brand,
        item.pattern,
        item.stock,
        item.sku,
        item.price,
    ].some((value) => String(value || "").toLowerCase().includes(keyword));
}

function applyTinderTextFilter(keyword) {
    const normalizedKeyword = String(keyword || "").toLowerCase().trim();
    const baseResults = Object.keys(activeTinderResults).length
        ? activeTinderResults
        : savedTinderResults;

    if (!normalizedKeyword) {
        renderTinderResults(cloneTinderResults(baseResults));
        return;
    }

    const filtered = {};

    for (const [brand, sets] of Object.entries(baseResults)) {
        const brandMatches = brand.toLowerCase().includes(normalizedKeyword);

        const matchingFront = brandMatches
            ? [...sets.front]
            : sets.front.filter((item) => tinderItemMatches(item, normalizedKeyword));

        const matchingRear = brandMatches
            ? [...sets.rear]
            : sets.rear.filter((item) => tinderItemMatches(item, normalizedKeyword));

        if (matchingFront.length || matchingRear.length) {
            filtered[brand] = {
                front: matchingFront,
                rear: matchingRear,
            };
        }
    }

    renderTinderResults(filtered);
}

async function Tinder() {
    const skuInput = document.getElementById("skuInput").value.trim();
    const skuInput2 = document.getElementById("skuInput2").value.trim();
    const resultsTable = document.querySelector("#resultsTable tbody");
    resultsTable.innerHTML = "";

    const fetchTyreDetails = async (size) => {
        if (!size || size.length !== 7) return [];

        const result = await fetchTyreProductsBySize(size);
        return result.products.map((item) => ({
            brand: item.brand || item.make || "No brand available",
            pattern: item.pattern || item.model || "No pattern available",
            price: item.price ? item.price.toFixed(2) : "0.00",
            stock: item.stock || "On Order",
            sku: item.sku || "No SKU available",
            link: item.link || result.manualUrl || "#",
        }));
    };

    const [front, rear] = await Promise.all([
        fetchTyreDetails(skuInput),
        fetchTyreDetails(skuInput2),
    ]);

    const grouped = {};
    savedTinderResults = {};

    [...front, ...rear].forEach((item) => {
        grouped[item.brand] = grouped[item.brand] || { front: [], rear: [] };
        (front.includes(item) ? grouped[item.brand].front : grouped[item.brand].rear).push(item);

        savedTinderResults[item.brand] = savedTinderResults[item.brand] || { front: [], rear: [] };
        (front.includes(item) ? savedTinderResults[item.brand].front : savedTinderResults[item.brand].rear).push(item);
    });

    activeTinderResults = cloneTinderResults(savedTinderResults);
    renderTinderResults(cloneTinderResults(activeTinderResults));
}

function renderTinderResults(data) {
    const resultsTable = document.querySelector("#resultsTable tbody");
    resultsTable.innerHTML = "";

    const sorted = Object.keys(data).sort();
    sorted.forEach((brand) => {
        const { front, rear } = data[brand];
        front.sort((a, b) => a.pattern.localeCompare(b.pattern));
        rear.sort((a, b) => a.pattern.localeCompare(b.pattern));

        const rowCount = Math.max(front.length, rear.length);
        const safeBrand = escapeHtml(brand || "");

        for (let i = 0; i < rowCount; i++) {
            const f = front[i] || {}, r = rear[i] || {};

            const safeFrontSku = escapeJsSingle(f.sku || "");
            const safeRearSku = escapeJsSingle(r.sku || "");

            const row = `<tr data-brand="${safeBrand.toLowerCase()}">
                ${i === 0 ? `<td rowspan="${rowCount}">${safeBrand}</td>` : ""}
                <td style="background:${getStockColor(f.stock)};" data-stock="${escapeHtml(f.stock || "")}">
                    ${f.pattern ? `<a href="${f.link}" target="_blank">${escapeHtml(f.pattern)}</a>` : "No data"}${f.price ? ` - $${escapeHtml(f.price)}` : ""} (${escapeHtml(f.stock || "No stock")})</td>
                <td style="background:${getStockColor(r.stock)};" data-stock="${escapeHtml(r.stock || "")}">
                    ${r.pattern ? `<a href="${r.link}" target="_blank">${escapeHtml(r.pattern)}</a>` : "No data"}${r.price ? ` - $${escapeHtml(r.price)}` : ""} (${escapeHtml(r.stock || "No stock")})</td>

                <td onclick="copySKU('${safeFrontSku}')" style="cursor:pointer; color:#60a5fa;">
                    ${escapeHtml(f.sku || "No SKU")}
                </td>

                <td onclick="copySKU('${safeRearSku}')" style="cursor:pointer; color:#60a5fa;">
                    ${escapeHtml(r.sku || "No SKU")}
                </td>
            </tr>`;
            resultsTable.innerHTML += row;
        }
    });

    if (sorted.length === 0) {
        resultsTable.innerHTML = `<tr><td colspan="5">No matching tyres found.</td></tr>`;
    }
}

function removeOutOfStockTinder() {
    const filtered = {};

    for (const [brand, sets] of Object.entries(savedTinderResults)) {
        const goodFront = sets.front.filter((item) => isAvailableStock(item.stock));
        const goodRear = sets.rear.filter((item) => isAvailableStock(item.stock));

        if (goodFront.length && goodRear.length) {
            filtered[brand] = {
                front: goodFront,
                rear: goodRear,
            };
        }
    }

    activeTinderResults = cloneTinderResults(filtered);

    const currentKeyword = document.getElementById("searchBar")?.value || "";
    applyTinderTextFilter(currentKeyword);
}

/* =========================
   F ALT TAB
   ========================= */

async function checkPrices({ copyLink = true } = {}) {
    const skuInput = document.getElementById("skuInput").value.trim().split("\n");
    const resultsTable = document.querySelector("#resultsTable tbody");

    // Search button clicks still copy automatically.
    // Enter-key searches already copied directly inside handleSkuInputEnter().
    if (copyLink) {
        copyCurrentTempeSearchLinksImmediate();
    }

    resultsTable.innerHTML = `<tr><td colspan="5">Searching...</td></tr>`;

    const rows = await Promise.all(skuInput.map(async (line) => {
        const query = line.trim();
        if (!query) return "";

        if (![5, 7].includes(query.length)) {
            return `<tr><td colspan="5">Invalid input: ${escapeHtml(query)}</td></tr>`;
        }

        const result = await fetchTyreProductsBySize(query);

        if (!result.products.length) {
            return renderManualFallbackRow(
                query,
                result.manualUrl,
                "Could not load results. Check the PC receiver connection or desktop Chrome Fetch Bridge"
            );
        }

        return result.products.map(renderFAltProductRow).join("\n");
    }));

    const rendered = rows.flat().join("\n").trim();
    resultsTable.innerHTML = rendered || `<tr><td colspan="5">No results returned.</td></tr>`;
    sortTableByPrice();
}

function sortTableByPrice() {
    const tbody = document.querySelector("#resultsTable tbody");
    const rows = Array.from(tbody.querySelectorAll("tr"));

    rows.sort((a, b) => {
        const aPrice = parseFloat((a.cells[2]?.textContent || "").replace("$", "")) || 0;
        const bPrice = parseFloat((b.cells[2]?.textContent || "").replace("$", "")) || 0;
        return aPrice - bPrice;
    });

    tbody.innerHTML = "";
    rows.forEach((r) => tbody.appendChild(r));
}

/* =========================
   SHARED FILTERS
   ========================= */

function removeOutOfStock() {
    const rows = document.querySelectorAll("#resultsTable tbody tr");

    rows.forEach((row) => {
        const stock = row.dataset.stock || "";
        row.style.display = isAvailableStock(stock) ? "" : "none";
    });
}

function filterTable() {
    const searchBar = document.getElementById("searchBar");
    const keyword = searchBar?.value.toLowerCase().trim() || "";

    // Tyres Tinder uses grouped rows with rowspans. Re-rendering the matching
    // data keeps every brand cell and rowspan valid after searches like "runflat".
    if (
        document.body.classList.contains("tinder-page") &&
        Object.keys(savedTinderResults).length
    ) {
        applyTinderTextFilter(keyword);
        return;
    }

    // Standard row filtering for F Alt Tab.
    const rows = document.querySelectorAll("#resultsTable tbody tr");

    rows.forEach((row) => {
        if (!keyword) {
            row.style.display = "";
            return;
        }

        const brand = (row.dataset.brand || "").toLowerCase();
        const matchInCells = [...row.cells].some((cell) =>
            cell.textContent.toLowerCase().includes(keyword)
        );

        row.style.display = matchInCells || brand.includes(keyword) ? "" : "none";
    });
}
