using System;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    internal static class Branch11 {
        internal static bool MainTitle(string title) { return Regex.IsMatch(title??"",@"^COSTAR:\s*11\s+Tempe\s+Tyres\s+Tempe(?:\s|$)",RegexOptions.IgnoreCase); }
        internal static bool OrderTitle(string title) { return Regex.IsMatch(title??"",@"^RepairOrder\s+Branch\s+11\b",RegexOptions.IgnoreCase); }
    }
    internal sealed class CostarInstance {
        internal readonly int Pid,Session;
        internal readonly long MainWindow,Started;
        internal readonly string Title;
        internal CostarInstance(int pid,long window,long started,int session,string title) {Pid=pid;MainWindow=window;Started=started;Session=session;Title=title;}
        internal bool Same(CostarInstance other) { return other!=null && Pid==other.Pid && MainWindow==other.MainWindow && Started==other.Started && Session==other.Session; }
        public override string ToString() { return "Branch 11 | PID "+Pid+" | Window "+MainWindow+" | "+Title+(OrderCheckLink.IsWipWindow(this)?" | Order Check's WIP window (not used for entry)":""); }
    }
    // UI selection, mobile dispatch and online entry share this gate. A lease
    // freezes the selected instance until the entire run (including cleanup) ends.
    internal sealed class EntryCoordinator {
        readonly object gate=new object();CostarInstance selected;EntryLease active;bool paused;
        internal CostarInstance Selected {get{lock(gate)return selected;}}
        internal bool Busy {get{lock(gate)return active!=null;}}
        internal string Owner {get{lock(gate)return active==null?"":active.Owner;}}
        internal bool MobilePaused {get{lock(gate)return paused;}set{lock(gate)paused=value;}}
        internal void Select(CostarInstance target) {lock(gate){Order.Require(active==null,"Wait for the current entry to finish before changing COSTAR.");selected=target;}}
        internal EntryLease TryBegin(string owner,bool mobile) {
            lock(gate) {
                if(active!=null || selected==null || (mobile&&paused))return null;
                active=new EntryLease(this,selected,owner);return active;
            }
        }
        internal void Release(EntryLease lease) {lock(gate){if(Object.ReferenceEquals(active,lease))active=null;}}
    }
    internal sealed class EntryLease:IDisposable {
        readonly EntryCoordinator coordinator;
        internal readonly CostarInstance Target;internal readonly string Owner;
        internal EntryLease(EntryCoordinator owner,CostarInstance target,string name){coordinator=owner;Target=target;Owner=name;}
        public void Dispose(){coordinator.Release(this);}
    }
    internal sealed class CostarInputLock:IDisposable {
        internal const string Name=@"Local\TempeCostarAutofill_v01";
        readonly Mutex mutex;bool held;
        internal CostarInputLock() {
            mutex=new Mutex(false,Name);
            try {
                try{held=mutex.WaitOne(0);}catch(AbandonedMutexException){held=true;}
                Order.Require(held,"Another COSTAR helper is entering data or the old standalone autofill is open. Close the old helper and try again.");
            } catch {mutex.Dispose();throw;}
        }
        public void Dispose(){if(held){held=false;mutex.ReleaseMutex();}mutex.Dispose();}
        internal static bool LegacyOpen(){Mutex m;try{if(Mutex.TryOpenExisting(Name,out m)){m.Dispose();return true;}}catch(UnauthorizedAccessException){return true;}return false;}
    }
}
