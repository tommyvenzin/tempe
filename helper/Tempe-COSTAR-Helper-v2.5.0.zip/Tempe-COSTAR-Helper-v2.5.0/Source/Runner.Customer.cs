// The entry engine, part 2 of 4: the customer lookup, COSTAR's account list and Search window,
// the header fields, Time in, Ship Via and the delivery panel.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed partial class Runner {
        // A phone with two or more COSTAR accounts opens COSTAR's customer "Search" list
        // (seen on 3 Oct: a WinForms form with a results grid and Add new, Include Inactive,
        // Print Results, Search, Cancel, OK and Clear). OK stays unusable until a row is
        // highlighted. Take the first account: highlight the top row of the results grid
        // (accessibility first, a click on that row if needed), wait for OK, press OK.
        // Cancel, Add new, Search, Clear and Print are never pressed, and a new customer is
        // never created once this list was shown. An unfamiliar list stops with a capture.
        bool TryChooseFirstAccount(IntPtr front,List<ControlInfo> popup) {
            if(popup==null || front==root || Native.Pid(front)!=pid) return false;
            var kind=Selectors.AccountChooser(Native.Class(front),popup);
            if(!kind.IsChooser) return false;
            if(chooserAttempts==0) { Diag.Popup(front,popup); try { Dump("account-chooser-controls",popup); } catch(IOException) { } }
            Diag.EventRaw("account_chooser",kind.Reason+" accept="+(kind.Accept!=null)+" acceptEnabled="+(kind.Accept!=null&&Native.IsWindowEnabled(new IntPtr(kind.Accept.Handle)))+" listbox="+(kind.ListBox!=0)+" attempt="+(chooserAttempts+1));
            Order.Require(chooserAttempts<2,"The customer list did not close after choosing the first account. It is captured in the report; choose the customer in COSTAR, then retry.");
            chooserAttempts++;
            Check(false);
            Order.Require(Native.GetForegroundWindow()==front && IsCustomerPopup(front),"The customer list changed before the first account was chosen.");
            UIntPtr result;
            IntPtr okButton=kind.Accept==null?IntPtr.Zero:new IntPtr(kind.Accept.Handle);
            if(okButton!=IntPtr.Zero && !Native.IsWindowEnabled(okButton) && kind.ListBox==0) {
                // OK greyed out: COSTAR found nothing in Tempe. Search every branch (Tommy's steps).
                if(!SearchAllBranches(front,popup,okButton)) {
                    var cancel=popup.Where(c=>c.TextState=="read" && c.Class.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0 && Order.Norm(c.Text).Replace("&","")=="CANCEL").ToList();
                    Order.Require(cancel.Count==1 && Native.GetAncestor(new IntPtr(cancel[0].Handle),2)==front,"No account in any branch, and the search window's Cancel button was not found. Close it, then retry.");
                    Native.WriteMessage(new IntPtr(cancel[0].Handle),0xF5,UIntPtr.Zero,null,3,1000,out result); // BM_CLICK Cancel
                    var closing=Stopwatch.StartNew();
                    while(Native.IsWindow(front) && Native.IsWindowVisible(front) && closing.ElapsedMilliseconds<2500) Pause(25);
                    lookupCancelled=true;chooserClock.Restart();
                    Say("No account for this phone in any branch; entering the order's customer details.");
                    return true;
                }
            }
            sawChooser=true;lookupCancelled=false;
            if(kind.ListBox!=0) {
                var list=new IntPtr(kind.ListBox);
                if(Native.IsWindow(list) && Native.GetAncestor(list,2)==front) Native.WriteMessage(list,0x0186,UIntPtr.Zero,null,3,1000,out result); // LB_SETCURSEL row 0
            } else {
                string how=SelectFirstRow(front,kind.Accept==null?IntPtr.Zero:new IntPtr(kind.Accept.Handle));
                Diag.EventRaw("account_first_row",how);
            }
            if(kind.Accept!=null) {
                var button=new IntPtr(kind.Accept.Handle);string caption;
                var ready=Stopwatch.StartNew();
                while(!Native.IsWindowEnabled(button) && ready.ElapsedMilliseconds<1500) Pause(25);
                Order.Require(Native.GetAncestor(button,2)==front && Native.IsWindowEnabled(button) && Native.IsWindowVisible(button) &&
                    Native.TryText(button,out caption) && Order.Norm(caption)==Order.Norm(kind.Accept.Text),
                    "The customer list's OK button did not become available after selecting the first account. Nothing was pressed; the list is captured in the report.");
                Native.WriteMessage(button,0xF5,UIntPtr.Zero,null,3,1000,out result); // BM_CLICK
                Say("Two or more accounts share this phone: chose the first one ("+Order.Clean(kind.Accept.Text).Replace("&","")+").");
            } else {
                Order.Require(kind.EnterAllowed,"The customer list has no OK button and has buttons that could change data. Nothing was pressed; it is captured in the report.");
                Native.Key(13);Diag.Key();
                Say("Two or more accounts share this phone: chose the first one (Enter).");
            }
            var timer=Stopwatch.StartNew();
            while(Native.IsWindow(front) && Native.IsWindowVisible(front) && Native.GetForegroundWindow()==front && timer.ElapsedMilliseconds<2500) Pause(25);
            chooserClock.Restart();
            return true;
        }
        // 6 Oct (Tommy's video, TTW1730345): COSTAR's phone lookup only searches Tempe
        // (Branch 11). When the customer's accounts belong to other branches its "Search for
        // an Existing Customer" window opens with "Nothing found!" and OK greyed out. Done by
        // hand: the phone into that window's Phone box, its Branch box cleared, Search; the
        // accounts from every branch appear with row 1 highlighted and OK takes it.
        // Returns true when accounts were found (OK available), false when no branch has it.
        bool SearchAllBranches(IntPtr front,List<ControlInfo> popup,IntPtr ok) {
            var phoneBox=Selectors.FieldRightOf(popup,"PHONE");var branchBox=Selectors.FieldRightOf(popup,"BRANCH");
            var search=popup.Where(c=>c.TextState=="read" && c.Class.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0 && Order.Norm(c.Text).Replace("&","")=="SEARCH").ToList();
            Order.Require(phoneBox!=null && branchBox!=null && search.Count==1,"COSTAR's customer search window is not laid out as expected (Phone, Branch, Search). Nothing was changed; it is captured in the report.");
            string digits=Order.Phone(lookupPhone);
            Order.Require(digits.Length>=8,"The customer phone for the all-branch search is missing.");
            SetPopupText(front,phoneBox,digits,"the search window's Phone box");
            SetPopupText(front,branchBox,"","the search window's Branch box");
            Say("No account for this phone in this branch (Branch "+branch+"): searching every branch.");
            UIntPtr result;
            Native.WriteMessage(new IntPtr(search[0].Handle),0xF5,UIntPtr.Zero,null,3,1000,out result); // BM_CLICK Search
            var wait=Diag.Wait("customer_search_all_branches");
            try {
                var timer=Stopwatch.StartNew();
                while(timer.ElapsedMilliseconds<15000) {
                    wait.Tick();Check(false);
                    Order.Require(Native.IsWindow(front) && Native.IsWindowVisible(front),"COSTAR's customer search window closed during the all-branch search.");
                    if(Native.IsWindowEnabled(ok)) { wait.Done("accounts found");return true; }
                    if(timer.ElapsedMilliseconds>=800) {
                        var now=PopupSnapshot(front);
                        if(!lastSnapshotBusy && Selectors.NothingFound(now)) { wait.Done("none in any branch");return false; }
                    }
                    Pause(150);
                }
            } finally { wait.End(); }
            throw new InvalidOperationException("COSTAR's all-branch customer search did not finish within 15 s. Check the search window, then retry.");
        }
        void SetPopupText(IntPtr front,ControlInfo box,string value,string label) {
            var h=new IntPtr(box.Handle);UIntPtr result;string now;
            Order.Require(Native.IsWindow(h) && Native.GetAncestor(h,2)==front && Native.IsWindowEnabled(h),"COSTAR's search window changed before "+label+" could be set.");
            BeforeWrite();
            Order.Require(Native.WriteMessage(h,0xC,UIntPtr.Zero,value,3,1500,out result)!=IntPtr.Zero,"COSTAR did not accept "+label+".");
            Order.Require(Native.TryText(h,out now) && Order.Clean(now)==Order.Clean(value),"COSTAR did not keep "+label+".");
            writes++;Diag.Write(0,0);
        }
        // Tommy's rule (6 Oct): an order whose customer has a COSTAR customer number gets Ship
        // Via SHOP, entered as the last step. Deliveries keep their own Ship Via; a new
        // customer (no customer number) is left as it is. Never fatal.
        void SetShipViaShop() {
            var s=Current();
            var h=Selectors.Header(s);
            if(Order.Clean(ReadLive(h.Account)).Length==0) return;
            var box=Selectors.ShipVia(s);
            if(box==null) { Say("Ship Via box not found; enter SHOP by hand.");Diag.EventRaw("ship_via","box not found");return; }
            if(Order.Norm(ReadLive(box))=="SHOP") { Say("Ship Via already SHOP.");return; }
            PutMapped(box,"SHOP","Ship Via",true);
            Say("Entered Ship Via: SHOP (customer has a COSTAR customer number).");Diag.EventRaw("ship_via","SHOP");
        }
        // Highlights the first customer row of the list's results grid until OK lights up.
        // 5 Oct: the old version searched the list's panels smallest first, found the small
        // search-criteria panel (a table with no customer rows) and gave up there. Now every
        // grid-like panel is tried, largest first, then one level deeper; a row is selected
        // through accessibility and clicked near its left edge (row selector / first cell),
        // up to 3 top rows, stopping as soon as OK is enabled. On failure the grid's shape
        // (roles, counts, positions; never names or values) goes into the report.
        string SelectFirstRow(IntPtr front,IntPtr ok) {
            var grids=new List<KeyValuePair<IntPtr,int>>();
            Native.EnumChildWindows(front,delegate(IntPtr h,IntPtr unused) {
                Native.Rect r;
                if(Native.IsWindowVisible(h) && Native.Class(h).IndexOf("WindowsForms10.Window",StringComparison.OrdinalIgnoreCase)>=0 && Native.GetWindowRect(h,out r)) {
                    int w=r.Right-r.Left,hh=r.Bottom-r.Top;
                    if(w>=200 && hh>=60) grids.Add(new KeyValuePair<IntPtr,int>(h,w*hh));
                }
                return grids.Count<200;
            },IntPtr.Zero);
            var shapes=new List<string>();
            var ordered=grids.OrderByDescending(x=>x.Value).Take(20).Select(x=>x.Key).ToList();
            for(int depth=1;depth<=2;depth++) {
                foreach(var grid in ordered) {
                    Accessibility.IAccessible client=null,table=null;List<Msaa.Row> rows=null;
                    try {
                        client=Msaa.FromWindow(grid);
                        table=Msaa.Role(client)==Msaa.RoleTable?client:Msaa.FindTable(client,depth);
                        if(table==null) { if(depth==1 && shapes.Count<8) shapes.Add(WindowSize(grid)+" "+Msaa.Shape(client,8)); continue; }
                        rows=Msaa.TopRows(table,3);
                        if(rows.Count==0) { if(shapes.Count<8) shapes.Add(WindowSize(grid)+" table without rows "+Msaa.Shape(table,10)); continue; }
                        int tried=0;
                        foreach(var row in rows) {
                            tried++;
                            Msaa.SelectChild(table,row.Child);Pause(120);
                            if(ok!=IntPtr.Zero && Native.IsWindowEnabled(ok)) return "row "+tried+" selected";
                            if(row.Width>0 && row.Height>0) {
                                var point=new Native.Point{X=row.Left+Math.Min(40,Math.Max(4,row.Width/4)),Y=row.Top+row.Height/2};
                                IntPtr hit=Native.WindowFromPoint(point);
                                if(hit!=IntPtr.Zero && (hit==front || Native.GetAncestor(hit,2)==front)) { Native.Click(point);Diag.Click(); }
                            }
                            var wait=Stopwatch.StartNew();
                            while(ok!=IntPtr.Zero && !Native.IsWindowEnabled(ok) && wait.ElapsedMilliseconds<700) Pause(30);
                            if(ok==IntPtr.Zero || Native.IsWindowEnabled(ok)) return "row "+tried+" selected and clicked";
                        }
                        if(shapes.Count<8) shapes.Add(WindowSize(grid)+" rows tried "+tried+", OK still off "+Msaa.Shape(table,10));
                    } catch(Exception e) {
                        if(shapes.Count<8) shapes.Add(WindowSize(grid)+" "+e.GetType().Name);
                    } finally {
                        if(rows!=null) foreach(var row in rows) Msaa.Release(row.Child);
                        if(!Object.ReferenceEquals(table,client)) Msaa.Release(table);
                        Msaa.Release(client);
                    }
                }
            }
            Diag.EventRaw("account_grid_shape",String.Join(" || ",shapes));
            return "no customer row found";
        }
        static string WindowSize(IntPtr h) { Native.Rect r; return Native.GetWindowRect(h,out r)?(r.Right-r.Left)+"x"+(r.Bottom-r.Top):"?"; }
        bool CustomerPopup(IntPtr front,List<ControlInfo> controls) {
            if(front==root || controls==null || !Selectors.CustomerNotFoundNotice(controls)) return false;
            Check(false); Order.Require(Native.GetForegroundWindow()==front && Native.Pid(front)==pid && Native.IsWindowVisible(front),"Customer popup changed.");
            Native.Key(27);Diag.Key();var timer=Stopwatch.StartNew();
            while(Native.IsWindowVisible(front) && Native.GetForegroundWindow()==front && timer.ElapsedMilliseconds<1500)Pause(25);
            Order.Require(!Native.IsWindowVisible(front) || Native.GetForegroundWindow()!=front,"The Customer Not found notice did not close after Escape.");
            Say("Dismissed Customer Not found.");return true;
        }
        bool IsCustomerPopup(IntPtr window) {
            if(window==IntPtr.Zero || window==root || !Native.IsWindowVisible(window) || Native.Caption(window).StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase)) return false;
            var owner=window;
            for(int i=0;i<16 && owner!=IntPtr.Zero;i++) {
                owner=Native.GetWindow(owner,4); // GW_OWNER
                if(owner==root) return true;
            }
            // Existing COSTAR main windows must never receive a Close request.
            return Native.Pid(window)==pid && !originalWindows.Contains(window.ToInt64());
        }
        List<ControlInfo> PopupSnapshot(IntPtr window) {
            try { return Snapshot(window); }
            catch(InvalidOperationException) {
                if(!Native.IsWindow(window) || Native.GetForegroundWindow()!=window) return null;
                throw;
            }
        }
        void RecoverCustomerUi(IntPtr front,List<ControlInfo> popup,List<ControlInfo> snapshot) {
            Check(false);
            if(Native.GetForegroundWindow()!=front) return;
            if(IsCustomerPopup(front)) {
                popup=popup??PopupSnapshot(front);
                if(popup==null) return;
                CaptureForegroundWindow("Customer popup recovery");
                if(Native.GetForegroundWindow()!=front || !IsCustomerPopup(front)) return;
                if(Native.Pid(front)==pid && CustomerPopup(front,popup)) { lookupCancelled=true;return; }
                if(TryChooseFirstAccount(front,popup)) return;
                int stage;popupCloseStages.TryGetValue(front.ToInt64(),out stage);
                Order.Require(stage<3 && recoveryActions<8,"The customer popup did not close. Close it in COSTAR and check the partial order before retrying.");
                Check(false);
                Order.Require(Native.GetForegroundWindow()==front && IsCustomerPopup(front),"Customer popup changed before cancellation.");
                var button=Selectors.CustomerCancelButton(popup); UIntPtr result;
                if(stage==0 && button!=null) {
                    var handle=new IntPtr(button.Handle);string caption;
                    Order.Require(Native.GetAncestor(handle,2)==front && Native.IsWindowEnabled(handle) && Native.IsWindowVisible(handle) && Native.TryText(handle,out caption) && Order.Norm(caption)==Order.Norm(button.Text),"The popup Cancel/Close button changed.");
                    Native.WriteMessage(handle,0xF5,UIntPtr.Zero,null,3,1000,out result); // BM_CLICK on Cancel/Close only
                    Say("Requested "+Order.Clean(button.Text).Replace("&","")+" on the customer popup.");
                } else if(stage<2) {
                    Native.Key(27);Diag.Key();Say("Sent Escape to cancel the customer popup.");
                } else {
                    // Normal title-bar Close; never destroy/disable a window or confirm OK/Yes.
                    Native.WriteMessage(front,0x10,UIntPtr.Zero,null,3,1000,out result);
                    Say("Requested Close on the customer popup.");
                }
                popupCloseStages[front.ToInt64()]=stage+1;recoveryActions++;lookupCancelled=true;
                Pause(400);return;
            }
            if(front!=root) {
                if(front==IntPtr.Zero) { Pause(150);return; }
                CaptureForegroundWindow("Customer lookup focus changed");
                Order.Require(!restoredCustomerFocus && Native.IsWindowEnabled(root),"Another window is blocking COSTAR. Its title/process are in the report. Close it and check the partial order before retrying.");
                restoredCustomerFocus=true;Native.BringToFront(root);
                Say("Returning to the original Repair Order after the customer lookup lost focus.");Pause(350);return;
            }
            if(Selectors.CustomerSearchInProgress(snapshot)) {
                Order.Require(Native.IsWindowEnabled(root) && searchCancelAttempts<2 && recoveryActions<8,"COSTAR's search did not cancel. Close the search and check the partial order before retrying.");
                Dump("cancel-search-controls",snapshot);
                Check(false);Order.Require(Native.GetForegroundWindow()==root,"COSTAR changed before cancelling its search.");
                Native.Key(27);Diag.Key();searchCancelAttempts++;recoveryActions++;lookupCancelled=true;
                Say("Sent Escape to cancel the customer search; checking that the Repair Order is editable.");Pause(400);
            }
        }
        void CustomerFormReady(int quietMilliseconds) {
            var wait=Diag.Wait("customer_form_ready");
            try {
            var timer=Stopwatch.StartNew();var quiet=Stopwatch.StartNew();string previous=null;
            while(timer.ElapsedMilliseconds<CustomerLookupTimeoutMs) {
                wait.Tick();Check(false);var front=Native.GetForegroundWindow();
                var snapshot=Snapshot(root);
                if(lastSnapshotBusy) { previous=null;quiet.Restart();Pause(150);continue; }
                if(front!=Native.GetForegroundWindow()) { quiet.Restart();Pause(40);continue; }
                bool searching=Selectors.CustomerSearchInProgress(snapshot);
                if(front!=root || searching) {
                    previous=null;quiet.Restart();
                    if(timer.ElapsedMilliseconds>=(front!=root?750:SearchPatienceMs)) RecoverCustomerUi(front,null,snapshot);
                    Pause(searching?120:50);continue;
                }
                if(!Native.IsWindowEnabled(root)) { previous=null;quiet.Restart();Pause(40);continue; }
                try {
                    var m=Selectors.Header(snapshot);
                    string signature=m.Account.Value+"|"+m.Name.Value+"|"+m.Phone.Value;
                    if(signature!=previous) { previous=signature;quiet.Restart(); }
                    if(quiet.ElapsedMilliseconds>=quietMilliseconds) {wait.Done("ok");return;}
                } catch(InvalidOperationException) { previous=null;quiet.Restart(); }
                Pause(40);
            }
            wait.Done("timeout");
            throw new InvalidOperationException("COSTAR did not return to an editable customer form after popup recovery. Close the remaining popup and retry on an empty Repair Order.");
            } finally {wait.End();}
        }
        bool LookupCustomer() {
            var wait=Diag.Wait("customer_lookup");
            try {
            int stable=0;string previous=null;var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<CustomerLookupTimeoutMs) {
                wait.Tick();Check(false);var front=Native.GetForegroundWindow();var snapshot=Snapshot(root);
                if(lastSnapshotBusy) { stable=0;Pause(150);continue; }
                if(front!=Native.GetForegroundWindow()) { stable=0;Pause(40);continue; }
                List<ControlInfo> popup=IsCustomerPopup(front)?PopupSnapshot(front):null;
                if(front!=Native.GetForegroundWindow()) { stable=0;Pause(40);continue; }
                if(popup!=null && Native.Pid(front)==pid && CustomerPopup(front,popup)) { lookupCancelled=true;stable=0;continue; }
                if(popup!=null && TryChooseFirstAccount(front,popup)) { stable=0;previous=null;continue; }
                bool searching=Selectors.CustomerSearchInProgress(snapshot) || (popup!=null && Selectors.CustomerSearchInProgress(popup));
                if(front!=root || searching || !Native.IsWindowEnabled(root)) {
                    stable=0;
                    int patience=front!=root?750:searching?SearchPatienceMs:3000;
                    if(timer.ElapsedMilliseconds>=patience) RecoverCustomerUi(front,popup,snapshot);
                    Pause(searching?120:50);continue;
                }
                FieldMap m;
                // An existing customer's account makes COSTAR rebuild the customer panel.
                // Missing labels during that redraw are transient: keep waiting.
                try { m=Selectors.Header(snapshot); }
                catch(InvalidOperationException) { stable=0;previous=null;Pause(60);continue; }
                string signature=m.Account.Value+"|"+m.Name.Value+"|"+m.Phone.Value;
                stable=signature==previous?stable+1:1;previous=signature;
                if(stable>=2) {
                    if(CustomerEntry.HasMatch(m.Account.Value,m.Name.Value,m.Phone.Value,order.customer.phone)){wait.Done(sawChooser?"existing-customer-first-of-several":"existing-customer");return true;}
                    if(sawChooser) {
                        // The first account was chosen from the list: give COSTAR time to load it.
                        Order.Require(chooserClock.ElapsedMilliseconds<5000,"The first account was chosen from the list, but COSTAR did not load an account with this phone. Choose it in COSTAR, then retry; the list is captured in the report.");
                        stable=0;previous=null;Pause(40);continue;
                    }
                    Order.Require(m.Account.Value.Length==0,"COSTAR selected an account whose phone does not match. Check the account before continuing.");
                    if(lookupCancelled || timer.ElapsedMilliseconds>=3000) {
                        Order.Require(CustomerEntry.LookupResolved(m.Account.Value,m.Name.Value,m.Phone.Value,order.customer.phone),"The customer phone changed during lookup recovery.");
                        wait.Done(lookupCancelled?"new-customer-after-popup":"new-customer-after-3s-wait");return false;
                    }
                }
                Pause(30);
            }
            wait.Done("timeout");
            throw new InvalidOperationException("Customer lookup did not return to an editable form. Check the popup and customer account.");
            } finally {wait.End();}
        }
        void CustomerField(Func<FieldMap,ControlInfo> selector,string value,string label,bool allowEmpty=false) {
            if(!allowEmpty && String.IsNullOrWhiteSpace(value)) return;
            value=Order.EntryText(value);
            Ready();var header=HeaderNow();
            if(verifiedCustomerAccount!=null)Order.Require(header.Account.Value==verifiedCustomerAccount &&
                (verifiedCustomerName==null || header.Name.Value==verifiedCustomerName),"The selected customer account/name changed while filling the header.");
            var c=selector(header);
            if(c.Value==Order.Clean(value)) return;
            Put(c,value,label,true); Ready(); ReadEquals(selector(HeaderNow()),value,label);
        }
        string ReadLive(ControlInfo c) {
            CheckTarget(c);string value;
            Order.Require(Native.TryText(new IntPtr(c.Handle),out value),"A mapped COSTAR field is not readable.");
            return Order.Clean(value);
        }
        void PutMapped(ControlInfo c,string value,string label,bool allowEmpty=false,bool lowerCase=false) {
            if(!allowEmpty && String.IsNullOrWhiteSpace(value))return;
            value=FieldText(value,lowerCase);Ready();
            if(ReadLive(c)==Order.Clean(value))return;
            Put(c,value,label,true,lowerCase);Ready();ReadEquals(c,value,label);
        }
        void GuardCustomer(FieldMap h) {
            Order.Require(ReadLive(h.Account)==verifiedCustomerAccount &&
                (verifiedCustomerName==null || ReadLive(h.Name)==verifiedCustomerName) &&
                Order.Phone(ReadLive(h.Phone))==Order.Phone(order.customer.phone),"The selected customer account/name/phone changed while filling the header.");
        }
        void FillOnlineHeader(bool existing) {
            // Header controls do not expand like grid rows. Map once, then check
            // each live HWND/parent/class and retained text rather than rereading
            // hundreds of unrelated grid controls for every field.
            var h=HeaderNow();var c=order.customer;GuardCustomer(h);
            if(!existing) {
                PutMapped(h.Name,c.name,"customer name");
                verifiedCustomerName=Order.Clean(Order.EntryText(c.name));
            }
            GuardCustomer(h);PutMapped(h.Email,c.email,"email",lowerCase:true);
            var fields=new[] {
                new {Field=h.Address,Value=c.streetAddress,Label="address",Clear=false},
                new {Field=h.Address2,Value=c.address2,Label="address line 2",Clear=!String.IsNullOrWhiteSpace(c.streetAddress)},
                new {Field=h.Suburb,Value=c.suburb,Label="suburb",Clear=false},
                new {Field=h.State,Value=c.state,Label="state",Clear=false},
                new {Field=h.Postcode,Value=c.postcode,Label="postcode",Clear=false},
                new {Field=h.PO,Value=order.orderId,Label="PO#",Clear=false},
                new {Field=h.Comment,Value=order.comment,Label="order comment",Clear=true}
            };
            foreach(var field in fields){GuardCustomer(h);PutMapped(field.Field,field.Value,field.Label,field.Clear);}
            GuardCustomer(h);
            if(!order.IsDelivery) SetTimeIn();
        }
        // Time in: COSTAR fills it with the moment the order was opened. For an online pickup
        // the booking time is what the workshop needs, so it goes in instead. Never fatal:
        // if COSTAR will not take it, the order is still finished and the log says so.
        void SetTimeIn() {
            string want=Order.TimeInText(order.pickupTime);
            if(want==null) return;
            var box=Selectors.TimeIn(Current());
            if(box==null) { Say("Time in box not found on this Repair Order; left as COSTAR set it.");Diag.EventRaw("time_in","box not found");return; }
            if(Order.ClockMinutes(ReadLive(box))==Order.ClockMinutes(want)) { Say("Time in already shows the booking time ("+want+").");return; }
            Put(box,want,"Time in",true);Ready();
            string now=ReadLive(box);
            if(Order.ClockMinutes(now)==Order.ClockMinutes(want)) { Say("Entered Time in: "+want+" (booking time).");Diag.EventRaw("time_in","set"); }
            else { Say("COSTAR did not keep Time in "+want+" (shows "+now+"). Set it by hand.");Diag.EventRaw("time_in","not kept"); }
        }
        void FillDelivery() {
            // Billing has already been committed; shipping is a separate panel.
            var d=order.shipping;var m=Selectors.Delivery(Current());
            PutMapped(m.Name,d.name,"delivery recipient",true);
            PutMapped(m.Address,d.streetAddress,"delivery street",true);
            PutMapped(m.Address2,d.address2,"delivery address line 2",true);
            PutMapped(m.Suburb,d.suburb,"delivery suburb",true);
            PutMapped(m.State,d.state,"delivery state",true);
            PutMapped(m.Postcode,d.postcode,"delivery postcode",true);
            PutMapped(m.Contact,d.contact,"delivery contact",true);
            PutMapped(m.BusinessPhone,d.businessPhone,"delivery business phone",true);
            PutMapped(m.MobilePhone,d.mobilePhone,"delivery mobile",true);
            PutMapped(m.Email,d.email,"delivery email",true,lowerCase:true);
            PutMapped(m.ShipVia,d.shipVia,"Ship Via",true);
            PutMapped(m.Instructions,d.instructions,"shipping instructions",true);
            Say("Billing and delivery panels filled separately.");
        }
    }
}
