// The RDP helper's eBay side (2.5.0): asks the desk PC for eBay orders, finds COSTAR Sydney
// (Branch 1) by itself, waits for a quiet moment, enters each order in a new Repair Order (left open
// for review) and reports back. Stopped attempts are remembered (encrypted) so a Retry continues in
// the same Repair Order only while nothing in it changed; an order entered once is never entered again.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    public sealed class EbayAttempt {
        public string orderNumber,lease,stopPrint,message,atUtc;
        public long window,processStart;public int processId,sessionId,branch;
        // typed: fields were written for this order; running: an entry was going (result unknown);
        // touched: this attempt's run wrote into its Repair Order (saved just before its first write).
        public bool typed,running,touched;
    }
    public sealed class EbayJournal {
        public List<EbayAttempt> attempts=new List<EbayAttempt>();
        // "order number|UTC time" of every eBay order this helper finished (newest last).
        public List<string> entered=new List<string>();
        // The last report the desk has not acknowledged yet.
        public EbayReport report;public int sequence;
    }
    // What to do with an order the desk hands over, given what this helper remembers about it.
    internal static class EbayAttempts {
        internal const string Fresh="fresh",Resume="resume",Reuse="reuse",Refuse="refuse";
        // alive: the attempt's Repair Order window still exists in the same COSTAR process.
        internal static string Decide(EbayAttempt attempt,bool fresh,bool alive,out string why) {
            why="";
            if(attempt==null||fresh) return Fresh;
            if(!attempt.typed) return alive?Reuse:Fresh;
            if(!alive) { why="eBay order "+attempt.orderNumber+" was partly entered in a Repair Order that is now closed (or COSTAR restarted). Check COSTAR Sydney: if the order is there, finish it and click Mark done by hand on the desk PC; if it is not, click Start again there.";return Refuse; }
            if(attempt.stopPrint==null) { why="The earlier attempt of eBay order "+attempt.orderNumber+" couldn't be recorded when it stopped, so its Repair Order isn't continued. Finish it in COSTAR Sydney and click Mark done by hand on the desk PC.";return Refuse; }
            return Resume;
        }
        // Whether an order handed over may be started at all, before COSTAR is touched; null if it may.
        // enteredAt: when this helper finished it before (null: never). deskTyped: the desk says it was
        // partly typed. Only Start again (Tommy, after checking COSTAR) passes the first rule.
        internal static string Refusal(string number,bool fresh,bool startAgain,bool deskTyped,EbayAttempt earlier,string enteredAt) {
            if(startAgain) return null;
            if(enteredAt!=null) return "Not entered twice: this helper already entered eBay order "+number+" ("+enteredAt+"). Check COSTAR Sydney, then click Mark done by hand on the desk PC (or Start again there if it is really not in COSTAR).";
            if(fresh&&earlier!=null&&earlier.typed) return "eBay order "+number+" was partly typed into a Repair Order before, so it isn't entered again as new. Check COSTAR Sydney, then on the desk PC: Retry (continues that Repair Order if nothing in it changed), Start again (a new Repair Order) or Mark done by hand.";
            if(!fresh&&earlier==null&&deskTyped) return "The desk says eBay order "+number+" was partly typed before, but this helper has no record of that Repair Order. Check COSTAR Sydney, then use Start again (a new Repair Order) or Mark done by hand on the desk PC.";
            return null;
        }
        internal static string Entered(EbayJournal j,string number) {
            if(j==null||j.entered==null) return null;
            var hit=j.entered.LastOrDefault(e=>e.StartsWith(number+"|",StringComparison.Ordinal));
            return hit==null?null:hit.Substring(number.Length+1);
        }
    }
    internal sealed class EbayEngine : IDisposable {
        readonly EntryCoordinator coordinator;readonly WorkerSettings settings;readonly string journalPath;readonly object gate=new object();readonly Action<string> log;
        EbayJournal state;volatile Runner runner;volatile bool disposed,busy;int started;
        internal volatile bool Enabled;
        internal const int QuietSeconds=10;
        internal volatile string Connection="Desk PC: connecting ...",Detail="eBay orders are off. Click Start eBay orders.",Current="",LastLine="",LastReport="";
        volatile int lastContactTick;internal volatile int RoundTripMs=-1;
        internal int SecondsSinceContact { get { int t=lastContactTick;return t==0?-1:unchecked(Environment.TickCount-t)/1000; } }
        volatile HttpWebRequest pending;volatile bool interrupted;readonly AutoResetEvent wake=new AutoResetEvent(false);
        readonly Stopwatch progressClock=Stopwatch.StartNew();
        // COSTAR Sydney, found again at most every 3 s (a window scan).
        CostarInstance target;DateTime targetAt=DateTime.MinValue;string targetDetail="";
        internal bool Busy {get{return busy;}}
        // Why the Online orders tab is typing or about to (set by the window), null when it isn't;
        // eBay orders wait meanwhile.
        internal Func<string> OnlineWaiting;
        internal int Branch {get{int b=AppSettings.Current.ebayBranch;return b>0?b:1;}}
        internal CostarInstance Target {get{return target;}}
        internal EbayEngine(WorkerSettings config,string folder,Action<string> notify,EntryCoordinator entries) {
            coordinator=entries;NetworkRules.Worker(config);settings=config;log=notify;journalPath=Path.Combine(folder,"ebay-journal.dat");
            try { state=PrivateFiles.Load<EbayJournal>(journalPath); }
            catch(Exception e) {
                try{File.Copy(journalPath,journalPath+".unreadable-"+DateTime.Now.ToString("yyyyMMdd-HHmmss"),true);}catch(Exception){}
                AppLog.Note("ebay_journal_unreadable",e.GetType().Name);state=null;
            }
            // A new journal counts its reports on from the time, so they always come after any earlier
            // journal's (the desk compares them; see EbayHello.sequence).
            if(state==null) state=new EbayJournal {sequence=(int)Math.Min(Int32.MaxValue/2,Math.Max(0,(DateTime.UtcNow-new DateTime(2026,1,1,0,0,0,DateTimeKind.Utc)).TotalSeconds))};
            if(state.attempts==null) state.attempts=new List<EbayAttempt>();
            if(state.entered==null) state.entered=new List<string>();
            // An entry that was going when the helper closed: its result is unknown.
            var lost=state.attempts.FirstOrDefault(a=>a.running);
            if(lost!=null) {
                // Typed by that run (touched): its stop print no longer describes the Repair Order. Not
                // touched: what was recorded before it (an earlier stop, or nothing typed) still holds.
                foreach(var a in state.attempts.Where(a=>a.running)) { a.running=false;if(a.touched){a.typed=true;a.stopPrint=null;}a.message="The helper closed while entering this order."; }
                Report(lost.orderNumber,lost.lease,"failed","The RDP helper closed while entering this eBay order. Check COSTAR Sydney: if it is there, finish it and click Mark done by hand on the desk PC; if not, click Start again there.","",lost.typed);
            }
            Enabled=AppSettings.Current.ebayOn;
        }
        void Save() { lock(gate) PrivateFiles.Save(journalPath,state); }
        EbayAttempt Attempt(string number) { lock(gate) return state.attempts.FirstOrDefault(a=>a.orderNumber==number); }
        void Remember(EbayAttempt attempt) {
            lock(gate) {
                state.attempts.RemoveAll(a=>a.orderNumber==attempt.orderNumber);state.attempts.Add(attempt);
                while(state.attempts.Count>50) state.attempts.RemoveAt(0);
                Save();
            }
        }
        void Forget(string number) { lock(gate) { if(state.attempts.RemoveAll(a=>a.orderNumber==number)>0) Save(); } }
        // Under gate: the next report (the desk acknowledges it by its sequence).
        void SetReport(string number,string lease,string status,string message,string progress,bool typed) {
            state.sequence++;
            state.report=new EbayReport {orderNumber=number,lease=lease,status=status,message=EbayText.Clean(message,2000),progress=EbayText.Clean(progress,1000),sequence=state.sequence,typed=typed};
        }
        void Report(string number,string lease,string status,string message,string progress,bool typed) {
            lock(gate) { SetReport(number,lease,status,message,progress,typed);Save(); }
            if(status!="entering"||(progress??"").Length==0) { Detail=message;log(message); }
            Interrupt();
        }
        // A claim this helper can't start now goes back in line on the desk with the reason (sent
        // with the next poll; if that is lost, the claim comes back and is declined again).
        volatile string declineLease,declineReason;
        void Decline(string lease,string why) {
            declineReason=EbayText.Clean(why,400);declineLease=lease;
            if(Detail!=why) { Detail=why; }
            Interrupt();
        }
        internal void Start() {
            if(disposed) return;
            if(!AppSettings.Current.ebayOn){AppSettings.Current.ebayOn=true;AppSettings.Current.Save();}
            bool was=Enabled;Enabled=true;AppLog.Note("ebay_start","");Connect();if(!was)Interrupt();
        }
        // persist: the eBay orders switch itself (Stop eBay orders). Stop all entry only pauses.
        internal void Stop(bool persist) {
            if(persist&&AppSettings.Current.ebayOn){AppSettings.Current.ebayOn=false;AppSettings.Current.Save();}
            bool was=Enabled;Enabled=false;var active=runner;if(active!=null)active.Cancel=true;
            if(was){AppLog.Note("ebay_stop",persist?"switched off":"stop all");Interrupt();}
        }
        internal void Connect(){if(disposed)return;if(Interlocked.Exchange(ref started,1)!=0)return;var t=new Thread(Loop);t.IsBackground=true;t.Start();}
        void Interrupt(){interrupted=true;var r=pending;if(r!=null){try{r.Abort();}catch(Exception){}}wake.Set();}
        // COSTAR Sydney: exactly one COSTAR of the eBay branch in this session (never Order Check's
        // WIP window). Null with the reason when there is none or more than one.
        CostarInstance FindTarget(out string detail) {
            if(DateTime.UtcNow-targetAt<TimeSpan.FromSeconds(3)) { detail=targetDetail;return target; }
            CostarInstance found=null;
            try {
                var mine=CostarWindows.Choices().Where(c=>c.Branch==Branch&&!OrderCheckLink.IsWipWindow(c)).ToList();
                if(mine.Count==1) { found=mine[0];detail="COSTAR "+found.Label+" ready"; }
                else detail=mine.Count==0?"COSTAR Branch "+Branch+" (Sydney) is not open in this Remote Desktop session":mine.Count+" COSTARs of Branch "+Branch+" are open: close all but one";
            } catch(Exception e) { detail=e.Message; }
            // Keep the same instance object while it is the same COSTAR, so Same() checks hold.
            if(found!=null&&target!=null&&found.Same(target)) found=target;
            target=found;targetDetail=detail;targetAt=DateTime.UtcNow;return found;
        }
        // Whether an eBay order may start now, and why not.
        bool Available(out string detail) {
            if(coordinator.Busy) { detail=coordinator.Owner+" is filling COSTAR";return false; }
            var online=OnlineWaiting;string onlineWhy=null;
            try { onlineWhy=online==null?null:online(); } catch(Exception) { onlineWhy=null; }
            if(onlineWhy!=null) { detail="Waiting: "+onlineWhy;return false; }
            if(CostarInputLock.LegacyOpen()) { detail="Close the original online-order helper";return false; }
            var t=FindTarget(out detail);
            if(t==null) return false;
            if(Native.UserActiveWithin(QuietSeconds*1000)) { detail="Waiting for a quiet moment: someone is using the COSTAR PC";return false; }
            return true;
        }
        EbayReply Request(EbayHello hello) {
            var request=(HttpWebRequest)WebRequest.Create(settings.baseUrl.TrimEnd('/')+"/api/worker/v1/ebay");
            request.Method="POST";request.ContentType="application/json";request.Headers["Authorization"]="Bearer "+settings.token;request.AllowAutoRedirect=false;request.Proxy=null;
            request.Timeout=8000+hello.waitMs;request.ReadWriteTimeout=8000+hello.waitMs;request.ServicePoint.Expect100Continue=false;
            request.ServerCertificateValidationCallback=delegate(object sender,X509Certificate cert,X509Chain chain,System.Net.Security.SslPolicyErrors errors) {
                if(cert==null)return false;using(var c=new X509Certificate2(cert))return DateTime.Now>=c.NotBefore&&DateTime.Now<=c.NotAfter&&Wire.Equal(Wire.Hash(c.RawData),settings.certificateHash);
            };
            byte[] bytes=Encoding.UTF8.GetBytes(Wire.Json(hello));request.ContentLength=bytes.Length;
            pending=request;
            try {
                using(var output=request.GetRequestStream())output.Write(bytes,0,bytes.Length);
                try {using(var response=request.GetResponse())using(var input=response.GetResponseStream())using(var reader=new StreamReader(input,Encoding.UTF8))return Wire.Read<EbayReply>(reader.ReadToEnd());}
                catch(WebException e) {
                    if(e.Response!=null)using(var input=e.Response.GetResponseStream())using(var reader=new StreamReader(input)) {
                        string body=reader.ReadToEnd();
                        var code=((HttpWebResponse)e.Response).StatusCode;
                        // A desk older than 2.5.0 answers this route with "key invalid" (401).
                        if(code==HttpStatusCode.NotFound||code==HttpStatusCode.Unauthorized) throw new InvalidOperationException("The desk receiver did not take the eBay request ("+(int)code+"). Update the desk receiver to 2.5.0 (yellow line on the desk PC); if it already is, pair this RDP helper with the desk again.");
                        throw new InvalidOperationException("Receiver rejected the request: "+body);
                    }
                    throw;
                }
            } finally { pending=null; }
        }
        void Loop() {
            while(!disposed) {
                bool held=false;
                try {
                    string detail;bool accepting=Enabled,available=false;
                    if(!accepting) detail="eBay orders switched off on the RDP helper";
                    else if(busy) detail="Entering an eBay order";
                    else available=Available(out detail);
                    // The order being entered is read BEFORE the report: an entry's last report is saved
                    // before it lets go of its lease, so the desk never sees "not entering" without it.
                    string working=runLease??"";
                    EbayReport report;int sequence;lock(gate){report=state.report==null?null:Wire.Copy(state.report);sequence=state.sequence;}
                    string declined=declineLease,declinedWhy=declineReason;
                    int waitMs=accepting&&!busy&&declined==null&&AppSettings.Current.longPoll?(available?8000:2000):0;
                    var clock=Stopwatch.StartNew();interrupted=false;
                    var reply=Request(new EbayHello {workerId=settings.workerId,accepting=accepting,available=available,detail=EbayText.Clean(detail,400),report=report,waitMs=waitMs,working=working,declined=declined,declineReason=declinedWhy,sequence=sequence});
                    if(declined!=null&&declineLease==declined){declineLease=null;declineReason=null;}
                    held=reply!=null&&reply.held;
                    int waited=reply==null?0:Math.Max(0,reply.waitedMs);
                    RoundTripMs=(int)Math.Max(0,clock.ElapsedMilliseconds-waited);lastContactTick=Environment.TickCount==0?1:Environment.TickCount;
                    Connection="Desk PC connected";if(!busy)Detail=detail;
                    if(reply!=null&&report!=null&&reply.ack==report.sequence) lock(gate) { if(state.report!=null&&state.report.sequence==report.sequence){state.report=null;try{Save();}catch(Exception){}} }
                    // Switched off meanwhile: the order goes back in line. While busy, a handed-back claim
                    // can only be the order being entered (one at a time): it is never declined.
                    if(reply!=null&&reply.command=="enter"&&!busy&&!disposed) {
                        if(Enabled) Accept(reply);
                        else if(!String.IsNullOrEmpty(reply.lease)&&reply.lease!=lastStartedLease) Decline(reply.lease,"eBay orders switched off on the RDP helper");
                    }
                } catch(Exception e) {
                    if(disposed) break;
                    if(interrupted){interrupted=false;continue;}
                    Connection="Desk PC not reachable: "+e.Message;AppLog.PollError("ebay: "+e.Message);
                }
                if(!disposed){int ms=held?100:Enabled?2000:3000;wake.WaitOne(ms);}
            }
        }
        // The lease of the last order this helper started: a claim the desk hands back again before it
        // has the result (a run that stopped early) is never started a second time.
        volatile string lastStartedLease;
        void Accept(EbayReply reply) {
            Order.Require(reply.order!=null&&!String.IsNullOrWhiteSpace(reply.lease),"The desk omitted the eBay order.");
            if(reply.lease==lastStartedLease) return;
            string number=reply.order.orderNumber??"";
            try { reply.order.Validate(); }
            catch(InvalidOperationException e) { Report(number,reply.lease,"failed","Not entered: "+e.Message,"",false);return; }
            string when;EbayAttempt earlier;lock(gate){when=EbayAttempts.Entered(state,number);earlier=state.attempts.FirstOrDefault(a=>a.orderNumber==number);}
            string refusal=EbayAttempts.Refusal(number,reply.fresh,reply.startAgain,reply.status!=null&&reply.status.typed,earlier,when==null?null:When(when));
            // Typed as far as anyone here knows: the desk's Start again dialog then warns.
            if(refusal!=null) { Report(number,reply.lease,"failed",refusal,"",when!=null||(earlier!=null&&earlier.typed)||(reply.status!=null&&reply.status.typed));AppLog.Note("ebay_refused",number+" "+refusal);return; }
            // The quiet moment and the other tabs are checked again now: the desk may have held this
            // poll for seconds, or handed back an earlier claim.
            string detail;
            if(!Available(out detail)) { Decline(reply.lease,detail);return; }
            var t=FindTarget(out detail);
            if(t==null) { Decline(reply.lease,detail);return; }
            var entry=coordinator.TryBegin("eBay order",t);
            if(entry==null) { Decline(reply.lease,(coordinator.Owner??"Another entry")+" is filling COSTAR");return; }
            bool startedThread=false,claimed=false;
            try {
                lock(gate) {
                    if(busy||disposed) return;
                    if(!Enabled) { Decline(reply.lease,"eBay orders switched off on the RDP helper");return; }
                    // From here every poll says this order is being worked on (working = its lease).
                    busy=true;claimed=true;runNumber=number;runLease=reply.lease;lastStartedLease=reply.lease;
                }
                var thread=new Thread(delegate(){Run(reply,entry);});thread.IsBackground=true;thread.SetApartmentState(ApartmentState.STA);thread.Start();startedThread=true;
            } finally { if(!startedThread){if(claimed){runNumber=null;runLease=null;lastStartedLease=null;busy=false;}entry.Dispose();} }
        }
        static string When(string utc) {
            DateTime at;
            return DateTime.TryParse(utc,CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out at)?at.ToLocalTime().ToString("ddd d MMM, HH:mm",CultureInfo.InvariantCulture):utc;
        }
        // The order being entered and its lease, for progress reports (at most one every 2.5 s).
        volatile string runNumber,runLease;volatile bool runTyped;
        void Progress(string message) {
            log(message);Detail=message;
            if(progressClock.ElapsedMilliseconds<2500) return;
            progressClock.Restart();
            var r=runner;string number=runNumber,lease=runLease;
            if(number==null||lease==null) return;
            try { Report(number,lease,"entering",message,message,runTyped||(r!=null&&r.Writes>0)); } catch(Exception) { }
        }
        void Run(EbayReply reply,EntryLease entry) {
            CostarInputLock inputLock=null;var clock=Stopwatch.StartNew();var job=reply.order;string number=job.orderNumber;
            EbayAttempt attempt=null;IntPtr window=IntPtr.Zero;bool typedBefore=false;
            try {
                Current=job.Reference+"  ·  "+job.BuyerName+"  ·  $"+(job.totalCents/100m).ToString("0.00",CultureInfo.InvariantCulture);
                inputLock=new CostarInputLock();CostarWindows.Main(entry.Target);
                var earlier=Attempt(number);typedBefore=earlier!=null&&earlier.typed;
                // Start again: Tommy checked COSTAR. The earlier record of this order (finished or not)
                // is retired, so a Retry of this new attempt works like any other.
                if(reply.startAgain) lock(gate) { if(state.entered.RemoveAll(e=>e.StartsWith(number+"|",StringComparison.Ordinal))>0) Save(); }
                if(reply.fresh&&earlier!=null){Forget(number);log("Start again: the earlier attempt of "+number+" is set aside; a new Repair Order is used.");earlier=null;}
                bool alive=earlier!=null&&earlier.window!=0&&Native.IsWindow(new IntPtr(earlier.window))&&(int)Native.Pid(new IntPtr(earlier.window))==earlier.processId&&
                    earlier.processId==entry.Target.Pid&&earlier.processStart==entry.Target.Started&&Branches.OrderTitle(Native.Caption(new IntPtr(earlier.window)),entry.Target.Branch);
                string why;string plan=EbayAttempts.Decide(earlier,reply.fresh,alive,out why);
                Order.Require(plan!=EbayAttempts.Refuse,why);
                // Recorded before the desk hears anything: if the helper closes from here on, it reports
                // this order as stopped when it starts again (never left "being entered" on the desk).
                bool resume=plan==EbayAttempts.Resume;
                attempt=new EbayAttempt {orderNumber=number,lease=reply.lease,window=plan==EbayAttempts.Fresh?0:earlier.window,processId=entry.Target.Pid,processStart=entry.Target.Started,
                    branch=entry.Target.Branch,typed=resume&&earlier.typed,stopPrint=resume?earlier.stopPrint:null,running=true,atUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture)};
                Remember(attempt);
                runTyped=earlier!=null&&earlier.typed;progressClock.Restart();
                Report(number,reply.lease,"entering",resume?"Continuing in the Repair Order it stopped in":"Opening a Repair Order in COSTAR "+entry.Target.Label,"",runTyped);
                AppLog.Note("ebay_fill_start",number+" "+plan+(earlier!=null?" (earlier attempt "+(earlier.typed?"typed":"untyped")+")":""));
                coordinator.Progress.Begin("eBay order",job.Reference,6+job.Plan().Count);
                bool reopened=false;
                while(true) {
                    long openMs=-1;bool own=plan==EbayAttempts.Resume;
                    if(plan==EbayAttempts.Fresh) {
                        var openTimer=Stopwatch.StartNew();
                        window=CostarWindows.OpenNew(entry.Target,delegate{},delegate{return !Enabled||disposed;},true);
                        openMs=openTimer.ElapsedMilliseconds;AppLog.Note("ebay_add_new",number+" "+openMs+" ms");
                    } else window=new IntPtr(earlier.window);
                    ProcessIdentity identity;Order.Require(LocalProcess.IsNamed((int)Native.Pid(window),"COSTAR",out identity),"COSTAR changed while opening the order.");
                    attempt=new EbayAttempt {orderNumber=number,lease=reply.lease,window=window.ToInt64(),processId=(int)Native.Pid(window),processStart=identity.Started,sessionId=identity.Session,branch=entry.Target.Branch,
                        typed=earlier!=null&&earlier.typed&&own,stopPrint=own?earlier.stopPrint:null,running=true,atUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture)};
                    Remember(attempt);
                    runner=new Runner(entry.Target.Pid,entry.Target.Branch,job.EngineOrder(),"",false,Progress,window.ToInt64());
                    runner.OnStage=coordinator.Progress.Stage;
                    runner.FreshlyOpened=openMs>=0;if(openMs>=0)runner.Diag.OpenNewMs=openMs;
                    runner.OwnAttempt=own;runner.ResumePrint=own?earlier.stopPrint:null;
                    // Recorded just before the first field is written: a close from then on can't be
                    // taken for an untouched Repair Order.
                    runner.BeforeFirstWrite=delegate { if(attempt!=null&&!attempt.touched){attempt.touched=true;Remember(attempt);} };
                    runner.Cancel=!Enabled||disposed;
                    try { runner.RunEbay(job);break; }
                    catch(RepairOrderInUseException) {
                        // The earlier EMPTY Repair Order (nothing typed there) holds something now: leave
                        // it, open a new one. Never for a Repair Order this order was typed into.
                        if(reopened||plan!=EbayAttempts.Reuse) throw;
                        reopened=true;var used=runner;runner=null;try{used.Dispose();}catch(Exception){}
                        log("The earlier Repair Order is no longer empty; it is left untouched and a new one is opened.");
                        plan=EbayAttempts.Fresh;earlier=null;
                    }
                }
                string checks=runner.Checks.Count==0?"":" CHECK BY HAND: "+String.Join(" ",runner.Checks.ToArray());
                string done="In COSTAR "+entry.Target.Label+", ready for review (Repair Order left open)."+checks;
                // Entered and its report in one write: a close in between can't lose either.
                lock(gate) {
                    state.attempts.RemoveAll(a=>a.orderNumber==number);
                    state.entered.Add(number+"|"+DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture));
                    while(state.entered.Count>500) state.entered.RemoveAt(0);
                    SetReport(number,reply.lease,"ready_for_review",done,"",true);
                    Save();
                }
                Detail=done;log(done);Interrupt();
                LastLine=number+" in COSTAR"+(runner.Checks.Count>0?" (check by hand)":"")+" at "+DateTime.Now.ToString("HH:mm");
                coordinator.Progress.End(true,job.Reference+" ready for review");
                AppLog.Note("ebay_fill_ok",number+" in "+(clock.ElapsedMilliseconds/100/10.0).ToString("0.0",CultureInfo.InvariantCulture)+" s run="+runner.Diag.RunId+(runner.Checks.Count>0?" checks="+runner.Checks.Count:""));
            } catch(Exception e) {
                try{if(runner!=null)runner.Diag.Stopped(e);}catch{}
                bool typed=attempt==null&&typedBefore&&!reply.fresh;
                try {
                    var r=runner;
                    if(attempt!=null) {
                        // This run touched the Repair Order (typed, or checked it for a resume): its stop
                        // print counts. Otherwise the earlier one still describes it.
                        bool touched=r!=null&&(r.Writes>0||r.ResumeVerified);
                        typed=attempt.typed||touched;
                        attempt.running=false;attempt.typed=typed;attempt.stopPrint=touched?r.StopPrint:attempt.stopPrint;attempt.message=e.Message;
                        Remember(attempt);
                    }
                } catch(Exception persist) { Enabled=false;log("eBay orders stopped: the attempt could not be saved. "+persist.Message); }
                LastLine=number+" stopped at "+DateTime.Now.ToString("HH:mm");
                coordinator.Progress.End(false,job.Reference+" stopped: "+e.Message);
                AppLog.Note("ebay_fill_stopped",number+" "+e.Message+(runner!=null?" run="+runner.Diag.RunId:""));
                try { Report(number,reply.lease,"failed",e.Message,"",typed); } catch(Exception persist) { Enabled=false;log("eBay orders stopped: the result could not be saved. "+persist.Message); }
            } finally {
                try{var r=runner;if(r!=null){r.Dispose();LastReport=r.ZipPath;log("COSTAR report: "+r.ZipPath);}}
                catch(Exception e){log("Report cleanup failed: "+e.Message);}
                finally{runner=null;Current="";runNumber=null;runLease=null;try{if(inputLock!=null)inputLock.Dispose();}finally{busy=false;entry.Dispose();Interrupt();}}
            }
        }
        // Check Sydney layout (types nothing): one open, EMPTY Repair Order in COSTAR Sydney.
        internal string CheckLayout() {
            string detail;var t=FindTarget(out detail);
            Order.Require(t!=null,detail+".");
            var entry=coordinator.TryBegin("Layout check",t);
            Order.Require(entry!=null,"Wait for the current entry to finish, then check again.");
            Runner check=null;
            try {
                using(new CostarInputLock()) {
                    var orders=CostarWindows.Orders(t);
                    Order.Require(orders.Count==1,orders.Count==0?"Open a NEW, empty Repair Order in COSTAR "+t.Label+" (Add New), then click Check again.":"Leave just one Repair Order open in COSTAR "+t.Label+" (a new, empty one), then click Check again.");
                    check=new Runner(t.Pid,t.Branch,new Order {orderId="LAYOUT-CHECK",customer=new Customer {name="",phone=""},lines=new List<OrderLine>()},"",false,log,orders[0].ToInt64());
                    string text=check.CheckLayout();
                    AppLog.Note("ebay_layout_check",text.Replace("\r","").Replace("\n"," | "));
                    return text;
                }
            } finally {
                try{if(check!=null){check.Dispose();log("Layout report: "+check.ZipPath);}}catch(Exception){}
                entry.Dispose();
            }
        }
        public void Dispose(){disposed=true;Stop(false);}
    }
}
