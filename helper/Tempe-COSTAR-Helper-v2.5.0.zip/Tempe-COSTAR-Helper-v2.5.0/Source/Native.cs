// Win32 and accessibility calls used to read and drive COSTAR. No database access or Save/Sell action.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace TempeCostar {
    // Raised before any field is touched when the open Repair Order already holds another
    // job. The online tab then opens a fresh Repair Order and fills that instead.
    internal sealed class RepairOrderInUseException:InvalidOperationException {
        internal RepairOrderInUseException(string message):base(message){}
    }
    // Microsoft Active Accessibility, the way Tempe Order Check reads COSTAR's
    // Infragistics grids (proven on the RDP PC). Used here only to find and highlight
    // the first row of COSTAR's customer list.
    internal static class Msaa {
        [DllImport("oleacc.dll")] static extern int AccessibleObjectFromWindow(IntPtr hwnd,uint id,ref Guid iid,[MarshalAs(UnmanagedType.Interface)] out object acc);
        [DllImport("oleacc.dll")] static extern int AccessibleChildren(Accessibility.IAccessible parent,int start,int count,[Out] object[] children,out int obtained);
        internal const int RoleTable=24,RoleRow=28,RolePageTab=37;
        // An object's name (a tab's caption); "" when it has none or cannot be read.
        internal static string NameOf(Accessibility.IAccessible parent,object child) {
            try {
                var a=child as Accessibility.IAccessible;
                object n=a!=null?a.get_accName(0):parent.get_accName(child);
                return n as string ?? "";
            } catch(Exception) { return ""; }
        }
        // 2.5.0: page tabs with this name anywhere under root (breadth first, at most "budget"
        // objects, "depth" levels): each as {left, top, width, height} on the screen.
        internal static List<int[]> FindPageTabs(Accessibility.IAccessible root,string name,int depth,int budget) {
            var found=new List<int[]>();
            if(root==null) return found;
            string want=Order.Norm(name);
            var level=new List<Accessibility.IAccessible>{root};var owned=new List<Accessibility.IAccessible>();int seen=0;
            try {
                for(int d=0;d<depth&&level.Count>0&&seen<budget;d++) {
                    var next=new List<Accessibility.IAccessible>();
                    foreach(var parent in level) {
                        foreach(object child in Children(parent,64)) {
                            seen++;
                            var a=child as Accessibility.IAccessible;
                            if(a!=null) owned.Add(a);
                            if(RoleOf(parent,child)==RolePageTab && Order.Norm(NameOf(parent,child))==want) {
                                int l,t,w,h;if(LocationOf(parent,child,out l,out t,out w,out h)&&w>4&&h>4) found.Add(new[]{l,t,w,h});
                            } else if(a!=null && seen<budget) next.Add(a);
                            if(seen>=budget) break;
                        }
                        if(seen>=budget) break;
                    }
                    level=next;
                }
            } finally { foreach(var o in owned) Release(o); }
            return found;
        }
        internal static Accessibility.IAccessible FromWindow(IntPtr h) {
            Guid iid=new Guid("618736E0-3C3D-11CF-810C-00AA00389B71");object acc;
            int hr=AccessibleObjectFromWindow(h,0xFFFFFFFC,ref iid,out acc);
            if(hr!=0||acc==null) throw new InvalidOperationException("COSTAR did not answer the accessibility request.");
            return (Accessibility.IAccessible)acc;
        }
        internal static Accessibility.IAccessible Child(Accessibility.IAccessible parent,int oneBased) { object o=parent.get_accChild(oneBased); return o as Accessibility.IAccessible; }
        internal static int Count(Accessibility.IAccessible a) { return a.accChildCount; }
        internal static int Role(Accessibility.IAccessible a) { object r=a.get_accRole(0); return r is int?(int)r:-1; }
        internal static bool Location(Accessibility.IAccessible a,out int left,out int top,out int width,out int height) {
            left=0;top=0;width=0;height=0;
            try { a.accLocation(out left,out top,out width,out height,0); return true; } catch(Exception) { return false; }
        }
        internal static List<object> All(Accessibility.IAccessible parent,int count) {
            var list=new List<object>();
            if(count<=0) return list;
            var items=new object[count];int got;
            int hr=AccessibleChildren(parent,0,count,items,out got);
            if(hr<0) return list;
            for(int i=0;i<got;i++) list.Add(items[i]);
            return list;
        }
        internal static void Release(object o) {
            if(o!=null && Marshal.IsComObject(o)) { try { Marshal.ReleaseComObject(o); } catch(Exception) { } }
        }
        // Children of an object: IAccessible objects, or numbered "simple" children (ints).
        internal static List<object> Children(Accessibility.IAccessible parent,int max) {
            int n;
            try { n=Math.Min(Count(parent),max); } catch(Exception) { return new List<object>(); }
            var list=All(parent,n);
            if(list.Count>0 || n==0) return list;
            for(int i=1;i<=n;i++) {
                object o=null;
                try { o=parent.get_accChild(i); } catch(Exception) { o=null; }
                list.Add(o!=null?o:(object)i);
            }
            return list;
        }
        internal static int RoleOf(Accessibility.IAccessible parent,object child) {
            try {
                var a=child as Accessibility.IAccessible;
                object r=a!=null?a.get_accRole(0):parent.get_accRole(child);
                return r is int?(int)r:-1;
            } catch(Exception) { return -1; }
        }
        internal static bool LocationOf(Accessibility.IAccessible parent,object child,out int left,out int top,out int width,out int height) {
            left=0;top=0;width=0;height=0;
            try {
                var a=child as Accessibility.IAccessible;
                if(a!=null) a.accLocation(out left,out top,out width,out height,0);
                else parent.accLocation(out left,out top,out width,out height,child);
                return true;
            } catch(Exception) { return false; }
        }
        internal static void SelectChild(Accessibility.IAccessible parent,object child) {
            try { var a=child as Accessibility.IAccessible; if(a!=null) a.accSelect(3,0); else parent.accSelect(3,child); } // TAKEFOCUS|TAKESELECTION
            catch(Exception) { }
        }
        // A table (role 24) among the children of root, down to "depth" levels.
        internal static Accessibility.IAccessible FindTable(Accessibility.IAccessible root,int depth) {
            if(root==null || depth<=0) return null;
            foreach(object o in Children(root,16)) {
                var a=o as Accessibility.IAccessible;
                if(a==null) continue;
                bool keep=false;
                try {
                    if(Role(a)==RoleTable) { keep=true; return a; }
                    var inner=FindTable(a,depth-1);
                    if(inner!=null) return inner;
                } catch(Exception) {
                } finally { if(!keep) Release(a); }
            }
            return null;
        }
        internal sealed class Row { internal object Child; internal int Left,Top,Width,Height,Order; }
        // The data rows nearest the top of the grid (by screen position: the grid can list
        // its active row twice), skipping a column-header row. At most "take" rows.
        internal static List<Row> TopRows(Accessibility.IAccessible table,int take) {
            var rows=new List<Row>();int order=0;
            foreach(object o in Children(table,300)) {
                order++;
                if(RoleOf(table,o)!=RoleRow || IsHeaderRow(o)) { Release(o); continue; }
                var row=new Row{Child=o,Order=order};int l,t,w,h;
                if(LocationOf(table,o,out l,out t,out w,out h)) { row.Left=l;row.Top=t;row.Width=w;row.Height=h; }
                rows.Add(row);
            }
            var sorted=rows.Where(r=>r.Height>0).OrderBy(r=>r.Top).ThenBy(r=>r.Order).ToList();
            if(sorted.Count==0) sorted=rows.OrderBy(r=>r.Order).ToList();
            var keep=sorted.Take(take).ToList();
            foreach(var r in rows) if(!keep.Contains(r)) Release(r.Child);
            return keep;
        }
        // A header row's first child is a column header (role 25).
        static bool IsHeaderRow(object o) {
            var a=o as Accessibility.IAccessible;
            if(a==null) return false;
            foreach(object c in Children(a,1)) { int r=RoleOf(a,c); Release(c); return r==25; }
            return false;
        }
        // Shape only (roles, counts, positions), never names or values: for the report.
        internal static string Shape(Accessibility.IAccessible a,int maxChildren) {
            var b=new StringBuilder();
            try {
                b.Append("role=").Append(Role(a)).Append(" n=").Append(Count(a)).Append(" [");
                int i=0;
                foreach(object o in Children(a,maxChildren)) {
                    int l,t,w,h;bool placed=LocationOf(a,o,out l,out t,out w,out h);
                    b.Append(i++>0?" ":"").Append((o is Accessibility.IAccessible)?"o":"s").Append(RoleOf(a,o)).Append(placed?"@y"+t+"h"+h:"");
                    Release(o);
                }
                b.Append("]");
            } catch(Exception e) { b.Append(" error ").Append(e.GetType().Name); }
            return b.ToString();
        }
    }
    internal static class Native {
        internal delegate bool EnumProc(IntPtr h, IntPtr arg);
        [StructLayout(LayoutKind.Sequential)] internal struct Rect { public int Left,Top,Right,Bottom; }
        [StructLayout(LayoutKind.Sequential)] internal struct Point { public int X,Y; }
        [StructLayout(LayoutKind.Sequential)] internal struct GuiInfo { public int size; public uint flags; public IntPtr active,focus,capture,menu,move,caret; public Rect rect; }
        [StructLayout(LayoutKind.Sequential)] internal struct MouseInput { public int dx,dy; public uint data,flags,time; public UIntPtr extra; }
        [StructLayout(LayoutKind.Sequential)] internal struct KeyInput { public ushort key,scan; public uint flags,time; public UIntPtr extra; }
        [StructLayout(LayoutKind.Explicit)] internal struct InputUnion { [FieldOffset(0)] public MouseInput mouse; [FieldOffset(0)] public KeyInput key; }
        [StructLayout(LayoutKind.Sequential)] internal struct Input { public uint type; public InputUnion data; }
        [DllImport("user32.dll")] internal static extern bool EnumWindows(EnumProc fn,IntPtr arg);
        [DllImport("user32.dll")] internal static extern bool EnumChildWindows(IntPtr h,EnumProc fn,IntPtr arg);
        [DllImport("user32.dll")] internal static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
        [DllImport("user32.dll")] internal static extern bool IsWindow(IntPtr h);
        [DllImport("user32.dll")] internal static extern bool IsWindowVisible(IntPtr h);
        [DllImport("user32.dll")] internal static extern bool IsWindowEnabled(IntPtr h);
        [DllImport("user32.dll")] internal static extern bool IsIconic(IntPtr h);
        [DllImport("user32.dll")] internal static extern bool ShowWindow(IntPtr h,int how);
        [DllImport("user32.dll")] internal static extern bool SetForegroundWindow(IntPtr h);
        [DllImport("user32.dll")] static extern bool AttachThreadInput(uint from,uint to,bool attach);
        [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
        [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
        [DllImport("user32.dll")] static extern void SwitchToThisWindow(IntPtr h,bool altTab);
        [StructLayout(LayoutKind.Sequential)] struct LastInput { public uint cbSize, dwTime; }
        [DllImport("user32.dll")] static extern bool GetLastInputInfo(ref LastInput info);
        // Tick of the last click or key this helper sent itself.
        internal static volatile int LastSyntheticTick;
        // Windows only lets the app you are using change the active window. When an order
        // arrives while you work in Chrome, a plain SetForegroundWindow is refused and COSTAR
        // stays behind. Joining the active window's input queue for a moment lifts that limit.
        internal static bool BringToFront(IntPtr h) {
            if(IsIconic(h)) ShowWindow(h,9);
            if(GetForegroundWindow()==h) return true;
            SetForegroundWindow(h);
            if(GetForegroundWindow()==h) return true;
            IntPtr front=GetForegroundWindow();uint unused;
            uint frontThread=front==IntPtr.Zero?0:GetWindowThreadProcessId(front,out unused),me=GetCurrentThreadId();
            bool attached=frontThread!=0&&frontThread!=me&&AttachThreadInput(me,frontThread,true);
            try { BringWindowToTop(h);SetForegroundWindow(h); }
            finally { if(attached) AttachThreadInput(me,frontThread,false); }
            if(GetForegroundWindow()==h) return true;
            SwitchToThisWindow(h,true);
            for(int i=0;i<8 && GetForegroundWindow()!=h;i++) System.Threading.Thread.Sleep(25);
            return GetForegroundWindow()==h;
        }
        // True when a real person pressed a key or moved the mouse within the last ms
        // milliseconds (the helper's own clicks and keys do not count).
        internal static bool UserActiveWithin(int ms) {
            var info=new LastInput{cbSize=(uint)Marshal.SizeOf(typeof(LastInput))};
            if(!GetLastInputInfo(ref info)) return true;
            int last=unchecked((int)info.dwTime),now=Environment.TickCount;
            if(unchecked(last-LastSyntheticTick)<=60) return false;
            return unchecked(now-last)<ms;
        }
        [DllImport("user32.dll")] internal static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] internal static extern IntPtr GetParent(IntPtr h);
        [DllImport("user32.dll")] internal static extern IntPtr GetWindow(IntPtr h,uint command);
        [DllImport("user32.dll")] internal static extern IntPtr GetAncestor(IntPtr h,uint flags);
        [DllImport("user32.dll")] internal static extern bool GetWindowRect(IntPtr h,out Rect r);
        [DllImport("user32.dll")] internal static extern IntPtr WindowFromPoint(Point p);
        [DllImport("user32.dll")] internal static extern bool GetGUIThreadInfo(uint id,ref GuiInfo info);
        [DllImport("user32.dll",EntryPoint="GetWindowLongW")] internal static extern int GetWindowLong(IntPtr h,int index);
        [DllImport("user32.dll",CharSet=CharSet.Unicode)] internal static extern int GetClassName(IntPtr h,StringBuilder s,int count);
        [DllImport("user32.dll",CharSet=CharSet.Unicode)] internal static extern int GetWindowText(IntPtr h,StringBuilder s,int count);
        [DllImport("user32.dll",EntryPoint="SendMessageTimeoutW",CharSet=CharSet.Unicode,SetLastError=true)] internal static extern IntPtr ReadMessage(IntPtr h,uint msg,UIntPtr w,StringBuilder s,uint flags,uint timeout,out UIntPtr result);
        [DllImport("user32.dll",EntryPoint="SendMessageTimeoutW",CharSet=CharSet.Unicode,SetLastError=true)] internal static extern IntPtr WriteMessage(IntPtr h,uint msg,UIntPtr w,string s,uint flags,uint timeout,out UIntPtr result);
        [DllImport("user32.dll",SetLastError=true)] internal static extern uint SendInput(uint count,Input[] inputs,int size);
        [DllImport("user32.dll")] internal static extern int GetSystemMetrics(int index);
        [DllImport("user32.dll")] internal static extern short GetAsyncKeyState(int key);
        [DllImport("user32.dll")] internal static extern uint GetClipboardSequenceNumber();
        [DllImport("user32.dll")] internal static extern bool RegisterHotKey(IntPtr h,int id,uint modifiers,uint key);
        [DllImport("user32.dll")] internal static extern bool UnregisterHotKey(IntPtr h,int id);
        [DllImport("user32.dll")] internal static extern bool SetProcessDPIAware();
        [DllImport("user32.dll",EntryPoint="SendMessageTimeoutW",SetLastError=true)] internal static extern IntPtr SendNull(IntPtr h,uint msg,UIntPtr w,IntPtr l,uint flags,uint timeout,out UIntPtr result);
        // The same Windows calls as 1.6.1 (proven on the RDP PC), with one reusable buffer
        // per thread for each kind of read instead of a new 8 KB buffer for every field.
        [ThreadStatic] static StringBuilder classBuffer,captionBuffer,fieldBuffer;
        [DllImport("winmm.dll")] internal static extern uint timeBeginPeriod(uint period);
        [DllImport("winmm.dll")] internal static extern uint timeEndPeriod(uint period);
        internal static uint Pid(IntPtr h) { uint p; GetWindowThreadProcessId(h,out p); return p; }
        internal static string Class(IntPtr h) { var b=classBuffer??(classBuffer=new StringBuilder(256)); b.Length=0; GetClassName(h,b,256); return b.ToString(); }
        internal static string Caption(IntPtr h) { var b=captionBuffer??(captionBuffer=new StringBuilder(1024)); b.Length=0; GetWindowText(h,b,1024); return b.ToString(); }
        internal static IntPtr Focus(IntPtr root) { uint p; var i=new GuiInfo(); i.size=Marshal.SizeOf(typeof(GuiInfo)); return GetGUIThreadInfo(GetWindowThreadProcessId(root,out p),ref i) ? i.focus : IntPtr.Zero; }
        internal static bool TryText(IntPtr h,out string text) {
            var b=fieldBuffer??(fieldBuffer=new StringBuilder(4096)); b.Length=0; UIntPtr result;
            bool ok=ReadMessage(h,0xD,new UIntPtr(4096),b,3,100,out result)!=IntPtr.Zero && result.ToUInt64()<4095;
            text=ok ? b.ToString() : null; return ok;
        }
        // A held Shift/Ctrl/Alt/Windows key would turn the helper's Tab into Shift+Tab or its
        // click into Ctrl+click. 5 Oct: an order stopped at once because a key was down for
        // a moment (you may be finishing a shortcut in Chrome). Wait up to 3 s for it instead.
        internal static void NoModifiers() {
            var timer=System.Diagnostics.Stopwatch.StartNew();
            while(true) {
                string held=HeldModifier();
                if(held==null) return;
                if(timer.ElapsedMilliseconds>=3000) throw new InvalidOperationException("The "+held+" key is held down. Release it and try again. If nothing is pressed, tap "+held+" once: Remote Desktop can leave it stuck.");
                System.Threading.Thread.Sleep(30);
            }
        }
        static string HeldModifier() {
            if((GetAsyncKeyState(0x10)&0x8000)!=0) return "Shift";
            if((GetAsyncKeyState(0x11)&0x8000)!=0) return "Ctrl";
            if((GetAsyncKeyState(0x12)&0x8000)!=0) return "Alt";
            if((GetAsyncKeyState(0x5B)&0x8000)!=0 || (GetAsyncKeyState(0x5C)&0x8000)!=0) return "Windows";
            return null;
        }
        internal static void Key(ushort key) {
            NoModifiers(); var input=new Input[2];
            input[0].type=1; input[0].data.key.key=key;
            input[1]=input[0]; input[1].data.key.flags=2;
            LastSyntheticTick=Environment.TickCount;
            uint sent=SendInput(2,input,Marshal.SizeOf(typeof(Input)));
            if(sent!=2) { if(sent==1) SendInput(1,new[]{input[1]},Marshal.SizeOf(typeof(Input))); throw new InvalidOperationException("Windows did not accept the navigation key. Run the helper at the same permission level as COSTAR."); }
        }
        // 2.5.0: a key combination such as Ctrl+Tab: pressed in order, released in reverse.
        internal static void Chord(params ushort[] keys) {
            NoModifiers();int n=keys.Length;var input=new Input[n*2];
            for(int i=0;i<n;i++) { input[i].type=1;input[i].data.key.key=keys[i]; }
            for(int i=0;i<n;i++) { input[n+i].type=1;input[n+i].data.key.key=keys[n-1-i];input[n+i].data.key.flags=2; }
            LastSyntheticTick=Environment.TickCount;
            uint sent=SendInput((uint)input.Length,input,Marshal.SizeOf(typeof(Input)));
            if(sent!=input.Length) {
                var up=new Input[n];for(int i=0;i<n;i++){up[i].type=1;up[i].data.key.key=keys[i];up[i].data.key.flags=2;}
                SendInput((uint)n,up,Marshal.SizeOf(typeof(Input)));
                throw new InvalidOperationException("Windows did not accept the key combination. Run the helper at the same permission level as COSTAR.");
            }
        }
        internal static void Click(Point p) {
            NoModifiers();
            int left=GetSystemMetrics(76),top=GetSystemMetrics(77),width=GetSystemMetrics(78),height=GetSystemMetrics(79);
            Order.Require(width>1 && height>1 && p.X>=left && p.X<left+width && p.Y>=top && p.Y<top+height,"COSTAR field is outside the visible desktop.");
            var input=new Input[3];
            input[0].data.mouse.dx=(int)Math.Round((p.X-left)*65535.0/(width-1));
            input[0].data.mouse.dy=(int)Math.Round((p.Y-top)*65535.0/(height-1));
            input[0].data.mouse.flags=0xC001;
            input[1].data.mouse.flags=2; input[2].data.mouse.flags=4;
            LastSyntheticTick=Environment.TickCount;
            uint sent=SendInput(3,input,Marshal.SizeOf(typeof(Input)));
            if(sent!=3) { SendInput(1,new[]{input[2]},Marshal.SizeOf(typeof(Input))); throw new InvalidOperationException("Windows did not accept the field click."); }
        }
    }
}
