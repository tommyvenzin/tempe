// Node tests for Website/discord.js (Discord alerts, one message per salesperson).
// Run: node Tests/OrderCheck/test-discord.cjs
process.env.TZ = "Australia/Sydney";
const assert = require("node:assert/strict");
const path = require("node:path");
const saved = new Map();
globalThis.localStorage = { getItem: (k) => (saved.has(k) ? saved.get(k) : null), setItem: (k, v) => saved.set(k, String(v)), removeItem: (k) => saved.delete(k) };
const D = require(path.join(__dirname, "..", "..", "Website", "discord.js"));
let groups = 0;
function group(name, fn) { fn(); groups++; console.log("PASS " + name); }

const HOOK = "https://discord.com/api/webhooks/123456789012345678/AbCdEfGhIjKlMnOpQrStUvWxYz_0123456789-abcdefghijkl";
const TOG = "111111111111111111";
const cfg = { url: HOOK, people: `TOG = ${TOG}`, on: true };
const shop = { shopHours: true, wipComplete: true, leaveOut: "MD ST UBH YTA" };
const row = (doc, by, total, name, comment = "") => ({ doc, by, total, name, comment, orderDate: "2026-10-23", sig: "s" + doc });
const red = (doc, by, total, name, codes, comment) => ({ status: "red", label: "Not ordered", codes, reasons: codes, row: row(doc, by, total, name, comment) });
const warn = (doc, by, total, name, pick, comment) => ({ status: "warn", label: "Not picked", summary: { pick }, row: row(doc, by, total, name, comment) });
const green = (doc, by, total, name) => ({ status: "green", label: "Ordered", row: row(doc, by, total, name) });

// What the board does with a plan when every Discord call works.
let nextId = 1;
function apply(p, extra = {}) {
  const st = p.state;
  for (const id of p.deletes) D.done(st, id);
  for (const e of p.edits) D.edited(st, e);
  for (const post of p.posts) D.recordPost(st, post, post.contents.map(() => "m" + nextId++));
  if (extra.shopHours !== false) D.finishRound(st);
  return st;
}
const card = (content, silent, mention) => D.body(content, silent, mention);
const desc = (content) => card(content).embeds[0].description;
const RED = 0xC0161F, ORANGE = 0xC45200;

const jobs = [
  red("07510297", "DB", 1560, "TAEHO CHOI", ["waiting"], "EDC44U"),
  red("07510305", "SA", 50, "TOP ONE AUTOMOTIVE", ["shop"]),
  red("07510467", "DB", 30, "PHILIP INNESS", ["waiting"], "FFI80G"),
  warn("07509852", "TOG", 89, "CHANELLE ANDERLUM", "printed 09:30", "NEL305 1 PM"),
  green("07510313", "MRA", 3030, "RUBAYET MAHMUD"),
  red("07450001", "ST", 640, "THE BOSS JOB", ["date"]),
];

group("Webhook links, the people list and settings", () => {
  assert.equal(D.parseWebhook(HOOK).id, "123456789012345678");
  assert.equal(D.parseWebhook(" https://discordapp.com/api/webhooks/123456789012345678/AbCdEfGhIjKlMnOpQrStUvWxYz/ ").url, "https://discord.com/api/webhooks/123456789012345678/AbCdEfGhIjKlMnOpQrStUvWxYz");
  for (const bad of ["", "https://evil.example/api/webhooks/123456789012345678/AbCdEfGhIjKlMnOpQrStUvWxYz", HOOK + "?thread_id=1", "http://discord.com/api/webhooks/123456789012345678/AbCdEfGhIjKlMnOpQrStUvWxYz"]) {
    assert.equal(D.parseWebhook(bad), null, "rejected: " + bad);
  }
  const p = D.parsePeople(`TOG = ${TOG}\n  db 222222222222222222\nSA: <@333333333333333333>\n\nMRA = 12345`);
  assert.deepEqual(p.people, { TOG, DB: "222222222222222222", SA: "333333333333333333" });
  assert.deepEqual(p.bad, ["MRA = 12345"]);
  D.saveSettings({ ...cfg, names: true });
  assert.deepEqual(D.loadSettings(), cfg, "only the link, the people list and on/off are kept");
  assert.equal(D.inShopHours(new Date("2026-10-25T10:00:00+11:00")), false, "Sunday");
  assert.equal(D.inShopHours(new Date("2026-10-26T07:00:00+11:00")), true, "Monday 7:00");
  assert.equal(D.inShopHours(new Date("2026-10-24T18:31:00+11:00")), false, "Saturday 18:31");
});

group("A card per salesperson: initials as the title, a coloured bar, Doc# - Name - Amount - Comment - what's wrong", () => {
  const p = D.plan(jobs, D.emptyState(), cfg, shop);
  assert.deepEqual(p.posts.map((x) => x.person), ["DB", "SA", "TOG"], "alphabetical, the boss left out, ordered jobs not posted");
  const db = card(p.posts[0].contents[0], p.posts[0].silent, p.posts[0].mention);
  assert.deepEqual(db, { content: "", embeds: [{ title: "DB", color: RED, description: [
    "07510297 - TAEHO CHOI - $1,560 - EDC44U - **Tick Customer Waiting**",
    "07510467 - PHILIP INNESS - $30 - FFI80G - **Tick Customer Waiting**",
  ].join("\n\n") }], allowed_mentions: { parse: [], users: [] } }, "a blank line between jobs, no ping for untagged people");
  assert.equal(desc(p.posts[1].contents[0]), "07510305 - TOP ONE AUTOMOTIVE - $50 - **Put SHOP**", "no comment: no empty dash");
  const tog = card(p.posts[2].contents[0], p.posts[2].silent, p.posts[2].mention);
  assert.equal(tog.content, `<@${TOG}>`, "Tommy's tag sits above his card");
  assert.deepEqual(tog.allowed_mentions, { parse: [], users: [TOG] }, "and only he is pinged");
  assert.equal(tog.embeds[0].title, "TOG");
  assert.equal(tog.embeds[0].color, ORANGE, "orange when it's only Not picked");
  assert.equal(tog.embeds[0].description, "07509852 - CHANELLE ANDERLUM - $89 - NEL305 1 PM - **Not picked (printed 09:30)**");
  assert.equal(tog.flags, undefined, "a normal post notifies");
  for (const post of p.posts) assert.doesNotMatch(JSON.stringify(card(post.contents[0])), /Open the board|Order Check|Tags|✅|🔴|🟠|·|—/, "nothing but the lines");
  const st = apply(p);
  const again = D.plan(jobs, st, cfg, shop);
  assert.deepEqual([again.posts.length, again.edits.length, again.deletes.length], [0, 0, 0], "same problems: nothing happens");
});

group("Fixed jobs disappear, a salesperson with nothing left loses the message", () => {
  let st = apply(D.plan(jobs, D.emptyState(), cfg, shop));
  const dbMsg = st.persons.DB.msgs[0].id;
  const fixedOne = jobs.map((j) => (j.row.doc === "07510297" ? green("07510297", "DB", 1560, "TAEHO CHOI") : j));
  let p = D.plan(fixedOne, st, cfg, shop);
  assert.deepEqual([p.posts.length, p.deletes], [0, []], "an edit, no notification");
  assert.deepEqual(p.edits.map((e) => [e.person, e.index, e.id]), [["DB", 0, dbMsg]]);
  assert.equal(desc(p.edits[0].content), "07510467 - PHILIP INNESS - $30 - FFI80G - **Tick Customer Waiting**");
  assert.deepEqual(card(p.edits[0].content, false, "").allowed_mentions, { parse: [], users: [] }, "edits never ping");
  st = apply(p);
  const fixedBoth = fixedOne.map((j) => (j.row.doc === "07510467" ? green("07510467", "DB", 30, "PHILIP INNESS") : j));
  p = D.plan(fixedBoth, st, cfg, shop);
  assert.deepEqual([p.posts.length, p.edits.length, p.deletes], [0, 0, [dbMsg]], "DB's message is deleted");
  st = apply(p);
  assert.equal(st.persons.DB, undefined);
  // the job left Work-in-Progress (invoiced): gone from the message too, but only after a full WIP read
  const noSa = fixedBoth.filter((j) => j.row.doc !== "07510305");
  assert.deepEqual(D.plan(noSa, st, cfg, { ...shop, wipComplete: false }).deletes, [], "a filtered or stale read keeps it");
  assert.deepEqual(D.plan(noSa, st, cfg, shop).deletes, [st.persons.SA.msgs[0].id]);
});

group("A new problem re-posts that salesperson's message so Discord notifies", () => {
  let st = apply(D.plan(jobs, D.emptyState(), cfg, shop));
  const old = st.persons.SA.msgs[0].id;
  const more = [...jobs, red("07510540", "SA", 1350, "TENA TRANSPORT PTY LTD", ["shop"])];
  const p = D.plan(more, st, cfg, shop);
  assert.deepEqual(p.deletes, [old]);
  assert.equal(p.posts.length, 1);
  assert.equal(p.posts[0].silent, false);
  assert.equal(desc(p.posts[0].contents[0]), "07510305 - TOP ONE AUTOMOTIVE - $50 - **Put SHOP**\n\n07510540 - TENA TRANSPORT PTY LTD - $1,350 - **Put SHOP**");
  st = apply(p);
  assert.deepEqual(st.persons.SA.docs, ["07510305", "07510540"]);
  // after 18:30 a new problem waits for 7:00; fixes still come off straight away
  const night = [...more, red("07510557", "DB", 30, "ASH FALZON", ["waiting"], "EZE13C")].map((j) => (j.row.doc === "07510305" ? green("07510305", "SA", 50, "TOP ONE AUTOMOTIVE") : j));
  const n = D.plan(night, st, cfg, { ...shop, shopHours: false });
  assert.equal(n.posts.length, 0, "nothing new posted at night");
  assert.deepEqual(n.edits.map((e) => e.person), ["SA"], "the fixed SA job still comes off");
  st = apply(n, { shopHours: false });
  const morning = D.plan(night, st, cfg, shop);
  assert.deepEqual(morning.posts.map((x) => x.person), ["DB"], "DB's new job goes out at 7:00");
  assert.match(morning.posts[0].contents[0], /07510557 - ASH FALZON - \$30 - EZE13C/);
});

group("Left out, deleted in Discord, long lists, half-posted messages", () => {
  let st = apply(D.plan(jobs, D.emptyState(), cfg, { ...shop, leaveOut: "" }));
  assert.ok(st.persons.ST, "without the list the boss's job is posted");
  const stMsg = st.persons.ST.msgs[0].id;
  assert.deepEqual(D.plan(jobs, st, cfg, shop).deletes, [stMsg], "with the list it's deleted");
  st = apply(D.plan(jobs, st, cfg, shop));
  // Tommy deletes the DB message himself: it isn't posted again until DB has something new
  const fixedOne = jobs.map((j) => (j.row.doc === "07510297" ? green("07510297", "DB", 1560, "TAEHO CHOI") : j));
  let p = D.plan(fixedOne, st, cfg, shop);
  D.gone(p.state, p.edits[0]);
  st = p.state;
  assert.deepEqual(D.plan(fixedOne, st, cfg, shop).posts, [], "stays deleted");
  p = D.plan([...fixedOne, red("07510600", "DB", 99, "NEW CUSTOMER", ["waiting"])], st, cfg, shop);
  assert.equal(p.posts.length, 1, "back with the next new problem");
  assert.match(desc(p.posts[0].contents[0]), /07510467[\s\S]*07510600/);
  // 45 jobs for one person: split under Discord's card limit, each part titled
  const many = Array.from({ length: 45 }, (_, i) => red("0752" + String(1000 + i), "KTJ", 1000 + i, "A LONG CUSTOMER NAME PTY LTD " + i, ["shop", "date"], "SOME COMMENT ABOUT THE JOB " + i));
  const big = D.plan(many, D.emptyState(), cfg, shop).posts[0];
  assert.ok(big.contents.length >= 2 && big.contents.every((c) => card(c).embeds[0].title === "KTJ" && desc(c).length <= 4096), "split past the card limit, each part titled");
  // a post that failed half way: its first part is deleted and the whole list goes again
  const half = D.plan(many, D.emptyState(), cfg, shop);
  half.state.cleanup.push("half1");
  const retry = D.plan(many, half.state, cfg, shop);
  assert.deepEqual([retry.deletes, retry.posts.length], [["half1"], 1]);
});

group("Messages from 1.6.0 to 1.6.2 are deleted and the channel is redrawn quietly as cards", () => {
  const v1 = { v: 1, quiet: {}, active: { "07510297": "old1" }, msgs: { old1: { at: 1, items: [] }, old2: { at: 1, items: [] }, old3: { at: 1, items: [] } } };
  saved.set(D.SENT_KEY, JSON.stringify(v1));
  const loaded = D.loadSent();
  assert.deepEqual([loaded.v, loaded.cleanup, loaded.migrated], [3, ["old1", "old2", "old3"], true]);
  const p = D.plan(jobs, loaded, cfg, shop);
  assert.deepEqual(p.deletes, ["old1", "old2", "old3"], "every old message goes");
  assert.ok(p.posts.length === 3 && p.posts.every((x) => x.silent), "the redraw doesn't notify");
  assert.equal(D.body(p.posts[0].contents[0], true, "").flags, 4096, "silent");
  const st = apply(p);
  assert.equal(st.migrated, undefined);
  const next = D.plan([...jobs, red("07510700", "SA", 10, "LATER", ["shop"])], st, cfg, shop);
  assert.equal(next.posts[0].silent, false, "after the redraw, new problems notify again");
  saved.set(D.SENT_KEY, "{broken");
  assert.deepEqual(D.loadSent(), D.emptyState(), "a damaged record starts fresh");
});

group("Text messages from 1.6.3 are deleted and redrawn as cards, quietly", () => {
  const v2 = { v: 2, cleanup: ["left1"], persons: { DB: { msgs: [{ id: "t1", content: "### DB" }], docs: ["07510297"], lines: {} }, SA: { msgs: [{ id: "t2", content: "### SA" }, { id: "t3", content: "### SA" }], docs: [], lines: {} } } };
  const p = D.plan(jobs, v2, cfg, shop);
  assert.deepEqual(p.deletes, ["left1", "t1", "t2", "t3"]);
  assert.ok(p.posts.length === 3 && p.posts.every((x) => x.silent));
  assert.equal(card(p.posts[0].contents[0], true, "").embeds[0].title, "DB");
});

group("Names and comments are plain text", () => {
  const odd = red("07460300", "MOR", 29.95, "SMITH *JONES* _CO_ @everyone <@123456789012345678>", ["shop"], "CALL ~~JOHN~~ `0400`");
  assert.equal(D.jobLine(odd), "07460300 - SMITH \\*JONES\\* \\_CO\\_ @\u200beveryone \\<@\u200b123456789012345678\\> - $29.95 - CALL \\~\\~JOHN\\~\\~ \\`0400\\` - **Put SHOP**");
  assert.equal(D.jobLine(red("07460301", "MOR", 100, "", ["shop", "date"])), "07460301 - $100 - **Put SHOP, Incorrect date**");
});

console.log(`${groups} test groups passed.`);
