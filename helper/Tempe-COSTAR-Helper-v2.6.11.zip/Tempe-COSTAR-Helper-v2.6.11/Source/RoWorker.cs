// The RDP helper's Repair Order side (2.6.0): asks the desk PC for the phones' Repair Order requests
// and does them in the selected COSTAR (Tempe), one at a time, in a quiet moment: reads its Work-in-
// Progress list, opens a Repair Order from it (double click on its row, or Enter on the selected row),
// reads it, types the phone's changes, checks them and closes it again. A change that stops after
// typing leaves the Repair Order open for a person to check (the phone can ask to close it then).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    // What the helper is doing (saved before COSTAR is touched): after a restart it tells the desk the
    // request stopped. touched: something was typed into the Repair Order.
    // printing (2.6.2): OK was about to go on COSTAR's print form (the Job Card may have printed).
    public sealed class RoAttempt { public string id,lease,kind,doc,atUtc;public long window,processStart;public int processId;public bool touched,printing; }
    // A Repair Order this helper left open after a change stopped (the phone may ask to close it).
    public sealed class RoLeftOpen { public string doc,atUtc;public long window,processStart;public int processId; }
    public sealed class RoJournal { public RoAttempt running;public RoLeftOpen leftOpen;public RoReport report;public int sequence; }
    // What an open from Work-in-Progress saw, for the engine when it stops: the Repair Order windows
    // there before anything was clicked (shown or not), and whether a person used the PC meanwhile
    // (then no window that opened is taken for the helper's own, so none is ever closed).
    internal sealed class RoOpenWatch { internal HashSet<long> Before;internal bool UserActive;internal readonly Stopwatch Clock=Stopwatch.StartNew(); }

    // How long each part of an open from Work-in-Progress took (2.6.1), for the day log and the report.
    internal sealed class RoOpenTimes {
        internal long ScanMs,SearchMs=-1,RevealMs,WindowMs=-1,TotalMs;internal int Rows,Scans,Wheels,Notches;internal bool OneCell,Clicked,Direct,FilterCleared;internal string How="",Hit="";
        // 2.6.11: the filter cleared (a person's search: for the phone's result only, never the day log).
        internal string Filter="";
        internal void Took(WipScan scan) { ScanMs+=scan.Ms;Scans++;Rows=scan.Lines.Count;OneCell=scan.OneCell; }
        static string S(long ms) { return (ms/100/10.0).ToString("0.0",CultureInfo.InvariantCulture)+" s"; }
        public override string ToString() {
            var b=new StringBuilder();
            b.Append("list read ").Append(S(ScanMs)).Append(" (").Append(Rows).Append(" rows").Append(OneCell?", one cell each":", every cell").Append(Scans>1?", "+Scans+" reads":"").Append(")");
            b.Append(SearchMs>=0?", Search "+S(SearchMs):", no Search");
            if(FilterCleared) b.Append(" (COSTAR's filter cleared first)");
            b.Append(", row ").Append(How.Length>0?How:"not reached").Append(" ").Append(S(RevealMs));
            if(Wheels>0) b.Append(" (").Append(Notches).Append(" notches").Append(Clicked?", one click to give the list the wheel":"").Append(")");
            if(Hit.Length>0) b.Append(", at the point: ").Append(Hit);
            if(Direct) b.Append(", opened without the mouse (Enter)");
            if(WindowMs>=0) b.Append(", COSTAR opened it in ").Append(S(WindowMs));
            b.Append(", ").Append(S(TotalMs)).Append(" in all");
            return b.ToString();
        }
    }

    // The scroll arithmetic of an open (2.6.1), apart from COSTAR so it can be tested. Rows are counted in
    // the list's order.
    internal static class WipScroll {
        internal const int MaxSteps=40,MaxTurnNotches=20,MaxRevealMs=30000;
        // Notches for one turn towards a row `rows` away (room: rows the list can still go that way before its
        // end, as seen; it may be a row out): one while it isn't known how far a notch goes; then as many as
        // bring the row to the middle, 20 at most, and only as many as stay a row short of the list's end (a
        // list may stop at its end, or go on past its last row: a turn short of it shows every notch of it);
        // one when not even that fits. Each turn is waited out before the next.
        internal static int Turn(int rows,int perNotch,int room) {
            if(perNotch<=0) return 1;
            int n=Math.Max(1,Math.Min(MaxTurnNotches,(int)Math.Ceiling(rows/(double)perNotch)));
            if(n*perNotch>room-1) n=Math.Max(1,(room-1)/perNotch);
            return n;
        }
        // Rows a turn must move the list (at least one; no more than it can go before its end).
        internal static int Expect(int notches,int perNotch,int room) { return Math.Max(1,Math.Min(room,notches*Math.Max(1,perNotch))); }
        // After a turn that came through (moved: rows, the way it was turned; room: rows it could go before
        // the list's end, as seen): how many rows a notch moves (0: still not known), or -1 when the turn moved
        // the list other than its notches say (then a notch may still be on its way: stop). One notch comes
        // through whole or not at all, so any move of one notch is all of it (no more than a notch's rows: the
        // list may have stopped at its end); it measures a notch unless it took the list to its end. A turn
        // of more notches must move exactly that many notches' rows (it stays short of the end: Turn).
        internal static int Accounted(int perNotch,int moved,int notches,int room) {
            if(moved<=0) return -1;
            if(notches==1) return perNotch<=0?(moved>=room?0:moved):moved<=perNotch?perNotch:-1;
            return perNotch>0&&moved==notches*perNotch?perNotch:-1;
        }
    }

    // One look at COSTAR's Work-in-Progress list for one open (2.6.1). Only each row's Document # cell is
    // read (one cell a row through accessibility; 2.6.0 read every cell of every row, about 4 s a look, and
    // looked again after each scroll step), and the cells are kept, so where the rows are after a scroll
    // is one call a row. Everything is released when the open ends.
    internal sealed class WipScan : IDisposable {
        // Pos: the row's place among the list's children (1 = first), to look at it again with new objects.
        internal sealed class Line { internal string Doc;internal Accessibility.IAccessible Row,Cell;internal int Left,Top,Width,Height,Pos;internal bool Placed; }
        // The list shows no table (before COSTAR's first Search, or while it is being made again).
        internal sealed class NoTable : InvalidOperationException { internal NoTable():base("COSTAR's Work-in-Progress list isn't showing a table. Press Search in COSTAR.") {} }
        // A cell read on its own that isn't the Document # cell: the list is read again, every cell.
        sealed class WrongCell : Exception { }
        internal readonly List<Line> Lines=new List<Line>();
        // HeadBottom: the bottom of the column headings, when the list tells (a row placed above it is hidden
        // behind them, never in view).
        internal int Target=-1,First=-1,Last=-1,DocIndex=-1,HeadBottom=-1;internal bool OneCell;internal long Ms;
        readonly List<object> owned=new List<object>();
        Accessibility.IAccessible client,table;Dictionary<string,int> columns;string poColumn="";
        Func<Accessibility.IAccessible> source;
        const string DocColumn="Document #";
        internal Line TargetLine { get { return Target>=0&&Target<Lines.Count?Lines[Target]:null; } }
        internal static WipScan Take(IntPtr grid,string doc,bool allCells=false) {
            Native.Rect box;Order.Require(Native.GetWindowRect(grid,out box),"COSTAR's Work-in-Progress list is gone.");
            return From(delegate { return Msaa.FromWindow(grid); },box,doc,allCells);
        }
        // From any accessibility root and the list's place on the screen (the self-tests give a made-up
        // list). allCells: every cell of every row (as 2.6.0 did), when one cell on its own can't be trusted.
        internal static WipScan From(Func<Accessibility.IAccessible> root,Native.Rect box,string doc,bool allCells) {
            var clock=Stopwatch.StartNew();
            if(!allCells) {
                var scan=new WipScan {source=root};bool wrong=false;
                try { scan.Read(root(),box,doc,false); }
                catch(WrongCell) { wrong=true; }
                catch(Exception) { scan.Dispose();throw; }
                // The wanted row's cell too must be named as the Document # column.
                if(!wrong&&scan.OneCell&&scan.TargetLine!=null&&Msaa.NameOf(scan.TargetLine.Row,scan.TargetLine.Cell).Trim()!=DocColumn) wrong=true;
                if(!wrong) { scan.Ms=clock.ElapsedMilliseconds;return scan; }
                scan.Dispose();AppLog.Note("ro_wip_cells","a cell read on its own wasn't the Document # cell: every cell read");
            }
            var all=new WipScan {source=root};
            try { all.Read(root(),box,doc,true); }
            catch(Exception) { all.Dispose();throw; }
            all.Ms=clock.ElapsedMilliseconds;return all;
        }
        void Read(Accessibility.IAccessible root,Native.Rect box,string doc,bool allCells) {
            client=root;
            table=Msaa.Role(client)==Msaa.RoleTable?client:Msaa.FindTable(client,3);
            if(table==null) throw new NoTable();
            string want=Order.Norm(doc);var seen=new Dictionary<string,int>(StringComparer.Ordinal);
            int docIndex=-1,alone=0,pos=0;bool one=!allCells;
            foreach(object o in Msaa.Children(table,5000)) {
                owned.Add(o);pos++;
                var row=o as Accessibility.IAccessible;
                if(row==null||Msaa.RoleOf(table,o)!=Msaa.RoleRow) continue;
                Accessibility.IAccessible cell=null;
                if(docIndex>=0&&one) {
                    object c=null;try { c=row.get_accChild(docIndex+1); } catch(Exception) { c=null; }
                    if(c!=null) owned.Add(c);
                    cell=c as Accessibility.IAccessible;
                    // Its name checked on the first rows and on every 10th after them (and on the wanted one at
                    // the end): one that isn't the Document # cell means reading the whole list again.
                    if(cell!=null&&(alone<3||alone%10==0)&&Msaa.NameOf(row,cell).Trim()!=DocColumn) throw new WrongCell();
                    if(cell!=null) alone++; else one=false; // no cell on its own: every cell from here (named with them)
                }
                if(cell==null) {
                    var cells=Msaa.Children(row,80);
                    try {
                        if(cells.Count==0) continue;
                        if(Msaa.RoleOf(row,cells[0])==25) { // the column headings
                            int hl,ht,hw,hh2;if(Msaa.LocationOf(table,row,out hl,out ht,out hw,out hh2)&&hw>0&&hh2>0) HeadBottom=Math.Max(HeadBottom,ht+hh2);
                            continue;
                        }
                        if(columns==null) {
                            columns=new Dictionary<string,int>(StringComparer.Ordinal);
                            for(int i=0;i<cells.Count;i++) { string n=Msaa.NameOf(row,cells[i]).Trim();if(n.Length>0&&!columns.ContainsKey(n)) columns[n]=i; }
                            poColumn=TempeOrderCheck.GridReader.FindPoColumn(columns.Keys);
                            Order.Require(columns.TryGetValue(DocColumn,out docIndex),"COSTAR's Work-in-Progress list has no Document # column.");
                        }
                        if(docIndex<cells.Count) cell=cells[docIndex] as Accessibility.IAccessible;
                    } finally { foreach(var c in cells) if(!Object.ReferenceEquals(c,cell)) Msaa.Release(c); }
                    if(cell==null) continue;
                    owned.Add(cell);
                }
                string d=Order.Norm(Msaa.ValueOf(row,cell));
                if(d.Length==0||!RoEdit.IsDoc(d)) continue;
                int l,t,w,hh;bool placed=Msaa.LocationOf(row,cell,out l,out t,out w,out hh)&&w>0&&hh>0;
                int at;
                if(seen.TryGetValue(d,out at)) {
                    // The list can hold its active row twice: one line per document, at the place shown.
                    var first=Lines[at];
                    if(!first.Placed&&placed) { first.Row=row;first.Cell=cell;first.Left=l;first.Top=t;first.Width=w;first.Height=hh;first.Placed=true;first.Pos=pos; }
                    continue;
                }
                seen[d]=Lines.Count;
                Lines.Add(new Line {Doc=d,Row=row,Cell=cell,Left=l,Top=t,Width=w,Height=hh,Placed=placed,Pos=pos});
                if(d==want) Target=Lines.Count-1;
            }
            OneCell=one&&docIndex>=0&&alone>0;DocIndex=docIndex;
            Range(box);
        }
        // Where rows show: from the bottom of the column headings (when the list tells where they are; a few
        // pixels either way: a row hidden behind them is a whole row higher), inside the list.
        internal int ViewTop(Native.Rect box) { return HeadBottom>0?Math.Max(box.Top,HeadBottom-4):box.Top; }
        void Range(Native.Rect box) {
            First=-1;Last=-1;int top=ViewTop(box);
            for(int i=0;i<Lines.Count;i++) { var x=Lines[i];if(x.Placed&&x.Top>=top&&x.Top+x.Height<=box.Bottom) { if(First<0) First=i;Last=i; } }
        }
        static void Place(Line x) { int l,t,w,h;x.Placed=Msaa.LocationOf(x.Row,x.Cell,out l,out t,out w,out h)&&w>0&&h>0;x.Left=l;x.Top=t;x.Width=w;x.Height=h; }
        // Where every row is now (one call each) and which are wholly in view. False when no row has a
        // place any more (the rows were made again: read the list again).
        internal bool Places(Native.Rect box) {
            bool any=false;foreach(var x in Lines) { Place(x);any|=x.Placed; }
            Range(box);return any;
        }
        internal void PlaceTarget() { var x=TargetLine;if(x!=null) Place(x); }
        internal int InView { get { return First<0?0:Last-First+1; } }
        // A row's height: the middle one of the steps between rows in view (19 px when nothing tells).
        internal int RowHeight {
            get {
                var steps=new List<int>();
                for(int i=Math.Max(0,First);First>=0&&i<Last;i++) { var a=Lines[i];var b=Lines[i+1];if(a.Placed&&b.Placed&&b.Top>a.Top) steps.Add(b.Top-a.Top); }
                if(steps.Count>0) { steps.Sort();return Math.Max(1,steps[steps.Count/2]); }
                return First>=0?Math.Max(1,Lines[First].Height):19;
            }
        }
        // Where the list is scrolled to, in rows: for every row wholly in view, its number less the rows above
        // it on the screen, the middle of those (one odd answer from accessibility doesn't move it). Null when
        // no row is in view. Larger: scrolled further down.
        internal int? ScrollRow(Native.Rect box) {
            if(First<0) return null;
            int h=RowHeight,top=ViewTop(box);var at=new List<int>();
            for(int i=First;i<=Last;i++) { var x=Lines[i];if(x.Placed&&x.Top>=top&&x.Top+x.Height<=box.Bottom) at.Add(i-(int)Math.Round((x.Top-box.Top)/(double)h)); }
            if(at.Count==0) return null;
            at.Sort();return at[at.Count/2];
        }
        // Rows the list can still move: up (above the first row in view) or down (below the last).
        internal int Room(bool up) { return First<0?0:up?First:Lines.Count-1-Last; }
        // The wanted row looked at with new objects at its place among the list's children: why it isn't
        // this Repair Order there, at the same place, or null when it is.
        internal string FreshCheck() {
            var x=TargetLine;if(x==null||source==null) return "no row";
            Accessibility.IAccessible root=null,fresh=null,row=null,cell=null;object o=null,c=null;
            try {
                root=source();fresh=Msaa.Role(root)==Msaa.RoleTable?root:Msaa.FindTable(root,3);
                if(fresh==null) return "no table";
                try { o=fresh.get_accChild(x.Pos); } catch(Exception) { o=null; }
                row=o as Accessibility.IAccessible;if(row==null) return "no row there";
                if(DocIndex<0) return "no Document # column";
                if(OneCell) { try { c=row.get_accChild(DocIndex+1); } catch(Exception) { c=null; } cell=c as Accessibility.IAccessible; }
                else { var cells=Msaa.Children(row,80);try { if(DocIndex<cells.Count) { c=cells[DocIndex];cell=c as Accessibility.IAccessible; } } finally { foreach(var k in cells) if(!Object.ReferenceEquals(k,c)) Msaa.Release(k); } }
                if(cell==null||Msaa.NameOf(row,cell).Trim()!=DocColumn) return "not the Document # cell";
                string d=Order.Norm(Msaa.ValueOf(row,cell));if(d!=x.Doc) return "Repair Order "+(d.Length>0?d:"(none)")+" is there now";
                int l,t,w,h;bool placed=Msaa.LocationOf(row,cell,out l,out t,out w,out h)&&w>0&&h>0;
                if(!placed||t!=x.Top||l!=x.Left) return "it moved";
                return null;
            } finally { Msaa.Release(c);Msaa.Release(o);if(fresh!=null&&!Object.ReferenceEquals(fresh,root)) Msaa.Release(fresh);Msaa.Release(root); }
        }
        // The wanted row is the selected (or focused) one, and no other row is either (for Enter, which opens
        // the list's current row).
        internal bool OnlyTargetSelected() {
            var x=TargetLine;if(x==null) return false;
            int st=Msaa.StateOf(table,x.Row);if(st<0||(st&0x6)==0) return false;
            foreach(var y in Lines) { if(Object.ReferenceEquals(y,x)) continue;int s=Msaa.StateOf(table,y.Row);if(s>=0&&(s&0x6)!=0) return false; }
            return true;
        }
        // 2.6.5: the wanted row is the list's active row, the one Enter opens: it carries the keyboard's mark
        // (focused) while the list has the keyboard, or it is the row that doesn't offer "Activate" while the
        // others do (COSTAR's list, the maps of 28 Oct: only the active row has no action).
        internal bool TargetActive() {
            var x=TargetLine;if(x==null) return false;
            int st=Msaa.StateOf(table,x.Row);
            if(st>=0&&(st&0x4)!=0) return true;
            string a;if(!Msaa.TryAction(table,x.Row,out a)||a.Trim().Length>0) return false;
            int others=0;
            foreach(var y in Lines) {
                if(Object.ReferenceEquals(y,x)) continue;
                string b;if(!Msaa.TryAction(table,y.Row,out b)||!String.Equals(b.Trim(),"Activate",StringComparison.OrdinalIgnoreCase)) return false;
                if(++others>=3) break;
            }
            return others>0;
        }
        // 2.6.5: the wanted row looked up afresh (new objects, at its place among the list's children) and
        // still this Repair Order there: the row (to press its "Activate"), or null with why not.
        internal Accessibility.IAccessible FreshTargetRow(out string why) {
            var x=TargetLine;why=null;
            if(x==null||source==null) { why="no row";return null; }
            Accessibility.IAccessible root=null,fresh=null,row=null,cell=null;object o=null,c=null;bool keep=false;
            try {
                root=source();fresh=Msaa.Role(root)==Msaa.RoleTable?root:Msaa.FindTable(root,3);
                if(fresh==null) { why="no table";return null; }
                try { o=fresh.get_accChild(x.Pos); } catch(Exception) { o=null; }
                row=o as Accessibility.IAccessible;if(row==null) { why="no row there";return null; }
                if(DocIndex<0) { why="no Document # column";return null; }
                if(OneCell) { try { c=row.get_accChild(DocIndex+1); } catch(Exception) { c=null; } cell=c as Accessibility.IAccessible; }
                else { var cells=Msaa.Children(row,80);try { if(DocIndex<cells.Count) { c=cells[DocIndex];cell=c as Accessibility.IAccessible; } } finally { foreach(var k in cells) if(!Object.ReferenceEquals(k,c)) Msaa.Release(k); } }
                if(cell==null||Msaa.NameOf(row,cell).Trim()!=DocColumn) { why="not the Document # cell";return null; }
                string d=Order.Norm(Msaa.ValueOf(row,cell));if(d!=x.Doc) { why="Repair Order "+(d.Length>0?d:"(none)")+" is there now";return null; }
                keep=true;return row;
            } finally { Msaa.Release(c);if(!keep) Msaa.Release(o);if(fresh!=null&&!Object.ReferenceEquals(fresh,root)) Msaa.Release(fresh);Msaa.Release(root); }
        }
        // Every row's place as last looked at, as one string: what changes when the list moves.
        internal string Signature() {
            var b=new StringBuilder();b.Append(First).Append('/').Append(Last).Append(':');
            foreach(var x in Lines) b.Append(x.Placed?x.Top.ToString(CultureInfo.InvariantCulture):"-").Append(',');
            return b.ToString();
        }
        // A row wholly in view, nearest the middle of the view (where a click only selects a row).
        internal Line NearestMiddle(Native.Rect box) {
            int mid=(box.Top+box.Bottom)/2;Line best=null;
            for(int i=Math.Max(0,First);First>=0&&i<=Last;i++) { var x=Lines[i];if(x.Placed&&(best==null||Math.Abs(x.Top+x.Height/2-mid)<Math.Abs(best.Top+best.Height/2-mid))) best=x; }
            return best;
        }
        // The wanted row: still that document (its cell read again), its state, its values, selected.
        internal bool TargetStill() { var x=TargetLine;return x!=null&&Order.Norm(Msaa.ValueOf(x.Row,x.Cell))==x.Doc; }
        internal int TargetState() { var x=TargetLine;return x==null?-1:Msaa.StateOf(table,x.Row); }
        // 2.6.5: what the wanted row offers ("Activate", or "" once it is the active row); null: can't be read.
        internal string TargetAction() { var x=TargetLine;string a;return x!=null&&Msaa.TryAction(table,x.Row,out a)?a.Trim():null; }
        internal void SelectTarget() { var x=TargetLine;if(x!=null) Msaa.SelectChild(table,x.Row); }
        internal RoListRow TargetRow() {
            var x=TargetLine;if(x==null) return null;
            var cells=Msaa.Children(x.Row,80);
            try {
                Func<string,string> cell=delegate(string name) { int ci;return columns!=null&&name.Length>0&&columns.TryGetValue(name,out ci)&&ci<cells.Count?Order.Clean(Msaa.ValueOf(x.Row,cells[ci])):""; };
                return new RoListRow {doc=x.Doc,date=cell("Order Date"),name=cell("Name"),total=cell("Doc Total"),shipVia=cell("Ship Via"),comment=cell("Comment"),by=cell("Written By"),status=cell("Status"),po=poColumn.Length>0?cell(poColumn):null};
            } finally { foreach(var c in cells) Msaa.Release(c); }
        }
        public void Dispose() {
            foreach(var o in owned) Msaa.Release(o);
            owned.Clear();Lines.Clear();
            if(table!=null&&!Object.ReferenceEquals(table,client)) Msaa.Release(table);
            Msaa.Release(client);table=null;client=null;
        }
    }

    // 2.6.7: a Repair Order window's number and PO# (null when they can't be read), read without typing or
    // pressing anything: the words of its labels (COSTAR's), then only the box beside the RepairOrder label
    // and the box under PO#. For the phone's request that closes a Repair Order left open in COSTAR first
    // (RoEngine.CloseFirst): which one it was, and whether it is an online order's.
    internal static class RoPeek {
        internal sealed class Seen { internal string Doc,Po; }
        internal static Seen Read(IntPtr window) {
            var s=new List<ControlInfo>();
            try {
                Native.Rect rb;if(!Native.GetWindowRect(window,out rb)) return new Seen();
                // COSTAR answering at once, or nothing is read (as the runner's reads: a busy COSTAR isn't
                // asked again and again); the first read that fails ends the reading.
                UIntPtr answer;if(Native.SendNull(window,0,UIntPtr.Zero,IntPtr.Zero,0x0002,250,out answer)==IntPtr.Zero) return new Seen();
                uint owner=Native.Pid(window);var handles=new List<IntPtr>();bool failed=false;
                Native.EnumChildWindows(window,delegate(IntPtr h,IntPtr unused) { if(Native.Pid(h)==owner&&Native.IsWindowVisible(h)) handles.Add(h);return handles.Count<4000; },IntPtr.Zero);
                foreach(var h in handles) {
                    Native.Rect box;if(!Native.GetWindowRect(h,out box)) continue;
                    var c=new ControlInfo {Handle=h.ToInt64(),Root=window.ToInt64(),Parent=Native.GetParent(h).ToInt64(),Class=Native.Class(h),Style=Native.GetWindowLong(h,-16),Visible=true,Enabled=Native.IsWindowEnabled(h),
                        Bounds=new[]{box.Left,box.Top,box.Right-box.Left,box.Bottom-box.Top},RelativeBounds=new[]{box.Left-rb.Left,box.Top-rb.Top,box.Right-box.Left,box.Bottom-box.Top},TextState="not-read"};
                    c.Password=c.Class.IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)>=0&&(c.Style&0x20)!=0;
                    string t;
                    if(c.Static&&!failed) { if(Native.TryText(h,out t)) { c.Text=t;c.TextState="read"; } else failed=true; }
                    s.Add(c);
                }
                if(failed) return new Seen();
            } catch(Exception) { return new Seen(); }
            return Find(s,delegate(ControlInfo c) { string t;return c.TextState=="read"?c.Text:!c.Password&&Native.TryText(new IntPtr(c.Handle),out t)?t:null; });
        }
        // The number beside the RepairOrder label (a label or a box: Runner.NumberBox) and the box under PO#.
        // text: a control's words (read on demand).
        internal static Seen Find(List<ControlInfo> s,Func<ControlInfo,string> text) {
            var seen=new Seen();
            try { var box=Runner.NumberBox(s);if(box!=null) { string t=Order.Clean(text(box));if(Regex.IsMatch(t,@"^\d{4,}$")) seen.Doc=t; } } catch(InvalidOperationException) { }
            try { var box=Selectors.Under(s,Selectors.Label(s,"PO#",0));string t=text(box);if(t!=null) seen.Po=Order.Clean(t); } catch(InvalidOperationException) { }
            return seen;
        }
    }
    // When the list must be searched (COSTAR reading its Work-in-Progress again) before a Repair Order is
    // opened from it (2.6.1): when it shows nothing, when the Repair Order isn't in it, or when it may be
    // listed but finished meanwhile: Order Check's recent copy (read with Search) doesn't have it, or there
    // is no recent copy that has it and nobody pressed Search in this COSTAR for 10 minutes.
    internal static class WipSearch {
        internal static readonly TimeSpan Trusted=TimeSpan.FromMinutes(10);
        internal static bool Needed(bool empty,bool found,bool? inRecentCopy,TimeSpan? sinceSearch) {
            if(empty||!found||inRecentCopy==false) return true;
            if(inRecentCopy==true) return false;
            return sinceSearch==null||sinceSearch.Value>Trusted;
        }
        static readonly Dictionary<string,long> last=new Dictionary<string,long>(StringComparer.Ordinal);
        static readonly Stopwatch clock=Stopwatch.StartNew();   // not the wall clock (it can be set back)
        static string Key(CostarInstance t) { return t.Pid.ToString(CultureInfo.InvariantCulture)+":"+t.Started.ToString(CultureInfo.InvariantCulture); }
        internal static void Pressed(CostarInstance t) { lock(last) last[Key(t)]=clock.ElapsedMilliseconds; }
        internal static TimeSpan? Since(CostarInstance t) { long at;lock(last) return last.TryGetValue(Key(t),out at)?TimeSpan.FromMilliseconds(clock.ElapsedMilliseconds-at):(TimeSpan?)null; }
    }

    // What an open does on the screen while it brings a row into view (2.6.1): COSTAR's own list
    // (CostarWipScreen), or a made-up one in the self-tests.
    internal interface IWipScreen {
        Native.Rect Box();                    // the list's place on the screen
        bool ListAt(Native.Point p);          // the list itself is under that point
        bool ListHasKeyboard();               // the list itself (not a box inside it) has the keyboard
        string KeyboardAt();                  // what has the keyboard, for the day log (a window's class)
        void Ready();                         // nobody used the PC since the open began; COSTAR in front
        void Click(Native.Point p);           // checked again just before: no key held, nobody, the list there
        void PastClick();                     // waits until a click now can't make a double click with the last
        void Wheel(Native.Point p,int notches);
        void GiveKeyboard();                  // 2.6.5: the keyboard to the list directly (no click)
        bool Activate(WipScan scan,string doc); // 2.6.5: the wanted row made the active row directly (its "Activate")
        void Say(string words);
        WipScan Scan(string doc);             // the list read again
        string DocAt(Native.Point p,WipScan scan); // the number accessibility says is at that point (null: can't tell)
    }
    internal sealed class CostarWipScreen : IWipScreen {
        readonly IntPtr main,grid;readonly RoOpenWatch watch;readonly string doc;readonly Func<bool> cancelled;readonly Action<string> say;
        readonly Stopwatch sinceClick=new Stopwatch();
        internal CostarWipScreen(IntPtr main,IntPtr grid,RoOpenWatch watch,string doc,Func<bool> cancelled,Action<string> say) { this.main=main;this.grid=grid;this.watch=watch;this.doc=doc;this.cancelled=cancelled;this.say=say; }
        public Native.Rect Box() { Native.Rect box;Order.Require(Native.GetWindowRect(grid,out box),"COSTAR's Work-in-Progress list is gone.");return box; }
        public bool ListAt(Native.Point p) { return Native.WindowFromPoint(p)==grid; }
        public bool ListHasKeyboard() { return Native.Focus(main)==grid; }
        public string KeyboardAt() { var f=Native.Focus(main);return f==IntPtr.Zero?"nothing in COSTAR":Native.Class(f)+(RoWip.Inside(f,grid)?" inside the list":""); }
        public void Ready() { Order.Require(!cancelled(),"Stopped.");RoWip.Quiet(watch,doc);RoWip.Front(main,cancelled); }
        public void Click(Native.Point p) { PastClick();Native.NoModifiers();RoWip.Quiet(watch,doc);Order.Require(ListAt(p),"COSTAR's Work-in-Progress list is covered.");Native.ClickNow(p);sinceClick.Restart(); }
        public void PastClick() { if(!sinceClick.IsRunning) return;int wait=Native.DoubleClickMs()+60-(int)sinceClick.ElapsedMilliseconds;if(wait>0) Thread.Sleep(Math.Min(wait,2000)); }
        public void Wheel(Native.Point p,int notches) { Native.NoModifiers();RoWip.Quiet(watch,doc);Order.Require(ListAt(p),"COSTAR's Work-in-Progress list is covered.");Native.WheelStepsNow(p,notches); }
        public void GiveKeyboard() { RoWip.Quiet(watch,doc);Direct.Focus(grid,3000,cancelled); }
        // The row looked up afresh and its "Activate" pressed on a thread of its own, with the last look (COSTAR's
        // main window in front and free, nobody at the PC) just before it (RoWip.Activated: what came of it).
        public bool Activate(WipScan scan,string wanted) {
            RoWip.Quiet(watch,doc);
            var act=Direct.Act(delegate(out object child,out string why) { child=null;return scan.FreshTargetRow(out why); },delegate {
                if(Native.GetForegroundWindow()!=main||!Native.IsWindowEnabled(main)) return RoWip.MainNotFree;
                if(Native.UserActiveWithin(1500)) return Direct.PcInUse;
                return null;
            });
            return RoWip.Activated(act,Direct.Went(act,5000,400),watch,wanted);
        }
        public void Say(string words) { say(words); }
        public WipScan Scan(string wanted) { return WipScan.Take(grid,wanted); }
        public string DocAt(Native.Point p,WipScan scan) { return RoWip.DocAt(p,scan.DocIndex); }
    }

    // COSTAR's Work-in-Progress list in the selected COSTAR: read it, find a document in it, open it.
    // Reads through accessibility (as Order Check does); the only input is Search (pressed through
    // accessibility, and only when the row isn't listed), the mouse wheel over the list (with one click on
    // a row when the list doesn't have the keyboard), and the double click (or Enter) that opens a row.
    internal static class RoWip {
        static TempeOrderCheck.WipHandles Screen(CostarInstance t,out IntPtr main) {
            main=CostarWindows.Main(t);
            var h=TempeOrderCheck.WipScreen.Locate(main);
            Order.Require(h!=null,"COSTAR "+t.Label+" isn't showing Work-in-Progress. Leave it on Work-in-Progress.");
            return h;
        }
        static string Money(decimal total) { return "$"+total.ToString("0.00",CultureInfo.InvariantCulture); }
        static RoListRow Row(TempeOrderCheck.WipRow r) {
            return new RoListRow {doc=r.Doc,date=r.OrderDateText,name=r.Name,total=r.HasTotal?Money(r.Total):"",shipVia=r.ShipVia,comment=r.Comment,by=r.By,po=r.Po,status=r.Status};
        }
        // The list as COSTAR shows it now. search: press Search first (the newest list). clear (2.6.11): COSTAR's
        // own search boxes emptied first (its Clear button), so a filter left on the PC doesn't hide Repair Orders.
        internal static RoList ReadList(CostarInstance t,bool search,bool clear,Func<bool> cancelled) {
            IntPtr main;var h=Screen(t,out main);
            var notes=new List<string>();
            if(clear&&search) {
                string boxes;string before=KnownFilter(h,cancelled,out boxes);
                if(before==null) notes.Add("COSTAR didn't answer when its search boxes were looked at, so its filter wasn't cleared: try again");
                else if(before.Length==0) notes.Add("COSTAR's Work-in-Progress wasn't filtered");
                else if(h.Clear==IntPtr.Zero||h.Search==IntPtr.Zero) notes.Add("COSTAR's filter ("+before+") wasn't cleared: its "+(h.Clear==IntPtr.Zero?"Clear":"Search")+" button wasn't found. Clear it at the PC");
                else {
                    string why=ClearFilter(h,cancelled);
                    AppLog.Note("ro_filter_cleared",(why==null?"for the list: ":"not cleared for the list ("+why+"): ")+boxes);
                    notes.Add(why==null?"COSTAR's filter cleared ("+before+")":"COSTAR's filter ("+before+") wasn't cleared: "+why+". Clear it at the PC");
                }
            }
            if(search&&h.Search!=IntPtr.Zero) { PressSearch(h,cancelled);WipSearch.Pressed(t); }
            else notes.Add(search?"COSTAR's Search button wasn't found, so the list is as COSTAR showed it":"read as COSTAR showed it (a Repair Order is open there)");
            var reader=new TempeOrderCheck.GridReader();
            var rows=reader.Read(h.Grid);
            string unused;string filter=KnownFilter(h,cancelled,out unused);
            if(filter==null) notes.Insert(0,"COSTAR didn't answer when its search boxes were looked at (the list may be filtered)");
            else if(filter.Length>0) notes.Insert(0,"COSTAR's Work-in-Progress is filtered ("+filter+")");
            return new RoList {rows=rows.Select(Row).ToList(),readUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture),source="costar",note=String.Join("; ",notes.ToArray())};
        }
        // Order Check's last read of its own WIP window, if it is recent: the list when COSTAR is busy.
        internal static RoList FromOrderCheck(TimeSpan maxAge) {
            var store=TempeOrderCheck.Hosting.Store;if(store==null) return null;
            Dictionary<string,object> root;
            try { root=new System.Web.Script.Serialization.JavaScriptSerializer {MaxJsonLength=16*1024*1024}.DeserializeObject(Encoding.UTF8.GetString(store.Snapshot())) as Dictionary<string,object>; }
            catch(Exception) { return null; }
            if(root==null||Field(root,"state")!="ok") return null;
            DateTimeOffset at;
            if(!DateTimeOffset.TryParse(Field(root,"readAt"),CultureInfo.InvariantCulture,DateTimeStyles.None,out at)||DateTimeOffset.Now-at>maxAge) return null;
            object rowsValue;var rows=root.TryGetValue("rows",out rowsValue)?rowsValue as System.Collections.IEnumerable:null;
            if(rows==null) return null;
            var list=new List<RoListRow>();
            foreach(object o in rows) {
                var r=o as Dictionary<string,object>;if(r==null) continue;
                decimal total;bool has=Field(r,"hasTotal")=="True"&&Decimal.TryParse(Field(r,"total"),NumberStyles.Number,CultureInfo.InvariantCulture,out total);
                list.Add(new RoListRow {doc=Field(r,"doc"),date=Field(r,"orderDateText"),name=Field(r,"name"),total=has?Money(Decimal.Parse(Field(r,"total"),NumberStyles.Number,CultureInfo.InvariantCulture)):"",
                    shipVia=Field(r,"shipVia"),comment=Field(r,"comment"),by=Field(r,"by"),po=Field(r,"po"),status=Field(r,"status")});
            }
            string filter=Field(root,"filter");
            return new RoList {rows=list,readUtc=at.UtcDateTime.ToString("o",CultureInfo.InvariantCulture),source="order-check",note="Order Check's list from "+at.ToString("HH:mm",CultureInfo.InvariantCulture)+(filter.Length>0?" (filtered: "+filter+")":"")};
        }
        // Whether Order Check's copy from the last 3 minutes lists `doc` (null: no such copy). A filtered copy
        // proves nothing either way.
        internal static bool? InRecentCopy(string doc) {
            var copy=FromOrderCheck(TimeSpan.FromMinutes(3));
            if(copy==null||copy.note.Contains("(filtered:")) return null;
            string want=Order.Norm(doc);
            return copy.rows.Any(r=>Order.Norm(r.doc)==want);
        }
        static string Field(Dictionary<string,object> d,string key) { object v;return d!=null&&d.TryGetValue(key,out v)&&v!=null?Convert.ToString(v,CultureInfo.InvariantCulture):""; }
        // Search through accessibility on its own thread (COSTAR may take seconds), then a list that
        // holds still (two equal row counts).
        // 2.6.11: COSTAR's Clear (Alt+L) pressed through accessibility, as Search is; null when its search boxes
        // then read empty (within 3 s), else why not (for the person; never the search's words). Nothing else is
        // pressed. ready: the caller's own look, on every pass of the wait and just before the press (the open's:
        // nobody at the PC since it began, which stops the open).
        internal static string ClearFilter(TempeOrderCheck.WipHandles h,Func<bool> cancelled,Action ready=null) {
            if(h.Clear==IntPtr.Zero) return "COSTAR's Clear button wasn't found";
            // Never while someone is typing in those boxes: a quiet moment (nobody at the PC for 3 s) waited for, up to
            // ClearQuietWaitMs; none comes, nothing is pressed.
            var quiet=Stopwatch.StartNew();
            while(Native.UserActiveWithin(RoEngine.CloseQuietSeconds*1000)) {
                Order.Require(!cancelled(),"Stopped.");
                if(ready!=null) ready();
                if(quiet.ElapsedMilliseconds>=ClearQuietWaitMs) { AppLog.Note("ro_filter_clear_failed","someone is using the PC: "+Native.LastInputSeen());return "someone is using the PC"; }
                Thread.Sleep(200);
            }
            Order.Require(!cancelled(),"Stopped.");
            if(ready!=null) ready();
            string error=PressButton(h.Clear,5000);
            // Not answered: it may still go, so nothing more is read or pressed (as for Search).
            Order.Require(error==null||!error.StartsWith("COSTAR didn't answer",StringComparison.Ordinal),"COSTAR didn't answer its Work-in-Progress Clear within 5 s. Is a window open in COSTAR?");
            if(error!=null) { AppLog.Note("ro_filter_clear_failed",error);return "COSTAR's Clear couldn't be pressed"; }
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<3000) {
                Order.Require(!cancelled(),"Stopped.");
                if(TempeOrderCheck.WipScreen.FilterTextKnown(h)=="") return null;
                Thread.Sleep(200);
            }
            AppLog.Note("ro_filter_clear_failed","the search boxes didn't read empty within 3 s of Clear");
            return "COSTAR's search boxes didn't empty after Clear";
        }
        // What COSTAR's search boxes hold, looked at again for up to 2 s while a box doesn't answer; null: still
        // unknown. boxes: the filled boxes' names alone (for the day log).
        internal static string KnownFilter(TempeOrderCheck.WipHandles h,Func<bool> cancelled,out string boxes) {
            var timer=Stopwatch.StartNew();
            while(true) {
                string f=TempeOrderCheck.WipScreen.FilterTextKnown(h,out boxes);
                if(f!=null||timer.ElapsedMilliseconds>=2000) return f;
                Order.Require(!cancelled(),"Stopped.");
                Thread.Sleep(200);
            }
        }
        internal const int ClearQuietWaitMs=10000;
        // A button's accessibility default action (Press) on a thread of its own; null, or why it couldn't be.
        static string PressButton(IntPtr button,int ms) {
            string error=null;
            var th=new Thread(delegate() {
                Accessibility.IAccessible b=null;
                try { b=Msaa.FromWindow(button);b.accDoDefaultAction(0); }
                catch(Exception e) { error=e.Message; }
                finally { Msaa.Release(b); }
            });
            th.IsBackground=true;th.SetApartmentState(ApartmentState.MTA);th.Start();
            if(!th.Join(ms)) return "COSTAR didn't answer the press within "+(ms/1000)+" s";
            return error;
        }
        static void PressSearch(TempeOrderCheck.WipHandles h,Func<bool> cancelled) {
            string error=PressButton(h.Search,20000);
            Order.Require(error==null||!error.StartsWith("COSTAR didn't answer",StringComparison.Ordinal),"COSTAR didn't finish its Work-in-Progress search within 20 s. Is a window open in COSTAR?");
            Order.Require(error==null,"Couldn't press Search in COSTAR's Work-in-Progress: "+error);
            var reader=new TempeOrderCheck.GridReader();var timer=Stopwatch.StartNew();int last=-2;
            while(timer.ElapsedMilliseconds<8000) {
                Order.Require(!cancelled(),"Stopped.");
                Thread.Sleep(400);
                int count=reader.TableRowCount(h.Grid);
                if(count>=0&&count==last) return;
                last=count;
            }
        }
        // In view and clickable: the Document # cell inside the list, below its column headings and clear of
        // its edges (its scroll bars are drawn inside it), and the list itself under that point.
        internal static bool InView(IWipScreen screen,WipScan scan,WipScan.Line s) {
            if(s==null||!s.Placed||s.Height<=4||s.Width<=4) return false;
            var box=screen.Box();var p=Point(s);
            return s.Top>=Math.Max(box.Top+2,scan.ViewTop(box))&&s.Top+s.Height<=box.Bottom-20&&p.X>box.Left+2&&p.X<box.Right-24&&screen.ListAt(p);
        }
        internal static Native.Point Point(WipScan.Line s) { return new Native.Point {X=s.Left+Math.Min(s.Width/2,40),Y=s.Top+s.Height/2}; }
        internal static void Front(IntPtr main,Func<bool> cancelled) {
            Native.BringToFront(main);var timer=Stopwatch.StartNew();
            while(!cancelled()&&Native.GetForegroundWindow()!=main&&timer.ElapsedMilliseconds<2000) Thread.Sleep(25);
            Order.Require(!cancelled(),"Stopped.");
            Order.Require(Native.GetForegroundWindow()==main&&Native.IsWindowEnabled(main),"COSTAR's main window couldn't be brought in front (another window is open in COSTAR?).");
        }
        internal static bool Inside(IntPtr h,IntPtr parent) { for(var p=h;p!=IntPtr.Zero;p=Native.GetParent(p)) if(p==parent) return true;return false; }
        internal const string MainNotFree="COSTAR's main window isn't in front and free";
        // 2.6.5: what came of the row's "Activate" (went: Direct.Went's answer). True: pressed. False: not pressed or
        // failed (activating a row opens nothing, so the mouse way may follow). The last look's no stops the open
        // there, as Quiet does: someone at the PC (marked, so a window that opens meanwhile is never taken for
        // the helper's), or COSTAR's main window not in front and free.
        internal static bool Activated(Direct.Pending act,string went,RoOpenWatch watch,string doc) {
            if(went=="pressed") return true;
            string refused=act.Refused;
            if(refused==Direct.PcInUse) {
                if(watch!=null) watch.UserActive=true;
                AppLog.Note("ro_user_active",doc+": at the last look before Activate, "+Native.LastInputSeen());
                throw new InvalidOperationException("Someone used the COSTAR PC while Repair Order "+doc+" was being opened, so the helper stopped there (nothing more clicked or pressed). Try again when the PC is free.");
            }
            if(refused!=null) throw new InvalidOperationException("COSTAR's main window wasn't in front and free when Repair Order "+doc+" was to be opened (a COSTAR window open?). Nothing was pressed: check COSTAR, then try again.");
            AppLog.Note("ro_open_direct",doc+": its row wasn't made the active one ("+(went=="failed"?act.PressError:act.FindError)+")");
            return false;
        }
        // 2.6.5 (no mouse): the wanted row made the list's selected row and its active row through accessibility
        // (selected, then its "Activate" pressed with the last look just before it; it may stay out of view:
        // Enter doesn't need it in view), and the list given the keyboard directly. True when a read with new
        // objects then shows that row still that Repair Order, the active row (Enter opens the active row: it
        // carries the keyboard's mark, or it alone offers no "Activate") and the only selected one, with the list
        // holding the keyboard (Tommy, 27 Oct: Enter opens it). False: the mouse way (Reveal, the double click).
        internal static bool SelectForEnter(IWipScreen screen,ref WipScan scan,string doc,RoOpenTimes times) {
            var clock=Stopwatch.StartNew();
            try {
                for(int attempt=1;attempt<=2;attempt++) {
                    screen.Ready();
                    scan.SelectTarget();
                    // Its "Activate" pressed only while it offers it (the selection may have made it the active row
                    // already: then there is nothing to press).
                    if(scan.TargetAction()!=""&&!screen.Activate(scan,doc)) return false;
                    Thread.Sleep(150);
                    if(!screen.ListHasKeyboard()) {
                        screen.GiveKeyboard();
                        var wait=Stopwatch.StartNew();
                        while(!screen.ListHasKeyboard()&&wait.ElapsedMilliseconds<800) Thread.Sleep(40);
                        if(!screen.ListHasKeyboard()) { AppLog.Note("ro_open_direct",doc+": the list didn't take the keyboard ("+screen.KeyboardAt()+")");return false; }
                    }
                    ReadAgain(screen,ref scan,doc,times);
                    if(scan.TargetStill()&&scan.TargetActive()&&scan.OnlyTargetSelected()&&screen.ListHasKeyboard()) { times.How="made the active row directly";times.Direct=true;return true; }
                }
                AppLog.Note("ro_open_direct",doc+": its row didn't become the active and only selected one");
                return false;
            } finally { times.RevealMs+=clock.ElapsedMilliseconds; }
        }
        // Brings the wanted row into view (2.6.1): nothing when it is in view already; else it is selected
        // through accessibility (the list may scroll to it by itself); else the mouse wheel over the list.
        // The wheel goes a notch at first (to see how many rows a notch moves), then as many notches a turn as
        // bring the row to the middle of the view (WipScroll.Turn: 20 at most, never past the list's end).
        // After each turn the list must have moved by exactly all of it and held still before anything else
        // happens, so no notch is ever still on its way (COSTAR, or the remote desktop, can be slow to pass
        // them on); if it hasn't within its time, or moved otherwise, the helper stops there and opens
        // nothing. The wheel is turned only while the list itself has the keyboard (one click on a row in view
        // gives it), so it can't turn anything else of COSTAR's. Returns whether the list may have moved.
        internal static bool Reveal(IWipScreen screen,ref WipScan scan,string doc,RoOpenTimes times) {
            var clock=Stopwatch.StartNew();
            try {
                if(InView(screen,scan,scan.TargetLine)) { times.How="in view";return false; }
                scan.SelectTarget();Thread.Sleep(150);
                if(!scan.Places(screen.Box())) ReadAgain(screen,ref scan,doc,times);
                if(InView(screen,scan,scan.TargetLine)) { times.How="in view once selected";return true; }
                screen.Say("Scrolling COSTAR's Work-in-Progress list to Repair Order "+doc+".");
                var box=screen.Box();
                var center=new Native.Point {X=(box.Left+box.Right)/2,Y=(box.Top+box.Bottom)/2};
                int perNotch=0,clicks=0;bool fresh=false;
                for(int step=0;step<WipScroll.MaxSteps&&clock.ElapsedMilliseconds<WipScroll.MaxRevealMs;step++) {
                    screen.Ready();
                    Order.Require(screen.ListAt(center),"COSTAR's Work-in-Progress list is covered.");
                    if(!screen.ListHasKeyboard()) {
                        Order.Require(clicks<2,"COSTAR's Work-in-Progress list doesn't keep the keyboard, so the list wasn't scrolled. Open Repair Order "+doc+" by hand.");
                        var any=scan.NearestMiddle(box);
                        Order.Require(any!=null&&InView(screen,scan,any),"COSTAR's Work-in-Progress list shows no row to click, so it wasn't scrolled. Open Repair Order "+doc+" by hand.");
                        // Its Document # cell: a click there only selects the row.
                        screen.Click(Point(any));clicks++;times.Clicked=true;
                        var waiting=Stopwatch.StartNew();
                        while(!screen.ListHasKeyboard()&&waiting.ElapsedMilliseconds<1000) Thread.Sleep(50);
                        if(!screen.ListHasKeyboard()) {
                            string at=screen.KeyboardAt();AppLog.Note("ro_wip_keyboard","after a click on a row: "+at);
                            throw new InvalidOperationException("COSTAR's Work-in-Progress list didn't take the keyboard ("+at+" has it), so it wasn't scrolled. Open Repair Order "+doc+" by hand.");
                        }
                    }
                    int? from=scan.ScrollRow(box);
                    Order.Require(from!=null,"COSTAR's Work-in-Progress list shows no row in view, so it wasn't scrolled. Open Repair Order "+doc+" by hand.");
                    int rows=(scan.First+scan.Last)/2-scan.Target;       // + : the row is above the middle (wheel up)
                    if(rows==0) break;
                    // room 0: the row is at an edge of the view, partly hidden (one notch, if the list still goes).
                    bool up=rows>0;int room=scan.Room(up);
                    int notches=WipScroll.Turn(Math.Abs(rows),perNotch,room);
                    int expect=WipScroll.Expect(notches,perNotch,room);
                    screen.Wheel(center,up?notches:-notches);times.Wheels++;times.Notches+=notches;
                    int moved=AwaitMoved(screen,ref scan,doc,times,from.Value,up?notches:-notches,expect,800+150*notches,ref fresh);
                    // Not all of it seen with these objects: once more with new ones (old ones may keep answering
                    // with the places they had); from then on every look is with new objects.
                    if(moved<0&&!fresh) { fresh=true;moved=AwaitMoved(screen,ref scan,doc,times,from.Value,up?notches:-notches,expect,0,ref fresh); }
                    if(moved<0&&room==0) break;
                    Order.Require(moved>=0,"COSTAR's Work-in-Progress list didn't scroll as far as it was turned (it may still be on its way). Nothing was opened; try again.");
                    int next=WipScroll.Accounted(perNotch,moved,notches,room);
                    Order.Require(next>=0,"COSTAR's Work-in-Progress list scrolled "+moved+" rows for "+notches+" wheel notches, not what they should move. Nothing was opened; try again.");
                    perNotch=next;
                    box=screen.Box();
                    if(InView(screen,scan,scan.TargetLine)) { times.How=times.Wheels==1?"brought into view with one wheel turn":"brought into view with "+times.Wheels+" wheel turns";return true; }
                }
                throw new InvalidOperationException("Repair Order "+doc+"'s row couldn't be brought into view in COSTAR's Work-in-Progress list. Open it by hand.");
            } finally { times.RevealMs+=clock.ElapsedMilliseconds; }
        }
        // The point to double-click (2.6.1), after the row is in view: first everything that takes time
        // before the click (`beforeLastLook`: COSTAR in front, its windows looked at; the double-click time
        // waited out), then the last looks: when the list moved or was searched, read again with new objects
        // and watched holding still for 200 ms; the row at that place among the list's children looked at with
        // new objects (still this Repair Order, at the same place); its cell read twice 150 ms apart.
        internal static Native.Point Aim(IWipScreen screen,ref WipScan scan,string doc,RoOpenTimes times,bool searched,Action beforeLastLook) {
            bool moved=Reveal(screen,ref scan,doc,times);
            if(beforeLastLook!=null) beforeLastLook();
            screen.PastClick();
            var box=screen.Box();
            if(moved||searched) {
                ReadAgain(screen,ref scan,doc,times);
                string places=scan.Signature();Thread.Sleep(200);scan.Places(box);
                Order.Require(scan.Signature()==places,"COSTAR's Work-in-Progress list was still moving. Nothing was opened; try again.");
            }
            scan.PlaceTarget();
            string fresh=scan.FreshCheck();
            if(fresh!=null) { ReadAgain(screen,ref scan,doc,times);scan.PlaceTarget();fresh=scan.FreshCheck(); }
            Order.Require(fresh==null,"Repair Order "+doc+"'s row in COSTAR's Work-in-Progress list didn't look the same when looked at again ("+fresh+"). Nothing was opened; try again.");
            var x=scan.TargetLine;int top=x.Top;bool placed=x.Placed;
            Thread.Sleep(150);scan.PlaceTarget();
            Order.Require(x.Placed==placed&&x.Top==top&&scan.TargetStill()&&InView(screen,scan,x),"Repair Order "+doc+"'s row moved in the list. Nothing was opened; try again.");
            return Point(x);
        }
        // Just before the double click: what accessibility finds at the point is not another Repair Order (it
        // may not tell: then the looks before stand).
        internal static void CheckPoint(IWipScreen screen,Native.Point point,WipScan scan,string doc,RoOpenTimes times) {
            string under=screen.DocAt(point,scan);times.Hit=under==null?"can't tell":under==doc?"this one":"another";
            Order.Require(under==null||under==doc,"Accessibility found Repair Order "+under+" under the point, not "+doc+". Nothing was opened; try again.");
        }
        // The Repair Order number accessibility finds at a point: a Document # cell there (or a row, through its
        // Document # cell); null when it can't tell (it names the list itself, or something else).
        internal static string DocAt(Native.Point p,int docIndex) {
            object child;var a=Msaa.FromPoint(p,out child);Accessibility.IAccessible cell=null;object c=null;
            try {
                if(a==null) return null;
                int id=child is int?(int)child:0;
                if(id!=0) {
                    // A simple child: its own role, name and value.
                    object r=null;try { r=a.get_accRole(id); } catch(Exception) { r=null; }
                    if(!(r is int)||(int)r!=29) return null;
                    string name="",value="";try { name=Convert.ToString(a.get_accName(id),CultureInfo.InvariantCulture)??"";value=Convert.ToString(a.get_accValue(id),CultureInfo.InvariantCulture)??""; } catch(Exception) { return null; }
                    return name.Trim()=="Document #"?Order.Norm(value):null;
                }
                int role=Msaa.Role(a);
                if(role==29) return Msaa.NameOf(null,a).Trim()=="Document #"?Order.Norm(Msaa.ValueOf(null,a)):null;
                if(role==Msaa.RoleRow&&docIndex>=0) {
                    try { c=a.get_accChild(docIndex+1); } catch(Exception) { c=null; }
                    cell=c as Accessibility.IAccessible;
                    return cell!=null&&Msaa.NameOf(a,cell).Trim()=="Document #"?Order.Norm(Msaa.ValueOf(a,cell)):null;
                }
                return null;
            } catch(Exception) { return null; }
            finally { Msaa.Release(c);Msaa.Release(a); }
        }
        // After `notches` wheel notches (+ up, - down) from scroll row `from`: waits until the list has moved
        // at least `expect` rows the way it was turned and then held still for 150 ms, so all of that turn has
        // come through and no notch is still on its way. `limitMs` for that, and a further 1.5 s of stillness
        // short of it means the rest isn't coming. Returns the rows moved, or -1 (not all of it came, or it
        // went the other way). Each look is with the objects of the last read, or (fresh, or once no row has a
        // place any more: the rows were made again) a new read; the list must stay the same list.
        static int AwaitMoved(IWipScreen screen,ref WipScan scan,string doc,RoOpenTimes times,int from,int notches,int expect,int limitMs,ref bool fresh) {
            var timer=Stopwatch.StartNew();var still=Stopwatch.StartNew();string last=null;int count=scan.Lines.Count,target=scan.Target;
            while(timer.ElapsedMilliseconds<limitMs+1500) {
                Thread.Sleep(40);
                var box=screen.Box();
                if(fresh) ReadAgain(screen,ref scan,doc,times);
                else if(!scan.Places(box)) { fresh=true;ReadAgain(screen,ref scan,doc,times); }
                Order.Require(scan.Lines.Count==count&&scan.Target==target,"COSTAR's Work-in-Progress list changed while it was scrolled. Nothing was opened; try again.");
                int? at=scan.ScrollRow(box);if(at==null) continue;
                int delta=at.Value-from;
                if(notches>0?delta>0:delta<0) return -1;
                int moved=Math.Abs(delta);var x=scan.TargetLine;
                string now=at.Value.ToString(CultureInfo.InvariantCulture)+"|"+(x!=null&&x.Placed?x.Top.ToString(CultureInfo.InvariantCulture):"-");
                if(now!=last) { last=now;still.Restart();continue; }
                if(moved>=expect&&still.ElapsedMilliseconds>=150) return moved;
                if(timer.ElapsedMilliseconds>=limitMs&&still.ElapsedMilliseconds>=1500) return -1;
            }
            return -1;
        }
        // The list read again (new objects); the wanted row must still be in it.
        static void ReadAgain(IWipScreen screen,ref WipScan scan,string doc,RoOpenTimes times) {
            scan.Dispose();scan=null;scan=screen.Scan(doc);times.Took(scan);
            Order.Require(scan.Target>=0,"Repair Order "+doc+" went from COSTAR's Work-in-Progress list. Nothing was opened.");
        }
        // Nobody has used the PC since the open began (the helper's own clicks and keys don't count):
        // checked before every click, scroll and key, so nothing goes in under a person's hands.
        internal static void Quiet(RoOpenWatch watch,string doc) {
            if(!Native.UserActiveWithin((int)Math.Min(600000,watch.Clock.ElapsedMilliseconds+1000))) return;
            watch.UserActive=true;
            // 2.6.6: what was seen, for the day log (28 Oct: a stop while COSTAR took 12 s to open one).
            AppLog.Note("ro_user_active",doc+": "+Native.LastInputSeen()+", "+watch.Clock.ElapsedMilliseconds+" ms into the open");
            throw new InvalidOperationException("Someone used the COSTAR PC while Repair Order "+doc+" was being opened, so the helper stopped there (nothing more clicked or pressed). Try again when the PC is free.");
        }
        // Every Repair Order window of this COSTAR, shown or not yet (COSTAR may build one before it shows).
        static HashSet<long> AllOrders(CostarInstance t) {
            CostarWindows.Main(t);var set=new HashSet<long>();
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) { if(Native.Pid(w)==t.Pid&&Native.Caption(w).StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase)) set.Add(w.ToInt64());return true; },IntPtr.Zero);
            return set;
        }
        // Opens `doc` from the list (2.6.1): the list read once; Search first only when it is needed
        // (WipSearch); its row brought into view and aimed at (Aim); a double click on its Document # cell;
        // if nothing opens, Enter on it once it is the selected row (Tommy, 27 Oct: both work). Nobody may use
        // the PC meanwhile (checked before every click, wheel turn and key). Returns the new Repair Order
        // window; row: its row's values as listed; selected: it was the list's selected row after; times:
        // how long each part took.
        internal static IntPtr Open(CostarInstance t,string doc,Func<bool> cancelled,Action<string> say,RoOpenWatch watch,RoOpenTimes times,out RoListRow row,out bool selected) {
            row=null;selected=false;var total=Stopwatch.StartNew();WipScan scan=null;
            try {
                IntPtr main;var h=Screen(t,out main);
                Order.Require(CostarWindows.Orders(t).Count==0,"A Repair Order is open in COSTAR "+t.Label+". Close it first.");
                watch.Before=AllOrders(t);
                Quiet(watch,doc);Front(main,cancelled);
                say("Looking for Repair Order "+doc+" in COSTAR's Work-in-Progress.");
                try { scan=WipScan.Take(h.Grid,doc);times.Took(scan); } catch(WipScan.NoTable) { scan=null; }
                bool? inCopy=InRecentCopy(doc);bool searched=false;
                if(h.Search!=IntPtr.Zero&&WipSearch.Needed(scan==null||scan.Lines.Count==0,scan!=null&&scan.Target>=0,inCopy,WipSearch.Since(t))) {
                    if(scan!=null) { scan.Dispose();scan=null; }
                    var searching=Stopwatch.StartNew();PressSearch(h,cancelled);WipSearch.Pressed(t);times.SearchMs=searching.ElapsedMilliseconds;searched=true;
                    scan=WipScan.Take(h.Grid,doc);times.Took(scan);
                    // Not there after a Search: once more reading every cell, before saying it isn't listed.
                    if(scan.Target<0&&scan.OneCell) { scan.Dispose();scan=null;scan=WipScan.Take(h.Grid,doc,true);times.Took(scan); }
                }
                Order.Require(scan!=null,"COSTAR's Work-in-Progress list isn't showing a table. Press Search in COSTAR.");
                // 2.6.11: not listed while COSTAR's own search boxes hold a filter (2 Nov 09:50, 10:10: a 2-row list after a
                // search at the PC): the filter cleared, Search pressed, and looked for again.
                string boxes="",filter="";
                if(scan.Target<0) filter=KnownFilter(h,cancelled,out boxes)??"";
                if(filter.Length>0&&h.Search!=IntPtr.Zero) {
                    // A stop names the boxes only: its words go to the day log and the run report, the search's words don't.
                    Order.Require(h.Clear!=IntPtr.Zero,"Repair Order "+doc+" isn't in COSTAR "+t.Label+"'s Work-in-Progress list, which is filtered at the PC ("+boxes+"), and COSTAR's Clear button wasn't found. Clear it at the PC (Clear, then Search), then try again.");
                    say("COSTAR's Work-in-Progress is filtered ("+filter+"): clearing it to find Repair Order "+doc+".");
                    Order.Require(!cancelled(),"Stopped.");
                    Quiet(watch,doc);   // nobody at the PC since the open began, as before every press here
                    string why=ClearFilter(h,cancelled,delegate{Quiet(watch,doc);});
                    AppLog.Note("ro_filter_cleared",(why==null?"for open ":"not cleared for open ")+doc+(why==null?"":" ("+why+")")+": "+boxes);
                    Order.Require(why==null,"Repair Order "+doc+" isn't in COSTAR "+t.Label+"'s Work-in-Progress list, which is filtered at the PC ("+boxes+"), and the filter couldn't be cleared ("+why+"). Clear it at the PC (Clear, then Search), or try again.");
                    // Said with whatever comes next (opened, or stopped): the person's search at the PC was emptied.
                    times.FilterCleared=true;times.Filter=filter;
                    scan.Dispose();scan=null;
                    Quiet(watch,doc);
                    var searching=Stopwatch.StartNew();PressSearch(h,cancelled);WipSearch.Pressed(t);times.SearchMs=Math.Max(0L,times.SearchMs)+searching.ElapsedMilliseconds;searched=true;
                    scan=WipScan.Take(h.Grid,doc);times.Took(scan);
                    if(scan.Target<0&&scan.OneCell) { scan.Dispose();scan=null;scan=WipScan.Take(h.Grid,doc,true);times.Took(scan); }
                }
                Order.Require(scan.Target>=0,"Repair Order "+doc+" isn't in COSTAR "+t.Label+"'s Work-in-Progress list (finished, or filtered out?).");
                row=scan.TargetRow();
                var screen=new CostarWipScreen(main,h.Grid,watch,doc,cancelled,say);
                // 2.6.5: no mouse first: the row selected and made the active one through accessibility, the list
                // given the keyboard directly, then Enter (checked as the Enter of 2.6.1 is, and the row checked again
                // right before it). Nothing opened: the mouse way below.
                if(Direct.On) {
                    IntPtr opened=OpenDirect(t,h,main,screen,ref scan,doc,cancelled,say,watch,times,out selected);
                    if(opened!=IntPtr.Zero) return opened;
                    times.Direct=false;times.How="";
                }
                var point=Aim(screen,ref scan,doc,times,searched,delegate {
                    Quiet(watch,doc);Front(main,cancelled);
                    Order.Require(AllOrders(t).SetEquals(watch.Before),"COSTAR opened a window while its list was being scrolled. Nothing was double-clicked: check COSTAR.");
                    say("Opening Repair Order "+doc+".");
                });
                // The last looks were just now; then at once: no key held, nobody, COSTAR in front, the list under
                // the point, and what accessibility finds at the point not another Repair Order.
                Native.NoModifiers();Quiet(watch,doc);
                Order.Require(Native.GetForegroundWindow()==main&&Native.WindowFromPoint(point)==h.Grid,"COSTAR's Work-in-Progress list was covered just before the double click. Nothing was opened; try again.");
                CheckPoint(screen,point,scan,doc,times);
                var opening=Stopwatch.StartNew();
                Native.DoubleClickNow(point);
                IntPtr window=WaitForWindow(t,watch,main,doc,cancelled);
                if(window==IntPtr.Zero) {
                    // Read again (new objects): Enter opens the selected row, so it must be this one, and only it.
                    ReadAgain(screen,ref scan,doc,times);
                    Order.Require(scan.OnlyTargetSelected(),"Repair Order "+doc+" didn't open with a double click, and its row isn't the one selected. Open it by hand.");
                    Quiet(watch,doc);Front(main,cancelled);
                    Order.Require(Native.Focus(main)==h.Grid,"COSTAR's Work-in-Progress list doesn't have the keyboard, so Enter isn't pressed. Open Repair Order "+doc+" by hand.");
                    // Pressed only with COSTAR idle (WaitForWindow), its main window in front, the list holding
                    // the keyboard and no Repair Order window being built: the key can't reach anything else.
                    Order.Require(Native.GetForegroundWindow()==main&&AllOrders(t).SetEquals(watch.Before),"COSTAR changed before Enter could be pressed. Nothing was pressed; try again.");
                    AppLog.Note("ro_open_enter",doc+": the double click opened nothing; Enter on the selected row");
                    Native.NoModifiers();Quiet(watch,doc);
                    Order.Require(Native.GetForegroundWindow()==main&&Native.Focus(main)==h.Grid,"COSTAR changed before Enter could be pressed. Nothing was pressed; try again.");
                    opening.Restart();
                    Native.KeyNow(13);
                    window=WaitForWindow(t,watch,main,doc,cancelled);
                    Order.Require(window!=IntPtr.Zero,"Repair Order "+doc+" didn't open (a double click and Enter were tried). Open it by hand.");
                }
                times.WindowMs=opening.ElapsedMilliseconds;
                int after=scan.TargetState();
                selected=after>=0&&(after&0x6)!=0;
                return window;
            } finally { if(scan!=null) scan.Dispose();times.TotalMs=total.ElapsedMilliseconds; }
        }
        // 2.6.5: Enter on the row made the active and only selected one (SelectForEnter), with the same checks as
        // the Enter of 2.6.1: COSTAR idle and in front, the list holding the keyboard, no Repair Order window being
        // built, nobody at the PC; and the row looked at once more right before Enter. Zero when that can't be
        // done or nothing opened (then the mouse way).
        static IntPtr OpenDirect(CostarInstance t,TempeOrderCheck.WipHandles h,IntPtr main,IWipScreen screen,ref WipScan scan,string doc,Func<bool> cancelled,Action<string> say,RoOpenWatch watch,RoOpenTimes times,out bool selected) {
            selected=false;
            Quiet(watch,doc);Front(main,cancelled);
            Order.Require(AllOrders(t).SetEquals(watch.Before),"COSTAR opened a window before Repair Order "+doc+" was opened. Nothing was pressed: check COSTAR.");
            if(!SelectForEnter(screen,ref scan,doc,times)) return IntPtr.Zero;
            say("Opening Repair Order "+doc+".");
            Quiet(watch,doc);Front(main,cancelled);
            Order.Require(Native.GetForegroundWindow()==main&&AllOrders(t).SetEquals(watch.Before),"COSTAR changed before Enter could be pressed. Nothing was pressed; try again.");
            // The last look, right before Enter: still that Repair Order, the active row and the only selected one.
            Order.Require(scan.TargetStill()&&scan.TargetActive()&&scan.OnlyTargetSelected(),"Repair Order "+doc+"'s row changed in the list before Enter. Nothing was pressed; try again.");
            Native.NoModifiers();Quiet(watch,doc);
            Order.Require(Native.GetForegroundWindow()==main&&Native.Focus(main)==h.Grid,"COSTAR changed before Enter could be pressed. Nothing was pressed; try again.");
            var opening=Stopwatch.StartNew();
            Native.KeyNow(13);
            IntPtr window=WaitForWindow(t,watch,main,doc,cancelled);
            if(window==IntPtr.Zero) { AppLog.Note("ro_open_direct",doc+": Enter on its row opened nothing; the mouse way");return IntPtr.Zero; }
            times.WindowMs=opening.ElapsedMilliseconds;
            // Not taken as a sign it is that Repair Order: the helper made it so (the opened one is still checked
            // by its number, or its name, comment, PO# and total all as listed).
            selected=false;
            return window;
        }
        // The Repair Order window that wasn't there before, once it has stayed the same for 300 ms. A
        // COSTAR message box shown instead stops it: nothing is pressed in it. A person using the PC
        // meanwhile stops it too (their window could be the next one). Zero only when nothing opened, no
        // new Repair Order window is being built (even hidden), and COSTAR has answered at once for 3 s
        // in a row, at least 8 s after the click (30 s at most): a slow COSTAR still opening it is
        // waited for, so nothing is ever pressed into a late window.
        static IntPtr WaitForWindow(CostarInstance t,RoOpenWatch watch,IntPtr main,string doc,Func<bool> cancelled) {
            var timer=Stopwatch.StartNew();var settle=Stopwatch.StartNew();IntPtr candidate=IntPtr.Zero;int idle=0;
            while(timer.ElapsedMilliseconds<30000) {
                Order.Require(!cancelled(),"Stopped while Repair Order "+doc+" was opening. Check COSTAR.");
                Quiet(watch,doc);
                var building=AllOrders(t).Where(x=>!watch.Before.Contains(x)).ToList();
                var fresh=CostarWindows.Orders(t).Where(x=>!watch.Before.Contains(x.ToInt64())).ToList();
                Order.Require(fresh.Count<=1,"More than one Repair Order opened in COSTAR "+t.Label+". Check COSTAR.");
                if(fresh.Count==1) {
                    Order.Require(Branches.OrderTitle(Native.Caption(fresh[0]),t.Branch),"The Repair Order that opened is not in "+t.Label+".");
                    if(fresh[0]==candidate&&settle.ElapsedMilliseconds>=300) return fresh[0];
                    if(fresh[0]!=candidate) { candidate=fresh[0];settle.Restart(); }
                    idle=0;
                } else {
                    candidate=IntPtr.Zero;
                    var fg=Native.GetForegroundWindow();
                    if(fg!=IntPtr.Zero&&fg!=main&&Native.Pid(fg)==t.Pid&&Native.Class(fg)=="#32770"&&timer.ElapsedMilliseconds>=300) Question(fg,doc);
                    UIntPtr result;
                    bool answering=building.Count==0&&fg==main&&Native.SendNull(main,0,UIntPtr.Zero,IntPtr.Zero,0x0002,500,out result)!=IntPtr.Zero;
                    idle=answering?idle+1:0;
                    if(timer.ElapsedMilliseconds>=8000&&idle>=60) return IntPtr.Zero;
                }
                Thread.Sleep(50);
            }
            Order.Require(AllOrders(t).SetEquals(watch.Before),"Repair Order "+doc+" took more than 30 s to open. Check COSTAR.");
            return IntPtr.Zero;
        }
        // A COSTAR message box instead of the Repair Order: read (for the phone), never answered.
        static void Question(IntPtr dialog,string doc) {
            var words=new List<string>();var buttons=new List<string>();
            Native.EnumChildWindows(dialog,delegate(IntPtr h,IntPtr unused) {
                if(!Native.IsWindowVisible(h)) return true;
                string cls=Native.Class(h),text;if(!Native.TryText(h,out text)) return true;
                if(cls.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0) buttons.Add(Order.Norm(text).Replace("&",""));
                else if(cls.IndexOf("STATIC",StringComparison.OrdinalIgnoreCase)>=0&&Order.Clean(text).Length>0) words.Add(Order.Clean(text));
                return words.Count+buttons.Count<40;
            },IntPtr.Zero);
            string said=EbayText.Clean(String.Join(" ",words.ToArray()),300).Replace("\"","'");
            AppLog.Note("ro_open_question",doc+": a COSTAR message box, buttons "+String.Join("/",buttons.ToArray()));
            throw new InvalidOperationException("COSTAR showed a message instead of opening Repair Order "+doc+(said.Length>0?": \""+said+"\"":"")+". Nothing was answered: answer it at the PC (COSTAR may then open the Repair Order: check it there).");
        }
    }

    internal sealed class RoEngine : IDisposable {
        readonly EntryCoordinator coordinator;readonly WorkerSettings settings;readonly string journalPath;readonly object gate=new object();readonly Action<string> log;
        RoJournal state;volatile Runner runner;volatile bool disposed,busy;int started;
        internal volatile bool Enabled;
        // How long nobody may have used the PC before a phone's request starts in COSTAR. 2.6.7 (Tommy, 28 Oct
        // 15:34: "change all idle time to 3 seconds", "when its waiting for costar to be ready"): 3 s (it was 10 s).
        internal const int QuietSeconds=3,TempeBranch=11;
        internal volatile string Connection="Desk PC: connecting ...",Detail="",Current="",LastLine="";
        volatile int lastContactTick;internal volatile int RoundTripMs=-1;
        internal int SecondsSinceContact { get { int t=lastContactTick;return t==0?-1:unchecked(Environment.TickCount-t)/1000; } }
        volatile HttpWebRequest pending;volatile bool interrupted;readonly AutoResetEvent wake=new AutoResetEvent(false);
        readonly Stopwatch progressClock=Stopwatch.StartNew();
        // COSTAR checked again at most every 3 s (a window scan).
        DateTime checkedAt=DateTime.MinValue;bool lastFree;string lastWhy="";
        internal bool Busy {get{return busy;}}
        // 2.6.7 (Tommy, 28 Oct 15:11: "if I'm trying to access it through phone but the pc is opening a repair
        // order, close that repair order so I can access it on the phone"): a Repair Order open in COSTAR Tempe
        // is closed first when the phone asks to open, change or print one, with COSTAR's own close (nothing
        // saved, sold or printed: it stays in Work-in-Progress), once nobody has used the PC for
        // CloseQuietSeconds and COSTAR isn't asking anything on it. Never one held for a person to finish: a
        // phone job's or an online order's (HeldForReview), or one whose PO# is an online order's.
        internal const int CloseQuietSeconds=3;   // Tommy, 28 Oct 15:34: every wait for COSTAR to be ready 3 s
        // The Repair Order windows other work leaves open for a person (set by the helper's window). Null: no
        // Repair Order is closed for the phone at all (as before 2.6.7).
        internal volatile Func<HashSet<long>> HeldForReview;
        // What was read of each open Repair Order (its number and PO#), kept a minute: read only when it may
        // be closed (nobody at the PC, nothing held), so COSTAR isn't asked while someone works in it.
        readonly Dictionary<long,KeyValuePair<DateTime,RoPeek.Seen>> peeked=new Dictionary<long,KeyValuePair<DateTime,RoPeek.Seen>>();
        // The Repair Order this helper left open after a change stopped ("" when none), for the window.
        internal string LeftOpen { get { lock(gate) return state.leftOpen==null?"":state.leftOpen.doc; } }
        // 2.6.10: a new phone job closed this Repair Order window first (WorkerEngine.CloseOpenFirst): if it is the one
        // this helper left open, it's no longer open.
        internal void ForgetLeftOpen(long window) { lock(gate) { if(state.leftOpen!=null&&state.leftOpen.window==window) { state.leftOpen=null;Save(); } } }
        internal RoEngine(WorkerSettings config,string folder,Action<string> notify,EntryCoordinator entries) {
            coordinator=entries;NetworkRules.Worker(config);settings=config;log=notify;journalPath=Path.Combine(folder,"ro-journal.dat");
            try { state=PrivateFiles.Load<RoJournal>(journalPath); }
            catch(Exception e) {
                try{File.Copy(journalPath,journalPath+".unreadable-"+DateTime.Now.ToString("yyyyMMdd-HHmmss"),true);}catch(Exception){}
                AppLog.Note("ro_journal_unreadable",e.GetType().Name);state=null;
            }
            // A new journal counts its reports on from the time, so they come after any earlier one's.
            if(state==null) state=new RoJournal {sequence=(int)Math.Min(Int32.MaxValue/2,Math.Max(0,(DateTime.UtcNow-new DateTime(2026,1,1,0,0,0,DateTimeKind.Utc)).TotalSeconds))};
            var lost=state.running;
            if(lost!=null) {
                state.running=null;
                // Its Repair Order still open (the same window in the same COSTAR): remembered as left
                // open, typed into or not, so it can be closed from the phone; never closed here.
                bool open=false;
                try {
                    var h=new IntPtr(lost.window);ProcessIdentity identity;
                    open=lost.window!=0&&Native.IsWindow(h)&&(int)Native.Pid(h)==lost.processId&&Native.Caption(h).StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase)
                        &&LocalProcess.IsNamed(lost.processId,"COSTAR",out identity)&&identity.Started==lost.processStart;
                } catch(Exception) { open=false; }
                if(open) state.leftOpen=new RoLeftOpen {doc=lost.doc,window=lost.window,processId=lost.processId,processStart=lost.processStart,atUtc=lost.atUtc};
                string why=lost.touched?"The RDP helper closed while changing Repair Order "+lost.doc+". Check it in COSTAR Tempe"+(open?" (it is still open there: close it there or from the phone)":"")+" before trying again."+(lost.printing?" Its Job Card may have printed: check the printer.":"")
                    :lost.printing?"The RDP helper closed while printing the Job Card of Repair Order "+lost.doc+": it may have printed. Check the printer before printing it again."+(open?" It is still open in COSTAR Tempe: close it there or from the phone.":"")
                    :open?"The RDP helper closed while Repair Order "+lost.doc+" was open (nothing was typed). It is still open in COSTAR Tempe: close it there or from the phone."
                    :"The RDP helper closed while doing this. Try again.";
                try { Report(lost.id,lost.lease,"failed",why,"",lost.touched,open); } catch(Exception) { }
            }
            Enabled=AppSettings.Current.roOn;
        }
        static string Now { get { return DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture); } }
        // 2.6.2: when this helper last printed (or may have printed) each Repair Order's Job Card.
        readonly Dictionary<string,DateTime> printedAt=new Dictionary<string,DateTime>();
        internal static readonly TimeSpan PrintAgainAfter=TimeSpan.FromMinutes(2);
        string RecentPrint(string doc) {
            DateTime at;lock(gate) if(!printedAt.TryGetValue(doc,out at)) return null;
            var ago=DateTime.UtcNow-at;if(ago>=PrintAgainAfter||ago<TimeSpan.Zero) return null;
            return "Job Card not printed: one for Repair Order "+doc+" went to the printer "+(int)ago.TotalSeconds+" s ago. Check the printer; print it again after 2 minutes if it isn't there.";
        }
        void Save() { lock(gate) PrivateFiles.Save(journalPath,state); }
        void Running(RoAttempt attempt) { lock(gate) { state.running=attempt;Save(); } }
        // Under gate: the next report (the desk acknowledges it by its sequence).
        void SetReport(string id,string lease,string status,string message,string progress,bool typed,bool leftOpen,RoSnapshot snapshot=null,RoList list=null,List<string> notes=null) {
            state.sequence++;
            state.report=new RoReport {id=id,lease=lease,status=status,message=EbayText.Clean(message,2000),progress=EbayText.Clean(progress,1000),sequence=state.sequence,typed=typed,leftOpen=leftOpen,snapshot=snapshot,list=list,notes=notes};
        }
        void Report(string id,string lease,string status,string message,string progress,bool typed,bool leftOpen,RoSnapshot snapshot=null,RoList list=null,List<string> notes=null) {
            lock(gate) { SetReport(id,lease,status,message,progress,typed,leftOpen,snapshot,list,notes);Save(); }
            if(status!="working"||(progress??"").Length==0) { Detail=message;log(message); }
            Interrupt();
        }
        volatile string declineLease,declineReason;
        void Decline(string lease,string why) { declineReason=EbayText.Clean(why,400);declineLease=lease;Detail=why;Interrupt(); }
        internal void Start() {
            if(disposed) return;
            if(!AppSettings.Current.roOn){AppSettings.Current.roOn=true;AppSettings.Current.Save();}
            bool was=Enabled;Enabled=true;AppLog.Note("ro_start","");Connect();if(!was)Interrupt();
        }
        // persist: the Repair Orders switch itself. Stop all entry only pauses.
        internal void Stop(bool persist) {
            if(persist&&AppSettings.Current.roOn){AppSettings.Current.roOn=false;AppSettings.Current.Save();}
            bool was=Enabled;Enabled=false;var active=runner;if(active!=null)active.Cancel=true;
            if(was){AppLog.Note("ro_stop",persist?"switched off":"stop all");Interrupt();}
        }
        internal void Connect(){if(disposed)return;if(Interlocked.Exchange(ref started,1)!=0)return;var t=new Thread(Loop);t.IsBackground=true;t.Start();}
        void Interrupt(){interrupted=true;var r=pending;if(r!=null){try{r.Abort();}catch(Exception){}}wake.Set();}
        // Whether a Repair Order may be opened in the selected COSTAR now, and why not. openAllowed: a
        // Repair Order may already be open (closing the one this helper left open).
        bool Free(out string detail,bool openAllowed=false) {
            if(!Enabled) { detail="Repair Orders are switched off on the RDP helper";return false; }
            if(coordinator.Busy) { detail=coordinator.Owner+" is filling COSTAR";return false; }
            if(coordinator.MobilePaused) { detail="Waiting: the Online orders tab is open on the RDP helper";return false; }
            var t=coordinator.Selected;
            if(t==null) { detail="No COSTAR is selected in the RDP helper";return false; }
            if(t.Branch!=TempeBranch) { detail="The selected COSTAR is "+t.Label+": Repair Orders from the phone are COSTAR Tempe's (Branch "+TempeBranch+"). Select COSTAR Tempe in the RDP helper";return false; }
            if(OrderCheckLink.IsWipWindow(t)) { detail="The selected COSTAR is Order Check's Work-in-Progress window";return false; }
            if(CostarInputLock.LegacyOpen()) { detail="Close the original online-order helper";return false; }
            if(Native.UserActiveWithin(QuietSeconds*1000)) { detail="Waiting for a quiet moment: someone is using the COSTAR PC";return false; }
            if(!openAllowed) {
                if(DateTime.UtcNow-checkedAt<TimeSpan.FromSeconds(3)) { detail=lastWhy;return lastFree; }
                string d;bool free=CostarWindows.Available(t,out d);
                // 2.6.7: open Repair Orders that may be closed first don't hold the phone up (CloseFirst).
                if(!free&&d.StartsWith("A Repair Order is open",StringComparison.Ordinal)) free=CloseFirst(t,out d);
                checkedAt=DateTime.UtcNow;lastFree=free;lastWhy=free&&d.StartsWith("Selected COSTAR ready",StringComparison.Ordinal)?"COSTAR "+t.Label+" is free":d;
                detail=lastWhy;return free;
            }
            detail="COSTAR "+t.Label+" ready";return true;
        }
        // 2.6.7: whether every Repair Order open in COSTAR t may be closed for the phone now; why: what the
        // phone is told (the Repair Order is open, and why it stays, or that it will be closed first).
        bool CloseFirst(CostarInstance t,out string why) {
            string start="A Repair Order is open in COSTAR "+t.Label;
            Func<HashSet<long>> provider=HeldForReview;HashSet<long> held=null;
            try { if(provider!=null) held=provider(); } catch(Exception) { held=null; }
            if(held==null) { why=start+": close it (or finish the phone job waiting for review) first";return false; }
            var open=CostarWindows.Orders(t);
            if(open.Count==0) { why="COSTAR "+t.Label+" is free";return true; }
            bool quiet=!Native.UserActiveWithin(CloseQuietSeconds*1000);
            var seen=new List<RoPeek.Seen>();
            foreach(var w in open) {
                bool isHeld=held.Contains(w.ToInt64());string blocker=Runner.CloseBlocker(w);
                // The looks that need no reading first: nothing of the Repair Order is read while it is held,
                // COSTAR is asking something on it, or someone uses the PC.
                string keep=KeepOpen(isHeld,blocker,quiet,null);
                if(keep!=null) { why=start+": "+keep;return false; }
                var one=Peeked(w);
                keep=KeepOpen(false,null,true,one);
                if(keep!=null) { why=start+(one.Doc!=null?" (RO "+one.Doc+")":"")+": "+keep;return false; }
                seen.Add(one);
            }
            why="COSTAR "+t.Label+" ready: "+(seen.Count==1?"Repair Order"+(seen[0].Doc!=null?" "+seen[0].Doc:"")+" is open there and will be closed first":seen.Count+" Repair Orders are open there and will be closed first");
            return true;
        }
        // 2.6.7: why an open Repair Order stays open for the phone (null: it may be closed first). held: other
        // work left it open for a person (a phone job's, an online order's); blocker: COSTAR is asking
        // something on it (Runner.CloseBlocker); quiet: nobody has used the PC for CloseQuietSeconds; seen:
        // what was read of it (null: not read yet: the looks that need no reading only). Its PO# must have
        // been read, and not be an online order's (after a restart the Online orders tab no longer knows its
        // Repair Orders).
        internal static string KeepOpen(bool held,string blocker,bool quiet,RoPeek.Seen seen) {
            if(held) return "it is a phone job's or an online order's, waiting for review. Finish it at the PC first";
            if(blocker!=null) return blocker+". Answer it at the PC first";
            if(!quiet) return "it will be closed once nobody has used the PC for "+CloseQuietSeconds+" s";
            if(seen==null) return null;
            if(seen.Po==null) return "COSTAR didn't answer when it was looked at. Close it at the PC, or try again";
            if(OnlineOrderPo.IsMatch(seen.Po)) return "it is online order "+Order.Norm(seen.Po)+"'s, maybe waiting for review. Finish or close it at the PC first";
            return null;
        }
        static readonly Regex OnlineOrderPo=new Regex(@"^TTW\d{4,}$",RegexOptions.IgnoreCase);
        RoPeek.Seen Peeked(IntPtr w) {
            long key=w.ToInt64();KeyValuePair<DateTime,RoPeek.Seen> kept;
            lock(gate) {
                if(peeked.TryGetValue(key,out kept)&&DateTime.UtcNow-kept.Key<TimeSpan.FromMinutes(1)) return kept.Value;
                if(peeked.Count>20) peeked.Clear();
            }
            var one=RoPeek.Read(w);
            if(one.Po!=null) lock(gate) peeked[key]=new KeyValuePair<DateTime,RoPeek.Seen>(DateTime.UtcNow,one);   // a failed read is tried again
            return one;
        }
        // 2.6.7: right before the phone's request opens anything, the Repair Orders open in COSTAR t closed, each
        // looked at again just before its close (nothing held, COSTAR asking nothing, nobody at the PC for
        // CloseQuietSeconds, its PO# not an online order's). Returns what the phone is told (empty: none was
        // open). Stops the request when one stays open.
        string CloseOpenFirst(RoTask task,CostarInstance t) {
            var open=CostarWindows.Orders(t);
            if(open.Count==0) return "";
            Func<HashSet<long>> provider=HeldForReview;HashSet<long> held=null;
            try { if(provider!=null) held=provider(); } catch(Exception) { held=null; }
            Order.Require(held!=null,"A Repair Order is open in COSTAR "+t.Label+". Close it first.");
            var closed=new List<string>();
            foreach(var w in open) {
                if(!Native.IsWindow(w)) continue;
                lock(gate) peeked.Remove(w.ToInt64());   // read afresh
                string keep=KeepOpen(held.Contains(w.ToInt64()),Runner.CloseBlocker(w),!Native.UserActiveWithin(CloseQuietSeconds*1000),null);
                var one=keep==null?Peeked(w):new RoPeek.Seen();
                if(keep==null) keep=KeepOpen(false,null,true,one);
                string name="Repair Order"+(one.Doc!=null?" "+one.Doc:"");
                Order.Require(keep==null,"A Repair Order is open in COSTAR "+t.Label+(one.Doc!=null?" (RO "+one.Doc+")":"")+": "+keep+".");
                // Said to the phone at once (not held back as progress is), so it shows which one goes.
                string closing="Closing "+name+", which was open in COSTAR "+t.Label+", before "+(task.kind=="edit"?"changing":task.kind=="print"?"printing the Job Card of":"opening")+" Repair Order "+task.doc+".";
                log("RO: "+closing);Detail=closing;progressClock.Restart();
                try { Report(task.id,task.lease,"working",closing,closing,false,false); } catch(Exception) { }
                bool shut=CloseWindow(w);
                AppLog.Note("ro_close_first",(one.Doc??"a Repair Order")+(shut?" closed":" still open")+" for "+task.kind+" "+task.doc);
                Order.Require(shut,name+" was open in COSTAR "+t.Label+" and didn't close (COSTAR may be asking something). Answer it at the PC, then try again.");
                lock(gate) { if(state.leftOpen!=null&&state.leftOpen.window==w.ToInt64()) { state.leftOpen=null;Save(); } }
                closed.Add(one.Doc!=null?"RO "+one.Doc:"a Repair Order");
            }
            return closed.Count==0?"":"Closed "+String.Join(" and ",closed.ToArray())+" first (it was open in COSTAR "+t.Label+"). ";
        }
        RoReply Request(RoHello hello) {
            var request=(HttpWebRequest)WebRequest.Create(settings.baseUrl.TrimEnd('/')+"/api/worker/v1/ro");
            request.Method="POST";request.ContentType="application/json";request.Headers["Authorization"]="Bearer "+settings.token;request.AllowAutoRedirect=false;request.Proxy=null;
            request.Timeout=8000+hello.waitMs;request.ReadWriteTimeout=8000+hello.waitMs;request.ServicePoint.Expect100Continue=false;
            request.ServerCertificateValidationCallback=delegate(object sender,X509Certificate cert,X509Chain chain,System.Net.Security.SslPolicyErrors errors) {
                if(cert==null)return false;using(var c=new X509Certificate2(cert))return DateTime.Now>=c.NotBefore&&DateTime.Now<=c.NotAfter&&Wire.Equal(Wire.Hash(c.RawData),settings.certificateHash);
            };
            byte[] bytes=Encoding.UTF8.GetBytes(Wire.Json(hello));request.ContentLength=bytes.Length;
            pending=request;
            try {
                using(var output=request.GetRequestStream())output.Write(bytes,0,bytes.Length);
                try {using(var response=request.GetResponse())using(var input=response.GetResponseStream())using(var reader=new StreamReader(input,Encoding.UTF8))return Wire.Read<RoReply>(reader.ReadToEnd());}
                catch(WebException e) {
                    if(e.Response!=null)using(var input=e.Response.GetResponseStream())using(var reader=new StreamReader(input)) {
                        string body=reader.ReadToEnd();var code=((HttpWebResponse)e.Response).StatusCode;
                        // A desk older than 2.6.0 answers this route with "key invalid" (401) or "not found".
                        if(code==HttpStatusCode.NotFound||code==HttpStatusCode.Unauthorized) throw new InvalidOperationException("The desk receiver did not take the Repair Order request ("+(int)code+"). Update the desk receiver to 2.6.0 (yellow line on the desk PC).");
                        throw new InvalidOperationException("Receiver rejected the request: "+body);
                    }
                    throw;
                }
            } finally { pending=null; }
        }
        void Loop() {
            while(!disposed) {
                bool held=false;
                try {
                    string detail;bool accepting=Enabled,available=false;
                    if(!accepting) detail="Repair Orders switched off on the RDP helper";
                    else if(busy) detail="Working on a Repair Order";
                    else available=Free(out detail);
                    string working=runLease??"";
                    RoReport report;int sequence;lock(gate){report=state.report==null?null:Wire.Copy(state.report);sequence=state.sequence;}
                    string declined=declineLease,declinedWhy=declineReason;
                    int waitMs=accepting&&!busy&&declined==null&&AppSettings.Current.longPoll?(available?8000:2000):0;
                    var clock=Stopwatch.StartNew();interrupted=false;
                    var reply=Request(new RoHello {workerId=settings.workerId,accepting=accepting,available=available,detail=EbayText.Clean(detail,400),report=report,waitMs=waitMs,working=working,declined=declined,declineReason=declinedWhy,sequence=sequence,print=true,clears=true});
                    if(declined!=null&&declineLease==declined){declineLease=null;declineReason=null;}
                    held=reply!=null&&reply.held;
                    int waited=reply==null?0:Math.Max(0,reply.waitedMs);
                    RoundTripMs=(int)Math.Max(0,clock.ElapsedMilliseconds-waited);lastContactTick=Environment.TickCount==0?1:Environment.TickCount;
                    Connection="Desk PC connected";if(!busy)Detail=detail;
                    if(reply!=null&&report!=null&&reply.ack==report.sequence) lock(gate) { if(state.report!=null&&state.report.sequence==report.sequence){state.report=null;try{Save();}catch(Exception){}} }
                    if(reply!=null&&reply.command=="do"&&reply.task!=null&&!busy&&!disposed) {
                        if(Enabled) Accept(reply.task);
                        else if(reply.task.lease!=lastStartedLease) Decline(reply.task.lease,"Repair Orders switched off on the RDP helper");
                    }
                } catch(Exception e) {
                    if(disposed) break;
                    if(interrupted){interrupted=false;continue;}
                    Connection="Desk PC not reachable: "+e.Message;AppLog.PollError("ro: "+e.Message);
                }
                if(!disposed){int ms=held?100:Enabled?2000:3000;wake.WaitOne(ms);}
            }
        }
        // The lease of the last request started: one handed back again before its result is in (the
        // report not acknowledged yet) is never started a second time.
        volatile string lastStartedLease,runLease,runId;
        void Accept(RoTask task) {
            if(String.IsNullOrWhiteSpace(task.lease)||task.lease==lastStartedLease) return;
            if(task.kind!="list") {
                if(!RoEdit.IsDoc(task.doc)) { Report(task.id,task.lease,"failed","The Repair Order number isn't valid.","",false,false);return; }
                if(task.kind=="edit") {
                    try { Order.Require(task.edit!=null&&task.edit.doc==task.doc,"The change is for another Repair Order.");task.edit.ValidateShape(); }
                    catch(InvalidOperationException e) { Report(task.id,task.lease,"failed","Not changed: "+e.Message,"",false,false);return; }
                }
            }
            if(task.kind=="close") {
                RoLeftOpen left;lock(gate) left=state.leftOpen;
                if(left==null||left.doc!=task.doc) { Report(task.id,task.lease,"failed","The RDP helper didn't leave Repair Order "+task.doc+" open. If it is open in COSTAR, close it there.","",false,false);return; }
            }
            EntryLease entry=null;
            if(task.kind!="list") {
                string detail;
                if(!Free(out detail,task.kind=="close")) { Decline(task.lease,detail);return; }
                entry=coordinator.TryBegin("Repair Order "+task.doc,true);
                if(entry==null) { Decline(task.lease,(coordinator.Owner.Length>0?coordinator.Owner:"Another entry")+" is filling COSTAR");return; }
            }
            bool startedThread=false,claimed=false;
            try {
                lock(gate) {
                    if(busy||disposed) return;
                    if(!Enabled) { Decline(task.lease,"Repair Orders switched off on the RDP helper");return; }
                    busy=true;claimed=true;runLease=task.lease;runId=task.id;lastStartedLease=task.lease;
                }
                var e2=entry;
                var thread=new Thread(delegate(){ if(task.kind=="list") RunList(task); else Run(task,e2); });
                thread.IsBackground=true;thread.SetApartmentState(ApartmentState.STA);thread.Start();startedThread=true;
            } finally { if(!startedThread){if(claimed){runLease=null;runId=null;lastStartedLease=null;busy=false;}if(entry!=null)entry.Dispose();} }
        }
        // Progress words for the phone (at most one report every 2.5 s).
        void Progress(string message) {
            log("RO: "+message);Detail=message;
            if(progressClock.ElapsedMilliseconds<2500) return;
            progressClock.Restart();
            var r=runner;string id=runId,lease=runLease;
            if(id==null||lease==null) return;
            try { Report(id,lease,"working",message,message,r!=null&&(r.Writes>0||r.Touched),false); } catch(Exception) { }
        }
        void Finish() { runLease=null;runId=null;busy=false;Current="";Interrupt(); }
        // Order Check's copy is used when it is this recent (it reads its own Tempe COSTAR every 2 minutes
        // in shop hours, pressing Search): the list comes at once and COSTAR Tempe isn't held up for it.
        // A fresh read (↻ on the phone) takes it only from the last 30 s.
        internal static readonly TimeSpan CopyAge=TimeSpan.FromMinutes(3),FreshCopyAge=TimeSpan.FromSeconds(30);
        void RunList(RoTask task) {
            try {
                Current="Work-in-Progress list";
                // 2.6.11: a clear of COSTAR's filter is always a read of COSTAR itself.
                var recent=task.clear?null:RoWip.FromOrderCheck(task.fresh?FreshCopyAge:CopyAge);
                if(recent!=null) {
                    Report(task.id,task.lease,"done",recent.rows.Count+" Repair Orders in Work-in-Progress · "+recent.note,"",false,false,null,recent);
                    LastLine="WIP list (Order Check's copy, "+recent.rows.Count+") at "+DateTime.Now.ToString("HH:mm");
                    AppLog.Note("ro_list",recent.rows.Count+" rows from "+recent.source+" (recent copy"+(task.fresh?", fresh asked":"")+")");
                    return;
                }
                Report(task.id,task.lease,"working","Reading COSTAR Tempe's Work-in-Progress","",false,false);
                RoList list=null;string why=null,detail;var t=coordinator.Selected;
                bool free=Free(out detail),freeWithOpenRo=!free&&Free(out detail,true);
                if(free||freeWithOpenRo) {
                    // With a Repair Order open nothing is pressed: the list is read as COSTAR shows it.
                    var entry=coordinator.TryBegin("Work-in-Progress list",true);
                    if(entry!=null) {
                        try {
                            // Search is pressed only with no Repair Order open now (looked at again here, not
                            // taken from the check a few seconds ago).
                            bool search=free&&CostarWindows.Orders(entry.Target).Count==0;
                            using(new CostarInputLock()) list=RoWip.ReadList(entry.Target,search,task.clear,delegate{return disposed||!Enabled;});
                            if(task.clear&&!search) list.note=(list.note.Length>0?list.note+"; ":"")+"COSTAR's filter wasn't cleared (a Repair Order is open there): close it, then try again";
                        }
                        catch(Exception e) { why=e.Message; }
                        finally { entry.Dispose(); }
                    } else why=(coordinator.Owner.Length>0?coordinator.Owner:"Another entry")+" is filling COSTAR";
                } else { Free(out detail);why=detail; }
                if(list==null) {
                    // 2.6.11: a clear asked for is never answered with a copy (nothing was cleared): it fails with why.
                    var copy=task.clear?null:RoWip.FromOrderCheck(TimeSpan.FromMinutes(15));
                    if(copy!=null) { copy.note=copy.note+(why==null?"":" (COSTAR Tempe was busy: "+why+")");list=copy; }
                }
                if(list!=null) {
                    string words=list.rows.Count+" Repair Orders in Work-in-Progress"+(String.IsNullOrEmpty(list.note)?"":" · "+list.note);
                    Report(task.id,task.lease,"done",words,"",false,false,null,list);
                    LastLine="WIP list read ("+list.rows.Count+") at "+DateTime.Now.ToString("HH:mm");
                    AppLog.Note("ro_list",list.rows.Count+" rows from "+list.source);
                } else {
                    Report(task.id,task.lease,"failed","The Work-in-Progress list couldn't be read: "+(why??(t==null?"no COSTAR is selected":"COSTAR is busy")),"",false,false);
                    AppLog.Note("ro_list_failed",why??"");
                }
            } catch(Exception e) {
                try { Report(task.id,task.lease,"failed","The Work-in-Progress list couldn't be read: "+e.Message,"",false,false); } catch(Exception) { }
            } finally { Finish(); }
        }
        static Order RoOrder(string doc) { return new Order {orderId="RO-"+doc,comment="",customer=new Customer {name="",phone=""},lines=new List<OrderLine>()}; }
        void Run(RoTask task,EntryLease entry) {
            CostarInputLock inputLock=null;var clock=Stopwatch.StartNew();string doc=task.doc;RoAttempt attempt=null;IntPtr window=IntPtr.Zero;Runner r=null;
            var watch=new RoOpenWatch();var times=new RoOpenTimes();CostarInstance target=null;PrintResult printing=null;string closedFirst="";
            string what=task.kind=="edit"?"Changing":task.kind=="close"?"Closing":task.kind=="print"?"Printing the Job Card of":"Opening";
            // 2.6.2: the Job Card printed once the Repair Order is read (print) or the change is in and checked.
            bool print=task.kind=="print"||(task.kind=="edit"&&task.edit!=null&&task.edit.print);
            try {
                Current=what+" Repair Order "+doc;progressClock.Restart();
                inputLock=new CostarInputLock();var t=entry.Target;target=t;CostarWindows.Main(t);
                coordinator.Progress.Begin("Repair Order",doc,(task.kind=="edit"?10:3)+(print?1:0));
                if(task.kind=="close") { RunClose(task,t);return; }
                // 2.6.2: a print alone right after one of this Repair Order (the desk restarted and the phone
                // asked again, say) isn't done: the first may still be on its way to the printer.
                if(task.kind=="print") {
                    string recent=RecentPrint(doc);
                    if(recent!=null) {
                        lock(gate) { SetReport(task.id,task.lease,"failed",recent,"",false,false);Save(); }
                        Detail=recent;log("RO: "+recent);Interrupt();
                        coordinator.Progress.End(false,doc+": a Job Card went moments ago");
                        AppLog.Note("ro_print_recent",doc);
                        return;
                    }
                }
                attempt=new RoAttempt {id=task.id,lease=task.lease,kind=task.kind,doc=doc,processId=t.Pid,processStart=t.Started,atUtc=Now};
                Running(attempt);
                Report(task.id,task.lease,"working",what+" Repair Order "+doc+" in COSTAR "+t.Label,"",false,false);
                AppLog.Note("ro_"+task.kind+"_start",doc+(task.kind=="edit"?" ("+task.edit.Summary()+(print?"; print the Job Card":"")+")":""));
                // 2.6.8: nothing is closed first for an open that can't happen now: COSTAR Tempe must be on
                // Work-in-Progress (RoWip.Open needs it; Free's answer may be up to 3 s old).
                string notWip=CostarWindows.WhyNotOnWip(t);
                Order.Require(notWip==null,notWip+". Nothing was closed or opened.");
                // 2.6.7: a Repair Order open in COSTAR Tempe closed first, when it may be (CloseFirst).
                closedFirst=CloseOpenFirst(task,t);
                RoListRow listed;bool selected;
                window=RoWip.Open(t,doc,delegate{return !Enabled||disposed;},Progress,watch,times,out listed,out selected);
                attempt.window=window.ToInt64();Running(attempt);
                r=new Runner(t.Pid,t.Branch,RoOrder(doc),"",false,Progress,window.ToInt64());runner=r;
                r.OnStage=coordinator.Progress.Stage;
                r.BeforeFirstWrite=delegate { if(!attempt.touched){attempt.touched=true;Running(attempt);} };
                r.Cancel=!Enabled||disposed;
                // The open from Work-in-Progress happens before the run starts: its time is the run's "open" time.
                r.Diag.OpenNewMs=times.TotalMs;r.Diag.EventRaw("ro_wip",times.ToString());
                var snap=r.ReadRo(doc,listed,selected);
                List<string> notes=new List<string>();string done="";
                if(task.kind=="edit") {
                    if(snap.sig!=task.edit.baseSig) {
                        // Someone changed it after the phone read it: nothing is typed; the phone gets what it holds now.
                        bool shut=r.CloseRo();
                        if(!shut) Left(doc,window,t);
                        lock(gate) { state.running=null;SetReport(task.id,task.lease,"failed","CHANGED: Repair Order "+doc+" changed after your phone read it, so nothing was typed. Here is what it holds now: check your changes and save again."+(shut?"":" COSTAR didn't close it (it may be asking something): close it at the PC.")+Also(SaidOnTheWay(r,times)),"",false,!shut,snap);Save(); }
                        Interrupt();coordinator.Progress.End(false,doc+" changed meanwhile");
                        AppLog.Note("ro_edit_changed",doc+" | "+times);
                        r.Diag.Completed();
                        return;
                    }
                    snap=r.EditRo(task.edit,snap);
                    // Things to check by hand only (2.6.11: what COSTAR showed on the way in goes with the words, below).
                    notes.AddRange(r.RoNotes);notes.AddRange(r.Checks);
                    done="Saved to COSTAR: "+task.edit.Summary()+".";
                    // 2.6.1: the phone hears it is in and checked now; COSTAR's close takes a second or two.
                    try { Report(task.id,task.lease,"working","All of it is in and checked. "+(print?"Printing its Job Card, then closing":"Closing")+" Repair Order "+doc+" again in COSTAR.",print?"Checked; printing the Job Card":"Checked; closing it again in COSTAR",true,false,snap,null,notes); } catch(Exception) { }
                } else if(print) {
                    notes.AddRange(r.Checks);   // a memo's words: to check by hand (the rest goes with the words, below)
                    try { Report(task.id,task.lease,"working","Read Repair Order "+doc+". Printing its Job Card.","Read; printing the Job Card",false,false,snap); } catch(Exception) { }
                } else {
                    // 2.6.11: a read shows these with the Repair Order: COSTAR's notices answered with OK on the way in
                    // (the customer's Notes; a memo's words), and a filter at the PC cleared to find it.
                    notes.AddRange(r.Notices);notes.AddRange(r.Checks);
                    if(times.FilterCleared) notes.Add(FilterClearedWords(times));
                    // 2.6.1: the phone shows the Repair Order now, while COSTAR closes it (a second or two).
                    try { Report(task.id,task.lease,"working","Read Repair Order "+doc+". Closing it again in COSTAR.","Read; closing it again in COSTAR",false,false,snap); } catch(Exception) { }
                }
                // 2.6.2: the Job Card. Never stops the rest: what happened goes with the result. Just before OK
                // the attempt notes it (a helper that closes then says the Job Card may have printed). After a
                // Stop in it, nothing more is done: the Repair Order isn't closed.
                string printWords="";
                if(print) {
                    printing=r.PrintJobCard(doc,delegate { attempt.printing=true;Running(attempt); });
                    if(printing.Printed||printing.Maybe) lock(gate) printedAt[doc]=DateTime.UtcNow;
                    printWords=printing.Words+" ";
                }
                bool printed=printing!=null&&printing.Printed,maybe=printing!=null&&printing.Maybe,stopped=printing!=null&&printing.Stopped;
                bool closed=!stopped&&r.CloseRo();
                if(!closed) Left(doc,window,t);
                string closing=stopped?"Stopped: Repair Order "+doc+" is left open in COSTAR Tempe: close it there or from the phone."
                    :closed?(task.kind=="edit"?"Closed again (it's in Work-in-Progress).":task.kind=="print"?"Closed again.":"Read and closed again.")
                    :task.kind=="edit"?"All of it is in and checked, but COSTAR didn't close the Repair Order: it may be asking something at the PC. Answer it there, then close it (or close it from the phone)."
                    :"COSTAR didn't close it again (it may be asking something at the PC): close it there or from the phone.";
                // A print-only request that surely printed nothing failed; one that may have printed didn't
                // (the phone says to check the printer, never to print again).
                string status=task.kind=="print"&&!printed&&!maybe?"failed":"done";
                // 2.6.11: a change or a print says what COSTAR showed on the way in, and a filter cleared, in its words.
                lock(gate) { state.running=null;SetReport(task.id,task.lease,status,closedFirst+(done.Length>0?done+" ":"")+printWords+closing+(task.kind=="open"?"":Also(SaidOnTheWay(r,times))),"",task.kind=="edit",!closed,snap,null,notes);Save(); }
                Detail=done.Length>0?done:print?printWords.Trim():"Read Repair Order "+doc+".";log("RO: "+Detail);Interrupt();
                r.Diag.Completed();
                string printedWords=printed?"Job Card printed":maybe?"Job Card may have printed":"Job Card not printed";
                LastLine=(task.kind=="edit"?"Changed ":task.kind=="print"?(printed?"Printed the Job Card of ":maybe?"May have printed the Job Card of ":"Didn't print the Job Card of "):"Read ")+doc+(print&&task.kind=="edit"?", "+printedWords:"")+(r.Checks.Count>0||r.RoNotes.Count>0?" (check by hand)":"")+(closed?"":" (left open)")+" at "+DateTime.Now.ToString("HH:mm");
                coordinator.Progress.End(status=="done",doc+(task.kind=="edit"?" changed":task.kind=="print"?" "+printedWords:" read")+(closed?"":", left open"));
                AppLog.Note("ro_"+task.kind+"_ok",doc+" in "+(clock.ElapsedMilliseconds/100/10.0).ToString("0.0",CultureInfo.InvariantCulture)+" s run="+r.Diag.RunId+(print?(printed?" printed":maybe?" may have printed: "+RoText.ForLog(printWords):" not printed: "+RoText.ForLog(printWords)):"")+(stopped?" stopped":"")+(notes.Count>0?" notes="+notes.Count:"")+(closed?"":" left open")+" | "+times);
            } catch(Exception e) {
                try{if(r!=null)r.Diag.Stopped(e);}catch{}
                // Typed: a write was tried (counted before it goes), not only one that went through.
                bool typed=(attempt!=null&&attempt.touched)||(r!=null&&(r.Writes>0||r.Touched)),leftOpen=false,gone=false;string extra="";
                // A Repair Order window that opened but wasn't handed over (the open stopped after it
                // appeared) is this helper's only when nobody used the PC meanwhile and it is the only one.
                if(window==IntPtr.Zero&&target!=null&&watch.Before!=null&&!watch.UserActive) {
                    try {
                        var fresh=CostarWindows.Orders(target).Where(x=>!watch.Before.Contains(x.ToInt64())).ToList();
                        if(fresh.Count==1&&Branches.OrderTitle(Native.Caption(fresh[0]),target.Branch)) window=fresh[0];
                        else if(fresh.Count>1) extra=" COSTAR opened "+fresh.Count+" Repair Order windows: check them and close them at the PC.";
                    } catch(Exception) { }
                } else if(window==IntPtr.Zero&&watch.UserActive) extra=" If a Repair Order opened, it was left as it is.";
                if(window!=IntPtr.Zero) {
                    if(Native.IsWindow(window)) {
                        bool shut=false;
                        // Closed again only when nothing was typed and no Stop was pressed; never over a COSTAR question.
                        if(!typed&&!(e is OperationCanceledException)) { try { shut=r!=null?r.CloseRo():CloseWindow(window); } catch(Exception) { shut=false; } }
                        if(!shut&&Native.IsWindow(window)) { try { Left(doc,window,entry.Target); } catch(Exception) { } leftOpen=true; }
                    } else gone=true;
                }
                string message=(e.Message.StartsWith("CHANGED:",StringComparison.Ordinal)?"":"Stopped: ")+e.Message;
                // 2.6.2: what the print came to, if it got that far.
                if(printing!=null) message+=" "+printing.Words;
                else if(attempt!=null&&attempt.printing) message+=" The Job Card may have printed: check the printer.";
                if(typed&&r!=null&&r.RoDone.Count>0) message+=" Already changed: "+String.Join("; ",r.RoDone.ToArray())+".";
                if(leftOpen) message+=" Repair Order "+doc+" is left open in COSTAR Tempe: check it there, then close it (or close it from the phone).";
                else if(typed) message+=gone?" The Repair Order was closed while the helper was typing (at the PC, or COSTAR stopped): check Repair Order "+doc+" in COSTAR Tempe.":" Check Repair Order "+doc+" in COSTAR Tempe.";
                else if(window!=IntPtr.Zero) message+=gone?" It was closed before anything was typed.":" Nothing was changed; it was closed again.";
                message+=extra;
                // 2.6.11: a filter at the PC emptied on the way, and COSTAR's notices answered, are said with a stop too.
                message+=Also(SaidOnTheWay(r,times));
                if(closedFirst.Length>0) message=closedFirst+message;
                LastLine=doc+" stopped at "+DateTime.Now.ToString("HH:mm");
                coordinator.Progress.End(false,doc+" stopped: "+e.Message);
                AppLog.Note("ro_"+task.kind+"_stopped",doc+" "+RoText.ForLog(e.Message)+(typed?" (typed)":"")+(leftOpen?" (left open)":"")+(r!=null?" run="+r.Diag.RunId:"")+(times.TotalMs>0?" | "+times:""));
                try { lock(gate) { state.running=null;SetReport(task.id,task.lease,"failed",message,"",typed,leftOpen);Save(); } Detail=message;log("RO: "+message);Interrupt(); }
                catch(Exception persist) { Enabled=false;log("RO: Repair Orders stopped: the result could not be saved. "+persist.Message); }
            } finally {
                try{if(r!=null){r.Dispose();log("RO: COSTAR report: "+r.ZipPath);}}catch(Exception){}
                finally{runner=null;try{if(inputLock!=null)inputLock.Dispose();}finally{try{entry.Dispose();}finally{Finish();}}}
            }
        }
        // 2.6.11: a person's search at the PC emptied to find the Repair Order (its words: for the phone only).
        static string FilterClearedWords(RoOpenTimes times) { return "COSTAR's Work-in-Progress was filtered at the PC ("+times.Filter+"): the filter was cleared to find this Repair Order."; }
        // What COSTAR showed on the way in (the customer's Notes answered) and a filter cleared, as words ("" none).
        static string SaidOnTheWay(Runner r,RoOpenTimes times) {
            var said=new List<string>();
            if(r!=null) said.AddRange(r.Notices);
            if(times.FilterCleared) said.Add(FilterClearedWords(times));
            return String.Join(" ",said.ToArray());
        }
        static string Also(string words) { return words.Length>0?" "+words:""; }
        // Remembered so the phone (or a person) can have it closed later.
        void Left(string doc,IntPtr window,CostarInstance t) {
            lock(gate) { state.leftOpen=new RoLeftOpen {doc=doc,window=window.ToInt64(),processId=t.Pid,processStart=t.Started,atUtc=Now};state.running=null;Save(); }
        }
        // WM_CLOSE to a Repair Order window, only while nothing of COSTAR's is open on it. 2.6.10: also for a new
        // phone job (WorkerEngine.CloseOpenFirst).
        internal static bool CloseWindow(IntPtr window) {
            if(!Native.IsWindow(window)) return true;
            if(Runner.CloseBlocker(window)!=null) return false;
            UIntPtr result;Native.WriteMessage(window,0x10,UIntPtr.Zero,null,3,1000,out result);
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<8000) { if(!Native.IsWindow(window)) return true;Thread.Sleep(100); }
            return false;
        }
        // Closes the Repair Order this helper left open (only that window, in the same COSTAR, and only
        // while COSTAR shows nothing on it).
        void RunClose(RoTask task,CostarInstance t) {
            RoLeftOpen left;lock(gate) left=state.leftOpen;
            Order.Require(left!=null&&left.doc==task.doc,"The RDP helper didn't leave Repair Order "+task.doc+" open.");
            var h=new IntPtr(left.window);
            if(!Native.IsWindow(h)||(int)Native.Pid(h)!=left.processId) {
                lock(gate) { state.leftOpen=null;SetReport(task.id,task.lease,"done","Repair Order "+task.doc+" was already closed.","",false,false);Save(); }
                coordinator.Progress.End(true,task.doc+" was already closed");
                LastLine="Already closed: "+task.doc+" at "+DateTime.Now.ToString("HH:mm");
                Interrupt();return;
            }
            Order.Require(left.processId==t.Pid&&left.processStart==t.Started&&Native.Caption(h).StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase),"That Repair Order belongs to another COSTAR. Close it at the PC.");
            string why=Runner.CloseBlocker(h);
            if(why!=null) {
                lock(gate) { SetReport(task.id,task.lease,"failed","Repair Order "+task.doc+" wasn't closed: "+why+". Answer it at the PC, then close it there (or from the phone).","",false,true);Save(); }
                coordinator.Progress.End(false,task.doc+" not closed");
                LastLine="Couldn't close "+task.doc+" at "+DateTime.Now.ToString("HH:mm");
                AppLog.Note("ro_close","blocked");
                Interrupt();return;
            }
            Progress("Closing Repair Order "+task.doc+".");
            bool shut=CloseWindow(h);
            lock(gate) {
                if(shut) state.leftOpen=null;
                SetReport(task.id,task.lease,shut?"done":"failed",shut?"Closed Repair Order "+task.doc+" (it's in Work-in-Progress).":"COSTAR didn't close Repair Order "+task.doc+": it may be asking something. Answer it at the PC.","",false,!shut);Save();
            }
            AppLog.Note("ro_close",task.doc+(shut?" closed":" still open"));
            coordinator.Progress.End(shut,task.doc+(shut?" closed":" not closed"));
            LastLine=(shut?"Closed ":"Couldn't close ")+task.doc+" at "+DateTime.Now.ToString("HH:mm");
            Interrupt();
        }
        public void Dispose(){disposed=true;Stop(false);}
    }
}
