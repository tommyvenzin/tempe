using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace TempeCostar {
    internal static class DeskActivity {
        [StructLayout(LayoutKind.Sequential)]struct InputInfo {internal uint cbSize,dwTime;}
        [DllImport("user32.dll")]static extern bool GetLastInputInfo(ref InputInfo info);
        internal static bool Idle() {var i=new InputInfo {cbSize=(uint)Marshal.SizeOf(typeof(InputInfo))};if(!GetLastInputInfo(ref i))return false;return unchecked((uint)Environment.TickCount-i.dwTime)>=30000;}
    }
    internal sealed partial class DeskForm:Form {
        readonly ReceiverSettings settings;readonly string folder,site;readonly X509Certificate2 cert;
        readonly Label chipReceiving=Ui.Chip("RECEIVING",Ui.Success),chipWorker=Ui.Chip("RDP HELPER",Ui.Muted),chipPinad=Ui.Chip("PINAD OFF",Ui.Muted);
        readonly Label headline=Ui.BigText("Starting ..."),detail=Ui.Hint("",760),updateLine=new Label {AutoSize=true,BackColor=Ui.Gold,ForeColor=Ui.Ink,Font=Ui.Bold,Padding=new Padding(10,6,10,6),Margin=new Padding(0,4,0,0),Cursor=Cursors.Hand,Visible=false};
        readonly CheckBox pinad=Ui.Check("Pinad mode: approve new jobs and continue the queue by itself",false);bool syncingPinad;
        readonly TextBox website=new TextBox {Width=520,Font=Ui.Base};
        readonly ListView jobs=new ListView {View=View.Details,FullRowSelect=true,HideSelection=false,Font=Ui.Base,MultiSelect=false,Height=260,Width=790};
        readonly Button approve=Ui.PrimaryButton("Approve selected",170),retry=Ui.SecondaryButton("Retry selected",150),next=Ui.SecondaryButton("Next Order",130),
            markDone=Ui.SecondaryButton("Mark done by hand",170),remove=Ui.DangerButton("Remove job",130),
            deleteCompleted=Ui.SecondaryButton("Hide selected",140),clearCompleted=Ui.SecondaryButton("Hide all completed",170),receiving=Ui.SecondaryButton("Stop receiving",150);
        readonly NotifyIcon tray=new NotifyIcon {Icon=SystemIcons.Application,Visible=true,Text="Tempe Mobile Job Card"};
        readonly System.Windows.Forms.Timer refresh=new System.Windows.Forms.Timer {Interval=1000};
        LocalServer server,trust;ReceiverApi api;JobQueue queue;Updater.Release updateOffer;int updateTicks;
        // 2.5.2 (25 Oct): after an update the old receiver can still hold its port for a moment; the new
        // one waits up to a minute for it instead of giving up at once.
        readonly System.Windows.Forms.Timer portRetry=new System.Windows.Forms.Timer {Interval=1000};bool serverUp,trustUp;int portWaits;
        internal DeskForm(ReceiverSettings config,string data,string sitePath) {
            settings=config;folder=data;site=sitePath;cert=Certificate(config.certificateThumbprint);
            queue=new JobQueue(PrivateFiles.Load<QueueState>(Path.Combine(folder,"queue.dat")),delegate(QueueState q){PrivateFiles.Save(Path.Combine(folder,"queue.dat"),q);});
            Text="Tempe Mobile — Desk PC Receiver | "+AutofillForm.Version;Size=new Size(860,940);MinimumSize=new Size(840,780);StartPosition=FormStartPosition.CenterScreen;Font=Ui.Base;BackColor=Ui.Canvas;
            // 2.5.0: header, then tabs (Phone jobs | eBay orders | Repair Orders since 2.6.0), then Setup.
            var root=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Padding=new Padding(12),BackColor=Ui.Canvas};
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));root.RowStyles.Add(new RowStyle(SizeType.Percent,100));root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            // Header card: chips, headline, detail, update.
            var head=Ui.Card();head.Dock=DockStyle.Top;
            var h=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Surface};
            var chips=Ui.Row(36);chipReceiving.Margin=new Padding(0,0,8,0);chipWorker.Margin=new Padding(0,0,8,0);chipPinad.Margin=new Padding(0,0,8,0);chips.Controls.Add(chipReceiving);chips.Controls.Add(chipWorker);chips.Controls.Add(chipPinad);chips.Controls.Add(chipEbay);chipEbay.Margin=new Padding(0,0,8,0);chips.Controls.Add(chipRo);
            h.Controls.Add(chips);h.Controls.Add(headline);h.Controls.Add(detail);h.Controls.Add(updateLine);
            h.Controls.Add(Ui.Hint("Phone job card: "+settings.Origin+"/Fitment_Planner.html",760));
            head.Controls.Add(h);
            // Actions row.
            var actions=Ui.Row();actions.Controls.Add(approve);actions.Controls.Add(retry);actions.Controls.Add(next);actions.Controls.Add(markDone);actions.Controls.Add(remove);
            // Jobs list.
            jobs.Columns.Add("Reference",150);jobs.Columns.Add("Customer",200);jobs.Columns.Add("Status",130);jobs.Columns.Add("Message",300);jobs.Dock=DockStyle.Fill;
            // Housekeeping + setup rows.
            var keep=Ui.Row();keep.Controls.Add(pinad);keep.Controls.Add(deleteCompleted);keep.Controls.Add(clearCompleted);
            var setup=Ui.Card();setup.Dock=DockStyle.Top;
            var s=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Surface};
            s.Controls.Add(Ui.Title("Setup"));
            var row1=Ui.Row();row1.Controls.Add(receiving);Add(row1,"Show phone QR",delegate{PairingPage();},150);Add(row1,"Export RDP connection",delegate{ExportWorker();},200);Add(row1,"Reset phone pairing",delegate{ResetPhonePairing();},180);
            var row2=Ui.Row();var webLabel=Ui.Text("Website (optional):",180);webLabel.Padding=new Padding(0,8,0,0);row2.Controls.Add(webLabel);website.Width=420;website.Text=settings.webUrl??"";row2.Controls.Add(website);var save=Ui.SecondaryButton("Save website",130);row2.Controls.Add(save);
            s.Controls.Add(row1);s.Controls.Add(row2);
            s.Controls.Add(Ui.Hint("Pinad mode: the queue continues by itself. Off: click Next Order after each review. Mark done by hand / Remove job free the queue when the RDP helper could not finish a job.",760));
            setup.Controls.Add(s);
            // Phone jobs tab: the actions, the job list and the housekeeping row, as before 2.5.0.
            var phone=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Padding=new Padding(8),BackColor=Ui.Canvas};
            phone.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            phone.RowStyles.Add(new RowStyle(SizeType.AutoSize));phone.RowStyles.Add(new RowStyle(SizeType.Percent,100));phone.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            phone.Controls.Add(actions,0,0);phone.Controls.Add(jobs,0,1);phone.Controls.Add(keep,0,2);
            var tabs=new TabControl {Dock=DockStyle.Fill,Font=Ui.Base,Margin=new Padding(0,0,0,10)};
            var phonePage=new TabPage("Phone jobs") {BackColor=Ui.Canvas};phonePage.Controls.Add(phone);
            var ebayPage=new TabPage("eBay orders") {BackColor=Ui.Canvas};ebayPage.Controls.Add(BuildEbayPage());
            // 2.6.0: Repair Orders opened and changed from the phone.
            var roPage=new TabPage("Repair Orders") {BackColor=Ui.Canvas};roPage.Controls.Add(BuildRoPage());
            tabs.TabPages.Add(phonePage);tabs.TabPages.Add(ebayPage);tabs.TabPages.Add(roPage);
            root.Controls.Add(head,0,0);root.Controls.Add(tabs,0,1);root.Controls.Add(setup,0,2);
            Controls.Add(root);
            approve.Click+=delegate{Attempt(delegate{queue.Approve(Selected());UpdateStatus();});};
            retry.Click+=delegate{Attempt(delegate{queue.Retry(Selected());UpdateStatus();});};
            next.Click+=delegate{Attempt(delegate{queue.Next();UpdateStatus();});};
            markDone.Click+=delegate{Attempt(MarkDone);};
            remove.Click+=delegate{Attempt(RemoveJob);};
            deleteCompleted.Click+=delegate {Attempt(delegate{queue.DeleteCompleted(Selected());UpdateStatus();});};
            clearCompleted.Click+=delegate {Attempt(delegate{queue.ClearCompleted();UpdateStatus();});};
            receiving.Click+=delegate{api.Receiving=!api.Receiving;AppLog.Note("receiving",api.Receiving?"on":"off");UpdateStatus();};
            jobs.SelectedIndexChanged+=delegate{UpdateButtons();};
            save.Click+=delegate {Attempt(delegate{settings.webUrl=NetworkRules.Website(website.Text);PrivateFiles.Save(Path.Combine(folder,"settings.dat"),settings);website.Text=settings.webUrl;});};
            updateLine.Click+=delegate{if(updateOffer!=null)Attempt(InstallUpdate);};
            api=new ReceiverApi(settings,queue,site,DeskActivity.Idle,Incoming);
            SetupEbay();SetupRo();
            pinad.Checked=queue.PinadMode;pinad.CheckedChanged+=delegate {if(!syncingPinad)Attempt(ChangePinadMode);};
            server=new LocalServer(settings.address,settings.port,cert,api.Handle);server.LargeBody=api.LargeBody;
            trust=new LocalServer(settings.address,settings.trustPort,null,Trust);
            Shown+=delegate {StartReceiver();};
            portRetry.Tick+=delegate {portRetry.Stop();StartReceiver();};
            refresh.Tick+=delegate{UpdateStatus();if(++updateTicks>=6*3600){updateTicks=0;CheckForUpdate();}};tray.BalloonTipClicked+=delegate{Show();WindowState=FormWindowState.Normal;Activate();};
            FormClosed+=delegate{portRetry.Dispose();refresh.Dispose();tray.Dispose();server.Dispose();trust.Dispose();cert.Dispose();};
        }
        void StartReceiver() {
            try {
                if(!serverUp) serverUp=server.TryStart();
                if(!trustUp) trustUp=trust.TryStart();
                if(serverUp&&trustUp) {
                    if(portWaits>0) AppLog.Note("receiver_port_wait",portWaits+" s");
                    refresh.Start();UpdateStatus();CheckForUpdate();return;
                }
                int port=serverUp?settings.trustPort:settings.port;
                if(++portWaits<=60) {
                    Ui.SetChip(chipReceiving,"STARTING",Ui.Warn);
                    Ui.SetText(headline,"Waiting for port "+port+" (the old receiver may still be closing) ... "+portWaits+" s");
                    portRetry.Start();return;
                }
                throw new InvalidOperationException("port "+port+" is still used by another program after a minute. Close any other Tempe Mobile receiver (Task Manager → Details → TempeMobile.exe → End task), then start this one again.");
            } catch(Exception e) {
                portRetry.Stop();api.Receiving=false;server.Dispose();trust.Dispose();
                Ui.SetChip(chipReceiving,"NOT RECEIVING",Ui.Danger);
                headline.Text="Receiver could not start: "+e.Message;MessageBox.Show(headline.Text,"Tempe Mobile");
            }
        }
        static X509Certificate2 Certificate(string thumbprint) {
            using(var store=new X509Store(StoreName.My,StoreLocation.CurrentUser)) {
                store.Open(OpenFlags.ReadOnly);var found=store.Certificates.Find(X509FindType.FindByThumbprint,thumbprint,false);
                Order.Require(found.Count==1&&found[0].HasPrivateKey&&found[0].NotAfter>DateTime.Now,"Receiver certificate is missing/expired. Run Setup-Desk.cmd under this Windows user.");return found[0];
            }
        }
        internal static void Add(FlowLayoutPanel panel,string label,Action action,int width=160) {var b=Ui.SecondaryButton(label,width);b.Click+=delegate{Attempt(action);};panel.Controls.Add(b);}
        internal static void Attempt(Action action){try{action();}catch(Exception e){MessageBox.Show(e.Message,"Tempe Mobile",MessageBoxButtons.OK,MessageBoxIcon.Information);}}
        string Selected(){Order.Require(jobs.SelectedItems.Count==1,"Select a job in the list first.");return (string)jobs.SelectedItems[0].Tag;}
        void ChangePinadMode() {
            try{queue.SetPinadMode(pinad.Checked);}
            catch{syncingPinad=true;try{pinad.Checked=queue.PinadMode;}finally{syncingPinad=false;}throw;}
            UpdateStatus();
        }
        void MarkDone() {
            string id=Selected();var job=queue.List().FirstOrDefault(j=>j.job.submissionId==id);Order.Require(job!=null,"Select a job first.");
            string text=job.job.Reference+"  |  "+job.job.customer.name+"\r\n\r\nMark this job as done by hand? Choose Yes only when its Repair Order is finished (or deliberately closed) in COSTAR.\r\n\r\nThe queue moves on and the RDP helper forgets this job's saved progress. Nothing is typed.";
            if(MessageBox.Show(this,text,"Mark done by hand",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            queue.MarkDone(id,api.Connected);AppLog.Note("desk_mark_done",job.job.Reference);api.Wake();UpdateStatus();
        }
        void RemoveJob() {
            string id=Selected();var job=queue.List().FirstOrDefault(j=>j.job.submissionId==id);Order.Require(job!=null,"Select a job first.");
            string text=job.job.Reference+"  |  "+job.job.customer.name+"\r\n\r\nRemove this job from the queue? It will not be entered. If it is half-entered in COSTAR, finish or close that Repair Order by hand.";
            if(MessageBox.Show(this,text,"Remove job",MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            queue.Remove(id,api.Connected);AppLog.Note("desk_remove_job",job.job.Reference);api.Wake();UpdateStatus();
        }
        string listSignature="";
        void UpdateStatus() {
            string selected=jobs.SelectedItems.Count==1?(string)jobs.SelectedItems[0].Tag:null;
            var receipts=queue.List().Where(x=>!x.hiddenFromList).ToList();
            var shown=receipts.Where(x=>!x.closed).Concat(receipts.Where(x=>x.closed).Reverse().Take(20)).ToList();
            // Rebuilt only when something changed, so scrolling and selection survive the 1 s tick.
            string signature=String.Join("|",shown.Select(r=>r.job.submissionId+":"+r.status+":"+r.version+":"+(r.closed?1:0)).ToArray());
            if(signature!=listSignature) {
                listSignature=signature;
                jobs.BeginUpdate();jobs.Items.Clear();
                foreach(var r in shown) {
                    string status=r.closed?"Completed":r.status.Replace('_',' ');
                    var item=new ListViewItem(new[]{r.job.Reference,r.job.customer.name,status,r.closed?"Review in COSTAR. "+r.message:r.message}){Tag=r.job.submissionId};
                    item.ForeColor=r.status=="failed"?Ui.Danger:r.status=="ready_for_review"?Ui.Success:r.status=="injecting"?Ui.Info:r.status=="awaiting_approval"?Ui.Warn:Ui.Ink;
                    jobs.Items.Add(item);
                    if(r.job.submissionId==selected)item.Selected=true;
                }
                jobs.EndUpdate();
            }
            clearCompleted.Enabled=receipts.Any(r=>r.status=="ready_for_review");
            UpdateButtons();
            bool on=api.Receiving,connected=api.Connected,accepting=api.Accepting;int since=api.SecondsSinceWorker;
            Ui.SetChip(chipReceiving,on?"RECEIVING":"RECEIVING OFF",on?Ui.Success:Ui.Danger);
            Ui.SetChip(chipWorker,connected?(accepting?"RDP HELPER: MOBILE ON":"RDP HELPER: MOBILE OFF"):"RDP HELPER OFFLINE",connected?(accepting?Ui.Success:Ui.Warn):Ui.Danger);
            Ui.SetChip(chipPinad,queue.PinadMode?"PINAD ON":"PINAD OFF",queue.PinadMode?Ui.Info:Ui.Muted);
            receiving.Text=on?"Stop receiving":"Start receiving";
            var current=queue.Current;int waiting=receipts.Count(x=>!x.closed&&(x.status=="queued"||x.status=="awaiting_approval"));
            string head=current!=null&&!current.closed?current.job.Reference+"  ·  "+current.status.Replace('_',' '):waiting>0?waiting+" job(s) waiting":"No job in progress";
            Ui.SetText(headline,head);
            string hint=api.ForgetHint;
            Ui.SetText(detail,(connected?"RDP helper in touch "+(since<=1?"now":since+" s ago"):"RDP helper not in touch"+(since>=0?" for "+since+" s":""))+"  ·  "+api.WorkerDetail+(hint.Length>0?"\r\n"+hint:""));
            if(updateLine.Visible!=(updateOffer!=null))updateLine.Visible=updateOffer!=null;
            UpdateEbay();UpdateRo();
        }
        void UpdateButtons() {
            var choice=jobs.SelectedItems.Count==1?queue.List().FirstOrDefault(j=>j.job.submissionId==(string)jobs.SelectedItems[0].Tag):null;
            approve.Enabled=choice!=null&&choice.status=="awaiting_approval";
            retry.Enabled=choice!=null&&choice.status=="failed";
            markDone.Enabled=choice!=null&&!choice.closed;
            remove.Enabled=choice!=null&&!choice.closed&&(choice.status=="awaiting_approval"||choice.status=="queued"||choice.status=="failed");
            deleteCompleted.Enabled=choice!=null&&choice.status=="ready_for_review";
            var current=queue.Current;next.Enabled=current!=null&&current.status=="ready_for_review"&&!current.closed;
        }
        void CheckForUpdate() {
            Updater.LaunchMode="Desk";
            Updater.CheckInBackground(delegate(Updater.Release found) {
                try { BeginInvoke(new Action(delegate {
                    if(updateOffer!=null && Updater.Parse(updateOffer.version)>=Updater.Parse(found.version)) return;
                    updateOffer=found;Ui.SetText(updateLine,"UPDATE "+found.version+" READY  -  CLICK HERE TO INSTALL");UpdateStatus();
                })); } catch(InvalidOperationException) { }
            });
        }
        void InstallUpdate() {
            var release=updateOffer;if(release==null)return;
            string notes=String.IsNullOrWhiteSpace(release.notes)?"":"\r\n\r\n"+release.notes;
            if(MessageBox.Show(this,"Install helper "+release.version+" on this desk PC now?"+notes+"\r\n\r\nIt is downloaded, every file is checked, then the receiver restarts into it. Phones reconnect by themselves.","Update the desk receiver",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
            AppLog.Note("update_started",release.version+" desk");
            ThreadPool.QueueUserWorkItem(delegate {
                try {
                    string target=Updater.Install(release,delegate(string message){ try{BeginInvoke(new Action(delegate{Ui.SetText(detail,message);}));}catch(InvalidOperationException){} });
                    BeginInvoke(new Action(delegate { try { Updater.RestartInto(target);Close(); } catch(Exception e) { MessageBox.Show(this,"Restart failed: "+e.Message+" Start the receiver again: it opens the new version.","Update"); } }));
                } catch(Exception e) {
                    AppLog.Note("update_failed",e.Message);
                    try { BeginInvoke(new Action(delegate{MessageBox.Show(this,"Update failed: "+e.Message,"Update");})); } catch(InvalidOperationException) { }
                }
            });
        }
        void Incoming(string id) {
            if(IsDisposed)return;try{BeginInvoke(new Action(delegate {
                var job=queue.Get(id);if(job!=null&&job.status=="awaiting_approval")tray.ShowBalloonTip(6000,"Job Card waiting","A mobile job needs approval. Open this helper and select Approve.",ToolTipIcon.Info);
                UpdateStatus();
            }));}catch(InvalidOperationException){}
        }
        // 2.5.1: the root that signed this desk's HTTPS certificate (looked up once); the setup file only
        // if it can't be found.
        byte[] trustRoot;bool trustLooked;readonly object trustGate=new object();
        byte[] TrustBytes() {
            lock(trustGate) {
                if(!trustLooked) {
                    trustLooked=true;
                    try { using(var root=TrustRoot.Of(cert,null)) { if(root!=null) { trustRoot=root.RawData;AppLog.Note("trust_root",root.Subject); } } }
                    catch(Exception e) { trustRoot=null;AppLog.Note("trust_root_missing",e.GetType().Name); }
                }
                if(trustRoot!=null) return trustRoot;
            }
            return File.ReadAllBytes(Path.Combine(folder,"Tempe-Mobile-Root.cer"));
        }
        HttpOutput Trust(HttpInput r) {
            if(r.method=="GET"&&r.path=="/trust.cer")return new HttpOutput {type="application/x-x509-ca-cert",bytes=TrustBytes()};
            return HttpOutput.Text("This port only supplies this PC's public trust certificate at /trust.cer. The order receiver uses HTTPS on port "+settings.port+".","text/plain; charset=utf-8");
        }
        void ExportWorker() {
            var connection=new WorkerSettings {baseUrl=settings.Origin,token=settings.workerToken,workerId=settings.workerId,certificateHash=Wire.Hash(cert.RawData)};
            string file=Path.Combine(folder,"worker-connection.json");File.WriteAllText(file,Wire.Json(connection),new UTF8Encoding(false));
            Process.Start("explorer.exe","/select,\""+file+"\"");
            MessageBox.Show("Copy worker-connection.json into the extracted package INSIDE RDP, then run Start-RDP.cmd there. This file contains a private pairing key; keep it off GitHub.","Connect RDP worker");
        }
        void ResetPhonePairing() {
            string previous=settings.phoneToken;settings.phoneToken=Wire.Token();
            try{PrivateFiles.Save(Path.Combine(folder,"settings.dat"),settings);}catch{settings.phoneToken=previous;throw;}
            PairingPage();MessageBox.Show("The old phone QR/key has been revoked. Scan the new Job Card QR on your phone. Existing queued jobs are kept.","Phone pairing reset");
        }
        void PairingPage() {
            string query="#pc="+Uri.EscapeDataString(settings.Origin)+"&key="+Uri.EscapeDataString(settings.phoneToken);
            string local=settings.Origin+"/Fitment_Planner.html"+query;
            string publicUrl=String.IsNullOrEmpty(settings.webUrl)?"":settings.webUrl+query;
            string certificateUrl="http://"+settings.address+":"+settings.trustPort+"/trust.cer";
            string qr;using(var reader=new StreamReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("TempeQR.js")))qr=reader.ReadToEnd();
            string links=Wire.Json(new[]{certificateUrl,local,publicUrl}).Replace("<","\\u003c").Replace(">","\\u003e").Replace("&","\\u0026");
            string html="<!doctype html><meta charset='utf-8'><title>Pair Tempe Mobile</title><style>body{font:17px system-ui;max-width:1000px;margin:30px auto;padding:20px;background:#111827;color:white}section{display:inline-block;vertical-align:top;width:290px;margin:15px}svg{display:block;background:white;width:260px;height:260px}a{color:#93c5fd;overflow-wrap:anywhere}p{line-height:1.5}</style><h1>Connect your iPhone</h1><p>Use the permitted work Wi-Fi. First install this PC's certificate, then enable full trust in Settings → General → About → Certificate Trust Settings. Only trust the certificate you created with Setup-Desk.cmd. Then scan the Job Card QR.</p><p>The local and GitHub websites have separate saved drafts. Keep using the same website for F Alt Tab and the Job Card.</p><main id='codes'></main><script>"+qr+"\nvar links="+links+";var titles=['1. Install this PC certificate','2. Open local Job Card','Or use your GitHub Job Card'];for(var i=0;i<links.length;i++){if(!links[i])continue;var s=document.createElement('section'),h=document.createElement('h2');h.textContent=titles[i];s.appendChild(h);var q=new TempeQR(-1,1);q.addData(links[i]);q.make();var n=q.getModuleCount(),svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','-4 -4 '+(n+8)+' '+(n+8));var d='';for(var y=0;y<n;y++)for(var x=0;x<n;x++)if(q.isDark(y,x))d+='M'+x+' '+y+'h1v1h-1z';var p=document.createElementNS(svg.namespaceURI,'path');p.setAttribute('d',d);svg.appendChild(p);s.appendChild(svg);var a=document.createElement('a');a.href=links[i];a.textContent='Open this link';s.appendChild(a);document.getElementById('codes').appendChild(s);}</script>";
            using(var rootCertificate=new X509Certificate2(TrustBytes()))
                html=html.Replace("<main id='codes'>","<p>Certificate: "+System.Web.HttpUtility.HtmlEncode(rootCertificate.Subject)+"<br>SHA-256: <code>"+Wire.Hash(rootCertificate.RawData)+"</code></p><main id='codes'>");
            string path=Path.Combine(folder,"Pair-Phone.html");File.WriteAllText(path,html,new UTF8Encoding(false));Process.Start(path);
        }
    }
    // The RDP helper window (2.4.0 layout): a header that says what is going on in one glance,
    // then the tabs. Everything the old window did is still here; the buttons that matter sit
    // first, the rest moved to Files & settings.
    internal sealed partial class WorkerForm:Form {
        internal const string AppTitle="Tempe COSTAR — Mobile + Online";
        readonly EntryCoordinator coordinator=new EntryCoordinator();
        readonly WorkerEngine engine;AutofillForm online;
        readonly BoundedLog messages=new BoundedLog();
        readonly RichTextBox log=Ui.Log();
        // Header
        // The header's left column has about 620 px at the default window width (900 px minus the
        // paddings and the 200 px right column), so nothing in it is wider than 600 px.
        readonly ComboBox targets=new ComboBox {DropDownStyle=ComboBoxStyle.DropDownList,Width=360,DropDownWidth=620,Font=Ui.Base,Margin=new Padding(0,0,8,0)};
        readonly Button refreshTargets=Ui.SecondaryButton("Refresh",100),showTarget=Ui.SecondaryButton("Show COSTAR",130),saveDiagnostics=Ui.SecondaryButton("Save diagnostics",150),addNote=Ui.SecondaryButton("Add note",100);
        // 2.6.3: Map COSTAR screen (read only), after a countdown to bring the screen up. 2.6.4: 10 s (5 s
        // was too short over Remote Desktop), and Ctrl+Alt+F9 maps the COSTAR screen in front at once.
        readonly Button mapCostar=Ui.SecondaryButton("Map COSTAR screen",190);
        const string MapOwner="The map (reading COSTAR)";
        const int MapSeconds=10,MapKeyId=2;
        int mapCountdown=-1,mapsTaken;volatile bool mapping;DateTime mapStarted;EntryLease mapLease;bool mapKey;
        readonly Label chip=Ui.Chip("STARTING",Ui.Muted),headline=Ui.BigText("Starting ..."),subline=Ui.Hint("",600),nowLine=Ui.Text("",600),perfLine=Ui.Hint("",600);
        readonly ProgressBar progress=new ProgressBar {Width=600,Height=8,Style=ProgressBarStyle.Continuous,Margin=new Padding(0,2,0,8),Visible=false};
        readonly Label updateLine=new Label {AutoSize=true,BackColor=Ui.Gold,ForeColor=Ui.Ink,Font=Ui.Bold,Padding=new Padding(10,6,10,6),Margin=new Padding(0,4,0,0),Cursor=Cursors.Hand,Visible=false};
        // Tabs
        readonly TabControl tabs=new TabControl {Dock=DockStyle.Fill,Font=Ui.Base};
        readonly TabPage mobilePage=new TabPage("Mobile jobs"),onlinePage=new TabPage("Online orders"),orderCheckPage=new TabPage("Order Check"),filesPage=new TabPage("Files & settings");
        TempeOrderCheck.MainForm orderCheck;
        // Mobile tab
        readonly Label connectionLine=Ui.Text("",800),jobLine=Ui.Text("",800),jobDetail=Ui.Hint("",800);
        readonly Button startMobile=Ui.PrimaryButton("Start / resume mobile",200),stopAll=Ui.DangerButton("Stop all entry",140),releaseJob=Ui.SecondaryButton("Release job (finished by hand)",240),startAgain=Ui.SecondaryButton("Start this job again",180);
        // Files & settings tab
        readonly ListView folders=new ListView {View=View.Details,FullRowSelect=true,HideSelection=false,Font=Ui.Base,Height=190,Width=820,MultiSelect=false};
        readonly Label filesNote=Ui.Hint("",820),versionLine=Ui.Text("",820);
        readonly CheckBox longPoll=Ui.Check("Hold the desk connection open so mobile jobs start at once (recommended)",true);
        // 2.6.5: COSTAR pressed directly (boxes, buttons, ticks, tabs, the Work-in-Progress row) instead of the mouse.
        readonly CheckBox directPresses=Ui.Check("Press COSTAR's buttons, ticks, tabs and boxes directly, without moving the mouse (recommended)",true);
        readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer {Interval=1000};
        bool syncingTargets,hotkey,refreshing,deadPin,filesBusy;int perfTicks,updateTicks;
        Updater.Release updateOffer;
        internal WorkerForm(WorkerSettings settings,string folder,bool onlineFirst=false) {
            Direct.On=AppSettings.Current.directPresses;
            Text=AppTitle+" | "+AutofillForm.Version;Size=new Size(900,1000);MinimumSize=new Size(880,760);Font=Ui.Base;StartPosition=FormStartPosition.CenterScreen;BackColor=Ui.Canvas;
            if(settings!=null){engine=new WorkerEngine(settings,folder,Append,coordinator);ebay=new EbayEngine(settings,folder,EbayAppend,coordinator);ro=new RoEngine(settings,folder,Append,coordinator);}
            var root=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=2,Padding=new Padding(12,12,12,8),BackColor=Ui.Canvas};
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));root.RowStyles.Add(new RowStyle(SizeType.Percent,100));
            root.Controls.Add(Header(),0,0);root.Controls.Add(tabs,0,1);Controls.Add(root);
            // 2.5.0: Mobile jobs | Online orders | eBay orders | Order Check | Files & settings.
            tabs.TabPages.Add(mobilePage);tabs.TabPages.Add(onlinePage);tabs.TabPages.Add(ebayPage);tabs.TabPages.Add(orderCheckPage);tabs.TabPages.Add(filesPage);
            BuildMobilePage();BuildEbayPage();BuildFilesPage();
            tabs.SelectedIndexChanged+=delegate{ChangeTab();};
            tabs.SelectedIndex=onlineFirst?1:0;coordinator.MobilePaused=onlineFirst;
            // The closed box shows the short name; the open list shows the full line (PID, window, title).
            targets.FormattingEnabled=true;
            targets.Format+=delegate(object sender,ListControlConvertEventArgs e){var c=e.ListItem as CostarInstance;if(c!=null&&!targets.DroppedDown)e.Value=c.Label+"  ·  PID "+c.Pid;};
            targets.DropDown+=delegate{targets.Invalidate();};targets.DropDownClosed+=delegate{targets.Invalidate();};
            targets.SelectedIndexChanged+=delegate{
                if(syncingTargets)return;
                try{
                    var chosen=targets.SelectedItem as CostarInstance;
                    if(chosen!=null && OrderCheckLink.IsWipWindow(chosen)) {
                        Append("That COSTAR is Order Check's Work-in-Progress window. The helper never types into it; choose another COSTAR.");
                        syncingTargets=true;try{targets.SelectedItem=coordinator.Selected;}finally{syncingTargets=false;}
                        return;
                    }
                    var previous=coordinator.Selected;
                    coordinator.Select(chosen);
                    if(chosen!=null) {
                        RememberBranch(chosen.Branch);AppLog.Note("branch_selected",chosen.Label);
                        if(previous!=null && previous.Branch!=chosen.Branch && engine!=null && engine.Enabled) {
                            // Mobile jobs carry no branch: never let them follow a branch switch silently.
                            engine.Stop();AppLog.Note("branch_switch_mobile_paused",previous.Branch+" -> "+chosen.Branch);
                            Append("Switched to "+chosen.Label+". Mobile jobs are paused so they don't go into the wrong branch. Click Start / resume mobile to take mobile jobs into "+chosen.Label+".");
                        } else if(previous==null || previous.Branch!=chosen.Branch) Append("Using "+chosen.Label+" for new orders.");
                    }
                    UpdateStatus();
                }
                catch(Exception e){Append(e.Message);}
            };
            refreshTargets.Click+=delegate{RefreshTargets();};
            showTarget.Click+=delegate{try{var h=CostarWindows.Main(coordinator.Selected);if(Native.IsIconic(h))Native.ShowWindow(h,9);Native.SetForegroundWindow(h);}catch(Exception e){Append(e.Message);}};
            saveDiagnostics.Click+=delegate{DeskForm.Attempt(SaveDiagnostics);};
            addNote.Click+=delegate{DeskForm.Attempt(AddNote);};
            mapCostar.Click+=delegate{StartMap();};
            updateLine.Click+=delegate{if(updateOffer!=null)DeskForm.Attempt(InstallUpdate);};
            startMobile.Click+=delegate{if(engine!=null&&EnsureTarget()){tabs.SelectedIndex=0;engine.Start();UpdateStatus();}};
            stopAll.Click+=delegate{StopAll();};
            releaseJob.Click+=delegate{DeskForm.Attempt(ReleaseJob);};
            startAgain.Click+=delegate{DeskForm.Attempt(StartJobAgain);};
            Shown+=delegate{hotkey=Native.RegisterHotKey(Handle,1,3,0x79);mapKey=RegisterMapKey();ChangeTab();timer.Start();Append("Mobile is off until you click Start / resume mobile; the desk PC can see this helper meanwhile.");ShowOrderCheckChoice();RefreshTargets();CheckForUpdate();RefreshFiles();if(engine!=null)engine.Connect();if(ebay!=null){ebay.Connect();if(ebay.Enabled)EbayAppend("eBay orders are on (switched on last time): they go into COSTAR Branch "+ebay.Branch+" by themselves.");else EbayAppend("eBay orders are off. Click Start eBay orders to take them from the desk PC.");}if(ro!=null){ro.Connect();Append(ro.Enabled?"Repair Orders from the phone are on: they are opened and changed in the selected COSTAR when it is free.":"Repair Orders from the phone are off (tick the box on this tab to switch them on).");}if(!hotkey)Append("Stop shortcut unavailable; use Stop all entry.");};
            timer.Tick+=delegate{MapTick();UpdateStatus();if(++perfTicks>=5){perfTicks=0;PerfMonitor.Sample();}if(++updateTicks>=6*3600){updateTicks=0;CheckForUpdate();}};
            FormClosing+=delegate(object sender,FormClosingEventArgs e){if(coordinator.Busy||(online!=null&&online.Busy)||(engine!=null&&engine.Busy)||(ebay!=null&&ebay.Busy)||(ro!=null&&ro.Busy)){StopAll();e.Cancel=true;Append("Stopping safely. Close again once entry has stopped.");}};
            FormClosed+=delegate{if(hotkey)Native.UnregisterHotKey(Handle,1);if(mapKey)Native.UnregisterHotKey(Handle,MapKeyId);timer.Dispose();if(orderCheck!=null)orderCheck.Shutdown();if(online!=null)online.Dispose();if(engine!=null)engine.Dispose();if(ebay!=null)ebay.Dispose();if(ro!=null)ro.Dispose();};
        }
        Control Header() {
            var card=Ui.Card(12);card.Dock=DockStyle.Top;card.AutoSize=true;card.Margin=new Padding(0,0,0,10);
            headline.MaximumSize=new Size(600,0);updateLine.MaximumSize=new Size(600,0);
            var grid=new TableLayoutPanel {ColumnCount=2,RowCount=1,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Surface};
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));grid.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            var left=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Fill,BackColor=Ui.Surface};
            var pick=Ui.Row(44);pick.Controls.Add(targets);pick.Controls.Add(refreshTargets);pick.Controls.Add(showTarget);
            left.Controls.Add(Ui.Hint("COSTAR used for mobile and online orders (any open branch)"));left.Controls.Add(pick);
            left.Controls.Add(headline);left.Controls.Add(subline);left.Controls.Add(nowLine);left.Controls.Add(progress);left.Controls.Add(perfLine);left.Controls.Add(updateLine);
            var right=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Anchor=AnchorStyles.Top|AnchorStyles.Right,BackColor=Ui.Surface,Margin=new Padding(12,0,0,0)};
            right.Controls.Add(chip);
            saveDiagnostics.Margin=new Padding(0,10,0,6);addNote.Margin=new Padding(0,0,0,6);saveDiagnostics.Width=190;addNote.Width=190;mapCostar.Margin=new Padding(0,0,0,0);
            right.Controls.Add(saveDiagnostics);right.Controls.Add(addNote);right.Controls.Add(mapCostar);
            grid.Controls.Add(left,0,0);grid.Controls.Add(right,1,0);
            card.Controls.Add(grid);
            return card;
        }
        void BuildMobilePage() {
            mobilePage.BackColor=Ui.Canvas;mobilePage.Padding=new Padding(0);
            var layout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=4,Padding=new Padding(12),BackColor=Ui.Canvas};
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var card=Ui.Card();card.Dock=DockStyle.Top;
            var lines=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Surface};
            lines.Controls.Add(Ui.Title("Mobile job cards from the phone"));lines.Controls.Add(connectionLine);lines.Controls.Add(jobLine);lines.Controls.Add(jobDetail);
            BuildRoCard(lines);
            card.Controls.Add(lines);
            var buttons=Ui.Row();buttons.Margin=new Padding(0,10,0,6);
            buttons.Controls.Add(startMobile);buttons.Controls.Add(stopAll);buttons.Controls.Add(releaseJob);buttons.Controls.Add(startAgain);
            layout.Controls.Add(card,0,0);layout.Controls.Add(buttons,0,1);layout.Controls.Add(log,0,2);
            layout.Controls.Add(Ui.Hint("Ctrl+Alt+F10 stops entry. Ctrl+Alt+F9 maps the COSTAR screen in front (read only). Keep the selected COSTAR visible during entry; other COSTAR windows can stay open. Release job: the job was finished by hand in COSTAR, so the queue moves on. Start this job again: its saved progress is set aside and Retry selected on the desk PC enters it from the start in a new Repair Order (only if it is NOT in COSTAR).",820),0,3);
            mobilePage.Controls.Add(layout);
        }
        void BuildFilesPage() {
            filesPage.BackColor=Ui.Canvas;
            var layout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=5,Padding=new Padding(12),BackColor=Ui.Canvas};
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            for(int i=0;i<4;i++) layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));
            var settings=Ui.Card();settings.Dock=DockStyle.Top;
            var s=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Surface};
            s.Controls.Add(Ui.Title("Settings"));
            longPoll.Checked=AppSettings.Current.longPoll;longPoll.CheckedChanged+=delegate{AppSettings.Current.longPoll=longPoll.Checked;AppSettings.Current.Save();AppLog.Note("setting_long_poll",longPoll.Checked?"on":"off");};
            s.Controls.Add(longPoll);
            directPresses.Checked=AppSettings.Current.directPresses;
            directPresses.CheckedChanged+=delegate{AppSettings.Current.directPresses=directPresses.Checked;AppSettings.Current.Save();Direct.On=directPresses.Checked;AppLog.Note("setting_direct_presses",directPresses.Checked?"on":"off");Append(directPresses.Checked?"COSTAR is pressed directly again (no mouse).":"Direct presses off: the helper clicks COSTAR with the mouse, as before 2.6.5.");};
            s.Controls.Add(directPresses);
            s.Controls.Add(Ui.Hint("Unticked, the helper moves the mouse and clicks as before 2.6.5 (only if direct presses misbehave).",800));
            s.Controls.Add(Ui.Hint("DET first / items above DET and the fitting note are on the Online orders tab. Order Check is switched on its own tab.",800));
            settings.Controls.Add(s);
            var version=Ui.Card();version.Dock=DockStyle.Top;
            var v=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Surface};
            v.Controls.Add(Ui.Title("Version"));v.Controls.Add(versionLine);
            version.Controls.Add(v);
            folders.Columns.Add("Folder",210);folders.Columns.Add("Items",60,HorizontalAlignment.Right);folders.Columns.Add("Size",80,HorizontalAlignment.Right);folders.Columns.Add("Dates",130);folders.Columns.Add("What it holds",240);
            folders.Dock=DockStyle.Fill;folders.DoubleClick+=delegate{DeskForm.Attempt(OpenSelectedFolder);};
            var buttons=Ui.Row();buttons.Margin=new Padding(0,10,0,6);
            var open=Ui.SecondaryButton("Open folder",130);open.Click+=delegate{DeskForm.Attempt(OpenSelectedFolder);};
            var clean=Ui.SecondaryButton("Clean up now",140);clean.Click+=delegate{DeskForm.Attempt(CleanUp);};
            var export=Ui.PrimaryButton("Diagnostics ZIP to Desktop",230);export.Click+=delegate{DeskForm.Attempt(ExportDiagnostics);};
            var boss=Ui.SecondaryButton("Boss report",120);boss.Click+=delegate{DeskForm.Attempt(delegate{string path=TimeSaved.SaveReport();Append("Time-saved report: "+path);AppLog.Note("report_boss","");Process.Start(path);});};
            var refresh=Ui.SecondaryButton("Refresh",100);refresh.Click+=delegate{RefreshFiles();};
            var report=Ui.SecondaryButton("Save worker report",170);report.Click+=delegate{DeskForm.Attempt(SaveReport);};
            buttons.Controls.Add(open);buttons.Controls.Add(clean);buttons.Controls.Add(export);buttons.Controls.Add(boss);buttons.Controls.Add(report);buttons.Controls.Add(refresh);
            layout.Controls.Add(settings,0,0);layout.Controls.Add(version,0,1);layout.Controls.Add(filesNote,0,2);layout.Controls.Add(buttons,0,3);layout.Controls.Add(folders,0,4);
            filesPage.Controls.Add(layout);
        }
    
        // Order Check (built in since 2.0.0) reads a second Tempe COSTAR's Work-in-Progress
        // list in the background, whichever tab is showing, and serves the board.
        // Order Check is OFF unless switched on (2.0.2). Off, it uses no memory, threads or
        // COSTAR time at all. The choice is remembered.
        // settings.json since 2.4.0 (AppSettings keeps the old flag file in step for older packages).
        static bool OrderCheckOn { get { return AppSettings.Current.orderCheck; } }
        void ShowOrderCheckChoice() {
            orderCheckPage.Controls.Clear();
            bool on=OrderCheckOn;
            var bar=new FlowLayoutPanel{Dock=DockStyle.Top,Height=52,Padding=new Padding(10,8,8,0),WrapContents=false,BackColor=Ui.Canvas};
            var toggle=on?Ui.SecondaryButton("Turn Order Check off",200):Ui.PrimaryButton("Turn Order Check on",200);
            var note=new Label{AutoSize=true,Padding=new Padding(8,10,0,0),Font=Ui.Base,ForeColor=Ui.Ink,
                Text=on?"Reads a second Tempe COSTAR's Work-in-Progress list in the background.":"Off: uses no memory or COSTAR time. Turn it on to check WIP jobs against picking slips."};
            toggle.Click+=delegate{DeskForm.Attempt(ToggleOrderCheck);};
            bar.Controls.Add(toggle);bar.Controls.Add(note);
            orderCheckPage.Controls.Add(bar);
            if(on) StartOrderCheck();
        }
        void ToggleOrderCheck() {
            if(OrderCheckOn) {
                AppSettings.Current.orderCheck=false;AppSettings.Current.Save();
                if(orderCheck!=null){orderCheck.Shutdown();orderCheck.Dispose();orderCheck=null;}
                TempeOrderCheck.Hosting.Store=null;
                AppLog.Note("order_check","turned off");
            } else {
                AppSettings.Current.orderCheck=true;AppSettings.Current.Save();
                AppLog.Note("order_check","turned on");
            }
            ShowOrderCheckChoice();
        }
        void StartOrderCheck() {
            try {
                if(!TempeOrderCheck.Hosting.Claim()) {
                    var notice=new Label{Text="The separate Order Check app is still running. Close it (right-click its tray icon, Exit), then restart this helper: Order Check now runs here.",Dock=DockStyle.Fill,Padding=new Padding(12)};
                    orderCheckPage.Controls.Add(notice);notice.BringToFront();
                    AppLog.Note("order_check","separate Order Check app still running; built-in reader not started");
                    return;
                }
                TempeOrderCheck.Hosting.Hold=delegate{return coordinator.Busy;};
                TempeOrderCheck.Hosting.Entered=delegate{return EnteredOrders.Json();};
                TempeOrderCheck.Hosting.EntryPid=delegate{var entry=coordinator.Selected;return entry==null?0:entry.Pid;};
                string site=Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"..","Website"));
                orderCheck=new TempeOrderCheck.MainForm(TempeOrderCheck.Hosting.BoardAddress(site),true){TopLevel=false,FormBorderStyle=FormBorderStyle.None,Dock=DockStyle.Fill};
                orderCheck.TargetChanged=delegate{OrderCheckLink.Forget();RefreshTargets();};
                orderCheckPage.Controls.Add(orderCheck);orderCheck.BringToFront();orderCheck.Show();
                AppLog.Note("order_check","started inside the helper");
            } catch(Exception e) {
                Append("Order Check could not start: "+e.Message);
                AppLog.Note("order_check","start failed: "+e.Message);
            }
        }
        void CheckForUpdate() {
            Updater.CheckInBackground(delegate(Updater.Release found) {
                try { BeginInvoke(new Action(delegate {
                    if(updateOffer!=null && Updater.Parse(updateOffer.version)>=Updater.Parse(found.version)) return;
                    updateOffer=found;Append("Helper "+found.version+" is available. Click the status line at the top to install it.");UpdateStatus();
                })); } catch(InvalidOperationException) { }
            });
        }
        // Downloads, checks and installs the offered version, then restarts into it.
        void InstallUpdate() {
            var release=updateOffer;
            if(release==null) return;
            if(coordinator.Busy || (online!=null&&online.Busy) || (engine!=null&&engine.Busy) || (ebay!=null&&ebay.Busy) || (ro!=null&&ro.Busy)) { Append("Finish or stop the current entry first, then click again to update."); return; }
            string notes=String.IsNullOrWhiteSpace(release.notes)?"":"\r\n\r\n"+release.notes;
            if(MessageBox.Show(this,"Install helper "+release.version+" now?"+notes+"\r\n\r\nIt is downloaded, every file is checked, then the helper restarts into it.","Update the helper",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes) return;
            Append("Updating to "+release.version+" ...");AppLog.Note("update_started",release.version);
            ThreadPool.QueueUserWorkItem(delegate {
                try {
                    string target=Updater.Install(release,delegate(string message){ try{BeginInvoke(new Action(delegate{Append(message);}));}catch(InvalidOperationException){} });
                    BeginInvoke(new Action(delegate {
                        Append("Installed "+release.version+". Restarting into it ...");
                        try { Updater.RestartInto(target);Close(); }
                        catch(Exception e) { Append("Restart failed: "+e.Message+" Start the helper again: it opens the new version."); }
                    }));
                } catch(Exception e) {
                    AppLog.Note("update_failed",e.Message);
                    try { BeginInvoke(new Action(delegate{Append("Update failed: "+e.Message);})); } catch(InvalidOperationException) { }
                }
            });
        }
        void ChangeTab() {
            bool active=tabs.SelectedIndex==1;coordinator.MobilePaused=active;AppLog.Note("tab",active?"online (mobile pickup paused)":tabs.SelectedIndex==2?"ebay":tabs.SelectedIndex==3?"order check":tabs.SelectedIndex==4?"files":"mobile");
            if(active&&online==null) {
                online=new AutofillForm(coordinator) {TopLevel=false,FormBorderStyle=FormBorderStyle.None,MinimumSize=Size.Empty,Dock=DockStyle.Fill};
                online.EnsureTarget=EnsureTarget;
                if(ebay!=null){var tab=online;ebay.OnlineWaiting=delegate{return tab.PendingReason;};}
                onlinePage.Controls.Add(online);online.Show();
            }
            if(online!=null)online.SetActive(active);
            if(tabs.SelectedIndex==4)RefreshFiles();
            UpdateStatus();
        }
        void StopAll(){AppLog.Note("stop_pressed","stop all");if(engine!=null)engine.Stop();if(online!=null)online.StopEntry();if(ebay!=null&&(ebay.Enabled||ebay.Busy)){ebay.Stop(false);EbayAppend("Stop all entry: eBay orders paused. Click Start eBay orders to carry on.");}if(ro!=null&&(ro.Enabled||ro.Busy)){ro.Stop(false);Append("Stop all entry: Repair Orders from the phone paused. Tick the box on the Mobile jobs tab to carry on.");}UpdateStatus();}
        // 2.4.0: the two ways out of a mobile job the helper can't finish.
        void ReleaseJob() {
            if(engine==null)return;
            string job=engine.DescribeJob();
            string message=job+"\r\n\r\nRelease this job because it was finished (or closed) by hand in COSTAR?\r\n\r\nThe helper types nothing. On the desk PC the job shows as ready for review, and Next Order (or Pinad mode) moves on to the next job. Only choose Yes once the Repair Order is really done in COSTAR.";
            if(MessageBox.Show(this,message,"Release job (finished by hand)",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button2)==DialogResult.Yes){engine.Release();Append("Released "+job+". The desk PC can move on with Next Order.");}
            UpdateStatus();
        }
        void StartJobAgain() {
            if(engine==null)return;
            string job=engine.DescribeJob();bool unstarted=engine.JobUnstarted;bool windowAlive=engine.JobWindowAlive;
            string message=job+"\r\n\r\n"+(unstarted?"This job stopped before any field was entered.":"This job may already have fields entered in a Repair Order.")+
                (windowAlive?"\r\n\r\nIts original Repair Order window is still open. Retry selected on the desk PC is the normal way to continue it. Start again only if that Repair Order was closed WITHOUT saving.":"\r\n\r\nIts original Repair Order window is gone.")+
                "\r\n\r\nCheck COSTAR first: if "+job+" is already in COSTAR, choose No and use Release job instead.\r\n\r\nSet the saved progress aside (a backup is kept) so Retry selected on the desk PC enters this job from the start in a NEW Repair Order?";
            if(MessageBox.Show(this,message,"Start this job again",MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2)==DialogResult.Yes){engine.StartAgain();Append("Progress for "+job+" set aside. Click Start / resume mobile here, then Retry selected on the desk PC.");}
            UpdateStatus();
        }
        void UpdateStatus() {
            // Display cached state only. No window discovery, process snapshots,
            // clipboard read or journal serialization belongs on this timer.
            Ui.AppendColoured(log,messages.Drain());if(online!=null)online.FlushLog();UpdateEbayTab();UpdateRoCard();
            bool pinned=engine!=null&&engine.TargetPinned,busy=coordinator.Busy;var selected=coordinator.Selected;
            var p=coordinator.Progress.Read();
            saveDiagnostics.Enabled=!busy;mapCostar.Enabled=!busy&&!mapping&&mapCountdown<0;if(!mapping&&mapCountdown<0&&mapCostar.Text!="Map COSTAR screen") mapCostar.Text="Map COSTAR screen";targets.Enabled=!busy&&(!pinned||deadPin)&&!refreshing;refreshTargets.Enabled=!busy&&!refreshing;showTarget.Enabled=!busy&&selected!=null;
            startMobile.Enabled=engine!=null&&!busy&&!refreshing&&selected!=null&&!engine.Enabled;
            stopAll.Enabled=busy||(engine!=null&&engine.Enabled)||(online!=null&&online.Busy)||(ebay!=null&&ebay.Busy)||(ro!=null&&ro.Busy);
            releaseJob.Enabled=engine!=null&&!busy&&!engine.Busy&&engine.CanRelease;
            startAgain.Enabled=engine!=null&&!busy&&!engine.Busy&&engine.CanStartAgain;
            // Header: chip, headline, sub line, now line. NEEDS YOU: a failed mobile job waits for a
            // decision, or an entry stopped in the last 10 minutes.
            string alert=engine!=null&&engine.CanRelease?"Mobile job needs you: "+engine.PendingSummary:!p.LastOk&&p.LastLine.Length>0&&(DateTime.Now-p.LastAt).TotalMinutes<10?p.LastLine:null;
            string chipText;Color chipBack;string head,sub;
            if(mapping||coordinator.Owner==MapOwner) {
                chipText="MAPPING";chipBack=Ui.Info;progress.Visible=false;
                head="Mapping COSTAR's screen";
                sub="Read only: nothing is clicked or typed  ·  "+((DateTime.Now-mapStarted).TotalSeconds).ToString("0")+" s";
            } else if(p.Active||busy) {
                chipText="FILLING";chipBack=Ui.Info;
                head=(p.Reference.Length>0?p.Reference:coordinator.Owner)+(p.Stage.Length>0?"  ·  "+p.Stage:"");
                var into=coordinator.ActiveTarget??selected;
                sub=coordinator.Owner+" is entering data into "+(into==null?"COSTAR":into.Label)+"  ·  "+((DateTime.Now-p.Started).TotalSeconds).ToString("0.0")+" s";
                progress.Visible=true;
                if(p.Steps>0){if(progress.Style!=ProgressBarStyle.Continuous)progress.Style=ProgressBarStyle.Continuous;progress.Maximum=p.Steps;progress.Value=Math.Min(p.Steps,Math.Max(0,p.Step));}
                else if(progress.Style!=ProgressBarStyle.Marquee)progress.Style=ProgressBarStyle.Marquee;
            } else {
                progress.Visible=false;
                if(refreshing){chipText="LOOKING";chipBack=Ui.Muted;head="Finding COSTAR windows ...";sub="";}
                else if(selected==null){chipText="NO COSTAR";chipBack=Ui.Muted;head="Select a COSTAR";sub="Open COSTAR in this Remote Desktop session, click Refresh, then pick it in the list.";}
                else if(alert!=null){chipText="NEEDS YOU";chipBack=Ui.Danger;head=alert;sub=engine!=null&&engine.CanRelease?"Finish it by hand and click Release job, or Start this job again (Mobile jobs tab).":"Check COSTAR, then carry on. The log has the details.";}
                else {
                    chipText="READY";chipBack=Ui.Success;head="Ready  ·  "+selected.Label;
                    sub=(engine==null?"Mobile not configured":engine.Enabled?"Mobile on"+(coordinator.MobilePaused?" (paused while Online orders is selected)":""):"Mobile off")+
                        "  ·  "+(online==null?"Online orders: open the tab to use":online.StateLine)+(ebay!=null&&ebay.Enabled?"  ·  eBay orders on":"")+(ro!=null&&ro.Enabled?"  ·  Repair Orders on":"")+(pinned&&!deadPin?"  ·  mobile job pinned to its COSTAR":"");
                }
            }
            Ui.SetChip(chip,chipText,chipBack);Ui.SetText(headline,head);Ui.SetText(subline,sub);
            Ui.SetText(nowLine,p.Active?"":p.LastLine.Length>0?"Last: "+p.LastLine+"  ("+p.LastAt.ToString("HH:mm")+")":"");
            string saved=TimeSaved.TodayLine();
            Ui.SetText(perfLine,(saved.Length>0?saved+"  ·  ":"")+PerfMonitor.Line);
            bool offer=updateOffer!=null;
            if(updateLine.Visible!=offer)updateLine.Visible=offer;
            if(offer)Ui.SetText(updateLine,"UPDATE "+updateOffer.version+" READY  -  CLICK HERE TO INSTALL"+(String.IsNullOrWhiteSpace(updateOffer.name)?"":"  ("+updateOffer.name+")"));
            // Mobile card.
            if(engine==null){Ui.SetText(connectionLine,"Mobile connection is not configured. Online orders still work. Import worker-connection.json and restart to connect mobile jobs.");Ui.SetText(jobLine,"");Ui.SetText(jobDetail,"");}
            else {
                int since=engine.SecondsSinceContact;
                Ui.SetText(connectionLine,engine.Connection+(since>=0?" ("+(since<=1?"just now":since+" s ago")+(engine.RoundTripMs>=0?", "+engine.RoundTripMs+" ms":"")+")":"")+(engine.Enabled?"  ·  mobile on"+(selected!=null?", jobs go into "+selected.Label:""):"  ·  mobile off")+(coordinator.MobilePaused?"  ·  paused while Online orders is selected":""));
                string job=engine.PendingSummary;
                Ui.SetText(jobLine,job.Length==0?"No mobile job in progress.":"Job: "+job+(pinned&&deadPin?"  (its COSTAR has closed)":""));
                Ui.SetText(jobDetail,engine.Detail);
            }
        }
        // Files & settings tab: sizes are summed on a background thread (the reports folder can hold hundreds of ZIPs).
        void RefreshFiles() {
            if(filesBusy)return;filesBusy=true;
            Ui.SetText(versionLine,"Installed: "+AutofillForm.Version+"   ·   running from "+AppDomain.CurrentDomain.BaseDirectory);
            ThreadPool.QueueUserWorkItem(delegate {
                var rows=new List<FolderStat>();
                try {
                    rows.Add(FolderStats.Of("Entry reports",AppData.Reports,"One ZIP per order (customer details; kept 30 days)",true));
                    rows.Add(FolderStats.Of("Diagnostics",AppData.Diagnostics,"Masked run files and day logs (kept 180 days)",true));
                    rows.Add(FolderStats.Of("Diagnostics ZIPs and startup logs",AppData.Home,"Save diagnostics output; Build.ps1 startup logs",true,true));
                    rows.Add(FolderStats.Of("Installed versions",AppData.Packages,"Auto-update packages (current + previous kept)",true));
                    rows.Add(FolderStats.Of("Build cache",AppData.Runtime,"Compiled helper builds (newest kept)",true));
                } catch(Exception) { }
                try{BeginInvoke(new Action(delegate{
                    folders.BeginUpdate();folders.Items.Clear();
                    foreach(var r in rows){var item=new ListViewItem(new[]{r.Name,r.Items.ToString(),AppData.Bytes(r.Size),r.Age,r.Note}){Tag=r.Path};folders.Items.Add(item);}
                    folders.EndUpdate();filesBusy=false;
                    Ui.SetText(filesNote,"Everything lives under "+AppData.Home+". Double-click a row to open it.");
                }));}catch(InvalidOperationException){filesBusy=false;}
            });
        }
        void OpenSelectedFolder(){Order.Require(folders.SelectedItems.Count==1,"Select a folder in the list first.");string path=(string)folders.SelectedItems[0].Tag;Directory.CreateDirectory(path);Process.Start("explorer.exe",path);}
        void CleanUp() {
            if(filesBusy){Append("Still counting files; try again in a moment.");return;}
            filesBusy=true;Ui.SetText(filesNote,"Working out what can go ...");
            string current="";try{string pointer=Path.Combine(AppData.Packages,"current.txt");if(File.Exists(pointer))current=File.ReadAllText(pointer).Trim();}catch(Exception){}
            string packageFolder=PackageFolder(),bin=AppDomain.CurrentDomain.BaseDirectory;
            // Sizing every old package and build takes a moment: off the UI thread, then the question.
            ThreadPool.QueueUserWorkItem(delegate {
                Cleanup.Plan packages=null,runtimes=null,logs=null;string problem=null;
                try { packages=Cleanup.Packages(AppData.Packages,packageFolder,current);runtimes=Cleanup.Runtimes(AppData.Runtime,bin);logs=Cleanup.Logs(AppData.Home,30); }
                catch(Exception e) { problem=e.Message; }
                try{BeginInvoke(new Action(delegate{filesBusy=false;if(IsDisposed)return;if(problem!=null)Append("Clean up could not look at the folders: "+problem);else DeskForm.Attempt(delegate{OfferCleanUp(packages,runtimes,logs);});}));}catch(InvalidOperationException){filesBusy=false;}
            });
        }
        void OfferCleanUp(Cleanup.Plan packages,Cleanup.Plan runtimes,Cleanup.Plan logs) {
            long total=packages.Bytes+runtimes.Bytes+logs.Bytes;int count=packages.Folders.Count+runtimes.Folders.Count+logs.Files.Count;
            if(count==0){Ui.SetText(filesNote,"Nothing to clean up. Kept: "+String.Join(", ",packages.Kept.Concat(runtimes.Kept).ToArray())+".");return;}
            string message="Remove "+count+" item(s), about "+AppData.Bytes(total)+":\r\n\r\n"+
                (packages.Folders.Count>0?"Old versions: "+String.Join(", ",packages.Folders.Select(Path.GetFileName).ToArray())+"\r\n":"")+
                (runtimes.Folders.Count>0?"Old builds: "+runtimes.Folders.Count+"\r\n":"")+
                (logs.Files.Count>0?"Old startup logs / diagnostics ZIPs: "+logs.Files.Count+"\r\n":"")+
                "\r\nKept: "+String.Join(", ",packages.Kept.ToArray())+".\r\nEntry reports and diagnostics follow their own 30/180-day rules. Settings, queue and journal are never touched.";
            if(MessageBox.Show(this,message,"Clean up",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes){Ui.SetText(filesNote,"Nothing removed.");return;}
            long freed,f;int removed=Cleanup.Apply(packages,out freed);removed+=Cleanup.Apply(runtimes,out f);freed+=f;removed+=Cleanup.Apply(logs,out f);freed+=f;
            AppLog.Note("cleanup",removed+" items, "+AppData.Bytes(freed));Append("Cleaned up "+removed+" item(s), "+AppData.Bytes(freed)+" freed.");RefreshFiles();
        }
        // The package folder this build came from (packages\Tempe-COSTAR-Helper-vX), if it is one.
        static string PackageFolder() {
            try {
                string pointer=Path.Combine(AppData.Packages,"current.txt");
                if(File.Exists(pointer)){string t=File.ReadAllText(pointer).Trim();if(Path.GetFileName(t.TrimEnd('\\'))=="Tempe-COSTAR-Helper-v"+Updater.Current.ToString(3))return t;}
            } catch(Exception) { }
            return Path.Combine(AppData.Packages,"Tempe-COSTAR-Helper-v"+Updater.Current.ToString(3));
        }
        void ExportDiagnostics() {
            AppLog.Note("report_saved","desktop");
            string path=DiagnosticsBundle.Save();
            string desktop=Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);string target=Path.Combine(desktop,Path.GetFileName(path));
            File.Copy(path,target,true);
            Append("Diagnostics ZIP saved to your Desktop: "+target+". Upload it to Claude (timings, stop reasons, day log; no customer details).");
            Process.Start("explorer.exe","/select,\""+target+"\"");
        }
        void RefreshTargets() {
            if(coordinator.Busy||refreshing)return;
            refreshing=true;UpdateStatus();
            ThreadPool.QueueUserWorkItem(delegate(object unused) {
                List<CostarInstance> choices=null;string error=null;
                try{choices=CostarWindows.Choices();}catch(Exception e){error=e.Message;}
                if(IsDisposed)return;
                try{BeginInvoke(new Action(delegate{ApplyTargets(choices,error);}));}catch(InvalidOperationException){}
            });
        }
        void ApplyTargets(List<CostarInstance> choices,string error) {
            try {
                if(error!=null)throw new InvalidOperationException(error);
                if(coordinator.Busy)return;
                var prior=coordinator.Selected;
                if(prior!=null && OrderCheckLink.IsWipWindow(prior)) { prior=null; Append("The COSTAR the helper was using is now Order Check's WIP window; switching to another COSTAR."); }
                var selected=prior==null?null:choices.FirstOrDefault(c=>c.Same(prior));
                var pending=engine==null?null:engine.PendingCheckpoint;
                // A job pinned to a COSTAR that is no longer running (or whose Repair Order
                // window is gone) can never be resumed or closed in that COSTAR. It keeps its
                // own safety checks, but it must not stop the current COSTAR being used.
                bool pinned=engine!=null&&engine.TargetPinned;
                deadPin=pinned&&pending!=null&&(CostarWindows.OrderWindowGone(pending)||CostarWindows.PinnedProcessGone(pending));
                if(prior!=null&&selected==null){selected=prior;choices.Add(prior);} // Never silently switch to another process.
                if(selected==null&&pending!=null&&pending.window!=0&&!deadPin) {
                    var matching=choices.Where(c=>c.Pid==pending.processId&&c.Started==pending.processStart&&c.Session==pending.sessionId).ToList();
                    if(matching.Count==1)selected=matching[0];
                } else if(selected==null) {
                    // The branch you used last (remembered), else the only COSTAR open.
                    var usable=choices.Where(c=>!OrderCheckLink.IsWipWindow(c)).ToList();
                    int preferred=PreferredBranch();
                    var mine=usable.Where(c=>c.Branch==preferred).ToList();
                    if(mine.Count==1) selected=mine[0];
                    else if(usable.Count==1) selected=usable[0];
                    if(usable.Count<choices.Count) Append("Skipped the COSTAR that Order Check reads (its Work-in-Progress window); the helper never types into it.");
                }
                syncingTargets=true;targets.Items.Clear();foreach(var choice in choices)targets.Items.Add(choice);targets.SelectedItem=selected;coordinator.Select(selected);
                if(deadPin) {
                    string job=engine.PendingSummary;
                    AppLog.Note("mobile_pin_released",job+" belonged to a COSTAR that has closed");
                    Append("Earlier mobile job "+job+" was entered in a COSTAR that has since closed, so its Repair Order window is gone. It no longer locks the COSTAR list."+
                        (job.Contains("ready for review")?" Next Order on the desk receiver will release it; make sure it was saved in COSTAR.":""));
                }
                string scan=CostarWindows.LastScan;
                AppLog.Note(choices.Count==0?"costar_not_found":"costar_found",choices.Count+" COSTAR ("+String.Join(", ",choices.Select(c=>c.Label).ToArray())+")"+(selected!=null?", using "+selected.Label+" pid "+selected.Pid:", none selected")+" | "+scan);
                if(choices.Count==0)Append("No COSTAR found in this Remote Desktop session ("+scan+"). Open COSTAR here, then click Refresh COSTAR list.");
                else if(selected==null)Append(choices.Count+" COSTAR windows found ("+String.Join(", ",choices.Select(c=>c.Label).ToArray())+"): choose one in the list above.");
                else Append("Using "+selected.Label+" (PID "+selected.Pid+").");
            } catch(Exception e){Append(e.Message);AppLog.Note("costar_not_found","search failed: "+e.Message);} finally {syncingTargets=false;refreshing=false;UpdateStatus();}
        }
        // The branch chosen last, remembered between starts (2.3.0; settings.json since 2.4.0).
        static int PreferredBranch() { return AppSettings.Current.preferredBranch; }
        static void RememberBranch(int branch) {
            if(branch<=0 || branch==AppSettings.Current.preferredBranch) return;
            AppSettings.Current.preferredBranch=branch;AppSettings.Current.Save();
        }
        // Finds a COSTAR on the spot when an action needs one and none is chosen yet.
        internal bool EnsureTarget() {
            if(coordinator.Selected!=null) return true;
            if(coordinator.Busy) return false;
            List<CostarInstance> choices=null;string error=null;
            try{choices=CostarWindows.Choices();}catch(Exception e){error=e.Message;}
            ApplyTargets(choices,error);
            return coordinator.Selected!=null;
        }
        static void SetLabel(Label label,string text){if(label.Text!=text)label.Text=text;}
        void SaveReport(){UpdateStatus();using(var dialog=new SaveFileDialog{FileName="Tempe-COSTAR-Worker-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+".txt",Filter="Text report|*.txt"})if(dialog.ShowDialog(this)==DialogResult.OK)File.WriteAllText(dialog.FileName,"Tempe COSTAR "+AutofillForm.Version+"\r\n"+headline.Text+"\r\n"+subline.Text+"\r\n"+connectionLine.Text+"\r\n"+jobLine.Text+"\r\n\r\n"+log.Text,new UTF8Encoding(false));}
        // 2.6.3 (Tommy, 28 Oct: map COSTAR's screens first, so the helper can press things directly instead
        // of clicking). Map COSTAR screen: time to bring the screen up, then a read-only map of the COSTAR in
        // front (CostarMap), saved with the diagnostics. 2.6.4: 10 s, or Ctrl+Alt+F9 whenever the screen is up
        // (the print form and the customer search window weren't up within 5 s); a sound when it's saved, for
        // someone looking at COSTAR rather than here.
        bool RegisterMapKey() {
            // Ctrl+Alt+F9, not repeated while held (MOD_NOREPEAT; Windows before 7 don't know it).
            bool ok=Native.RegisterHotKey(Handle,MapKeyId,0x4003,0x78)||Native.RegisterHotKey(Handle,MapKeyId,3,0x78);
            if(!ok) Append("The map shortcut (Ctrl+Alt+F9) is taken by another program: use the Map COSTAR screen button.");
            return ok;
        }
        void StartMap() {
            if(mapping||mapCountdown>=0||coordinator.Busy) return;
            mapCountdown=MapSeconds;mapCostar.Text="Map in "+MapSeconds+" s ...";mapCostar.Enabled=false;
            Append("Map: bring up the COSTAR screen to map now ("+MapSeconds+" s; a menu can be opened too)"+(mapKey?", or press Ctrl+Alt+F9 as soon as it's up":"")+". The helper only reads it: nothing is clicked or typed. A sound says when it's saved.");
        }
        // Ctrl+Alt+F9: the COSTAR screen in front, mapped now (a countdown still running ends here).
        void MapNow() {
            if(mapping) { Append("Map: still reading the last screen. Press Ctrl+Alt+F9 again once it's saved.");System.Media.SystemSounds.Exclamation.Play();return; }
            mapCountdown=-1;
            BeginMap();
        }
        void MapTick() {
            // A COSTAR that doesn't answer the map's reads for 2.5 minutes doesn't hold entries up any longer.
            if(mapping&&(DateTime.Now-mapStarted).TotalSeconds>150) {
                var held=mapLease;mapLease=null;mapping=false;if(held!=null) held.Dispose();
                Append("Map: COSTAR hasn't answered for 2.5 minutes, so entries can go on again. The map may still finish (a line here says so).");
            }
            if(mapCountdown<0) return;
            if(--mapCountdown>0) { mapCostar.Text="Map in "+mapCountdown+" s ...";return; }
            mapCountdown=-1;
            BeginMap();
        }
        void BeginMap() {
            var lease=coordinator.TryBeginRead(MapOwner);
            if(lease==null) { mapCostar.Text="Map COSTAR screen";Append("Map not taken: "+(coordinator.Owner.Length>0?coordinator.Owner:"an entry")+" is filling COSTAR. Map again when it's done.");System.Media.SystemSounds.Exclamation.Play();return; }
            mapping=true;mapStarted=DateTime.Now;mapCostar.Text="Mapping ...";mapLease=lease;
            var thread=new Thread(delegate() {
                try {
                    var r=CostarMap.Run();
                    int n=Interlocked.Increment(ref mapsTaken);
                    Append("Map "+n+" saved: "+r.Windows+" COSTAR window"+(r.Windows==1?"":"s")+" ("+r.Words+"), "+r.Controls+" controls, "+r.Pressable+" that Windows can press or tick directly, "+r.Accessible+" accessibility objects ("+r.Hidden+" parts that don't show left out)"+(r.Others>0?", "+r.Others+" window"+(r.Others==1?"":"s")+" of another COSTAR listed":"")+(r.Cut?" (cut short: a very big screen)":"")+". Map the next screen, or click Save diagnostics and send the ZIP to Claude.");
                    System.Media.SystemSounds.Asterisk.Play();
                } catch(Exception e) { Append("Map not saved: "+e.Message);System.Media.SystemSounds.Exclamation.Play(); }
                finally { lease.Dispose();if(Object.ReferenceEquals(mapLease,lease)) { mapLease=null;mapping=false; } }
            });
            thread.IsBackground=true;thread.SetApartmentState(ApartmentState.STA);thread.Start();
        }
        void SaveDiagnostics() {
            AppLog.Note("report_saved","");
            string path=DiagnosticsBundle.Save();
            Append("Diagnostics saved (timings, stop reasons, today's day log; no customer details): "+path+". Upload this ZIP to Claude.");
            Process.Start("explorer.exe","/select,\""+path+"\"");
        }
        // A quick note for the end-of-day report, stored with the time it was written.
        void AddNote() {
            using(var dialog=new Form {Text="Note for the end-of-day report",ClientSize=new Size(540,128),StartPosition=FormStartPosition.CenterParent,
                FormBorderStyle=FormBorderStyle.FixedDialog,MinimizeBox=false,MaximizeBox=false,ShowInTaskbar=false,Font=Font}) {
                var help=new Label {Text="What happened? Please no customer names or numbers.",AutoSize=true,Location=new Point(12,12)};
                var text=new TextBox {Location=new Point(12,40),Width=516,MaxLength=300};
                var save=new Button {Text="Save note",DialogResult=DialogResult.OK,Location=new Point(318,80),Width=100,Height=34};
                var cancel=new Button {Text="Cancel",DialogResult=DialogResult.Cancel,Location=new Point(428,80),Width=100,Height=34};
                dialog.Controls.Add(help);dialog.Controls.Add(text);dialog.Controls.Add(save);dialog.Controls.Add(cancel);
                dialog.AcceptButton=save;dialog.CancelButton=cancel;
                if(dialog.ShowDialog(this)==DialogResult.OK && text.Text.Trim().Length>0) {
                    AppLog.Note("user_note",text.Text.Trim());
                    Append("Note saved for the end-of-day report.");
                }
            }
        }
        void Append(string text){messages.Add(text);}
        protected override void WndProc(ref Message m){if(m.Msg==0x312&&m.WParam.ToInt32()==1)StopAll();if(m.Msg==0x312&&m.WParam.ToInt32()==MapKeyId)MapNow();if(m.Msg==0x8001){if(m.WParam.ToInt32()==1)tabs.SelectedIndex=1;WindowState=FormWindowState.Normal;Activate();}base.WndProc(ref m);}
        internal static bool ShowExisting(bool onlineFirst) {
            bool found=false;Native.EnumWindows(delegate(IntPtr h,IntPtr unused){
                if(!Native.Caption(h).StartsWith(AppTitle,StringComparison.Ordinal))return true;
                try {ProcessIdentity identity;
                    if(!LocalProcess.IsNamed((int)Native.Pid(h),"TempeMobile",out identity))return true;
                    found=true;UIntPtr result;Native.WriteMessage(h,0x8001,new UIntPtr(onlineFirst?1u:0u),null,3,500,out result);Native.SetForegroundWindow(h);
                }catch{}return true;
            },IntPtr.Zero);return found;
        }
    }
}
