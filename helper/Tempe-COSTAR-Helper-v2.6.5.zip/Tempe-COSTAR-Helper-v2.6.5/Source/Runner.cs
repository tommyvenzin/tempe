// The entry engine, part 1 of 4 (2.4.0 split of CostarAutofill.cs): state, checks, snapshots, focus,
// typing and committing. Attended COSTAR 5.7 repair-order entry. No database access or Save/Sell action.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed partial class Runner : IDisposable {
        readonly Process process;
        readonly uint pid;
        readonly IntPtr root;
        readonly Order order;
        readonly string payment;
        readonly bool fitting;
        readonly Action<string> notify;
        readonly JavaScriptSerializer json=new JavaScriptSerializer { MaxJsonLength=2000000 };
        readonly StreamWriter log;
        internal volatile bool Cancel;
        internal string Folder, ZipPath;
        int writes;
        // How many fields this run has typed (0 = COSTAR untouched).
        internal int Writes { get { return writes; } }
        // 2.5.0: called once, just before the first field of this run is written (eBay attempts).
        internal Action BeforeFirstWrite;
        // 2.6.0: every write about to be tried, counted before it goes (Writes counts the ones that
        // went through): a write that failed half way may still have reached COSTAR.
        int writeAttempts;
        internal bool Touched { get { return writeAttempts>0; } }
        void BeforeWrite() { writeAttempts++;if(writes==0) { var first=BeforeFirstWrite;if(first!=null)first(); } }
        readonly Stopwatch runClock=Stopwatch.StartNew();
        readonly List<object> timings=new List<object>();
        int snapshotCount;
        long snapshotMilliseconds;
        int gridSnapshotCount,controlTextReads,skippedQuantities;
        IntPtr gridPanel;
        long gridPanelParent;
        string gridPanelClass;
        readonly Dictionary<int,int> packagePrices=new Dictionary<int,int>();
        readonly HashSet<long> originalWindows=new HashSet<long>();
        readonly Dictionary<long,int> popupCloseStages=new Dictionary<long,int>();
        bool enteringCustomer,lookupCancelled,restoredCustomerFocus;
        int searchCancelAttempts,recoveryActions;
        string verifiedCustomerAccount,verifiedCustomerName;
        internal RunDiagnostics Diag;
        IntPtr lastWritten;
        internal bool FreshlyOpened;
        // 2.3.1 resume rules. OwnAttempt: this Repair Order is where this helper stopped this order
        // earlier in this session. ResumePrint: what it held then (Selectors.OrderPrint); it must be
        // unchanged. MustResume: Order Check already lists the order, so only that attempt may be
        // continued, otherwise stop with DuplicateMessage. StopPrint: set when this run stops.
        internal bool OwnAttempt,MustResume,ResumeVerified;internal string ResumePrint,DuplicateMessage,StopPrint;
        // 2.3.2: the Online tab's "DET first" choice. Off: items first, then DET, as before 2.3.0.
        internal bool DetFirst=true;
        bool fastTimer;
        long idleWaitedMs;
        readonly Dictionary<long,string> classCache=new Dictionary<long,string>();
        readonly Action<ControlInfo> lateRead,liveRead;
        long[] gridLabels;
        FieldMap headerCache;
        int skippedReads,lateReads,headerReads,headerHits,busySkips,busySnapshots;
        // True when the last snapshot found COSTAR not answering and read no text.
        bool lastSnapshotBusy;
        bool sawChooser;int chooserAttempts,focusRecoveries;
        // The phone typed for the customer lookup (used for the all-branch search).
        string lookupPhone="";
        readonly Stopwatch chooserClock=new Stopwatch();
        internal const int CustomerLookupTimeoutMs=20000;
        // COSTAR's phone search can take several seconds when it is slow (3-4 Oct: 2.2-2.5 s
        // and more). Escape during the search cancels the account list it is about to show,
        // so a search that is still running is left alone for this long.
        internal const int SearchPatienceMs=15000;
        // 2.4.0: %LOCALAPPDATA%\TempeMobileCostar\reports (moved from TempeCostarAutofill\Reports once).
        internal static string ReportsRoot { get { return AppData.Reports; } }
        // The COSTAR branch this run's Repair Order must belong to (2.3.0: any branch).
        readonly int branch;
        internal int Branch { get { return branch; } }
        internal Runner(int processId,int expectedBranch,Order data,string pay,bool includeFitting,Action<string> progress,long expectedWindow=0) {
            lateRead=LateRead;liveRead=LiveRead;
            ProcessIdentity identity;Order.Require(LocalProcess.IsNamed(processId,"COSTAR",out identity),"Select COSTAR running inside this Remote Desktop session.");
            process=Process.GetProcessById(processId);
            try {
            IntPtr keep=process.Handle;
            Order.Require(expectedBranch>0,"The COSTAR branch for this order is unknown. Refresh the COSTAR list and select a COSTAR.");
            pid=(uint)processId; branch=expectedBranch; order=data; payment=Order.EntryText(pay.Trim()); fitting=includeFitting; notify=progress;
            var candidates=new List<IntPtr>();
            Native.EnumWindows(delegate(IntPtr h,IntPtr unused) {
                if(Native.IsWindowVisible(h)) originalWindows.Add(h.ToInt64());
                if(Native.Pid(h)==pid && Native.IsWindowVisible(h) && Branches.OrderTitle(Native.Caption(h),branch) && (expectedWindow==0 || h.ToInt64()==expectedWindow)) candidates.Add(h);
                return true;
            },IntPtr.Zero);
            Order.Require(candidates.Count==1,"Open one empty Repair Order (Branch "+branch+") in COSTAR, then click Fill again.");
            root=candidates[0];
            Order.Require(Branches.OrderTitle(Native.Caption(root),branch),"This Repair Order is not in Branch "+branch+". Open an empty Repair Order in that branch.");
            // Keep per-field diagnostics off redirected Desktop/UNC shares.
            string parent=ReportsRoot;
            Folder=Path.Combine(parent,DateTime.Now.ToString("yyyyMMdd-HHmmss")+"-"+order.orderId+"-"+Guid.NewGuid().ToString("N").Substring(0,6));
            Directory.CreateDirectory(Folder);
            log=new StreamWriter(Path.Combine(Folder,"steps.jsonl"),false,new UTF8Encoding(false)); log.AutoFlush=false;
            File.WriteAllText(Path.Combine(Folder,"order.json"),json.Serialize(order),new UTF8Encoding(false));
            // Last statement: nothing after this can throw and leave the probe running.
            Diag=new RunDiagnostics(Path.GetFileName(Folder),order.orderId,root,pid);
            Diag.SetEnv("branch",branch.ToString(CultureInfo.InvariantCulture));
            } catch {try{if(log!=null)log.Dispose();}finally{process.Dispose();}throw;}
        }
        internal void Activate() { Native.BringToFront(root); }
        void ActivateAndWait() {
            Activate();var timer=Stopwatch.StartNew();
            while(Native.GetForegroundWindow()!=root && timer.ElapsedMilliseconds<2000)Pause(25);
            Ready();
        }
        void Say(string text) { log.WriteLine(json.Serialize(new{At=DateTimeOffset.Now.ToString("o"),Version=AutofillForm.Version,Step=text,Writes=writes})); Diag.Step(text); notify(text); }
        // 2.4.0: the window's header follows the stages (name, index, planned count).
        internal Action<string,int,int> OnStage;int stageIndex,stageCount;
        void Stage(string name) {
            stageIndex++;var hook=OnStage;
            if(hook!=null) { try { hook(name,stageIndex,stageCount); } catch(Exception) { } }
        }
        void Timed(string stage,Action action) {
            var timer=Stopwatch.StartNew();bool completed=false;Diag.BeginStage(stage);Stage(stage);
            try {action();completed=true;}
            finally {
                Diag.EndStage(completed);
                var timing=new {Stage=stage,Milliseconds=timer.ElapsedMilliseconds,Completed=completed};
                timings.Add(timing);log.WriteLine(json.Serialize(new{At=DateTimeOffset.Now.ToString("o"),Type="timing",Timing=timing}));log.Flush();
            }
        }
        void Check(bool foreground) {
            // 2.5.1: while a note's key press is in flight (its letter in, not yet taken back) a Stop waits
            // for it, so the note is never left with the extra letter (PressAtEnd).
            if(Cancel && !keyInFlight) throw new OperationCanceledException("Stopped by you. Check the partially filled order in COSTAR.");
            Order.Require(!process.HasExited && Native.IsWindow(root) && Native.Pid(root)==pid && Branches.OrderTitle(Native.Caption(root),branch),"The original Repair Order was closed or changed.");
            if(foreground) {
                var front=Native.GetForegroundWindow();bool enabled=Native.IsWindowEnabled(root);
                if(front==IntPtr.Zero) {
                    // Windows briefly has no active window while one closes and another opens.
                    var gap=Stopwatch.StartNew();
                    while(front==IntPtr.Zero && gap.ElapsedMilliseconds<1500){Thread.Sleep(25);front=Native.GetForegroundWindow();}
                    enabled=Native.IsWindowEnabled(root);
                    Diag.EventRaw("foreground_gap",gap.ElapsedMilliseconds+" ms, then "+(front==root?"COSTAR":front==IntPtr.Zero?"still none":"another window"));
                }
                if(front!=root && enabled && focusRecoveries<3 && (front==IntPtr.Zero || Native.Pid(front)!=pid) && !Native.UserActiveWithin(2000)) {
                    // Another app took the screen and nobody is typing: bring COSTAR back once.
                    focusRecoveries++;
                    if(Native.BringToFront(root)) { Diag.EventRaw("focus_recovered","attempt "+focusRecoveries); front=root; }
                }
                if(front!=root || !enabled) {Diag.ForegroundLost(front,enabled);throw new InvalidOperationException("COSTAR lost focus or opened another screen. Entry stopped; check the current form.");}
            }
        }
        void Pause(int ms) { var slept=Stopwatch.StartNew(); try { for(int i=0;i<ms;i+=50) { Check(false); Thread.Sleep(Math.Min(50,ms-i)); } } finally { Diag.Pause(slept.ElapsedMilliseconds); } }
        // COSTAR answers a no-op message only when its UI thread is processing
        // messages again. Waiting for that avoids reading or clicking while it is
        // busy loading or redrawing. It never sends input.
        void WaitIdle(int maxMs) {
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<maxMs) {
                Check(false);
                int remaining=maxMs-(int)timer.ElapsedMilliseconds;
                UIntPtr result;var call=Stopwatch.StartNew();
                if(Native.SendNull(root,0,UIntPtr.Zero,IntPtr.Zero,0x0002,(uint)Math.Max(1,Math.Min(250,remaining)),out result)!=IntPtr.Zero)break;
                if(!Native.IsWindow(root))break;
                if(call.ElapsedMilliseconds<20)Thread.Sleep(20); // Reported as not responding: do not spin.
            }
            long waited=timer.ElapsedMilliseconds;
            if(waited>=3){idleWaitedMs+=waited;Diag.IdleWait(waited);}
        }
        // Reads the customer/header map, tolerating a brief redraw (for example
        // while COSTAR loads an existing customer's account).
        FieldMap HeaderNow() {
            // Reuse the last header map while the customer panel is unchanged: no full
            // screen read, and each field's value is read live only when it is used.
            var cached=headerCache;
            if(cached!=null) {
                Check(true);WaitIdle(3000);
                if(HeaderStill(cached)) { headerHits++; return LiveHeader(cached); }
                headerCache=null;
            }
            var timer=Stopwatch.StartNew();
            while(true) {
                try { var m=Selectors.Header(Current()); headerCache=m; return m; }
                catch(InvalidOperationException) {
                    if(timer.ElapsedMilliseconds>=3000 || Native.GetForegroundWindow()!=root) throw;
                    Pause(30);
                }
            }
        }
        static ControlInfo[] Fields(FieldMap m) { return new[]{m.Name,m.Account,m.Address,m.Address2,m.Suburb,m.State,m.Postcode,m.Phone,m.Email,m.PO,m.Comment}; }
        // Unchanged means every mapped field is the same window, still visible and
        // enabled, under the same parent, at the same position and size. An existing
        // customer's account rebuilds the panel, which fails this and forces a full read.
        bool HeaderStill(FieldMap m) {
            foreach(var c in Fields(m)) {
                var h=new IntPtr(c.Handle);Native.Rect box;
                if(!Native.IsWindow(h) || Native.Pid(h)!=pid || !Native.IsWindowVisible(h) || !Native.IsWindowEnabled(h) ||
                    Native.GetAncestor(h,2)!=root || Native.GetParent(h).ToInt64()!=c.Parent || !Native.GetWindowRect(h,out box) ||
                    box.Left!=c.Bounds[0] || box.Top!=c.Bounds[1] || box.Right-box.Left!=c.Bounds[2] || box.Bottom-box.Top!=c.Bounds[3]) return false;
            }
            return true;
        }
        ControlInfo Fresh(ControlInfo c) {
            return new ControlInfo { Handle=c.Handle,Root=c.Root,Parent=c.Parent,Style=c.Style,Class=c.Class,Visible=c.Visible,Enabled=c.Enabled,Password=c.Password,
                Bounds=c.Bounds,RelativeBounds=c.RelativeBounds,TextState="skipped",Late=liveRead };
        }
        FieldMap LiveHeader(FieldMap m) {
            return new FieldMap { Name=Fresh(m.Name),Account=Fresh(m.Account),Address=Fresh(m.Address),Address2=Fresh(m.Address2),Suburb=Fresh(m.Suburb),
                State=Fresh(m.State),Postcode=Fresh(m.Postcode),Phone=Fresh(m.Phone),Email=Fresh(m.Email),PO=Fresh(m.PO),Comment=Fresh(m.Comment) };
        }
        void FastTimer(){if(!fastTimer)fastTimer=Native.timeBeginPeriod(1)==0;}
        // A normal idle form reads every field. If some could not be read, COSTAR is still
        // drawing: read again (up to 5 s) rather than judge an order from a half-read form.
        List<ControlInfo> Settled(List<ControlInfo> s) {
            var timer=Stopwatch.StartNew();
            while((lastSnapshotBusy || s.Any(c=>c.TextState=="read-failed-or-timed-out")) && timer.ElapsedMilliseconds<5000) { Pause(150); s=Current(); }
            return s;
        }
        List<ControlInfo> Snapshot(IntPtr window) { return Snapshot(window,window,null); }
        List<ControlInfo> Snapshot(IntPtr window,IntPtr subtree) { return Snapshot(window,subtree,null); }
        // Two phases. Phase 1 records every control's geometry, class and state: these
        // are local Windows calls and cost almost nothing. Phase 2 reads text, which is a
        // cross-process round trip per control and the expensive part. "pick" (optional)
        // names the controls whose text is needed now; other readable controls are marked
        // "skipped" and read on demand only if something asks. Button captions are read
        // only on popups: the Repair Order form and item grid never use them.
        List<ControlInfo> Snapshot(IntPtr window,IntPtr subtree,Func<List<ControlInfo>,HashSet<long>> pick) {
            Check(false);WaitIdle(8000);int readsBefore=controlTextReads;
            Native.Rect rb; Order.Require(Native.GetWindowRect(window,out rb),"Cannot read the COSTAR window bounds.");
            var handles=new List<IntPtr>(400);
            uint windowPid=Native.Pid(window);
            bool popup=window!=root;
            Native.EnumChildWindows(subtree,delegate(IntPtr h,IntPtr unused) { if(Native.Pid(h)==windowPid && Native.IsWindowVisible(h)) handles.Add(h); return handles.Count<4000; },IntPtr.Zero);
            Order.Require(handles.Count<4000,"Unexpectedly large control tree.");
            var result=new List<ControlInfo>(handles.Count); var elapsed=Stopwatch.StartNew();
            int checkedControls=0;long windowHandle=window.ToInt64();
            foreach(var h in handles) {
                if(Cancel || (checkedControls++%64)==0) Check(false);
                Native.Rect box; if(!Native.GetWindowRect(h,out box)) continue;
                var c=new ControlInfo { Handle=h.ToInt64(),Root=windowHandle,Parent=Native.GetParent(h).ToInt64(),Class=ClassOf(h),Style=Native.GetWindowLong(h,-16),
                    Visible=true,Enabled=Native.IsWindowEnabled(h),Bounds=new[]{box.Left,box.Top,box.Right-box.Left,box.Bottom-box.Top},RelativeBounds=new[]{box.Left-rb.Left,box.Top-rb.Top,box.Right-box.Left,box.Bottom-box.Top},TextState="not-read" };
                c.Password=c.Class.IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)>=0 && (c.Style&0x20)!=0;
                result.Add(c);
            }
            HashSet<long> wanted=pick==null?null:pick(result);
            checkedControls=0;
            // Every text read is a request COSTAR's screen thread must answer. While COSTAR is
            // busy (searching, loading) those requests pile up and it has to work through
            // them afterwards: the lag seen in 2.0.x. So: one cheap "are you there?" first and
            // no reads at all if it is not answering; and the first read that fails stops all
            // further reads in this snapshot. Callers see "busy" and simply look again later.
            bool busy=!Responsive(window,60);
            foreach(var c in result) {
                if(c.Password || !(c.Edit || c.Static || (popup && c.Class.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0))) continue;
                if(wanted!=null && !wanted.Contains(c.Handle)) { c.TextState="skipped";c.Late=lateRead;skippedReads++;continue; }
                if(busy) { c.TextState="busy";busySkips++;continue; }
                if(Cancel || (checkedControls++%32)==0) Check(false);
                Order.Require(elapsed.ElapsedMilliseconds<8000,"COSTAR is still busy reading fields. Wait for it to finish and retry on an empty order.");
                ReadText(c);
                if(c.TextState!="read" && !Responsive(window,30)) busy=true;
            }
            lastSnapshotBusy=busy;if(busy)busySnapshots++;
            Check(false);snapshotCount++;snapshotMilliseconds+=elapsed.ElapsedMilliseconds;
            Diag.Snapshot(window!=subtree?"grid":(window==root?"full":"popup"),elapsed.ElapsedMilliseconds,controlTextReads-readsBefore);return result;
        }
        // COSTAR answers a no-op message within ms when its screen thread is free.
        bool Responsive(IntPtr window,int ms) {
            UIntPtr result;
            return Native.SendNull(window,0,UIntPtr.Zero,IntPtr.Zero,0x0002,(uint)ms,out result)!=IntPtr.Zero;
        }
        void ReadText(ControlInfo c) {
            controlTextReads++;string value;bool ok=Native.TryText(new IntPtr(c.Handle),out value);
            c.Text=value;c.TextState=ok?"read":"read-failed-or-timed-out";
        }
        // A skipped control that something asked for after all. Correct either way; the
        // diagnostics count these so the read plan can be tightened if one is ever missed.
        void LateRead(ControlInfo c) {
            lateReads++;ReadText(c);
            if(lateReads<=20)Diag.EventRaw("late_read",RunDiagnostics.KindOf(c.Class)+" @"+c.X+","+c.Y+" "+c.W+"x"+c.H);
        }
        // Header fields returned from the cached map are read live on first use.
        void LiveRead(ControlInfo c){headerReads++;ReadText(c);}
        // Control classes never change for a window, so look each one up once per run.
        string ClassOf(IntPtr h) {
            string name;long key=h.ToInt64();
            if(classCache.TryGetValue(key,out name)) return name;
            if(classCache.Count>6000) classCache.Clear();
            name=Native.Class(h);classCache[key]=name;return name;
        }
        List<ControlInfo> Current() {
            var waited=Stopwatch.StartNew();
            while(true) {
                Check(true);var s=Snapshot(root);
                if(!lastSnapshotBusy || waited.ElapsedMilliseconds>=20000) return s;
                Pause(150);
            }
        }
        List<ControlInfo> GridCurrent() {
            Check(true);
            // Cache the container identity only. Rediscover live rows and values
            // on every read, including after DET creates or moves note controls.
            if(gridPanel==IntPtr.Zero || !Native.IsWindow(gridPanel) || Native.Pid(gridPanel)!=pid ||
                Native.GetAncestor(gridPanel,2)!=root || !Native.IsWindowVisible(gridPanel) ||
                !Native.IsWindowEnabled(gridPanel) || Native.GetParent(gridPanel).ToInt64()!=gridPanelParent || Native.Class(gridPanel)!=gridPanelClass) {
                var full=Current();var labels=full.Where(c=>c.Static && Order.Norm(c.Peek)=="ITEM").ToList();
                if(labels.Count!=1){gridPanel=IntPtr.Zero;gridLabels=null;return full;}
                gridPanel=new IntPtr(labels[0].Parent);
                Order.Require(Native.Pid(gridPanel)==pid && Native.GetAncestor(gridPanel,2)==root,"The item grid does not belong to this Repair Order.");
                gridPanelParent=Native.GetParent(gridPanel).ToInt64();gridPanelClass=Native.Class(gridPanel);
                RememberGridLabels(full);
                return full;
            }
            // Callers keep their normal wait/retry around row validation; temporary
            // overlapping rows during expansion must not fail before that wait.
            // Read plan: only the five header labels and the cells under them. The grid
            // holds ~180 readable controls; the engine's logic consults ~45 of them.
            var known=gridLabels;
            var snapshot=known==null?Snapshot(root,gridPanel):Snapshot(root,gridPanel,delegate(List<ControlInfo> s){return Selectors.GridReadSet(s,known);});
            gridSnapshotCount++;
            if(known==null) RememberGridLabels(snapshot);
            else if(!GridLabelsStill(snapshot,known)) {
                // A remembered label moved or changed: finish reading this snapshot in full
                // and learn the labels again, exactly as before the read plan existed.
                gridLabels=null;Diag.EventRaw("grid_read_plan_reset","header labels changed");
                foreach(var c in snapshot) if(c.Skipped){c.Late=null;ReadText(c);}
                RememberGridLabels(snapshot);
            }
            return snapshot;
        }
        static readonly string[] GridLabelNames={"ITEM","DESCRIPTION","QTY OR HRS","NET","LIST"};
        void RememberGridLabels(List<ControlInfo> s) {
            try { var g=Selectors.ProductGrid(s); gridLabels=new[]{g.Item.Handle,g.Description.Handle,g.Quantity.Handle,g.Net.Handle,g.ListPrice.Handle}; }
            catch(InvalidOperationException) { gridLabels=null; }
        }
        static bool GridLabelsStill(List<ControlInfo> s,long[] labels) {
            for(int i=0;i<labels.Length;i++) {
                long handle=labels[i];var c=s.FirstOrDefault(x=>x.Handle==handle);
                if(c==null || Order.Norm(c.Peek)!=GridLabelNames[i]) return false;
            }
            return true;
        }
        void Dump(string name,List<ControlInfo> data) { File.WriteAllText(Path.Combine(Folder,name+".json"),json.Serialize(data),new UTF8Encoding(false)); }
        void CaptureForegroundWindow(string stage) {
            // The old report captured only the Repair Order behind a dialog.
            // Keep the actual COSTAR window too, so a new notice can be mapped.
            try {
                var front=Native.GetForegroundWindow();
                if(front==root || !Native.IsWindow(front)) return;
                Native.Rect box; if(!Native.GetWindowRect(front,out box)) return;
                File.WriteAllText(Path.Combine(Folder,"foreground-window.json"),json.Serialize(new {
                    At=DateTimeOffset.Now.ToString("o"),Version=AutofillForm.Version,Step=stage,Handle=front.ToInt64(),Parent=Native.GetParent(front).ToInt64(),
                    Class=Native.Class(front),Title=Native.Caption(front),ProcessId=Native.Pid(front),CostarProcessId=pid,RepairOrderEnabled=Native.IsWindowEnabled(root),Enabled=Native.IsWindowEnabled(front),Bounds=new[]{box.Left,box.Top,box.Right-box.Left,box.Bottom-box.Top}
                }),new UTF8Encoding(false));
                if(Native.Pid(front)==pid || IsCustomerPopup(front)) {var popup=Snapshot(front);Dump("foreground-controls",popup);Diag.Popup(front,popup);}
            } catch { /* Diagnostics must not hide the original stop reason. */ }
        }
        void Ready() {
            WaitIdle(3000);var timer=Stopwatch.StartNew();int spins=0;
            try {
                while(timer.ElapsedMilliseconds<15000) {
                    Check(false);
                    string title;
                    if(Native.GetForegroundWindow()==root && Native.IsWindowEnabled(root) && Native.TryText(root,out title)) return;
                    if(enteringCustomer) { CustomerFormReady(0);return; }
                    if(Native.GetForegroundWindow()!=root) {
                        Diag.ForegroundLost(Native.GetForegroundWindow(),Native.IsWindowEnabled(root));
                        throw new InvalidOperationException("COSTAR opened another screen or lost focus. Entry stopped for you to check it.");
                    }
                    spins++;Pause(25);
                }
                throw new InvalidOperationException("COSTAR did not become ready in time.");
            } finally { if(spins>0) Diag.ReadyWait(timer.ElapsedMilliseconds); }
        }
        void CheckTarget(ControlInfo c) {
            Check(true); var h=new IntPtr(c.Handle);
            Order.Require(c.Edit && Native.Pid(h)==pid && Native.IsWindowVisible(h) && Native.IsWindowEnabled(h) && Native.GetAncestor(h,2)==root && Native.GetParent(h).ToInt64()==c.Parent && Native.Class(h)==c.Class && (Native.GetWindowLong(h,-16)&0x20)==0,"The target field changed before entry.");
        }
        void ClickTarget(ControlInfo c) {
            WaitIdle(2000);CheckTarget(c); var h=new IntPtr(c.Handle);
            Native.Rect box; Order.Require(Native.GetWindowRect(h,out box),"Cannot locate the target field.");
            var point=new Native.Point { X=box.Left+Math.Min(9,Math.Max(2,(box.Right-box.Left)/4)),Y=box.Top+Math.Min(10,Math.Max(2,(box.Bottom-box.Top)/2)) };
            IntPtr hit=Native.WindowFromPoint(point);
            if(hit!=h) {
                // 4 Oct: on a brand-new Repair Order something sat over the first field for a
                // moment (a retry on the same order always worked). Record what it was, then
                // wait up to 1.5 s for it to go; bring COSTAR back once if another app is on top.
                Diag.EventRaw("covered",DescribeCover(hit));
                var wait=Stopwatch.StartNew();bool raised=false;
                while(hit!=h && wait.ElapsedMilliseconds<1500) {
                    if(!raised && hit!=IntPtr.Zero && Native.Pid(hit)!=pid && !Native.UserActiveWithin(2000)) { raised=true; Native.BringToFront(root); }
                    Thread.Sleep(50);
                    Check(true);
                    if(!Native.GetWindowRect(h,out box)) break;
                    point=new Native.Point { X=box.Left+Math.Min(9,Math.Max(2,(box.Right-box.Left)/4)),Y=box.Top+Math.Min(10,Math.Max(2,(box.Bottom-box.Top)/2)) };
                    hit=Native.WindowFromPoint(point);
                }
                Diag.EventRaw("covered_wait",wait.ElapsedMilliseconds+" ms, "+(hit==h?"cleared":"still covered by "+DescribeCover(hit)));
            }
            Order.Require(hit==h,"The target field is covered. Leave COSTAR unobstructed and retry on an empty order.");
            Native.Click(point);Diag.Click();
        }
        // What is on top of a field: masked to its window class, owner and whether it is
        // COSTAR's own window (titles of other apps are never recorded).
        string DescribeCover(IntPtr hit) {
            if(hit==IntPtr.Zero) return "nothing";
            bool costar=Native.Pid(hit)==pid;IntPtr top=Native.GetAncestor(hit,2);
            return (costar?"COSTAR ":"another app ")+Native.Class(hit)+(costar&&top==root?" inside this Repair Order":costar?" in window \""+Sanitize.Text(Native.Caption(top),40)+"\"":"");
        }
        object DescribeControl(IntPtr h) {
            if(h==IntPtr.Zero || Native.Pid(h)!=pid || Native.GetAncestor(h,2)!=root) return null;
            Native.Rect box; Native.GetWindowRect(h,out box);
            string cls=Native.Class(h),text=null; int style=Native.GetWindowLong(h,-16);
            if(cls.IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)>=0 && (style&0x20)==0) Native.TryText(h,out text);
            return new { Handle=h.ToInt64(),Parent=Native.GetParent(h).ToInt64(),Class=cls,Style=style,Text=text,
                Bounds=new[]{box.Left,box.Top,box.Right-box.Left,box.Bottom-box.Top} };
        }
        void TraceFocus(string stage,ControlInfo expected) {
            try {
                IntPtr focus=Native.Focus(root),front=Native.GetForegroundWindow(); Native.Rect box; Native.GetWindowRect(root,out box);
                log.WriteLine(json.Serialize(new { At=DateTimeOffset.Now.ToString("o"),Version=AutofillForm.Version,Type="focus",
                    Step=stage,Writes=writes,ForegroundIsRepairOrder=front==root,RepairOrderBounds=new[]{box.Left,box.Top,box.Right-box.Left,box.Bottom-box.Top},
                    Expected=expected,ExpectedLive=expected==null?null:DescribeControl(new IntPtr(expected.Handle)),ActualFocus=DescribeControl(focus) }));
            } catch { /* Diagnostics must not change entry behavior. */ }
        }
        // 2.6.5: the keyboard to a box directly (Direct.Focus: no mouse), checked; a click into it only when
        // the box doesn't have the keyboard after that (a second way into the same box can't do harm).
        bool FocusDirect(ControlInfo c) {
            if(!Direct.On) return false;
            WaitIdle(2000);CheckTarget(c);var h=new IntPtr(c.Handle);
            bool came=Direct.Focus(h,3000,()=>Cancel);Diag.Pressed();Check(true);
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<800) {
                Check(true);
                if(Native.Focus(root)==h) { Diag.FocusWait(timer.ElapsedMilliseconds);return true; }
                Pause(25);
            }
            Diag.EventRaw("direct_fallback","box "+Shape(h)+": "+(came?"the keyboard didn't stay there":"COSTAR didn't answer")+", a click instead");
            return false;
        }
        // The keyboard to a box once, for a caller that checks where it went and tries again (leaving the item
        // lines, a note line): directly, or with one click (mouse: the caller's later tries, or direct presses
        // off). Like a click it doesn't wait for COSTAR to finish with the box it leaves (DET makes its notes
        // then): 0.6 s at most, then the caller looks.
        void FocusOrClick(ControlInfo c,bool mouse) {
            if(mouse||!Direct.On) { ClickTarget(c);return; }
            WaitIdle(2000);CheckTarget(c);
            if(!Direct.Focus(new IntPtr(c.Handle),600,()=>Cancel)) Diag.EventRaw("direct_slow","COSTAR still on the keyboard going to "+Shape(new IntPtr(c.Handle))+" after 0.6 s");
            Diag.Pressed();Check(true);
        }
        void Focus(ControlInfo c) {
            CheckTarget(c);if(Native.Focus(root).ToInt64()==c.Handle)return;
            if(FocusDirect(c)) return;
            ClickTarget(c); var h=new IntPtr(c.Handle);
            var timer=Stopwatch.StartNew();var trace=new List<string>();IntPtr seen=new IntPtr(-1);
            while(timer.ElapsedMilliseconds<2000) {
                Check(true);var now=Native.Focus(root);
                if(now==h) {Diag.FocusWait(timer.ElapsedMilliseconds);return;}
                if(now!=seen && trace.Count<40) {seen=now;trace.Add(timer.ElapsedMilliseconds+"ms "+Shape(now));}
                Pause(25);
            }
            Diag.FocusFailed(Shape(h),trace);
            TraceFocus("Ordinary field focus failed",c);
            throw new InvalidOperationException("COSTAR did not focus the expected field.");
        }
        // Control kind, handle and position relative to the Repair Order. No text.
        string Shape(IntPtr h) {
            if(h==IntPtr.Zero) return "none";
            try {
                if(Native.Pid(h)!=pid) return "outside-COSTAR";
                Native.Rect box,rb;Native.GetWindowRect(h,out box);Native.GetWindowRect(root,out rb);
                return RunDiagnostics.KindOf(Native.Class(h))+"#"+h.ToInt64()+"@"+(box.Left-rb.Left)+","+(box.Top-rb.Top)+"+"+(box.Right-box.Left)+"x"+(box.Bottom-box.Top)+
                    (h==lastWritten?" (last written field)":"")+(Native.GetAncestor(h,2)!=root?" (other window)":"");
            } catch { return "unreadable"; }
        }
        void ReadEquals(ControlInfo c,string value,string label) {
            string actual; var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<2500) {
                Check(true);
                if(Native.TryText(new IntPtr(c.Handle),out actual) && Order.Clean(actual)==Order.Clean(value)) return;
                Pause(25);
            }
            throw new InvalidOperationException(label + " did not retain the expected value. Entry stopped.");
        }
        static string FieldText(string value,bool lowerCase) {
            return lowerCase?(value??"").ToLowerInvariant():Order.EntryText(value);
        }
        void Put(ControlInfo c,string value,string label,bool tab,bool lowerCase=false) {
            value=FieldText(value,lowerCase); Order.Safe(value,label,500);
            Focus(c); WriteFocused(c,value,label,tab,lowerCase);
        }
        void WriteFocused(ControlInfo c,string value,string label,bool tab,bool lowerCase=false) {
            value=FieldText(value,lowerCase); Order.Safe(value,label,500);
            CheckTarget(c); var h=new IntPtr(c.Handle);
            int style=Native.GetWindowLong(h,-16);
            Order.Require(c.Edit && (style&0x820)==0 && Native.Focus(root)==h,"The " + label + " field is read-only or protected.");
            BeforeWrite();
            UIntPtr result;var writeTimer=Stopwatch.StartNew();
            Order.Require(Native.WriteMessage(h,0xC,UIntPtr.Zero,value,3,1500,out result)!=IntPtr.Zero && result!=UIntPtr.Zero,"COSTAR did not accept " + label + ".");
            long setMs=writeTimer.ElapsedMilliseconds;lastWritten=h;
            writes++; ReadEquals(c,value,label);Diag.Write(setMs,writeTimer.ElapsedMilliseconds-setMs);
            Check(true);
            // Preserve the edit control's normal "modified" state for validation on Tab.
            Order.Require(Native.WriteMessage(h,0xB9,new UIntPtr(1),null,3,500,out result)!=IntPtr.Zero,"COSTAR did not mark " + label + " as edited.");
            if(tab) CommitField(c);
            Say("Entered " + label + ".");
        }
        void CommitField(ControlInfo c) {
            CheckTarget(c);var h=new IntPtr(c.Handle);
            Order.Require(Native.Focus(root)==h,"The field lost focus before validation.");
            Check(true);Native.Key(9);Diag.Key();var timer=Stopwatch.StartNew();
            // Most fields commit within milliseconds; a phone lookup can take seconds
            // when COSTAR is slow (4 Oct: 2.5 s), so allow 8 s before giving up.
            while(timer.ElapsedMilliseconds<8000) {
                Check(false);
                // A phone lookup can open its notice before Tab reaches the next field.
                if(Native.GetForegroundWindow()!=root || !Native.IsWindowEnabled(root)){Diag.Commit(timer.ElapsedMilliseconds,"dialog");return;}
                var focus=Native.Focus(root);
                if(focus!=IntPtr.Zero && focus!=h){Diag.Commit(timer.ElapsedMilliseconds,"moved");return;}
                Pause(25);
            }
            Diag.Commit(timer.ElapsedMilliseconds,"timeout");
            throw new InvalidOperationException("COSTAR did not commit the field after Tab.");
        }
    }
}
