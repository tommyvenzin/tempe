// The entry engine, part 6 (2.6.2): printing a Repair Order's Job Card, only when the phone asked for
// it (Tommy, 27 Oct: "click print on the top left", then in the print form "tick print job card and
// untick invoice, qty stay 1, and to can be left oki, if its not possible, then keep it to default").
// The only print the helper ever does. Print is found by its own name (never by where it sits: Sell is
// next to it); the print form must be this Repair Order's (its number in the title) and must show
// exactly the Job Card ticked to print, nothing else ticked to print or to email, before OK. Anything
// else: the form is cancelled (nothing printed) or, if it can't be, left for a person. A COSTAR message
// is read, never answered.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    // The print form's layout, from its controls: the Print, Qty and eMail columns by their headings; a
    // row for every tick box under Print, named by the first label on its line right of the eMail column
    // (Job Card, (COPY) Invoice, Freight Label, Delivery Docket); the row's eMail box and quantity box on
    // the same line (the Job Card's quantity box must be found: "qty stay 1" is checked, never assumed);
    // OK and Cancel. Null with the reason when any of it isn't clear.
    internal static class PrintForm {
        internal sealed class Row { internal string Name="";internal ControlInfo Label,Print,Email,Qty; }
        internal sealed class Layout { internal readonly List<Row> Rows=new List<Row>();internal Row JobCard;internal ControlInfo Ok,Cancel; }
        // Words as COSTAR shows them, compared without case, & and punctuation (brackets and # kept).
        internal static string Words(string text) { return Regex.Replace(Order.Norm((text??"").Replace("&","")),@"[^A-Z0-9()#]+"," ").Trim(); }
        static string Words(ControlInfo c) { return c!=null&&c.TextState=="read"?Words(c.Text):""; }
        static int Cx(ControlInfo c) { return c.X+c.W/2; }
        static int Cy(ControlInfo c) { return c.Y+c.H/2; }
        static bool SameLine(ControlInfo a,ControlInfo b) { return Math.Abs(Cy(a)-Cy(b))<=Math.Max(8,Math.Min(a.H,b.H)/2+2); }
        static bool Button(ControlInfo c) { return c.Visible&&c.Class.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0; }
        static bool Under(ControlInfo c,ControlInfo heading) { return Math.Abs(Cx(c)-Cx(heading))<=Math.Max(14,heading.W/2+6)&&c.Y>heading.Y+heading.H/2; }
        // isTick: whether a button is a tick box (accessibility says so on the PC).
        internal static Layout Read(List<ControlInfo> s,Func<ControlInfo,bool> isTick,out string problem) {
            problem=null;
            if(s==null) { problem="it couldn't be read";return null; }
            var labels=s.Where(c=>c.Static&&c.TextState=="read").ToList();
            var print=labels.Where(c=>Words(c)=="PRINT").ToList();
            var email=labels.Where(c=>{string w=Words(c);return w=="EMAIL"||w=="E MAIL";}).ToList();
            var qty=labels.Where(c=>Words(c)=="QTY").ToList();
            if(print.Count!=1||email.Count!=1) { problem="its Print and eMail columns weren't found";return null; }
            if(qty.Count!=1) { problem="its Qty column wasn't found";return null; }
            ControlInfo ph=print[0],eh=email[0],qh=qty[0];
            var ticks=s.Where(c=>Button(c)&&isTick(c)).ToList();
            var map=new Layout();
            foreach(var box in ticks.Where(b=>Under(b,ph)).OrderBy(b=>b.Y)) {
                var row=new Row {Print=box};
                var mails=ticks.Where(b=>!Object.ReferenceEquals(b,box)&&SameLine(b,box)&&Under(b,eh)).ToList();
                if(mails.Count!=1) { problem="a row's eMail box wasn't clear";return null; }
                row.Email=mails[0];
                var names=labels.Where(l=>SameLine(l,box)&&l.X>=row.Email.X+row.Email.W&&Words(l).Length>0).OrderBy(l=>l.X).ToList();
                if(names.Count==0) { problem="a row has no document name";return null; }
                row.Label=names[0];row.Name=Words(names[0]);
                // Its quantity: the one edit box under Qty on its line (a number box's own edit box), else
                // the one other box there whose words could be read.
                var under=s.Where(c=>c.Visible&&!Button(c)&&!Object.ReferenceEquals(c,qh)&&SameLine(c,box)&&Under(c,qh)).ToList();
                var edits=under.Where(c=>c.Class.IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)>=0).ToList();
                if(edits.Count==1) row.Qty=edits[0];
                else if(edits.Count==0&&under.Count==1&&under[0].TextState=="read") row.Qty=under[0];
                map.Rows.Add(row);
            }
            if(map.Rows.Count==0) { problem="it has no tick boxes under Print";return null; }
            // Each tick box is in one row and one column only, and every one under eMail is in a row.
            var used=map.Rows.SelectMany(r=>new[]{r.Print,r.Email}).ToList();
            if(used.Distinct().Count()!=used.Count||ticks.Count(b=>Under(b,eh))!=map.Rows.Count) { problem="its tick boxes weren't clear";return null; }
            var jobs=map.Rows.Where(r=>r.Name.Contains("JOB CARD")).ToList();
            if(jobs.Count!=1) { problem=jobs.Count==0?"it has no Job Card row":"it has "+jobs.Count+" Job Card rows";return null; }
            map.JobCard=jobs[0];
            if(map.JobCard.Qty==null) { problem="the Job Card's quantity box wasn't clear";return null; }
            var ok=s.Where(c=>Button(c)&&!isTick(c)&&Words(c)=="OK").ToList();
            var cancel=s.Where(c=>Button(c)&&!isTick(c)&&Words(c)=="CANCEL").ToList();
            if(ok.Count!=1) { problem="its OK button wasn't found";return null; }
            map.Ok=ok[0];map.Cancel=cancel.Count==1?cancel[0]:null;
            return map;
        }
        // What the form must show before OK, or why not: the Job Card ticked to print, no other document
        // ticked to print, nothing ticked to email, the Job Card's quantity 1.
        // ticked: a tick box's state; qtyText: a quantity box's text (null: it couldn't be read).
        internal static string Wrong(Layout map,Func<ControlInfo,bool?> ticked,Func<ControlInfo,string> qtyText) {
            if(map==null||map.JobCard==null) return "the form wasn't read";
            foreach(var r in map.Rows) {
                bool? p=ticked(r.Print),m=ticked(r.Email);
                if(p==null||m==null) return "the ticks for "+Title(r)+" couldn't be read";
                if(Object.ReferenceEquals(r,map.JobCard)?p!=true:p!=false) return Object.ReferenceEquals(r,map.JobCard)?"the Job Card isn't ticked to print":Title(r)+" is still ticked to print";
                if(m!=false) return Title(r)+" is ticked to email";
            }
            if(map.JobCard.Qty==null) return "the Job Card's quantity couldn't be read";
            string raw=qtyText(map.JobCard.Qty);if(raw==null) return "the Job Card's quantity couldn't be read";
            string q=Order.Clean(raw);if(q!="1") return "the Job Card's quantity is "+(q.Length>0?q:"empty")+", not 1";
            return null;
        }
        internal static string Title(Row r) {
            if(r.Name.Contains("JOB CARD")) return "the Job Card";
            if(r.Name.Contains("INVOICE")) return "the Invoice";
            string t=r.Label==null?"":Order.Clean(r.Label.Text);
            return t.Length>0&&t.Length<=40?"the "+t:"a document";
        }
        // The Repair Order number in the print form's title ("Print RepairOrder 07490123"): "" when the
        // title is the print form's without a number, null when it isn't the print form's.
        internal static string TitleNumber(string caption) {
            var m=Regex.Match(caption??"",@"^\s*Print\s*Repair\s*Order(?:\s+([0-9A-Za-z-]{1,20}))?\s*$",RegexOptions.IgnoreCase);
            return m.Success?m.Groups[1].Value:null;
        }
        // Two Repair Order numbers are the same (leading zeros aside).
        internal static bool SameNumber(string a,string b) {
            string x=Order.Norm(a??""),y=Order.Norm(b??"");
            if(x.Length==0||y.Length==0) return false;
            if(Regex.IsMatch(x,@"^\d+$")&&Regex.IsMatch(y,@"^\d+$")) return x.TrimStart('0')==y.TrimStart('0');
            return x==y;
        }
    }

    // What a print came to (2.6.2). Words: for the phone and the day log. Printed: OK went and the print
    // form closed. Maybe: OK went (or the form went some other way) but how it ended can't be told: never
    // said as "not printed", so it isn't asked for again blindly. Stopped: a Stop came (nothing more is
    // clicked; the caller doesn't close the Repair Order either).
    internal sealed class PrintResult { internal string Words="";internal bool Printed,Maybe,Stopped; }
    internal sealed partial class Runner {
        // Where COSTAR's Print is: its own window (a button), or a point where accessibility finds an
        // object named Print (a toolbar COSTAR draws itself).
        sealed class PrintButton { internal IntPtr Window;internal Native.Point Point;internal string How; }
        // This print: OK was clicked on its form; its end can't be told.
        bool printOk,printMaybe;
        // Prints the Job Card of the Repair Order in front (number: its number when known, checked
        // against the print form's title). beforeOk: called just before OK goes (the caller notes that the
        // print may have gone). Never throws (a Stop included: the caller goes on).
        internal PrintResult PrintJobCard(string number,Action beforeOk) {
            var result=new PrintResult();printOk=false;printMaybe=false;
            Diag.BeginStage("Print the Job Card");Stage("Printing the Job Card");
            try {
                bool printed;result.Words=PrintJobCardCore(number,beforeOk,out printed);result.Printed=printed;
            } catch(OperationCanceledException) {
                result.Stopped=true;
                result.Words=printOk?"The Job Card may have printed (stopped after OK on the print form): check the printer.":printMaybe?"The Job Card may have printed (stopped while COSTAR may still open the print form): check COSTAR and the printer.":"Job Card not printed: stopped. Check COSTAR (the print form may be open).";
            } catch(Exception e) {
                string why=e.Message.TrimEnd('.',' ');
                // 2.6.5: printMaybe too (a Print press COSTAR may still be on): never "Print it at the PC" then.
                result.Words=printOk||printMaybe?"The Job Card may have printed ("+why+"): check the printer.":"Job Card not printed: "+why+". Print it at the PC.";
                try { CaptureForegroundWindow("print"); } catch(Exception) { }
            } finally { Diag.EndStage(result.Printed); }
            result.Maybe=!result.Printed&&(printOk||printMaybe);
            if(result.Maybe&&result.Words.IndexOf("may have printed",StringComparison.OrdinalIgnoreCase)<0) result.Words="The Job Card may have printed ("+result.Words.TrimEnd('.',' ')+"): check the printer.";
            Say(result.Words);Diag.EventRaw("print_job_card",(result.Printed?"printed: ":result.Maybe?"may have printed: ":"not printed: ")+result.Words);
            return result;
        }
        string PrintJobCardCore(string number,Action beforeOk,out bool printed) {
            printed=false;
            Check(false);WaitIdle(3000);
            string blocked=CloseBlocker(root);
            Order.Require(blocked==null,blocked+" (answer it at the PC first)");
            // Never brought in front under someone's hands.
            Order.Require(!Native.UserActiveWithin(2000),"someone is using the COSTAR PC, so the print wasn't started");
            ActivateAndWait();
            Order.Require(Native.GetForegroundWindow()==root&&Native.IsWindowEnabled(root),"the Repair Order isn't in front");
            var button=FindPrintButton();
            Order.Require(button!=null,"COSTAR's Print button wasn't found on the Repair Order");
            var before=OwnWindows();
            Quiet("Print");
            if(!PressPrint(button)) ClickPrint(button);
            IntPtr form=WaitForPrintForm(before,number);
            return FillPrintForm(form,beforeOk,out printed);
        }
        // Nobody at the PC for the last 1.5 s (the helper's own input aside) before each click of a print.
        void Quiet(string what) {
            Order.Require(!Native.UserActiveWithin(1500),"someone is using the COSTAR PC, so "+what+" wasn't clicked");
        }
        // COSTAR's own windows that show now (to see which one opens next).
        HashSet<long> OwnWindows() {
            var set=new HashSet<long>();
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) { if(Native.Pid(w)==pid&&Native.IsWindowVisible(w)) set.Add(w.ToInt64());return true; },IntPtr.Zero);
            return set;
        }
        PrintButton FindPrintButton() {
            var found=new List<IntPtr>();var seen=new List<string>();
            Native.EnumChildWindows(root,delegate(IntPtr h,IntPtr unused) {
                if(!Native.IsWindowVisible(h)||Native.Class(h).IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)<0) return true;
                string t;if(!Native.TryText(h,out t)) return true;
                string w=PrintForm.Words(t);
                if(w.Length>0&&w.Length<=20&&seen.Count<40) seen.Add(w);
                // Tick boxes, radio buttons and groups are button windows too: only a push button is Print.
                if(w=="PRINT"&&PushButton(h)) found.Add(h);
                return found.Count<5;
            },IntPtr.Zero);
            if(found.Count==1) {
                Order.Require(Native.IsWindowEnabled(found[0]),"COSTAR's Print button is greyed out on this Repair Order");
                Native.Rect r=new Native.Rect();Order.Require(Native.GetWindowRect(found[0],out r),"COSTAR's Print button moved");
                Diag.EventRaw("print_button","a button of its own");
                return new PrintButton {Window=found[0],Point=new Native.Point {X=(r.Left+r.Right)/2,Y=(r.Top+r.Bottom)/2},How="button"};
            }
            Order.Require(found.Count==0,"COSTAR shows "+found.Count+" Print buttons on the Repair Order");
            // A toolbar COSTAR draws itself: an accessible push button named Print, within the window.
            Accessibility.IAccessible a=null;List<int[]> named;
            try { a=Msaa.FromWindow(root);named=Msaa.FindNamed(a,n=>PrintForm.Words(n)=="PRINT",new[]{43,56,57,62},8,900); }
            catch(Exception) { named=new List<int[]>(); }
            finally { Msaa.Release(a); }
            Native.Rect box;Order.Require(Native.GetWindowRect(root,out box),"the Repair Order moved");
            named=named.Where(n=>n[0]>=box.Left&&n[1]>=box.Top&&n[0]+n[2]<=box.Right&&n[1]+n[3]<=box.Bottom).ToList();
            Diag.EventRaw("print_button",named.Count==1?"accessible":"not found; buttons: "+String.Join(" | ",seen.ToArray())+"; accessible ones named Print: "+named.Count);
            if(named.Count!=1) return null;
            Order.Require((named[0][4]&0x1)==0,"COSTAR's Print button is greyed out on this Repair Order");
            return new PrintButton {Point=new Native.Point {X=named[0][0]+named[0][2]/2,Y=named[0][1]+named[0][3]/2},How="accessible"};
        }
        static bool PushButton(IntPtr h) { int role;bool on;TickState(h,out role,out on);return role==43; }
        // 2.6.5: Print pressed directly. A Print button window gets its own click posted (BM_CLICK). COSTAR's
        // drawn toolbar has its Print pressed through accessibility: the object at Print's place, which must be
        // named Print (never Sell, next to it), not greyed, the very one the click would check; the press on a
        // thread of its own (COSTAR comes back from it only when the print form closes), and the last look
        // (the Repair Order in front and free, nobody at the PC for 1.5 s) made on that thread just before it.
        // False only when it wasn't pressed at all (then one click, as before): once a press has gone to COSTAR
        // there is never a second one. printPress: that press, while COSTAR may still be on it.
        Direct.Pending printPress;
        bool PressPrint(PrintButton b) {
            printPress=null;
            if(!Direct.On) return false;
            WaitIdle(2000);Check(true);Native.NoModifiers();Quiet("Print");
            if(b.Window!=IntPtr.Zero) {
                Order.Require(Native.IsWindow(b.Window)&&Native.IsWindowVisible(b.Window)&&Native.IsWindowEnabled(b.Window)&&Native.GetAncestor(b.Window,2)==root,"COSTAR's Print button changed");
                if(!Direct.PressLater(b.Window)) { Diag.EventRaw("direct_fallback","Print: the press couldn't be posted, a click instead");return false; }
                Diag.Pressed();Diag.EventRaw("print_press","the Print button's own click");return true;
            }
            var window=root;var at=b.Point;
            var act=Direct.Act(delegate(out object child,out string why) {
                child=null;why=null;
                var hit=Native.WindowFromPoint(at);
                if(hit==IntPtr.Zero||Native.GetAncestor(hit,2)!=window) { why="Print is covered";return null; }
                var found=Msaa.FromPoint(at,out child);
                if(found==null) { why="nothing answers at Print's place";return null; }
                int role=Msaa.RoleOf(found,child??(object)0),st=Msaa.StateOf(found,child??(object)0);
                string name=Msaa.NameOf(found,child??(object)0);
                if(PrintForm.Words(name)!="PRINT"||Array.IndexOf(new[]{43,56,57,62},role)<0) { why="the object at Print's place isn't Print";Msaa.Release(child);child=null;Msaa.Release(found);return null; }
                if(st>=0&&(st&0x1)!=0) { why="Print is greyed out";Msaa.Release(child);child=null;Msaa.Release(found);return null; }
                if(child is int&&(int)child==0) child=null;
                return found;
            },delegate {
                if(Native.GetForegroundWindow()!=window||!Native.IsWindowEnabled(window)) return "the Repair Order isn't in front and free";
                if(Native.UserActiveWithin(1500)) return Direct.PcInUse;
                return null;
            });
            string went=Direct.Went(act,5000,400);
            if(went=="pressed") { printPress=act;Diag.Pressed();Diag.EventRaw("print_press","Print pressed through accessibility");return true; }
            // A press that went to COSTAR and failed may still have done something: never followed by a click.
            if(went=="failed") { printMaybe=true;throw new InvalidOperationException("COSTAR's Print was pressed and the press failed ("+act.PressError+"): check COSTAR, the print form may open"); }
            // The last look's no stops the print (its own record: nothing writes over it).
            string refused=act.Refused;
            if(refused!=null) throw new InvalidOperationException(refused==Direct.PcInUse?"someone is using the COSTAR PC, so Print wasn't pressed":"the Repair Order isn't in front (COSTAR is showing something?), so Print wasn't pressed");
            Order.Require(act.FindError!="Print is greyed out","COSTAR's Print button is greyed out on this Repair Order");
            Diag.EventRaw("direct_fallback","Print: "+act.FindError+", a click instead");
            return false;
        }
        // The click on Print: COSTAR in front, the button where it was and nothing over it; for a drawn
        // toolbar, accessibility must find Print itself under the point.
        void ClickPrint(PrintButton b) {
            WaitIdle(2000);Check(true);
            var p=b.Point;
            if(b.Window!=IntPtr.Zero) {
                Native.Rect r=new Native.Rect();
                Order.Require(Native.IsWindow(b.Window)&&Native.IsWindowVisible(b.Window)&&Native.IsWindowEnabled(b.Window)&&Native.GetAncestor(b.Window,2)==root&&Native.GetWindowRect(b.Window,out r),"COSTAR's Print button changed");
                p=new Native.Point {X=(r.Left+r.Right)/2,Y=(r.Top+r.Bottom)/2};
                Order.Require(Native.WindowFromPoint(p)==b.Window,"COSTAR's Print button is covered");
            } else {
                var hit=Native.WindowFromPoint(p);
                Order.Require(hit!=IntPtr.Zero&&Native.GetAncestor(hit,2)==root,"COSTAR's Print button is covered");
                Order.Require(PrintForm.Words(Msaa.NameAt(p))=="PRINT","accessibility doesn't find Print where it was");
            }
            Native.NoModifiers();Quiet("Print");
            Native.ClickNow(p);Diag.Click();
        }
        // The print form for this Repair Order: a new COSTAR window titled "Print RepairOrder <number>"
        // (the number checked when known; else it must belong to this Repair Order's window), in front and
        // holding still. A COSTAR message instead is read and never answered.
        IntPtr WaitForPrintForm(HashSet<long> before,string number) {
            var timer=Stopwatch.StartNew();IntPtr candidate=IntPtr.Zero,other=IntPtr.Zero;var still=new Stopwatch();
            while(timer.ElapsedMilliseconds<15000) {
                Check(false);
                IntPtr form=IntPtr.Zero;other=IntPtr.Zero;
                Native.EnumWindows(delegate(IntPtr w,IntPtr unused) {
                    if(Native.Pid(w)!=pid||!Native.IsWindowVisible(w)||before.Contains(w.ToInt64())||Decoration(w)) return true;
                    if(PrintForm.TitleNumber(Native.Caption(w))!=null) form=w; else if(other==IntPtr.Zero) other=w;
                    return true;
                },IntPtr.Zero);
                if(form!=IntPtr.Zero) {
                    var front=Native.GetForegroundWindow();
                    if(front!=IntPtr.Zero&&front!=form&&!before.Contains(front.ToInt64())&&Native.Pid(front)==pid&&Native.Class(front)=="#32770"&&timer.ElapsedMilliseconds>=300)
                        throw new InvalidOperationException("COSTAR showed a message with its print form"+Said(front)+". Nothing was answered or pressed: answer it at the PC, then cancel the print form");
                    if(form!=candidate) { candidate=form;still.Restart(); }
                    else if(still.ElapsedMilliseconds>=300&&Native.GetForegroundWindow()==form&&Native.IsWindowEnabled(form)) {
                        // Whose it is: its number in the title, else it belongs to this Repair Order's window.
                        string shown=PrintForm.TitleNumber(Native.Caption(form)),wrong=null;
                        if(number!=null&&shown.Length>0&&!PrintForm.SameNumber(shown,number)) wrong="COSTAR's print form is for Repair Order "+shown+", not "+number;
                        else if((number==null||shown.Length==0)&&!OwnedBy(form,root)) wrong="COSTAR's print form doesn't show it is this Repair Order's";
                        if(wrong!=null) { int c=CancelUnread(form);throw new InvalidOperationException(wrong+": the helper pressed nothing on it. "+(c>0?"The print form was cancelled.":c<0?"The print form closed at the PC.":"Cancel the print form at the PC.")); }
                        Diag.EventRaw("print_form","open after "+timer.ElapsedMilliseconds+" ms"+(shown.Length>0?", its number checked":", it belongs to this Repair Order"));
                        return form;
                    }
                } else if(other!=IntPtr.Zero&&Native.Class(other)=="#32770"&&timer.ElapsedMilliseconds>=300) {
                    throw new InvalidOperationException("COSTAR showed a message instead of the print form"+Said(other)+". Nothing was answered: answer it at the PC");
                }
                Pause(50);
            }
            if(candidate!=IntPtr.Zero&&Native.IsWindow(candidate)&&Native.IsWindowVisible(candidate)) {
                int c=CancelUnread(candidate);
                if(c<0) printMaybe=true;
                throw new InvalidOperationException("COSTAR's print form opened but didn't come to the front within 15 s, so nothing was ticked on it. "+(c>0?"The print form was cancelled.":c<0?"Then it closed at the PC (not by the helper): it may have printed.":"Cancel the print form at the PC."));
            }
            if(other!=IntPtr.Zero) throw new InvalidOperationException("COSTAR opened \""+Sanitize.Text(Native.Caption(other),40)+"\" instead of the print form; nothing was pressed in it: check it at the PC");
            // 2.6.5: COSTAR still on the Print press: the print form may open yet (at the PC).
            var onPress=printPress;
            if(onPress!=null&&!onPress.Returned&&onPress.PressError==null) { printMaybe=true;throw new InvalidOperationException("COSTAR's print form didn't open within 15 s and COSTAR is still on the Print press: the print form may open yet. Check COSTAR"); }
            throw new InvalidOperationException("COSTAR's print form didn't open within 15 s");
        }
        // Cancel on a print form that isn't to be used (only its own Cancel button, found by its words): 1
        // cancelled by the helper, 0 left open (for a person), -1 it went some other way (a person at the
        // PC, not the helper). Brought in front only when nobody is using the PC and no COSTAR message is.
        static bool Shown(IntPtr w) { return Native.IsWindow(w)&&Native.IsWindowVisible(w); }
        int CancelUnread(IntPtr form) {
            if(!Shown(form)) return -1;
            try {
                var front=Native.GetForegroundWindow();
                if(front!=form) {
                    if(front!=IntPtr.Zero&&Native.Pid(front)==pid&&Native.Class(front)=="#32770") return 0;
                    if(Native.UserActiveWithin(2000)) return 0;
                    Native.BringToFront(form);var wait=Stopwatch.StartNew();
                    while(Native.GetForegroundWindow()!=form&&wait.ElapsedMilliseconds<1000) Pause(50);
                }
                var s=Snapshot(form);
                var cancel=s.Where(c=>c.Visible&&c.Class.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0&&c.TextState=="read"&&PrintForm.Words(c.Text)=="CANCEL").ToList();
                if(cancel.Count!=1) return Shown(form)?0:-1;
                return ClickCancel(form,cancel[0]);
            } catch(OperationCanceledException) { throw; }
            catch(Exception) { }
            return Shown(form)?0:-1;
        }
        // The form's own Cancel, once: 1 the form went after it, 0 still open, -1 it went without the click.
        int ClickCancel(IntPtr form,ControlInfo cancel) {
            if(!Shown(form)) return -1;
            try { ClickFormButton(form,cancel,"Cancel"); }
            catch(OperationCanceledException) { throw; }
            catch(Exception) { return Shown(form)?0:-1; }
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<5000) { if(!Shown(form)) return 1;Pause(100); }
            return 0;
        }
        static bool OwnedBy(IntPtr w,IntPtr owner) {
            var o=Native.GetWindow(w,4);
            for(int i=0;i<16&&o!=IntPtr.Zero;i++,o=Native.GetWindow(o,4)) if(o==owner) return true;
            return false;
        }
        // A COSTAR message's words (": "..."" or ""), never its buttons pressed.
        static string Said(IntPtr dialog) {
            var words=new List<string>();
            Native.EnumChildWindows(dialog,delegate(IntPtr h,IntPtr unused) {
                if(!Native.IsWindowVisible(h)) return true;
                string t;if(Native.Class(h).IndexOf("STATIC",StringComparison.OrdinalIgnoreCase)>=0&&Native.TryText(h,out t)&&Order.Clean(t).Length>0) words.Add(Order.Clean(t));
                return words.Count<20;
            },IntPtr.Zero);
            string said=EbayText.Clean(String.Join(" ",words.ToArray()),300).Replace("\"","'");
            return said.Length>0?": \""+said+"\"":"";
        }
        static string Words(string said) { return said.Length>0?said.Substring(1):" something"; }
        // Accessibility's word on a box: a tick box (true/false), or null when it can't tell.
        static bool? Ticked(ControlInfo c) {
            if(c==null) return null;int role;bool on;
            return TickState(new IntPtr(c.Handle),out role,out on)&&role==44?on:(bool?)null;
        }
        static bool IsTick(ControlInfo c) { int role;bool on;return TickState(new IntPtr(c.Handle),out role,out on)&&role==44; }
        string FillPrintForm(IntPtr form,Action beforeOk,out bool printed) {
            printed=false;PrintForm.Layout map=null,first=null;
            try {
                var s=Snapshot(form);try { Dump("print-form-controls",s); } catch(Exception) { }
                string problem;map=first=PrintForm.Read(s,IsTick,out problem);
                Order.Require(map!=null,"the print form wasn't as expected ("+problem+")");
                Diag.EventRaw("print_form_rows",String.Join(" | ",map.Rows.Select(r=>r.Name+(Object.ReferenceEquals(r,map.JobCard)?" (job card)":"")+": print "+Ticked(r.Print)+", email "+Ticked(r.Email)).ToArray()));
                SetFormTick(form,map.JobCard.Print,true,"Print for the Job Card");
                foreach(var r in map.Rows) if(!Object.ReferenceEquals(r,map.JobCard)) SetFormTick(form,r.Print,false,"Print for "+PrintForm.Title(r));
                foreach(var r in map.Rows) SetFormTick(form,r.Email,false,"eMail for "+PrintForm.Title(r));
                // Read again: exactly that, before OK.
                WaitIdle(2000);
                var again=Snapshot(form);var check=PrintForm.Read(again,IsTick,out problem);
                Order.Require(check!=null,"the print form changed ("+problem+")");
                map=check;
                string wrong=PrintForm.Wrong(map,Ticked,delegate(ControlInfo q) { string t;return Native.TryText(new IntPtr(q.Handle),out t)?t:null; });
                Order.Require(wrong==null,wrong);
            } catch(OperationCanceledException) { throw; }
            catch(Exception e) { return CancelPrint(form,map??first,e.Message); }
            if(beforeOk!=null) { try { beforeOk(); } catch(Exception e) { return CancelPrint(form,map,"the helper couldn't note the print first ("+e.Message+")"); } }
            try { ClickFormButton(form,map.Ok,"OK"); }
            catch(OperationCanceledException) { throw; }
            catch(Exception e) {
                // The click itself failed part way: it may still have gone. Nothing more is clicked.
                if(printOk) { printMaybe=true;return "The Job Card may have printed: the OK click on the print form didn't finish ("+e.Message.TrimEnd('.',' ')+"). Check the print form at the PC and the printer."; }
                // Not clicked (it changed, or something covers it). A form that went meanwhile went some other
                // way (a person at the PC?): how isn't known.
                if(!Shown(form)) { printMaybe=true;return "The Job Card may have printed: the print form closed before OK could be pressed ("+e.Message.TrimEnd('.',' ')+"). Check the printer."; }
                return CancelPrint(form,map,e.Message);
            }
            // After OK: the form goes (30 s at most; nothing more is clicked, so a Stop isn't waited for).
            // A COSTAR message meanwhile is read, never answered.
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<30000) {
                var fg=Native.GetForegroundWindow();
                bool gone=!Native.IsWindow(form)||!Native.IsWindowVisible(form);
                if(fg!=IntPtr.Zero&&fg!=form&&fg!=root&&Native.Pid(fg)==pid&&Native.Class(fg)=="#32770") {
                    printMaybe=true;
                    return "The Job Card may have printed: after OK"+(gone?" the print form closed and":" on the print form")+" COSTAR said"+Words(Said(fg))+" (not answered: answer it at the PC). Check the printer.";
                }
                if(gone) {
                    Thread.Sleep(200);
                    fg=Native.GetForegroundWindow();
                    if(fg!=IntPtr.Zero&&fg!=root&&Native.Pid(fg)==pid&&Native.Class(fg)=="#32770") { printMaybe=true;return "The Job Card may have printed: after OK the print form closed and COSTAR said"+Words(Said(fg))+" (not answered: answer it at the PC). Check the printer."; }
                    printed=true;return "Job Card printed (sent to COSTAR's Job Card printer).";
                }
                Thread.Sleep(100);
            }
            return "The Job Card may have printed: the print form is still open 30 s after OK. Check it at the PC and the printer.";
        }
        // Not printed: the form cancelled (its own Cancel, nothing else) when it can be, else left for a
        // person. Without the form's layout, its Cancel is found by its words (CancelUnread). A form that
        // went without the helper's Cancel (a person at the PC pressed something) may have printed.
        string CancelPrint(IntPtr form,PrintForm.Layout map,string why) {
            why=why.TrimEnd('.',' ');
            int c=map!=null&&map.Cancel!=null?ClickCancel(form,map.Cancel):CancelUnread(form);
            if(c<0) { printMaybe=true;return "The Job Card may have printed: the print form closed at the PC, not by the helper (it had stopped because "+why+"). Check the printer."; }
            return "Job Card not printed: "+why+"."+(c>0?" The print form was cancelled; print it at the PC.":" The print form is still open in COSTAR: print or cancel it at the PC.");
        }
        // A tick box on the print form set to `want`: one real click when it isn't, then read again.
        void SetFormTick(IntPtr form,ControlInfo box,bool want,string label) {
            var h=new IntPtr(box.Handle);int role;bool on;
            Order.Require(TickState(h,out role,out on)&&role==44,label+" can't be read as a tick box");
            if(on==want) return;
            Order.Require(Native.IsWindowEnabled(h),label+" is greyed out");
            // 2.6.5: set directly (PressTick: the keyboard to it, its own click, read back); one real click only
            // when that says so; a press that may still change it: nothing more (the form is then cancelled).
            string how=PressTick(box,form,want,label,true);
            if(how=="click") ClickFormBox(form,box,label);
            else if(how=="leave") throw new InvalidOperationException(label+" was pressed and can't be read back yet (it may still change): nothing more was pressed");
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<3000) {
                Pause(50);
                if(TickState(h,out role,out on)&&on==want) return;
                Order.Require(Native.GetForegroundWindow()==form&&Native.IsWindowEnabled(form),"COSTAR opened a window after "+label+" was clicked");
            }
            throw new InvalidOperationException(label+" didn't change when clicked");
        }
        // One click on a control of the print form: the form in front, the control where it was and
        // nothing over it, nobody at the PC.
        void ClickFormBox(IntPtr form,ControlInfo c,string label) {
            WaitIdle(2000);Check(false);var h=new IntPtr(c.Handle);Native.Rect r=new Native.Rect();
            Order.Require(Native.GetForegroundWindow()==form&&Native.IsWindowEnabled(form),"the print form isn't in front");
            Order.Require(Native.IsWindow(h)&&Native.IsWindowVisible(h)&&Native.IsWindowEnabled(h)&&Native.GetAncestor(h,2)==form&&Native.GetParent(h).ToInt64()==c.Parent&&Native.GetWindowRect(h,out r),label+" changed on the print form");
            int w=r.Right-r.Left;
            var p=new Native.Point {X=r.Left+Math.Min(8,Math.Max(2,w/2)),Y=r.Top+(r.Bottom-r.Top)/2};
            Order.Require(Native.WindowFromPoint(p)==h,label+" is covered on the print form");
            Native.NoModifiers();Quiet(label);
            Native.ClickNow(p);Diag.Click();
        }
        void ClickFormButton(IntPtr form,ControlInfo c,string label) {
            WaitIdle(2000);Check(false);var h=new IntPtr(c.Handle);Native.Rect r=new Native.Rect();string t;
            Order.Require(Native.GetForegroundWindow()==form&&Native.IsWindowEnabled(form),"the print form isn't in front");
            Order.Require(Native.IsWindow(h)&&Native.IsWindowVisible(h)&&Native.IsWindowEnabled(h)&&Native.GetAncestor(h,2)==form&&Native.TryText(h,out t)&&PrintForm.Words(t)==PrintForm.Words(label)&&Native.GetWindowRect(h,out r),label+" changed on the print form");
            var p=new Native.Point {X=(r.Left+r.Right)/2,Y=(r.Top+r.Bottom)/2};
            Order.Require(Native.WindowFromPoint(p)==h,label+" is covered on the print form");
            Native.NoModifiers();Quiet(label);
            // From here the print may go: never said as "not printed" again.
            if(label=="OK") printOk=true;
            // 2.6.5: its own click posted (it prints and closes the form: a sent one would wait for that); the
            // mouse only when the press couldn't be posted at all and the button is still there under the point.
            if(Direct.On) {
                if(Direct.PressLater(h)) { Diag.Pressed();return; }
                Order.Require(Native.IsWindow(h)&&Native.WindowFromPoint(p)==h,label+" went from the print form before it could be pressed");
                Diag.EventRaw("direct_fallback",label+": the press couldn't be posted, a click instead");
            }
            Native.ClickNow(p);Diag.Click();
        }
        // The number in the box beside the Repair Order's "RepairOrder" label, read now, or null.
        internal string ShownNumber() {
            try {
                var s=Current();var box=NumberBox(s);if(box==null) return null;
                string t;if(!Native.TryText(new IntPtr(box.Handle),out t)) return null;
                t=Order.Clean(t);return Regex.IsMatch(t,@"^\d{4,}$")?t:null;
            } catch(InvalidOperationException) { return null; }
        }
    }
}
