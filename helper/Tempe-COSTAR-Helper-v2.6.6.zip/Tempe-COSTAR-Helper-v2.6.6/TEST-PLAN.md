# v2.6.6 checks (Item lines clicked)

Use a test Repair Order for 2 to 4, standing at the PC.

1. **Update:** the RDP helper offers 2.6.6; the title says **2.6.6 - Item lines clicked**; 136 + 16 self-test groups pass. The day log has no `ro_wip_cells` / `ro_open_direct` lines from the update's self-tests (12:45 on 28 Oct had seven).
2. **A car change from the phone (rego and odometer, on a Repair Order with DET):** the pointer clicks into the REGO NO note, then the ODOMETER note, as in 2.6.4 (the run report's `memo_focus` "ok", one click each). Both notes go in. Close the Repair Order and open it again in COSTAR: both notes still show the new words.
3. **Leaving the item lines:** after the notes, the pointer clicks PO# (or the first box at the top that changes); the run report has `direct_skipped` "leaving the item lines: clicked". Customer Waiting right after a line change is clicked too ("Customer Waiting: leaving the item lines, a click").
4. **A quantity and a price of a line, a new item, a line taken out:** each box clicked as in 2.6.4; the change stays after closing and opening again.
5. **Customer Waiting and a print, with no line changed:** as in 2.6.5: the row made the active one directly, Print pressed directly, one Job Card.
6. **An online order with DET first:** DET's notes appear after the click on PO# (`det_leave_once` "ok"), then the car notes go in clicked.
7. **Customer phone (online and eBay orders):** no "COSTAR did not accept customer phone" stops. A run whose phone took more than 5 s has a `write_late` event ("taken after 5 s").
8. **If COSTAR moves the keyboard off a quantity, price or note before Tab:** the run report has `focus_lost`, then `focus_again` "clicked again before Tab", and the order goes on. **For a note, close the Repair Order and open it again: the note must still show its words** (its key was pressed again after the click). With someone moving the mouse at that moment, it stops as before ("not tried: someone used the PC").
9. **If a box loses the keyboard:** the run report's events say where it went (`focus_lost`: the box's kind and place, COSTAR in front or not, someone at the PC or not, the last key or mouse move). A "Someone used the COSTAR PC" stop has its `ro_user_active` line in the day log (opens) or a `user_active` event (prints).

---

# v2.6.5 checks (Press COSTAR directly)

Use a test Repair Order for 2 to 4, standing at the PC. Watch the mouse pointer: it shouldn't move.

1. **Update:** the RDP helper offers 2.6.5; the title says **2.6.5 - Press COSTAR directly**; 135 + 16 self-test groups pass. Files & settings shows "Press COSTAR's buttons, ticks, tabs and boxes directly" ticked.
2. **Repair Orders (phone), Order / print… with both ticked:** COSTAR opens the Repair Order without its list scrolling (the day log `ro_open_ok`: "row made the active row directly", "opened without the mouse (Enter)"); Customer Waiting ticks; Print opens the print form (`print_press` "Print pressed through accessibility"); Job Card ticked, Invoice unticked, OK; **one Job Card prints, nothing else**; COSTAR closes the Repair Order.
3. **Customer Waiting kept:** open that Repair Order again in COSTAR: Customer Waiting is still ticked (COSTAR kept the direct press, not only showed it).
4. **Repair Orders, a change:** a quantity and a note line: the boxes take the keyboard without the pointer moving; the note keeps its words after the Repair Order is closed and opened again.
5. **Phone job / online order / eBay order:** filled with the pointer still; eBay's Ship to / Rebill to tabs change (`tab_switch` "direct").
6. **A line taken out from the phone:** exactly as in 2.6.4 (the Delete key; its right-click menu's Delete if COSTAR doesn't take the key). Not changed in 2.6.5.
7. **Someone at the PC:** move the mouse just as a print from the phone is starting: the helper stops before Print ("someone is using the COSTAR PC, so Print wasn't pressed"), nothing printed.
8. **Back-up:** the day log's `direct_fallback` lines say where the mouse stepped in (there should be few or none). Untick the switch: the mouse moves and clicks as in 2.6.4; tick it again: still again.
9. Prints never twice, no second Repair Order from one Add New (as in 2.6.2).

---

# v2.6.4 checks (Map COSTAR, deeper)

1. **Update:** the RDP helper offers 2.6.4; the title says **2.6.4 - Map COSTAR, deeper**; 134 + 16 self-test groups pass. The hint under the Mobile jobs log says "Ctrl+Alt+F9 maps the COSTAR screen in front (read only)".
2. **Ctrl+Alt+F9 on a Repair Order:** the header says **MAPPING** for a few seconds, then a sound; the log: "Map N saved: 1 COSTAR window (RepairOrder …), N controls, …, N accessibility objects (N parts that don't show left out), N windows of another COSTAR listed". The map's `.txt` lists the toolbar's buttons (Print among them) and the lines' boxes; nothing on the COSTAR screen moved.
3. **The print form:** Print on a test Repair Order, Ctrl+Alt+F9 while the form shows, cancel it by hand after the sound. The `.txt` has the form's ticks (Job Card, Invoice), its quantity boxes and OK / Cancel.
4. **The customer search window:** Ctrl+Alt+F9 while it shows; its list's rows are counted, customers show as "[N chars]".
5. **The button:** "Map in 10 s ..." counts down; Ctrl+Alt+F9 during the countdown maps at once.
6. **Busy:** Ctrl+Alt+F9 while a phone job is being entered: "Map not taken: … is filling COSTAR" and a different sound; the job goes on undisturbed. Ctrl+Alt+F9 twice quickly: "still reading the last screen".
7. **Save diagnostics:** the ZIP's `maps` folder has the new maps; a `.txt` shows customer names, phones and Repair Order numbers only as "[N chars]" / "[number]".
8. Phone jobs, prints, Repair Orders and eBay orders work as in 2.6.2.

---

# v2.6.3 checks (Map COSTAR)

1. **Update:** the RDP helper offers 2.6.3; the title says **2.6.3 - Map COSTAR**; 133 + 16 self-test groups pass. A **Map COSTAR screen** button shows under Add note.
2. **A map:** press it: "Map in 5 s ..." counts down, the header says **MAPPING** "Read only: nothing is clicked or typed"; within a few seconds the log says "Map 1 saved: N COSTAR windows (...), N controls, N that Windows can press or tick directly, N accessibility objects". Nothing on the COSTAR screen moves, no box changes, the mouse stays where it is.
3. **The six screens** of the README (Repair Order with lines, print form, customer search window, Work-in-Progress, eBay Ship to / Rebill tab, a line's right-click menu): one map each; the right-click menu stays open while it is mapped.
4. **Busy:** while a phone job is being entered the button is greyed; a map pressed just before a job arrives makes the job wait a few seconds ("The map (reading COSTAR) is filling COSTAR"), then it goes on.
5. **Save diagnostics:** the ZIP has a `maps` folder with a `.json` and a `.txt` per map. Open a `.txt`: customer names, phones and Repair Order numbers show as "[N chars]" / "[number]".
6. Phone jobs, prints, Repair Orders and eBay orders work as in 2.6.2.

---

# v2.6.2 checks (Print and order from the phone)

Use a test Repair Order (made up for the test) for 2 to 6.

1. **Update:** the desk receiver first, then the RDP helper: both yellow lines offer 2.6.2; titles say **2.6.2 - Print and order from the phone**; 132 + 16 self-test groups pass. The 2.6.1 checks below apply too (2.6.2 includes it).
2. **Print alone (Repair Orders):** open the test Repair Order on the phone, change nothing. The save bar says **Order / print…**. Open it, untick Order: the button says **Print the Job Card**. Tap it: COSTAR opens the Repair Order, Print is clicked (the RDP helper's log: `print_button` "a button of its own" or "accessible"), the print form opens titled with this Repair Order's number, Job Card gets ticked, the Invoice unticked, OK; one Job Card comes out of the Job Card printer (OKI); COSTAR closes the Repair Order; the phone says **Job Card printed**. Nothing else on the Repair Order changed.
3. **Order alone (Repair Orders):** on a Repair Order without SHOP, with Customer Waiting not ticked and an older Date In: change nothing, **Order / print…**, untick Print: the Order line lists what it sets; **Save to COSTAR**: Ship Via SHOP, Customer Waiting ticked, Date In today; nothing printed. Open the review again: "Already Ship Via SHOP, Customer Waiting ticked, Date In today".
4. **A change with both (the default):** change a quantity, **Review & save**: both ticked, **Save and print**: "In COSTAR and checked", then **Saved and printed**; the quantity, SHOP, Customer Waiting and today in COSTAR; one Job Card printed.
5. **Your own Ship Via stays:** type COURIER in Ship Via on the phone, review: "Customer Waiting ticked, Date In today · your Ship Via above stays"; saved with COURIER.
6. **The print form as COSTAR shows it:** if the phone says "Job Card not printed: the print form wasn't as expected (…)", the form was cancelled and nothing printed: send the RDP helper's report (`print-form-controls` lists the form's boxes, `print_form_rows` what the helper read). If COSTAR shows a message instead of the form (or after OK), the phone quotes it and the helper leaves it unanswered: answer it at the PC.
7. **Phone job, both ticked (the default):** SUBMIT TO COSTAR shows Order and Print the Job Card, both ticked → **Submit to COSTAR**. The job ends "READY FOR REVIEW · Ordered: Ship Via SHOP, Customer Waiting ticked, Repair Date today. · Job Card printed (sent to COSTAR's Job Card printer)." In COSTAR: SHOP, Customer Waiting ticked, Repair Date today; one Job Card printed. If the phone job's new Repair Order can't be printed before it is saved (COSTAR asks), the status quotes COSTAR's question and the job is still ready for review: tell Claude what COSTAR asked.
8. **Phone job, Order unticked:** Ship Via and Customer Waiting as COSTAR made them; "Not ordered (as chosen on the phone)." **Print unticked:** no print, "Ordered: …" only. **Cancel:** nothing sent.
9. **Never twice:** stop the RDP helper (Ctrl+Alt+F10) right after a phone job's Job Card printed, then Retry: "Job Card printed earlier."; no second Job Card. On the Repair Orders page, a print whose answer was lost ("The desk PC doesn't have this print") is never sent again by itself: **Print again** only after checking the printer. A printer that isn't ready (COSTAR says so after OK): the phone says **Check the printer** ("may have printed"), never "not printed".
10. **Hands off:** move the mouse on the RDP PC just before Print would be clicked: "someone is using the COSTAR PC, so Print wasn't clicked"; nothing printed.
11. **Phone jobs, eBay orders and the Repair Order checks of 2.6.0 and 2.6.1** work as before.

---

# v2.6.1 checks (Repair Orders faster)

1. **Update:** desk receiver and RDP helper offer 2.6.1; titles say **2.6.1 - Repair Orders faster**; 129 + 16 self-test groups pass (the start after the update takes about 10 seconds longer for them).
2. **A row in view:** tap a Repair Order whose row COSTAR Tempe shows without scrolling. The phone shows it within a few seconds; COSTAR doesn't scroll. The RDP helper's day log (`ro_open_ok`) says `no Search, row in view`.
3. **A row far down:** tap one you would have to scroll to in COSTAR. COSTAR's list moves a little (one notch), then jumps to the row (one or two turns; one more small step for the last rows of the list) and opens it; the log says `row brought into view with 3 wheel turns`, `at the point: this one` (or `can't tell`) and how long each part took. Compare with 2.6.0 (15 s to 2½ minutes). Try the very first and the very last row too.
4. **A Repair Order made a minute ago** (not in COSTAR Tempe's list until Search): the log says `Search` and it still opens.
5. **Shown before the close:** the Repair Order appears on the phone while COSTAR is still closing it (the save bar says "COSTAR is closing it…" for a second or two).
6. **Save:** "In COSTAR and checked" appears as soon as the change is checked, then "Checked and closed". Tap **Done** during "Checked; closing it in COSTAR…": the sheet goes and a note says "saved to COSTAR" a moment later.
7. **List:** opening the page shows the list at once, marked "(Order Check's copy)". ↻ reads COSTAR's list just now ("Reading COSTAR's Work-in-Progress…").
8. **The wheel only goes to the list:** click into one of the Work-in-Progress search boxes in COSTAR Tempe (leave it empty), wait 10 s, then open a row far down from the phone: one click on a row in view, then the wheel; the search box is unchanged. The log says `one click to give the list the wheel`.
9. **Search when needed:** open a Repair Order made a minute ago, and (with Order Check paused) one after 10 minutes without any Repair Order from the phone: the log says `Search`. Open another right after: `no Search`.
10. **Left open:** if COSTAR doesn't close a Repair Order after a read or a save (it asks something), the phone says so with **Close it in COSTAR**. Leave it, go back, open it (or another Repair Order) on the phone: it says a Repair Order is open and that your phone left RO … open, with **Close RO … in COSTAR**; after the close the open goes on by itself.
11. **A stop says why:** if an open stops with "didn't take the keyboard (… has it)", "didn't scroll as far as it was turned", "scrolled N rows for M notches" or "Accessibility found Repair Order …", nothing was clicked after it: open that one by hand and send the report (the day log has `ro_wip_keyboard` / the times line).
12. Phone jobs, eBay orders and the 2.6.0 Repair Order checks (taking a line out, a stop part way, "COSTAR's copy changed") work as before.

---

# v2.6.0 checks (Repair Orders on the phone)

Use test Repair Orders (made up for the test) until 6 and 7 have passed.

1. **Update:** the desk receiver first, then the RDP helper: both yellow lines offer 2.6.0; titles say **2.6.0 - Repair Orders on the phone**; 126 + 16 self-test groups pass. The desk has a **Repair Orders** tab and an **RO** chip (RO: ON once the RDP helper is in touch); the RDP helper's Mobile jobs tab has a **Repair Orders from the phone** card, ticked.
2. **List:** phone → F Alt Tab menu → Repair Orders. ↻ (or opening the page): "Reading COSTAR's Work-in-Progress…", then the list as in COSTAR Tempe (number, date, name, total, comment). Search by number, name, comment and PO#; All / Today / This week. With COSTAR busy (a phone job being typed), ↻ shows Order Check's copy and says how old it is.
3. **Open:** tap a test Repair Order: "Opening in COSTAR…"; COSTAR Tempe brings it up from Work-in-Progress and closes it again; the phone shows the customer, car (MAKE/MODEL, REGO NO, ODOMETER from DET), every line with quantity and price, Ship Via, Date In and Customer Waiting as in COSTAR. The helper's log says how it opened (double-click, or Enter). With another Repair Order open in COSTAR Tempe it waits ("A Repair Order is open in COSTAR Tempe …").
4. **One change:** change one item's quantity, Review & save → Save to COSTAR: "Typing into COSTAR", then "Checked and closed". In COSTAR: that quantity changed, nothing else; the Repair Order is in Work-in-Progress, not saved or invoiced.
5. **Everything at once:** name, email, address, PO#, comment, make/model, rego, odometer, an item's price, a note's words, Ship Via, Date In (tomorrow), Customer Waiting (tick or untick), one new item with quantity and price, one new note: all in; "Checked and closed". Open it in COSTAR and compare with the phone.
6. **Take a line out:** the bin on an item line → save. The log says "Took out line N (CODE)" (or "(right-click menu)"). If COSTAR asks to confirm with Yes and No, the log says it was answered Yes. Any other question, a right-click menu that isn't COSTAR's own line menu, or a line that only lost its item code: the phone says "Stopped part way", the Repair Order stays open, nothing was answered: send the report (it lists the menu's items and the question's buttons).
7. **A Repair Order without DET:** enter a car on the phone: DET and its three notes are added, then the car. A Repair Order on a COSTAR account: the mobile box is locked on the phone.
8. **Changed in COSTAR meanwhile:** open it on the phone, change it in COSTAR by hand and close it, then save on the phone: "COSTAR's copy changed", nothing typed; the phone shows COSTAR's copy with your changes kept; save again: they go in.
9. **A stop part way:** press Ctrl+Alt+F10 while a change is being typed: the phone says "Stopped part way" with what already went in; the Repair Order stays open in COSTAR Tempe; the RDP card says it was left open. **Close it in COSTAR** on the phone closes it. A stop before anything is typed: "Nothing was changed; it was closed again."
10. **Quiet moment:** move the mouse on the RDP PC while a phone save waits: it waits ("someone is using the COSTAR PC") and goes in 10 seconds after you stop.
11. **Switched off:** untick Repair Orders from the phone: the phone says they are switched off in the RDP helper; a save waits on the desk and fails after 10 minutes if not switched on again.
12. **Phone jobs and eBay still work** as before, also right after a Repair Order change.
13. **Never twice:** add an item and save, then at once go back to the list (or lock the phone, or reload the page): the save carries on; the list shows "RO …: saved to COSTAR" (or opening the Repair Order again shows the save sheet following it to the end). In COSTAR the item is there once. With the desk PC unplugged from the network for a moment during a save: "Lost contact" → plug it in → **Check again**: it ends once, never twice.
14. **Hands off while it opens:** move the mouse on the RDP PC just after tapping a Repair Order on the phone: the phone says someone used the PC; nothing more is clicked; if a Repair Order opened it is left as it is.

---

# v2.5.3 checks (SHOP and waiting)

1. **Update:** both yellow lines offer 2.5.3; titles say **2.5.3 - SHOP and waiting**; 117 + 16 self-test groups pass.
2. **New customer's phone job:** after the final check the log says "Entered Ship Via: SHOP." then "Ticked Customer Waiting."; the Repair Order shows both. Order Check doesn't ask to "Put SHOP" or "Tick Customer Waiting" for it.
3. **Existing customer's phone job:** the same (Ship Via was already SHOP for them).
4. **Already ticked / already SHOP** (a Retry after a stop at the end): "Customer Waiting already ticked.", "Ship Via already SHOP."; nothing is clicked twice.
5. **Online pickup for a new customer:** still no SHOP (unchanged); no Customer Waiting click.
6. **F Alt Tab on a phone** (after uploading the three website files): a **Job Card** button bottom right; add a tyre: it shows 1 and the "added on the Job Card" toast sits above it; tap: the Job Card opens with the tyre. On a computer screen the button doesn't show.

---

# v2.5.2 checks (eBay RO closes)

1. **Update:** both yellow lines offer 2.5.2; titles say **2.5.2 - eBay RO closes**; 116 + 16 self-test groups pass. The desk starts receiving by itself after its update (a "Waiting for port 8790 …" line for a few seconds is fine).
2. **eBay closes:** send one order: it goes in, the log says "Left item editor before closing" and "Closed the Repair Order", and the window closes. The desk says "entered and closed (it's in Work-in-Progress)". Open it from Work-in-Progress: header, Ship to, Rebill to EBAY + Card#, SA / SA and every line (tyre, F, M E, M BUY, M DFE) with the notes' words.
3. **Switch:** untick **Close each Repair Order once it's in** on the eBay orders tab: the next order stays open ("Repair Order left open"). Tick it again: the one after closes. The tick is remembered after a restart.
4. **CHECK BY HAND stays open:** an order that ends with a CHECK BY HAND note (for example Terms not 7INV) is left open.
5. **Desk port:** after its update the new receiver waits for its port instead of stopping; a second copy started while one is open is still refused ("already open").

---

# v2.5.1 checks (notes saved)

1. **Update:** both yellow lines offer 2.5.1; titles say **2.5.1 - notes saved**; 115 + 16 self-test groups pass.
2. **eBay notes kept:** let an eBay order go in. Close its Repair Order and open it again: `EBAY ITEM # …` (each item) and `EBAY BUYER NAME: …` keep the order's words; no note ends with an extra letter.
3. **Online notes kept:** the same with an online order: MAKE/MODEL, REGO NO, TO SUIT (`M C`) and PAYING BY (`M PC`) keep their words after closing and reopening.
4. **Phone job notes kept:** the same with a phone job that has MAKE/MODEL, REGO NO, ODOMETER and Additional notes; ODOMETER keeps its number.
5. **A stop at a note:** press Ctrl+Alt+F10 while a note line is being filled (an eBay order, an online order and a phone job), then Retry: the note is written and confirmed again; after closing and reopening it has its words and no extra letter.
6. **Desk certificate:** on the eBay PC, open `http://<desk address>:8791/trust.cer`: its name ("Issued to") is the "Issued by" of the desk's HTTPS certificate (Chrome → `https://<desk address>:8790/` → Certificate Viewer). The phone pairing page names the same certificate.

---

# v2.5.0 checks (eBay orders)

1. **Update:** the RDP helper and the desk receiver both offer 2.5.0 on their yellow line; titles say **2.5.0 - eBay orders**; 113 + 16 self-test groups pass. The desk window has tabs **Phone jobs | eBay orders** and an **EBAY** chip; the RDP helper has an **eBay orders** tab.
2. **Layout check (types nothing):** open COSTAR Branch 1 (Sydney) in the RDP session on Work-in-Progress, click Add New, then **Check Sydney layout (types nothing)**. Every line says OK: empty RO, header, Ship to, Written By / Salesperson / Terms boxes, item lines counted, Rebill to tab found, switched to Rebill to, its boxes, switched back. "Nothing was typed." Send a screenshot if a line says NO. Close the empty RO.
3. **Pairing:** desk → eBay orders → **Pair eBay PC** shows the address and PIN. On the eBay PC: install the certificate from the popup's button (Current User → Trusted Root), restart Chrome, Connect with a wrong PIN (refused), then the right PIN: "Connected". The desk's pairing window says Paired.
4. **Waiting:** with eBay orders OFF on the RDP helper, send an order: the panel says "Sent ✓ Waiting for COSTAR: eBay orders are switched off…"; the desk lists it as queued. Opening the order again shows the same status; Send can't be clicked again.
5. **First real order:** click **Start eBay orders**. Within about 10 s of nobody touching the RDP PC, COSTAR Sydney comes forward, Add New, and the order goes in: phone lookup, header (PO# = eBay order number, comment EBAY DFE), Ship to (Ship Via DFE), Rebill to EBAY (EBAY PAYMENTS, note, Terms 7INV appear) + Card#, Written By SA, Salesperson SA, lines 1 tyre (eBay price) · 3 F · 5 M E · 7 M BUY · 9 M DFE. The panel follows it to "In COSTAR Sydney ✓". Check the RO against the eBay page before saving.
6. **Two orders in a row:** send two; the second goes into its own new RO after the first; the first stays open.
7. **Stop and Retry:** press Ctrl+Alt+F10 during an entry: the panel says Stopped, the desk shows failed. Start eBay orders again, then **Send again** on the eBay PC (or Retry on the desk): it continues in the same RO. Edit that RO by hand after a stop, then Retry: it refuses ("changed after the helper stopped").
8. **Start again / Mark done:** stop an order, close its RO WITHOUT saving, Retry → refused (window gone); **Start again in a new RO** enters it fresh. Mark done by hand on another stopped one: the panel says In COSTAR.
9. **Never twice:** an order that is in COSTAR can't be sent again (the panel shows In COSTAR) and can't be removed on the desk. Even if the desk's eBay list were lost and the order sent again, the RDP helper refuses it ("already entered by this helper"); only **Start again in a new RO** on the desk, after checking COSTAR, enters it once more.
10. **Not sendable:** an order whose item has no custom label, or 5+ items: the panel says "Can't send to COSTAR: …" and the button stays off.
11. **Online orders beside eBay:** with the Online orders tab open and Fill automatically on, send an online order while an eBay order is being entered: it starts by itself right after the eBay order. Load an online order by hand and leave it unfilled: eBay orders still go in (the eBay tab never says it waits for that order).
12. **Removed, then sent again:** stop an order after a few fields (Ctrl+Alt+F10), Remove it on the desk, then Send again on the eBay PC: it continues in the SAME Repair Order (nothing new opened). Do the same but change something in that RO first: it stops ("changed after the helper stopped"); no second RO.
13. **A COSTAR window left open:** stop an order while a COSTAR list or notice is open, leave it open, Retry: the helper stops at once ("COSTAR opened another screen…") and does not close or pick anything in it.
14. **Stop on Rebill to:** press Ctrl+Alt+F10 while the Rebill to tab shows (just after EBAY is typed). Retry: the helper clicks Ship to, checks the RO, and carries on (EBAY and Card# kept).
15. **Helper closed mid-entry:** close the RDP helper (Task Manager) while an eBay order is going in, open it again: the desk shows that order as stopped within a few seconds (not "being entered"), and the next waiting order goes in. Check the half-entered RO and use Mark done or Start again.

---

# v2.4.2 checks

1. **Phone, the stuck card:** after the website files are uploaded (or the desk is on 2.4.2 and the phone uses its local page), reload the job card: it says "Closed on the PC — start a new job"; **New job** is enabled; tap it, confirm. A fresh card appears.
2. **Stopped order:** stop a mobile job (Ctrl+Alt+F10); the phone shows "Stopped — Retry on this phone, or New job"; New job asks to confirm and starts a new card; the stopped job is still on the desk list for Retry / Mark done / Remove.
3. **Removed on the desk:** Remove a waiting job on the desk; the phone shows "Removed on the desk PC" within a few seconds; New job works.

---

# v2.4.1 checks

1. **Update:** both windows offer 2.4.1 on their yellow line (the desk checks every 6 hours; restart it to check now). Titles say **2.4.1 - renovation, first look**.
2. **Desk chip:** with the RDP helper open and mobile off, the desk says **RDP HELPER: MOBILE OFF** (amber) within 3 s, and "RDP helper in touch now · Mobile off on the RDP helper (jobs wait in the queue)". Click Start / resume mobile: **RDP HELPER: MOBILE ON** (green).
3. **Phone with mobile off:** send a job card while mobile is off on the helper: the phone accepts it ("will wait in the queue"); it is entered once mobile is switched on.
4. **COSTAR list** shows "Branch 11 (TEMPE) · PID …"; the drop-down shows the full line.
5. **Online tab:** after an order, the line reads "Finished TTW… at hh:mm · waiting for the next order" and the details are grey. No text runs off the right edge.
6. **Desk window:** the Setup card and its hint are fully visible at the default size.

---

# v2.4.0 checks

1. **Update on the RDP PC:** upload the two GitHub files, reopen the helper, click the yellow line, Yes. The window reopens with the new header; the title says **2.4.0 - renovation**; 96 + 16 self-test groups pass. Take a screenshot of the window and send it (first look at the layout).
2. **Desk PC:** close the old receiver, extract the ZIP into a new folder, run `Start-Desk.cmd` from it. The queue and pairing are still there. The header chips show RECEIVING and RDP HELPER (in touch) once the RDP helper is open.
3. **Files & settings tab:** the folders show counts and sizes; Open folder opens them; Clean up now lists the old versions it would remove (keeps 2.3.2 and 2.4.0) — say Yes if you like; Diagnostics ZIP to Desktop puts the ZIP on the desktop.
4. **Mobile job, normal:** send a job card from the phone with mobile on. It starts within about a second of approval (before: up to 2 s). The header shows FILLING with the job's stage and progress; the desk list shows it injecting then ready for review.
5. **Release job:** stop a mobile job on purpose (Ctrl+Alt+F10 during entry), finish its Repair Order by hand, then **Release job (finished by hand)** → the desk shows it ready for review; Next Order moves on; nothing is typed into COSTAR.
6. **Start this job again:** stop a job during entry, close its Repair Order WITHOUT saving, then **Start this job again** → Start / resume mobile → **Retry selected** on the desk: a new Repair Order is opened and the job entered from the start.
7. **Desk exits:** with a failed job selected, **Mark done by hand** closes it and the next job starts; **Remove job** drops a waiting job. The RDP helper's log says the desk closed the job.
8. **Online orders:** send an order; it starts within a second of Send to COSTAR. DET first / fitting note sit next to Paying by. After a stop the header says NEEDS YOU for a while; Fill Repair Order continues with the next.
9. **Order Check tab:** turn on/off still works (the setting is now in settings.json; the old flag file is kept in step).
10. **Old desk with new RDP helper (if the desk is updated later):** mobile jobs still work at the old 2 s rhythm; Release job still works.

---

# v2.3.2 checks

1. **Update from 2.3.1:** upload the two GitHub files, restart the helper, then click the yellow line and Yes.
   - The title shows **2.3.2 - DET first fixed**, and 90 + 16 self-test groups pass.
   - The Online tab has the **DET first (items above DET)** box, ticked.
2. **Pickup with two tyres + M FB (+ WA):** DET goes on line 6 with its notes on 7–9; the tyres on lines 1–2, M FB on 3, WA on 4. The order ends READY FOR REVIEW. This is exactly where 2.3.0 and 2.3.1 stopped.
3. **DET first off:** untick the box, then fill a pickup.
   - The items go on lines 1 onwards, then DET with its notes straight after them, then PAYING BY if set.
   - Restart the helper: the box is still unticked. Tick it again for DET first.
4. **If a DET-first order still stops:** untick DET first and send the order again (without changing its Repair Order). It continues in that Repair Order, with the remaining items after DET's notes. Send the diagnostics.
5. **TTW1730569** (stopped 10 Oct under 2.3.1): finish it by hand, if not done yet: 0358092 ×2 on line 2 (check its price), then M FB on line 3. The helper won't continue it after the update.

---

# v2.3.1 checks

1. **Update from 2.3.0:** after uploading the GitHub files, restart the helper and click the yellow line, then Yes. The title shows **2.3.1 - unstuck**, and 87 + 16 self-test groups pass.
2. **Branch 1:** select the Branch 1 COSTAR and fill a Branch 1 store's pickup. It goes all the way to READY FOR REVIEW (2.3.0 would have stopped at once).
3. **Pickup with tyre + M FB (+ WA):** DET on line 6, notes on 7–9, the tyre on 1, M FB on 2, WA on 3. If the log says "COSTAR's item lines can't be counted safely…", the items went after DET's notes instead: send the diagnostics.
4. **Retry after a stop, nothing touched:** stop an order with Ctrl+Alt+F10 after its tyre, then send it again. It goes back into that Repair Order ("Going back…" / "Order Check lists …: that is the Repair Order the helper stopped in"), continues and ends READY FOR REVIEW, with no second Repair Order.
5. **Retry after changing it by hand:** stop an order, change something in its Repair Order (for example a quantity), send it again: refused ("changed after the helper stopped"); nothing is typed.
6. **TTW1730549** (stopped 9 Oct under 2.3.0): finish it by hand (M FB on line 2, Ship Via SHOP). The helper won't continue it after the update.

---

# v2.3.0 checks

1. **Update from 2.2.1:** after uploading the GitHub files, restart the helper. The grey line offers 2.3.0; click it, then Yes. The window reopens with title **2.3.0 - any branch** and 85 + 16 self-test groups passed.
2. **Branches:** with COSTAR Branch 11 and Branch 1 open, both appear in the list as "Branch 11 (TEMPE)" and "Branch 1 (…)".
   - Pick Branch 1: the log says "Using Branch 1 …".
   - Restart the helper: Branch 1 is selected again.
3. **Branch switch with mobile running:** mobile pauses ("Mobile jobs are paused…"). Start / resume mobile shows "jobs go into Branch 1 …".
4. **Online, Branch 1:** on Tempe Orders pick the Branch 1 store, send an order, fill with Branch 1 selected. No question is asked if the store matches the branch name; otherwise "Check the branch" appears.
   - Send a Tempe order while Branch 1 is selected: "Check the branch" names Branch 11 if it's open. No: nothing is typed.
5. **DET first (online pickup):** DET on line 6, notes on 7–9 (PAYING BY on 10 if set), tyre(s) from line 1, M FB, then WA/WAFR above DET. The log says "DET is on line 6 with its notes directly under it."
6. **DET first (mobile):** same layout. Diagnostics: the "Create DET details" step passes, and items verify on lines 1, 2, …
7. **The bug Tommy saw:** close and reopen the Repair Order; DET's notes are still there.
8. **Deliveries:** unchanged (items, freight, TO SUIT, PAYING BY).
9. **Branch question with Auto-load on:** while "Check the branch" is open, copy another order: nothing loads or starts until you answer. Answer Yes: the order named in the question is the one entered.
10. **If 2.3.0 can't start:** the window says it was set aside and that your usual shortcut starts version 2.2.1 again; the shortcut then opens 2.2.1.

---

# v2.2.1 checks

1. **Auto-update:** with 2.2.1's files on GitHub, 2.2.0's status line offers "Update 2.2.1 ready". Yes: download, check, install, restart. The title shows **2.2.1 - finds Order Check**.
2. **Order Check tab:**
   - "Board data: http://127.0.0.1:8796/wip.json …" if 8795 is held, followed by "Port 8795 is held by another Order Check (version …)";
   - or 8795 as before when free.
3. **Tempe Orders (Today/Tomorrow):** the COSTAR check shows ✓/≈/✗ again, with "port 8796" if moved, plus a line about the old copy.
4. **Open board** opens the Order Check board on the right port (`?reader=…` in the address when not 8795).

---

# v2.2.0 checks

1. Start-RDP: title **2.2.0 - resume and updates**; 80 + 15 self-test groups pass.
2. **Resume:** start an online order and press Ctrl+Alt+F10 after its first item. Fill again:
   - "Going back to the Repair Order … was started in";
   - "This Repair Order already holds … Continuing where it stopped";
   - existing lines are "already entered; checked";
   - it ends READY FOR REVIEW with no duplicate rows and no second Repair Order.
3. **Missing orders:** with Order Check on, open Tempe Orders (Today, then Tomorrow).
   - Each order shows ✓/≈/✗ and the bar shows the counts.
   - **Make it** on a ✗ order: the helper enters it, and after a check it shows ✓ (entered by the helper).
4. **Auto-update** (after 2.2.0 and its latest.json are on GitHub, nothing should be offered for the same version):
   - when a newer version is uploaded, the status line offers it;
   - Yes: download, check, install, restart;
   - an old folder's Start-RDP.cmd starts the newest installed version.
5. **Boss report:** opens in the browser with today/7/30-day figures and no customer details. The status line shows today's time saved.

---

# v2.1.0 checks

1. Start-RDP: title **2.1.0 - all branches**; 77 + 15 self-test groups pass.
2. **Customer only in other branches** (TTW1730345's phone):
   - the Search window's Phone is filled, Branch is cleared and Search is pressed;
   - row 1 is taken with OK and the account loads;
   - diagnostics show the wait `customer_search_all_branches` "accounts found".
3. **Phone in no branch:** the search finds nothing, Cancel is pressed and the order's customer details are entered (new customer).
4. **Ship Via:** an existing customer's pickup or mobile job ends with Ship Via SHOP (`ship_via` SHOP). A delivery keeps its own Ship Via. A new customer gets no SHOP.

---

# v2.0.3 checks

1. Start-RDP: title **2.0.3 - steady**; 76 + 15 self-test groups pass.
2. **Two-account phone:** the first account is chosen. Diagnostics show `account_chooser`, then `account_first_row` "row 1 selected…", and the run completes as `existing-customer-first-of-several`. If it fails, `account_grid_shape` holds the grid structure: send the report.
3. **Batch of online orders:** `online_skip_review_ro` in the day log; no "not empty" runs; END OF DAY counts checks separately.
4. **Hold Shift for a second** while an order starts: the helper waits and continues.
5. The status line meter stays about 40–60 MB, CPU under 1%.

---

# v2.0.2 checks (lag)

1. Start-RDP: title **2.0.2 - lag fix**; 75 + 15 self-test groups pass.
2. The status line shows "Helper NN MB, CPU N%". At idle: under about 80 MB and under 1% CPU.
3. Run online and mobile orders, including a slow phone search (the two-account customer). COSTAR stays responsive and doesn't freeze after the search. Diagnostics may show `costar_busy_skips`; that is the helper holding back.
4. Order Check tab: Off by default. Turn it on, choose the second Tempe COSTAR, and it reads. Choosing the entry COSTAR is refused ("That is the COSTAR the helper types into").
5. After a few hours: Save diagnostics. END OF DAY shows helper memory start/peak/now and CPU; no growth flags.

---

# v2.0.1 checks

1. Start-RDP: title **2.0.1 - one system**; 74 helper + 15 Order Check test groups pass.
2. **Two-account customer** (TTW1730377's phone): the search is not interrupted, the first account is chosen (`account_chooser`, `account_first_row`), and no "search did not cancel".
3. **Online pickup:** the Repair Order's **Time in** shows the booking time ("10:30 am"), and the log says "Entered Time in".
4. **Fresh Repair Order** from Fill automatically: no "target field is covered". If there's a `covered` event, `covered_wait` should say "cleared".
5. **Slow COSTAR:** phone lookups taking 2–5 s complete instead of stopping.
6. **Speed:** memory after jobs stays around 40–60 MB (no drop to 1 MB), and the next job starts promptly.

---

# v2.0.0 checks (one system)

1. Close the separate Order Check app. Start-RDP builds 13 source files (now including `OrderCheck.cs`). The self-test report shows **73** helper groups and **15** Order Check groups. Title **2.0.0 - one system**.
2. **Order Check tab:** it reads normally ("Reading normally", the board data link and "Helper tags use the … column" or "Helper tags off"). The board in Chrome loads.
3. **One COSTAR choice:** choose the WIP window in the Order Check tab. The helper's list marks it "Order Check's WIP window" and switches entry to the other Tempe COSTAR.
4. **Background reading:** switch to the Mobile or Online tab. Order Check keeps reading (board updates every 2 minutes).
5. **Old app still running:** the Order Check tab says to close it, and the helper itself works normally.
6. **Closing the helper** stops Order Check's reader and frees port 8795.
7. All 1.9.0 checks below.

---

# v1.9.0 checks

1. Start-RDP builds (now with Accessibility.dll) and passes **73** self-test groups; title **1.9.0 - lean build**.
2. Fill automatically with Chrome in front: COSTAR comes to the front, Add New opens a settled Repair Order, and entry completes. No "not ready", "covered" or "lost focus" stops.
3. Two accounts on one phone: the customer Search list shows, row 1 is highlighted, OK is pressed, and the first account loads (`existing-customer-first-of-several`). Cancel is never pressed.
4. Typing in another app during entry: entry stops (your keys never go to COSTAR). Not typing: COSTAR is taken back (`focus_recovered`, at most 3 per order).
5. Order Check running: its WIP COSTAR is marked in the list and skipped. A manual pick of it is refused. An online order already in WIP is refused (`online_duplicate_blocked`).

The 1.8.3 and earlier checks below still apply.

---

# v1.8.3 checks

1. Start-RDP builds and passes **71** self-test groups; title **1.8.3 - lean build**.
2. With Friday's finished job still in the journal and a restarted COSTAR: the log explains that the earlier job's COSTAR has closed, the list is enabled, and the current Tempe COSTAR is selected (`mobile_pin_released`, `costar_found` in the day log).
3. An online order fills without touching the COSTAR list.
4. Start / resume mobile, then Next Order on the desk: the worker confirms the old job closed ("already closed"), and the next job is entered in a new Repair Order.
5. Live-pin safety, unchanged: with an unfinished job whose original COSTAR is still running, the list stays on that COSTAR.

---

# v1.8.2 checks

1. With COSTAR Tempe open in the RDP session: Start-RDP builds, **70** self-tests pass, title **1.8.2 - lean build**.
2. **Without clicking Refresh**, the log shows "Using Tempe COSTAR (PID …)" and the list shows it selected. The day log has a `costar_found` line.
3. With COSTAR closed: the log explains that no Tempe COSTAR was found and lists the COSTAR windows it saw. Open COSTAR, click Refresh COSTAR list, and it is found.
4. **Online:** load an order and click Fill straight away, without touching the COSTAR list. It is entered.
5. **Mobile:** Start / resume mobile works without a manual Refresh. In diagnostics, `det_leave_once` is `ok` and the DET stage is shorter than in 1.6.1 (about 0.8–1.5 s).
6. **Save diagnostics:** THINGS TO LOOK AT shows the checkpoint-save breakdown (copy / JSON / encrypt / write / replace).

The 1.8.1 and earlier checks below still apply.

---

# v1.8.1 lean build + day log: checks

1. Start-RDP builds and passes **70** self-test groups; title **1.8.1 - lean build**.
8. **Day log:** after a few jobs, click **Add note**, type a test note, then **Save diagnostics**. The ZIP contains `day-log/events-<today>.jsonl`, and `summary.txt` starts with END OF DAY showing today's counts, your note with its time, SPEED BY VERSION and THINGS TO LOOK AT. No customer names, phones, addresses or emails anywhere in the ZIP.
9. **Failures outside entry are visible:** load something that is not a valid order with auto-load on, or start Fill with no COSTAR selected. The day log shows `online_load_failed` / `online_fill_refused` with the reason.
2. **Reads:** after a mobile job and an online order, the diagnostics summary's SCREEN READS shows text reads far below 1.6.x (about 12,000 per mobile job), "skipped by read plan" in the thousands, and "late" near zero. Entry behaves exactly as before.
3. **Two accounts on one phone:** the first account is chosen and entry continues (event `account_chooser`, wait result `existing-customer-first-of-several`). If it stops instead, the report ZIP contains `account-chooser-controls.json`.
4. **Online with an earlier order open:** leave the previous online order open for review, load the next order, click Fill. A fresh Repair Order is opened and filled; the earlier one is untouched.
5. **Fill automatically:** tick it; click Send to COSTAR for two orders in quick succession. Both are entered one after the other, each in its own Repair Order. Send the first again: the helper refuses it ("already entered in this session").
6. **Stop during automatic filling** (Ctrl+Alt+F10): the queue pauses; clicking Fill continues with the next order.
7. Memory: with the worker running across several jobs, its memory drops back after each job.

The 1.6.1 and earlier checks below still apply.

---

# v1.6.1 speed build: checks

1. Start-RDP builds and passes **66** self-test groups; title **1.6.1 - speed build**.
2. Mobile job: in the diagnostics, `det_lookup` is ok and `leave_grid` needs one attempt; checkpoint save time is well below the 1.6.0 figure (1.2 s for 17 saves).
3. The 1.6.0 checks below, especially TTW1730342 (existing customer, delivery) and Fill with no Repair Order open.

---

# v1.6.0 speed build: checks

1. Start-RDP builds and passes **66** self-test groups; the title shows **1.6.0 - speed build**.
2. **Existing customer, online delivery:** run an order whose phone already exists in COSTAR (for example TTW1730342 again). Entry must continue past the phone lookup, compare billing and delivery fields, change only those that differ, then add the items.
3. **Same Repair Order retry:** stop an online order right after the phone lookup, then click Fill again on the same order. It must continue (same phone, no items) instead of asking for an empty order. An order holding a different phone must still stop.
4. **No Repair Order open:** close every Branch 11 Repair Order, load an online order and click Fill. The helper must click Add New, wait for the new form and fill it.
5. **Mobile job:** the run completes; in the diagnostics summary the DET stage is well under 1 s of waiting and checkpoint saves are about one per step.
6. **Stop test:** press Ctrl+Alt+F10 during a test order; entry stops promptly and the summary shows `user_stop` with the right stage.

The 1.5.5 and 1.5.4 checks below still apply.

---

# v1.5.5 diagnostics build: checks

1. Start-RDP builds and passes **65** self-test groups; the title shows **1.5.5 - diagnostics build**.
2. Process one test mobile job and one online order exactly as with 1.5.4. Entry steps, speed and stops should look the same as 1.5.4.
3. After each run, `%LOCALAPPDATA%\TempeMobileCostar\reports (before 2.4.0: TempeCostarAutofill\Reports)` contains the run's ZIP only (no duplicate folder), and `%LOCALAPPDATA%\TempeMobileCostar\diagnostics (before 2.4.0: TempeCostarAutofill\Diagnostics)` contains a matching `.json`.
4. **Save diagnostics** creates `Tempe-COSTAR-Diagnostics-<date>.zip` beside those folders and opens Explorer on it. Open `summary.txt`: it should list outcomes, stages, waits and environment, and no customer names, phone numbers, addresses or emails.
5. Stop one run on purpose (Ctrl+Alt+F10) on a test order. It should appear as `user_stop` in the summary.

The 1.5.4 checks below still apply.

---

# v1.5.4 complete package: first acceptance checks

First extract the complete ZIP into its fresh Tempe-Mobile-COSTAR-v1.5.4 folder. All 11 C# source files, especially ResourceBudget.cs and CostarSession.cs, must be present. The builder checks for missing dependencies before compiling. Close the old combined helper. If normal closing is unavailable inside RDP, try Ctrl+Alt+End to reach Task Manager and end only the Tempe helper. Forced termination can leave a partially entered order; inspect it before resuming. Keep COSTAR and its existing order data.

Run Start-RDP and leave it paused for one minute before submitting any work. It should remain responsive; no COSTAR discovery or mobile polling starts until requested. Record TempeMobile.exe CPU and memory at opening and after one minute. Click Refresh once and repeat. Start mobile and check again with no new job. Visit Online orders with auto-load off and check again. Stop at the first returning slowdown and note which action triggered it. No numerical RAM/CPU target has been verified yet.

Then run the following inside RDP after the launcher passes its Windows self-tests. Entry tests create live Repair Orders; use your normal approved test data.

1. Close the old worker and standalone autofill once. Start-RDP opens one app with Mobile jobs and Online orders. Start-Online should bring the same app forward, on Online orders, without creating a second worker.
2. Open two separate Branch 11 COSTAR instances and, if available, a different branch. Refresh the target list: only real Branch 11 instances appear. Select one and use Show selected COSTAR. The screenshot's CefSharp subprocesses must not appear as choices.
3. Keep a Repair Order open in the unselected process. Leave the selected process on Work-in-Progress. Click Start / resume mobile. A new mobile job should still open and fill the selected process only.
4. During a mobile run, the target selector must be disabled. Switching to Online orders must not interrupt the running mobile job or allow simultaneous online entry. Finish/review/close the mobile order normally.
5. With Online orders selected, queued mobile jobs wait. Open one new empty Branch 11 Repair Order in the selected process, Send to COSTAR from the website, click Load copied order, then Fill Repair Order. Confirm a different COSTAR account name is retained, the supplied address is used, prices/quantities are correct and entry order is wheels/tyres/M FB/alignment/DET. Make/model, rego and odometer template must stay correct after clicking away.
6. Check a known phone and a customer-not-found phone. New text/codes must be capitals; existing COSTAR account/name must remain intact. For delivery, check both addresses, F freight, DFE, TO SUIT, and surcharge handling. No missing package components may be guessed.
7. Close the online Repair Order and switch back to Mobile jobs. If mobile is enabled, queued work resumes in the selected instance. Stop all entry or Ctrl+Alt+F10 must stop either active mode; Resume mobile explicitly after a stop.
8. With no unfinished job, close the selected COSTAR. The app must not silently choose another instance. A reopened process requires refreshing/reselection. If a job is partial, its retry must remain tied to the original process and order; it must not create another order after process restart.
9. Open entry reports and compare stage times for the relevant order in timing.json. Do not compare online delivery/fitting and a simpler mobile job as if they had equal field counts.

For the failed phone job, confirm it was not completed manually before using Start this job again (2.4.0; was Reset unstarted job, which rejected started jobs). In 2.4.0 the dialog warns instead of refusing when the window is still open or fields were entered; the older button rejected a still-open original window, a pending/entered field, uncertain Add New, or a mismatched job/lease. After an allowed reset, retry the same job from the desk receiver; no new phone submission is required. With a new order loading, the worker should wait for the required grid/header controls without typing. An unknown blocking window must still stop entry for review.

Confirm both customer and delivery email fields are lowercase after clicking away. Other inserted text remains uppercase.

The entries below are the prior queue/recovery checks and still apply to the selected COSTAR instance.

---

# Controlled Windows acceptance test

Start with the single-job test in README. Use approved test records and known COSTAR SKUs. Stop at the first mismatch and save the worker report, rather than deleting the queue or starting a replacement submission.

| Check | Action | Expected result |
| --- | --- | --- |
| Build | Run Check-Build.cmd. | EXE compiles; all self-test groups pass. No COSTAR interaction. |
| Pairing | Launch desk and RDP helpers; refresh/select the target, Start / resume mobile, then open the phone QR link. | Both helpers show connected and phone Submit becomes available after required fields/products are filled. |
| Basic entry | Submit one tyre, quantity 1, complete vehicle details and notes. | One new RO; phone first, then retained COSTAR name or new name; tyre then M FB; DET make/model, rego, odometer; final M note; Ready for Review. |
| New customer | Use a phone with no existing record. | Phone is first; known not-found notice closes; submitted name is entered in capitals; no account is invented. |
| Existing mobile customer | Use an existing phone with a different submitted name. | COSTAR account/name and address are retained; details finish; the next queued job can still start. |
| Existing online customer | Use an existing phone with a different submitted name and billing address. | COSTAR account/name remain; supplied billing address replaces the old address, including clearing a stale second line. |
| Delivery address | Send an online delivery with a different recipient/address from billing. | Both panels contain their own data; DFE comment and normal freight are retained. |
| DET speed and commit | Watch MAKE/MODEL, REGO NO and ODOMETER entry, then click away. | PO is visited once after DET; no repeated PO trips; all entered values remain in their correct rows. |
| Capitals | Use mixed-case customer text, email and additional notes. | Inserted values are uppercase. Retained COSTAR names and catalogue descriptions are not rewritten. |
| Lookup still loading | Use a normal SKU that takes time to resolve. | The helper waits for the resolved row before quantity/price entry; no duplicate rows or skipped lines. |
| Timing report | Open the resulting COSTAR report ZIP. | timing.json records total/stage durations and snapshot totals; no new video is required to identify a slow stage. |
| Active arrival, Pinad off | Use desk keyboard/mouse immediately before phone submission. Leave the approval untouched for over 30 seconds. | Job remains awaiting approval until explicitly approved or Pinad mode is enabled. |
| Pinad mode | Enable Pinad mode, use desk keyboard/mouse, then submit with COSTAR available. | Job starts on the next worker poll without Approve selected; final RO stays open if no further job is waiting. |
| Continuous queue | With Pinad mode on, submit three distinct jobs. | Each job fills once in FIFO order. Each completed window closes before the next opens, without Approve or Next Order clicks. Recent completed jobs remain listed for later review in COSTAR. |
| Delete selected | Select a completed or READY FOR REVIEW entry and click Delete selected, then restart the desk helper. | Entry disappears and stays removed; the order remains in COSTAR. A later submission still advances normally. |
| Clear completed | With completed entries and pending jobs listed, click Clear completed. | All completed entries disappear; pending/failed/running jobs remain. COSTAR orders are kept. |
| Later arrival | With Pinad mode on, let the only job finish, then submit another job. | The completed window closes and the new job starts automatically. |
| Stop receiving | Stop receiving before the current job finishes, with another queued. | Filling may finish, but no new close/assignment is issued until receiving resumes. An action already received by the worker may finish. |
| Close prompt | If COSTAR presents a prompt on automatic closure, leave it unanswered. | Worker pauses and the next job remains queued. Handle the prompt normally, then resume the worker. |
| Existing waiting jobs | Enable Pinad mode with jobs awaiting approval. | Waiting jobs become approved in their existing order; only one starts at a time. |
| Remember mode | Restart the desk receiver with Pinad mode enabled, then disable it and submit a new job while active. | Checkbox stays enabled after restart. Disabling restores approval for the new job; previously approved jobs stay approved. |
| Idle arrival | With no RO open, leave desk input idle for over 30 seconds, then submit a test job. | Job starts when worker/COSTAR is available. |
| Full order | Use three distinct lines: wheel and two tyres; choose WAFR. | Wheels first, tyre order preserved, correct quantities, M FB, WAFR, details, notes. COSTAR prices retained. |
| Front alignment | On a separate approved test, choose WA. | WA follows M FB; no WAFR row. |
| Manual queue | With Pinad mode off, while a ready RO remains open, submit a second job. Then click Next Order. | Second job waits; first window closes normally; second receives its own RO. A close prompt stops for manual handling. |
| Phone loss | After the desk has received a job, temporarily disconnect the phone, then reconnect. | Worker continues; status recovers; no second RO or repeated rows. |
| Controlled Retry | On a test, stop between steps; inspect the partial order, then resume worker and Retry the same job. | Exact before/after state is reconciled. Partial/unrecognised state stops, with no repeated product rows. |
| Wrong target | Leave an unrelated RO open before submitting. | No automatic overwrite or second RO. Pending job waits. |

For an initial failure, send:

1. `bin\self-test-results.txt`, or the compilation error if no EXE was created.
2. The text from **Save worker report**.
3. The matching ZIP under `%LOCALAPPDATA%\TempeMobileCostar\reports (before 2.4.0: TempeCostarAutofill\Reports)` if native entry had begun.

Do not send the worker connection file or phone pairing QR. A report is enough to diagnose the first stop; no new screen recording is required at this stage.
