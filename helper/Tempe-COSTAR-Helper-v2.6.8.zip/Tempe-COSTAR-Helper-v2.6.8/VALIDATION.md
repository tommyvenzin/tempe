# Validation — v2.6.8 — 29 October 2026

## Basis

- **Found in the report of 29 Oct, 01:18** (helper 2.6.6). Tommy sent it with "study this, wholesale order". Three read-only maps (01:05, 01:08, 01:10) show COSTAR Sydney (Branch 1) on **"Orders yet to be filled"**, the wholesale orders list, with a wholesale Order open.
- **The list title.** The main window shows one list at a time. Its title label sits at [208,67], where Work-in-Progress shows "Work-in-Progress", and it's the first STATIC in EnumChildWindows order. Both lists have their own **Add new** in the same place ([210,88]).
- **What Add new does there.** On "Orders yet to be filled" it starts that list's document, a wholesale Order ("Order  Branch 1 …"), not a Repair Order.
- **The gap.** `CostarWindows.OpenNew` (online orders, phone jobs, eBay orders) found the one Add new on the main window and pressed it, without checking which list was showing. "Leave the selected COSTAR on Work-in-Progress" was only advice in the texts.
  - **What would have happened:** an eBay order arriving with COSTAR Sydney on that list would have started an empty wholesale Order, waited 30 s for a RepairOrder window, stopped ("Add New did not appear") and left the Order open. A retry would have opened another one.
  - **Typing was never at risk:** the helper only works in windows titled RepairOrder, and its line code needs the "Qty or Hrs" heading, which an Order doesn't have.

## Changes

- **`CostarWindows.Showing(main)`:**
  - first asks COSTAR a no-op message (WM_NULL, 250 ms). A COSTAR that doesn't answer is asked nothing more and reads as "" (each label read could otherwise wait 0.1–0.5 s);
  - null when `TempeOrderCheck.WipScreen.Locate` finds Work-in-Progress (the same look Order Check and the phone's Repair Orders use);
  - otherwise the list's title from `ListTitle`, or "" when it couldn't be read.
- **`ListTitle(main)` / `Title`:**
  - the title is the topmost *wide* visible STATIC (at least `TitleWidth` = 400 px; the title spans the list, 1713 px on the PC; the search labels are 235 px at most), the leftmost when level;
  - each label is read with `Native.TryText` (100 ms), and the first one that doesn't answer ends the look with "", so a lower label is never taken for the title;
  - no wide label, or an empty one on top, gives "";
  - words that aren't COSTAR's short words (`TitleWords`: 1–40 characters, letters first, then letters, digits, spaces and `'&/().,-`) give `UnnamedList`: still another list, with no words repeated.
- **`OtherList(showing)`:** another list's title (or `UnnamedList`) was read, not "Work-in-Progress".
- **`NotOnWip(costar, showing)`:** what is said in each case:
  - another list: "COSTAR … is showing "…" (or: another list), not Work-in-Progress (Add new there doesn't start a Repair Order). Put it back on Work-in-Progress";
  - "Work-in-Progress" named but not found: "… Work-in-Progress list isn't ready yet";
  - nothing read: "… isn't answering: which list it shows couldn't be read (it must show Work-in-Progress)".
- **`OpenNew`:**
  - before looking for Add new, another list refuses at once;
  - nothing readable, or Work-in-Progress still loading, is looked at again every 250 ms for up to `WipWaitMs` (15 s, about as long as the helper's other waits for a busy COSTAR), then refused;
  - Stop is honoured ("Stopped before Add new. Nothing was pressed.");
  - right before `beforeClick` and the press:
    - a last look refuses when another list's title is read;
    - the Add new found earlier must still be showing and enabled, and for a mouse click still the window under the point. These are read without any text, so a busy COSTAR can't slip past them.
  - Each refusal goes in the day log (`add_new_refused`) and throws "… Add new was not pressed.".
- **`WhyNotOnWip(target)`** (for the waits):
  - non-null when another list, or Work-in-Progress named but not found, was read;
  - null when COSTAR is too busy to say. That case isn't held back here, as before 2.6.8; `OpenNew`'s own look waits for it.
- **`CostarWindows.Available`** (phone jobs in `Worker`, phone Repair Orders in `RoEngine.Free`): `WhyNotOnWip` first, then open Repair Orders as before. The "A Repair Order is open …" text is unchanged, so 2.6.7's close-first still recognises it.
- **`RoEngine.Run`:** `WhyNotOnWip` right before `CloseOpenFirst`, so a Repair Order is never closed first for an open that can't happen ("… Nothing was closed or opened."). `Free`'s answer can be up to 3 s old.
- **`EbayEngine.Available`:**
  - checks `WhyNotOnWip` after finding COSTAR Sydney. An eBay order is declined back to the desk's queue with the reason, and goes in once the list is back;
  - if COSTAR closed or changed since the last look, the eBay engine looks for COSTAR Sydney again at once and says so.
- **End-of-day report:** `add_new_refused` is counted under THINGS TO LOOK AT, with the last reason. These refusals come before a run starts, so no run report holds them.
- **`StopCategory`:** `not_on_wip` for the texts, kept for any run that ends on one (none does today).
- **Test data:** the 2.6.7 test used a real online order number; it now uses the made-up TTW0000414.
- Version: 2.6.8 - Add new on WIP only. Includes 2.6.7.

## Replayed on the recorded maps

The check (Order Check's `WipScreen.Locate` and the new `ListTitle` / `OtherList`) was simulated on the maps' recorded controls (parents, classes, words, positions):
- **28 Oct 09:04**, COSTAR Sydney and both COSTAR Tempe windows on Work-in-Progress: found (the `ultraGrid1` list, one Search button). Title "Work-in-Progress", not another list. So eBay orders still go in.
- **28 Oct 09:50**, COSTAR Tempe with a Repair Order open: found.
- **29 Oct 01:05, 01:08, 01:10**, COSTAR Sydney on "Orders yet to be filled": not found. Title "Orders yet to be filled", another list, so Add new is refused at once.

## Review

An independent review of the first draft (commit 0082461) found **nothing critical or important**. In the default setup it found no way for Add new to be pressed while another list shows, and no way for a steady Work-in-Progress screen to be refused all the time. Its minor findings, and what was done:

1. **A lower label could be taken for the title** when the title's read timed out but a search label answered. Fixed: the first unanswered read ends the look, and the title must be the topmost *wide* label.
2. **"`not_on_wip` in the end-of-day report" was never recorded:** refusals come before a run report exists. Fixed: the end-of-day report counts `add_new_refused` from the day log; the README says so.
3. **The last look let an unreadable screen through to a mouse click** (Direct off, a list switched during the activation while still loading). Fixed: the Add new found earlier must still be showing and enabled, and for a click still the window under the point.
4. **A phone job handed out from an answer up to 3 s old can stop instead of waiting** if the list changes in between. Kept: nothing is pressed, the job says why, and Retry works (`beforeClick` hasn't run). The README says so. eBay orders recheck when they're claimed and go back in the queue.
5. **A refusal could take much longer than 3 s** while COSTAR is busy but not yet counted as hung. Fixed: the 250 ms WM_NULL look reads nothing from a COSTAR that doesn't answer. The wait for a busy COSTAR is now a deliberate 15 s.
6. **Privacy: `TitleWords` checks a label's shape, not where it comes from.** Hardened: only the topmost wide label counts, and odd words read as "another list". The mapped lists' titles are COSTAR's own words.
7. **First use of `Locate` on COSTAR Sydney.** Replayed on the recorded maps (below): Sydney's Work-in-Progress is found. README check step 2 shows it on the PC, and step 4 sends one real eBay order.
8. **Close-first could close a Repair Order before an open that then fails** (a nit). Fixed: `RoEngine.Run` checks `WhyNotOnWip` before `CloseOpenFirst`.
9. **Nits:** the eBay panel showed the desk's wording for a COSTAR that had just closed (fixed: it looks again at once); `TitleWords` ran twice per label (gone).

The reviewer also noted that the draft's "busy counts as ready" for the waits would let a Locate mismatch on Sydney fail every eBay order. Fixed: Work-in-Progress named but not found now holds work back with "isn't ready yet". Only "can't be read" isn't held back.

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **134 of 138** helper groups and 16 of 16 Order Check. The same 4 Windows-only groups fail here by design.
  - New group "Add new only on Work-in-Progress (2.6.8)":
    - the title (topmost wide label, leftmost when level, none or empty on top);
    - `TitleWords`, and words that aren't plain becoming "another list" without being repeated;
    - `OtherList`, the three texts, and the stop's kind;
    - never the open-Repair-Order wait text.
- 12 mutations, each of which fails the self-tests:
  - Work-in-Progress taken for another list;
  - long titles;
  - any characters;
  - rightmost; bottommost;
  - the unread text dropped;
  - the category dropped;
  - "another list" not another list;
  - an empty top label skipped;
  - a narrow title width;
  - a short wait;
  - odd words repeated.
- Replayed on the recorded maps (above).
- End-to-end on this build: Repair Orders 96, Job Card 19. Node tests: startup 9, Job Card 47, Repair Orders 10.
- Install replayed with the Updater code the PCs run, from "2.6.6 - Item lines clicked". The upload set was scanned for secrets and customer data, including the 28 and 29 Oct reports' Repair Order, document and online order numbers.

## Not verified here (no Windows or COSTAR here)

- **The checks on the real PC:** `WipScreen.Locate` and `ListTitle` on the live COSTAR Sydney and Tempe windows, and the WM_NULL look. README check steps 1–4 cover them.
- **The button check before the press:** whether another list hides Work-in-Progress's Add new (`IsWindowVisible` false). If it doesn't, the title look still refuses.

---

# Validation — v2.6.7 — 28 October 2026

## Basis

- **The ask.** Tommy, 28 Oct 15:11: "if I'm trying to access it through phone but the pc is opening a repair order, close that repair order so I can access it on the phone".
  - Before 2.6.7, a phone request waited while any Repair Order was open in COSTAR Tempe. The helper said "A Repair Order is open … close it (or finish the phone job waiting for review) first".
  - The phone offered a close only for the Repair Order that same phone had left open.
- 15:34: "change all idle time to 3 seconds", "by all I mean when its waiting for costar to be ready".
- **What an open Repair Order in COSTAR Tempe can be:**
  - one the Repair Order helper left open after a stop (its journal's `leftOpen`);
  - one COSTAR opened late, after an open had stopped (13:38 on 28 Oct);
  - one a person opened at the PC;
  - a phone job's, waiting for review (`WorkerEngine`'s checkpoint window);
  - an online order's, left for review or stopped in. The Online orders tab tracks these in `lastFilledWindow` and `stoppedIn`, which are lost on a restart; their PO# is TTW….

## Changes

- **`RoEngine.Free`:** when the only thing in the way is open Repair Order windows in COSTAR Tempe, `CloseFirst` decides. The helper then reports "ready: Repair Order … is open there and will be closed first", and the desk hands out the request. Otherwise it waits and the phone is told why.
- **`KeepOpen`** (what stays open, first reason first):
  1. held for review (`HeldForReview`: the phone job's pinned window, and the Online orders tab's windows);
  2. COSTAR asking something on it (`Runner.CloseBlocker`);
  3. someone used the PC in the last `CloseQuietSeconds` (3 s);
  4. its PO# couldn't be read;
  5. its PO# is an online order number (`^TTW\d{4,}$`).
  - The first three need no reading of the window.
- **`RoPeek.Read`:**
  - asks WM_NULL first (250 ms) and reads nothing when it isn't answered;
  - reads the words of the STATIC labels only, and stops at the first failed read;
  - then reads only the box beside the "RepairOrder" label (`Runner.NumberBox`) and the box under "PO#" (`Selectors.Under`).
  - Kept a minute per window; a failed read is tried again. Nothing read is logged, except an online order number in the phone's message.
- **`CloseOpenFirst`** runs right before `RoWip.Open` for open, change and print requests.
  - Each open Repair Order is looked at again: nothing held, nothing asked, nobody at the PC, PO# read.
  - The phone is told at once: "Closing Repair Order …, which was open in COSTAR Tempe, before opening Repair Order …".
  - Then `CloseWindow` runs: the `CloseBlocker` guard, WM_CLOSE, and a wait of up to 8 s. One that doesn't close stops the request, and nothing is answered.
  - The day log gets `ro_close_first`. `leftOpen` is cleared when it was that window.
  - The result starts with "Closed RO … first (it was open in COSTAR Tempe)."
- **`HeldForReview`** is set by the RDP helper's window, from `WorkerEngine.PinnedWindow` and `AutofillForm.HeldWindows`. When it's null, nothing is closed (as in 2.6.6).
- **Waits for a quiet PC:** `RoEngine.QuietSeconds` and `EbayEngine.QuietSeconds` are 3 s (10 s before); `CloseQuietSeconds` is 3 s. The checks during an open or a print (`RoWip.Quiet`, Print's last look) are unchanged.
- Version: 2.6.7 - Open RO closed first.

## Review

The independent review agent started on the first draft (`ebae527`) didn't report back: the session restarted while it ran. A self-review of the final diff covered the questions it was given:

- **What can be closed.**
  - Held for review: a phone job's pinned window, the Online orders tab's windows, and any PO# that is an online order number (for after a restart). These stay open, and so does one with a COSTAR question on it.
  - One the helper left open after a stopped change is closed (its typed words stay in it; the README says to open it on the phone to check).
  - A person's Repair Order is closed after 3 s without input, as Tommy chose.
- **Races.**
  - `Free` (its 3 s cache) only lets the desk hand the request out. `CloseOpenFirst` looks at every window again right before closing it.
  - The loop doesn't call `Free` while a request runs. `peeked` and `leftOpen` change only under the engine's gate, and `HeldForReview` is called outside it.
- **COSTAR's load.**
  - `RoPeek` reads nothing without an answer to WM_NULL within 250 ms, stops at the first failed read, and reads labels plus two boxes.
  - It reads only when nothing is held or asked and nobody is at the PC, and each read is kept a minute.
- **Phone and desk.**
  - The new waiting texts still start with "A Repair Order is open in COSTAR Tempe". The phone's offer to close the one it left open still works (a `close` request), and no website change is needed.
- **Fixed in this pass:** the Work-in-Progress search rule's comment had ended up above `RoPeek`; it's back in place.

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **133 of 137** helper groups and 16 of 16 Order Check. The same 4 Windows-only groups fail here by design.
  - New group "A Repair Order left open in COSTAR closed first for the phone (2.6.7)":
    - what stays open and why, first reason first;
    - an online order's PO# in either case, and only a real one;
    - a PO# that couldn't be read;
    - the number and PO# read from a made-up Repair Order, with the label missing, the PO# missing, and a box that isn't a number.
- Mutations, each of which fails the self-tests:
  - held closed;
  - an online order's closed;
  - an unread PO# closed;
  - closed while someone uses the PC;
  - any text taken as the number;
  - and five of the earlier ones.
- End-to-end on this build: Repair Orders 96, Job Card 19. Node tests: startup 9, Job Card 47, Repair Orders 10.
- Install replayed with the Updater code the PCs run, from 2.6.6. The upload set was scanned for secrets and customer data.

## Not verified here (no Windows or COSTAR here)

- **WM_CLOSE on a Repair Order a person opened.** COSTAR keeps it in Work-in-Progress; the helper's own closes have done that since 2.6.0. Check TEST-PLAN 2.6.7, step 2.
- **`RoPeek` on the real window:** whether the RepairOrder label and the PO# box are found. The `ro_close_first` lines should name the Repair Order.
- **The 3 s waits on the real PC.**

---

# Validation — v2.6.6 — 28 October 2026

## Basis

- Diagnostics of 28 Oct 14:05 (2.6.5 installed at 12:44). Seven Repair Order runs on 2.6.5; six completed.
- **The stop that 2.6.5 caused.** The run at 13:28, a car change with a print, stopped at stage "Car" with "The field lost focus before validation." Its events:
  - REGO NO note: `memo_focus` ok in 62 ms (2.6.5's direct try). Written, key pressed and taken back, Tab, read back ok.
  - ODOMETER note: `memo_focus` ok in 57 ms (direct). Written; "A" and Backspace taken, the note box checked as holding the keyboard before each.
  - Then `CommitField` found the keyboard elsewhere before Tab. No `direct_slow`, no `direct_fallback`, and nobody was marked at the PC.
- **History of the click.** Before 2.6.5, all 317 `memo_focus` waits were "ok" on the first try with the mouse, with no retries; 408 note read-backs were ok; no note commit ever lost the keyboard. 2.6.5's direct try reached 2 note lines and lost 1.
- **The item grid moves the keyboard by itself.** This was already known from earlier runs:
  - `leave_grid` needed three tries 8 times after notes;
  - 10 Oct: a click closes the line that had the keyboard, and the lines below it move up (RequireLineStill).
- **Other stops in the same report:**
  - "COSTAR did not accept customer phone": 3 on 28 Oct (2.6.2 and 2.6.4), 8 in all since 12 Oct. Every one came 1.54–1.65 s into the stage: a click, then WM_SETTEXT's 1.5 s limit running out, with COSTAR busy for 1.6–1.9 s (the probe). Writes 0. In runs that went through, WM_SETTEXT on the phone took up to 1.46 s.
  - "The field lost focus before validation" after an item loaded, with the mouse: 28 Oct 08:16 (the freight charge, 2.6.2), 25 Oct (an eBay quantity), 14 Oct (a quantity), 6 Oct (a phone job's quantity). Each came 0.1–0.2 s after the item finished loading. In two of them the grid's labels moved while it loaded (`grid_read_plan_reset`).
- **Not changed (they work as designed):**
  - 13:06 and 13:10: a document from Order Check's copy wasn't in COSTAR Tempe's Work-in-Progress list (15 rows showing at 13:06; 126 at 13:10, every cell read). Nothing was opened.
  - 13:38: "Someone used the COSTAR PC", 12 s into an open while COSTAR was still opening the Repair Order. 2.6.6 logs what was seen.
  - 13:49 (twice): COSTAR wasn't showing Work-in-Progress.
  - 12:45: seven day-log lines from the update's own self-tests (made-up lists). 2.6.6 mutes them.

## Changes

- **Item lines clicked (Runner):**
  - `Focus(c, grid)` and `Put(…, grid)`: a box of the item lines is clicked; 2.6.4's path is unchanged (ClickTarget, then up to 2 s for the box to have the keyboard).
  - Call sites:
    - `AddCode` and `RequireLineStill` (the item code);
    - `FinishLine` (quantity through `PutQuantity`, net price);
    - `FinishFreight` (quantity, list price);
    - `RoCell` (a line's quantity or price);
    - `RoAddItem` (a new item's quantity and price);
    - `RoRemove` (the item code, before Delete).
  - `FocusMemo` is 2.6.4's code again, identical by diff apart from a comment.
- **Leaving the item lines is a click (`ClickOnly`):**
  - A box gets the keyboard directly only when it isn't under the item lines' panel (`gridPanel`, which GridCurrent reads, the panel itself included) and the keyboard isn't in that panel now. Otherwise it's clicked, and `direct_skipped` says why ("a box of the item lines" / "leaving the item lines").
  - It's decided after `WaitIdle` and the box's checks, right before the press.
  - With no box holding the keyboard after this run has clicked into the item lines, it clicks.
  - If no read of the item lines has found the panel yet, the panel is looked for once per run (a phone job resumed with the keyboard still in a line from before).
  - Applies in `FocusDirect`, `FocusOrClick` and `PressTick` (Customer Waiting on the Repair Order).
  - So `LeaveGrid`, DET's leave (`LeaveForDetNotes`), and the first box at the top, Ship Via, Date In or Customer Waiting after line work are clicked, as in 2.6.4. Moves from one box at the top to another stay direct.
- **Words given time (WriteFocused):**
  - WM_SETTEXT may take 5 s (it was 1.5 s), and so may EM_SETMODIFY (it was 0.5 s).
  - On a time-out (ERROR_TIMEOUT), COSTAR is waited for (up to 8 s idle) and the box read. Words that are there count as taken (`write_late`).
  - Otherwise the stop says "COSTAR didn't confirm … within 13 s (it may still take it)".
  - A box that doesn't have the keyboard before its words now stops as "lost focus before its words went in" (`focus_failed`), no longer as "read-only or protected". A note that loses it before its key press is `focus_failed` too (it was "other").
- **Clicked once more (CommitField, FocusAgain):**
  - Applies to a quantity, price or note box of the item lines, when the keyboard isn't on it at Tab.
  - Conditions: the same box (CheckTarget), still showing exactly what was written (Order.Clean), COSTAR's Repair Order in front (Check), and nobody at the PC in the last 3 s.
  - Then `Focus(c, grid)` clicks it and COSTAR is waited for: idle, then 250 ms that the box must hold the keyboard through. The keyboard and the words are checked again, EM_SETMODIFY is sent again, and Tab follows.
  - A note line gets its key press again (`PressAtEnd`) before Tab, because COSTAR keeps a note only after one (25 Oct).
  - It happens once; a second loss stops as before. Not used for item codes (COSTAR looks those up on Tab) or for the boxes at the top.
- **Diagnostics:**
  - `Holds(h, step)` in WriteFocused, CommitField, PressAtEnd, KeyInto, RoKey and CursorAtEnd: a `focus_lost` event with the box that should have had the keyboard and the one that did (kind, handle, place: no words), COSTAR in front or not, someone at the PC or not, and the last input (`LastInputSeen`).
  - When an open stops for someone at the PC: `ro_user_active` in the day log (Quiet, and Activate's last look).
  - When a print stops for someone at the PC: `user_active` in the run (its first look, each click's look, Print's last look).
  - `LastInputSeen` never throws.
- `AppLog.Off` is set by `--self-test`; `AppLog.Skipped` counts the notes left out.
- Version: 2.6.6 - Item lines clicked.

## Review

An independent review of the drafts (`bb4f6c7`, `4f337b0`) found nothing that types into the wrong box or loses an order, and no remaining path where a box of the item lines gets the keyboard directly. What was done with each finding:

1. **The click before Tab on a note line had no key press after it.** Reading the words back doesn't prove COSTAR keeps them (25 Oct). A note clicked again now gets its key press again (`PressAtEnd`) before Tab.
2. **Leaving the item lines was still a direct press.**
   - PO# given the keyboard directly in `LeaveGrid` and `LeaveForDetNotes` could hold it while COSTAR never left its line. `LeaveGrid` would accept that, and DET's notes would wait 12 s and stop.
   - The same applied to the first box at the top after line work.
   - Fixed with `ClickOnly`: every move out of the item lines is a click.
3. **Two keyboard checks didn't log where the keyboard went** (`WriteFocused`, `CursorAtEnd`), and one called a lost keyboard "read-only". Both now use `Holds`, with their own wording.
4. **The self-test read the live day log**, which could fail on a sharing violation and block an update, and it didn't test the `--self-test` wiring. It now checks the wiring and a counter, and reads no files.
5. **The "someone at the PC" logs were incomplete.** `LastInputSeen` was added to `focus_lost` and to Activate's refusal, and the print path's refusals now log it too.
6. **Rough edges in the slower write:** EM_SETMODIFY got 5 s as well, and the 13 s stop says COSTAR may still take the words. A Stop can now wait up to 5 s inside a write.
7. **Docs.**

### Second review (`7b9b4d8`)

No blocking problems, and nothing worse than 2.6.4 for online orders, eBay orders or phone jobs in a way it could show. Done:

1. **`ClickOnly` could choose direct in edge cases:**
   - it was decided before COSTAR was idle;
   - no box holding the keyboard;
   - the grid panel itself holding it;
   - the panel not known yet, on a resumed phone job.
   It's now decided after `WaitIdle` and the box's checks. The panel itself counts, the panel is looked for once per run, and with no keyboard owner after line work it clicks.
2. **`FocusAgain` didn't wait for COSTAR to settle.** It now waits for COSTAR to go idle, then 250 ms, and the box must hold the keyboard through that before the key press or Tab.
3. **Comments; two stop wordings mapped to `focus_failed`.**

Its answers:
- The helper never leaves the keyboard in the item lines without having read them (`gridPanel` set).
- Nothing leaves the lines with an edit pending except through `ClickOnly`. Print, Add New, the print form and the line menu are unchanged from 2.6.4 there.
- `LeaveGrid` clicks on every try while the keyboard is in the lines.

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **132 of 136** helper groups and 16 of 16 Order Check. The same 4 Windows-only groups fail here by design.
  - New group "The day log (2.6.6)":
    - the `--self-test` run has the day log off;
    - a note while off is left out (`AppLog.Skipped`);
    - the new stop wordings fall into the right categories.
- Mutations, each of which fails the self-tests:
  - the 12 of 2.6.5;
  - the day log left on in the self-tests;
  - the new stop category removed.
- End-to-end on this build: Repair Orders 96, Job Card 19. Node tests: startup 9, Job Card 47, Repair Orders 10.
- `FocusMemo` compared with 2.6.4 by diff: identical apart from comments.
- Install replayed with the Updater code the PCs run, from 2.6.5. The upload set was scanned for secrets and customer data, including the Repair Order and document numbers of the 28 Oct report.

## Not verified here (no Windows or COSTAR here)

- **The click path into the item lines** is 2.6.4's, unchanged. Its record on COSTAR is the real PC's history: 317 note lines, and the item lines of every order before 2.6.5. The first car change on 2.6.6 is the check (TEST-PLAN 2.6.6, step 2).
- **New behaviour that runs only on Windows and COSTAR:**
  - leaving the item lines by a click (`direct_skipped` "leaving the item lines");
  - the 5 s write and the late read (`write_late`);
  - the click before Tab (`focus_again`; for a note, close and reopen to check it was kept: TEST-PLAN 2.6.6, step 8).
- **The flows that haven't run on 2.6.5 or 2.6.6 yet** (online orders, eBay orders, phone jobs) are the supervised checks in TEST-PLAN 2.6.6.

---

# Validation — v2.6.5 — 28 October 2026

## Basis

- Tommy, 28 Oct 08:29: "it's working, but it looks like its clicking instead of like native, how can I help to make it better? do you want to map it first?". 10:09: the 2.6.4 maps of seven screens arrived; they are saved as `claude/10-COSTAR-Map-Notes.md` and `claude/10-COSTAR-Map-Data-2026-10-28.txt`. 10:28: "full gas no brakes sir".
- What the maps showed (2.6.4):
  - COSTAR 5.7 is WinForms. Its buttons and tick boxes are owner-drawn BUTTON windows. They take BM_CLICK, which the helper has used for Search, Cancel and Yes since 2.x.
  - The Repair Order's toolbar is a ToolStrip. Its buttons exist only for accessibility (Back, Close, New, Print Alt+P, Sell Alt+L next to it, Schedule, Delete, PIN, History, Branch, E-Mail, Inspections), each with the action "Press".
  - Customer Waiting and the print form's ticks are tick boxes ("Check" / "Uncheck").
  - Ship to / Rebill to / Contacts / Notes are a SysTabControl32 ("Switch").
  - Work-in-Progress and the search results are Infragistics UltraGrid. Every row offers "Activate" except the active row (the one Enter opens), which is marked focused only while the grid has the keyboard. No row was selected when the maps were taken.
  - The line menu has Delete, Delete (Lost Sale), Select Line, Cut Line(s), Paste Line(s) and Deselect Line(s).
- Where 2.6.4 used the mouse:
  - the click into each box, in every kind of order (`covered` 18 times in the last runs);
  - Customer Waiting; Print; the print form's ticks and OK / Cancel;
  - eBay's tabs (`tab_switch` "click" 86 times);
  - Add New;
  - Work-in-Progress (wheel, click, double click);
  - the line menu (right click, then a click on Delete);
  - the customer list's row (after accessibility's selection, rarely).

## Changes

- **`Direct` (new, Direct.cs):**
  - `On`: setting `directPresses`, default on.
  - `Focus(h, ms, cancelled)`: Windows' SetFocus from COSTAR's own input queue, joined for that moment (AttachThreadInput, on a thread of its own). The wait ends at `ms` or at a Stop.
  - `Press(h)`: BM_CLICK sent, with SendMessageTimeout 1.5 s. Returns 1 when answered, 0 when not yet answered (it may still go), -1 when not sent.
  - `AfterPress`: what follows a tick press.
    - "done": the tick shows what's wanted.
    - "click": COSTAR answered and the tick reads unchanged, so one real click may follow.
    - "leave": unanswered or unreadable, so nothing more is pressed.
  - `PressLater(h)`: BM_CLICK posted.
  - `ShowTab(strip, i)`: TCM_SETCURFOCUS, which tells COSTAR the same as a click on the tab.
  - `Act(find, gate)` / `Went`: an accessibility default action, found and made on a thread of its own.
    - States are looking / pressed / given up. A press given up is never made late; a failed press is never followed by another.
    - `gate` is the last look, taken on that thread right before the press. If it says no, nothing is pressed and the reason is kept in its own field (`Refused`), so a time limit running out at the same moment can't write over it.
- **Boxes (Runner):**
  - `Focus`: `FocusDirect` gives the keyboard directly (3 s at most, ends at a Stop) and checks for 0.8 s that the box has it. Otherwise one click, with 2.6.4's checks.
  - `FocusOrClick` (leaving the item lines on tries 1–2; a note line's first try): the keyboard given directly with a 0.6 s wait at most. Like a click, it doesn't wait for COSTAR to finish with the box it leaves; the caller then looks where the keyboard is.
    - Leaving the item lines clicks from try 3.
    - A note line gets one direct try, then 2.6.4's three tries with the mouse.
  - Words still go in with WM_SETTEXT. Tab, Enter, Escape, Delete and the note's letter stay real keys.
  - As before, the cursor is put and checked at the end of the text before any key that could change it (the note's letter, Delete).
- **Customer Waiting and the print form's ticks (`PressTick`):**
  1. COSTAR must be in front and enabled, and the box must still be the same box (process, visible, enabled, window, parent, class), as the click checked. On the print form, nobody may be at the PC.
  2. The box gets the keyboard first, as a click gives it. The value is then taken in when the box is left, or when OK validates it.
  3. BM_CLICK, then the tick is read back (`AfterPress`).
  - Customer Waiting is then checked for 3 s as before. On the print form, "leave" cancels the form.
- **Print (`PressPrint`):**
  - A Print button window gets BM_CLICK posted.
  - COSTAR's drawn toolbar: the object at Print's place (where the click aims) is pressed through accessibility on its own thread. It must be named Print, with a button role, and not greyed.
  - Last look, right before the press: the Repair Order in front and enabled, and nobody at the PC for 1.5 s. If it says no (`Refused`), nothing is pressed and the helper stops, saying why.
  - Not found within 5 s: given up (never pressed late), then one click as before.
  - A press that went is never followed by a click. One that failed stops as "may have printed".
  - If the print form isn't open within 15 s while COSTAR is still on the press: "may have printed", so a phone retry can't print twice.
  - Every "may have printed" reaches the phone as that, never as "not printed … Print it at the PC". This also fixes 2.6.2's wording for a print form that closed at the PC before it came in front.
- **The print form's OK and Cancel:** BM_CLICK posted. `printOk` is set before, as for the click. A click only if the post failed and the button is still there under the point.
- **Work-in-Progress (`RoWip.OpenDirect`, `SelectForEnter`):**
  1. The row is selected through accessibility.
  2. Its "Activate" is pressed, but only while the row offers it: a selection can already make it the active row, which offers nothing to press. The row is looked up afresh among the list's children and must still be that Repair Order. The press is on its own thread, with a last look right before it: COSTAR's main window in front and enabled, nobody at the PC for 1.5 s.
     - If the last look says no, the open stops there, as for any step with someone at the PC. Someone at the PC is marked, so a window that opens meanwhile is never taken for the helper's.
  3. The list gets the keyboard directly.
  4. A read with new objects must show, with the list holding the keyboard:
     - the row is still that Repair Order;
     - it is COSTAR's active row: marked focused, or the only row offering no "Activate" while the others offer it;
     - it is the only selected or focused row.
  5. The same is looked at once more right before Enter, which goes with 2.6.1's checks.
  - Nothing opened: the 2.6.1 way.
  - This path no longer passes on `selected`. The opened Repair Order must match by its number, or by its name, comment, PO# and total all as listed.
- **eBay tabs:** TCM_SETCURFOCUS on the tab's place, checked by the page showing. The tab count is asked only on this path. Then the click, then Ctrl+Tab, as before.
- **Add New:** BM_CLICK (as when an open order covered it), never followed by a click.
- **Customer Not found:** its one button (OK) gets BM_CLICK. Escape follows only when COSTAR answered and the notice stayed; an unanswered OK stops.
- **Not changed:**
  - Taking a Repair Order line out works as in 2.6.4: the Delete key, then the right-click menu. The setting doesn't touch it. The review below showed that the menu's Delete may act on lines selected before.
  - The customer list's row.
  - The 2.6.1 mouse way in Work-in-Progress, now the fallback.
- **Desk window:** Files & settings has "Press COSTAR's buttons, ticks, tabs and boxes directly" (ticked). Off means 2.6.4 everywhere. Each press decision reads the setting once, so nothing is pressed directly and then clicked because the setting was switched in between.
- **Diagnostics:**
  - `Presses` is counted per stage.
  - Events: `direct_fallback`, `direct_slow`, `print_press`, `ro_open_direct`.
  - `ro_open_ok` says "row made the active row directly … opened without the mouse (Enter)"; `tab_switch` says "direct".
  - `memo_focus` says "ok" when the first try (the direct one) took.

## Review

An independent review of the first draft found 5 important and 7 minor items. Nothing was pressed twice. What was done with each:

1. **Accessibility presses fired seconds after their last check.** `Act` now takes its last look on the press thread right before the press. Print is pressed at its place (no search of the window). The last look is: in front and free, nobody at the PC.
2. **The line menu's Delete was new destructive behaviour, and which line it acts on was unverified.** Reverted: the line menu works exactly as in 2.6.4.
3. **The line menu with the setting off didn't behave as in 2.6.4.** Fixed by the same revert.
4. **BM_CLICK on a tick box isn't a click, and nobody had checked that COSTAR keeps it.** The box now gets the keyboard first. Two first checks at the PC are in TEST-PLAN: Customer Waiting kept after close and reopen, and one supervised Job Card print.
5. **Enter opens the active row, not the selected one.** The row is now made the active one and required to be it, and the only selected one. This is checked again right before Enter, and `selected` isn't passed on.
6. **A failed tick read led to a second press.** Now no second press ("leave"). PressTick also makes the click's in-front, enabled and identity checks.
7. **The setting was read several times in one operation.** Now read once per operation.
8. **Slow focus.**
   - Focus changes end at a Stop.
   - The tries that loop wait 0.6 s.
   - The note line keeps all three mouse tries.
   - Select-all on the first direct focus is harmless: words go in with WM_SETTEXT, and the cursor is put and checked at the end before any key.
   - Still possible: a focus change that COSTAR holds up with a message of its own completes once the message is answered. The keyboard then goes to that box; nothing is typed.
9. **A press still waiting to land was reported "not printed".** Now "may have printed".
10. **A late menu.** Gone with the revert.
11. **Small things:**
    - `DefaultAction` removed, along with the now-unused `FindOne` and `OpenMenu`.
    - A late finder can't overwrite the reason.
    - Seconds are shown with one decimal.
    - The tab count is asked only when the tab is shown directly.
    - Each press's wait handle is left to the garbage collector: a handful a day, and its thread may still set it.
12. **Test gaps.** The made-up list now keeps selected and active apart. New tests:
    - Activate ignored; another row active (marked, and told only by its action); nothing tells which row is active.
    - The last look saying no; the list sorted again before Activate.
    - The press's last look taken once, after the finding.
    - What follows a tick pressed directly.

### Second review (of the fixes)

No critical or important findings, and no path that prints twice, opens or types into the wrong Repair Order, or toggles a tick twice. Its four minor items are done:

1. **The last look's no before Activate went on to the mouse way**, which only stopped at its next look. It now stops the open at once, and someone at the PC is marked.
2. **Two new "may have printed" cases reached the phone as "not printed … Print it at the PC".** Now "may have printed … check the printer".
3. **A 5 s limit running out could write over the last look's reason**, turning a stop into a click (still safe, because the click looks again). The reason is now kept in its own field, and the time limit never replaces a reason already given.
4. **Logs and docs:** the note line's day log counts the direct try as the first try; this page's wording on the setting.

Its note on things that can't be checked here: if the selection already makes the row active, the row offers no "Activate", and pressing it might fail and send every open the mouse way. The press is now skipped when the row offers nothing.

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **131 of 135** helper groups and 16 of 16 Order Check. The same 4 Windows-only groups fail here by design.
  - New group "Direct presses (2.6.5)": a Repair Order opened from a made-up Work-in-Progress list with no click and no wheel. The made-up list keeps selected and active apart, as COSTAR's does.
  - The open goes to the mouse way when:
    - the list won't keep the keyboard;
    - another row stays selected or active;
    - nothing tells which row is active;
    - the list was sorted again before Activate.
  - The open stops when the last look before Activate sees someone at the PC, or COSTAR's main window not in front and free.
  - A selection that already makes the row the active one: no Activate pressed, then Enter.
  - Accessibility presses: never made late, never twice, never past a last look that says no; a failed press is "failed".
  - What follows a tick pressed directly.
- 12 mutations of the new code, each of which fails the self-tests:
  - a press made late;
  - a failed press taken as pressed;
  - the last look ignored;
  - an unanswered tick press followed by a click;
  - another selected row allowed;
  - the active row not required;
  - no Activate;
  - other rows' actions not read;
  - a fresh row of another Repair Order accepted;
  - the list not given the keyboard;
  - Activate pressed on a row that is already active;
  - the last look's no not stopping the open.
- End-to-end on this build: Repair Orders 96, Job Card 19. Node tests: startup 9, Job Card 47, Repair Orders 10.
- Install replayed with the Updater code the PCs run, from 2.6.4. The upload set was scanned for secrets and customer data.

## Not verified here (no Windows or COSTAR here)

- Everything that talks to COSTAR directly runs only on Windows:
  - SetFocus through joined input;
  - BM_CLICK on COSTAR's tick boxes and buttons;
  - the toolbar's Print through accessibility;
  - TCM_SETCURFOCUS;
  - the Work-in-Progress row's Activate and Enter.
- Whether COSTAR keeps a tick pressed directly is the first check at the PC (TEST-PLAN 2.6.5, steps 2–3): Customer Waiting after close and reopen, and the print form printing only the Job Card.
- Every path checks its result. Where a second try can't do harm, it falls back to the 2.6.4 mouse way. The switch turns it all off.

---

# Validation — v2.6.4 — 28 October 2026

## Basis

- Tommy, 28 Oct 09:09, with the diagnostics ZIP holding five 2.6.3 maps (09:04–09:08): "I dont know if this reads the repair order screen".
- What the maps showed. **Repair Order window:** Windows' view complete (about 300 controls: the Arrived / EstComplete / Parts Req. / In Shop / CustWaiting / Completed owner-drawn buttons, TaxIn, Check stock..., Next #, National / Rebill Accounts..., the Ship to / Rebill to / Contacts / Notes tabs, a "Toolbar" panel, 25 line panels with their boxes and a button each). Accessibility cut at 2,500 objects, 2,321 of them hidden: 2,046 were child windows' title, menu and scroll bars, size grips and their buttons; the toolbar and the lines were never reached. **The line's right-click menu** (a WinForms menu window): 11 items, each "Press". **Maps 2–4:** no COSTAR window in front (5 s too short over Remote Desktop); no map has the print form or the customer search window. **Every map** read all three COSTARs in the session (Tempe twice, Sydney): about 26 s each.

## Changes

- **`CostarMap` walk:** the state is asked first; an object below the window with STATE_SYSTEM_INVISIBLE is counted (`accessibleHidden`), not kept, and nothing under it is asked. Windows' frame parts that show (title bar, scroll bar, size grip, scroll thumb, the "System" menu bar) are kept with `frame: true` but not opened. The first-8-and-last-2 sample applies only to real lists (table, list, outline); other containers are read whole (≤ 2,000 children). Per window: 5,000 kept / 20,000 asked objects, 40 s; per map 100 s.
- **Which windows:** the COSTAR process of the window in front (else of the one on top) is read, up to 12 of its windows; other COSTARs' windows (and this one's past 12) are listed only (`listedOnly`: caption, class, place). Schema `tempe.costar-map.v2` (`costar`, `listedOnly`, `frame`, `accessibleHidden`, `accessibleFrames`, `accessibleMs`).
- **Reader's page (`.txt`):** the same line many times once, counted ("(x30)"); a list's rows, cells and items counted under it, its headings in one line; frame parts and the everyday states "can take the keyboard" / "selectable" left out (the `.json` keeps everything).
- **RDP helper window:** countdown 10 s; **Ctrl+Alt+F9** (`RegisterHotKey` id 2, MOD_NOREPEAT where Windows has it; a log line if another program has it) maps at once and ends a countdown; refused while an entry fills COSTAR (`TryBeginRead`) or a map runs; a sound when saved (Asterisk) or not taken / failed (Exclamation); the watchdog lets entries go on after 2.5 minutes; the hint under the Mobile jobs log mentions Ctrl+Alt+F9.

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **130 of 134** helper groups + 16 of 16 Order Check (the same 4 Windows-only groups fail here by design). New: a made-up Repair Order window as accessibility shows it (124 boxes, each with hidden title, menu and scroll bars and a grip; a tab page behind another; the toolbar last): the toolbar reached within 2.6.3's budget; each hidden part asked its state only, nothing under it asked; the title bar, system menu and grip kept but not opened; nothing pressed, selected or changed; box values as their length; the reader's page (toolbar buttons with keys and states, tabs, the same button once and counted, no frame parts or everyday states, another COSTAR listed); which windows are read and listed. The 2.6.3 map test now also checks the headings line and the counted rows and cells.
- 8 mutations of the new code (hidden parts read, role asked before the state, frame parts opened, every container sampled, other COSTARs read, repeats not counted, everyday states shown, frame parts on the page): each one fails the self-tests.
- Replayed on Tommy's 09:08 map: of the 2,500 objects 2.6.3 read in the Repair Order window, 2.6.4 keeps 100 and asks 301 hidden ones a single question (the other 2,099 are under them), so the same budget now goes on through the window.
- Node tests (startup 9, Job Card 47, Repair Orders 10); install replayed with the Updater code the PCs run; the upload set scanned for secrets and customer data.

## Not verified here (no Windows or COSTAR here)

- The map on the real COSTAR: whether COSTAR's "Toolbar" shows its buttons to accessibility (a WinForms ToolStrip does, each with "Press"); how long a map takes now; the hotkey and the sounds on the RDP PC.

---

# Validation — v2.6.3 — 28 October 2026

## Basis

- Tommy, 28 Oct 08:29, after the first 2.6.2 prints: "it's working, but it looks like its clicking instead of like native, how can I help to make it better? do you want to map it first?"; 08:31: "tell me which other process are still manual, so we can map all together"; 08:34: "go" (to the Map button: read only, 5 s to bring the screen up, six screens).
- Still done with the real mouse or keyboard (the list sent to Tommy): the click into each box and the Tab after it (every kind of order; the words themselves go in with WM_SETTEXT), clicks and keys in the lines grid, Add New, the customer search window's first account, Customer Waiting, Print / the print form's ticks / OK, eBay's Ship to / Rebill tabs, the Work-in-Progress open (wheel, a click, the double click, Enter), taking a line out (a click on its code and Delete, or the right-click menu). Already direct: the words in boxes, every read, the Search buttons, Cancel in COSTAR's popups, Yes on "delete this line?", closing a Repair Order, all of Order Check.

## Changes

- **`CostarMap` (new, CostarMap.cs):** every visible COSTAR window (processes named COSTAR; tooltips, shadows and IME windows aside; at most 12; the one in front first). A window that doesn't answer WM_NULL within 0.5 s isn't read. Per window: its class, caption (cleaned), owner, whether it's in front or in a menu loop, the control with the keyboard; **Windows' view** (EnumChildWindows, ≤ 2000): class, kind from class and style (button, tick box, radio, group, drawn button, text box, password / read-only box, drop-down, label, tabs, toolbar, list, tree, menu, COSTAR panel), id, style, place, enabled, COSTAR's words (labels, buttons; ≤ 40 characters, cleaned) or the length of a box's text, BM_GETCHECK for tick boxes, and "press / tick (BM_CLICK)" where a button window takes it; words stop for the rest of a window that doesn't answer a read within 90 ms; **accessibility's view** (OBJID_WINDOW, depth ≤ 14, ≤ 2500 objects and 25 s a window, 90 s in all): role, name (COSTAR's own words kept; rows, cells, list items, text boxes and anything inside a table or list except its headings: their length only; emails and long numbers masked), value (length only), state in words, default action, keyboard shortcut, place, children; a list of more than 40 has its first 8 and last 2 read and its size said. Only getters are called: nothing is clicked, typed, focused, selected or set.
- **Output:** `diagnostics\maps\map-<time>.json` and a reader's page `map-<time>.txt` (per window: Windows' controls by kind, what can be pressed or ticked directly, accessibility objects with an action or keys, lists with their size and headings). **Save diagnostics** adds the last 14 days of maps (`maps/`); kept 180 days.
- **RDP helper window:** **Map COSTAR screen** under Add note; "Map in N s ..." for 5 s; then the map holds COSTAR (`EntryCoordinator.TryBeginRead`: no entry starts meanwhile; others wait with "The map (reading COSTAR) is filling COSTAR") on a background thread; the header says MAPPING, "Read only: nothing is clicked or typed"; the log says what was saved. Greyed while an entry runs. If COSTAR doesn't answer the map for 2 minutes, entries go on again (the map may still finish).

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **129 of 133** helper groups + 16 of 16 Order Check (the same 4 Windows-only groups fail here by design). New: the map's words (kept / length only / masked), kinds by class and style, states in words; the made-up Work-in-Progress list (130 rows) read through the same accessibility calls: a sample (first 8 and last 2 rows), its size and headings said, no customer name, Repair Order number or PO# in the map, nothing selected, clicked, scrolled or focused; the reader's page; the budget.
- The 2.6.2 end-to-end tests (Repair Orders 96, Job Card 19) on this build; node tests.
- Install replayed with the 2.6.2 Updater code; the upload set scanned for secrets and customer data (release script).

## Not verified here (no Windows or COSTAR here)

- The map on the real COSTAR (how long it takes; whether COSTAR's controls answer accessibility as expected). It only reads, and stops waiting after 2 minutes.

---

# Validation — v2.6.2 — 28 October 2026

## Basis

- Tommy, 27 Oct 16:24, with three screenshots (the Repair Order window, COSTAR's print form as it opens, and as he wants it): "Step to print: 1. click print on the top left 2. that form will appear, by default the invoice will be light up, but we need to adjust 3. tick print job card and untick invoice, qty stay 1, and to can be left oki, if its not possible, then keep it to default, it will also work. Step to order: 1. on ship via type in SHOP 2. and tick on CustWaiting 3. make sure date is today. … I need you to allow these options to be done while doing the order on mobile or check order from mobile, so instead of ordering straightaway for mobile order I want both options to be showing up after I click on submit to costar, I want it to give me options to tick those 2 before going ahead".
- 17:45: "I cant deploy it now, but you can start working on it". His answers: the choices on the Job Card (after SUBMIT TO COSTAR) and on Repair Orders (when saving, and a print with nothing changed); both ticked to start with.
- 2.6.1 was not uploaded yet: 2.6.2 includes it.

## Changes

- **Printing (`Runner.Print.cs`, new):** `PrintJobCard(number, beforeOk)` never throws; its `PrintResult` says what happened in words, and whether it **printed** (OK went and the form closed), **may have printed** (OK went, or the form went some other way, but the end can't be told: never said as "not printed") or was **stopped**. Before Print: nothing of COSTAR's open on the Repair Order (`CloseBlocker`), nobody at the PC for 2 s, the Repair Order in front and enabled. **Print** found by its words only: one visible, enabled push button window (accessibility role 43) "Print" on the Repair Order, else one accessible push/drop-down/split button named Print inside its rectangle (not unavailable); nobody at the PC for 1.5 s (`Quiet`); for a window button, the window under the point must be it; for a drawn toolbar, accessibility must name Print at the point. **The print form:** a new COSTAR window titled "Print RepairOrder …" that holds still 300 ms, in front and enabled, for this Repair Order (its number in the title when known, else owned by the Repair Order's window); another form is cancelled unread; a COSTAR message instead of (or with) it is quoted and never answered; 15 s at most (a form that never came in front is said, and cancelled when it can be). **Its rows** (`PrintForm.Read`): the Print, eMail and Qty headings; a row for each tick box (MSAA role 44) under Print, its one eMail box on the same line, its name the first label right of the eMail column, its quantity the one edit box under Qty (a number box's own edit box, else the one readable box there), required for the Job Card; every tick box under eMail in a row; exactly one Job Card row; one OK. **Before OK** (`PrintForm.Wrong`, after setting and reading again): the Job Card ticked to print, every other document unticked, every eMail unticked, the Job Card's quantity read and 1. One real click a box, only when it isn't as wanted, then read back (3 s); a greyed box, a window opening, or a box that doesn't change stops it. Anything not as expected before OK: **Cancel** (the form's own Cancel button, by its layout or by its words; the form brought in front only when nobody is using the PC and no COSTAR message is) and "Job Card not printed: …"; a form that can't be cancelled is left for a person and said; a form that went without the helper's Cancel "may have printed". **OK:** once its click may have gone, nothing more is clicked. **After OK:** up to 30 s for the form to close; a COSTAR message meanwhile (with or after the form) is quoted, never answered, and the end is "may have printed".
- **Phone jobs (`MobileRunner`):** `MobileJob.options {order, printJobCard}` (no options: ordered, not printed, as 2.5.3). After the final check: if ordering, Ship Via SHOP and Repair Date today (`RepairDateToday`: read; typed only in an edit/combo box when not today); if printing, the Job Card (`MobileCheckpoint.print`: `started` just before OK or when it may have printed, `done` after; a resumed job never prints again); if ordering, Customer Waiting last (not after a Stop during the print; then COSTAR isn't brought in front either). None of it stops the job (the report dump included); `JobNotes` go with READY FOR REVIEW (`OrderNote`, the print's words). The RO's number for the form check is read beside its RepairOrder label (`ShownNumber`, ≥ 4 digits) or left out.
- **Repair Orders (`RoWorker`, `RoModel`):** kind `print` (open, read, print, close; nothing typed; a second print of the same Repair Order joins the first; surely not printed → `failed`, may have printed → `done` with those words; not done at all within 2 minutes of one that went); `RoEdit.print` (after the change is in and checked, before the close; part of the content hash; not a change alone). `RoAttempt.printing` just before OK (a helper closed after it says "may have printed"); after a Stop in the print the Repair Order isn't closed; an error after the print keeps its words. The desk's time-out and restart words for prints say "may have printed".
- **Versions out of step:** hellos say what the RDP helper does (`WorkerHello.jobOptions`, `RoHello.print`); health has `jobOptions` and `roPrint`, `/ro/list` `helper.print`. The desk never hands (or hands again) a print, or a job whose choices an older helper would ignore, to a helper that doesn't say it does them: it fails with nothing done and says why.
- **Job Card page:** SUBMIT TO COSTAR → `choices` dialog (Order, Print the Job Card; both ticked; Cancel) with a 2.6.2 RDP helper, else the old Confirm; health checked again before sending (changed meanwhile: nothing sent). The submitted card says what was chosen. RETRY can be scrolled clear of the SUBMIT bar on phones (`jobcard-bottom-space` 56 px; the page's own bottom padding is 22 px on phones).
- **Repair Orders page:** review with Order and Print ticks (both ticked each time); Order fills only what isn't so (not your own changes, not boxes the phone can't change); with nothing changed **Order / print…**; print-only requests; a save only from the open review (Try again opens it); sheet words for printing (**Check the printer** for "may have printed"); a print that joined another follows its ID; a print the desk forgot is offered only as a new print; `canPrint` follows the desk at once (a print refused because the helper doesn't print turns it off). Page assets `?v=20261027-ro4` / `-choices`.

## Independent review, round 1 (28 Oct)

A separate agent reviewed the first version (it also ran the page script against a stub to confirm finding 1). All eight are fixed:

1. **High: "Try again" after a failed save sent Order and Print without the review.** The review's ticks are page-wide and start ticked; after a reload (or another Repair Order's review) Try again sent Ship Via SHOP, Customer Waiting, today and a print the person had unticked. **Fixed:** a save goes only from the open review; Try again opens the review (as soon as the Repair Order is read). E2E: a save with both unticked, the page reloaded while it runs, it fails with nothing typed → Try again shows the review, nothing sent by itself.
2. **High: a print that may have gone could be said "not printed"** (a COSTAR message after OK with the form still showing, the form open 30 s after OK, the helper closing after OK, the desk's 90 s / restart time-outs). **Fixed:** `PrintResult {Printed, Maybe, Stopped}`; `Maybe` once OK was clicked (or the form went some other way); the Repair Order attempt notes `printing` just before OK (a restart says "may have printed"); the desk's time-out words for prints say so; a print-only request that may have printed ends `done`, never "not printed"; the phone shows **Check the printer**. E2E for both a print alone and a change with print.
3. **Medium: a window after the new Repair Date step stopped an entered phone job** (the report dump read the Repair Order and threw). **Fixed:** the dump can't stop the job.
4. **Medium: the print form was left open when its layout couldn't be read.** **Fixed:** Cancel is then found by its words (the form brought in front first, not while a COSTAR message is); a message shown with the form is quoted, nothing pressed; a form that never comes in front within 15 s is said (and cancelled when it can be).
5. **Medium-low: the Job Card's quantity was not checked when its box wasn't identified.** **Fixed:** the Qty column and the Job Card's quantity box are required (an edit box, a number box's own edit box, or one readable box) and it must read 1; else nothing is printed.
6. **Low-medium: a tick box or radio button captioned Print could be taken for Print.** **Fixed:** accessibility roles 44/45 are never Print.
7. **Low: a Stop during the print was swallowed** and the Repair Order closed anyway. **Fixed:** after a Stop nothing more is done; the Repair Order is left open and said.
8. **Low: a print that joined another phone's print lost track after a reload.** **Fixed:** the phone follows the joined request's ID. E2E: another phone's print waiting, this phone joins, reload → followed to "Job Card printed", one Job Card.

## Independent review, round 2 (28 Oct)

A second agent reviewed the round-1 fixes and the whole print path again (reading; compiled it). It found the round-1 fixes 1, 3, 5 and 8 holding, 2, 4, 6 and 7 holding in part, and nine more points. Fixed:

1. **Medium-high: the print form (or the Repair Order) could be brought in front under someone's hands** — the new cancel-by-words path, and the Repair Order before Print after a person took the screen. **Fixed:** nothing is brought in front unless nobody has used the PC for 2 s; otherwise the form is left and said.
2. **Medium: "printed" after OK when COSTAR then showed a message** (e.g. a printer that isn't there): **now "may have printed"** (a phone job keeps it as possibly printed: no second print on a Retry).
3. **Low-medium: OK counted as clicked, then the click itself failed** and the form was cancelled with "not printed" words under a "printed" headline. **Fixed:** once OK may have gone nothing more is clicked and the words are "may have printed"; any unknown end is worded so (safety net).
4. **Low-medium: a form that closed at the PC (not by the helper) was said "cancelled / not printed".** **Fixed:** the helper's own Cancel is told from a form that went some other way: "the print form closed at the PC, not by the helper … may have printed".
5. **Low-medium (plausible): desk restart during a print, then Print again → two Job Cards.** **Fixed:** a print alone of a Repair Order whose Job Card went (or may have gone) less than 2 minutes before isn't done; the phone says why.
6. **Low: a Stop during a phone job's print** went on to Customer Waiting and brought COSTAR in front. **Fixed:** after a Stop there, nothing more is clicked or brought forward; the job is READY FOR REVIEW with what wasn't done.
7. **Low: Print matched any button window captioned Print whose role wasn't a tick box** (a group, an unreadable role). **Fixed:** only a push button (role 43).
8. **Low: the print's outcome was lost when an error came after it** (journal save), and a report dump error before OK left the form open unsaid. **Fixed:** the error path adds the print's words (or "may have printed" once OK was noted); the dump can't stop the print; any error before OK cancels the form.
9. **Low: accessibility objects read for tick boxes weren't released** (about 100 a print): released now. A request handed to the RDP helper but not taken yet is not handed again to one that no longer prints / does the choices (as for waiting ones). An unreadable quantity is said as such ("couldn't be read").

Not changed: the phone job prints its Job Card before Customer Waiting is ticked (ticking it may make COSTAR open a window, which would stop the print); if the printed Job Card should show Customer Waiting, the order can be swapped once the first jobs show what COSTAR does. Accessibility calls into COSTAR have no time-out of their own (as everywhere in the helper).

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **128 of 132** helper groups + 16 of 16 Order Check; the same 4 Windows-only groups fail here by design. New: the print form read from its labels and tick boxes as on 27 Oct, and what must be on it before OK (COSTAR's default Invoice, other documents, eMail, quantity 2 / empty / unreadable, ticks that can't be read; forms with two Job Card rows, none, no eMail or Qty column, a stray eMail box, no OK, boxes accessibility doesn't call tick boxes, no quantity box; a number box and a quantity shown as words); the print form's title and number; the number beside the RepairOrder label; the phone's choices through validation, JSON, the desk's health and hand-over and a 409 for other choices; Repair Orders print requests, joining, the fingerprint; helpers that don't print / don't do the choices (waiting and handed-over requests and jobs).
- Mutation checks: with any one of these taken out a self-test fails — the desk's print guard, the desk's choices guard, the eMail check, one Job Card row, the stray eMail box check, the quantity check, the title check, print joining.
- Phone end to end, Repair Orders (`e2e_ro.py`: the real desk receiver code over TLS, a simulated RDP helper that prints, the page in headless Chromium 390×844): **96 checks**, incl. Order / print with no change, Save and print, print alone (Order unticked or nothing left to order), both unticked, your own Ship Via kept, not printed, may have printed (alone and with a change), a print the desk forgot (Print again is a new print), a helper that stops printing after the phone looked (refused at the desk, the offer gone at once), no print offered, Try again through the review after a reload, a print joining another phone's and followed after a reload; the 2.6.0/2.6.1 checks with Order and Print ticked by default. Round-2 (2.6.0) duplicate-change scenarios A–E with Order ticked: none reproduces.
- Phone end to end, Job Card (`e2e_jobcard.py`: the real Fitment Planner page, the real desk code in Pinad mode, a simulated RDP helper's job side): **19 checks** — the two ticks, Cancel, Order unticked, both ticked, an older RDP helper (Confirm as before, no choices sent), the helper changing version while the choices are on the screen (nothing sent) and after the job was sent (stopped at the desk, said; Retry with a 2.6.2 helper enters it with its choices), RETRY reachable above the SUBMIT bar.
- Node: Repair Orders page 10, check-package, job card 47, startup 9.
- Install replayed with 2.6.0's Updater code; the upload set scanned for secrets and customer data (release script).

## Not verified here (no Windows or COSTAR here)

- COSTAR's real Print button (a button window of its own, or drawn into the toolbar), the print form's controls (labels for Print / Qty / eMail and the document names; tick boxes that accessibility calls tick boxes; the quantity box's kind), its title with the number, and what COSTAR does after OK. The helper refuses and says why when they aren't as expected (the report has `print-form-controls`, `print_form_rows`, `print_button`).
- Whether COSTAR prints a phone job's new Repair Order without asking to save it first (if it asks: not answered, said; the job is still ready for review).
- Whether ticking Customer Waiting after the print opens a window; whether the Job Card shows Customer Waiting.
- The Repair Date box of a new phone Repair Order (normally today already: then nothing is typed).
- Self-tests on Windows (.NET Framework): if a group fails there, the update is set aside and the version before starts again (send the startup report).

---

# Validation — v2.6.1 — 27 October 2026

## Basis

- Tommy, 27 Oct 13:39, with the RDP helper's report from 13:33: "it is working, but remember, I am a speed demon, and this is taking forever, like, unacceptable".
- The report (2.6.0, six Repair Order runs that afternoon): opens took 17.5, 17.0, 145.9 and 133.4 s, two saves (a car change each) 137.6 and 137.2 s. Inside those, the Repair Order itself took 2.3–4.0 s (reading it about 0.5 s, COSTAR's close 0.6–1.0 s after its own 1 s of work, the change and its check 1–2 s). The rest, 15 s to 2½ minutes, went before the Repair Order window appeared: finding its row in COSTAR Tempe's Work-in-Progress (about 130 rows). 2.6.0 pressed Search, then read every cell of every row through accessibility (about 4 s a look), again after selecting the row, after each of up to 14 scroll steps of at most 10 notches, just before the double click, and once more after it. Two opens were stopped by someone using the PC during those minutes; one by a list showing no table.
- 16:26: "dont worry about the print and the order for now, finish the speed update first" (printing the Job Card and the shop-order options are a later update).

## Changes

- **`WipScan` (new, RoWorker.cs):** one look at the list for one open: only each row's Document # cell is read (the row's own child, its name checked on the first 3 rows, every 10th and the wanted one; every cell, as 2.6.0, when that doesn't hold), the cells are kept, so where the rows are after a scroll is one call a row. Duplicates (the active row listed twice) are one line, at the place shown. Rows without a place, or placed above the bottom of the column headings (when the list says where they are), are out of view. Released when the open ends.
- **`WipScroll` and `RoWip.Reveal`:** nothing when the row is in view; else it is selected through accessibility (the list may scroll to it); else the wheel, turned only while the list itself has the keyboard (one click on a row in view gives it, at most twice; else it stops, saying what has the keyboard). One notch first, to measure how many rows a notch moves; then turns of up to 20 notches worked out to bring the row to the middle, never closer than a row to the list's end (as seen), and a single notch for the rest. **Every turn is accounted for:** the list must move by exactly notches × rows-per-notch (a single notch: any move up to its rows, as it comes whole or not at all) and then hold still for 150 ms before anything else; if it moves less within 0.8 s + 0.15 s a notch (and 1.5 s of stillness), once more with new objects, or otherwise, it stops and opens nothing. 40 turns or 30 s at most.
- **`RoWip.Aim`:** after the row is in view, first what takes time (COSTAR in front, its windows looked at, the double-click time waited out), then the last looks: when the list moved or was searched, read again with new objects and watched holding still for 200 ms; the row at its place among the list's children looked at with new objects (`FreshCheck`: still this Repair Order, at the same place; else read again once); its place read twice 150 ms apart.
- **`RoWip.Open`:** Search only when needed (`WipSearch`: the list shows nothing or not this Repair Order, Order Check's read from the last 3 minutes doesn't have it, or there's no such read and no Search in that COSTAR for 10 minutes; a filtered read proves nothing); not found after a Search: read once more with every cell. Just before the double click: no key held, nobody at the PC, COSTAR in front, the list under the point, and what accessibility finds at the point (`AccessibleObjectFromPoint`) not another Repair Order (`CheckPoint`; "can't tell" lets the looks before stand). If the double click opens nothing: the list read again, the wanted row the only selected or focused one, the list itself holding the keyboard, then Enter.
- **Identity (`Runner.OtherNumberShown`):** another number in the box beside the RepairOrder label stops it ("COSTAR opened Repair Order …, not …. Nothing was changed.").
- **Day log:** every open, change and stop says where the time went (`list read …, no Search / Search …, row in view / brought into view with N wheel turns … (N notches), at the point: this one / can't tell, COSTAR opened it in …, … in all`); the run report has the same line (`ro_wip`). `ro_wip_keyboard` when the list won't take the keyboard.
- **Shown as soon as read:** after reading (open) and after the final check (edit) the helper sends a `working` report with the Repair Order, then closes it. The phone shows it at once ("COSTAR is closing it…" in the save bar; "In COSTAR and checked" on the save sheet, with COSTAR's notes and **Done**).
- **List:** answered from Order Check's own copy when at most 3 minutes old (30 s for ↻, the phone's `fresh`), else read from COSTAR Tempe as before. Desk: `RoAsk.fresh` / `RoTask.fresh`; a fresh ask makes a waiting list read fresh; an older list never replaces a newer one (`RoQueue.Older`).
- **Phone:** status asked every 0.4 s for the first 10 s (0.9 s to 30 s, then 1.5 s). A Repair Order a read or save left open is marked (`tempe:ro-left:v1:<doc>`, 24 h); while the helper waits because a Repair Order is open, the phone names the one it left open and offers **Close RO … in COSTAR** (any open, not only that one's); the mark goes once it is closed, even if the sheet was closed first. Page assets `?v=20261027-ro3`.
- `Msaa.All`: accessibility's children call only for COM objects (COSTAR's); the self-tests' made-up list and a missing library take them one by one. `Msaa.FromPoint`, `Native.WheelStepsNow` (at most 60 single notches in one SendInput, none for 0), `Native.DoubleClickMs`; `WipSearch` on a monotonic clock.

## Independent review, round 1 (27 Oct)

A separate agent reviewed the first version and modelled COSTAR working through the wheel notches at its own pace.

1. **Medium-high: the list could be taken as settled while COSTAR was still working through queued notches** (8 of 280 opens in its model landed on another row). Fixed in round 1 by whole-list stillness; replaced in round 2 by accounted turns (below). Its model against the final code: **280 opens, 0 wrong rows, 0 stops** (average 1.6 s).
2. **Medium: skipping Search** lost a list showing no table and a row still listed for a Repair Order finished meanwhile: now `WipSearch` (above).
3. **Medium-low: the keyboard check** took a box inside the list as the list: now the list's own window must have the keyboard, waited for up to 1 s after the click.
4. **Medium-low (phone):** COSTAR's notes with the early "checked"; the left-open mark and the close offer.
5. **Low:** older lists, ↻ during a read, Order Check's filter in the note. 6. **Low:** sampled cell names. 7. **Low:** no wheel event for 0 notches; a second click waits out the double-click time.

## Independent review, round 2 (27 Oct)

A second agent reviewed the round-1 fixes, added a "burst" wheel (4 notches 12 ms apart, then a pause, COSTAR answering accessibility meanwhile) and mutated the code to see which tests notice.

1. **Medium-high: pauses partway through the notches still sent the double click to the wrong row** (gaps of 700 ms: 2 of 6 opens; 1000 ms: 3 of 6), because a new turn was worked out from a read taken while earlier notches were still on their way. **Fixed:** accounted turns (each turn must move the list by exactly its notches before anything else), turns kept a row short of the list's end, single notches whole. Its burst model against the final code, gaps 100–1400 ms, both kinds of list end: **84 opens, 74 right, 0 wrong, 10 stopped** (all 10 at 1400 ms).
2. **Medium: the tests passed for the wrong reason** (each guard alone was enough for every model the tests had). **Fixed:** the tests now have the burst wheel and assert "may stop, never another row"; with the accounting taken out they fail (row 120 instead of 102), as they do without `FreshCheck` (a list sorted again: row 51 instead of 50), without the headings check (a double click behind the headings), without the end margin, and without `CheckPoint`. The 150 ms stillness after a turn, Aim's 200 ms watch and its second look 150 ms later stay as defence in depth: no model here needs them on top of the accounting, so taking one out alone isn't noticed.
3. **Medium-low: the last look wasn't the last thing before the click** (COSTAR brought in front, its windows listed, the phone told, the double-click time waited out came after it). **Fixed:** all of that now comes before the last looks.
4. **Low-medium: a row in view was never looked at with new objects.** **Fixed:** `FreshCheck` (new objects at its place) on every path, and `CheckPoint` at the click point.
5. **Low: the Enter fallback checked less.** **Fixed:** read again, the wanted row the only selected or focused one, the list's own window holding the keyboard.
6. **Low: the identity check could accept a Repair Order showing another number** (two new $0.00 Repair Orders for one account). **Fixed:** `OtherNumberShown`.
7. **Stops on the real PC (they stop rather than misclick):** the exact keyboard test (kept: a box inside the list could take the wheel; the stop now says what has the keyboard), long turns on a slow COSTAR (now 0.8 s + 0.15 s a notch + 1.5 s of stillness, once more with new objects), failing reads (one odd place no longer moves the scroll row: the middle of all rows in view), the wall clock (now monotonic).
8. **Phone, low:** the offer named a Repair Order as if it were the open one (now: "a Repair Order is open … your phone left RO … open there"), the mark stayed if the sheet was closed first (cleared now), opening another Repair Order got no offer (now it does).

## Checks performed here

- Compile C# 5 against .NET Framework 4.6.2 / 4.7.1 / 4.7.2 / 4.8 references (build and rsp sets): 0 errors, the 3 known warnings.
- Self-tests (harness on .NET 8, Linux): **125 of 129** helper groups + 16 of 16 Order Check; the same 4 Windows-only groups fail here by design. Repair Order groups take about 9 s.
- Mutation checks (above): accounting, `FreshCheck`, headings, end margin and `CheckPoint` each fail a test when taken out.
- Phone end to end (`e2e_ro.py`: real desk receiver code over TLS, simulated RDP helper, the page in headless Chromium 390×844): **56 checks** pass, incl. the early snapshot, the left-open offer for the same and for another Repair Order, the close clearing the mark. Round-2 (2.6.0) duplicate-change scenarios A–E: none reproduces. Node: Repair Orders page 10, check-package, job card 43, startup 9.
- Both reviewers' models rerun against the final code (above).
- Install replayed with 2.6.0's updater code and the upload set scanned for secrets and customer data (release script).

## Not verified here (no Windows or COSTAR here)

- How COSTAR's grid answers on the real PC: a row's own child as its Document # cell, places of rows out of view, the column headings' place, rows per wheel notch, whether selecting a row scrolls the list, which window has the keyboard after the click on a row, and whether `AccessibleObjectFromPoint` names the cell under the mouse (the day log says `at the point: this one` or `can't tell`).
- The real times: expected about 3 s for a row in view and 4–6 s for one far down, of which COSTAR's own open about 2 s. The first reports will tell.
- The Repair Order window's RepairOrder label and the box beside it (from Tommy's screenshot, not read on the PC yet).
- Self-tests on Windows (.NET Framework): the made-up list runs there for the first time; if a group fails, the update is set aside and 2.6.0 starts again (send the startup report).

---

# Validation — v2.6.0 — 27 October 2026

## Basis

- Tommy, 27 Oct: "Next project is to be able to add new and open the repair order and also edit it through the phone, but with better UI UX interface, run it."
- His answers the same day: any Repair Order in Tempe's Work-in-Progress (a searchable list); change the customer details, the car and notes, products and quantities, prices, Ship Via (SHOP), Date In / Repair Date and Customer Waiting; straight in (no approval on the desk); closed again afterwards; COSTAR opens a Repair Order with a double-click on its Work-in-Progress row, or the row selected and Enter; a line is taken out with a click on its item code (not the description) and Delete, or the line's right-click menu → Delete. A new Repair Order starts on the Job Card as before.

## Changes

- **Phone page** `Website/Repair_Orders.html`, `repair-orders.js`, `repair-orders.css` (new): list (search, All / Today / This week, the helper's state), one Repair Order in four sections (Customer, Car, Lines, Job) with a save bar counting the changes, an add sheet (common codes M FB, WA, WAFR; M codes take no quantity or price), a review sheet (before → after for every change) and a progress sheet (sent → waiting → typing → checked and closed). Rules mirror the helper's. Unsaved changes are kept per Repair Order for 24 hours; a read is reused for 2 minutes. After a part-way stop: **Close it in COSTAR** / **Read it again**; after "COSTAR's copy changed": COSTAR's copy with the phone's changes on top. Customer words are only ever set as text (no HTML from data). `costar-client.js`: `roList`, `roAsk`, `roStatus` (404 → null). Links on `index.html` and `Fitment_Planner.html`.
- **Desk** `LocalHttp.cs`: `/api/mobile/v1/ro/list`, `/ro/requests`, `/ro/requests/{id}`, health fields, the helper's long-poll `/api/worker/v1/ro`; a request body up to 1 MB only for that poll with the worker key (decided from the path as the routes read it, before the body is read; 64 KB for everything else, as before). `RoModel.cs` `RoQueue` (in memory; one list read and one open per Repair Order at a time, one change or close per Repair Order, 20 waiting at most, 10 minutes to be taken, 90 s of helper silence, finished ones kept 3 hours). `RoDesk.cs` (new) + `DesktopUi.cs`: **Repair Orders** tab and **RO** chip.
- **RDP helper** `RoWorker.cs` (new): `RoWip` reads the Work-in-Progress grid through accessibility (as Order Check does), finds the row (Search, then the wheel to bring it into view), opens it with a double-click on a cell of that row, or the row selected and Enter, and waits for the Repair Order window; any other window stops it. `RoEngine`: the long-poll, when it may run (as eBay orders: switched on, nothing else typing, Online orders tab closed, Tempe selected and on Work-in-Progress with no Repair Order open, 10 s without input), list / open / edit / close, the journal `ro-journal.dat` (DPAPI) with the Repair Order left open.
- `Runner.Ro.cs` (new): the Repair Order read (`RoRead.Build`, every box, Ship Via, Date In, Customer Waiting, the filled lines with kinds, DET's three notes, fingerprint), its identity (its number shown on it, or its name, comment and PO# as in Work-in-Progress with the row selected or the same total), the change (`EditRo`: `RoEdit.Validate` against the read, every box found first, then the changes in a fixed order, each read back), line removal (`RoRemove`: click on the item code, cursor after its last letter, Delete; else the right-click menu's one Delete item; a confirmation about deleting answered Yes, any other question stops), the final check (`LeaveGrid`, read again, `RoExpect.Check`: asked boxes hold the asked values, other boxes unchanged, old lines in order with the asked changes, new lines present, nothing else) and `CloseRo` (WM_CLOSE, as Next Order).
- `Runner.Customer.cs`: Customer Waiting split into find / read / set (phone jobs unchanged). `Native.cs`: accessibility value and state, mouse double click, right click and wheel. `RoTab.cs` (new): the RDP helper's card on the Mobile jobs tab (`AppSettings.roOn`, default on).
- `RoTests.cs` (new): 9 self-test groups (reading and fingerprint; Date In formats; the change rules; the after-check incl. a line that only lost its code and the total; the questions answered, the RO number and the day log; the desk queue; the phone routes; the held poll; body sizes). `Tests/test-repair-orders.cjs` (new, Node): the page's draft on a newer read and its box rules.

## Independent review, round 1 (27 Oct)

A separate agent reviewed the new code (it reproduced the first item in a browser). What it found and what was done:

1. **High — a change could go in twice.** When the phone lost sight of a save it had sent (back, reload, a slow answer), it kept the draft and could send it again on the next read, with new lines added twice. Now a save is written down with its request ID before it is sent and followed by that ID wherever the phone goes; a reload, going back or "Lost contact → Check again" only ever asks about that ID (the same ID sent again returns its status); another save of that Repair Order waits until it ends; the result applies to that Repair Order whatever is on screen. A draft's new lines are kept on a newer read only when no save of it may have gone in part way, or COSTAR read just now still holds exactly what the draft was made on; otherwise they are left out and the phone says so. End to end: back during a save, a reload during a save, a lost answer, a part-way stop with a new line: each change in COSTAR once.
2. **High — "Nothing was changed" after typing** when the Repair Order window had gone. Now "typed" means a write was tried (counted before it goes), and the message says the Repair Order was closed while the helper was typing.
3. **A draft's line change could move to another line** after "COSTAR's copy changed". Line changes now carry what their line held (code, words, quantity, price) and follow it; one that doesn't fit exactly one line is left out and said. The review names a line to take out by its words.
4. **Right-click fallback.** Now only COSTAR's own line menu (Windows' menu window, or one that says it is a menu; not a text box's Cut / Copy / Paste menu) with exactly one enabled Delete item, clicked only while the menu is still under the point; Escape only while Windows says a menu has the keyboard (else the menu is left for a person); any other window after the right click stops. A line that only lost its code (words or price left) stops at once, and the final check fails on one; the total must stay the same when nothing priced was asked.
5. **A slow answer for one Repair Order could land on another's screen.** Every answer is checked against the Repair Order on screen.
6. **"Already changed" could miss a step that typed and then stopped.** Each step is listed as soon as it may have typed ("typed, not checked" until checked).
7. **Dialogs answered while opening.** Nothing is pressed in a COSTAR message box any more; it is read for the phone and left for a person. COSTAR's "Customer Not found" notice after a new mobile number is still dismissed, exactly as on every phone job.
8. **WM_CLOSE over a COSTAR question.** Every close (after a read, a stop, a change, from the phone) only when the Repair Order is enabled and owns no visible COSTAR window; otherwise it is left open and said.
9. **The delete question was matched loosely.** Now a box the Repair Order owns, exactly Yes and No, words about deleting this line, and none about saving, printing, invoicing, paying, closing, stock, special or back orders, all lines or the customer.
10. **A done save that didn't close** now says "In COSTAR, not closed yet" (it may be asking something at the PC), not "Saved".
11. **The RO number anywhere counted** (a comment naming another RO). Now only a label or a read-only box outside the customer boxes and the item lines.
12. **Opening from Work-in-Progress.** Real input on the PC is checked before every click, scroll and key while opening (the helper's own don't count), the click goes on the Document # cell, Enter only with no Shift/Ctrl/Alt held, no Repair Order window being built (hidden ones count) and COSTAR idle 3 s; a Repair Order window that appeared during a stopped open is closed only when nobody used the PC and it is the only one.
13. Phone rules now match the helper's (lengths, no tabs, 25 lines, locked boxes).
14. No customer words in the day log (COSTAR's words, account numbers and long numbers left out).
15. 1 MB bodies only for the keyed Repair Order poll (see Desk).
16. A Repair Order the helper had open when it was closed or restarted is remembered as left open (the phone can close it); a stopped open's window is no longer lost.
17. Closing from the phone first checks that it is still that window in that COSTAR and that nothing is open on it. 18. The list read presses Search only with no Repair Order open right now. 19. Repair Orders run only when the selected COSTAR is Tempe (Branch 11). Repair Orders stay on by default after the update (nothing happens until a phone asks). 20. Smaller page fixes (box limits set anew per Repair Order, no stale progress).

## Independent review, round 2 (27 Oct)

A second agent checked the fixes. Round 1's fixes held except where noted here; it reproduced five more ways the phone could still put a change in twice or on the wrong line, all now fixed and re-run with its own scripts (none reproduces):

1. **The draft now remembers the fingerprint its save was sent from** (replacing a flag that later reads could move or clear). Its new lines and lines taken out are kept on a newer read only while COSTAR, read just then, still has exactly that fingerprint (nothing of the save can be in), or when that same save is known to have typed nothing with the desk holding that one request throughout. The mark is cleared only by the save that set it, or by a fresh read with no save open (what is left is then only "set this to that"). So: a save the phone never saw end and only comes back to hours later (its record expired), a desk restart during a save ("Check again" now asks the desk first; "Send it again" marks the save as resent), a read that lands while a save is open, and a save sent again at once after a part-way stop: each puts its lines in once.
2. **Lines that look the same:** a line change remembers which of the identical lines it was and follows it only while there are still exactly as many of them; otherwise it is left out and said. Lines taken out are left out too when a save may have gone in part way.
3. **Editing waits while a save is open** (the form and Undo all are locked: what was sent is what goes in).
4. **The "delete this line?" answer** now needs the whole question to be one of a short list of wordings about one line ("Delete this line?", "Are you sure you want to delete this item?", "Remove the selected row?", "Delete line 3?", "This line will be deleted. Continue?" …), singular, with exactly Yes and No; plurals, linked lines, lines on order, received or reserved stop.
5. **Clicks go at once after their last check:** the menu's Delete, the right click, and the clicks, wheel, double click and Enter that open a row first wait for any held Shift/Ctrl/Alt, then look, then act with no further wait.
6. A menu's shadow window (and tooltips) no longer count as another window. A line taken out whose line changed in COSTAR is said, not dropped quietly.

## Checks performed here

- Compiled at C# 5 against .NET Framework 4.6.2, 4.7.1, 4.7.2 and 4.8 reference assemblies: **0 errors**, the 3 known warnings.
- Self-tests: **122 of 126** + **16 of 16** (the same 4 Windows-only groups fail here). Node tests of the helper (package check incl. the new page's script references, job card 43, startup 9, Repair Orders page 10, Order Check).
- End to end: this build's desk receiver code over TLS on 127.0.0.1, a simulated RDP helper on the worker route, the phone page in headless Chromium at 390×844: **43 checks** (pairing, waiting with the helper offline, list order, search and filters, open, letter limits, validation, change count, draft kept after reload, review, the exact change sent, the page after saving, "COSTAR's copy changed", a line taken out after COSTAR's lines moved, a part-way stop with a new line (the steps ticked up to where it stopped) then the close and a new read, the same draft saved again at once after a part-way stop, the account rule, the 2-minute reuse, back during a save, a reload during a save, a lost answer then Check again, a slow answer for another Repair Order, M codes, no script errors). Screens checked by eye.
- Two independent reviews by separate agents (above); round 2's five browser scenarios re-run after the fixes: none reproduces.
- Install replayed with 2.5.3's Updater code; secret and customer-data scan clean.

## Not verified here

- Everything in COSTAR (Windows only), TEST-PLAN 2.6.0: reading the Work-in-Progress grid with a cell per column caption; the double-click and Enter that open a row; whether the Repair Order shows its number (otherwise the identity check uses name, comment, PO# and the selected row); the Date In box (a text box, a drop-down or a calendar: a calendar is left for COSTAR); the Delete key and the right-click menu on an item code, and any question COSTAR asks; Customer Waiting on Repair Orders not made by the helper.
- The page on real phones (iPhone safe area, the date picker).

---

# Validation — v2.5.3 — 26 October 2026

## Basis

- Tommy, 26 Oct: "Pretty happy with the mobile jobs now, please make it so it will automatically put SHOP on the ship via and tick customer waiting. Also for the mobile website, make a button to switch easily to the job card section."
- Order Check already asks for both ("Put SHOP", "Tick Customer Waiting").

## Changes

- `Runner.Customer.cs` `SetShipViaShop(always)`: phone jobs pass `always` (SHOP for every customer); online pickups keep the customer-number rule.
- `TickCustomerWaiting`: the Repair Order's BUTTON-class controls are read for their caption ("Customer Waiting", "Cust. Waiting", a few words at most); failing that, a caption-less box beside such a label. Exactly one, or nothing is done. Its accessibility role must be a check box (44); its checked state is read (STATE_SYSTEM_CHECKED); already ticked, locked or unreadable → a log line, nothing clicked. Otherwise one real click on the box (COSTAR in front, the box where it was, nothing over it), then up to 3 s for the tick; a COSTAR window opening is left alone. Never fatal. Diagnostics `customer_waiting` (with the buttons' captions when not found; no customer data).
- `MobileRunner.cs`: after the final check, Ship Via SHOP, the report dump, then Customer Waiting (last; a Stop there leaves it by hand); stage count includes both.
- Website (also on GitHub): `index.html` Job Card button (phones, ≤768 px, where the page links are in the menu) with the card's product count; `F_alt_tab.js` `refreshJobCardSwitch` (on load, after Add Tyre, on any card change via the shared store, back from the Job Card); `allaround.css` button style, room under the results, toasts above the button. Script and style version tags `20261026-jc1`.

## Checks performed here

- Compiled at C# 5 against .NET Framework 4.6.2, 4.7.1, 4.7.2 and 4.8 reference assemblies: **0 errors**, the 3 known warnings.
- Self-tests: **113 of 117** + **16 of 16** (the same 4 Windows-only groups fail here). Node tests of the helper (package check incl. website script references, job card 43, startup 9, Order Check).
- F Alt Tab in Chromium at 390×844 (phone) and 1280×900: the button shows on the phone only, links to the Job Card, shows the count after Add Tyre and after a change in another tab, and sits below the toast; no page errors.
- Install replayed with 2.5.2's Updater code; secret and customer-data scan clean.

## Not verified here

- Customer Waiting in COSTAR (Windows only): its caption, that accessibility reports it as a check box with its tick, and that one click ticks it (TEST-PLAN 2.5.3). Whatever COSTAR does when it's ticked (a picking slip) happens as when it's ticked by hand.
- The button on real phones (iPhone safe area).

---

# Validation — v2.5.2 — 26 October 2026

## Basis

- Tommy, 26 Oct: 2.5.1 works ("working nicely now"); for eBay, press Close after the input.
- 25 Oct: after the desk updated itself to 2.5.1 it said "Receiver could not start: Only one usage of each socket address…": the old receiver still held its port (the restart waits 3 s; the desk gave up at once). Ending the old TempeMobile.exe and starting again fixed it.

## Changes

- `Runner.Ebay.cs` `CloseEntered` (after the final check, when `CloseWhenEntered`): nothing if a CHECK BY HAND note exists; otherwise `LeaveGrid("before closing")` (PO# clicked, text checked unchanged, as for DET) so COSTAR commits the last line; COSTAR in front and enabled, PO# = this order, total unchanged since the final check; then `WM_CLOSE` to the Repair Order, as `CloseMobile` does for Next Order, and up to 8 s for the window to go. Never throws: a window still open, Stop, or anything unexpected becomes a CHECK BY HAND note ("close it by hand"); nothing COSTAR asks is answered. Nothing after it can turn the entered order into a stopped one (review.json written in a try).
- `EbayWorker.cs`: passes `AppSettings.ebayClose` (new, default on, also for settings saved before 2.5.2); report "entered and closed (it's in Work-in-Progress)"; last line "(closed)". `EbayTab.cs`: tick box **Close each Repair Order once it's in**, saved at once; hint updated.
- `LocalHttp.cs` `LocalServer.TryStart`: false (listener reset) while the address is in use. `DesktopUi.cs` `StartReceiver`: tries both listeners, then every second for up to 60 s while either port is taken ("Waiting for port N … (the old receiver may still be closing)", chip STARTING); then the error names the port and says to end the other TempeMobile.exe. A start failure shows NOT RECEIVING (it stayed green before).
- Self-test: the close setting is on by default, also when read from older settings, and stays off once unticked.

## Checks performed here

- Compiled at C# 5 against .NET Framework 4.6.2, 4.7.1, 4.7.2 and 4.8 reference assemblies: **0 errors**, the 3 known warnings.
- Self-tests: **112 of 116** + **16 of 16** (the same 4 Windows-only groups fail here). Node tests of the helper; extension 7 Node groups; end to end **20 checks** against this build's desk code.
- Install replayed with 2.5.1's Updater code; secret and customer-data scan clean.

## Not verified here

- The close in COSTAR (Windows only): that clicking PO# commits the last line (M DFE) before the close, and that COSTAR closes an eBay Repair Order without asking (TEST-PLAN 2.5.2). Next Order closes phone jobs the same way.
- The port wait on the desk PC (only seen after an update).

---

# Validation — v2.5.1 — 25 October 2026

## Basis

- Tommy, 25 Oct: the eBay orders go in "perfectly", but after closing and reopening a Repair Order the note lines (EBAY ITEM #, EBAY BUYER NAME, DET's notes, M C) are back to COSTAR's own text. By hand he types "A" after the words, leaves the line, comes back and deletes it, and then it is kept. His test the same day: words pasted in, then A and Backspace in one go, then leaving the line: kept.
- 25 Oct pairing: the desk's `Tempe-Mobile-Root.cer` was the root of a second Setup-Desk run (20261019) while its HTTPS certificate was signed by the first one (20261014), so the eBay PC trusted the wrong root (`net::ERR_CERT_AUTHORITY_INVALID`). Fixed by hand that day (the right root exported over the file).
- Tommy, 25 Oct: no GitHub key in updates.

## Changes

- `Runner.Grid.cs`: `WriteNote` = the words put in as before (WM_SETTEXT, read back, EM_SETMODIFY, no Tab), then `PressAtEnd`: the cursor to the end (EM_SETSEL) and confirmed there with nothing selected (EM_GETSEL, COSTAR in front, the line focused); VK A; wait until the line reads the words plus one letter; the cursor confirmed at the end again; Backspace; wait until it reads the words exactly; then Tab as before. `RoomForKey`: before the line is touched, EM_GETLIMITTEXT; a note that leaves no room for one more letter stops with the counts. Diagnostics `note_room` and `note_keyed` hold labels and counts only, never the words.
- Every note write uses it: `Memo` (DET's notes, `M C`, `M PC`, phone note steps), eBay `NoteText` (`M E`, `M BUY`) and the phone job's Additional notes. A note that already shows our words is confirmed again: in `Memo` unless it is COSTAR's bare "NAME:" (empty value), in `NoteText` on a resumed line, and in a resumed phone job (below).
- `LocalHttp.cs` `TrustRoot.Of`: builds the chain of the desk's HTTPS certificate (no revocation check, unknown root allowed) and returns its self-signed top as a public-only certificate, or nothing (no issuer found, or a signature that doesn't verify). `DesktopUi.cs`: `/trust.cer` and the phone pairing page use it, looked up once; `Tempe-Mobile-Root.cer` only when it finds nothing.
- New self-tests: two made-up roots and a certificate signed by the first (fixed bytes): without the first, nothing; with it, the first (public only). A phone note stopped during its key press is recognised; nothing else is.
- Release: the `Tests` folder is no longer in the ZIP (its only token-like text is a made-up placeholder in a sharing test; nothing on the PCs uses the folder).

## Checks performed here

- **Independent review** (a separate agent, code reading plus its own compiles and probe tests): nothing that breaks every order; message packing, the limit logic and the focus checks correct. Findings, all addressed:
  - a Stop (Ctrl+Alt+F10) or a held modifier around the A could leave the letter in the note, or send the key to another window after an Alt+Tab: each key now goes only after the modifiers are released, then COSTAR in front, the run not stopped and the line focused are checked just before it (`KeyInto`, `Native.KeyNow` never waits); from the A until it is taken back a Stop waits (`keyInFlight` in `Check`); any failure after the A says an extra letter may be at the end;
  - phone jobs: a resumed note step that already showed its words was accepted without the key press, and words plus the key's letter were refused as "partly applied": both are now written and confirmed again (`MobileProof.AfterWithKeyLetter`, new self-test);
  - a note longer than COSTAR's line would have stopped orders that 2.5.0 finished: it now goes in as before with a CHECK BY HAND note (eBay) or log line;
  - the new self-test used `CertificateRequest`, which needs .NET 4.7.2: it now uses fixed made-up certificates (public parts only, unique names), the missing-root case first; the build compiles against 4.6.2, 4.7.1, 4.7.2 and 4.8 again;
  - the note text is read with retries, COSTAR is waited for before each key, and each key has 8 s, as Tab does;
  - TEST-PLAN: ODOMETER on a phone job, and the stop check on all three kinds of order.
- **Review round 2** (the same agent, the fix round only, with its own compiles and harness run): every finding fixed; nothing new above low. The low ones, also done:
  - a note COSTAR may not keep was only a log line on phone jobs and online orders: it is now in the runner's CHECK list, added to the phone job's READY FOR REVIEW message on the desk, to the online "Finished … (check by hand)" line, and repeated at the end of the run log;
  - the extra-letter hint could appear when no key had gone: a modifier is now checked before the key counts as in flight, and a modifier that goes down while COSTAR is checked is waited for again (3 tries) instead of stopping with the letter in;
  - an unanswered line-length question is asked once more after COSTAR is idle.
- Compiled at C# 5 against .NET Framework 4.6.2, 4.7.1, 4.7.2 and 4.8 reference assemblies (both reference sets each): **0 errors**, the 3 known warnings.
- Self-tests: **111 of 115** + **16 of 16** (the same 4 Windows-only groups fail here), after each round. Probe: the certificate lookup never returns a root with the same name but another key, even next to the right one.
- Node tests of the helper (check-package, job card 43, startup 9, Order Check). Extension 1.4.2 unchanged: 7 Node groups and the end-to-end run against this build's desk code: **20 checks**.

## Not verified here

- The key press in COSTAR itself (Windows only): the first eBay and online orders, closed and reopened (TEST-PLAN 2.5.1).
- COSTAR's note-line limit (logged as `note_room`).

---

# Validation — v2.5.0 — 23 October 2026

## Basis

- Tommy, 23 Oct 15:20: his friend enters the eBay orders by copying them one value at a time from the "404 But It's Found" extension; Tommy wants one click on the eBay PC to send the order to his PC and the helper to type it into COSTAR. His rules: Sydney branch (Branch 1); the comment always stops at `EBAY DFE`; `M DFE` only (the consignment number is someone else's job); Rebill to `EBAY` (COSTAR then fills EBAY PAYMENTS, "PLEASE USE ORDER NUMBER AS CARD#" and Terms 7INV); Written By and Salesperson `SA`; entered straight away; the eBay sale price on the tyre line. Example RO 07497644 and the extension's copy-all output.
- The friend's PC is in the shop on the same network, so the desk receiver (HTTPS 8790) is the path, with its own eBay key.

## Changes

- **Desk receiver:** `EbayQueue` (`ebay.dat`, DPAPI): one receipt per eBay order number, content hash without the send time, replace-before-pickup, 409 after, leases, reports applied once per sequence, Retry / Start again / Mark done / Remove, prune past 300. API `/api/ebay/v1` (pair, health, orders, status, retry) with its own key; the extension's origin (`chrome-extension://` + 32 letters) is allowed on the eBay routes only. PIN pairing (6 digits, 10 minutes, 5 tries, one use). Worker route `/api/worker/v1/ebay` (held poll, ack). New tab **eBay orders** and an EBAY chip. An unreadable `ebay.dat` is set aside and the desk starts with an empty eBay list.
- **RDP helper:** `EbayEngine` (journal `ebay-journal.dat`: attempts, orders entered, report with sequence): finds the one Branch 1 COSTAR, waits for 10 s without input and for any online or mobile entry, takes the coordinator lease for that target, refuses an order it already entered unless the desk says **Start again**. `Runner.RunEbay`: header, Ship to, Rebill to (MSAA page tab; Ctrl+Tab only inside a SysTabControl32), Written By / Salesperson SA, spaced lines (items, F, M E per item, M BUY, M DFE), notes written and read back, final check. Layout surprises that are safe to leave become "CHECK BY HAND" notes. New tab **eBay** with **Check Sydney layout (types nothing)**. Online auto-fill that was blocked by an eBay entry starts by itself afterwards. Time saved counts eBay orders.
- **Website/** refreshed from the live repo (Order Check 1.6.4); this release changes nothing in it.
- **Extension 1.4** (not in the helper ZIP): `costar_send.js` (order builder and status words), `background.js` (pairing, send, status, retry; eBay pages may only ask for those), the panel's Send row, the popup's pairing section.

## Checks performed here

- Compiled at C# 5 against .NET Framework 4.8 reference assemblies (both reference sets): **0 errors**, the 3 known warnings.
- Self-tests: **109 of 113** + **16 of 16** (the same 4 Windows-only groups as 2.4.2 fail here). 17 new eBay groups.
- Node tests: check-package, job card (43), startup (9), Order Check (C# 5 scan, Discord 8, order rules 12, Firebase share, GitHub share).
- Extension: 7 Node groups; end to end **20 checks**: the real extension in Chromium against the real desk receiver code from this build over TLS on 127.0.0.1, with the RDP helper played over the worker API (pairing, wrong PIN, send, wait reason, claim, buyer/address/item/freight/total as on the page, progress, CHECK note, reopened page, two items, Send again = Retry, missing SKU, a discount line, origins). Made-up buyers and order numbers only.
- **Independent review, round 1** (a separate agent, code reading): 4 high, 8 medium, 5 lower, 2 security and 2 extension findings, all addressed:
  - a partly typed order removed and sent again is never entered in a new RO (the desk keeps `typed`; the helper refuses `fresh` for a typed attempt and "typed" orders it has no record of; only Start again passes, and it retires the `entered` record);
  - a retry continues in its own unchanged RO when the stop came before PO# (same-customer start); a new RO only replaces an earlier EMPTY one;
  - the helper says which order it is entering (`working`): an order it no longer enters is set to stopped, never left "being entered"; the attempt is recorded before the desk hears of it; `entered` and the ready report are one write; a claim it can't start is declined back into line with the reason;
  - the quiet moment and the other tabs are checked again when an order arrives;
  - stops while Rebill to shows keep the print from just before it; a retry clicks Ship to first; a tab that won't open must leave Ship to showing; no COSTAR window is handled on its own before the customer step;
  - email check only when the eBay order has one; locked or unkept Written By / Salesperson / Rebill boxes become CHECK BY HAND notes; Written By and Salesperson are part of the retry comparison; Rebill to and Card# in the RO it stopped in are never overwritten;
  - an online order loaded for a manual Fill no longer holds eBay orders up; auto-fill only while its tab shows;
  - details are fixed once the helper has had an order; worker words are cleaned on both sides, never refused; the 401 from an older desk is explained; extra COSTAR lines are named in the stop;
  - one normalised path for the origin rule, the key and the route; the desk's own pages can't use the eBay routes;
  - the extension refuses any payment line other than subtotal and postage (discount, fee, tax) and checks subtotal + postage = total; Chrome's Local Network Access: extension pages and workers are not blocked (checked against a 13 Oct 2026 report on Chrome 155); the "can't reach" message now mentions Chrome's local-network question.
- **Independent review, round 2** (a new agent, the fix round only; it compiled and ran the self-tests and probe tests of its own): every round-1 finding fixed or fixed in the safe direction; no new way for a normal first order to fail. New findings, all addressed:
  - a late, older poll could mark an order being typed as stopped (then Start again could enter it twice): the helper now says `working` from the moment it takes an order, and sends its report counter (`sequence`); the desk only stops orders whose last report is not newer than that, and counts them as possibly typed;
  - refusals now report typed when the helper knows it was; a claim handed back again after an early stop is never started twice (`lastStartedLease`);
  - unconfirmed claims come back to a switched-off helper, which hands them back (never stuck); details stay changeable until the helper's first report; "Waiting:" said once;
  - an attempt records `touched` just before its first write: a close before that keeps the earlier stop print and doesn't count as typed; a retry switches back to Ship to from any tab;
  - an online line that won't start by itself (an order loaded) no longer holds eBay orders;
  - the extension: subtotal + postage = total decides (a heading or note line can't block every order; label variants like "Items subtotal", "Postage & packaging"); without a subtotal, any other money line or an unreadable amount stops the send, and so do discount words on the page.
- Re-run after round 2: C# 5 compile 0 errors (both reference sets); self-tests **109 of 113** + **16 of 16**; extension 7 Node groups; end to end **20 checks**; Node tests of the helper pass.
- Install replayed with 2.4.2's Updater code; secret and customer-data scan clean.

## Not verified here

- Anything typed into COSTAR Sydney: the Rebill to tab and its boxes, the Written By / Salesperson boxes, COSTAR's default texts for M E / M BUY / M DFE, Branch 1's new Repair Order. First run: **Check Sydney layout (types nothing)** on a new, empty Sydney RO, then one real order watched from start to finish.
- Pairing on the real eBay PC (certificate install, the desk's LAN address) and the eBay pages with several items.

---

# Validation — v2.4.2 — 19 October 2026

## Basis

- Tommy, 10:47: "the phone job card is still stuck on the last order". `jobcard-shared.js` refused `new` unless the submission was `ready_for_review`; the desk's queue had been reset by hand the night before, so the phone's `getJob` got 404, the page showed "The PC no longer reports this submission", Retry failed, and New job stayed disabled. The 2.4.0 desk's `removed` status would also have been rejected as "unsupported job status".

## Changes (Website only, plus the version)

- `jobcard-shared.js`: `STATUSES` + `removed`; `settled(sub)` (ready_for_review, removed, failed or gone); operation `gone` (set when the PC answers unknown, never while awaiting ack); `new` allowed when settled; a `removed` card ignores later statuses like a reviewed one.
- `Fitment_Planner.js`: poll marks the card gone instead of only showing a message; status names; Retry hidden when gone; New job enabled when settled; the confirm text says a stopped order stays on the desk PC.
- `Fitment_Planner.html` and `Tests/test-startup.cjs`: script version tag `20261019-newjob`, so phones fetch the new scripts.
- `Tests/test-jobcard.cjs`: four new checks (failed → new; gone → new; removed settled and sticky; gone ignored before ack). 43 checks.

## Checks performed here

- Compiled at C# 5: 0 errors, 3 known warnings (the C# is unchanged apart from the version). Self-tests 92 of 96 + 16 of 16. Node tests pass.
- Install replayed with 2.4.1's, 2.4.0's and 2.3.2's Updater code; secret and customer-data scan clean.

---

# Validation — v2.4.1 — 19 October 2026

## Basis

- Tommy's screenshot of both 2.4.0 windows (08:25): the desk said RDP HELPER OFFLINE while the helper was open with mobile off; the COSTAR list text was cut off; "No order loaded." sat under a finished order's details; the Online tab's hint line ran off the right edge; the desk's bottom hint was cut off by the window height.

## Changes

- `WorkerEngine.Connect()` starts the poll loop; `WorkerForm.Shown` calls it, `Start()` calls it too. With `Enabled=false` the hello carries `accepting=false`, `available=false` and `waitMs=0` (no hold), so the desk sees the helper in touch and `Accept` is never reached (it also re-checks `Enabled` under the gate). Reports in the journal reach the desk on the first poll.
- `AppLog.PollError`: every 100th failure after the first.
- COSTAR list: `Format` event shows `Label · PID` when closed; the drop-down shows `ToString()`.
- Online tab: `lastFinished` line, grey preview after an order; widths 770.
- Desk: `Size` 860×900, `MinimumSize` 840×760; website row on one line; shorter hint.
- Wording: "Desk PC connected / not reachable", "Mobile off on the RDP helper (jobs wait in the queue)".

## Checks performed here

- Compiled at C# 5 against .NET 4.8: **0 errors**, 3 known warnings. Self-tests: **92 of 96** + **16 of 16** (the 4 Windows-only groups as before). Node tests pass.
- Install replayed with 2.4.0's and 2.3.2's Updater code; secret and customer-data scan clean.

## Not verified here

- The windows themselves (second look is Tommy's).

---

# Validation — v2.4.0 — 19 October 2026

## Basis

- Tommy, 19 Oct 00:45: full permission to rebuild; "recheck everything, more efficient, modern UI/UX, better file management, faster connection, faster process". And the live problem that night: mobile job MJC-…9366 failed on every Retry with "This mobile job belongs to another COSTAR instance", and the queue had no way out short of renaming `journal.dat` / `queue.dat`.
- Code reading of every file (Worker, MobileModel, LocalHttp, DesktopUi, Updater, Diagnostics, ResourceBudget, Program, the Runner, OrderModel, MobileRunner) for stuck states, fixed waits and UI-thread work. Four parallel audit agents were started as well; they were cut off by an interruption, so the findings here are from the direct reading plus the review rounds below.

## What stays

The entry engine (snapshots, the busy gate, lines by count, identity before typing, customer lookup, account list, all-branch search, resume rules, final checks) is 2.3.2's, moved file by file and unchanged in behaviour apart from the stage hook (`Runner.OnStage`).

## Changes

- **Stuck states** (`Worker.cs`, `MobileModel.cs`, `DesktopUi.cs`):
  - `WorkerJournal.releasedByHand`. `WorkerEngine.Release()` sets it and reports `ready_for_review` ("Released: finished by hand …"); the later `close` command reports `closed` without touching COSTAR. Any desk version accepts this sequence (checked against `JobQueue.Poll`: the report is applied by sequence, Next Order asks for close, the close ack closes the receipt).
  - `WorkerEngine.StartAgain()`: backup of the journal, fresh checkpoint (`MobileRecovery.FreshCheckpoint` now accepts any consistent failed job; `CanReset` still means "unstarted"). Retry on the desk then opens a new Repair Order. Replaces `ResetUnstarted`.
  - `Run()`: the instance check names the two buttons; when the pinned COSTAR process is gone, mobile is switched off so the same failure doesn't repeat on every Retry.
  - Desk: `JobQueue.MarkDone(id)` (ready_for_review + closed, current slot cleared) and `Remove(id)` (waiting or failed only; status `removed`, hidden). `Poll` answers a report about an unknown or closed job with command `forget`; the 2.4.0 worker backs up and clears its journal on `forget`. A 2.3.x worker ignores the command (it keeps polling, as before).
- **Connection** (`LocalHttp.cs`, `Worker.cs`, `MobileModel.cs`): `WorkerHello.waitMs`, `WorkerReply.held/waitedMs`. The desk holds a `wait` answer for up to min(waitMs, 20 s) on a monitor pulsed by `JobQueue.Changed` (after every saved change) and `ReceiverApi.Wake()`, then asks the queue again without the report. The worker sends waitMs 8000 while accepting jobs and not busy (setting `longPoll`, default on), with request timeouts of 8 s + waitMs, keeps the request in `pending`, and interrupts it (`Abort`) on a new report, Stop or Start; a held reply is followed by the next poll at once, otherwise the 2 s / 3 s rhythm stays. `Connected` now means "in touch within 15 s"; `Accepting` is separate; `/health` adds `workerAccepting`; a phone's job is accepted while the helper is in touch even if mobile entry is off there.
- **Progress** (`CostarSession.cs`): `EntryProgress` on the coordinator (Begin/Stage/End, copies on Read; End without Begin is ignored). The Runner calls `OnStage` from `Timed` and the two `BeginStage` points with a planned count; the online thread and the mobile run call Begin/End.
- **UI** (`DesktopUi.cs`, `OnlineTab.cs`, `Ui.cs`): header card with chip, headline, sub line, progress bar, last result, update line; Mobile tab card and four buttons; Online tab card/actions/log; Files & settings tab (`FolderStats`, `Cleanup`, `AppSettings`, export of the diagnostics ZIP to the Desktop); coloured `RichTextBox` logs (`LogLines.Kind` decides the colour; testable without System.Drawing). Desk receiver: chips, `ListView`, grouped buttons, Mark done / Remove, update check and install (`Updater.LaunchMode="Desk"` → `Start-Desk.cmd`).
- **Files** (`AppData.cs`): `AppData.Reports/Diagnostics` move the old folders once; `Runner.ReportsRoot` and `RunDiagnostics.Root` point there. `Cleanup.Packages` keeps current + running + newest other; `Cleanup.Runtimes` keeps the running build + 2; `Cleanup.Logs` keeps 20 startup logs and diagnostics ZIPs ≤ 30 days. `AppSettings` (settings.json) replaces the flag files `det-last`, `order-check-on`, `preferred-branch.txt` and keeps them in step for older packages.
- **Clipboard:** the Online tab's timer runs at 250 ms while idle (1 s while busy).
- **Split:** `CostarAutofill.cs` → `Native.cs`, `Runner.cs`, `Runner.Customer.cs`, `Runner.Grid.cs`, `Runner.Online.cs`, `OnlineTab.cs`, `OnlineModelTests.cs` (no code change beyond the move and `OnlineModelTests.SelfTest`). Build.ps1 lists 22 files; `Tests/check-package.cjs` now checks that list against `Source\*.cs`.
- **END OF DAY:** counts of released / started-again / marked-done / removed jobs.
- **Self-tests:** 96 groups (new: desk exits + forget; released job close; held poll; progress; cleanup plan + folder stats; settings round trip + log colours; the recovery test now expects started jobs to be startable again).

## Checks performed here

- Compiled with Roslyn at C# 5 against .NET 4.8 reference assemblies (Build.ps1's list and references): **0 errors**, the usual 3 warnings.
- Self-tests under .NET 8: **92 of 96** plus **16 of 16**; the 4 Windows-only groups fail here as before. The held-poll test exercises the real `ReceiverApi.Handle` with a background submit; the desk-exits test covers stranded `injecting` jobs with a reachable and an unreachable helper.
- Node tests: package (now with the file-list check), job card, startup, Order Check rules and C# 5 scan.
- Two reviewers on the full diff, each with a follow-up round:
  - Protocol/worker reviewer. Blocking (fixed): `forget` while a run was busy nulled the journal under the typing thread (`Forget` now returns while busy; the desk refuses Mark done on a job a reachable helper is typing). Should-fixes (all fixed): Release/StartAgain stopped a live run; a released job's close still needed the original COSTAR; the hold ignored `available`; two lost-wakeup/zombie-request windows in the held poll; the interrupt didn't wake the sleep; a 2.3.x helper facing a 2.4.0 desk's Mark done keeps reporting (now a hint on the desk).
  - UI/files/split reviewer. Blocking (fixed): the root TableLayoutPanel had no column style, so the header clipped the tab control. Should-fixes (all fixed): a refused online start ended a running mobile job's header state; the read-only RichTextBox refused its trim; the held-poll race; Save worker report had vanished; the home folder row counted subfolders; `AppData.Locate` unsynchronised; cleanup planning on the UI thread.
  - Follow-up findings, done after the rounds: Mark done / Remove allowed for a job the helper never picked up or an unreachable helper holds (`MarkDone(id, workerReachable)`, `Remove(id, workerReachable)`; tested); the forget hint resets once the helper stops reporting the job; the hold is skipped when the queue changed during the poll itself; buttons grow with their captions for 120/125 % DPI and the COSTAR list drops down wide; "No" to Clean up resets the note and a closed form gets no stray box; the two "window is closed" messages name the new buttons; the phone page says "mobile entry off, your card will wait" instead of "RDP worker online" when the helper is in touch but not taking jobs.
- Package, manifest, latest.json; install replayed with **2.3.2's own Updater code**; secret scan.

## Not verified here

- **The window itself.** No Windows here, so the new layout has not been seen. It uses TableLayoutPanel/FlowLayoutPanel with AutoSize everywhere, so it should hold together; the first start on the PC is its first look.
- Live COSTAR entry is unchanged in code; the stage hook only reports.
- The long poll against the real desk receiver over the shop LAN (tested here in-process).

---

# Validation — v2.3.2 — 10 October 2026

## Basis

- Tommy's diagnostics, 10 Oct 19:50, and the entry report of TTW1730569 (2.3.1). It was used here for the grid geometry only; no customer value was printed or kept.
  - DET went on line 6 with its notes on lines 7–9 (structural check passed), and 0358091 ×2 went on line 1.
  - Item 0358092: `grid_shape` "items above DET: steady, but lines 1-6 are not on their places". Boxes at 0, 159, 178 … px: line 1 at its place, lines 2–25 140 px lower. Focus was in line 1's 42×20 cell at x=834.
  - Then the fallback chose the first empty line after everything: line 10, drawn 140 px low. The click moved focus there, line 1 closed, line 10 moved back up, and `RequireLineStill` stopped: "moved before typing".
  - Earlier in the same run, "DET notes" had the same shape. The MAKE/MODEL editor (806×160 at 225,483) was focused, and lines 8–25 were 140 px lower.
- Control dumps (before and at the stop):
  - 25 ITEM boxes, one panel per line under the grid container. Line 1 is at y=369, 1 px under the ITEM label (341+27).
  - When DET's notes appear, the bottom panel (line 25's) moves to line 7 and lines 7–24 move down one. DET and lines 1–5 keep their boxes.
  - A focused empty line stays 20 px tall; focused filled lines and notes open to 160 px.
- 2.3.0's stop (9 Oct) is the same mechanism, seen through `EvenLines`.

## Changes

- **Grid** (`OrderModel.cs`):
  - `Countable()`: exactly 25 boxes (`CostarLines`), the first within 6 px of 1 px under the ITEM label.
  - `LinesTo(handle)`: the handles from line 1 down to that box.
  - `NextFreeAbove(index)`: the box after the last filled box above `index`, or -1.
  - `Lattice`, `LinesAt` and `OnLattice` are removed.
- **Choosing lines** (`CostarAutofill.cs`):
  - `SteadyGrid(why, wantCounted, …)`: two identical looks, as before. It waits up to 1.5 s for a countable look only when one is wanted. The learnt lattice is gone.
  - `LineRow(line)` needs a countable look and takes `Rows[line-1]`.
  - `NextEmptyRow` is the first empty box after the last filled one (2.2.1's rule).
  - `ItemRowAbove(detLine | -1)`: DET is found by its text, and must be at `detLine-1` when the look is countable. The item goes on `NextFreeAbove(DET)`. It falls back to after everything when nothing is free above DET or an item of this order is already below it (`items_after_det`).
  - Each of these returns the chosen box plus its `LinesTo` path.
- **Before typing**, `RequireLineStill(row, path)` takes a fresh steady look and checks:
  - the same `LinesTo` path;
  - the box is still empty;
  - focus is still on the box. If not, the box is clicked once more (`line_focus_retry`) and checked again; otherwise entry stops.
  - Positions are no longer compared.
- **DET first / DET last:**
  - `Runner.DetFirst` comes from the new Online tab check box "DET first (items above DET)". It is ticked by default; `%LOCALAPPDATA%\TempeMobileCostar\det-last` exists while it is unticked. The value is captured on the UI thread for each fill and logged in `online_fill_start` ("det-first" / "det-last").
  - DET first: `DetFirstLine` checks the grid is countable and that DET's line and every line below it are empty. Then DET goes on that line, followed by `DetNotes(line)`, then the items above DET.
  - Otherwise (`det_last` event with the reason, or the box unticked): the items go to the first empty line after everything, then DET there, then `DetNotes(0)`. This is 2.2.1's order.
  - Resume with DET already entered: leave the grid, wait for the notes, read DET's line, `DetNotes`. Missing items go above DET only with DET first on.
  - `DetNotes`: template, `RequireNotesUnderDet` (structural, plus DET's line when countable), MAKE/MODEL, REGO NO, ODOMETER, PAYING BY.
- **Final check:** the DET block moved to `Selectors.CheckDetBlock(s, vehicle, rego, payment)`, with the same rules. Exactly one DET; its three notes are the next three filled rows; PAYING BY is fourth when set.
- **Mobile:** numbered lines use the same `LineRow` and `RequireLineStill`. The plan is unchanged.
- **END OF DAY:** unusual grid shapes, orders with items after DET's notes, `det_last` pickups, fills with DET first off, and `line_focus_retry` counts.
- **Self-tests:**
  - Replaced the two lattice groups with line numbers by count, and a line as the Nth box (open line, moved box, stray/missing/scrolled box).
  - Added: next line above DET; the 10 Oct grid with the tyre's line open (`ProductGrid`, `Countable`, `NextFreeAbove`, `LinesTo`, cells of the open line); the final DET check for DET first, DET last and items after the notes (positive and negative); end-of-day lines.
  - Total 90.

## Checks performed here

- Compiled with Roslyn at C# 5 against .NET 4.8 reference assemblies, with Build.ps1's reference set and with csc.rsp's: **0 errors**, the usual 3 warnings.
- Self-tests under .NET 8: **86 of 90** plus **16 of 16**. The 4 Windows-only groups fail here as before.
- Replay on the real 10 Oct dumps (local only):
  - The new and stopped Repair Orders are countable.
  - DET is line 6; the notes are on lines 7–9; the next item is line 2 (the same box as line 2 on the new order).
  - With line 1 open (lines 2–25 +140 px) and with line 7 open, the grid is still countable and line 2 is chosen. Its `LinesTo` is unchanged once the open line closes, and the open line's 806×160 description cell is found.
  - The box that was line 8 before DET's notes fails `LinesTo` afterwards; line 3's passes.
  - `CheckDetBlock` passes on the stopped order.
- A separate review of the diff and full sources found nothing blocking. Its should-fix (tests for the final DET check on every layout) and nits are done: the focus re-check, the first-box tolerance, wording, and the test data.
- A second review round on those fixes also found nothing blocking. The `RequireLineStill` loop always ends, a moved box is followed rather than missed, and `CheckDetBlock` behaves the same as the old inline check for every layout `Run()` can produce.
- Node tests (package, job card, startup, Order Check rules/sharing, C# 5 scan of OrderCheck.cs) pass. The page is unchanged.
- The real Windows compiler (`csc /langversion:5`) remains the final check on the PC. If it refuses the build, `Launch.ps1` sets 2.3.2 aside and starts 2.3.1.
- Package, manifest and latest.json. The install was replayed with **2.3.1's own Updater code** (the version on the PC).

## Not verified here

- Live COSTAR: a DET-first pickup with two or more items, and the "DET first" check box on the PC.

---

# Validation — v2.3.1 — 9 October 2026

## Basis

- Tommy's diagnostics, 13:45. 2.3.0 built and passed its self-tests on the RDP PC.
- The one 2.3.0 order, TTW1730549 (store Parramatta NSW, confirmed into Branch 11):
  - DET went to line 6 with its notes on 7–9; tyre S1028 went to line 1 with its quantity;
  - then "Item M FB" stopped: `EvenLines` was false on the very next look, 6 ms later.
- Its retry at 13:15:55 was refused. Order Check (read at 13:15) listed TTW1730549 as document 7856262: the helper's own open, stopped Repair Order.
- Earlier runs logged "grid_read_plan_reset: header labels changed" during product item stages (5 runs): COSTAR re-lays its grid out while it loads a product.
- A separate review of the change (three rounds) found a 2.3.0 bug: `Runner.Check()` still required `RepairOrder Branch 11`, so any other branch would stop at the first check.

## Changes

- **Branch:** `Runner.Check()` uses `Branches.OrderTitle(caption, branch)`.
- **Grid** (`OrderModel.cs`): `Lattice` (median pitch and start), `LinesAt(start, pitch, lines, slack)`, `OnLattice`.
- **Looking at the grid** (`CostarAutofill.cs`):
  - `SteadyGrid(why, lines, out snapshot, out numbered)`: two identical consecutive looks (ITEM label y; every box's handle, y and text). It gives up after at least 4 looks and 2.5 s, or 10 s.
  - `Numbered`: lines 1..N each within 3 px of the lattice learnt on the run's first steady, evenly spaced grid, stored relative to the ITEM label; no fewer boxes than learnt.
  - `NoteGridShape`: event `grid_shape` (offsets, sizes, classes, filled, focus; no values), up to 2 normal and 2 problem shapes per run.
  - `LineRow` (lines 1..max(line, last filled) countable), `ItemRowAbove`, `RequireNotesUnderDet` (structural: the three notes are the next three filled rows after DET, plus line checks when countable), `SteadyLook` for every "first empty line after everything".
  - `AddCode`: `Focus`, then `RequireLineStill` (live position relative to the Repair Order within 3 px, live text empty), then `WriteFocused`.
- **Fallback:** if the lines stay out of place (or DET's line is unknown on a resume, or an item is already below DET), the remaining items go after everything (`items_after_det`). DET missing, doubled or moved stops entry.
- **Verify:** the three DET notes must be exactly the three filled rows after DET, with PAYING BY (when set) the fourth.
- **Resume:**
  - `Selectors.OrderPrint(s, delivery)`: every header field, Time in, Ship Via, the delivery panel, products as code x qty @ net, note lines as text. COSTAR's own DET/M FB texts and blank DET notes are left out.
  - `SettledPrint`: two equal prints from fully read looks, at least 3 tries, up to 15 s. It is taken when a run that typed something (or a verified resume) stops, and stored with `stoppedIn`.
  - On retry, the helper's own stopped Repair Order (`OwnAttempt`) must give the same print before anything is typed; otherwise it refuses. A Repair Order that already holds the order (PO# and phone) but isn't that attempt is refused.
  - For an order Order Check lists, the only candidate is that own Repair Order (`MustResume`); otherwise the 2.3.0 refusal stands.
  - The resume leaves the grid (PO#) and waits for DET's notes before reading DET's line.
- **END OF DAY:** lines out of step, items after notes, and listed-order retries appear under THINGS TO LOOK AT.
- Self-test groups 86 (lines by place) and 87 (stopped-order print).

## Checks performed here

- Compiled with Roslyn at C# 5 against .NET 4.8 reference assemblies, with Build.ps1's reference set and with csc.rsp's: **0 errors**, the usual 3 warnings.
- Self-tests under .NET 8: **83 of 87** plus **16 of 16**. The 4 Windows-only groups fail here as before.
- Three review rounds by a separate agent on the diff and full sources. The last round had no blocking findings.
- Node tests. The page is unchanged.
- Package, manifest and latest.json. The install was replayed with **2.3.0's own Updater code** (the version on the PC).

## Not verified here

- Live COSTAR: how quickly the grid holds still after a product (`grid_shape` will show it), and a real resume.

---

# Validation — v2.3.0 — 9 October 2026

## Basis

- Tommy (9 Oct): COSTAR loses DET's notes on close when DET is entered last. Enter DET first on line 6, items above. Also: work with any COSTAR branch open on the PC (Branch 1 orders).
- Real captures (2 Oct, empty and filled Repair Orders): 25 item boxes, all enabled, 19 px apart, line labels 1–25 alongside, so box N is line N.
- Day logs 3–5 Oct: only "COSTAR:  11 Tempe Tyres Tempe" was ever seen, so the branch parser is written for the known format and tested on invented titles for other branches.

## Changes

- **Branches** (`CostarSession.cs`): `Branches.OfMain` / `NameOfMain` / `OfOrder` / `MainTitle(title,branch)` / `OrderTitle(title,branch)` / `OrLegacy` / `Place` / `StoreMatches`.
  - `CostarInstance` carries Branch, BranchName and Label; `Same` includes the branch.
  - Every former `Branch11` check compares with the selected or recorded branch: detection, Main, OnlineOrder, OpenNew, ValidateTarget, the Runner constructor, and online window reuse/resume.
  - `MobileCheckpoint.branch` (0 = legacy Branch 11). `Runner(pid, branch, …)`; diagnostics Env "branch".
  - `Selectors.Blank/BlankDelivery(s, branch)`: Branch 11 keeps TEMPE/NSW; other branches accept their own default suburb and a valid AU state.
  - Worker window: branch labels, a remembered branch (`preferred-branch.txt`), mobile paused when the branch changes while mobile is enabled, and the yellow bold update line.
- **Store check** (`AutofillForm.CheckStoreBranch`): pickup store vs branch place (strict). On a mismatch, a Yes/No dialog names any matching open COSTAR; the answer is remembered per store and branch for the session. Logged as `online_branch_question` / `online_branch_confirmed` / `online_branch_refused`.
  - While the dialog is open (`askingBranch`), the clipboard timer and `StartEntry` do nothing: a WinForms timer still ticks under a message box, and before this guard a newly copied order could replace the one being asked about. The order is captured before asking and must still be the one on screen afterwards. A minimised helper window is restored and activated first.
- **Website** (`OnlineOrders/Tempe-Orders-COSTAR.html` = GitHub testrun.html, and `transfer-core.js`, identical rules):
  - pickups from any store; `store` sent; schema 3 for non-Tempe pickups (refused by helpers before 2.3.0), schema 1 for Tempe;
  - Store picker (localStorage), store-aware titles and list;
  - COSTAR check limited to Tempe.
  - The helper validates schema 3 and requires a store.
- **DET first:**
  - `Order.DetLine(itemLines)` = max(6, itemLines+2).
  - `Grid.EvenLines` / `LineOf`; `Runner.LineRow` (requires empty line and even spacing), `ItemRowAbove` (next free line above DET, or the old after-everything rule when none fits), `RequireNotesUnderDet`.
  - `AddCode(…, line, above)`.
  - Online pickups: DET block (DET, template, notes check, MAKE/MODEL, REGO NO, ODOMETER, PAYING BY), then items above. Resume reuses an existing DET at its own line; if its notes are missing (stopped right after DET was typed), it leaves the grid once (`LeaveForDetNotes`, else `LeaveGrid`) so they appear. The final check requires exactly one DET.
  - Mobile plan v3: DET (line), notes, notes row, then items on lines 1..n. `MobileRow.line` comes from the snapshot. `After` checks the planned line for add/det steps (DET block consecutive from its line); line-0 steps keep the old rules. `PrepareCheckpoint` moves unstarted older-plan jobs to v3 and refuses started ones (as before).
- **Launch.ps1:** if the build or self-tests fail in the package `current.txt` points to, the pointer is renamed `current.txt.failed` first. Then it points at the newest earlier installed package (`packages\Tempe-COSTAR-Helper-v*` with a lower `VERSION.txt` and a Launch.ps1), so old shortcuts hand over to it (2.2.1 on Tommy's PC). With none, there is no pointer and each shortcut starts its own folder. The message names the version that starts.
- **Self-tests 81–85:** branch titles and instances; store and suburb rules; DET placement and line-checked item proofs (positive and negative); grid lines and the DET line rule; old-plan checkpoints; schema 3.

## Checks performed here

- **Compiled with a real C# compiler** (new for this release): Roslyn from PowerShell 7.4.6 (GitHub release) at `LanguageVersion.CSharp5`, against .NET Framework 4.8 reference assemblies (`mono/reference-assemblies` on GitHub), with Build.ps1's reference list and again with the framework's full csc.rsp list: **0 errors**, the same 3 harmless warnings as 2.2.1. The known-good 2.2.1 compiles the same way, so the method agrees with the RDP PC's csc. (Against 4.5 references the X509 `using` blocks fail in both versions: the PC has .NET 4.6 or later.)
- **Self-tests run** under .NET 8 (compiled as above; a stand-in for `JavaScriptSerializer`; `AutofillForm.SelfTest` moved out of the Form class in the scratch copy only): **81 of 85** helper groups and **16 of 16** Order Check groups pass. The 4 that fail need Windows (process identity, a WinForms TextBox, folder ACLs, user32) and fail identically for 2.2.1 (76 of 80 there).
- **Launcher fallback**, 6 scenarios with PowerShell: a failed update points back to 2.2.1 ("starts version 2.2.1 again") and an old 2.2.0 shortcut then hands over to 2.2.1; with only 2.3.0 installed the pointer is set aside; a failing folder that isn't the pointer target leaves it alone; a passing update changes nothing and old shortcuts hand over to it.
- **Page:** the inline script parses and runs against a fake DOM (Store picker rendered with Tempe NSW, a choice is remembered and the list reloads). `transfer-core.js` is embedded verbatim; Tempe → schema 1, other stores → schema 3 with the store named.
- Static checks (balance, C# 6+ syntax, shadowing, `using`s, one entry point) and a line-by-line diff review against 2.2.1.
- Node: package, job card, startup, Order Check rules/sharing/C# 5 (7 tests).
- ZIP, manifest and latest.json; the install replayed with the helper's own `Updater.Validate`, `Extract` and `VerifyManifest` from the compiled code.

## Not verified here

- Live COSTAR behaviour: typing on line 6 with empty lines above, the notes appearing under DET, and other branches' window titles (parsed from the known format).
- On the PC only: the 4 Windows-only self-test groups and the WinForms screens (the branch question, the yellow update line). A failed build or self-test sets the update aside automatically.

---

# Validation — v2.2.1 — 7 October 2026

## Basis

- **Tommy's screenshot (2.2.0):** Order Check reading normally (98 jobs, PO column found, WIP COSTAR PID 227392).
- **The saved Tempe Orders page:** "COSTAR check unavailable … Order Check has not read COSTAR yet (setup)".
- So a different Order Check answered on 127.0.0.1:8795. `HttpServer.Start` failed silently: `SetState("error")` was overwritten by the next successful read. Loopback ports are machine-wide on the shared RDP server, while Order Check's mutex is session-local (`Local\TempeOrderCheck_v1`).

## Changes

- `HttpServer` tries 8795–8804 (ExclusiveAddressUse) and keeps `Port`. `Route` checks the Host header against the served port.
- `Problem` names the occupant of 8795 (its `/health`: version, state, user, session) and stays in the status text permanently.
- `/health` adds port, state, session and user.
- **Open board** appends `?reader=http://127.0.0.1:<port>` when not 8795 (the board already supports `?reader`).
- **Tempe Orders page** (`testrun.html`):
  - `findOrderChecks()` probes ports 8795–8804 (`/health`, then `/wip.json`) and uses the most recently read Order Check in state "ok";
  - merges `/entered.json` from all;
  - lists idle copies as a note, and gives a clear error when only an unready copy answers.
- Order Check self-test group 16 (`PortTest`): a busy port → the next port is served, the busy port is reported, own Host is accepted, the other port's Host gets 403.

## Checks performed here

- 14 C# files clean (balance, C# 6+ syntax, shadowing; one entry point). Order Check C# 5 check.
- Node end-to-end: two fake Order Checks (old copy on 8795 in setup; healthy on 8796 with WIP and entered) → the page uses 8796, matches PO# / helper-entered / missing, and notes 8795. With only the old copy: a clear message.
- All package tests. ZIP, manifest and latest.json fingerprint verified.

---

# Validation — v2.2.0 — 6 October 2026

## Changes

- **Resume:**
  - `Selectors.SameOrderInProgress` (PO# = order number, same phone, comment empty or equal).
  - `Run()`: resume path skips the empty check and the phone lookup (account and name taken from the order), reuses item rows by code and occurrence (`ExistingRow`, `FinishLine`), and reuses DET/F rows (`FinishFreight`). Memos are idempotent as before.
  - AutofillForm remembers `stoppedIn[orderId] = window` when a run stops after typing (`Runner.Writes > 0`), retries there, and forgets on success. `Verify` still requires the exact item sequence.
- **Missing orders:**
  - `OnlineOrders/Tempe-Orders-COSTAR.html` (= GitHub `testrun.html`) gains the COSTAR check: `/wip.json` and `/entered.json` from 127.0.0.1:8795; matching by PO#, by the order number in the comment (digit-boundary safe), by helper-entered, or by amount ±max($1, 2%) as "probably".
  - **Make it** reuses Send to COSTAR; **Make all missing** spaces sends 3 s apart.
  - Order Check route `/entered.json` ← `Hosting.Entered` ← `EnteredOrders.Json()` (today and yesterday's `online_fill_ok` from the day log; order numbers and times only).
- **Auto-update:**
  - `Updater.cs`: HTTPS GET of `latest.json` only under `https://tommyvenzin.github.io/tempe/helper/` (TLS 1.2, no redirects).
  - Release validation: version, ZIP name matching the version, SHA-256 format, size 10 KB–50 MB.
  - Download size limit; ZIP SHA-256 must match; extraction with a zip-slip guard; every file checked against `PACKAGE-SHA256.json`; install to `packages\Tempe-COSTAR-Helper-vX`; `current.txt` pointer; restart through the matching Start-*.cmd after the helper closes.
  - `Launch.ps1` hands over to a newer version found via `current.txt` (`VERSION.txt` comparison; `-NoHandOver` prevents loops).
  - Worker window: checks at start and every 6 h, offers in the status line, refuses during entry.
- **Time saved:**
  - `TimeSaved` counts `online_fill_ok` / `mobile_job_ready` / stopped from the day logs.
  - Minutes in `time-saved.json` (default 4/4, written only when a report is made).
  - Status line (cached 1 min); Boss report HTML (today/7/30 days, day table, no order details); END OF DAY line.
- Self-tests 78–80: resume recognition (made-up customer), time-saved counting and report, updater validation, manifest tamper detection and the zip-slip guard.

## Checks performed here

- 14 C# files: balance, C# 6+ syntax and shadowing scans clean, one entry point.
- Argument-count check on all new methods (flags reviewed: all framework/LINQ/lambda false positives).
- Order Check C# 5 check. All Node tests, including the page's JavaScript syntax.
- Matching logic unit-tested in Node: PO#, comment, helper-entered, amount, missing, and digits inside a phone number not matching.
- ZIP, manifest and latest.json fingerprint verified.

## Not verified here

- Compilation and live COSTAR.
- PowerShell syntax of the Launch.ps1 hand-over (no PowerShell here; reviewed by hand).
- Chrome's private-network access from the GitHub page to 127.0.0.1 (Order Check's board already does the same).

---

# Validation — v2.1.0 — 6 October 2026

## Basis

Tommy's screen recording TEIK.mp4 (22 s, silent), frame by frame:
- the phone is entered in the Repair Order;
- the "Search…" window (Search for an Existing Customer) opens with "Nothing found!", the Phone box empty, Branch "11" and OK disabled;
- the phone is typed into Phone, Branch is cleared and Search is pressed;
- 3 accounts appear (other branches), row 1 highlighted and OK enabled;
- row 1 is taken, the account loads, and SHOP is typed into Ship Via.

## Changes

- **Selectors:**
  - `NothingFound` (a static "Nothing found!");
  - `FieldRightOf(label)` (a box to the right of its label, same vertical centre ±6);
  - `ShipVia` (the box under "Ship Via", same parent).
- **`TryChooseFirstAccount`:**
  - if OK is disabled (not a list box), `SearchAllBranches` runs: WM_SETTEXT Phone (digits of the phone typed for the lookup), WM_SETTEXT Branch "", BM_CLICK Search, then wait up to 15 s for OK enabled ("accounts found") or "Nothing found!" (after 800 ms, non-busy popup snapshot);
  - none found: BM_CLICK Cancel, `lookupCancelled`, and the new-customer path.
  - `sawChooser` is set only when an account is chosen.
- **`SetShipViaShop`:** if Account# is non-empty, PutMapped Ship Via "SHOP". Online pickups run it as stage "Ship Via SHOP" before the final check; mobile runs it after the final check (Ship Via is not part of the mobile proof) and it is non-fatal.
- `lookupPhone` is recorded where the phone is typed (online header, mobile phone step).
- **Fixed before release** (found by a new argument-count check): `Diag.Write()` had no matching overload, so `Diag.Write(0,0)`.
- Self-test 77: Search window boxes, Nothing found, chooser with a disabled OK, and Ship Via (geometry from the 5 Oct popup_layout).

## Checks performed here

- 13 C# files: balance, C# 6+ syntax and shadowing scans clean, one entry point.
- **New:** a method-existence and argument-count check for every helper call (all flags reviewed; the only real one is fixed).
- Order Check C# 5 check. All Node tests. ZIP and manifest verified.

## Not verified here

Compilation, and live COSTAR behaviour of the Search window's Search button and Ship Via.

---

# Validation — v2.0.3 — 5 October 2026

## Basis: end-of-day report 5 Oct 22:37–22:51 (2.0.2)

- 19 runs: 8 completed; 7 open-order checks (about 60 ms, "not empty"); 2 account-list stops; 1 modifier stop; 1 focus stop after a failed list.
- Memory 42–56 MB, CPU 0.0% average.
- **Account list:**
  - The popup was recognised (`account_chooser` accept=True, acceptEnabled=False).
  - `account_first_row_error` ArgumentException on the first panel, then "grid found but it has no rows": the smallest panels were tried first and the code returned at the first table without rows.

## Changes

- `Msaa`:
  - `Children` (AccessibleChildren, falling back to get_accChild; handles simple int child IDs), `RoleOf`, `LocationOf`, `SelectChild`;
  - `FindTable(root, depth)`, exception-tolerant;
  - `TopRows(table, take)`: rows by screen position, header rows (first child role 25) skipped;
  - `Shape` (roles/counts/positions only).
- `SelectFirstRow(front, ok)`:
  - candidate panels ≥200×60, largest first; depth 1, then 2;
  - per row: accSelect, check OK, click left edge inside the popup, wait ≤700 ms for OK; up to 3 rows;
  - on failure logs `account_grid_shape`.
- `Native.NoModifiers`: waits ≤3 s; the message names the key.
- `AutofillForm.lastFilledWindow`: the Repair Order of the last successful fill is not re-tried (`online_skip_review_ro`).
- `RunDiagnostics.Stopped`: RepairOrderInUseException → Outcome "probe". `DiagnosticsBundle.IsProbe` also recognises 2.0.2-style checks (online, "not empty", under 1 s, at the empty-order stage). Excluded from TODAY counts and the detailed completion %.
- `OpenNew`: "Order Entry" is not logged as a prompt.
- Report ZIPs use CompressionLevel.Fastest.
- Self-test 76: probe counting (current and legacy checks excluded; a genuine mobile "not empty" stop still counted).

## Checks performed here

13 C# files: balance, C# 6+ syntax and shadowing scans clean, one entry point. Order Check C# 5 check. All Node tests. ZIP and manifest verified.

## Not verified here

Compilation, and COSTAR's customer list grid under the new selection (the report records its shape if it still fails).

---

# Validation — v2.0.2 (lag fix) — 4 October 2026

## Findings in code

- `Snapshot()`: `WaitIdle(3000)` and then reads **regardless**. Each WM_GETTEXT is a SendMessageTimeout of 100 ms to COSTAR's UI thread, up to 8 s per snapshot.
- `LookupCustomer` / `CustomerFormReady` repeat full snapshots every 30–50 ms while COSTAR searches. 2.0.1 extended that to 15 s, so queued requests built up on COSTAR's thread.
- `timeBeginPeriod(1)` during every entry: global on NT 6.2.
- Order Check always on (thread, server, timer).
- Worker poll 1 s, with a window scan per poll.
- `new JavaScriptSerializer()` per message.
- `Process.GetCurrentProcess()` not disposed in Order Check's window search.

## Changes

- `Snapshot`:
  - `WaitIdle(8000)`, then `Responsive(window,60)`. If not answering: no text reads; readable controls marked `busy`.
  - A failed read with COSTAR not answering stops further reads.
  - Sets `lastSnapshotBusy`; counts `busySkips`/`busySnapshots` (logged per run as `costar_busy_skips`).
- `Current()` waits (150 ms steps, up to 20 s) for a non-busy snapshot. `Settled()` and the startup wait treat busy as not ready.
- Lookup loops back off 150 ms on busy and poll 120 ms while "SEARCHING" (was 30–50 ms).
- `FastTimer()` is no longer called (no `timeBeginPeriod`).
- Order Check is opt-in (flag file `order-check-on` in the helper's data folder; tab button).
  - `Hosting.EntryPid` stops reads of the entry COSTAR; `Hosting.Hold` stops reads during entry.
  - Process leak fixed.
- Worker poll 2 s while enabled; `Available()` cached 3 s.
- `Wire` uses one `JavaScriptSerializer` per thread.
- `GCSettings.LatencyMode = SustainedLowLatency`.
- `PerfMonitor`:
  - samples every 5 s for the status line;
  - writes `perf` (ws, private, heap, handles, gdi, user, threads, cpu) to the day log every 5 minutes, and `perf_after_job` after each job;
  - END OF DAY shows start/peak/now and CPU, and flags >300 MB, handle growth >500, GDI/USER growth >200, or CPU >5%.
- Self-test 75: perf parsing and the report lines.

## Checks performed here

13 C# files: balance, C# 6+ syntax and shadowing scans clean, one entry point. Order Check C# 5 check. All Node tests. ZIP and manifest verified.

## Not verified here

Compilation, live CPU/memory on the RDP server (the new meter and day log will show it).

---

# Validation — v2.0.1 — 4 October 2026

## Basis: diagnostics 4 Oct 00:37–00:56 (2.0.0, 7 online runs, 1 completed)

- 3× "target field is covered": first click on a fresh Repair Order, 70–430 ms after it appeared.
- 1× "search did not cancel": the commit dialog appeared 2236 ms after Tab, then "SEARCHING" with COSTAR busy for 6 s, then Escape at 3 s cancelled the search.
- 1× commit timeout: 2523 ms with a 2500 ms limit.
- 1× Add New 30.9 s beside a reviewed order.
- Memory dropped to 1 MB after every run (EmptyWorkingSet).

## Changes

- `SearchPatienceMs=15000` for a running search (LookupCustomer and CustomerFormReady). Popups keep 750 ms; other waits keep 3 s.
- `CommitField` limit 8000 ms.
- `ClickTarget`: if covered, it logs `covered` (masked: COSTAR or another app, window class) and waits up to 1.5 s, re-aiming at the live rectangle. If another process is on top and nobody is typing, `BringToFront(root)` once. Then `covered_wait`.
- `Memory.Trim`: `GC.Collect()` only above 96 MB managed heap; no EmptyWorkingSet.
- `TempeOrderCheck.Hosting.Store` (hosted Store) is read directly by `OrderCheckLink`; HTTP remains only as a fallback.
- `Hosting.Hold` (= coordinator busy) makes `Poller.Cycle` wait during entry.
- `OpenNew` logs the first foreground COSTAR prompt (title/class) as `add_new_prompt`.
- **Time in:**
  - `Selectors.TimeIn` finds the "Time in" label → combo directly below → its single inner Edit (optional).
  - `Order.TimeInText("HH:mm")` → "h:mm am/pm"; `Order.ClockMinutes` compares formats.
  - `SetTimeIn()` runs after the online header for pickups. It is non-fatal and logs `time_in` set / not kept / box not found.
  - `Verify` adds a non-fatal note if Time in differs from the booking.
- Self-test 74: Time in format, comparison and box finding (real layout: label 109,295; combo 109,309; Edit 112,312; Promised beside it).

## Checks performed here

13 C# files: bracket balance, C# 6+ syntax and shadowing scans clean, one entry point. Order Check C# 5 check (no lambdas). All Node tests (helper package/job card/startup, Order Check rules/sharing). ZIP and manifest verified.

## Not verified here

Compilation and live COSTAR behaviour (RDP PC). Whether COSTAR accepts "10:30 am" typed into Time in: the helper reports either way.

---

# Validation — v2.0.0 (one system) — 3 October 2026

## Merge

- `Source/OrderCheck.cs` (Order Check 1.4.0 reader, namespace `TempeOrderCheck`) is compiled into the helper.
  - Its `Program`/`Main` is replaced by `Hosting` (claims the old app's mutex `Local\TempeOrderCheck_v1`, works out the board address). One entry point remains: `TempeCostar.Program.Main`.
  - The old app lowered the whole process to below-normal priority. Not done here, so entry speed is unaffected. Its reader and Search threads already run at below-normal thread priority.
- `MainForm(board, hosted)` is embedded as the third tab (TopLevel=false).
  - Hosted: no tray icon, no Exit; `Shutdown()` runs when the helper closes.
  - `TargetChanged` tells the helper to forget its cached WIP key and refresh its own COSTAR list.
  - If the helper's current target becomes the WIP window, it is dropped and the other Tempe COSTAR is chosen.
- Self-test: `--self-test` runs `MobileTests.Run()` and `TempeOrderCheck.SelfTests.Run()` and writes both reports. Failure of either fails the build.
- Board files are in `Website/`, mirroring the GitHub repo. Sharing docs, the extension update and notes are in `OrderCheck/`. Order Check's Node tests are in `Tests/OrderCheck` with repointed paths.
- Data folders unchanged: `%LOCALAPPDATA%\TempeOrderCheck` (WIP window, interval, Mark OK marks), so settings carry over.

## Checks performed here

- All 13 C# files: bracket balance, C# 6+ syntax scan, loop-shadowing scan. Exactly one `Main`.
- Order Check's own C# 5 checker (no lambdas) on `OrderCheck.cs`.
- Order Check Node tests (10 rules groups, GitHub sharing, Firebase payload).
- Helper package, job card and startup tests (website script references include the board).
- ZIP and SHA-256 manifest verified from a fresh extract.

## Not verified here

Compilation and the 88 self-test groups run on the RDP PC.

---

# Validation — v1.9.0 — 3 October 2026

## Basis (diagnostics 3 Oct 23:39–23:41, helper 1.8.3)

- **Auto-fill runs:**
  - "The selected COSTAR is not ready to open a new order": the main window did not come forward.
  - "The target field is covered": the Repair Order was behind another window.
  - "Open one empty Repair Order": the window Add New returned was gone a moment later.
- **Manual run:** the phone matched several accounts. COSTAR showed its customer Search list (WinForms form, 53 controls; buttons Add new / Include Inactive / Print Results / Search / Cancel / OK / Clear). The helper pressed Cancel and entered a new customer. Later "no foreground window" stopped it at the first item.

## Changes

- `Native.BringToFront`: SetForegroundWindow, then a short AttachThreadInput to the active window's thread (BringWindowToTop + SetForegroundWindow), then SwitchToThisWindow. Used by `Runner.Activate`, popup recovery and `OpenNew`.
- `Runner.Check(foreground)`:
  - a null foreground is waited out (up to 1.5 s);
  - if another process holds the foreground, COSTAR's window is enabled, and no real user input arrived in the last 2 s (`Native.UserActiveWithin`, which ignores the helper's own SendInput), COSTAR is brought back, at most 3 times per run;
  - COSTAR popups are never bypassed.
- `CommitField` re-checks the foreground right before sending Tab.
- `OpenNew` returns a new Repair Order only after the same window has stayed visible and titled for 300 ms.
- **Account list:**
  - `Selectors.AccountChooser` accepts the OK button even when disabled.
  - `TryChooseFirstAccount`: highlight the top row (`Msaa` from Order Check: table → top row by screen position → `accSelect`, plus a click inside the list), wait for OK to enable, then BM_CLICK OK.
  - The popup's structure is captured once.
- **`OrderCheckLink`:**
  - reads Order Check's `targetKey` (PID@local start ticks) and matches it to the helper's UTC start ±2 s;
  - auto-select skips that window, and a manual pick is refused;
  - before online entry, GET `127.0.0.1:8795/wip.json` (1.5 s timeout) and refuse when a row's `po` equals the TTW number;
  - an absent or old Order Check never blocks.
- `Build.ps1` references `Accessibility.dll`.
- Self-tests 73: Order Check key/lookup, and the real Search-list shape.

## Checks performed here

Exact replacements reviewed. Bracket balance, C# 6+ syntax and loop-shadowing scans are clean. JavaScript/package tests pass. ZIP and manifest verified. Order Check 1.4.0: its own package, rules (10 groups), sharing and C# 5 checks all pass here.

## Not verified here

Compilation and self-tests (on the RDP PC). Whether COSTAR's grid accepts `accSelect` (the click on row 1 covers it). The exact WIP PO column name (Order Check reports it).

---

# Validation — v1.8.3 — 3 October 2026

## Basis

1.8.2 screenshot: "1 Tempe COSTAR windows found: choose one in the list above". The list was disabled and the status read "Mobile job pinned to its original instance". The journal held the 2 October 17:00 job as ready_for_review. Its COSTAR process and Repair Order window no longer existed.

## Cause

- The worker accepts a new job only after the journal job is closed.
- The desk closes a reviewed job by sending "close", which the worker acknowledges.
- `ApplyTargets` auto-selects only the pinned process while a pin exists. `UpdateStatus` disables the list while pinned.
- `Worker.Run("close")` required the pinned COSTAR before reaching its existing "window already gone" acknowledgement.
- Result: once COSTAR closed, nothing could be selected, closed or started.

## Changes

- `CostarWindows.OrderWindowGone(cp)`: the window no longer exists, or belongs to another process. `CostarWindows.PinnedProcessGone(cp)`: no COSTAR process with that PID, start time and session.
- `Worker.Run("close")`: the closed-or-gone acknowledgement now runs before the same-COSTAR requirement. Live windows are unchanged (same-COSTAR check, `ValidateTarget`, `CloseMobile`).
- `WorkerForm.ApplyTargets`: a pin whose window or process is gone ("dead pin") no longer restricts selection or locks the list. It is logged and explained. Live pins behave as before.
- `MobileRecovery.CanReset` unchanged: the existing safety tests (no reset after any entered field) still hold.
- Self-test 71: gone-window and gone-process recognition.

## Checks performed here

Counted replacements reviewed as diffs. Bracket balance, C# 6+ syntax and loop-shadowing scans are clean. JavaScript/package tests pass. ZIP and manifest verified. Compilation and self-tests run on the RDP PC.

## Known remaining edge

COSTAR closed **in the middle of** a mobile entry leaves a failed job with entered fields. It no longer locks the list, but the automatic reset deliberately refuses it. It needs its own guarded recovery, to be designed with care.

---

# Validation — v1.8.2 — 3 October 2026

## Basis: 1.8.1 day log and 1.6.1 runs (diagnostics of 3 October)

- **1.8.1:** started 4 times with no crash. An online order (TTW1730376) was refused with "Select a Branch 11 COSTAR instance above": no COSTAR target was selected. The helper never searched for COSTAR at startup, and the search result was not logged. Detection code was identical to 1.6.1 except the 1.8.0 window-title reading.
- **1.6.1 mobile:** 7.96 / 8.92 / 8.05 s.
  - DET lookup about 80 ms, but leave-grid needed 3 clicks (0.47–1.16 s) although the DET notes existed after the first click.
  - Checkpoint saves about 66 ms each (20 per job) even without forced flush.
  - One startup stop: "A COSTAR field is still loading" while COSTAR was busy (1.16 s) drawing the new order.

## Changes

- `Native.Class`, `Native.Caption`, `Native.TryText`: the 1.6.1 P/Invoke calls (StringBuilder, CharSet.Unicode), with one reused StringBuilder per thread and per kind. The unmanaged buffer code is removed.
- `CostarWindows.Choices` records what it saw (`LastScan`: COSTAR main-window titles and process-check failures). `WorkerForm`:
  - searches at startup;
  - `EnsureTarget()` before Start / resume mobile and before online Fill;
  - logs `costar_found` / `costar_not_found`;
  - explains a failed search in the log.
- `WaitForMobileStartup` waits while any control text read failed. The online reuse path uses `Settled(Current())`, up to 5 s.
- DET: `LeaveForDetNotes` clicks PO# once and accepts when the three DET notes exist and are stable. Otherwise it falls back to `LeaveGrid`.
- `PrivateFiles.Save` times JSON / encrypt / write / replace. `Worker.Persist` times the checkpoint copy. Per-run totals go in the run file, and the end-of-day page shows the per-save breakdown and any COSTAR-not-found searches.

## Checks performed here

Exact counted replacements reviewed as diffs. Bracket balance, C# 6+ syntax scan and loop-variable shadowing scan are clean. JavaScript/package tests pass. ZIP and SHA-256 manifest verified. No C# compiler or COSTAR here; compilation and the 70 self-tests run on the RDP PC.

---

# Validation — v1.8.1 (1.8.0 + day log) — 3 October 2026

## Added in 1.8.1

- `Diagnostics.cs`:
  - `AppLog`: a thread-safe, masked JSON-lines day log (`events-YYYYMMDD.jsonl`), working-set MB on every line, rate-limited desk-connection errors (first, every 20th, recovery), crash capture via `AppDomain.UnhandledException` (type, message, first 4 stack frames). Never throws.
  - Retention: day logs 180 days; saved bundles 30 days.
  - Bundle: adds `day-log/` (last 14 days). The summary now starts with `EndOfDay`: today, speed by version, things to look at. `Summary(reports)` is unchanged for callers.
  - `Popup` also records a text-free `popup_layout` (control kind, position, size, enabled).
- Hooks:
  - `Program`: app start, exit and startup crash.
  - `Worker`: mobile start/stop, job start (with resume step and job-card age), ready, failed, close, unstarted reset, connection drops and recovery.
  - `AutofillForm`: order loaded or failed to load, queue decisions, duplicate refusals, fill start (manual/auto, seconds after loading, queue length), fresh Repair Order opened beside one in use, Add New time, fill result (seconds, run file), queue paused, stop pressed.
  - `Runner.Dispose`: memory before and after the trim.
  - `WorkerForm`: **Add note** dialog, tab switches, Stop all, report saved.
- `MobileTests.cs`: 70 groups (adds the end-of-day page check, on synthetic data; tests never write to the real day log).

## Checks performed here

Exact counted replacements reviewed as diffs. C# tokenizer bracket balance, C# 6+ syntax scan, and a scan for loop variables that share a name with a lambda in their own header: all clean. Lambda-name overlaps are only in sibling scopes, the same patterns that compiled in 1.6.1. JavaScript/package tests pass. ZIP and SHA-256 manifest verified.

## Not verified here

Same as 1.8.0: no C# compiler or COSTAR in this environment. Compilation, the 70 self-tests and live behaviour are confirmed on the RDP machine.

---

# Validation — v1.8.0 lean build — 3 October 2026

## Basis

1.6.x diagnostics (4 runs, COSTAR 5.7.6.0, Tempe Branch 11): screen reading took 19–43% of each run; a 10.3 s mobile job made ~12,200 text reads (14 full form reads, 53 grid reads). A real capture shows the item grid has ~214 controls (100 edits, 51 statics, 32 buttons) of which the engine's grid logic uses the 5 column labels and the cells under them.

## Changes

- **Text reads (Native):** WM_GETTEXT, GetClassName and GetWindowText write into one reusable unmanaged buffer per thread (freed with the thread); previously each read allocated a 4,096-char StringBuilder plus a marshalled native copy.
- **Snapshot:** phase 1 collects geometry/class/state for all controls (local calls); phase 2 reads text only for the controls a read plan names. Skipped controls are marked and read on demand through `ControlInfo.Late` if anything asks (counted as late reads, first 20 logged). Button captions are read only for popups. Control classes are cached per window for the run.
- **Grid read plan:** after the grid labels are learned from a full read, grid reads take the 5 labels plus edits within each label's column tolerance (the same tolerance `ProductGrid`/`Cell` use). If a label disappears or its text changes, that snapshot is completed in full and the labels are learned again.
- **Label searches** (`Selectors.Label`, `Selectors.Header`) use only text that was actually read (`Peek`), so skipped display labels are never fetched.
- **Header cache:** `HeaderNow` reuses the last map while all 11 fields are the same windows, visible, enabled, same parent, same rectangle; returned fields are fresh copies read live on first use. Any change falls back to the previous full read.
- **Customer lookup:** `Selectors.AccountChooser` classifies a selection list (list control, or a WinForms form with a list area and exactly one OK/Select-type button; message boxes `#32770` excluded). `TryChooseFirstAccount` selects row 0 for list boxes, presses that button via BM_CLICK, or Enter only when no risky button exists; bounded to 2 attempts; the lookup then waits up to 5 s for the chosen account and never falls back to a new customer.
- **Online:** `RepairOrderInUseException` is raised before any input when a reused open order is not empty; the online tab then opens a fresh order (`OpenNew(...,allowExisting:true)` identifies the window that was not there before, and uses BM_CLICK if an open order covers Add New). `OrderQueue` + "Fill automatically" queue copied orders while one is entered, refuse duplicates and orders already entered this session, and pause after a stop.
- **Memory:** after each job, full GC + `EmptyWorkingSet`.
- **Diagnostics:** text reads, skipped, late and header-cache counts per run (summary SCREEN READS, CSV columns).
- **Self-tests:** 69 groups (adds read plan + on-demand reads, account chooser, order queue).

## Checks performed here

Exact counted replacements, reviewed as diffs against 1.6.1; every grid-snapshot consumer audited (only labels plus the five columns are used; totals and delivery checks use full reads); C# tokenizer bracket balance and C# 6+ syntax scan clean; JavaScript/package tests pass; ZIP and SHA-256 manifest verified.

## Not verified here

No C# compiler or COSTAR in this environment: compilation, the 69 self-tests, live read counts and the real two-account popup are confirmed on the RDP machine. 1.5.5–1.6.1 compiled there with the same toolchain.

---

# Validation — v1.6.1 speed build — 2 October 2026

## Basis (1.6.0 diagnostics, 2 runs on COSTAR 5.7.6.0)

- Mobile 10.3 s; leave-grid needed 3 attempts (1.18 s). Online pickup 5.2 s; leave-grid 3 attempts (0.53 s), the second re-click fired 44 ms after the first because COSTAR was briefly busy before processing the click.
- Mobile: 17 checkpoint saves between steps took 1.20 s (about 70 ms each).
- Existing customer lookup on an online pickup completed without a stop.

## Changes

- `CostarAutofill.cs`: before leaving the grid after DET, wait up to 1.5 s for the DET row's description (COSTAR's code lookup), then leave; if it does not fill, continue as 1.6.0 did. Leave-grid re-clicks after a settle only once 120 ms have passed since the click.
- `MobileModel.cs`: `PrivateFiles.Save` takes an optional `flush` flag (default true: unchanged for settings, desk queue and status reports).
- `Worker.cs`: checkpoint saves use `flush=false`; 1 s desk poll while mobile entry is enabled and not paused (3 s otherwise).
- `MobileTests.cs`: storage round-trip also covers `flush=false`.

## Checks performed here

Exact counted replacements reviewed as diffs; C# tokenizer balance and C# 6+ syntax scan clean; JavaScript/package tests pass; ZIP and SHA-256 manifest verified. C# compilation and the 66 self-tests run on the RDP machine at first launch (1.6.0 built there with the same toolchain).

---

# Validation — v1.6.0 speed build — 2 October 2026

## Basis

Changes target what the 1.5.5 diagnostics measured on 2 October (4 runs, COSTAR 5.7.6.0, Tempe Branch 11):
- DET: leaving the item grid failed its first click in both runs and waited a full 2 s before the second click worked.
- Mobile: about 2.9 s between steps, consistent with two encrypted checkpoint saves per step plus progress saves.
- Existing customer (TTW1730342): COSTAR did not answer for more than 2 s after the phone entry; the helper read the screen mid-redraw, found no labels and stopped with a layout error.

## Changes

- `CostarAutofill.cs`: `WaitIdle` (WM_NULL via SendMessageTimeout, abort-if-hung, capped) before every screen read, before Ready checks and before clicks; `HeaderNow` tolerates a brief header redraw (3 s cap, stops at once on focus loss); the customer lookup treats a missing header during redraw as transient within its existing 20 s limit; leave-grid re-clicks within 0.7 s and accepts PO# after COSTAR settles or after a 300 ms hold (6 s total budget, as before); shorter polls; 1 ms timer resolution during a run (released in Dispose); online Fill opens a Repair Order with the existing Add New routine when none is open.
- `MobileRunner.cs`: one checkpoint save per step (the pending marker), final save after the last step; pre-step re-read only for the first step of a run; customer-popup recovery limited to phone/name/reference steps; shorter startup/stability polls.
- `Worker.cs`: progress saves throttled to 2.5 s; checkpoint and progress save times sent to diagnostics.
- `Diagnostics.cs`: correct stop stage, idle-wait and save counters, time between steps, wait outcome labels, label-only layout fingerprint.
- `MobileTests.cs`: 66 groups (adds stop-stage, between-step and wait-label checks).

## Resume safety of the single save per step

Before each step the journal records all verified steps and marks the step pending. If entry stops after the step's input, the existing recovery compares COSTAR with the verified view: unchanged means not applied, exactly the step's change means applied, anything else stops without guessing. This is the same reconciliation used before; the removed "after" save only shortened what recovery had to re-check.

## Checks performed here

- Every edit applied as an exact, counted replacement and reviewed as a diff against 1.5.5.
- C# tokenizer bracket balance and a scan for C# 6+ syntax (`/langversion:5`): clean.
- JavaScript/package tests pass; ZIP and SHA-256 manifest verified.

## Not verified here

No Windows compiler or COSTAR is available in this environment. C# compilation, the 66 self-tests and live timing are verified by the first run on the RDP machine. 1.5.5 compiled and ran there with the same toolchain.
