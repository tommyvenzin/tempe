// 2.9.7: the wholesale helper (Start-Wholesale.cmd: TempeMobile.exe --wholesale) for a Windows session of its own on
// costar-server (Tommy, 14 Nov: "the dedicated wholesale RDP session to check repeatedly and stay in the Wholesale
// Orders section"). Only the wholesale dry run runs in it, checking by itself from 06:00 to 18:00 (WholesaleRun's
// loop): no phone jobs, online or eBay orders, Order Check or desk connection. It shows which Windows session and
// login it is in, and won't start checking while another Tempe helper runs in that same session (Tommy: "Confirm the
// actual RDP arrangement before assuming two connections create independent sessions"). Its files are its own (the
// "wholesale" folder: what it has looked at, the Discord channel's webhook (encrypted) and message ids). Checking
// stays on across restarts (wholesale-settings.json) until Stop is pressed; updates install themselves outside
// 06:00-18:00 when it's between passes, and checking starts again in the new version.
// 2.9.8: Approach (how orders are worked through: WholesaleSpeed; the 2.9.7 approach until another is picked, and
// Back to 2.9.7 returns to it at once, from the next pass) and Run speed comparison (WholesaleSpeedTest: the same orders
// opened with each approach in turn, its report shown and saved with the diagnostics). Checking stops for the test and
// starts again after it if it was on.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace TempeCostar {
    // approach (2.9.8): the WholesaleSpeed preset checking uses ("baseline": the 2.9.7 approach). 2.9.10 (Tommy, 15 Nov
    // 11:17: "use All four, search by order number for further dry runs and as the intended lookup method for the future
    // live workflow"): "all-number" unless another is picked; approachSet: the version that last set it by itself
    // (WholesaleSettingsFile.Adopt: once, when 2.9.10 first starts).
    public sealed class WholesaleSettings { public bool loop;public string autoUpdateTried="",approach="all-number",approachSet=""; }

    internal sealed class WholesaleForm:Form {
        internal const string AppTitle="Tempe COSTAR - Wholesale (dry run)";
        readonly string folder,settingsFile;readonly EntryCoordinator coordinator=new EntryCoordinator();
        readonly WholesaleState state;readonly WholesaleDiscord discord;readonly WholesaleView view;WholesaleSettings settings;
        readonly Label sessionLine=Ui.Hint("",860),discordLine=Ui.Hint("",860);
        readonly Button start=Ui.PrimaryButton("Start checking (dry run)",220),stop=Ui.DangerButton("Stop",90),hook=Ui.SecondaryButton("Discord channel ...",160),
            diagnostics=Ui.SecondaryButton("Save diagnostics",150),updateNow=Ui.SecondaryButton("Update now",120),install=Ui.PrimaryButton("Install update",200),
            github=Ui.SecondaryButton("GitHub upload",140);   // 2.9.20: sets up the upload of each saved diagnostics ZIP (DiagnosticsGitHub)
        readonly CheckBox withWindows=Ui.Check("Start with Windows (this login)",false);
        ComboBox approach;
        readonly Button baseline=Ui.SecondaryButton("Back to 2.9.7",140),speedTest=Ui.SecondaryButton("Run speed comparison",200);
        // The speed test: running (test), asked for and waiting for checking to stop (testPending), checking was on before it.
        volatile WholesaleSpeedTest test;bool testPending,loopBeforeTest,testSeen;int testSize=10;List<string> testInclude=new List<string>();
        readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer {Interval=1000};
        volatile WholesaleRun run;Updater.Release offer;bool checking,installing,resumeTold;int ticks;DateTime lastAutoTry=DateTime.MinValue,resumeAt=DateTime.MaxValue;
        // 2.9.10: Windows' session changes noted (Native.SessionEvent), for the evidence of a stop for someone at the PC.
        protected override void OnHandleCreated(EventArgs e) { base.OnHandleCreated(e);Native.WatchSession(Handle); }
        protected override void WndProc(ref Message m) { if(m.Msg==Native.SessionChangeMessage) Native.SessionEvent(m.WParam.ToInt32());base.WndProc(ref m); }
        internal WholesaleForm(string dataFolder) {
            folder=dataFolder;settingsFile=Path.Combine(folder,"wholesale-settings.json");settings=LoadSettings();
            state=new WholesaleState(folder);discord=new WholesaleDiscord(folder);view=new WholesaleView(state);
            Text=AppTitle+" | "+AutofillForm.Version;Size=new Size(1000,940);MinimumSize=new Size(900,700);Font=Ui.Base;StartPosition=FormStartPosition.CenterScreen;BackColor=Ui.Canvas;
            var card=Ui.Card();card.Dock=DockStyle.Top;
            var lines=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Surface};
            lines.Controls.Add(Ui.Title("Wholesale orders in COSTAR Sydney: checking by itself (dry run)"));
            lines.Controls.Add(Ui.Hint("From 06:00 to 18:00 it reads COSTAR Sydney's \"Orders yet to be filled\" again and again and opens up to 100 BUF orders a pass: staff's go requests first, then orders not looked at yet (oldest first), then ones to try again. "+
                "It shows what it WOULD do with each (Sell, then Cancel, or the tags [stock] [card] [review] [items] it would add to the Comment) and, with a channel set, says so on Discord (every message starts DRY RUN). Nothing is typed, sold or changed. "+
                "It stays on COSTAR's wholesale list. Run it in a Windows session of its own (a second login), connected, not minimized and not locked: it clicks tyre lines open to read their stock.",860));
            lines.Controls.Add(sessionLine);lines.Controls.Add(discordLine);lines.Controls.Add(withWindows);lines.Controls.Add(view.Line);
            card.Controls.Add(lines);
            var buttons=Ui.Row();buttons.Margin=new Padding(0,10,0,6);
            foreach(var b in new Control[]{start,stop,hook,diagnostics,github,updateNow,install}) buttons.Controls.Add(b);
            install.Visible=false;stop.Enabled=false;
            var speedRow=Ui.Row();speedRow.Margin=new Padding(0,0,0,6);
            speedRow.Controls.Add(new Label {Text="Approach:",AutoSize=true,Font=Ui.Base,ForeColor=Ui.Ink,Margin=new Padding(0,10,6,0)});
            approach=SpeedComparisonUi.ApproachBox(settings.approach);
            foreach(var c in new Control[]{approach,baseline,speedTest}) speedRow.Controls.Add(c);
            var rows=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Canvas,Margin=new Padding(0)};
            rows.Controls.Add(buttons);rows.Controls.Add(speedRow);
            Controls.Add(view.Build(card,rows));
            approach.SelectedIndexChanged+=delegate{ChooseApproach();};
            baseline.Click+=delegate{approach.SelectedIndex=0;};
            speedTest.Click+=delegate{DeskForm.Attempt(AskSpeedTest);};
            withWindows.Checked=AutoStart.On("Wholesale");
            withWindows.CheckedChanged+=delegate{ DeskForm.Attempt(delegate{ AutoStart.Set("Wholesale",withWindows.Checked); }); };
            start.Click+=delegate{DeskForm.Attempt(delegate{StartLoop(false);});};
            stop.Click+=delegate{
                var r=run;if(r!=null&&r.Running){r.Cancel=true;view.Append("Stopping ...");}
                var t=test;if(t!=null&&t.Running){t.Stop();view.Append("Stopping the speed comparison after the order in hand ...");}
                testPending=false;loopBeforeTest=false;
                resumeAt=DateTime.MaxValue;resumeTold=false;settings.loop=false;SaveSettings();
            };
            hook.Click+=delegate{DeskForm.Attempt(ChooseChannel);};
            // 2.9.20: "helper-wholesale" in GitHub (its uploads and set-up file), so they aren't taken for the RDP helper's.
            diagnostics.Click+=delegate{DeskForm.Attempt(delegate{ string path=DiagnosticsBundle.Save();view.Append("Diagnostics saved: "+path);DiagnosticsGitHub.After(this,DiagnosticsGitHub.WholesaleApp,path,path,view.Append);Process.Start("explorer.exe","/select,\""+path+"\""); });};
            github.Click+=delegate{DeskForm.Attempt(delegate{DiagnosticsGitHub.Window(this,DiagnosticsGitHub.WholesaleApp);});};
            updateNow.Click+=delegate{UpdateNow();};
            install.Click+=delegate{InstallUpdate(false);};
            timer.Tick+=delegate{Tick();};
            Shown+=delegate {
                AutoStart.Refresh("Wholesale");
                view.Append("Wholesale helper "+AutofillForm.Version+" in "+Native.SessionText()+". Its files: "+folder);
                view.Append("Approach: "+WholesaleSpeed.NameOf(WholesaleSpeed.Preset(settings.approach).key)+".");
                if(settings.loop) { resumeAt=DateTime.Now.AddSeconds(20);view.Append("Checking was on when this helper last closed: it starts again in 20 seconds (press Stop to keep it off)."); }
                timer.Start();CheckForUpdate();ShowLines();
            };
            FormClosing+=delegate { var r=run;if(r!=null&&r.Running) r.Cancel=true;var t=test;if(t!=null&&t.Running) t.Stop(); };
        }
        WholesaleSettings LoadSettings() { return WholesaleSettingsFile.Load(settingsFile); }
        void SaveSettings() { WholesaleSettingsFile.Save(settingsFile,settings); }
        // Why this session can't be checked in now (null: it can): another Tempe helper in it, or the session not
        // connected or locked (WholesaleRun waits on these, and Discord hears after 10 minutes).
        static string SessionCheck() {
            int mine=Native.SessionId;
            if(Native.OtherHelperSessions().Contains(mine)) return "another Tempe helper is running in this same Windows session (the RDP helper?). The wholesale helper needs a Windows session of its own: sign in with a second login, or close the other helper here.";
            return Native.SessionProblem();
        }
        void StartLoop(bool automatic) {
            var last=run;
            Order.Require(last==null||!last.Running,"Checking is already on.");
            int mine=Native.SessionId;
            Order.Require(!Native.OtherHelperSessions().Contains(mine),"Another Tempe helper is running in this same Windows session (the RDP helper?). The wholesale helper needs a Windows session of its own: sign in with a second login (or close the other helper in this session), then start checking.");
            var t=test;
            Order.Require(t==null||!t.Running,"A speed comparison is running: press Stop (or wait for it to end) first.");
            var r=new WholesaleRun(coordinator,view.Append,new WholesaleOptions {Loop=true,State=state,Discord=discord,Session=SessionCheck,Speed=delegate { return WholesaleSpeed.Preset(settings.approach); }});
            run=r;resumeAt=DateTime.MaxValue;settings.loop=true;SaveSettings();
            view.Append(automatic?"Checking started again by itself.":"Checking started.");
            var thread=new Thread(delegate() { r.Run();view.Append(r.Summary); }) {IsBackground=true,Name="Wholesale loop"};
            thread.Start();
        }
        void Tick() {
            var r=run;bool running=r!=null&&r.Running;
            var t=test;bool testing=t!=null&&t.Running;
            if(testing) { var current=t.Current;view.Update(current);Ui.SetText(view.Line,t.StatusLine); } else view.Update(r);
            start.Enabled=!running&&!installing&&!testing&&!testPending;stop.Enabled=running||testing||testPending;
            speedTest.Enabled=!testing&&!testPending&&!installing;
            // The speed test once checking has stopped; checking again after it, if it was on.
            if(testPending&&!running&&!installing) { testPending=false;StartTest(); }
            if(t!=null&&!testing&&testSeen) { testSeen=false;if(loopBeforeTest) { loopBeforeTest=false;resumeAt=DateTime.Now.AddSeconds(10);view.Append("Checking starts again in 10 seconds."); } }
            if(DateTime.Now>=resumeAt&&!running&&!installing&&!testing&&!testPending) Resume();
            if(++ticks%5==1) ShowLines();
            if(ticks%(6*3600)==0) CheckForUpdate();
            install.Visible=offer!=null;if(offer!=null) install.Text="Install "+offer.version;
            AutoUpdate();
        }
        // Checking started again by itself (after a restart or an update). If it can't start (another helper in this
        // session ...), no message box on an unattended screen: said here and on Discord (once), tried every 5 minutes.
        void Resume() {
            resumeAt=DateTime.MaxValue;
            try { StartLoop(true);resumeTold=false; }
            catch(Exception e) {
                view.Append("Checking couldn't start again by itself: "+e.Message+" Tried again in 5 minutes.");
                AppLog.Note("wholesale_resume_failed",RoText.ForLog(e.Message));
                if(!resumeTold) { resumeTold=true;discord.Say("resume-"+WholesalePlan.ToMs(DateTime.UtcNow).ToString(System.Globalization.CultureInfo.InvariantCulture),"**DRY RUN** · Wholesale checking couldn't start again by itself: "+RoText.ForLog(e.Message)+" It tries again every 5 minutes (or press Start checking)."); }
                resumeAt=DateTime.Now.AddMinutes(5);
            }
        }
        void ShowLines() {
            var others=Native.OtherHelperSessions();int mine=Native.SessionId;
            string problem=Native.SessionProblem();
            Ui.SetText(sessionLine,"Running in "+Native.SessionText()+". "+(others.Count==0?"No other Tempe helper is running on this computer.":others.Contains(mine)?"ANOTHER TEMPE HELPER IS RUNNING IN THIS SAME SESSION: checking won't start until this helper has a session of its own.":"Other Tempe helpers on this computer are in session "+String.Join(", ",others.Distinct().Select(x=>x.ToString()).ToArray())+" (not this one): good.")+(problem!=null?" Now: "+problem+".":""));
            Ui.SetText(discordLine,discord.On?"Discord: the wholesale channel is set ("+discord.Sent+" sent this time"+(discord.Waiting>0?", "+discord.Waiting+" waiting":"")+")"+(discord.LastError.Length>0?"; "+discord.LastError:"")+".":"Discord: no channel set (Discord channel ... to set it). The dry run works without it.");
        }
        // The wholesale channel's webhook: pasted here once, kept encrypted on this PC, never shown again.
        void ChooseChannel() {
            using(var dialog=new Form {Text="Wholesale Discord channel",Size=new Size(640,250),FormBorderStyle=FormBorderStyle.FixedDialog,StartPosition=FormStartPosition.CenterParent,MinimizeBox=false,MaximizeBox=false,Font=Ui.Base,BackColor=Ui.Canvas}) {
                var note=new Label {AutoSize=false,Location=new Point(14,12),Size=new Size(600,58),Text="In Discord: the wholesale channel's settings, Integrations, Webhooks, New Webhook, Copy Webhook URL. Paste it here. It is kept encrypted on this PC only and never shown again."};
                var box=new TextBox {Location=new Point(14,76),Size=new Size(600,26),UseSystemPasswordChar=true};
                var save=Ui.PrimaryButton("Save",100);save.Location=new Point(14,120);
                var test=Ui.SecondaryButton("Send a test",130);test.Location=new Point(124,120);test.Enabled=discord.On;
                var off=Ui.SecondaryButton("Turn off",110);off.Location=new Point(264,120);off.Enabled=discord.On;
                var close=Ui.SecondaryButton("Close",100);close.Location=new Point(514,120);
                dialog.Controls.AddRange(new Control[]{note,box,save,test,off,close});
                save.Click+=delegate{DeskForm.Attempt(delegate{discord.Save(box.Text);box.Text="";test.Enabled=off.Enabled=true;MessageBox.Show(dialog,"Saved. Send a test to check it reaches the channel.","Wholesale Discord channel");});};
                test.Click+=delegate{string why=discord.Test();MessageBox.Show(dialog,why==null?"Discord took the test message.":"The test didn't go: "+why,"Wholesale Discord channel");};
                off.Click+=delegate{DeskForm.Attempt(delegate{discord.Remove();test.Enabled=off.Enabled=false;});};
                close.Click+=delegate{dialog.Close();};
                dialog.ShowDialog(this);
            }
            ShowLines();
        }
        // 2.9.8: the approach checking uses, from the next pass (kept in wholesale-settings.json).
        void ChooseApproach() {
            int i=approach.SelectedIndex;if(i<0||i>=WholesaleSpeed.Keys.Length) return;
            string key=WholesaleSpeed.Keys[i];if(key==WholesaleSpeed.Preset(settings.approach).key) return;
            settings.approach=key;SaveSettings();
            var r=run;
            view.Append("Approach: "+WholesaleSpeed.NameOf(key)+(r!=null&&r.Running?" (from the next pass)":"")+".");
            AppLog.Note("wholesale_approach",key);
        }
        // The speed test asked for: how many orders, and any to include; checking stops for it (after the order in hand).
        void AskSpeedTest() {
            var t=test;Order.Require(t==null||!t.Running,"A speed comparison is running already.");
            Order.Require(!installing&&!testPending,"Wait a moment: the helper is busy.");
            Order.Require(!Native.OtherHelperSessions().Contains(Native.SessionId),"Another Tempe helper is running in this same Windows session (the RDP helper?): run the speed comparison from its Wholesale tab instead, or close it here.");
            int size;List<string> include;
            if(!SpeedComparisonUi.Ask(this,out size,out include)) return;
            testSize=size;testInclude=include;
            loopBeforeTest=settings.loop;testPending=true;resumeAt=DateTime.MaxValue;
            var r=run;
            if(r!=null&&r.Running) { r.Finish=true;view.Append("Checking stops after the order in hand, then the speed comparison starts ..."); }
        }
        void StartTest() {
            var t=new WholesaleSpeedTest(coordinator,view.Append,SessionCheck,discord,testSize,testInclude,true,settings.approach);
            test=t;testSeen=true;
            view.Append("Speed comparison started: "+testSize+" orders"+(testInclude.Count>0?" (including "+String.Join(", ",testInclude.ToArray())+")":"")+". Leave this session alone until it's done.");
            var thread=new Thread(delegate() {
                t.Run();
                view.Append(t.StatusLine);
                foreach(var line in SpeedComparisonUi.Lines(t.ReportText)) view.Append(line);
                if(t.ReportFile.Length>0) view.Append("The report is saved: "+t.ReportFile+" (Save diagnostics includes it).");
                try { BeginInvoke(new Action(delegate { SpeedComparisonUi.ShowReport(this,t.ReportText); })); } catch(InvalidOperationException) { }
            }) {IsBackground=true,Name="Wholesale speed comparison"};
            thread.Start();
        }
        void CheckForUpdate() {
            Updater.CheckInBackground(delegate(Updater.Release found) {
                try { BeginInvoke(new Action(delegate {
                    if(offer!=null&&Updater.Parse(offer.version)>=Updater.Parse(found.version)) return;
                    offer=found;view.Append("Helper "+found.version+" is available (Install "+found.version+").");
                })); } catch(InvalidOperationException) { }
            });
        }
        void UpdateNow() {
            if(checking||installing) return;
            checking=true;updateNow.Enabled=false;updateNow.Text="Checking ...";
            Updater.CheckNow(delegate(Updater.Release found,string error) {
                try { BeginInvoke(new Action(delegate {
                    checking=false;updateNow.Enabled=true;updateNow.Text="Update now";
                    if(error!=null) { MessageBox.Show(this,"GitHub couldn't be reached to look for an update: "+error,"Update",MessageBoxButtons.OK,MessageBoxIcon.Information);return; }
                    if(found==null) { MessageBox.Show(this,UpdateText.Newest(AutofillForm.Version),"Update",MessageBoxButtons.OK,MessageBoxIcon.Information);return; }
                    if(offer==null||Updater.Parse(found.version)>=Updater.Parse(offer.version)) offer=found;
                    InstallUpdate(false);
                })); } catch(InvalidOperationException) { }
            });
        }
        // Outside 06:00-18:00, between passes, nobody using this session for 10 minutes, each version once, at most hourly.
        void AutoUpdate() {
            var r=run;var now=DateTime.Now;var t=test;
            if(testPending||(t!=null&&t.Running)) return;
            if(offer==null||installing||WholesalePlan.InHours(now)||settings.autoUpdateTried==offer.version||now-lastAutoTry<TimeSpan.FromHours(1)) return;
            if(coordinator.Busy||Native.UserActiveWithin((int)Unattended.QuietForUpdate.TotalMilliseconds)) return;
            if(r!=null&&r.Running&&r.InPass) return;
            lastAutoTry=now;InstallUpdate(true);
        }
        // Downloaded, every file checked, installed; the helper restarts into it (Start-Wholesale.cmd), and checking
        // starts again there if it was on.
        void InstallUpdate(bool automatic) {
            var release=offer;
            if(release==null||installing) return;
            var r=run;
            if(!automatic) {
                var t=test;
                if(testPending||(t!=null&&t.Running)) { MessageBox.Show(this,"A speed comparison is running: press Stop (or wait for it to end), then install.","Update",MessageBoxButtons.OK,MessageBoxIcon.Information);return; }
                if(r!=null&&r.Running&&r.InPass) { MessageBox.Show(this,"Checking is in the middle of a pass: press Stop (or wait for the pass to end), then install.","Update",MessageBoxButtons.OK,MessageBoxIcon.Information);return; }
                string notes=String.IsNullOrWhiteSpace(release.notes)?"":"\r\n\r\n"+release.notes;
                if(MessageBox.Show(this,"Install helper "+release.version+" now?"+notes+"\r\n\r\nIt is downloaded, every file is checked, then the wholesale helper restarts into it (checking goes on there if it's on now).","Update the wholesale helper",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes) return;
            }
            var lease=coordinator.TryBeginRead("Updating the helper");
            if(lease==null) { if(!automatic) view.Append("Checking is using COSTAR right now: try again in a moment.");return; }
            installing=true;bool loopWasOn=settings.loop;
            if(r!=null&&r.Running) r.Cancel=true;
            view.Append("Updating to "+release.version+" ...");AppLog.Note("update_started",release.version+(automatic?" automatic":"")+" (wholesale)");
            ThreadPool.QueueUserWorkItem(delegate {
                try {
                    string target=Updater.Install(release,delegate(string message){ try{BeginInvoke(new Action(delegate{view.Append(message);}));}catch(InvalidOperationException){} });
                    BeginInvoke(new Action(delegate {
                        view.Append("Installed "+release.version+". Restarting into it ...");
                        if(automatic) settings.autoUpdateTried=release.version;
                        settings.loop=loopWasOn;SaveSettings();
                        try { lease.Dispose();Updater.RestartInto(target);Close(); }
                        catch(Exception e) { installing=false;AppLog.Note("update_failed","restart: "+e.Message);view.Append("Restart failed: "+e.Message+" Start the wholesale helper again: it opens the new version."); }
                    }));
                } catch(Exception e) {
                    AppLog.Note("update_failed",e.Message);
                    try { BeginInvoke(new Action(delegate { installing=false;lease.Dispose();view.Append("The update didn't install: "+e.Message);if(loopWasOn) resumeAt=DateTime.Now.AddSeconds(5); })); } catch(InvalidOperationException) { }
                }
            });
        }
    }
}
