// 2.6.3 (Tommy, 28 Oct: "it looks like its clicking instead of like native ... do you want to map it
// first?"): the Map button. It only reads COSTAR, never clicks, types, focuses or sends anything that
// changes it: every COSTAR window that shows (the one in front first), each control's kind, COSTAR's own
// words on it (customer words: their length only), its state, and what Windows or accessibility could do
// with it directly (a button's press, a tick box's tick, a tab's switch, a menu item, a list row's
// action, a keyboard shortcut). The map goes with Save diagnostics (maps/), for the next update to press
// what COSTAR allows directly instead of clicking with the mouse.
// 2.6.4 (Tommy's first maps, 28 Oct: "I dont know if this reads the repair order screen"): 2,321 of the
// Repair Order's first 2,500 accessibility objects were parts that don't show (the title, menu and scroll
// bars Windows gives every COSTAR box), so the read ran out before the toolbar and the lines. What doesn't
// show is now counted, never read or opened; Windows' frame parts that show are kept but not opened; only
// the COSTAR in front (or on top) is read, another COSTAR's windows are listed; the reader's page is shorter.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace TempeCostar {
    internal static class CostarMap {
        internal const string Schema="tempe.costar-map.v2";   // v2 (2.6.4): "costar", "listedOnly", "frame", "accessibleHidden"
        internal static string Folder { get { return Path.Combine(AppData.Diagnostics,"maps"); } }
        // Accessibility roles (Windows' numbers) by name, for the map's reader.
        static readonly Dictionary<int,string> RoleNames=new Dictionary<int,string> {
            {1,"title bar"},{2,"menu bar"},{3,"scroll bar"},{4,"grip"},{9,"window"},{10,"client"},{11,"menu"},{12,"menu item"},{13,"tooltip"},
            {15,"document"},{16,"pane"},{18,"dialog"},{20,"group"},{21,"separator"},{22,"toolbar"},{23,"status bar"},{24,"table"},{25,"column header"},
            {26,"row header"},{27,"column"},{28,"row"},{29,"cell"},{30,"link"},{33,"list"},{34,"list item"},{35,"outline"},{36,"outline item"},
            {37,"tab"},{38,"tab page"},{40,"picture"},{41,"label"},{42,"text box"},{43,"button"},{44,"tick box"},{45,"radio button"},{46,"combo box"},
            {47,"drop-down list"},{48,"progress bar"},{51,"slider"},{52,"spin button"},{56,"drop-down button"},{57,"menu button"},{60,"tab list"},
            {62,"split button"},{64,"outline button"}};
        internal static string RoleName(int role) { string n;return RoleNames.TryGetValue(role,out n)?n:"role "+role.ToString(CultureInfo.InvariantCulture); }
        // Roles whose names hold the customer's data (rows, cells, list items, text boxes): their length only.
        static readonly int[] DataRoles={28,29,34,36,42,46};
        // Words as the map keeps them. COSTAR's own words (buttons, ticks, tabs, menus, headings, labels) are
        // kept, with emails and long numbers masked; data (cells, rows, list items, text boxes, and
        // anything inside a table or list but its headings) as its length only.
        internal static string Words(int role,string words,bool inData) {
            words=(words??"").Trim();
            if(words.Length==0) return "";
            bool heading=role==25||role==26;
            if(!heading&&(inData||Array.IndexOf(DataRoles,role)>=0)) return Length(words);
            return Sanitize.Text(words,80);
        }
        internal static string Length(string words) { int n=(words??"").Trim().Length;return n==0?"":"["+n.ToString(CultureInfo.InvariantCulture)+" chars]"; }
        // 2.9.0: a customer's words that COSTAR shows as labels. On the Cashier window (after Sell) the labels right
        // of "Customer" on its row hold the customer's name (COSTAR's own captions there, such as Terms, are kept);
        // a Point-of-sale Memo's words are the customer's memo, and any other message box's words may name the customer.
        // Their length only, in the controls and in accessibility alike, each view by itself (its labels and their
        // places) and each with what the other hid (a label's words are its accessible name too, without its "&"; MSAA
        // also names a control after the label before it: any object with those words, but COSTAR's own buttons, ticks,
        // tabs, menus and headings), as are a label's words too long to keep (over 40: length only in the controls since
        // 2.6.4, kept in accessibility till now).
        internal sealed class LabelSeen { internal int X,Y,W,H;internal string Words;internal Dictionary<string,object> Item; }
        static readonly string[] CustomerCaptions={"CUSTOMER","CUSTOMER NAME","CUST NAME"};
        static readonly string[] OwnCaptions={"TERMS","PHONE","BUS PH","HOME PH","MOBILE PH","FAX","EMAIL","CONTACT","ACCOUNT","ACCOUNT#","BALANCE","AMOUNT","TOTAL"};
        // Words compared as COSTAR's two views give them: no "&", one space, no colon at the end, upper case.
        internal static string Norm(string words) { return Regex.Replace((words??"").Replace("&",""),@"\s+"," ").Trim().TrimEnd(':').TrimEnd().ToUpperInvariant(); }
        // The labels of one window that hold a customer's words (see above): right of "Customer" on its row, all but
        // COSTAR's captions (Terms, Contact, Phone ...) and the terms' words (the label just after Terms); every label of a
        // message box (message: the window is one, class #32770: a Point-of-sale Memo, or any other).
        internal static List<LabelSeen> Private(IList<LabelSeen> labels,bool message) {
            var hide=new List<LabelSeen>();
            if(labels==null) return hide;
            if(message) { hide.AddRange(labels.Where(l=>Norm(l.Words).Length>0));return hide; }
            foreach(var c in labels) {
                if(Array.IndexOf(CustomerCaptions,Norm(c.Words))<0) continue;
                // Right of it, on its row (their heights overlap by half the shorter one's at least), left to right.
                bool termsWords=false;
                foreach(var l in labels.Where(x=>x!=c&&OnRowRight(x,c)).OrderBy(x=>x.X)) {
                    string n=Norm(l.Words);
                    if(n.Length==0) continue;
                    if(Array.IndexOf(OwnCaptions,n)>=0||Array.IndexOf(CustomerCaptions,n)>=0) { termsWords=n=="TERMS";continue; }
                    if(termsWords) { termsWords=false;continue; }
                    if(!hide.Contains(l)) hide.Add(l);
                }
            }
            return hide;
        }
        static bool OnRowRight(LabelSeen l,LabelSeen c) {
            int overlap=Math.Min(l.Y+l.H,c.Y+c.H)-Math.Max(l.Y,c.Y);
            return l.X>=c.X+c.W-4&&overlap>0&&2*overlap>=Math.Min(l.H,c.H);
        }
        // COSTAR's own controls, whose names are never a label's echo (menu items, headings, tabs, buttons, ticks, radio
        // buttons, drop-down, menu and split buttons): every other object with a hidden label's words is hidden too.
        static readonly int[] OwnRoles={12,25,26,37,43,44,45,56,57,62};
        // A control's words as the map keeps them: 40 characters at most (emails and long numbers masked), else
        // their length; a label's that aren't kept go into masked, for accessibility to keep their length too.
        internal static string ControlWords(string kind,string text,HashSet<string> masked) {
            string words=Order.Clean(text);
            if(words.Length<=40) return Sanitize.Text(words,40);
            if(kind=="label"&&masked!=null) masked.Add(Norm(words));
            return Length(words);
        }
        // Accessibility state flags worth knowing for a direct press, in words.
        internal static string StateWords(int state) {
            if(state<0) return "";
            var w=new List<string>();
            if((state&0x1)!=0) w.Add("greyed");
            if((state&0x2)!=0) w.Add("selected");
            if((state&0x4)!=0) w.Add("has the keyboard");
            if((state&0x8)!=0) w.Add("pressed");
            if((state&0x10)!=0) w.Add("ticked");
            if((state&0x20)!=0) w.Add("half ticked");
            if((state&0x40)!=0) w.Add("read-only");
            if((state&0x8000)!=0) w.Add("hidden");
            if((state&0x10000)!=0) w.Add("off screen");
            if((state&0x100000)!=0) w.Add("can take the keyboard");
            if((state&0x200000)!=0) w.Add("selectable");
            return String.Join(", ",w.ToArray());
        }
        // A Windows control's kind, from its class and style (a WinForms class is "WindowsForms10.<class>...").
        internal static string Kind(string cls,int style) {
            string c=(cls??"").ToUpperInvariant();
            if(c=="#32768") return "menu";
            if(c.Contains("BUTTON")) {
                switch(style&0xF) {
                    case 0: case 1: return "button";
                    case 2: case 3: case 5: case 6: return "tick box";
                    case 4: case 9: return "radio button";
                    case 7: return "group box";
                    case 0xB: return "button (drawn by COSTAR)";
                    default: return "button ("+(style&0xF).ToString(CultureInfo.InvariantCulture)+")";
                }
            }
            if(c.Contains("RICHEDIT")) return "text box";
            if(c.Contains("EDIT")) return (style&0x20)!=0?"password box":(style&0x800)!=0?"read-only text box":"text box";
            if(c.Contains("COMBOBOX")) return "drop-down";
            if(c.Contains("STATIC")) return "label";
            if(c.Contains("SYSTABCONTROL32")) return "tabs";
            if(c.Contains("TOOLBARWINDOW32")) return "toolbar";
            if(c.Contains("LISTBOX")||c.Contains("SYSLISTVIEW32")) return "list";
            if(c.Contains("SYSTREEVIEW32")) return "tree";
            if(c.Contains("SCROLLBAR")) return "scroll bar";
            if(c.Contains("MSCTLS_UPDOWN")) return "up/down arrows";
            if(c.Contains("SYSDATETIMEPICK32")) return "date box";
            if(c.Contains("MDICLIENT")) return "window area";
            if(c.StartsWith("WINDOWSFORMS10.WINDOW",StringComparison.Ordinal)) return "COSTAR panel";
            return "other";
        }
        // Whose words a Windows control shows as COSTAR's own (kept) or data (length only).
        static bool DataKind(string kind) { return kind.Contains("text box")||kind=="password box"||kind=="drop-down"||kind=="list"||kind=="tree"||kind=="date box"; }

        // ---- accessibility: one window's tree, read only ----
        internal sealed class Walk {
            internal readonly List<Dictionary<string,object>> Items=new List<Dictionary<string,object>>();
            // Seen: objects kept in the map; Visited: objects asked about at all (hidden ones too); Hidden:
            // objects that don't show (counted only); Frames: Windows' frame parts that show (kept, not opened).
            internal int Budget=5000,MaxDepth=24,Seen,Visited,Hidden,Frames,OriginX,OriginY;internal long TimeLimitMs=40000;internal bool Cut;
            internal readonly Stopwatch Clock=Stopwatch.StartNew();
            // 2.9.0: words (Norm) the window's controls kept as their length only: a name with them, the same. Raw: each
            // item's name as read (for Hide; never written out). Message: the window is a message box (#32770).
            internal HashSet<string> Masked;internal readonly List<string> Raw=new List<string>();internal bool Message;
        }
        // A list (a table, a list, a tree) with more than this many rows or items: its first 8 and last 2 are read
        // (the rest are alike: counted). 2.6.4: only a list; a window or a panel with many boxes is read whole.
        internal const int LongList=40;
        internal const int Invisible=0x8000;
        // Windows' own frame parts: a title bar, a scroll bar and its thumb, a size grip, the system menu.
        // Their buttons (Close, Minimize, Line down ...) are Windows', never COSTAR's: not opened.
        internal static bool Frame(int role,string name) {
            return role==1||role==3||role==4||role==39||(role==2&&String.Equals((name??"").Trim(),"System",StringComparison.OrdinalIgnoreCase));
        }
        internal static Walk Accessible(Accessibility.IAccessible root,int originX,int originY,int budget,long timeLimitMs,HashSet<string> masked=null,bool message=false) {
            var w=new Walk {OriginX=originX,OriginY=originY,Budget=budget,TimeLimitMs=timeLimitMs,Masked=masked,Message=message};
            if(root!=null) Visit(w,null,root,"1",0,false);
            Hide(w);
            return w;
        }
        // 2.9.0: accessibility's own labels (role 41, by their places) through the same rule as the controls' (they may
        // not have been read there: COSTAR slow, or words too long to read), and labels over 40 characters; then every
        // name with the words of one of them as its length too. Masked words go back into the controls' set.
        static void Hide(Walk w) {
            var labels=new List<LabelSeen>();var words=new List<string>();
            for(int i=0;i<w.Items.Count&&i<w.Raw.Count;i++) {
                string raw=w.Raw[i];object rect;
                if(raw==null||RoleIn(w.Items[i])!=41) continue;
                words.Add(raw);
                // A message box's labels are all hidden, placed or not.
                if(w.Items[i].TryGetValue("rect",out rect)) { var r=(int[])rect;labels.Add(new LabelSeen {X=r[0],Y=r[1],W=r[2],H=r[3],Words=raw,Item=w.Items[i]}); }
                else if(w.Message) labels.Add(new LabelSeen {X=-1,Y=-1,W=0,H=0,Words=raw,Item=w.Items[i]});
            }
            var hide=new HashSet<string>(StringComparer.Ordinal);
            foreach(var l in Private(labels,w.Message)) hide.Add(Norm(l.Words));
            foreach(var raw in words) if(Order.Clean(raw).Length>40) hide.Add(Norm(raw));   // placed or not
            hide.Remove("");
            if(hide.Count==0) return;
            for(int i=0;i<w.Items.Count&&i<w.Raw.Count;i++) if(w.Raw[i]!=null&&Array.IndexOf(OwnRoles,RoleIn(w.Items[i]))<0&&hide.Contains(Norm(w.Raw[i]))) w.Items[i]["name"]=Length(w.Raw[i]);
            if(w.Masked!=null) w.Masked.UnionWith(hide);
        }
        static void Visit(Walk w,Accessibility.IAccessible parent,object child,string path,int depth,bool inData) {
            if(w.Seen>=w.Budget||w.Visited>=w.Budget*4||w.Clock.ElapsedMilliseconds>w.TimeLimitMs) { w.Cut=true;return; }
            w.Visited++;
            // The state first: what doesn't show (a box's own title and scroll bars, a tab page behind another)
            // costs this one question; nothing else of it, or under it, is asked.
            int state=Msaa.StateOf(parent,child);
            if(depth>0&&state>=0&&(state&Invisible)!=0) { w.Hidden++;return; }
            w.Seen++;
            int role=Msaa.RoleOf(parent,child);
            string name=Msaa.NameOf(parent,child),value=Msaa.ValueOf(parent,child),action=Msaa.ActionOf(parent,child),keys=Msaa.ShortcutOf(parent,child);
            int l,t,wd,ht;bool placed=Msaa.LocationOf(parent,child,out l,out t,out wd,out ht);
            bool frame=Frame(role,name);
            var a=child as Accessibility.IAccessible;
            int count=0;if(a!=null&&!frame) { try { count=a.accChildCount; } catch(Exception) { count=0; } }
            var item=new Dictionary<string,object> {{"path",path},{"role",role},{"kind",RoleName(role)}};
            string words=w.Masked!=null&&!String.IsNullOrEmpty(name)&&Array.IndexOf(OwnRoles,role)<0&&w.Masked.Contains(Norm(name))?Length(name):Words(role,name,inData);if(words.Length>0) item["name"]=words;
            if(!String.IsNullOrEmpty(value)) item["value"]=Length(value);
            if(state>=0) { item["state"]="0x"+state.ToString("X",CultureInfo.InvariantCulture);string sw=StateWords(state);if(sw.Length>0) item["stateWords"]=sw; }
            if(!String.IsNullOrEmpty(action)) item["action"]=Sanitize.Text(action,40);
            if(!String.IsNullOrEmpty(keys)) item["keys"]=Sanitize.Text(keys,40);
            if(placed&&(wd>0||ht>0)) item["rect"]=new[]{l-w.OriginX,t-w.OriginY,wd,ht};
            if(count>0) item["children"]=count;
            if(a==null) item["simple"]=true;
            if(frame) { item["frame"]=true;w.Frames++; }
            w.Items.Add(item);w.Raw.Add(String.IsNullOrEmpty(name)?null:name);
            if(frame||a==null||depth>=w.MaxDepth||count<=0) return;
            bool list=IsList(role),data=inData||list,sample=list&&count>LongList;
            var kids=Msaa.Children(a,list?400:2000);
            try {
                int n=kids.Count;
                for(int i=0;i<n;i++) {
                    if(sample&&n>LongList&&i>=8&&i<n-2) continue;
                    Visit(w,a,kids[i],path+"."+(i+1).ToString(CultureInfo.InvariantCulture),depth+1,data);
                    if(w.Cut) break;
                }
                if(sample&&n>LongList) item["read"]="the first 8 and last 2 of "+n.ToString(CultureInfo.InvariantCulture)+" (the rest alike)";
            } finally { foreach(var k in kids) Msaa.Release(k); }
        }

        // ---- the windows: Windows' own view of each control, read only ----
        // labels: the labels read (for the map's last pass over them, after accessibility; may be null).
        internal static Dictionary<string,object> Controls(IntPtr window,int originX,int originY,bool message,HashSet<string> masked,List<LabelSeen> labels,out int count,out int pressable) {
            var list=new List<Dictionary<string,object>>();int seen=0,direct=0;bool busy=false;if(labels==null) labels=new List<LabelSeen>();
            uint pid=Native.Pid(window);
            Native.EnumChildWindows(window,delegate(IntPtr h,IntPtr unused) {
                if(seen>=2000) return false;
                if(!Native.IsWindowVisible(h)||Native.Pid(h)!=pid) return true;
                seen++;
                string cls=Native.Class(h);int style=Native.GetWindowLong(h,-16);string kind=Kind(cls,style);
                Native.Rect r;Native.GetWindowRect(h,out r);
                var c=new Dictionary<string,object> {{"h",h.ToInt64()},{"parent",Native.GetParent(h).ToInt64()},{"class",cls},{"kind",kind},
                    {"id",Native.CtrlId(h)},{"style","0x"+style.ToString("X8",CultureInfo.InvariantCulture)},{"rect",new[]{r.Left-originX,r.Top-originY,r.Right-r.Left,r.Bottom-r.Top}},{"enabled",Native.IsWindowEnabled(h)}};
                // A COSTAR that doesn't answer within 90 ms: no more words read from this window (each would wait).
                if(kind!="password box"&&!busy) {
                    string text;var asked=Stopwatch.StartNew();bool read=Native.TryText(h,out text);
                    if(!read&&asked.ElapsedMilliseconds>=90) busy=true;
                    if(read&&!String.IsNullOrEmpty(text)) {
                        if(DataKind(kind)) c["text"]=Length(text);
                        else {
                            c["words"]=ControlWords(kind,text,masked);
                            if(kind=="label") labels.Add(new LabelSeen {X=r.Left-originX,Y=r.Top-originY,W=r.Right-r.Left,H=r.Bottom-r.Top,Words=Order.Clean(text),Item=c});
                        }
                    }
                }
                // What Windows could do with it directly: a button window takes BM_CLICK (a press; a tick box's tick).
                if(kind=="button"||kind=="button (drawn by COSTAR)") { c["direct"]="press (BM_CLICK)";direct++; }
                else if(kind=="tick box"||kind=="radio button") {
                    c["direct"]="tick (BM_CLICK)";direct++;
                    UIntPtr check;if(!busy&&Native.SendNull(h,0xF0,UIntPtr.Zero,IntPtr.Zero,3,200,out check)!=IntPtr.Zero) c["check"]=(int)check.ToUInt64();   // BM_GETCHECK: read only
                }
                list.Add(c);return true;
            },IntPtr.Zero);
            count=seen;pressable=direct;
            foreach(var l in Private(labels,message)) { l.Item["words"]=Length(l.Words);if(masked!=null) masked.Add(Norm(l.Words)); }
            var result=new Dictionary<string,object> {{"count",seen},{"items",list}};
            if(busy) result["wordsStopped"]="COSTAR didn't answer within 90 ms: the rest of this window's words weren't read";
            return result;
        }
        static readonly string[] SkipClasses={"SysShadow","tooltips_class32","IME","MSCTFIME UI","Default IME"};
        // COSTAR's windows that show now: the one in front first, then as Windows stacks them (at most 40).
        internal static List<IntPtr> ShownWindows(out IntPtr front) {
            var pids=new Dictionary<uint,bool>();var found=new List<IntPtr>();IntPtr fg=Native.GetForegroundWindow();
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) {
                if(!Native.IsWindowVisible(w)) return true;
                uint pid=Native.Pid(w);bool costar;
                if(!pids.TryGetValue(pid,out costar)) { ProcessIdentity identity;costar=LocalProcess.IsNamed((int)pid,"COSTAR",out identity);pids[pid]=costar; }
                if(!costar||SkipClasses.Any(s=>Native.Class(w).IndexOf(s,StringComparison.OrdinalIgnoreCase)>=0)) return true;
                Native.Rect r;if(!Native.GetWindowRect(w,out r)||r.Right-r.Left<4||r.Bottom-r.Top<4) return true;
                found.Add(w);return found.Count<40;
            },IntPtr.Zero);
            front=found.Contains(fg)?fg:IntPtr.Zero;
            if(front!=IntPtr.Zero) { found.Remove(front);found.Insert(0,front); }
            return found;
        }
        // 2.6.4: which windows are read. pids: each shown window's process, the one in front first (else the
        // one on top). The COSTAR that window belongs to is the one being mapped: up to `most` of its windows
        // are read. Every other COSTAR open in the session (another branch, a second Tempe) is only listed,
        // as are this COSTAR's windows past `most` (at most `most` listed).
        internal static void Plan(IList<uint> pids,int most,out List<int> read,out List<int> listed) {
            read=new List<int>();listed=new List<int>();
            if(pids==null||pids.Count==0) return;
            for(int i=0;i<pids.Count;i++) {
                if(pids[i]==pids[0]&&read.Count<most) read.Add(i);
                else if(listed.Count<most) listed.Add(i);
            }
        }

        // ---- one map: the COSTAR in front, read; written to maps/ ----
        internal sealed class Result { internal string JsonPath,TextPath,Words="";internal int Windows,Controls,Pressable,Accessible,Hidden,Others;internal bool Cut; }
        internal const long TotalMs=100000,WindowMs=40000;internal const int WindowBudget=5000;
        internal static Result Run() {
            var clock=Stopwatch.StartNew();IntPtr front;var windows=ShownWindows(out front);
            Order.Require(windows.Count>0,"No COSTAR window shows on this PC: open COSTAR (and the screen to map), then map again.");
            var pids=windows.Select(w=>Native.Pid(w)).ToList();
            // COSTAR 1 is the one read; the others are numbered as they come.
            var numbers=new Dictionary<uint,int>();foreach(var p in pids) if(!numbers.ContainsKey(p)) numbers[p]=numbers.Count+1;
            List<int> read,listed;Plan(pids,12,out read,out listed);
            var maps=new List<Dictionary<string,object>>();var result=new Result();var names=new List<string>();
            foreach(int i in read) {
                var w=windows[i];
                if(clock.ElapsedMilliseconds>TotalMs) { result.Cut=true;maps.Add(Listed(w,front,numbers[pids[i]],"not read: the map ran out of time"));continue; }
                Native.Rect r;if(!Native.GetWindowRect(w,out r)) continue;
                string caption=Sanitize.Text(Order.Clean(Native.Caption(w)),80);
                var focus=Native.Focus(w);
                var m=new Dictionary<string,object> {{"handle",w.ToInt64()},{"class",Native.Class(w)},{"caption",caption},{"costar",numbers[pids[i]]},{"front",w==front},
                    {"enabled",Native.IsWindowEnabled(w)},{"owner",Native.GetWindow(w,4).ToInt64()},{"rect",new[]{r.Left,r.Top,r.Right-r.Left,r.Bottom-r.Top}},
                    {"style","0x"+Native.GetWindowLong(w,-16).ToString("X8",CultureInfo.InvariantCulture)},{"menuMode",Native.InMenuMode(w)}};
                // A COSTAR window that doesn't answer within half a second isn't read (each read would wait on it).
                UIntPtr alive;
                if(Native.SendNull(w,0,UIntPtr.Zero,IntPtr.Zero,2,500,out alive)==IntPtr.Zero) { m["busy"]="COSTAR didn't answer within 0.5 s: not read";maps.Add(m);result.Windows++;names.Add(caption.Length>0?caption:Native.Class(w));continue; }
                if(focus!=IntPtr.Zero&&Native.Pid(focus)==Native.Pid(w)) m["keyboardAt"]=new Dictionary<string,object> {{"h",focus.ToInt64()},{"class",Native.Class(focus)},{"kind",Kind(Native.Class(focus),Native.GetWindowLong(focus,-16))}};
                int count,pressable;var masked=new HashSet<string>(StringComparer.Ordinal);bool message=Native.Class(w)=="#32770";var labels=new List<LabelSeen>();
                m["controls"]=Controls(w,r.Left,r.Top,message,masked,labels,out count,out pressable);
                Accessibility.IAccessible acc=null;Walk walk=null;
                long left=Math.Max(1000,Math.Min(WindowMs,TotalMs-clock.ElapsedMilliseconds));
                try { acc=Msaa.FromWindowObject(w,0);walk=Accessible(acc,r.Left,r.Top,WindowBudget,left,masked,message); }   // OBJID_WINDOW: title and menu bars too
                catch(Exception e) { m["accessibleError"]=Sanitize.Text(e.Message,120); }
                finally { Msaa.Release(acc); }
                // What accessibility hid by itself, hidden in the controls too.
                foreach(var l in labels) if(masked.Contains(Norm(l.Words))) l.Item["words"]=Length(l.Words);
                if(walk!=null) {
                    m["accessible"]=walk.Items;m["accessibleRead"]=walk.Seen;m["accessibleHidden"]=walk.Hidden;m["accessibleFrames"]=walk.Frames;m["accessibleMs"]=walk.Clock.ElapsedMilliseconds;
                    if(walk.Cut) { m["accessibleCut"]=true;result.Cut=true; }
                    result.Accessible+=walk.Seen;result.Hidden+=walk.Hidden;
                }
                maps.Add(m);result.Windows++;result.Controls+=count;result.Pressable+=pressable;
                names.Add(caption.Length>0?caption:Native.Class(w));
            }
            foreach(int i in listed) {
                bool other=pids[i]!=pids[0];
                maps.Add(Listed(windows[i],front,numbers[pids[i]],other?"another COSTAR open in this session: listed, not read":"not read: more windows than a map reads"));
                if(other) result.Others++;
            }
            var doc=new Dictionary<string,object> {{"schema",Schema},{"version",AutofillForm.Version},{"atLocal",DateTimeOffset.Now.ToString("o",CultureInfo.InvariantCulture)},
                {"ms",clock.ElapsedMilliseconds},{"read","COSTAR 1: the one in front"+(front==IntPtr.Zero?" (none was: the one on top)":"")},{"windows",maps}};
            Directory.CreateDirectory(Folder);
            string stamp=DateTime.Now.ToString("yyyyMMdd-HHmmss",CultureInfo.InvariantCulture),basePath=Path.Combine(Folder,"map-"+stamp);
            result.JsonPath=basePath+".json";result.TextPath=basePath+".txt";
            File.WriteAllText(result.JsonPath,Wire.Json(doc),new UTF8Encoding(false));
            File.WriteAllText(result.TextPath,Summary(maps),new UTF8Encoding(false));
            result.Words=String.Join(" | ",names.ToArray());
            AppLog.Note("costar_map",result.Windows+" windows, "+result.Controls+" controls, "+result.Accessible+" accessible objects ("+result.Hidden+" hidden parts not read), "+result.Others+" windows of another COSTAR listed, in "+(clock.ElapsedMilliseconds/100/10.0).ToString("0.0",CultureInfo.InvariantCulture)+" s"+(front==IntPtr.Zero?" (no COSTAR window in front)":"")+(result.Cut?" (cut short)":""));
            return result;
        }
        // A window listed only: what it is and where, nothing read from inside it.
        static Dictionary<string,object> Listed(IntPtr w,IntPtr front,int costar,string why) {
            Native.Rect r;bool placed=Native.GetWindowRect(w,out r);
            var m=new Dictionary<string,object> {{"handle",w.ToInt64()},{"class",Native.Class(w)},{"caption",Sanitize.Text(Order.Clean(Native.Caption(w)),80)},{"costar",costar},{"front",w==front},{"listedOnly",why}};
            if(placed) m["rect"]=new[]{r.Left,r.Top,r.Right-r.Left,r.Bottom-r.Top};
            return m;
        }

        // ---- the reader's page: per window, what could be pressed, ticked, switched or chosen directly ----
        // 2.6.4: shorter. The same thing many times (each line's own button) once, counted; a list's rows,
        // cells and items counted under it, its headings in one line; frame parts and states that every
        // box has ("can take the keyboard", "selectable") left out (the .json keeps everything).
        internal static string Summary(List<Dictionary<string,object>> windows) {
            var b=new StringBuilder();
            b.AppendLine("COSTAR map ("+AutofillForm.Version+", "+DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm",CultureInfo.InvariantCulture)+"). Read only: nothing was clicked, typed or changed. Customer words show as [N chars]. Parts that don't show aren't read.");
            foreach(var m in windows) {
                b.AppendLine();
                string head="== "+Str(m,"caption")+" ("+Str(m,"class")+")"+(m.ContainsKey("costar")?" — COSTAR "+Str(m,"costar"):"")+(Flag(m,"front")?" — in front":"")+(Flag(m,"menuMode")?" — a menu has the keyboard":"");
                if(m.ContainsKey("listedOnly")) { b.AppendLine(head+" — "+Str(m,"listedOnly"));continue; }
                b.AppendLine(head);
                if(m.ContainsKey("busy")) { b.AppendLine(Str(m,"busy"));continue; }
                var at=m.ContainsKey("keyboardAt")?m["keyboardAt"] as Dictionary<string,object>:null;
                if(at!=null) b.AppendLine("Keyboard at: "+Str(at,"kind")+" ("+Str(at,"class")+")");
                var controls=m.ContainsKey("controls")?m["controls"] as Dictionary<string,object>:null;
                var items=controls!=null&&controls.ContainsKey("items")?controls["items"] as List<Dictionary<string,object>>:new List<Dictionary<string,object>>();
                var kinds=items.GroupBy(c=>Str(c,"kind")).OrderByDescending(g=>g.Count()).Select(g=>g.Count()+" "+g.Key).ToArray();
                b.AppendLine("Windows' controls: "+(kinds.Length==0?"none":String.Join(", ",kinds)));
                foreach(var g in items.Where(c=>c.ContainsKey("direct")).GroupBy(c=>Str(c,"kind")+" \""+Str(c,"words")+"\": "+Str(c,"direct")+(c.ContainsKey("check")?" (now "+Str(c,"check")+")":"")+(Flag(c,"enabled")?"":" — greyed")))
                    b.AppendLine("  "+g.Key+Times(g.Count()));
                var acc=m.ContainsKey("accessible")?m["accessible"] as List<Dictionary<string,object>>:null;
                if(acc==null) { b.AppendLine("Accessibility: "+(m.ContainsKey("accessibleError")?Str(m,"accessibleError"):"not read"));continue; }
                b.AppendLine("Accessibility: "+acc.Count+" objects read"+(m.ContainsKey("accessibleHidden")?", "+Str(m,"accessibleHidden")+" parts that don't show not read":"")+(Flag(m,"accessibleCut")?" (cut short: more there)":""));
                foreach(var line in AccessibleLines(acc)) b.AppendLine("  "+line);
            }
            return b.ToString();
        }
        static bool IsList(int role) { return role==24||role==33||role==35; }
        static bool InList(int role) { return role==25||role==26||role==28||role==29||role==34||role==36; }
        static int RoleIn(Dictionary<string,object> o) { object v;return o.TryGetValue("role",out v)&&v is int?(int)v:-1; }
        static string Times(int n) { return n>1?" (x"+n.ToString(CultureInfo.InvariantCulture)+")":""; }
        // States worth a reader's eye (every box can take the keyboard; most things are selectable).
        static string Brief(string stateWords) {
            return String.Join(", ",(stateWords??"").Split(new[]{", "},StringSplitOptions.RemoveEmptyEntries).Where(s=>s!="can take the keyboard"&&s!="selectable").ToArray());
        }
        // The accessibility part of a window's page: what has an action or keys, where buttons sit (toolbars,
        // tab lists, menu bars, menus), and each list with what's in it.
        internal static List<string> AccessibleLines(List<Dictionary<string,object>> acc) {
            var lists=acc.Where(o=>IsList(RoleIn(o))).Select(o=>Str(o,"path")).ToList();
            Func<string,string> owner=path=>lists.Where(l=>path.StartsWith(l+".",StringComparison.Ordinal)).OrderByDescending(l=>l.Length).FirstOrDefault();
            var parts=new Dictionary<string,List<Dictionary<string,object>>>();
            foreach(var o in acc) {
                if(!InList(RoleIn(o))) continue;
                string l=owner(Str(o,"path"));if(l==null) continue;
                List<Dictionary<string,object>> p;if(!parts.TryGetValue(l,out p)) parts[l]=p=new List<Dictionary<string,object>>();
                p.Add(o);
            }
            var lines=new List<string>();var counts=new Dictionary<string,int>();
            foreach(var o in acc) {
                if(Flag(o,"frame")) continue;
                int role=RoleIn(o);string path=Str(o,"path");
                if(InList(role)&&owner(path)!=null) continue;
                bool action=o.ContainsKey("action"),keys=o.ContainsKey("keys"),list=IsList(role);
                bool holder=role==22||role==60||role==2||role==11;   // toolbars, tab lists, menu bars, menus
                if(!(action||keys||list||holder||role==25||role==26)) continue;
                string state=Brief(Str(o,"stateWords"));
                string text=Str(o,"kind")+(o.ContainsKey("name")?" \""+Str(o,"name")+"\"":"")+(action?": "+Str(o,"action"):"")+(keys?" ["+Str(o,"keys")+"]":"")+
                    ((list||holder)&&o.ContainsKey("children")?" — "+Str(o,"children")+" in it":"")+(o.ContainsKey("read")?" (read "+Str(o,"read")+")":"")+(state.Length>0?" — "+state:"");
                if(list) {
                    lines.Add(path+" "+text);
                    List<Dictionary<string,object>> p;
                    if(parts.TryGetValue(path,out p)) {
                        var heads=p.Where(x=>RoleIn(x)==25).Select(x=>Str(x,"name")).Where(x=>x.Length>0).ToArray();
                        if(heads.Length>0) lines.Add("    headings: "+String.Join(", ",heads));
                        var rest=p.Where(x=>RoleIn(x)!=25&&RoleIn(x)!=26).GroupBy(x=>Str(x,"kind")+(x.ContainsKey("action")?" ("+Str(x,"action")+")":"")).Select(g=>g.Count().ToString(CultureInfo.InvariantCulture)+" "+g.Key).ToArray();
                        if(rest.Length>0) lines.Add("    read: "+String.Join(", ",rest));
                    }
                    continue;
                }
                int n;
                if(counts.TryGetValue(text,out n)) { counts[text]=n+1;continue; }
                counts[text]=1;lines.Add(path+" "+text);
            }
            // The same thing many times: once, counted (at its first place).
            for(int i=0;i<lines.Count;i++) {
                int space=lines[i].IndexOf(' ');if(space<0||lines[i].StartsWith("    ",StringComparison.Ordinal)) continue;
                int n;if(counts.TryGetValue(lines[i].Substring(space+1),out n)&&n>1) lines[i]+=Times(n);
            }
            return lines;
        }
        static string Str(Dictionary<string,object> d,string key) { object v;return d!=null&&d.TryGetValue(key,out v)&&v!=null?Convert.ToString(v,CultureInfo.InvariantCulture):""; }
        static bool Flag(Dictionary<string,object> d,string key) { object v;return d!=null&&d.TryGetValue(key,out v)&&v is bool&&(bool)v; }
    }
}
