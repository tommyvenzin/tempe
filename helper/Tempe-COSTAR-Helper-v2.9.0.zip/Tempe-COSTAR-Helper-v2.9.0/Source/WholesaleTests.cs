// Self-tests for the wholesale dry run (2.9.0): which orders are opened, the rules (Terms, card details, tyres, the
// stock, what it would do), the list, the Order window, the customer's Notes and the left-hand menu read from
// made-up COSTAR screens. Never opens, clicks or types into COSTAR. Made-up customers, orders and test card numbers
// (the card makers' published test numbers).
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace TempeCostar {
    internal static class WholesaleTests {
        static void Check(bool value,string message){if(!value)throw new InvalidOperationException(message);}
        // A made-up accessibility object: role, name, value, state, action and children.
        sealed class Node : Accessibility.IAccessible {
            internal readonly int Role,State;internal readonly string Name,Value,Action;internal int Pressed;internal readonly List<Node> Kids=new List<Node>();
            internal Node(int role,string name,string value=null,string action="",int state=0) { Role=role;Name=name;Value=value;Action=action;State=state; }
            internal Node Add(params Node[] kids) { Kids.AddRange(kids);return this; }
            object Accessibility.IAccessible.accParent { get { return null; } }
            int Accessibility.IAccessible.accChildCount { get { return Kids.Count; } }
            object Accessibility.IAccessible.get_accChild(object varChild) { int i=Convert.ToInt32(varChild,CultureInfo.InvariantCulture);return i>=1&&i<=Kids.Count?Kids[i-1]:null; }
            string Accessibility.IAccessible.get_accName(object varChild) { return Name; }
            string Accessibility.IAccessible.get_accValue(object varChild) { return Value; }
            string Accessibility.IAccessible.get_accDescription(object varChild) { return ""; }
            object Accessibility.IAccessible.get_accRole(object varChild) { return Role; }
            object Accessibility.IAccessible.get_accState(object varChild) { return State; }
            string Accessibility.IAccessible.get_accHelp(object varChild) { return ""; }
            int Accessibility.IAccessible.get_accHelpTopic(out string pszHelpFile,object varChild) { pszHelpFile="";return 0; }
            string Accessibility.IAccessible.get_accKeyboardShortcut(object varChild) { return ""; }
            object Accessibility.IAccessible.accFocus { get { return null; } }
            object Accessibility.IAccessible.accSelection { get { return null; } }
            string Accessibility.IAccessible.get_accDefaultAction(object varChild) { return Action; }
            void Accessibility.IAccessible.accSelect(int flagsSelect,object varChild) { }
            void Accessibility.IAccessible.accLocation(out int pxLeft,out int pyTop,out int pcxWidth,out int pcyHeight,object varChild) { pxLeft=0;pyTop=0;pcxWidth=10;pcyHeight=10; }
            object Accessibility.IAccessible.accNavigate(int navDir,object varStart) { return null; }
            object Accessibility.IAccessible.accHitTest(int xLeft,int yTop) { return null; }
            void Accessibility.IAccessible.accDoDefaultAction(object varChild) { System.Threading.Interlocked.Increment(ref Pressed); }
            void Accessibility.IAccessible.set_accName(object varChild,string pszName) { }
            void Accessibility.IAccessible.set_accValue(object varChild,string pszValue) { }
        }
        static WholesaleRow Row(string doc,string ordered,string ship,string shipVia,string comment) { return new WholesaleRow {Doc=doc,OrderDate=ordered,ShipDate=ship,ShipVia=shipVia,Comment=comment,Name="TEST CUSTOMER"}; }
        const string ST="WindowsForms10.STATIC.app.0.1",ED="WindowsForms10.EDIT.app.0.1",WN="WindowsForms10.Window.8.app.0.1",SB="WindowsForms10.SCROLLBAR.app.0.1";
        static ControlInfo Mk(long h,long parent,string cls,int x,int y,int w,int hh,string text) {
            return new ControlInfo {Handle=h,Parent=parent,Class=cls,Visible=true,Enabled=true,Bounds=new[]{x,y,w,hh},RelativeBounds=new[]{x,y,w,hh},Text=text,TextState="read"};
        }
        // A box nothing can be typed into (ES_READONLY), as COSTAR's order number and a loaded line's item, words, size, list.
        static ControlInfo RO(ControlInfo c) { c.Style|=WholesaleOrderReader.ReadOnly;return c; }
        // A made-up wholesale Order window laid out as COSTAR's (the 29 and 30 Oct maps). lines[n] = item, description,
        // size, order qty, back order, ship qty ("NOTE" as the item: a note line). expanded: line 1 is open (its box
        // 160 px high, the lines under it 140 px lower).
        static List<ControlInfo> OrderWindow(string number,string terms,string comment,Dictionary<int,string[]> lines,bool notesMarker,bool moreLines,bool expanded) {
            var s=new List<ControlInfo>();long id=1000;
            s.Add(Mk(id++,100,ST,37,83,176,17,"Order"));s.Add(RO(Mk(id++,100,ED,214,82,150,20,number)));s.Add(Mk(id++,100,"WindowsForms10.BUTTON.app.0.1",388,81,60,22,"Ne&xt #"));
            s.Add(Mk(id++,100,ST,389,108,95,15,"Order Date"));s.Add(Mk(id++,100,ST,389,215,95,15,"Terms"));s.Add(Mk(id++,100,ED,389,230,72,20,terms));
            s.Add(Mk(id++,100,ST,389,250,95,15,"Salesperson"));s.Add(Mk(id++,100,ED,389,265,72,20,"TV"));
            s.Add(Mk(id++,100,ST,706,85,51,13,"Comment"));s.Add(Mk(id++,100,ED,782,82,265,20,comment));
            s.Add(Mk(id++,100,ST,274,295,109,15,"PO#"));s.Add(Mk(id++,100,ED,274,310,109,20,"TEST PO"));
            if(notesMarker) s.Add(Mk(id++,100,ST,818,107,74,14,"Notes"));
            foreach(var hd in new[]{Tuple.Create(38,"#"),Tuple.Create(61,"Item"),Tuple.Create(223,"Description"),Tuple.Create(497,"Size"),Tuple.Create(646,"Order Qty"),Tuple.Create(687,"Back order"),Tuple.Create(728,"Ship Qty/Hrs"),Tuple.Create(769,"List"),Tuple.Create(832,"Disc"),Tuple.Create(873,"Net"),Tuple.Create(936,"Tax")})
                s.Add(Mk(id++,200,ST,hd.Item1,341,40,27,hd.Item2));
            s.Add(Mk(id++,200,ST,497,354,70,13,"Complete?"));
            var bar=Mk(id++,200,SB,1030,370,17,475,"");bar.Enabled=moreLines;s.Add(bar);
            for(int n=1;n<=25;n++) {
                int y=370+19*(n-1)+(expanded&&n>1?140:0);long panel=300+n;
                s.Add(Mk(id++,panel,ST,36,y+1,27,19,n.ToString(CultureInfo.InvariantCulture)));
                string[] l;lines.TryGetValue(n,out l);
                s.Add(Mk(id++,panel,ED,63,y,163,20,l==null?"":l[0]));
                s.Add(Mk(id++,panel,ED,107,y,40,20,"03/11/2026"));   // the narrow box behind the item (a date)
                if(l==null) continue;
                if(l[0]=="NOTE") { s.Add(Mk(id++,panel,ED,225,y,806,160,l[1]));continue; }
                s.Add(RO(Mk(id++,panel,ED,225,y,275,expanded&&n==1?160:20,l[1])));s.Add(RO(Mk(id++,panel,ED,499,y,149,20,l[2])));
                s.Add(Mk(id++,panel,ED,648,y,42,20,l[3]));s.Add(Mk(id++,panel,ED,689,y,42,20,l[4]));s.Add(Mk(id++,panel,ED,730,y,42,20,l[5]));
                s.Add(RO(Mk(id++,panel,ED,771,y,64,20,"140.00")));s.Add(Mk(id++,panel,ED,875,y,64,20,"140.00"));
            }
            // The totals (the 3 Nov map: labels in one panel, the amounts under Tax Out, GST and Tax In).
            s.Add(Mk(id++,400,ST,701,847,56,15,"Tax Out"));s.Add(Mk(id++,400,ST,756,847,69,15,"GST"));s.Add(Mk(id++,400,ST,971,847,77,15,"Tax In"));
            s.Add(Mk(id++,400,ST,684,863,73,19,"381.82"));s.Add(Mk(id++,400,ST,753,863,73,19,"38.18"));s.Add(Mk(id++,400,ST,972,863,73,19,"420.00"));
            return s;
        }
        // The stock panel COSTAR shows under a line once it has been the open one (the 3 Nov maps): "Frame1" in the line's
        // panel, holding the stock panel (On hand / - Commit / = Avail / On Order down the left, "ThisBr      OtherBrs"
        // over two columns of read-only boxes), and "NON-STOCKING!" over it when the item isn't stocked.
        static void StockPanel(List<ControlInfo> s,long linePanel,int y,string thisAvail,string otherAvail,bool nonStocking,bool heading=true,bool twice=false) {
            long frame=linePanel*100+1,stock=linePanel*100+2,id=linePanel*1000;int top=y+26;
            s.Add(Mk(frame,linePanel,WN,39,top,900,130,"Frame1"));s.Add(Mk(stock,frame,WN,39,top+20,165,111,""));
            if(nonStocking) s.Add(Mk(id++,frame,ST,43,top+22,154,17,"NON-STOCKING!"));
            if(heading) s.Add(Mk(id++,stock,ST,104,top+20,101,17,"ThisBr      OtherBrs"));
            string[] rows={"On hand","- Commit","= Avail","On Order"};
            for(int i=0;i<rows.Length;i++) {
                int ry=top+33+19*i;s.Add(Mk(id++,stock,ST,39,ry+1,66,17,rows[i]));
                s.Add(Mk(id++,stock,ED,104,ry,50,20,rows[i]=="= Avail"?thisAvail:i==0?"9":"0"));s.Add(Mk(id++,stock,ED,153,ry,50,20,rows[i]=="= Avail"?otherAvail:"5"));
            }
            if(twice) s.Add(Mk(id++,stock,ST,39,top+120,66,17,"= Avail"));
            s.Add(Mk(id++,frame,ED,474,top,234,20,"TEST SUPPLIER ITEM"));s.Add(Mk(id++,frame,ST,710,top+3,50,14,"Sup List"));
        }
        static Dictionary<int,string[]> Lines() {
            return new Dictionary<int,string[]> {
                {1,new[]{"W43116","WINRUN 265/70R16 112T MAXCLAW A/T","265/70R16","4","4",""}},
                {2,new[]{"FREIGHT","FREIGHT CHARGE","","1","1",""}},
                {3,new[]{"NOTE","TEST NOTE FOR THE MADE-UP ORDER","","","",""}}
            };
        }
        static WholesaleLook Look(string terms,List<bool?> notes,bool marker,params WholesaleLine[] lines) {
            var l=new WholesaleLook {Row=Row("WO9000001","01/11/2026","03/11/2026","BUFRIV",""),Opened=true,Terms=terms,NotesMarker=marker,OrderComment="WWW"};
            if(notes!=null) { l.NotesRead.AddRange(notes);l.NotesShown=notes.Count>0; }
            l.Lines.AddRange(lines);l.Card=WholesaleRules.CardFrom(l.NotesRead,marker);
            return l;
        }
        // A tyre line: ThisBr "= Avail" (null: not read) and its Order Qty (4 unless said).
        static WholesaleLine Tyre(int n,int? available,string qty="4") { return new WholesaleLine {Number=n,Item="W4311"+n,Description="WINRUN 265/70R16",Size="265/70R16",OrderQty=qty,Tyre=true,Available=available}; }
        static WholesaleLine Other(int n) { return new WholesaleLine {Number=n,Item="FREIGHT",Description="FREIGHT CHARGE",OrderQty="1"}; }
        internal static void Cases(Action<string,Action> Case) {
            Case("Wholesale (2.9.0): which orders the dry run opens (BUF, the Comment, the ShipDate), oldest first",()=>{
                string today="2026-11-03";
                foreach(var via in new[]{"BUFRIV","BUFWEST","BUFF","bufnewc"," BUFGLBN"}) Check(WholesaleRules.Screen(Row("WO1","01/11/2026","03/11/2026",via,""),today)==null,"Ship Via "+via+" is BUF.");
                foreach(var via in new[]{"DXTDUB","SHOP","","XBUF"}) Check(WholesaleRules.Screen(Row("WO1","01/11/2026","03/11/2026",via,""),today)=="not BUF","Ship Via \""+via+"\" isn't BUF.");
                foreach(var c in new[]{"","WWW","www","BUF","BUFF","BUFFALO","WWW BUF","WWW BUFF","www  buffalo"," WWW "}) Check(WholesaleRules.Screen(Row("WO1","01/11/2026","03/11/2026","BUFRIV",c),today)==null,"Comment \""+c+"\" is to be done.");
                foreach(var c in new[]{"B/O","B/O BUFFALO","AWAITING TT","AWAITING TT BUFFALO","WAITING TT","GAT","NO STOCK NO ANSWER 3:27","AT 11","AT 3","2/11","coming from roselands","CHECK STOCK","WWW CHECK STOCK","NO CARD DETAILS","BUFFALO WWW","WWW.","WWW-BUFF"})
                    Check((WholesaleRules.Screen(Row("WO1","01/11/2026","03/11/2026","BUFRIV",c),today)??"").Contains("someone is on it"),"Comment \""+c+"\": someone is on it.");
                Check(WholesaleRules.Screen(Row("WO1","01/11/2026","04/11/2026","BUFRIV",""),today).Contains("after today"),"A ShipDate after today waits.");
                Check(WholesaleRules.Screen(Row("WO1","01/11/2026","03/11/2026","BUFRIV",""),today)==null&&WholesaleRules.Screen(Row("WO1","01/11/2026","28/10/2026","BUFRIV",""),today)==null&&WholesaleRules.Screen(Row("WO1","01/11/2026","","BUFRIV",""),today)==null,"Today, earlier and no ShipDate are done.");
                Check(WholesaleRules.Screen(Row("WO1","01/11/2026","3rd Nov","BUFRIV",""),today).Contains("can't be read"),"An unreadable ShipDate isn't opened.");
                var order=WholesaleRules.Oldest(new[]{Row("WO3","02/11/2026","","BUFF",""),Row("WO4","","","BUFF",""),Row("WO1","30/10/2026","","BUFF",""),Row("WO2","30/10/2026","","BUFF",""),Row("WO0","??","","BUFF","")});
                Check(String.Join(",",order.Select(r=>r.Doc).ToArray())=="WO1,WO2,WO3,WO0,WO4","Oldest first, then by number, an empty or unreadable date last: "+String.Join(",",order.Select(r=>r.Doc).ToArray()));
            });
            Case("Wholesale (2.9.0): Terms, card details in the Notes (yes/no only), tyres and what it would do",()=>{
                foreach(var t in new[]{"30INV","1INV","7ST","COD","EOM","CASH","cash","14ST CUSTOMER"}) Check(Array.IndexOf(WholesaleRules.TermCodes,WholesaleRules.TermCode(t))>=0,"Terms "+t+" are COSTAR's.");
                Check(WholesaleRules.TermCode("")==""&&WholesaleRules.TermCode("  ")=="","Empty Terms.");
                // The card makers' test numbers, made-up words.
                Check(WholesaleRules.CardDetails(new[]{"PAY BY CARD 4111 1111 1111 1111 EXP 05/27 CVV 123"}),"Visa test number with its expiry.");
                Check(WholesaleRules.CardDetails(new[]{"MC 5555-5555-5555-4444 12/2028"}),"Mastercard test number, dashes, a four-digit year.");
                Check(WholesaleRules.CardDetails(new[]{"ACCOUNT CUSTOMER","AMEX 3782 822463 10005 EXPIRY 0726"}),"Amex test number (4-6-5) with its expiry, in the second note.");
                Check(!WholesaleRules.CardDetails(new[]{"AMEX 3782 822463 10005","EXPIRY 0726"}),"The number in one note and an expiry in another: not card details (can't be sure they go together).");
                Check(!WholesaleRules.CardDetails(new[]{"IMEI 490154203237518 DELIVERY 12.25"})&&!WholesaleRules.CardDetails(new[]{"IMEI 490154203237518 DELIVERY 12.50"})&&!WholesaleRules.CardDetails(new[]{"IMEI 490154203237518 CALLED 2/11"})&&!WholesaleRules.CardDetails(new[]{"4111 1111 1111 1111 PAID 12.50 ON 02/11/2026"}),"A price, a day/month date or a full date isn't an expiry.");
                Check(WholesaleRules.CardDetails(new[]{"4111-1111-1111-1111 EXP: 12-29"})&&WholesaleRules.CardDetails(new[]{"CARD 4111111111111111 2/2031"}),"Expiries with a dash, and a month with a four-digit year.");
                Check(WholesaleRules.CardDetails(new[]{"4111111111111111 exp 1/27"}),"A number in one run, a one-digit month.");
                Check(WholesaleRules.CardDetails(new[]{"VISA 4111 1111 1111 1111 123 05/27"}),"A number followed by its CVV, then the expiry.");
                Check(!WholesaleRules.CardDetails(new[]{"4111 1111 1111 1112 EXP 05/27"}),"A number that fails the check digit isn't a card.");
                Check(!WholesaleRules.CardDetails(new[]{"4111 1111 1111 1111"}),"A card number without an expiry isn't card details.");
                Check(!WholesaleRules.CardDetails(new[]{"CALLED 2/11/2026 PH 0412 345 678 SAYS PAY ON PICKUP"}),"A date and a phone number aren't card details.");
                Check(!WholesaleRules.CardDetails(new[]{"ABN 51 824 753 556 INV 02/11"}),"An ABN isn't a card number.");
                Check(!WholesaleRules.CardDetails(new string[0])&&!WholesaleRules.CardDetails(null),"No notes, no card details.");
                Check(WholesaleRules.CardFrom(new List<bool?>{false,true},false)==true&&WholesaleRules.CardFrom(new List<bool?>{null,true},true)==true&&WholesaleRules.CardFrom(new List<bool?>{false,null},false)==null&&WholesaleRules.CardFrom(new List<bool?>{false},true)==false,"Card details from the Notes that popped up.");
                Check(WholesaleRules.CardFrom(new List<bool?>(),false)==false&&WholesaleRules.CardFrom(new List<bool?>(),true)==null,"No Notes popped up: none, unless the order has notes all the same.");
                Check(!WholesaleRules.MayHaveNotes(false,"Ship to")&&WholesaleRules.MayHaveNotes(false,"Notes")&&WholesaleRules.MayHaveNotes(false,null)&&WholesaleRules.MayHaveNotes(true,"Ship to"),"The Notes marker can't be seen with the Notes tab showing (or the tab unknown).");
                foreach(var size in new[]{"205/55R16","245/45ZR18","225/45 R17","LT245/75R16","265/70-16","P225/60R16","31X10.50R15","33X12.50R20LT","7.50R16","7.00-16","195R15C","11R22.5","295/80R22.5","255/35 ZR19 96Y","225/45RF17"}) Check(WholesaleRules.Tyre(size,""),size+" is a tyre.");
                foreach(var size in new[]{"17X8.0","5/114.3","18X9.5 6X139.7","","FREIGHT","16","750-16"}) Check(!WholesaleRules.Tyre(size,"KING 17X8 ET35 6/139.7 BLACK"),"\""+size+"\" isn't a tyre.");
                Check(WholesaleRules.Tyre("","WINRUN 265/70R16 112T MAXCLAW A/T"),"A tyre by its description when its Size is empty.");
                Check(!WholesaleRules.Enough(4)&&WholesaleRules.Enough(5)&&!WholesaleRules.Enough(0)&&!WholesaleRules.Enough(-1),"Enough: more than 4 available.");
                Check(WholesaleRules.WithWords("","CHECK STOCK")=="CHECK STOCK"&&WholesaleRules.WithWords(" WWW ","CHECK STOCK")=="WWW CHECK STOCK","Words go at the end of the Comment.");
                var none=new List<bool?>();
                Func<WholesaleLook,string> act=l=>WholesaleRules.Decide(l).Action;
                Check(act(Look("30INV",none,false,Tyre(1,null),Other(2)))=="stock","Stock not read yet: the dry run says so.");
                Check(act(Look("30INV",none,false,Tyre(1,5),Tyre(2,9),Other(3)))=="sell","Every tyre more than 4: sell.");
                var shortOne=WholesaleRules.Decide(Look("30INV",none,false,Tyre(1,5),Tyre(2,0)));
                Check(shortOne.Action=="comment"&&shortOne.Words=="CHECK STOCK"&&shortOne.Why.Contains("line 2")&&shortOne.Why.Contains("= Avail 0 in Sydney + 4 on this order = 4"),"One tyre with 4 counting this order's own: CHECK STOCK ("+shortOne.Why+").");
                Check(act(Look("30INV",none,false,Tyre(1,5),Tyre(2,null)))=="stock"&&act(Look("30INV",none,false,Tyre(1,-2),Tyre(2,null)))=="comment","Short wins over unread; unread wins over enough.");
                // Tommy, 3 Nov: this order's own tyres are in COSTAR's Commit, so they're added back to "= Avail".
                Check(act(Look("30INV",none,false,Tyre(1,4)))=="sell"&&act(Look("30INV",none,false,Tyre(1,1)))=="sell"&&act(Look("30INV",none,false,Tyre(1,0)))=="comment"&&act(Look("30INV",none,false,Tyre(1,2,"2")))=="comment"&&act(Look("30INV",none,false,Tyre(1,3,"2.00")))=="sell","\"= Avail\" plus this order's Order Qty more than 4: 4+4, 1+4 and 3+2 sell; 0+4 and 2+2 don't.");
                var twoA=Tyre(1,1,"2");var twoB=Tyre(2,1,"2");twoB.Item=twoA.Item;
                Check(act(Look("30INV",none,false,twoA,twoB))=="sell","The same tyre on two lines: both lines' Order Qty added back (1+2+2).");
                twoA.Available=0;twoB.Available=0;Check(act(Look("30INV",none,false,twoA,twoB))=="comment","... and 0+2+2 doesn't sell.");
                var noQty=WholesaleRules.Decide(Look("30INV",none,false,Tyre(1,9,"")));var oddQty=WholesaleRules.Decide(Look("30INV",none,false,Tyre(1,9,"4 PCS")));
                Check(noQty.Action=="stock"&&noQty.Why.Contains("Order Qty is empty")&&oddQty.Action=="stock"&&oddQty.Why.Contains("reads"),"An Order Qty that can't be read: the stock isn't checked, and why ("+noQty.Why+").");
                Check(WholesaleRules.StockWords(Look("30INV",none,false,Tyre(1,4)),Tyre(1,4))=="= Avail 4 in Sydney + 4 on this order = 8","The tab's words for a line's stock.");
                var cash=WholesaleRules.Decide(Look("CASH",new List<bool?>{false},false,Tyre(1,9)));
                Check(cash.Action=="comment"&&cash.Words=="NO CARD DETAILS","CASH without card details: a comment, the stock not looked at.");
                Check(act(Look("CASH",new List<bool?>{true},false,Tyre(1,9)))=="sell"&&act(Look("CASH",new List<bool?>{true},false,Tyre(1,0)))=="comment","CASH with card details goes on to the stock.");
                Check(act(Look("CASH",new List<bool?>{null},false,Tyre(1,9)))=="leave"&&act(Look("CASH",none,true,Tyre(1,9)))=="leave","CASH whose card details can't be told: left alone.");
                Check(act(Look("CASH",none,false,Tyre(1,9)))=="comment","CASH, no Notes at all: no card details.");
                Check(act(Look("",none,false,Tyre(1,9)))=="leave"&&act(Look(null,none,false,Tyre(1,9)))=="leave"&&act(Look("90DAYS",none,false,Tyre(1,9)))=="leave","Terms empty, unreadable or unknown: left alone.");
                Check(WholesaleRules.Decide(Look("",none,false,Tyre(1,9))).Why.Contains("empty")&&WholesaleRules.Decide(Look(null,none,false,Tyre(1,9))).Why.Contains("couldn't be read")&&WholesaleRules.Decide(Look("90DAYS",none,false,Tyre(1,9))).Why.Contains("aren't one of COSTAR's codes"),"Each says why.");
                var now=Look("30INV",none,false,Tyre(1,9));now.OrderComment="AT 11";
                var nowV=WholesaleRules.Decide(now);Check(nowV.Action=="leave"&&nowV.Why.Contains("now says"),"The order's own Comment changed to AT 11 since the list was read: left alone.");
                now.OrderComment=null;Check(WholesaleRules.Decide(now).Why.Contains("Comment couldn't be read"),"The order's Comment unreadable: left alone.");
                now.OrderComment=" www buff ";Check(WholesaleRules.Decide(now).Action=="sell","The order's Comment still to do (any case, spaces).");
                var noTyre=WholesaleRules.Decide(Look("7ST",none,false,Other(1)));
                Check(noTyre.Action=="sell"&&noTyre.Why.Contains("no tyre lines"),"No tyre lines: only tyres are checked (said).");
                Check(act(Look("7ST",none,false))=="leave","No item lines read: left alone.");
                var more=Look("7ST",none,false,Tyre(1,9));more.MoreLines=true;Check(act(more)=="leave","More than 25 lines: left alone.");
                var changed=Look("7ST",none,false,Tyre(1,9));changed.Problem="it changed in the list meanwhile";Check(act(changed)=="leave","A problem: left alone.");
                Check(WholesaleRules.Plain(WholesaleRules.Decide(Look("30INV",none,false,Tyre(1,9)))).StartsWith("Would SELL",StringComparison.Ordinal),"Plain words for the tab.");
                Check(WholesaleRules.Message("Someone used the COSTAR PC while Repair Order WO1 was being opened. COSTAR's Work-in-Progress list is covered.")=="Someone used the COSTAR PC while Order WO1 was being opened. COSTAR's wholesale list is covered.","The open's words for an Order.");
            });
            Case("Wholesale (2.9.0): \"Orders yet to be filled\" read from a made-up list",()=>{
                string[] cols={"Order Date","ShipDate","Document #","Name","Comment","Phone","Written By","PO","PO Total","Ship Via","Source"};
                Func<string[],Node> row=delegate(string[] v) { var r=new Node(28,"row");for(int i=0;i<cols.Length;i++) r.Add(new Node(29,cols[i],v[i]));return r; };
                var head=new Node(28,"headings");foreach(var c in cols) head.Add(new Node(25,c));
                var table=new Node(24,"Table").Add(head,
                    row(new[]{"01/11/2026","03/11/2026","WO9000002","TEST CUSTOMER TWO","WWW","0400000002","WWW","TWW1","200.00","BUFRIV","MDX"}),
                    row(new[]{"30/10/2026","30/10/2026","WO9000001","TEST CUSTOMER","","0400000001","Web","","100.00","BUFF","Web Order"}),
                    row(new[]{"30/10/2026","","OR9000003","TEST CUSTOMER THREE","B/O","","TV","","","DXTDUB",""}),
                    row(new[]{"30/10/2026","30/10/2026","WO9000001","TEST CUSTOMER","","0400000001","Web","","100.00","BUFF","Web Order"}));
                var client=new Node(10,"ultraGrid1").Add(table);
                var rows=WholesaleList.Read(()=>client);
                Check(rows.Count==3,"Three orders (one listed twice): "+rows.Count);
                var a=rows.First(r=>r.Doc=="WO9000002");
                Check(a.OrderDate=="01/11/2026"&&a.ShipDate=="03/11/2026"&&a.Comment=="WWW"&&a.ShipVia=="BUFRIV"&&a.Name=="TEST CUSTOMER TWO"&&a.Po=="TWW1"&&a.PoTotal=="200.00"&&a.Source=="MDX"&&a.By=="WWW","The cells by their columns.");
                var hidden=new Node(10,"ultraGrid1").Add(new Node(24,"Table").Add(new Node(28,"row").Add(new Node(29,"Document #","WO1"),new Node(29,"Order Date","01/11/2026"),new Node(29,"ShipDate",""),new Node(29,"Comment",""),new Node(29,"Ship Via","HIDDEN",null,0x8000),new Node(29,"Ship Via","BUFRIV"),new Node(29,"ShipVia","OTHER"))));
                var shownVia=WholesaleList.Read(()=>hidden);
                Check(shownVia.Count==1&&shownVia[0].ShipVia=="BUFRIV","The shown Ship Via cell, by its exact name: "+(shownVia.Count>0?shownVia[0].ShipVia:"none"));
                var noVia=new Node(10,"ultraGrid1").Add(new Node(24,"Table").Add(new Node(28,"row").Add(new Node(29,"Document #","WO1"),new Node(29,"Order Date","01/11/2026"),new Node(29,"ShipDate",""),new Node(29,"Comment",""))));
                string error=null;try { WholesaleList.Read(()=>noVia); } catch(InvalidOperationException e) { error=e.Message; }
                Check(error!=null&&error.Contains("Ship Via"),"A list without its Ship Via column stops: "+error);
            });
            Case("Wholesale (2.9.0): the Order window read from made-up controls (number, Terms, Comment, lines, tyres)",()=>{
                Func<ControlInfo,string> text=c=>c.Text;
                var v=WholesaleOrderReader.Parse(OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false),text);
                Check(v.Problem==null,"Read without a problem: "+v.Problem);
                Check(v.Number=="WO9000001"&&v.Terms=="30INV"&&v.Comment=="WWW"&&!v.NotesMarker&&!v.MoreLines,"Number, Terms, Comment: "+v.Number+" "+v.Terms+" "+v.Comment);
                Check(v.Lines.Count==3,"Three lines (the empty ones skipped): "+v.Lines.Count);
                var tyre=v.Lines[0];Check(tyre.Number==1&&tyre.Item=="W43116"&&tyre.Size=="265/70R16"&&tyre.OrderQty=="4"&&tyre.BackOrder=="4"&&tyre.ShipQty==""&&tyre.Tyre&&!tyre.Note,"Line 1, the tyre: "+tyre.Item+" "+tyre.Size+" "+tyre.OrderQty);
                Check(!v.Lines[1].Tyre&&!v.Lines[1].Note&&v.Lines[1].Item=="FREIGHT","Line 2: freight, not a tyre.");
                Check(v.Lines[2].Note&&!v.Lines[2].Tyre&&v.Lines[2].Description=="","Line 3: a note line, its words not read.");
                var open=WholesaleOrderReader.Parse(OrderWindow("WO9000001","CASH","",Lines(),true,false,true),text);
                Check(open.Problem==null&&open.Lines.Count==3&&open.Lines[0].Tyre&&open.Lines[2].Note&&open.NotesMarker&&open.Terms=="CASH","Line 1 open (expanded), the others lower; the Notes marker seen.");
                Check(WholesaleOrderReader.Parse(OrderWindow("WO9000001","30INV","",Lines(),false,true,false),text).MoreLines,"The lines' scroll bar on: more lines than show.");
                var unread=WholesaleOrderReader.Parse(OrderWindow("WO9000001","30INV","",Lines(),false,false,false),c=>c.X==648?null:c.Text);
                Check(unread.Problem!=null&&unread.Problem.Contains("line 1"),"A box that can't be read: a problem ("+unread.Problem+").");
                var noTerms=WholesaleOrderReader.Parse(OrderWindow("WO9000001","30INV","",Lines(),false,false,false),c=>c.X==389&&c.Y==230?null:c.Text);
                Check(noTerms.Terms==null&&WholesaleRules.Decide(new WholesaleLook {Row=Row("WO9000001","","","BUFF",""),Terms=noTerms.Terms,OrderComment=""}).Why.Contains("Terms couldn't be read"),"Terms that can't be read: left alone.");
                var twoLabels=OrderWindow("WO9000001","30INV","",Lines(),false,false,false);twoLabels.Add(Mk(9000,100,ST,37,120,176,17,"Order"));twoLabels.Add(Mk(9001,100,ED,214,119,150,20,"WO9000002"));
                Check(WholesaleOrderReader.Number(twoLabels,text)==null,"Two \"Order\" labels: its number can't be told.");
                Check(WholesaleOrderReader.Number(OrderWindow("WO9000001","30INV","",Lines(),false,false,false),text)=="WO9000001"&&WholesaleOrderReader.Number(OrderWindow("WO9000001","30INV","",Lines(),false,false,false),c=>c.X==214?null:c.Text)==null,"The number on its own (null when its box can't be read).");
                var notOrder=OrderWindow("WO9000001","30INV","",Lines(),false,false,false).Where(c=>c.Text!="Order Qty").ToList();
                Check(WholesaleOrderReader.Parse(notOrder,text).Problem!=null,"No Order Qty heading (not a wholesale Order): a problem.");
            });
            Case("Wholesale (2.9.0): Sydney's stock on an opened tyre line (ThisBr = Avail; NON-STOCKING), from made-up screens laid out as the 3 Nov maps",()=>{
                Func<ControlInfo,string> text=c=>c.Text;
                Func<string,string,bool,List<ControlInfo>> win=delegate(string mine,string others,bool notStocked) { var s=OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false);StockPanel(s,301,370,mine,others,notStocked);return s; };
                var s1=win("12","40",false);
                var v=WholesaleOrderReader.Parse(s1,text);
                Check(v.Problem==null&&v.Lines.Count==3&&v.Lines[0].Panel==301&&v.Lines[0].Opens==s1.First(c=>c.Parent==301&&c.X==225).Handle,"The stock panel doesn't upset the lines; line 1 opens through its words.");
                var r=WholesaleOrderReader.Stock(s1,301,text);
                Check(r.Found&&r.Available==12&&!r.NonStocking&&r.Problem==null,"ThisBr = Avail read (12, not OtherBrs' 40): "+r.Available+" "+r.Problem);
                Check(!WholesaleOrderReader.Stock(s1,302,text).Found,"Line 2 hasn't been open: no stock panel.");
                Check(WholesaleOrderReader.Stock(win("-1","0",false),301,text).Available==-1&&WholesaleOrderReader.Stock(win("4.00","0",false),301,text).Available==4&&WholesaleOrderReader.Stock(win("1,234","0",false),301,text).Available==1234&&WholesaleOrderReader.Stock(win("4.5","0",false),301,text).Available==4,"Negative, decimal and grouped numbers; a part one rounded down.");
                var non=WholesaleOrderReader.Stock(win("","",true),301,text);
                Check(non.Found&&non.NonStocking&&non.Available==null&&non.Problem==null,"NON-STOCKING!: empty boxes, not stocked.");
                Check(WholesaleOrderReader.Stock(win("","",false),301,text).Problem.Contains("empty")&&WholesaleOrderReader.Stock(win("n/a","",false),301,text).Problem.Contains("reads"),"Empty or odd without NON-STOCKING!: a problem.");
                Check(WholesaleOrderReader.Stock(s1,301,c=>c.X==104&&c.Class==ED?null:c.Text).Problem.Contains("couldn't be read"),"A box that can't be read: a problem.");
                var noHead=OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false);StockPanel(noHead,301,370,"12","40",false,false);
                Check(WholesaleOrderReader.Stock(noHead,301,text).Problem.Contains("heading"),"No ThisBr heading: a problem (OtherBrs isn't taken for it).");
                var twice=OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false);StockPanel(twice,301,370,"12","40",false,true,true);
                Check(WholesaleOrderReader.Stock(twice,301,text).Problem.Contains("2 times"),"Two = Avail labels: a problem.");
                var bare=OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false);bare.Add(Mk(9001,301,WN,39,396,900,130,"Frame1"));bare.Add(Mk(9002,9001,ST,43,418,154,17,"NON-STOCKING!"));
                var alone=WholesaleOrderReader.Stock(bare,301,text);
                Check(alone.Found&&alone.NonStocking&&alone.Available==null,"NON-STOCKING! without its stock panel: not stocked, not \"didn't open\".");
                Check(WholesaleOrderReader.Stock(win("99999999999","0",false),301,text).Problem.Contains("too big"),"A number too big to be stock: a problem (not a crash).");
                var stray=win("12","40",false);stray.Add(Mk(9101,30101,ST,600,420,40,15,"Item"));stray.Add(Mk(9102,30101,ST,650,420,40,15,"Net"));
                var sv=WholesaleOrderReader.Parse(stray,text);
                Check(sv.Problem==null&&sv.Lines.Count==3&&WholesaleOrderReader.Changed(WholesaleOrderReader.Fingerprint(s1,text),WholesaleOrderReader.Fingerprint(stray,text))==null,"Words like Item or Net inside an opened line's panel aren't taken for the lines' headings.");
                var noBox=OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false);noBox.Remove(noBox.First(c=>c.X==214&&c.Y==82));
                Check(WholesaleOrderReader.Number(noBox,text)==null&&WholesaleOrderReader.NumberBox(noBox)==null,"No number box: no number (the Next # button beside it isn't taken).");
                var editable=OrderWindow("WO9000001","30INV","WWW",Lines(),false,false,false);editable.First(c=>c.Parent==302&&c.X==225).Style=0;
                var ev=WholesaleOrderReader.Parse(editable,text);
                Check(ev.Lines[1].Opens==0&&ev.Lines[0].Opens!=0,"A line whose words box can be typed into isn't opened (never its item box instead).");
                var nonLine=Tyre(1,null);nonLine.NonStocking=true;
                var nv=WholesaleRules.Decide(Look("30INV",new List<bool?>(),false,nonLine,Tyre(2,9)));
                Check(nv.Action=="comment"&&nv.Words=="CHECK STOCK"&&nv.Why.Contains("NON-STOCKING"),"A NON-STOCKING tyre: CHECK STOCK ("+nv.Why+").");
                var why=Tyre(1,null);why.StockWhy="the line didn't open";
                var wv=WholesaleRules.Decide(Look("30INV",new List<bool?>(),false,why,Tyre(2,9)));
                Check(wv.Action=="stock"&&wv.Why.Contains("didn't open"),"A tyre whose stock couldn't be read: not sold, and why ("+wv.Why+").");
            });
            Case("Wholesale (2.9.0): the order read again after its tyre lines were opened: a line's box, the Comment, Terms or the totals changed, a box gone, a line new; the stock panels and a note's words left out",()=>{
                var asked=new List<ControlInfo>();
                Func<ControlInfo,string> text=c=>{ asked.Add(c);return c.Text; };
                var lines=Lines();lines[4]=new[]{"NOTE","TEST NOTE WORDS"};
                Func<List<ControlInfo>> win=()=>OrderWindow("WO9000001","30INV","WWW",lines,false,false,false);
                var s=win();var before=WholesaleOrderReader.Fingerprint(s,text);
                Check(before.ContainsKey("line 1 ORDER QTY")&&before.ContainsKey("line 1 DESCRIPTION")&&before.ContainsKey("line 1 NET")&&before.ContainsKey("line 1 box at 107")&&before.ContainsKey("line 25 ITEM")&&before["Comment"]=="WWW"&&before["Terms"]=="30INV"&&before["the order's number"]=="WO9000001"&&before["the totals at 972,863"]=="420.00","Lines by number and heading, the Comment, Terms, the number and the totals: "+String.Join(", ",before.Keys.Take(12).ToArray()));
                Check(!asked.Any(c=>c.W>=600)&&!before.Values.Contains("TEST NOTE WORDS"),"A note line's words aren't read.");
                var same=win();StockPanel(same,301,370,"12","40",false);StockPanel(same,302,389,"","",true);
                Check(WholesaleOrderReader.Changed(before,WholesaleOrderReader.Fingerprint(same,text))==null,"Stock panels shown under lines: nothing changed.");
                var shownBefore=win();StockPanel(shownBefore,301,370,"12","40",false);var shownAfter=win();StockPanel(shownAfter,301,370,"11","39",false);
                Check(WholesaleOrderReader.Changed(WholesaleOrderReader.Fingerprint(shownBefore,text),WholesaleOrderReader.Fingerprint(shownAfter,text))==null,"A stock panel there before and after with other numbers: the order didn't change.");
                var qty=win();qty.First(c=>c.Parent==301&&c.X==648).Text="5";
                Check(WholesaleOrderReader.Changed(before,WholesaleOrderReader.Fingerprint(qty,text))=="line 1 ORDER QTY","A line's Order Qty changed: said.");
                var net=win();net.First(c=>c.Parent==302&&c.X==875).Text="99.00";
                Check(WholesaleOrderReader.Changed(before,WholesaleOrderReader.Fingerprint(net,text))=="line 2 NET","A line's Net changed: said.");
                var comment=win();comment.First(c=>c.X==782&&c.Y==82).Text="WWW CHECK STOCK";
                Check(WholesaleOrderReader.Changed(before,WholesaleOrderReader.Fingerprint(comment,text))=="Comment","The Comment changed: said.");
                var total=win();total.First(c=>c.X==972&&c.Y==863).Text="430.00";
                Check(WholesaleOrderReader.Changed(before,WholesaleOrderReader.Fingerprint(total,text))=="the totals at 972,863","The totals changed: said.");
                var gone=win();gone.Remove(gone.First(c=>c.Parent==301&&c.X==499));
                Check(WholesaleOrderReader.Changed(before,WholesaleOrderReader.Fingerprint(gone,text))=="line 1 SIZE (gone)","A box gone: said.");
                var fewer=WholesaleOrderReader.Fingerprint(win().Where(c=>c.Parent!=325).ToList(),text);
                Check(WholesaleOrderReader.Changed(fewer,WholesaleOrderReader.Fingerprint(win(),text))=="line 25 box at 107 (new)","A line that wasn't there before: said.");
                var unread=WholesaleOrderReader.Fingerprint(win(),c=>c.Parent==302&&c.X==648?null:c.Text);
                Check(WholesaleOrderReader.Changed(before,unread)=="line 2 ORDER QTY","A box that couldn't be read: not taken as the same.");
            });
            Case("Wholesale (2.9.0): card details in a made-up Notes window (yes / no / can't tell), the words kept nowhere",()=>{
                Func<string[],Node> notes=delegate(string[] texts) {
                    var pane=new Node(16,"").Add(new Node(28,"Top Row").Add(new Node(25,"Top Left Header Cell"),new Node(25,"Note[Column Header]"),new Node(25,"[Column Header]"),new Node(25,"Date[Column Header]"),new Node(25,"Entered By[Column Header]")));
                    for(int i=0;i<texts.Length;i++) { string n="Row"+i;pane.Add(new Node(28,"x").Add(new Node(26,n),new Node(29,"Note "+n,texts[i]),new Node(29," "+n,""),new Node(29,"Date "+n,"02/11/2026"),new Node(29,"Entered By "+n,"TV"))); }
                    return new Node(9,"Notes").Add(new Node(1,""),new Node(10,"Notes").Add(new Node(9,"").Add(new Node(10,"").Add(new Node(22,"").Add(new Node(43,"New",null,"Press")),new Node(9,"").Add(new Node(10,"").Add(pane)))),new Node(9,"OK").Add(new Node(43,"OK",null,"Press"))));
                };
                Check(WholesaleNotes.Card(()=>notes(new[]{"ACCOUNT CUSTOMER","PAY BY CARD 5555 5555 5555 4444 EXP 12/28"}))==true,"Card details in the second note.");
                Check(WholesaleNotes.Card(()=>notes(new[]{"CALL BEFORE DISPATCH 0400 000 001"}))==false,"No card details.");
                Check(WholesaleNotes.Card(()=>notes(new string[0]))==false,"The Notes list empty: no card details.");
                Check(WholesaleNotes.Card(()=>new Node(9,"Notes").Add(new Node(10,"Notes")))==null,"No Note column found: can't tell.");
            });
            Case("Wholesale (2.9.0): the left-hand menu's item found by name and pressed through accessibility; the Order windows told apart",()=>{
                Func<Node[]> items=()=>new[]{new Node(43,"Wholesale Order",null,"Press"),new Node(43,"Quotation",null,"Press"),new Node(43,"Repair Order",null,"Press"),new Node(43,"Invoice",null,"Press")};
                var outline=new Node(35,"").Add(new Node(64,"Order Entry",null,"Collapse"));outline.Add(items());
                var root=new Node(10,"COSTAR").Add(new Node(9,"").Add(new Node(10,"Advanced Search")),new Node(9,"").Add(outline));
                object child;string why;
                var found=CostarMenu.Find(root,"Wholesale Order",out child,out why) as Node;
                Check(found!=null&&child==null&&found.Name=="Wholesale Order","Wholesale Order found ("+why+").");
                Check(CostarMenu.Find(root,"repair order",out child,out why) is Node,"Repair Order found, any case.");
                Check(CostarMenu.Find(root,"Stock Take",out child,out why)==null&&why.Contains("isn't in"),"An item that isn't there: "+why);
                outline.Add(new Node(43,"Quotation",null,"Press"));
                Check(CostarMenu.Find(root,"Quotation",out child,out why)==null&&why.Contains("2 times"),"Twice: not pressed ("+why+").");
                Check(CostarMenu.Find(new Node(10,"COSTAR"),"Wholesale Order",out child,out why)==null&&why.Contains("wasn't found"),"No menu: "+why);
                var act=Direct.Act(delegate(out object c,out string w) { return CostarMenu.Find(root,"Wholesale Order",out c,out w); });
                Check(Direct.Went(act,5000,400)=="pressed"&&outline.Kids.OfType<Node>().Single(k=>k.Name=="Wholesale Order").Pressed==1&&outline.Kids.OfType<Node>().Where(k=>k.Name!="Wholesale Order").All(k=>k.Pressed==0),"Only Wholesale Order pressed.");
                Func<int,Node> tabs=delegate(int sel) { var list=new Node(60,"");string[] n={"Ship to","Rebill to","Contacts","Notes"};for(int i=0;i<n.Length;i++) list.Add(new Node(37,n[i],null,"Switch",i==sel?0x2:0));return new Node(9,"").Add(new Node(10,"").Add(list)); };
                Check(WholesaleOrderReader.SelectedTab(()=>tabs(0))=="Ship to"&&WholesaleOrderReader.SelectedTab(()=>tabs(3))=="Notes"&&WholesaleOrderReader.SelectedTab(()=>tabs(-1))==null,"The tab showing over the order's header.");
                var two=tabs(0);two.Kids[0].Kids[0].Add(new Node(37,"Notes",null,"Switch",0x2));
                Check(WholesaleOrderReader.SelectedTab(()=>two)==null,"Two tabs marked showing: can't tell.");
                var w1=RoListKind.Wholesale;var ro=RoListKind.Wip;
                Check(w1.IsWindow("Order  Branch 1  Tempe Tyres Sydney")&&w1.InBranch("Order  Branch 1  Tempe Tyres Sydney",1)&&!w1.InBranch("Order  Branch 1  Tempe Tyres Sydney",11),"An Order window of Branch 1.");
                foreach(var c in new[]{"RepairOrder  Branch 1  Tempe Tyres Sydney","Invoice  Branch 1  Tempe Tyres Sydney","Orders yet to be filled","OrderCheck","Notes",""}) Check(!w1.IsWindow(c),"\""+c+"\" isn't an Order window.");
                Check(ro.IsWindow("RepairOrder  Branch 11  Tempe Tyres Tempe")&&ro.InBranch("RepairOrder  Branch 11  Tempe Tyres Tempe",11)&&!ro.IsWindow("Order  Branch 1  Tempe Tyres Sydney"),"Repair Orders as before.");
                Check(ro.Title=="Work-in-Progress"&&ro.OrderCheckCopy&&w1.Title=="Orders yet to be filled"&&!w1.OrderCheckCopy,"The lists' titles.");
            });
        }
    }
}
