// 2.8.1 (Tommy, 3 Nov 09:01: "Tempe pickups only"): the Tempe Orders page's Auto sends this helper the Tempe pickups
// for today and tomorrow that aren't in COSTAR, and the helper enters them by itself, one at a time, without
// the Online orders tab (OnlineTab.AutoTick). The page reaches the helper through Order Check's server on this PC
// (127.0.0.1), with a key it was given once by pairing (a 6-digit code shown in the helper). Deliveries and other
// stores' pickups are still sent by hand with Send to COSTAR.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    // What the helper knows of each order the page sent (kept a few days, encrypted: online-auto.dat). The orders
    // themselves are kept in memory only: after a restart the page sends again what wasn't started.
    // told: Discord heard of it (held for a person, or entered but left open for checking); open: entered but left open.
    public sealed class OnlineAutoRecord { public string orderId,state,message,receivedUtc,updatedUtc,notBeforeUtc;public int tries;public bool told,open; }
    public sealed class OnlineAutoState {
        public string keyHash,pairId,pausedWhy,pausedUtc;public bool paused;
        public List<OnlineAutoRecord> orders=new List<OnlineAutoRecord>();
    }
    // The page's round (POST /online/status): the orders it found missing, those it holds back for a person (pages
    // before the helper decided that itself), those it couldn't send (a service without a COSTAR code, a discount...:
    // a person is needed), what went wrong on its side ("" when nothing), and its Auto switch ("off").
    public sealed class OnlinePageCheck { public string id,doc; }
    public sealed class OnlinePageSkip { public string id,why; }
    public sealed class OnlinePageHello { public List<string> ids;public List<OnlinePageCheck> check;public List<OnlinePageSkip> skipped;public string error,auto; }

    // Why the page's next order doesn't start yet. Soon: only for a moment (another entry, someone using the PC,
    // Order Check's next read); otherwise a person may be needed (Discord hears of it after 10 minutes).
    internal sealed class AutoWait {
        internal readonly string Why;internal readonly bool Soon;
        internal AutoWait(string why,bool soon) { Why=why??"";Soon=soon; }
    }
    // What OnlineInbox.Step looks at, from the window (Windows, COSTAR, Order Check); the self-tests pass made-up ones.
    internal sealed class AutoStep {
        internal Func<AutoWait> Local;                      // the Online orders tab: busy, a question, an order of its own
        internal Func<string,bool> ByHand;                  // sent with Send to COSTAR or Make it in this session (whatever came of it)
        internal Func<string,string> EnteredBefore;         // entered here before (this session's line, the day log): when, else null
        internal CostarInstance Target;                     // the COSTAR selected in the helper
        internal Func<string> Busy;                         // another entry under way: its owner, else null
        internal Func<CostarInstance,AutoWait> Costar;      // that COSTAR ready (still the one picked, Work-in-Progress, nobody at the PC)
        internal DateTime LastEntryUtc;                     // when the last entry here ended (a read must begin after it)
        internal Func<string> Wip;                          // Order Check's latest read (its wip.json), or null
        internal Action AskRead;                            // asks Order Check for a read now
        internal Action<string> Say;                        // a line for the Online orders tab
    }

    // States: waiting (in line here), entering, entered, in_costar (already in COSTAR: not entered twice), held (a job
    // with the same amount is in COSTAR: a person decides), by_hand (sent with Send to COSTAR or Make it meanwhile: the
    // Online orders tab has it), stopped (a person is needed; the page's orders pause until Resume).
    internal sealed class OnlineInbox {
        readonly object gate=new object();readonly Action<OnlineAutoState> save;OnlineAutoState state;
        Dictionary<string,Order> held=new Dictionary<string,Order>(StringComparer.OrdinalIgnoreCase);   // waiting or entering
        AutoWait wait=new AutoWait("",false);
        bool dirty;DateTime lastSave=DateTime.MinValue,lastAsk=DateTime.MinValue;
        // Orders the page said were sent by hand (Send to COSTAR, Make it), and when. Such an order waits here a while for
        // the Online orders tab to take it (then it is the tab's: by_hand); if the tab doesn't (nobody loaded or filled
        // it), it is entered by itself after all, its checks against COSTAR as ever, so it isn't left out.
        readonly Dictionary<string,DateTime> hand=new Dictionary<string,DateTime>(StringComparer.OrdinalIgnoreCase);
        internal static readonly TimeSpan HandWait=TimeSpan.FromMinutes(10);
        internal const int MostTries=2;   // the first try, and one retry of a stop that typed nothing
        // Stale: an order's details are only used while recent (Order.Validate(true): 30 minutes); one still waiting
        // after this is let go, and the page sends it again with fresh details.
        internal static readonly TimeSpan Keep=TimeSpan.FromDays(4),BackAfter=TimeSpan.FromSeconds(30),Stale=TimeSpan.FromMinutes(25),
            SaveAgain=TimeSpan.FromSeconds(30),AskAgain=TimeSpan.FromSeconds(20);
        internal OnlineInbox(OnlineAutoState initial,Action<OnlineAutoState> persist) {
            state=initial??new OnlineAutoState();if(state.orders==null) state.orders=new List<OnlineAutoRecord>();
            save=persist;
            // After a restart: one still waiting wasn't started (the page sends it again); one being entered when the
            // helper closed needs a person (it may be part way in COSTAR), and the page's orders pause until then.
            state.orders.RemoveAll(r=>r==null||r.state=="waiting");
            var now=DateTime.UtcNow;
            foreach(var r in state.orders.Where(r=>r.state=="entering").ToList()) {
                r.state="stopped";r.message="The helper closed while it was being entered: check COSTAR for it.";r.updatedUtc=Stamp(now);
                state.paused=true;state.pausedWhy=r.orderId+" was being entered when the helper closed: check COSTAR for it (finish it, or delete it and click Make it on the page).";state.pausedUtc=Stamp(now);
            }
        }
        static string Stamp(DateTime utc) { return utc.ToString("o",CultureInfo.InvariantCulture); }
        static DateTime Read(string stamp) { DateTime at;return DateTime.TryParse(stamp??"",CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out at)?at.ToUniversalTime():DateTime.MinValue; }
        OnlineAutoRecord Find(string id) { return state.orders.FirstOrDefault(r=>String.Equals(r.orderId,id,StringComparison.OrdinalIgnoreCase)); }
        // A change is kept in memory at once and saved; an action that fails changes nothing. A save that fails (a full
        // disk, a locked file) never stops the helper: it is tried again (Flush), and meanwhile memory is what counts.
        T Change<T>(Func<T> action) {
            lock(gate) {
                var old=Wire.Copy(state);var oldHeld=new Dictionary<string,Order>(held,StringComparer.OrdinalIgnoreCase);
                T value;
                try { value=action();Prune(DateTime.UtcNow); }
                catch { state=old;held=oldHeld;throw; }
                dirty=true;Persist();
                return value;
            }
        }
        void Persist() {
            lastSave=DateTime.UtcNow;
            if(save==null) { dirty=false;return; }
            try { save(state);dirty=false; }
            catch(Exception e) { AppLog.Note("online_auto_save_failed",e.GetType().Name); }
        }
        // Every second from the window: a save that failed is tried again every 30 s.
        internal void Flush() { lock(gate) { if(dirty&&DateTime.UtcNow-lastSave>=SaveAgain) Persist(); } }
        internal bool Unsaved { get { lock(gate) return dirty; } }
        void Prune(DateTime nowUtc) { state.orders.RemoveAll(r=>r.state!="waiting"&&r.state!="entering"&&nowUtc-Read(r.updatedUtc)>Keep); }

        // Why an order can't come in by itself ("" when it can): Tempe pickups only (Tommy, 3 Nov): not a delivery (the
        // website's delivery method, which the page sends, doesn't name one; the page makes a delivery schema 2, and a
        // pickup needs its pickup time), schema 1, a Tempe store named, no package.
        static readonly Regex DeliveryWords=new Regex(@"AUSTRALIA|DELIVER|PARTNER|FREIGHT|COURIER|POSTAGE|SHIPPING|EBAY",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant);
        internal static string Refusal(Order o) {
            if(o==null) return "No order was sent.";
            string id=o.orderId??"";
            if(o.IsDelivery) return id+" is a delivery order: only Tempe pickups come in by themselves. Send it with Send to COSTAR.";
            string method=Order.Clean(o.deliveryMethod);
            if(method.Length>60||DeliveryWords.IsMatch(method)) return id+" isn't marked as collected in store"+(method.Length<=60?" ("+method+")":"")+": only Tempe pickups come in by themselves. Send it with Send to COSTAR.";
            bool tempe=!String.IsNullOrWhiteSpace(o.store)&&Branches.StoreMatches(o.store,"Tempe Tyres Tempe");
            if(o.schema!=1||!tempe) return id+" is a pickup at "+(String.IsNullOrWhiteSpace(o.store)?"a store it doesn't name":Order.Clean(o.store))+": only Tempe pickups come in by themselves. Send it with Send to COSTAR.";
            if(o.lines!=null&&o.lines.Any(l=>l!=null&&l.kind=="package")) return id+" has a package to finish by hand: send it with Send to COSTAR.";
            return "";
        }
        // Why the next order can't go into the selected COSTAR (null when it can): one is selected, it isn't Order
        // Check's, and it is Tempe.
        internal static string Hold(CostarInstance target,Order next) {
            if(target==null) return "no COSTAR is selected in the helper";
            if(OrderCheckLink.IsWipWindow(target)) return "the selected COSTAR is Order Check's";
            if(next==null||!Branches.StoreMatches(String.IsNullOrWhiteSpace(next.store)?"Tempe NSW":next.store,target.BranchName)) return "the selected COSTAR is "+target.Label+", not Tempe";
            return null;
        }
        // The page's next order to start now, or null (WaitWhy says why). In this order: one waiting (and due); the
        // Online orders tab free; not entered here before; a Tempe COSTAR selected; no other entry; that COSTAR ready;
        // a read of COSTAR's Work-in-Progress list that began after the order arrived and after the last entry ended
        // (so what was typed meanwhile, by the helper or a person, shows); and on that read, the order neither in
        // COSTAR (its number as the PO# or in a comment) nor a job with the same amount (a person decides: held).
        internal Order Step(AutoStep w,DateTime nowUtc) {
            Expire(nowUtc);
            var next=Next(nowUtc);
            if(next==null) { SetWait(null);return null; }
            var local=w.Local==null?null:w.Local();
            if(local!=null) { SetWait(local);return null; }
            // Sent by hand meanwhile (Send to COSTAR or the page's Make it) and taken by the Online orders tab: that try,
            // whatever comes of it, is a person's (one put away unfilled is released: Released).
            if(w.ByHand!=null&&w.ByHand(next.orderId)) {
                if(Known(next.orderId,"by_hand","Sent with Send to COSTAR or Make it: the Online orders tab had it",nowUtc)&&w.Say!=null) w.Say(next.orderId+" from the Tempe Orders page was sent by hand too (the Online orders tab had it): not entered by itself.");
                SetWait(null);return null;
            }
            string before=w.EnteredBefore==null?null:w.EnteredBefore(next.orderId);
            if(before!=null) {
                if(Known(next.orderId,"in_costar","Entered by the helper before ("+before+"): not entered twice",nowUtc)&&w.Say!=null) w.Say(next.orderId+" from the Tempe Orders page was entered by the helper before ("+before+"): not entered twice.");
                SetWait(null);return null;
            }
            string target=Hold(w.Target,next);
            if(target!=null) { SetWait(new AutoWait(target,false));return null; }
            string owner=w.Busy==null?null:w.Busy();
            if(owner!=null) { SetWait(new AutoWait(owner+" is being entered in COSTAR",true));return null; }
            var costar=w.Costar==null?null:w.Costar(w.Target);
            if(costar!=null) { SetWait(costar);return null; }
            DateTime received;lock(gate) { var r=Find(next.orderId);received=r==null?nowUtc:Read(r.receivedUtc); }
            DateTime after=received>w.LastEntryUtc?received:w.LastEntryUtc;
            string json=w.Wip==null?null:w.Wip();string kind="";
            string fresh=json==null?"Order Check isn't on in this helper (Order Check tab)":OrderCheckLink.FreshIn(json,new DateTimeOffset(nowUtc,TimeSpan.Zero),after,out kind);
            if(fresh!=null) {
                // A read is asked for when one is due (it begins after the order came) or none was made lately.
                if(json!=null&&(kind=="soon"||kind=="old")&&nowUtc-lastAsk>=AskAgain&&w.AskRead!=null) { lastAsk=nowUtc;w.AskRead(); }
                SetWait(new AutoWait(fresh,json!=null&&kind=="soon"));return null;
            }
            var seen=OrderCheckLink.MatchIn(json,next);
            if(seen.Kind=="in") {
                string why=seen.How=="left"?"Was in COSTAR as document "+(seen.Doc.Length>0?seen.Doc:"?")+" (Work-in-Progress last listed it "+Listed(seen.When)+"; invoiced or deleted since, Order Check): not entered again":
                    "Already in COSTAR as document "+(seen.Doc.Length>0?seen.Doc:"?")+" (its number "+(seen.How=="PO#"?"is the PO#":"is in the comment")+", Order Check): not entered twice";
                if(Known(next.orderId,"in_costar",why,nowUtc)&&w.Say!=null) w.Say(next.orderId+" from the Tempe Orders page: "+why+".");
                SetWait(null);return null;
            }
            if(seen.Kind=="maybe") {
                string why="Held for you: COSTAR has a job for this customer (or a walk-in) with the same amount (doc "+seen.Doc+"). If it's a new order, click Make it on the Tempe Orders page";
                if(Known(next.orderId,"held",why,nowUtc)&&w.Say!=null) w.Say(next.orderId+" from the Tempe Orders page: "+why+".");
                SetWait(null);return null;
            }
            SetWait(null);
            return next;
        }
        void SetWait(AutoWait w) { lock(gate) wait=w??new AutoWait("",false); }
        static string Listed(string stamp) {
            DateTimeOffset at;
            return DateTimeOffset.TryParse(stamp??"",CultureInfo.InvariantCulture,DateTimeStyles.None,out at)?at.ToString("ddd d MMM HH:mm",CultureInfo.InvariantCulture):"earlier";
        }
        // One still waiting after Stale (its details would be old) is let go: the page sends it again. Every second,
        // whatever else holds the orders (paused, switched off), so nothing waits here for ever.
        internal void Expire(DateTime nowUtc) {
            lock(gate) {
                foreach(var gone in hand.Where(h=>nowUtc-h.Value>Stale).Select(h=>h.Key).ToList()) hand.Remove(gone);
                if(!state.orders.Any(x=>x.state=="waiting"&&(nowUtc-Read(x.receivedUtc)>Stale||!held.ContainsKey(x.orderId)))) return;
                Change(delegate {
                    foreach(var gone in state.orders.Where(x=>x.state=="waiting"&&(nowUtc-Read(x.receivedUtc)>Stale||!held.ContainsKey(x.orderId))).ToList()) { state.orders.Remove(gone);held.Remove(gone.orderId); }
                    return true;
                });
            }
        }
        // A new order is put in line; one the helper already knows is left as it is (its record is returned).
        internal OnlineAutoRecord Offer(Order o,DateTime nowUtc,out bool added) {
            string why=Refusal(o);Order.Require(why.Length==0,why);
            bool isNew=false;
            var r=Change(delegate {
                var known=Find(o.orderId);
                if(known!=null) return Wire.Copy(known);
                var record=new OnlineAutoRecord {orderId=o.orderId,state="waiting",message="Waiting in the RDP helper",receivedUtc=Stamp(nowUtc),updatedUtc=Stamp(nowUtc)};
                state.orders.Add(record);held[o.orderId]=o;isNew=true;
                return Wire.Copy(record);
            });
            added=isNew;return r;
        }
        // The next order to enter (the oldest waiting one, once its retry time has come), or null.
        internal Order Next(DateTime nowUtc) {
            lock(gate) {
                foreach(var r in state.orders.Where(x=>x.state=="waiting").OrderBy(x=>x.receivedUtc,StringComparer.Ordinal)) {
                    Order o;DateTime marked;
                    if(Read(r.notBeforeUtc)>nowUtc||Read(r.receivedUtc)<nowUtc-Stale||!held.TryGetValue(r.orderId,out o)) continue;
                    if(hand.TryGetValue(r.orderId,out marked)&&nowUtc-marked<HandWait) continue;   // sent by hand: the tab may take it
                    return o;
                }
                return null;
            }
        }
        // False when it wasn't waiting any more (sent by hand meanwhile, from the server's thread): then it isn't started.
        internal bool Started(string id,DateTime nowUtc) {
            return Change(delegate { var r=Find(id);if(r==null||r.state!="waiting") return false;r.state="entering";r.tries++;r.message="Being entered";r.updatedUtc=Stamp(nowUtc);return true; });
        }
        // It couldn't start after all (COSTAR taken a moment before): back in line, the try not counted.
        internal void Back(string id,string why,DateTime nowUtc) {
            Change(delegate {
                var r=Find(id);
                if(r!=null&&r.state=="entering") { r.state="waiting";r.tries=Math.Max(0,r.tries-1);r.notBeforeUtc=Stamp(nowUtc+BackAfter);r.message="Waiting: "+(why??"");r.updatedUtc=Stamp(nowUtc); }
                return true;
            });
        }
        // A waiting order settled without being entered here: in_costar (entered before, or Order Check lists it) or
        // held (a job with the same amount: a person decides). True when it was waiting.
        internal bool Known(string id,string newState,string message,DateTime nowUtc) {
            return Change(delegate {
                var r=Find(id);if(r==null||r.state!="waiting") return false;
                r.state=newState;r.message=message??"";r.updatedUtc=Stamp(nowUtc);held.Remove(id);return true;
            });
        }
        // The page said this order was sent by hand (Send to COSTAR, Make it): it waits HandWait for the Online orders tab.
        internal void MarkFromPage(string id,DateTime nowUtc) {
            if(String.IsNullOrWhiteSpace(id)) return;
            lock(gate) { if(hand.Count<500) hand[id.Trim()]=nowUtc; }
        }
        // The Online orders tab put away an order sent by hand without filling it (Clear, or too old): it is the page's
        // again (the page sends it, and it is checked against COSTAR as any other).
        internal bool Released(string id,DateTime nowUtc) {
            if(String.IsNullOrWhiteSpace(id)) return false;
            lock(gate) hand.Remove(id.Trim());
            return Change(delegate { var r=Find(id);if(r==null||r.state!="by_hand") return false;state.orders.Remove(r);return true; });
        }
        // The same order loaded or queued in the Online orders tab (sent with Send to COSTAR or Make it): never also
        // entered by itself. True when the helper had it (waiting, held, or stopped earlier).
        internal bool TakenByHand(string id,DateTime nowUtc) {
            if(String.IsNullOrWhiteSpace(id)) return false;
            return Change(delegate {
                var r=Find(id);if(r==null||(r.state!="waiting"&&r.state!="held"&&r.state!="stopped")) return false;
                r.state="by_hand";r.message="Sent with Send to COSTAR or Make it: the Online orders tab has it";r.updatedUtc=Stamp(nowUtc);held.Remove(id);return true;
            });
        }
        // outcome: entered, in_costar or stopped. A stop that typed nothing (Unattended.Retryable) is tried once more,
        // a minute later; any other stop, or a second one, waits for a person and pauses the automatic orders.
        // Returns the order's state after it.
        internal string Finished(string id,string outcome,bool typed,string message,DateTime nowUtc) { return Finished(id,outcome,typed,message,nowUtc,false); }
        // leftOpen: entered, but the Repair Order is left open for checking (CHECK BY HAND, or online orders aren't closed
        // by themselves): a person must look at it and close it (the phone's jobs wait while it is open).
        internal string Finished(string id,string outcome,bool typed,string message,DateTime nowUtc,bool leftOpen) {
            return Change(delegate {
                var r=Find(id);if(r==null) return "";
                r.updatedUtc=Stamp(nowUtc);r.message=message??"";
                if(outcome=="entered"||outcome=="in_costar") { r.state=outcome;r.open=outcome=="entered"&&leftOpen;r.told=false;held.Remove(id);return r.state; }
                if(!typed&&Unattended.Retryable(message)&&r.tries<MostTries&&held.ContainsKey(id)) {
                    r.state="waiting";r.notBeforeUtc=Stamp(nowUtc+Unattended.RetryAfter);
                    r.message="Tried again by itself in a minute (it stopped before anything was typed): "+(message??"");
                    return r.state;
                }
                r.state="stopped";held.Remove(id);
                state.paused=true;state.pausedWhy=id+" stopped: "+(message??"");state.pausedUtc=Stamp(nowUtc);
                return r.state;
            });
        }
        internal void Resume() { Change(delegate { state.paused=false;state.pausedWhy=null;state.pausedUtc=null;return true; }); }
        // Stop all (the button or Ctrl+Alt+F10): the page's orders wait for Resume too.
        internal void Pause(string why,DateTime nowUtc) { Change(delegate { if(!state.paused) { state.paused=true;state.pausedWhy=why??"";state.pausedUtc=Stamp(nowUtc); } return true; }); }
        internal bool Paused { get { lock(gate) return state.paused; } }
        internal string PausedWhy { get { lock(gate) return state.pausedWhy??""; } }
        internal DateTime PausedUtc { get { lock(gate) return Read(state.pausedUtc); } }
        // Orders waiting here or being entered (not saved: a restart would drop them).
        internal int Waiting { get { lock(gate) return held.Count; } }
        // Why the waiting orders don't start yet ("" when nothing holds them): said to the page. Soon: only for a moment.
        internal string WaitWhy { get { lock(gate) return held.Count==0?"":wait.Why; } }
        internal bool WaitSoon { get { lock(gate) return wait.Soon; } }
        // The orders a person must look at that Discord hasn't heard of yet (held, or entered but left open); MarkTold once
        // it has.
        internal List<OnlineAutoRecord> HeldUntold() { lock(gate) return state.orders.Where(r=>(r.state=="held"||(r.state=="entered"&&r.open))&&!r.told).Select(r=>Wire.Copy(r)).ToList(); }
        internal void MarkTold(IEnumerable<string> ids) {
            var list=(ids??new string[0]).ToList();
            Change(delegate { foreach(var r in state.orders.Where(r=>list.Contains(r.orderId,StringComparer.OrdinalIgnoreCase))) r.told=true;return true; });
        }
        internal Dictionary<string,object> Status(IEnumerable<string> ids) {
            var map=new Dictionary<string,object>(StringComparer.OrdinalIgnoreCase);
            lock(gate) {
                foreach(string id in ids??new string[0]) {
                    var r=id==null?null:Find(id);if(r==null) continue;
                    DateTime at=Read(r.updatedUtc);
                    map[r.orderId]=new Dictionary<string,object> { {"state",r.state},{"at",at==DateTime.MinValue?"":at.ToLocalTime().ToString("HH:mm",CultureInfo.InvariantCulture)},{"message",r.message??""} };
                }
            }
            return map;
        }
        internal OnlineAutoRecord Get(string id) { lock(gate) { var r=Find(id);return r==null?null:Wire.Copy(r); } }
        // The page's key (pairing): only its hash is kept, with an id for the pairing that /health shows, so the page
        // finds this helper among others on the RDP server (the id isn't secret: the key is).
        internal bool Paired { get { lock(gate) return !String.IsNullOrEmpty(state.keyHash); } }
        internal string PairId { get { lock(gate) return String.IsNullOrEmpty(state.keyHash)?"":state.pairId??""; } }
        internal bool KeyMatches(string key) { if(String.IsNullOrEmpty(key)) return false;lock(gate) return Wire.Equal(Wire.Hash(Encoding.UTF8.GetBytes(key)),state.keyHash); }
        internal string SetKey(string key) {
            string id=Wire.Token().Substring(0,12);
            Change(delegate { state.keyHash=Wire.Hash(Encoding.UTF8.GetBytes(key));state.pairId=id;return true; });
            return id;
        }
    }

    // 2.8.1: only one helper on the RDP server takes the page's orders at a time (each Windows session can run one, and
    // two paired pages with Auto on would send both the same orders): a machine-wide mutex, held on the window's thread
    // (a mutex belongs to the thread that took it) while this helper takes them.
    internal static class AutoRole {
        const string Name=@"Global\TempeCostarPageOrders_v1";
        static Mutex held;static bool told;
        internal static bool Held { get { return held!=null; } }
        internal static bool Claim() {
            if(held!=null) return true;
            Mutex m=null;
            try {
                m=new Mutex(false,Name);
                bool mine;try { mine=m.WaitOne(0); } catch(AbandonedMutexException) { mine=true; }
                if(mine) { held=m;m=null;return true; }
            } catch(UnauthorizedAccessException) { }   // another user's helper holds it
            catch(Exception e) { if(!told) { told=true;AppLog.Note("online_auto_role",e.GetType().Name); } return true; }   // no machine-wide names here: one session
            finally { if(m!=null) m.Dispose(); }
            return false;
        }
        internal static void Release() { var m=held;held=null;if(m!=null) { try { m.ReleaseMutex(); } catch(Exception) { } m.Dispose(); } }
    }

    // The page's side of Order Check's server: /online/pair, /online/status and /online/order (POST, JSON, from the
    // page on GitHub only: Order Check's Route). Runs on the server's thread; the inbox is thread-safe.
    internal static class OnlinePage {
        internal static OnlineInbox Inbox;
        internal static Func<bool> On=delegate { return false; };
        internal static readonly EbayPairing Pairing=new EbayPairing();
        static readonly object gate=new object();
        static DateTime contactUtc=DateTime.MinValue,errorSinceUtc=DateTime.MinValue;static string pageError="";static bool autoOff;
        static List<OnlinePageCheck> check=new List<OnlinePageCheck>();static List<OnlinePageSkip> skipped=new List<OnlinePageSkip>();
        // When the page last checked in, what went wrong on its side (and since when), whether its Auto is off, and the
        // orders it holds back for a person.
        internal static DateTime ContactUtc { get { lock(gate) return contactUtc; } }
        internal static string PageError { get { lock(gate) return pageError; } }
        internal static DateTime PageErrorSinceUtc { get { lock(gate) return errorSinceUtc; } }
        internal static bool PageAutoOff { get { lock(gate) return autoOff; } }
        internal static List<OnlinePageCheck> Check { get { lock(gate) return check.ToList(); } }
        internal static List<OnlinePageSkip> Skipped { get { lock(gate) return skipped.ToList(); } }
        // For Order Check's /health: the pairing's id ("" when not paired).
        internal static string PairId() { var box=Inbox;return box==null?"":box.PairId; }
        internal static KeyValuePair<int,string> Handle(string method,string path,string authorization,byte[] body) {
            try {
                if(method!="POST") return Reply(404,"Unknown address.");
                string text=Encoding.UTF8.GetString(body??new byte[0]);
                if(path=="/online/pair") {
                    var inbox=Inbox;if(inbox==null) return Reply(503,"The helper isn't ready yet.");
                    var ask=Wire.Read<Dictionary<string,object>>(text.Length==0?"{}":text);
                    object pin;string code=ask!=null&&ask.TryGetValue("pin",out pin)&&pin!=null?Convert.ToString(pin,CultureInfo.InvariantCulture).Trim():"";
                    if(!Pairing.Try(code)) { AppLog.Note("online_page_pair_refused","");return Reply(403,"That code isn't right, or it has run out: click Pair the Tempe Orders page in the helper for a new one."); }
                    string key=Wire.Token();string pair=inbox.SetKey(key);AppLog.Note("online_page_paired","");
                    return new KeyValuePair<int,string>(200,Wire.Json(new Dictionary<string,object> { {"key",key},{"pair",pair} }));
                }
                var box=Inbox;if(box==null) return Reply(503,"The helper isn't ready yet.");
                if(!box.KeyMatches(Bearer(authorization))) return Reply(401,"This page isn't paired with the helper: click Auto on the page and type the code the helper shows (Files & settings, Runs by itself, Pair the Tempe Orders page).");
                bool on=On();
                if(path=="/online/status") {
                    var hello=Wire.Read<OnlinePageHello>(text.Length==0?"{}":text)??new OnlinePageHello();
                    var now=DateTime.UtcNow;
                    lock(gate) {
                        contactUtc=now;
                        // No error field (a round that only waited for Order Check's read): the page's trouble stays as it was.
                        if(hello.error!=null) {
                            string error=Sanitize.Text(hello.error,300);
                            if(error.Length==0) errorSinceUtc=DateTime.MinValue; else if(pageError.Length==0||errorSinceUtc==DateTime.MinValue) errorSinceUtc=now;
                            pageError=error;
                        }
                        autoOff=String.Equals(hello.auto,"off",StringComparison.OrdinalIgnoreCase);
                        check=(hello.check??new List<OnlinePageCheck>()).Where(c=>c!=null&&!String.IsNullOrWhiteSpace(c.id)).Take(50).ToList();
                        skipped=(hello.skipped??new List<OnlinePageSkip>()).Where(c=>c!=null&&!String.IsNullOrWhiteSpace(c.id)).Take(50)
                            .Select(c=>new OnlinePageSkip {id=Sanitize.Text(c.id,20),why=Sanitize.Text(c.why??"",200)}).ToList();
                    }
                    var ids=(hello.ids??new List<string>()).Where(i=>!String.IsNullOrWhiteSpace(i)).Take(200).ToList();
                    string why=!on?"automatic online orders are switched off in the helper (Files & settings, Runs by itself)":box.Paused?"automatic online orders are paused: "+box.PausedWhy+" Click Resume on the helper's Online orders tab once it's sorted.":box.WaitWhy;
                    return new KeyValuePair<int,string>(200,Wire.Json(new Dictionary<string,object> {
                        {"accepting",on},{"paused",box.Paused},{"why",why??""},{"waiting",box.Waiting},{"orders",box.Status(ids)} }));
                }
                // An order sent by hand from the page (Send to COSTAR, Make it): it waits for the Online orders tab a while.
                if(path=="/online/hand") {
                    var said=Wire.Read<Dictionary<string,object>>(text.Length==0?"{}":text);
                    object idValue;string id=said!=null&&said.TryGetValue("id",out idValue)&&idValue!=null?Convert.ToString(idValue,CultureInfo.InvariantCulture).Trim().ToUpperInvariant():"";
                    Order.Require(Regex.IsMatch(id,@"^TTW\d{1,20}$"),"That isn't an online order number.");
                    box.MarkFromPage(id,DateTime.UtcNow);AppLog.Note("online_auto_by_hand",id+" (the page)");
                    return new KeyValuePair<int,string>(200,Wire.Json(new Dictionary<string,object> { {"ok",true} }));
                }
                if(path=="/online/order") {
                    if(!on) return Reply(409,"Automatic online orders are switched off in the helper.");
                    Order.Require(text.Length>0&&text.Length<=200000,"The order is missing or too large.");
                    var o=Wire.Read<Order>(text);Order.Require(o!=null,"Invalid order data.");
                    o.Validate(true);
                    bool added;var r=box.Offer(o,DateTime.UtcNow,out added);
                    if(added) AppLog.Note("online_auto_received",o.orderId+" pickup "+o.pickupDate+" "+o.pickupTime);
                    return new KeyValuePair<int,string>(200,Wire.Json(new Dictionary<string,object> { {"orderId",r.orderId},{"state",r.state},{"message",r.message??""},{"added",added} }));
                }
                return Reply(404,"Unknown address.");
            }
            catch(InvalidOperationException e) { return Reply(400,e.Message); }
            catch(ArgumentException e) { return Reply(400,"Unreadable request: "+e.GetType().Name); }
            catch(Exception e) { AppLog.Note("online_page_error",e.GetType().Name);return Reply(500,"The helper couldn't take it ("+e.GetType().Name+")."); }
        }
        static string Bearer(string header) {
            string h=(header??"").Trim();
            return h.StartsWith("Bearer ",StringComparison.OrdinalIgnoreCase)?h.Substring(7).Trim():"";
        }
        static KeyValuePair<int,string> Reply(int code,string error) { return new KeyValuePair<int,string>(code,Wire.Json(new Dictionary<string,object> { {"error",error} })); }
    }
}
