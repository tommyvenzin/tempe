using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;

namespace TempeCostar {
    public sealed class MobileCustomer { public string name, mobile; }
    public sealed class MobileVehicle { public string registration, makeModel; public int? odometer; }
    public sealed class MobileProduct { public string type, sku, description; public int quantity; }
    // 2.6.2: what the phone chose with SUBMIT TO COSTAR (Tommy, 27 Oct). order: Ship Via SHOP, Customer
    // Waiting ticked and the Repair Date today; printJobCard: COSTAR prints the Job Card. An older phone
    // sends none: ordered (as since 2.5.3), nothing printed.
    public sealed class MobileOptions { public bool? order, printJobCard; }
    public sealed class MobileJob {
        public string schema, submissionId, draftId, createdUtc, fittingCode, alignment, additionalNotes;
        public MobileCustomer customer;
        public MobileVehicle vehicle;
        public List<MobileProduct> products;
        public MobileOptions options;
        internal bool Ordering { get { return options==null || options.order==true; } }
        internal bool PrintingJobCard { get { return options!=null && options.printJobCard==true; } }
        public void Validate() {
            Guid id, draft; DateTimeOffset date;
            Order.Require(schema=="tempe.mobile-jobcard.v1" && Regex.IsMatch(submissionId??"",@"^MJC-[0-9a-fA-F-]{36}$") && Guid.TryParse((submissionId??"").Substring(4),out id),"Invalid mobile submission ID.");
            Order.Require(Guid.TryParse(draftId,out draft) && DateTimeOffset.TryParse(createdUtc,CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out date),"Invalid draft ID or date.");
            Order.Require(customer!=null && vehicle!=null,"Customer and vehicle are required.");
            Text(customer.name,"customer name",200,true); Text(customer.mobile,"mobile",30,true);
            Order.Require(Regex.IsMatch(customer.mobile,@"^\+?[\d ()-]+$") && Regex.IsMatch(Order.Phone(customer.mobile),@"^\d{8,15}$"),"Invalid mobile number.");
            Text(vehicle.makeModel,"vehicle",200,true);
            Order.Require(Regex.IsMatch(vehicle.registration??"",@"^[A-Z0-9 -]{1,15}$",RegexOptions.IgnoreCase)&&Regex.IsMatch(vehicle.registration??"",@"[A-Z0-9]",RegexOptions.IgnoreCase),"Invalid registration.");
            Order.Require(vehicle.odometer.HasValue && vehicle.odometer>=0 && vehicle.odometer<=9999999,"Odometer is required (0 is valid).");
            Order.Require(products!=null && products.Count>=1 && products.Count<=3,"Use one to three products.");
            var codes=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach(var p in products) {
                Order.Require(p!=null && (p.type=="wheel" || p.type=="tyre") && Regex.IsMatch(p.sku??"",@"^[A-Z0-9][A-Z0-9._-]{0,39}$") && !Regex.IsMatch(p.sku??"",@"^(F|M|DET|WA|WAFR|SERVICES?|UNKNOWN|UNAVAILABLE)$"),"Invalid product SKU/type.");
                Order.Require(codes.Add(p.sku) && p.quantity>=1 && p.quantity<=100,"Duplicate SKU or invalid quantity.");
                Text(p.description,"product description",400,false);
            }
            Order.Require(fittingCode=="M FB" && (alignment==null || alignment=="WA" || alignment=="WAFR"),"Invalid fitting/alignment code.");
            Order.Require((additionalNotes??"").Length<=400 && !(additionalNotes??"").Any(c=>Char.IsControl(c) && c!='\r' && c!='\n' && c!='\t'),"Invalid additional notes.");
            Order.Require(options==null || (options.order.HasValue && options.printJobCard.HasValue),"Invalid Job Card choices (order, print).");
        }
        static void Text(string value,string label,int limit,bool required) {
            Order.Safe(value,label,limit); Order.Require(!required || !String.IsNullOrWhiteSpace(value),label+" is required.");
        }
        internal string Reference { get { return "MJC-"+submissionId.Substring(4).Replace("-","").Substring(0,12).ToUpperInvariant(); } }
        internal string Notes { get { return Regex.Replace(additionalNotes??"",@"\s+"," ").Trim(); } }
        internal IEnumerable<MobileProduct> Ordered { get { return products.OrderBy(p=>p.type=="wheel"?0:1); } }
        internal Order EngineOrder() {
            return new Order { orderId=Reference,createdUtc=createdUtc,vehicle=vehicle.makeModel.ToUpperInvariant(),rego=vehicle.registration.ToUpperInvariant(),
                customer=new Customer { name=customer.name.ToUpperInvariant(),phone=customer.mobile },comment="",lines=new List<OrderLine>() };
        }
    }
    internal static class Wire {
        // One serializer per thread, reused (a new one per message was created every poll
        // and every checkpoint save).
        [ThreadStatic] static JavaScriptSerializer serializer;
        static JavaScriptSerializer Serializer { get { return serializer ?? (serializer=new JavaScriptSerializer { MaxJsonLength=12000000,RecursionLimit=32 }); } }
        internal static string Json(object value) { return Serializer.Serialize(value); }
        internal static T Read<T>(string text) { return Serializer.Deserialize<T>(text); }
        internal static T Copy<T>(T value) { return Read<T>(Json(value)); }
        internal static string Token() { var b=new byte[32];using(var r=RandomNumberGenerator.Create())r.GetBytes(b);return Convert.ToBase64String(b).TrimEnd('=').Replace('+','-').Replace('/','_'); }
        internal static string Hash(byte[] data) { using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(data)).Replace("-",""); }
        internal static bool Equal(string a,string b) { if(a==null||b==null)return false;int n=a.Length^b.Length;for(int i=0;i<a.Length;i++)n|=a[i]^(i<b.Length?b[i]:0);return n==0; }
    }
    internal static class PrivateFiles {
        internal static string Home { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TempeMobileCostar"); } }
        internal static void DirectoryReady(string path) {
            Directory.CreateDirectory(path);
            var acl=new DirectorySecurity();acl.SetAccessRuleProtection(true,false);
            var inheritance=InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit;
            acl.AddAccessRule(new FileSystemAccessRule(WindowsIdentity.GetCurrent().User,FileSystemRights.FullControl,inheritance,PropagationFlags.None,AccessControlType.Allow));
            acl.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.LocalSystemSid,null),FileSystemRights.FullControl,inheritance,PropagationFlags.None,AccessControlType.Allow));
            Directory.SetAccessControl(path,acl);
        }
        internal static T Load<T>(string path) where T:class {
            if(!File.Exists(path))return null;
            return Wire.Read<T>(Encoding.UTF8.GetString(ProtectedData.Unprotect(File.ReadAllBytes(path),null,DataProtectionScope.CurrentUser)));
        }
        // flush=false skips the forced write-through to disk. The data still reaches the
        // operating system before Save returns and survives this helper crashing; only a
        // power cut or Windows crash could lose it, which also loses COSTAR's unsaved order.
        // Timing of the last save on this thread, for the diagnostics only.
        [ThreadStatic] internal static long LastJsonMs,LastProtectMs,LastWriteMs,LastReplaceMs;
        internal static void Save(string path,object value,bool flush=true) {
            var clock=System.Diagnostics.Stopwatch.StartNew();
            string json=Wire.Json(value);long jsonMs=clock.ElapsedMilliseconds;
            byte[] bytes=ProtectedData.Protect(Encoding.UTF8.GetBytes(json),null,DataProtectionScope.CurrentUser);long protectMs=clock.ElapsedMilliseconds;
            string temp=path+"."+Guid.NewGuid().ToString("N")+".tmp";long writeMs=protectMs;
            try {
                using(var f=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)) {f.Write(bytes,0,bytes.Length);if(flush)f.Flush(true);}
                writeMs=clock.ElapsedMilliseconds;
                if(File.Exists(path))File.Replace(temp,path,null);else File.Move(temp,path);
            } finally {if(File.Exists(temp))File.Delete(temp);}
            LastJsonMs=jsonMs;LastProtectMs=protectMs-jsonMs;LastWriteMs=writeMs-protectMs;LastReplaceMs=clock.ElapsedMilliseconds-writeMs;
        }
    }
    // waiting (2.6.9): why a queued phone job is still waiting, from the desk (null otherwise). Older
    // phones and RDP helpers ignore it.
    public sealed class JobStatus { public string submissionId,status,message,progress,waiting;public int version; }
    public sealed class Receipt {
        public MobileJob job; public string hash,status,message,progress,lease,workerId; public int version,workerSequence;
        public bool approved,closed,awaitingWorker,hiddenFromList;
        // 2.8.0: when it last stopped (UTC, round-trip), and whether the desk retried it by itself (once, ever).
        public string stoppedUtc;public bool autoRetried;
        internal JobStatus Status() { return new JobStatus {submissionId=job.submissionId,status=status,message=message,progress=progress,version=version}; }
    }
    public sealed class QueueState { public List<Receipt> jobs=new List<Receipt>();public string currentId; public bool nextRequested,pinadMode; }
    public sealed class WorkerReport { public string submissionId,lease,status,message,progress; public int sequence; }
    // waitMs (2.4.0): how long the desk may hold the poll waiting for something to happen (0: answer
    // at once, as before). held/waitedMs (2.4.0): the desk did hold it, for this long. Older
    // versions ignore the fields they don't know.
    // jobOptions (2.6.2): this RDP helper does the phone's Job Card choices (order, print the Job Card).
    public sealed class WorkerHello { public string workerId;public bool available,accepting,jobOptions;public string detail;public WorkerReport report;public int waitMs; }
    public sealed class WorkerReply { public MobileJob job;public string lease,command;public JobStatus status;public bool held;public int waitedMs; }
    internal sealed class JobQueue {
        readonly object gate=new object();readonly Action<QueueState> save;
        QueueState state;
        internal JobQueue(QueueState initial,Action<QueueState> persist) {state=initial??new QueueState();save=persist;}
        // 2.4.0: raised after every saved change, so a held worker poll can answer at once.
        internal event Action Changed;
        T Change<T>(Func<T> action) {
            T value;
            lock(gate) { var old=Wire.Copy(state);try {value=action();save(state);}catch {state=old;throw;} }
            var changed=Changed;if(changed!=null){try{changed();}catch(Exception){}}
            return value;
        }
        internal List<Receipt> List() {lock(gate)return Wire.Copy(state.jobs);}
        internal Receipt Current {get {lock(gate)return Wire.Copy(state.jobs.FirstOrDefault(j=>j.job.submissionId==state.currentId));}}
        Receipt Find(string id) {var r=state.jobs.FirstOrDefault(j=>j.job.submissionId==id);Order.Require(r!=null,"Unknown submission.");return r;}
        Receipt Pending() {return state.jobs.FirstOrDefault(j=>!j.closed && j.job.submissionId!=state.currentId && (j.status=="queued"||j.status=="awaiting_approval"||j.status=="failed"));}
        internal JobStatus Get(string id) {lock(gate){var r=state.jobs.FirstOrDefault(j=>j.job.submissionId==id);return r==null?null:r.Status();}}
        // 2.6.9: what in this queue holds a queued phone job back, in words for the phone's progress sheet
        // (null: nothing here, it goes next). One job is in COSTAR at a time (the current one, until Next
        // Order or Pinad mode closes it), and the queue goes in order: an earlier job that stopped or awaits
        // approval holds the later ones (Poll hands out only the first pending job).
        // 2.6.9: whether this job is the one in COSTAR now (the current job; a stopped one Retry queued again
        // carries on in its own Repair Order whether or not COSTAR is free: Poll).
        internal bool IsCurrent(string id) {lock(gate)return state.currentId!=null&&state.currentId==id;}
        internal string Ahead(string id) {
            lock(gate) {
                var r=state.jobs.FirstOrDefault(j=>j.job.submissionId==id);
                if(r==null||r.closed||r.status!="queued"||state.currentId==id) return null;
                var current=state.jobs.FirstOrDefault(j=>j.job.submissionId==state.currentId&&!j.closed);
                var earlier=state.jobs.Take(state.jobs.IndexOf(r)).Where(j=>!j.closed&&j.job.submissionId!=state.currentId&&(j.status=="queued"||j.status=="awaiting_approval"||j.status=="failed")).ToList();
                int count=earlier.Count+(current!=null?1:0);
                string more=count>1?" ("+count+" orders ahead)":"";
                if(current!=null) {
                    if(current.status=="injecting") return "Another order is being entered in COSTAR"+more+".";
                    if(current.status=="failed") return "The order before it stopped: retry or remove it on the desk PC"+more+".";
                    if(current.status!="ready_for_review") return "Another order goes first"+more+".";
                    if(state.nextRequested) return "The order before it is being closed in COSTAR"+more+".";
                    if(!state.pinadMode) return "The order before it is ready for review in COSTAR: press Next Order on the desk PC"+more+".";
                    var first=Pending();
                    if(first!=null&&first.status=="queued"&&first.approved) return "The order before it is being closed in COSTAR (Pinad mode)"+more+".";
                    // Pinad mode, but an earlier job holds the queue: that one is said below.
                }
                var holding=earlier.FirstOrDefault();
                if(holding==null) return null;
                if(holding.status=="failed") return "An earlier order stopped: retry or remove it on the desk PC"+more+".";
                if(holding.status=="awaiting_approval") return "An earlier order is waiting for approval on the desk PC"+more+".";
                return count==1?"One order ahead of it.":count+" orders ahead of it.";
            }
        }
        static void Set(Receipt r,string status,string message) {r.status=status;r.message=message;r.version++;if(status=="failed")r.stoppedUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture);}
        // 2.8.0: a job that stopped before anything was typed, retried once by itself (Unattended.RetryDue), the stop
        // time and the "once" kept in the queue file (a desk restart neither retries it again nor an old one). True
        // when it was set to wait again. The caller asks only while the RDP helper is in touch and taking jobs.
        internal static bool AutoRetryDue(Receipt r,DateTime nowUtc) {
            DateTime at;
            return r!=null&&!r.closed&&r.status=="failed"&&!r.autoRetried&&DateTime.TryParse(r.stoppedUtc??"",CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out at)&&Unattended.RetryDue(r.message,at.ToUniversalTime(),nowUtc,false);
        }
        internal bool AutoRetry(string id,DateTime nowUtc) {
            lock(gate) { var r=state.jobs.FirstOrDefault(j=>j.job.submissionId==id);if(!AutoRetryDue(r,nowUtc)) return false; }
            return Change(delegate {
                var r=Find(id);if(!AutoRetryDue(r,nowUtc)) return false;
                r.autoRetried=true;r.approved=true;Set(r,"queued","Retried by itself once (it stopped before anything was typed): checking the existing order");
                return true;
            });
        }
        internal bool PinadMode {get {lock(gate)return state.pinadMode;}}
        internal void SetPinadMode(bool enabled) {Change(delegate {
            if(state.pinadMode==enabled)return true;
            state.pinadMode=enabled;
            if(enabled)foreach(var r in state.jobs.Where(j=>!j.closed && j.status=="awaiting_approval")) {
                r.approved=true;Set(r,"queued","Pinad mode approved; waiting for COSTAR");
            }
            return true;
        });}
        internal JobStatus Submit(MobileJob job,bool idleAtArrival) {
            job.Validate();string hash=Wire.Hash(Encoding.UTF8.GetBytes(Wire.Json(job)));
            return Change(delegate {
                var old=state.jobs.FirstOrDefault(j=>j.job.submissionId==job.submissionId);
                if(old!=null){Order.Require(Wire.Equal(old.hash,hash),"CONFLICT: This ID already has a different payload.");return old.Status();}
                Order.Require(state.jobs.Count(j=>!j.closed && j.status!="ready_for_review")<100,"The pending queue is full.");
                bool approved=state.pinadMode||idleAtArrival;
                var r=new Receipt {job=Wire.Copy(job),hash=hash,approved=approved,status=approved?"queued":"awaiting_approval",version=1,message=state.pinadMode?"Pinad mode approved; waiting for COSTAR":approved?"Waiting for COSTAR":"Approve this job on the desk PC"};
                state.jobs.Add(r);return r.Status();
            });
        }
        internal JobStatus Approve(string id) {return Change(delegate {var r=Find(id);if(r.status=="awaiting_approval"){r.approved=true;Set(r,"queued","Approved; waiting for COSTAR");}return r.Status();});}
        internal JobStatus Retry(string id) {return Change(delegate {var r=Find(id);if(r.status=="failed"){r.approved=true;Set(r,"queued","Retry requested; checking the existing order");}return r.Status();});}
        internal void DeleteCompleted(string id) {Change(delegate {
            var r=Find(id);Order.Require(r.status=="ready_for_review","Only completed jobs can be removed from this list.");
            r.hiddenFromList=true;return true;
        });}
        internal void ClearCompleted() {Change(delegate {
            foreach(var r in state.jobs.Where(j=>j.status=="ready_for_review"))r.hiddenFromList=true;
            return true;
        });}
        // 2.4.0: the job was finished (or closed) by hand in COSTAR. It counts as reviewed and
        // closed; if it was the current job the queue moves on. The worker is told to forget it.
        // workerReachable: the RDP helper is in touch (ReceiverApi.Connected). A job the helper is
        // typing right now is left alone; one it never picked up, or that an unreachable helper holds,
        // can be marked done (the 2.4.0 helper's own busy guard protects a run that is still going).
        internal JobStatus MarkDone(string id,bool workerReachable) {return Change(delegate {
            var r=Find(id);Order.Require(!r.closed,"This job is already closed.");
            Order.Require(r.status!="injecting"||r.awaitingWorker||!workerReachable,"The RDP helper is entering this job right now. Stop it there first (Stop all entry), then mark it done.");
            r.approved=true;r.closed=true;Set(r,"ready_for_review","Marked done by hand on the desk PC. Check it in COSTAR.");
            if(state.currentId==id){state.currentId=null;state.nextRequested=false;}
            return r.Status();
        });}
        // 2.4.0: a job that should not be entered (sent twice, cancelled, or abandoned). Allowed
        // while it waits, or when it failed; never while the worker is typing it.
        internal JobStatus Remove(string id,bool workerReachable) {return Change(delegate {
            var r=Find(id);
            Order.Require(!r.closed,"This job is already closed.");
            bool stranded=r.status=="injecting"&&(r.awaitingWorker||!workerReachable);
            Order.Require(r.status=="awaiting_approval"||r.status=="queued"||r.status=="failed"||stranded,"Only a waiting or failed job can be removed. Use Mark done by hand for a finished one.");
            r.closed=true;r.hiddenFromList=true;Set(r,"removed","Removed on the desk PC");
            if(state.currentId==id){state.currentId=null;state.nextRequested=false;}
            return r.Status();
        });}
        internal void Next() {Change(delegate {
            var current=state.jobs.FirstOrDefault(j=>j.job.submissionId==state.currentId);
            Order.Require(current!=null && current.status=="ready_for_review","Next Order requires a completed order ready for review.");
            var next=state.jobs.FirstOrDefault(j=>!j.closed && j.job.submissionId!=state.currentId && (j.status=="queued"||j.status=="awaiting_approval"));
            Order.Require(next!=null,"No pending job is available.");next.approved=true;Set(next,"queued","Next Order approved");state.nextRequested=true;return true;
        });}
        // 2.6.2: a job whose choices differ from what every RDP helper did before (Order unticked, or the
        // Job Card to print) goes only to an RDP helper that says it does the choices. One that changed
        // version since the phone looked would order it anyway and print nothing: the job fails, with
        // nothing entered, until it is retried with a 2.6.2 RDP helper (or removed and sent again).
        static bool Chosen(MobileJob job) {return job.options!=null && (job.options.order==false || job.options.printJobCard==true);}
        const string ChoicesMessage="Not entered: the RDP helper on the COSTAR PC can't do this job's choices now (Order / Print the Job Card; it changed version). Retry once it is updated, or remove this job and submit it again.";
        const string ChoicesStopped="Stopped: the RDP helper on the COSTAR PC can't do this job's choices now (Order / Print the Job Card; it changed version). Check COSTAR, then Retry once it is updated, or remove this job and submit it again.";
        internal WorkerReply Poll(WorkerHello hello) {
            return Change(delegate {
                if(hello.report!=null) {
                    var p=hello.report;var r=state.jobs.FirstOrDefault(j=>j.job.submissionId==p.submissionId);
                    // 2.4.0: a report about a job this desk no longer has, or has closed by hand, is not
                    // an error: the worker is told to forget that job.
                    if(r==null)return new WorkerReply {command="forget",status=new JobStatus {submissionId=p.submissionId,status="removed",message="Unknown to this desk"}};
                    Order.Require(r.workerId==hello.workerId && Wire.Equal(r.lease,p.lease),"Wrong worker or lease.");
                    if(r.closed&&p.status!="closed"&&state.currentId!=p.submissionId)return new WorkerReply {command="forget",status=r.Status()};
                    if(p.sequence>r.workerSequence) {
                        Order.Require(new[]{"injecting","failed","ready_for_review","closed"}.Contains(p.status),"Invalid worker status.");
                        if(r.status!="ready_for_review" || p.status=="closed") {
                            if(p.status=="closed") {Order.Require(state.nextRequested && r.status=="ready_for_review" && state.currentId==p.submissionId,"Unexpected close acknowledgement.");r.closed=true;Set(r,"ready_for_review","Entry complete; window closed. Review in COSTAR.");state.currentId=null;state.nextRequested=false;}
                            else {Set(r,p.status,p.message??"");r.progress=p.progress??"";}
                        }
                        r.workerSequence=p.sequence;r.awaitingWorker=false;
                    }
                }
                var current=state.jobs.FirstOrDefault(j=>j.job.submissionId==state.currentId);
                if(!hello.accepting)return new WorkerReply {command="wait"};
                // COSTAR is occupied by the completed order here, so available is normally false.
                // Reuse the existing close/acknowledge handshake before assigning another job.
                if(!state.nextRequested && state.pinadMode && current!=null && current.status=="ready_for_review" && current.workerId==hello.workerId) {
                    var pending=Pending();
                    if(pending!=null && pending.status=="queued" && pending.approved)state.nextRequested=true;
                }
                if(state.nextRequested && current!=null && current.workerId==hello.workerId)
                    return new WorkerReply {command="close",job=Wire.Copy(current.job),lease=current.lease,status=current.Status()};
                if(current!=null) {
                    if(current.status=="injecting" && current.awaitingWorker && current.workerId==hello.workerId) {
                        // Handed over but not taken yet, and the helper now doesn't do the choices: not again.
                        if(!hello.jobOptions && Chosen(current.job)) {current.awaitingWorker=false;Set(current,"failed",ChoicesStopped);return new WorkerReply {command="wait",status=current.Status()};}
                        return new WorkerReply {command="inject",job=Wire.Copy(current.job),lease=current.lease,status=current.Status()};
                    }
                    if(current.status=="queued" && current.approved && current.workerId==hello.workerId) {
                        if(!hello.jobOptions && Chosen(current.job)) {Set(current,"failed",ChoicesMessage);return new WorkerReply {command="wait",status=current.Status()};}
                        current.awaitingWorker=true;Set(current,"injecting","Checking saved progress");return new WorkerReply {command="inject",job=Wire.Copy(current.job),lease=current.lease,status=current.Status()};
                    }
                    return new WorkerReply {command="wait",status=current.Status()};
                }
                if(!hello.available)return new WorkerReply {command="wait"};
                // FIFO: held arrivals need explicit approval or the user enabling Pinad mode.
                var next=Pending();
                if(next==null||!next.approved||next.status!="queued")return new WorkerReply {command="wait"};
                if(!hello.jobOptions && Chosen(next.job)) {Set(next,"failed",ChoicesMessage);return new WorkerReply {command="wait"};}
                next.workerId=hello.workerId;next.lease=Wire.Token();next.awaitingWorker=true;state.currentId=next.job.submissionId;Set(next,"injecting","Opening COSTAR");
                return new WorkerReply {command="inject",job=Wire.Copy(next.job),lease=next.lease,status=next.Status()};
            });
        }
    }
}
