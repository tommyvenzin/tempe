// The entry engine, part 6 (2.6.11): COSTAR's notices over an order, answered with their one OK.
// Tommy, 2 Nov: "some customer may have notes popped up before we can access to repair order ... it cant be
// ignored, we have to press OK"; "Some customer have more than 1 pop up, so make sure both are cleared";
// "apply those pop up skips on all the orders". Seen on an account customer's Repair Order: the customer's
// Notes (a COSTAR window titled "Notes", with New / Colour / Delete, the notes, and one button: OK), then a
// message box "Point-of-sale Memo!" with its words and OK. Until 2.6.10 any such window stopped the entry
// (or the phone's Repair Order request) for a person to answer.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;

namespace TempeCostar {
    internal sealed partial class Runner {
        // Said with the result (the phone, the desk, the eBay PC): the customer's Notes answered. A memo's words go
        // with the things to check by hand (Checks): they're for the person (an instruction about the account, say).
        internal readonly List<string> Notices=new List<string>();
        int popupsAnswered;
        const int MostPopups=6;
        // The notices whose OK went: each waited for while it closes, never pressed again (2.6.11).
        readonly PressedNotices pressedNotices=new PressedNotices();readonly Stopwatch noticeClock=Stopwatch.StartNew();
        // What a COSTAR window over the order is, from its title, class and buttons alone: "notes" (the customer's
        // Notes: never read, they hold card details), "memo" (a Point-of-sale Memo), "notice" (another message
        // box with one OK), or null (anything else: a question with choices, a window with other buttons, the
        // Customer Not found notice (the customer lookup answers that one itself), the Repair Order...). Pure.
        internal static string PopupKind(string title,string cls,IList<string> buttons,string words) {
            if(buttons==null||buttons.Count!=1||Order.Norm(buttons[0]).Replace("&","")!="OK") return null;
            string t=Order.Clean(title);cls=cls??"";
            if(t.Equals("Notes",StringComparison.OrdinalIgnoreCase)) return cls.StartsWith("WindowsForms10.Window",StringComparison.OrdinalIgnoreCase)?"notes":null;
            if(cls!="#32770") return null;
            // A message box always has words: none read (COSTAR busy) is not known well enough to answer (it could be
            // Customer Not found, which the lookup must see for itself).
            if(Order.Norm(words).Length==0||Order.Norm(words).Contains("NOT FOUND")) return null;
            return t.StartsWith("Point-of-sale Memo",StringComparison.OrdinalIgnoreCase)?"memo":"notice";
        }
        // A button's name for PopupKind: a greyed one, or one whose text couldn't be read, is "?" (never OK). Pure.
        internal static string ButtonName(bool enabled,string text) { return enabled&&text!=null?text:"?"; }
        // A memo's words for the person: numbers (3 digits or more) and emails taken out, 160 letters.
        internal static string MemoWords(string words) {
            // Every run of digits holding 3 or more (with spaces, dashes, slashes or dots between) goes: a card number
            // with its expiry and code, a phone, an account or amount. Two-digit numbers stay.
            string w=Regex.Replace(Order.Norm(words),@"\d[\d \-/.]*\d",m=>m.Value.Count(Char.IsDigit)>=3?"[number]":m.Value);
            w=Regex.Replace(w,@"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}","[email]");
            return w.Length>160?w.Substring(0,160)+"...":w;
        }
        // Whether the window is this order's own (owned, directly or through other owned windows, by its Repair
        // Order window): another order's notes are never touched. (A window of COSTAR's from before the run that is
        // owned by this Repair Order is still this order's: the phone's Repair Orders make their Runner after the
        // Repair Order, and its Notes, have shown.)
        bool OwnedByOrder(IntPtr window) {
            var owner=window;
            for(int i=0;i<16&&owner!=IntPtr.Zero;i++) { owner=Native.GetWindow(owner,4);if(owner==root) return true; }
            return false;
        }
        // Whether a window is the customer's Notes (by title alone): its contents are never read or dumped, even
        // when it can't be answered.
        internal static bool IsNotesWindow(IntPtr window) {
            return window!=IntPtr.Zero&&Order.Clean(Native.Caption(window)).Equals("Notes",StringComparison.OrdinalIgnoreCase)&&Native.Class(window).StartsWith("WindowsForms10.Window",StringComparison.OrdinalIgnoreCase);
        }
        // A Point-of-sale Memo (a message box): its words may hold card details, so it is never dumped either.
        internal static bool IsMemoWindow(IntPtr window) {
            return window!=IntPtr.Zero&&Native.Class(window)=="#32770"&&Order.Clean(Native.Caption(window)).StartsWith("Point-of-sale Memo",StringComparison.OrdinalIgnoreCase);
        }
        // The window in front answered with its OK when it is one of COSTAR's notices over this order. True:
        // answered (gone), or its OK went and it is being waited for (the caller looks again; after
        // PressedNotices.CloseMs the run stops). False: not such a notice, or its OK couldn't be sent (nothing pressed).
        bool AnswerPopup(IntPtr front) {
            if(front==IntPtr.Zero||front==root||!Native.IsWindow(front)||!Native.IsWindowVisible(front)||Native.Pid(front)!=pid) return false;
            if(Native.Caption(front).StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase)||!OwnedByOrder(front)) return false;
            // A notice whose OK went is known by its window alone (not read again: COSTAR may be busy closing it):
            // waited for, never pressed again, never cancelled. Ones gone since are forgotten.
            pressedNotices.Sweep(delegate(long w) { var h=new IntPtr(w);return Native.IsWindow(h)&&Native.IsWindowVisible(h); });
            string pressedKind;string look=pressedNotices.Look(front.ToInt64(),noticeClock.ElapsedMilliseconds,out pressedKind);
            if(look!=null) {
                Order.Require(look=="wait","COSTAR's "+(pressedKind=="notes"?"Notes":"notice")+" over the order stayed open after its OK was pressed. Nothing more was pressed: close it at the PC, then retry.");
                Pause(100);return true;
            }
            string title=Native.Caption(front),cls=Native.Class(front);
            var buttons=new List<IntPtr>();var names=new List<string>();var statics=new List<string>();
            Native.EnumChildWindows(front,delegate(IntPtr h,IntPtr unused) {
                if(!Native.IsWindowVisible(h)) return true;
                string c=Native.Class(h),t;
                // A greyed button isn't one to press: the window is then not known well enough.
                if(c.IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0) { buttons.Add(h);names.Add(ButtonName(Native.IsWindowEnabled(h),Native.TryText(h,out t)?t:null)); }
                else if(cls=="#32770"&&c.IndexOf("STATIC",StringComparison.OrdinalIgnoreCase)>=0&&Native.TryText(h,out t)&&Order.Clean(t).Length>0) statics.Add(Order.Clean(t));
                return buttons.Count+statics.Count<40;
            },IntPtr.Zero);
            string kind=PopupKind(title,cls,names,String.Join(" ",statics.ToArray()));
            if(kind==null) return false;
            Order.Require(popupsAnswered<MostPopups,"COSTAR keeps showing notices over the order ("+popupsAnswered+" answered with OK). Look at COSTAR before retrying.");
            // Its own OK (BM_CLICK sent; a message box's OK closes it as it returns). Nothing else is pressed. Not sent
            // at all (the button went): nothing pressed, the caller's usual way. Sent (answered or not): remembered,
            // never pressed again; what COSTAR showed is said from now on, however long it takes to close.
            int sent=Direct.Press(buttons[0],1500);Diag.Pressed();
            if(sent<0) { Diag.EventRaw("popup_ok",kind+" \""+Sanitize.Text(title,40)+"\": OK couldn't be pressed");return false; }
            pressedNotices.Pressed(front.ToInt64(),noticeClock.ElapsedMilliseconds,kind);popupsAnswered++;
            string note=kind=="notes"?"COSTAR showed the customer's Notes before the order (OK pressed): see them in COSTAR if you need to."
                :"COSTAR showed "+(kind=="memo"?"a Point-of-sale Memo":"a notice \""+Sanitize.Text(title,40)+"\"")+": \""+MemoWords(String.Join(" ",statics.ToArray()))+"\" (OK pressed).";
            var list=kind=="notes"?Notices:Checks;
            if(!list.Contains(note)) list.Add(note);
            var gone=Stopwatch.StartNew();
            while(Native.IsWindow(front)&&Native.IsWindowVisible(front)&&gone.ElapsedMilliseconds<(sent==0?3000:2000)) Pause(25);
            bool closed=!Native.IsWindow(front)||!Native.IsWindowVisible(front);
            if(closed) pressedNotices.Gone(front.ToInt64());
            Diag.EventRaw("popup_ok",kind+" \""+Sanitize.Text(title,40)+"\": "+(closed?"closed":"still showing")+" ("+(sent==1?"OK pressed":"OK unanswered")+")");
            if(closed) Say("Answered COSTAR's "+(kind=="notes"?"Notes":kind=="memo"?"Point-of-sale Memo":"notice")+" with OK.");
            return true;
        }
        // The Notes answered, for the result ("" when none).
        internal string NoticeWords(string separator) { return Notices.Count==0?"":String.Join(separator,Notices.ToArray()); }
    }

    // 2.6.11: the notices whose OK went, each with when and its kind. One still showing is waited for (CloseMs from
    // its press), never pressed again and never cancelled; one gone (closed or hidden) is forgotten, so a window
    // shown again later is a new notice. Several at once are all remembered. Pure: the time is given.
    internal sealed class PressedNotices {
        sealed class Press { internal long At;internal string Kind; }
        readonly Dictionary<long,Press> pressed=new Dictionary<long,Press>();
        internal const int CloseMs=6000;
        internal int Count { get { return pressed.Count; } }
        internal void Pressed(long window,long nowMs,string kind) { pressed[window]=new Press {At=nowMs,Kind=kind}; }
        internal void Gone(long window) { pressed.Remove(window); }
        // null: its OK hasn't gone (it may be answered); "wait": it has, give it time; "stop": CloseMs on, still there.
        internal string Look(long window,long nowMs,out string kind) {
            Press p;kind=null;
            if(!pressed.TryGetValue(window,out p)) return null;
            kind=p.Kind;return nowMs-p.At<CloseMs?"wait":"stop";
        }
        internal void Sweep(Func<long,bool> showing) { foreach(long w in pressed.Keys.ToList()) if(!showing(w)) pressed.Remove(w); }
    }
}
