// The entry engine, part 4 of 4: the online order run (Run), its final check (Verify) and
// disposal/report packing.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed partial class Runner {
        // DET's notes: COSTAR makes them once DET loses focus. They must be right under DET (detLine:
        // DET's line when known, else 0), then the car, rego, odometer and payment go in.
        void DetNotes(int detLine) {
            WaitForDetailsTemplate();
            RequireNotesUnderDet(detLine);
            Memo("MAKE/MODEL",order.vehicle,"M",false);
            Memo("REGO NO",order.rego,"M",false);
            Memo("ODOMETER","","M ODO",false);
            if(payment.Length>0)Memo("PAYING BY",payment,"M PC");
        }
        void Verify(List<ControlInfo> s) {
            var h=Selectors.Header(s); var c=order.customer;
            Order.Require(CustomerEntry.SameIdentity(h.Account.Value,h.Name.Value,h.Phone.Value,verifiedCustomerAccount,verifiedCustomerName,c.phone),"The customer account/name/phone changed after lookup. Check the Repair Order before saving.");
            var checks=new[]{new{Actual=h.Address.Value,Expected=c.streetAddress,Label="address"},
                new{Actual=h.Suburb.Value,Expected=c.suburb,Label="suburb"},new{Actual=h.Postcode.Value,Expected=c.postcode,Label="postcode"},
                new{Actual=h.PO.Value,Expected=order.orderId,Label="PO#"},new{Actual=h.Comment.Value,Expected=order.comment,Label="comment"}};
            foreach(var check in checks) if(!String.IsNullOrWhiteSpace(check.Expected)) Order.Require(Order.Norm(check.Actual)==Order.Norm(check.Expected),"Final check failed: " + check.Label + ".");
            if(!String.IsNullOrWhiteSpace(c.email))Order.Require(Order.Clean(h.Email.Value)==Order.Clean(FieldText(c.email,true)),"Final email check failed: the supplied address must be retained in lowercase.");
            if(!String.IsNullOrWhiteSpace(c.streetAddress))Order.Require(Order.Norm(h.Address2.Value)==Order.Norm(c.address2),"Final billing address line 2 check failed.");
            if(!String.IsNullOrWhiteSpace(c.state))Order.Require(Order.Norm(h.State.Value)==Order.Norm(c.state),"Final billing state check failed.");
            Order.Require(Order.Phone(h.Phone.Value)==Order.Phone(c.phone),"Final phone check failed.");
            if(!order.IsDelivery) {
                try {
                    var timeIn=Selectors.TimeIn(s);string booked=Order.TimeInText(order.pickupTime);
                    if(timeIn!=null && booked!=null && Order.ClockMinutes(timeIn.Value)!=Order.ClockMinutes(booked)) {
                        Say("Note: Time in shows "+timeIn.Value+", booking time is "+booked+".");
                        // 2.8.0: a check (the order isn't closed with the wrong time), once.
                        if(!Checks.Any(x=>x.IndexOf("Time in",StringComparison.Ordinal)>=0)) Checks.Add("Time in shows "+timeIn.Value+": make it "+booked+" (the booking time) by hand.");
                    }
                } catch(InvalidOperationException) { }
            }
            var g=Selectors.ProductGrid(s);
            var noteCodes=order.IsDelivery?new[]{"DET","M","M FB","M ODO","M PC","M C","F"}:new[]{"DET","M","M FB","M ODO","M PC"};
            var steps=order.ItemSteps(fitting);
            var expectedLines=steps.Where(step=>step.Line!=null).Select(step=>step.Line).ToList();
            var enteredItems=g.Rows.Where(r=>r.Value.Length>0 && (Order.Norm(r.Value)=="M FB" || !noteCodes.Contains(Order.Norm(r.Value)))).ToList();
            Order.Require(enteredItems.Select(r=>Order.Norm(r.Value)).SequenceEqual(steps.Select(step=>step.Code)),"Final item order must be wheels, tyres, fitting/balancing, then alignment.");
            if(!order.IsDelivery) {
                var dets=g.Rows.Where(r=>Order.Norm(r.Value)=="DET").ToList();
                Order.Require(dets.Count==1,"Final check failed: the order must have exactly one DET line.");
                int detAt=g.LineOf(dets[0].Handle);
                if(enteredItems.Any(r=>g.LineOf(r.Handle)>detAt)) Say("Note: some items are after DET's notes on this order (no free line was left above DET, or it was started that way).");
            }
            var paid=g.Rows.Where(r=>r.Value.Length>0 && !noteCodes.Contains(Order.Norm(r.Value))).ToList();
            Order.Require(paid.Count==expectedLines.Count,"Unexpected number of product/service rows after entry.");
            for(int i=0;i<paid.Count;i++) {
                var line=expectedLines[i]; var r=paid[i];
                int expectedPrice=line.unitCents;
                if(line.kind=="package") Order.Require(packagePrices.TryGetValue(order.lines.IndexOf(line),out expectedPrice),"The package item's retained price was not recorded.");
                Order.Require(Order.Norm(r.Value)==line.code && Selectors.Cell(s,r,g.Quantity).Value==line.quantity.ToString(CultureInfo.InvariantCulture) && Selectors.Cents(Selectors.Cell(s,r,g.Net))==expectedPrice,"Final check failed on item " + line.code + ".");
            }
            var descriptions=g.Rows.Where(r=>r.Value.Length>0).Select(r=>Selectors.Cell(s,r,g.Description).Value).ToList();
            if(order.IsDelivery) {
                var d=Selectors.Delivery(s);var expected=order.shipping;
                var deliveryChecks=new[]{new{Actual=d.Name.Value,Expected=expected.name,Label="delivery recipient"},new{Actual=d.Address.Value,Expected=expected.streetAddress,Label="delivery street"},
                    new{Actual=d.Address2.Value,Expected=expected.address2,Label="delivery address line 2"},new{Actual=d.Suburb.Value,Expected=expected.suburb,Label="delivery suburb"},
                    new{Actual=d.State.Value,Expected=expected.state,Label="delivery state"},new{Actual=d.Postcode.Value,Expected=expected.postcode,Label="delivery postcode"},
                    new{Actual=d.Contact.Value,Expected=expected.contact,Label="delivery contact"},
                    new{Actual=d.ShipVia.Value,Expected=expected.shipVia,Label="Ship Via"},new{Actual=d.Instructions.Value,Expected=expected.instructions,Label="shipping instructions"},
                    new{Actual=h.State.Value,Expected=c.state,Label="billing state"},new{Actual=h.Address2.Value,Expected=c.address2,Label="billing address line 2"}};
                foreach(var check in deliveryChecks) Order.Require(Order.Norm(check.Actual)==Order.Norm(check.Expected),"Final check failed: " + check.Label + ".");
                Order.Require(Order.Clean(d.Email.Value)==Order.Clean(FieldText(expected.email,true)),"Final delivery email check failed: the address must be retained in lowercase.");
                Order.Require(Order.Phone(d.BusinessPhone.Value)==Order.Phone(expected.businessPhone) && Order.Phone(d.MobilePhone.Value)==Order.Phone(expected.mobilePhone),"Final delivery phone check failed.");
                var freight=g.Rows.Where(r=>Order.Norm(r.Value)=="F").ToList();
                Order.Require(freight.Count==(order.freightCents>0?1:0),"Unexpected number of freight rows.");
                if(freight.Count==1) Order.Require(Selectors.Cell(s,freight[0],g.Quantity).Value=="1" && Selectors.Cents(Selectors.Cell(s,freight[0],g.Net))==order.freightCents,"Final freight check failed.");
                string vehicleNote="TO SUIT:"+(order.DeliveryVehicleNote.Length==0?"":" "+order.DeliveryVehicleNote);
                Order.Require(descriptions.Count(value=>Order.Norm(value)==Order.Norm(vehicleNote))==1,"Final delivery vehicle note check failed.");
                Order.Require(!g.Rows.Any(r=>new[]{"DET","M FB","M ODO"}.Contains(Order.Norm(r.Value))),"An unexpected pickup note was added to the delivery order.");
            } else Selectors.CheckDetBlock(s,order.vehicle,order.rego,payment);
            if(payment.Length>0) Order.Require(descriptions.Count(d=>Order.Norm(d)=="PAYING BY: "+Order.Norm(payment))==1,"Final payment note check failed.");
            // Only the exact automatic surcharge may be absent from an otherwise
            // complete order total. The package exception remains separate.
            if(!order.requiresReview) Order.Require(order.MatchesCostarTotal(Selectors.Total(s)),"COSTAR total does not match the online amount before or after its automatic card surcharge. Check the order manually; no save was attempted.");
        }
        internal void Run() {
            try {
                Diag.Kind=order.IsDelivery?"online-delivery":"online-pickup";
                order.Validate(true); Order.Safe(payment,"payment note",60);
                runClock.Restart();
                stageCount=4+(order.lines==null?0:order.lines.Count)+(order.IsDelivery?1:3);
                Diag.BeginStage(FreshlyOpened?"Startup: wait for new Repair Order":"Startup: verify empty Repair Order");Stage("Opening the Repair Order");
                List<ControlInfo> initial;
                if(FreshlyOpened) {
                    // A visible title is not proof that the new form's fields have loaded.
                    enteringCustomer=false;Activate();initial=WaitForMobileStartup();enteringCustomer=true;
                } else {enteringCustomer=true;ActivateAndWait();initial=Settled(Current());}
                Dump("before-controls",initial);Diag.Layout(initial);
                // A stopped earlier attempt of this same order (PO# = order number, same phone):
                // continue in it instead of opening another Repair Order.
                // 2.3.1: the Repair Order this helper stopped this order in (this session) is only used
                // again if it holds exactly what it held at the stop, whatever stage the stop was at. One
                // changed by hand since, or not read steadily, is left alone. Nothing typed.
                if(OwnAttempt) {
                    Order.Require(ResumePrint!=null,"The stopped attempt couldn't be recorded when it stopped, so this Repair Order isn't continued. Nothing was typed; finish it in COSTAR.");
                    string now=SettledPrint();
                    if(now!=ResumePrint) Diag.EventRaw("resume_changed",now==null?"could not read it steadily":"held "+ResumePrint.Length+" chars at the stop, "+now.Length+" now");
                    Order.Require(now==ResumePrint,"This Repair Order changed after the helper stopped (or couldn't be read steadily), so it isn't continued. Nothing was typed; finish it in COSTAR.");
                    ResumeVerified=true;
                }
                bool resuming=false;
                if(!FreshlyOpened && Selectors.SameOrderInProgress(initial,order)) {
                    // A Repair Order already holding this order (PO# and phone) is only continued when
                    // it is that stopped attempt. One typed or finished by hand is left alone.
                    Order.Require(OwnAttempt,"This Repair Order already holds "+order.orderId+" (same PO# and phone), but this helper didn't start it this session, so it isn't continued. Nothing was typed; finish it in COSTAR.");
                    resuming=true;
                    if(MustResume) Diag.EventRaw("resume_listed_order","Order Check lists this order; continuing the helper's own unchanged attempt");
                }
                // Order Check already lists this order: never a fresh entry. Checked before typing.
                if(MustResume && !resuming) throw new InvalidOperationException(DuplicateMessage??order.orderId+" is already in COSTAR. Nothing was typed.");
                if(resuming) {
                    Diag.EventRaw("resume_order","PO# and phone match this order; continuing where the earlier attempt stopped");
                    Say("This Repair Order already holds "+order.orderId+" from an earlier attempt. Continuing where it stopped.");
                } else if(Selectors.SameCustomerStart(initial,order)) {
                    Diag.EventRaw("same_customer_start","Repair Order already holds this order's phone with no items");
                    Say("This Repair Order already holds this order's customer and no items. Re-checking the customer, then comparing and updating the details.");
                } else {
                    try {
                        Selectors.Blank(initial,branch);
                        if(order.IsDelivery) Selectors.BlankDelivery(initial,branch);
                    } catch(InvalidOperationException busy) {
                        // Nothing has been typed yet. An order opened by the helper itself is
                        // always new, so only a reused, already-open order can be "in use".
                        if(writes==0 && !FreshlyOpened) throw new RepairOrderInUseException(busy.Message);
                        throw;
                    }
                    Say("Verified an empty Repair Order. Looking up the customer's phone first.");
                }
                Diag.EndStage(true);
                bool existing=false;
                if(resuming) Timed("Resume: customer already looked up",delegate {
                    var current=HeaderNow();lookupPhone=order.customer.phone;
                    verifiedCustomerAccount=current.Account.Value;existing=Order.Clean(current.Account.Value).Length>0;
                    if(existing)verifiedCustomerName=current.Name.Value;
                    Say(existing?"Customer account already on the order; keeping it.":"No customer account on the order; checking the entered details.");
                });
                else Timed("Customer phone lookup",delegate {
                    var h=Selectors.Header(initial);lookupPhone=order.customer.phone;Put(h.Phone,order.customer.phone,"customer phone",true);
                    existing=LookupCustomer();var matched=HeaderNow();
                    verifiedCustomerAccount=matched.Account.Value;
                    if(existing)verifiedCustomerName=matched.Name.Value;
                    Say(existing?"Matched phone; retaining COSTAR's account and customer name.":"No matching customer; entering the order's customer details.");
                });
                Timed("Customer and order header",delegate {
                    FillOnlineHeader(existing);
                    if(order.IsDelivery)FillDelivery();
                    CustomerFormReady(0);
                    var confirmed=HeaderNow();
                    Order.Require(CustomerEntry.SameIdentity(confirmed.Account.Value,confirmed.Name.Value,confirmed.Phone.Value,verifiedCustomerAccount,verifiedCustomerName,order.customer.phone),"The selected customer account/name/phone changed during entry.");
                });
                enteringCustomer=false;
                var itemSteps=order.ItemSteps(fitting);
                foreach(var step in itemSteps) itemCodes.Add(Order.Norm(step.Code));
                stageCount=stageIndex+itemSteps.Count+(order.IsDelivery?2:3);
                // Pickups, "DET first" ticked (2.3.0, the default): DET and its notes go in first on line 6
                // (lower for a long order), then the items fill the lines above it from line 1. Not ticked
                // (2.3.2), or when this order can't have it: the items first, then DET and its notes after
                // them, as before 2.3.0. Deliveries have no DET: items, freight, then the notes.
                int above=0;bool detDone=false;
                if(!order.IsDelivery) {
                    long existingDet=resuming?ExistingRow("DET",0):0;
                    if(existingDet!=0) {
                        // Out of the item grid first (focus on PO#), so no line is open. A stop while DET's
                        // notes were being made: leaving DET makes them; wait for them first.
                        LeaveGrid("before checking the stopped order");
                        bool notes;
                        try { notes=Selectors.FindMemo(GridCurrent(),"MAKE/MODEL","M")!=null; } catch(InvalidOperationException) { notes=false; }
                        if(!notes) WaitForDetailsTemplate();
                        List<ControlInfo> ds;bool dn;
                        var dg=SteadyGrid("resume: DET's line",true,out ds,out dn);
                        Order.Require(dg!=null && dg.LineOf(existingDet)>0,"COSTAR's item grid kept changing, so the stopped order can't be checked. Entry stopped; check the order.");
                        int detAt=dn?dg.LineOf(existingDet):0;
                        // Items still missing: above DET (DET first), or after everything (DET last).
                        if(DetFirst) above=detAt>0?detAt:-1;
                        Diag.SetEnv("detLine",(detAt>0?detAt.ToString(CultureInfo.InvariantCulture):"?")+" (already entered)");
                        Timed("Details (DET already entered)",delegate {
                            Say(detAt>0?"DET was already entered on line "+detAt+".":"DET was already entered.");
                            DetNotes(detAt);
                        });
                        detDone=true;
                    } else if(DetFirst) {
                        int detLine=DetFirstLine(itemSteps.Count);
                        if(detLine>0) {
                            above=detLine;detDone=true;
                            Diag.SetEnv("detLine",detLine.ToString(CultureInfo.InvariantCulture));
                            Timed("Details first (DET block)",delegate {
                                AddCode("DET",false,commitOutsideGrid:true,line:detLine);
                                DetNotes(detLine);
                            });
                        } else Diag.SetEnv("detLine","last (this order)");
                    } else {
                        Diag.SetEnv("detLine","last (DET first is off)");
                        Say("DET first is off: the items go in first, then DET and its notes after them.");
                    }
                }
                var occurrences=new Dictionary<string,int>(StringComparer.Ordinal);
                foreach(var step in itemSteps) {
                    string code=Order.Norm(step.Code);int nth;occurrences.TryGetValue(code,out nth);occurrences[code]=nth+1;
                    long already=resuming?ExistingRow(code,nth):0;
                    Timed("Item "+step.Code,delegate {
                        if(already!=0) {
                            if(step.Line!=null)FinishLine(step.Line,already);
                            Say("Item "+step.Code+" was already entered; checked it.");
                        }
                        else if(step.Line!=null)AddLine(step.Line,above);else AddCode(step.Code,false,above:above);
                    });
                }
                if(!order.IsDelivery && !detDone) Timed("Details (DET after the items)",delegate {
                    AddCode("DET",false,commitOutsideGrid:true);
                    DetNotes(0);
                });
                if(order.IsDelivery) Timed("Details and freight",delegate {
                    long freight=resuming&&order.freightCents>0?ExistingRow("F",0):0;
                    if(freight!=0)FinishFreight(freight);else AddFreight();
                    Memo("TO SUIT",order.DeliveryVehicleNote,"M C");
                    if(payment.Length>0)Memo("PAYING BY",payment,"M PC");
                });
                // 2.8.0 (Tommy, 2 Nov: "Please put SHOP on online orders"): every pickup, not only customers with a
                // COSTAR customer number. Deliveries keep their own Ship Via.
                if(!order.IsDelivery) {
                    // Never fatal: the order is in by now (as for phone jobs); not SHOP is a check.
                    bool shop=false;string why="";
                    try { Timed("Ship Via SHOP",delegate { shop=SetShipViaShop(true); }); }
                    catch(InvalidOperationException e) { why=" ("+e.Message+")"; }
                    if(!shop) Checks.Add("Ship Via isn't SHOP"+why+": enter SHOP by hand.");
                }
                Diag.BeginStage("Final verification and report");Stage("Final check");Ready();var final=Current();Verify(final);Dump("after-controls",final);
                // 2.8.0: Customer Waiting only for a pickup booked today 14:00-16:00 or tomorrow 08:00-09:00; last,
                // as for phone jobs (COSTAR may print a picking slip once it's ticked); never fatal: not ticked is a check.
                if(!order.IsDelivery && Order.WaitingSlot(order.pickupDate,order.pickupTime,DateTime.Today)) {
                    bool waiting=false;string why="";
                    try { Timed("Customer Waiting",delegate { OrderWindowBack("Customer Waiting");waiting=TickCustomerWaiting();if(waiting) waitingBox=tickedWaiting; }); }
                    catch(OperationCanceledException) { why=" (stopped)"; }
                    catch(Exception e) { why=" ("+e.Message+")"; }
                    if(!waiting) Checks.Add("Customer Waiting not ticked"+why+": booked "+order.pickupDate+" "+order.pickupTime+", tick it.");
                } else if(!order.IsDelivery) Say("Customer Waiting left as it is (booked "+order.pickupDate+" "+order.pickupTime+"; it is ticked for today 14:00-16:00 and tomorrow 08:00-09:00).");
                int actualTotal=Selectors.Total(final);
                File.WriteAllText(Path.Combine(Folder,"review.json"),json.Serialize(new{OrderId=order.orderId,ManualCompletionRequired=order.requiresReview,OnlineTotalCents=order.totalCents,CostarTotalCents=actualTotal,DifferenceCents=order.totalCents-actualTotal,
                    CustomerEntryMode="Phone first; retain COSTAR account/name; update supplied address",CustomerPopupRecoveryActions=recoveryActions,CustomerLookupCancelled=lookupCancelled,
                    OnlineCardSurchargeCents=order.surchargeCents,OnlineTotalBeforeSurchargeCents=order.TotalBeforeSurchargeCents,CardSurchargeHandledBy="COSTAR",
                    TotalCheck=order.requiresReview?"Package requires manual completion":(actualTotal==order.totalCents?"Online total matched":"Total before automatic card surcharge matched"),
                    IncompletePackages=order.lines.Where(l=>l.kind=="package").Select(l=>new{l.code,l.description,l.quantity,OnlinePackageTotalCents=l.totalCents}).ToArray()}),new UTF8Encoding(false));
                // 2.8.0 (Tommy, 2 Nov 20:58: review only what needs a look, "yes"): an order that is in and needs nothing
                // by hand is closed as an eBay order is (it stays in Work-in-Progress); with a check, or a package to
                // finish, it stays open for a person.
                if(CloseWhenEntered && !order.requiresReview) CloseEntered(actualTotal);
                if(order.surchargeCents>0) Say("Website card surcharge $"+(order.surchargeCents/100m).ToString("0.00",CultureInfo.InvariantCulture)+" is handled by COSTAR. No surcharge item was entered. Website total $"+(order.totalCents/100m).ToString("0.00",CultureInfo.InvariantCulture)+"; current COSTAR total $"+(actualTotal/100m).ToString("0.00",CultureInfo.InvariantCulture)+".");
                if(order.requiresReview) Say("MANUAL COMPLETION REQUIRED - " + order.orderId + ": add missing package tyres and review wheel quantity/pricing. COSTAR $"+(actualTotal/100m).ToString("0.00",CultureInfo.InvariantCulture)+"; online $"+(order.totalCents/100m).ToString("0.00",CultureInfo.InvariantCulture)+". Repair Order left open.");
                else Say((Closed?"IN COSTAR - ":"READY FOR REVIEW - ") + order.orderId + " - total $" + (actualTotal/100m).ToString("0.00",CultureInfo.InvariantCulture) + (order.surchargeCents>0 && actualTotal==order.TotalBeforeSurchargeCents?" before COSTAR's automatic card surcharge":"") + (Closed?". Closed (it's in Work-in-Progress).":". Repair Order left open."));
                if(Checks.Count>0) Say("CHECK BY HAND before saving: "+String.Join(" ",Checks.ToArray()));
                Diag.EndStage(true);Diag.Completed();
            } catch(Exception error) {
                Diag.Stopped(error);TraceFocus("Stopped run",null);
                Say("STOPPED: " + error.Message);
                try { if(!process.HasExited && Native.IsWindow(root)) { bool saved=Cancel; Cancel=false; try { CaptureForegroundWindow(error.Message); Dump("stopped-controls",Snapshot(root)); if(writes>0 || ResumeVerified) { try { StopPrint=SettledPrint(); } catch(Exception) { StopPrint=null; } } } finally { Cancel=saved; } } } catch { }
                throw;
            } finally { log.Flush(); }
        }
        public void Dispose() {
            if(fastTimer){Native.timeEndPeriod(1);fastTimer=false;}
            try {File.WriteAllText(Path.Combine(Folder,"timing.json"),json.Serialize(new {Version=AutofillForm.Version,ElapsedMilliseconds=runClock.ElapsedMilliseconds,Writes=writes,SnapshotCount=snapshotCount,GridSnapshotCount=gridSnapshotCount,ControlTextReads=controlTextReads,SkippedQuantities=skippedQuantities,SnapshotMilliseconds=snapshotMilliseconds,Stages=timings}),new UTF8Encoding(false));}catch{}
            try {Diag.Reads(skippedReads,lateReads,headerReads,headerHits);Diag.Finish(runClock.ElapsedMilliseconds,writes,snapshotCount,gridSnapshotCount,controlTextReads,skippedQuantities,snapshotMilliseconds);Diag.Save(Folder);}catch{}
            log.Dispose(); process.Dispose();
            try { ZipPath=Folder+".zip"; ZipFile.CreateFromDirectory(Folder,ZipPath,CompressionLevel.Fastest,false); } catch { ZipPath=Folder; }
            // The ZIP holds the complete report; keep a single copy of customer details.
            if(ZipPath!=Folder) { try { Directory.Delete(Folder,true); } catch { } }
            ReportRetention.Prune();
            classCache.Clear();headerCache=null;gridLabels=null;
            Memory.Trim();
            if(busySnapshots>0) Diag.EventRaw("costar_busy_skips",busySnapshots+" snapshots, "+busySkips+" field reads not sent while COSTAR was busy");
            PerfMonitor.AfterJob(Diag==null?"":Diag.RunId);
        }
    }
}
