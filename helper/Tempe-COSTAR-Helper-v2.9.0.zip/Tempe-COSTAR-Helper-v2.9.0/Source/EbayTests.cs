// Self-tests for eBay orders (2.5.0): the order and its plan, the desk queue and API, the PIN
// pairing, the layout rules for Rebill to and the staff boxes, the final line check and the
// helper's retry decisions. Never opens, clicks or types into COSTAR. Made-up buyer details.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;

namespace TempeCostar {
    internal static class EbayTests {
        static void Check(bool value,string message){if(!value)throw new InvalidOperationException(message);}
        static void Reject(Action action,string message){bool rejected=false;try{action();}catch(InvalidOperationException){rejected=true;}Check(rejected,message);}
        internal static EbayOrder Sample(string number="11-11111-11111") {
            return new EbayOrder {schema=EbayOrder.Schema,submissionId="EBY-"+number,createdUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture),orderNumber=number,
                orderDate=DateTime.UtcNow.ToString("dd/MM/yy",CultureInfo.InvariantCulture),priceSource="total minus freight",sentFrom="404 But It's Found 1.4",
                buyer=new EbayBuyer {name="Test Buyer",phone="0400 000 001",email="abc123def456@members.ebay.com",username="testbuyer1"},
                address=new EbayAddress {street="1 TEST CRESCENT",street2="",suburb="TESTVILLE",state="NSW",postcode="2799"},
                items=new List<EbayItem> {new EbayItem {sku="W43116",itemId="175288170173",title="WINRUN 265/70R16 112T MAXCLAW A/T",quantity=1,unitCents=14000}},
                freightCents=1000,totalCents=15000};
        }
        static EbayQueue Queue(){return new EbayQueue(null,s=>{});}
        // Made-up certificates for the desk certificate test (public parts only; the keys were thrown
        // away): two roots and a desk certificate signed by the first. Fixed bytes, so the test needs
        // nothing newer than the rest of the helper.
        const string TestRootA="MIIDFTCCAf2gAwIBAgICWgEwDQYJKoZIhvcNAQELBQAwKjEoMCYGA1UEAxMfVGVtcGUgU2VsZi1UZXN0IFJvb3QgQSA4YzQxZDI3ZTAeFw0yNjAxMDEwMDAwMDBaFw00NjAxMDEwMDAwMDBaMCoxKDAmBgNVBAMTH1RlbXBlIFNlbGYtVGVzdCBSb290IEEgOGM0MWQyN2UwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDBn33Bk7xoeQwWlrvktPMMs6CQ3x33/BMQ99+WY89e1Aop/nuUn2b4rgXIqnaJ6nSybY1P4IDX2zHaE/xpDhk7jI72WiLcvF8R8L5g7s0cABMGNXPVe0qExmLVZygPivv0wbkbWdtRPqlywkbu0+Wupk0LxcqOgC8pDGC1rVWp8SnpFguj9OitbM+RWVgdeVDyeCIel5oGITtlWXOiTYeMcIu4IdVfQXYn2qfBIr9zGTJkVtCj1GStEO2iRXrrDseC20hlghlCOLs42XYUEMA9j90oWNaBFgny7dJa8DGn7o7UwFoIthZlc+F2rpc2Mmj6cVcjJvZBkNcBMQV3vaS7AgMBAAGjRTBDMBIGA1UdEwEB/wQIMAYBAf8CAQEwDgYDVR0PAQH/BAQDAgEGMB0GA1UdDgQWBBRd+FgtRrpxKoIcBvMqmWJRq3c+WzANBgkqhkiG9w0BAQsFAAOCAQEAXX9XgfmS/9Dr42Xp6ULz2QSUacZDKVGZEj+sVa6aJ4OBVi8iDiV6A3WIS2BAuY/jmG8nHoAW1G8+FYsHbEKfJIr6jirezscb67Ii9E0rApPtnhe/AKXrgfHwdEjT8rV77JT3/n84PICe4MEt68SEyI1IfL+UjcdcrBTtYTyTps96PchdW6IAjH7cFUt/V9TkzExnIB9YrxBULyWsOjPaKj/iQC53uK9sePdDtdEH46JmBLOkOseRFm4XXJHCx6N5zhN44OqYgwp57V30XZcBoWUyXAxh6dBhgYu6riUvR6OLCE1uMUhJM+PeZIqiql1wNoxcVfsSE/bqWGBYdhb+vg==";
        const string TestRootB="MIIDFTCCAf2gAwIBAgICWwEwDQYJKoZIhvcNAQELBQAwKjEoMCYGA1UEAxMfVGVtcGUgU2VsZi1UZXN0IFJvb3QgQiA4YzQxZDI3ZTAeFw0yNjAxMDEwMDAwMDBaFw00NjAxMDEwMDAwMDBaMCoxKDAmBgNVBAMTH1RlbXBlIFNlbGYtVGVzdCBSb290IEIgOGM0MWQyN2UwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCyAYVkRR48qzan7X+78xGkhF+mrNRKruN/fsOzaLdwmaptEORzmAKEtLM2q7hI5mYLPF0g1nlw7PfJFurkqtRslsGa/6QU9U25YmgU/ZRzj3iRBs3sqYtdZo4nlVUc3liOoNbYGzGRJ+VQLOCeuYmqAp8nXPozdiAR1F+R0rmsIQYo5figXsgK6M7Kyf/vqPiWyRk1tPNDPGygmvUqhTzrTEwDJSaD8/bFIvDeHUCMwsoj1rxSXqCN3IcWVqYIgoio2gQ3BmWn+1ixz4vBqFsmLXy6NOVLiGleOTrslD22wvvLpi8wFEtvfeUg5zLp9d732nVtdBiOUY2ncK8YnG3pAgMBAAGjRTBDMBIGA1UdEwEB/wQIMAYBAf8CAQEwDgYDVR0PAQH/BAQDAgEGMB0GA1UdDgQWBBTfKgb9r7qDjRt8HUcXEG+LYpybwzANBgkqhkiG9w0BAQsFAAOCAQEAUX+OTwRRkmSocdDhfZs+MZ3I/k14q6v/JozgZODrSwNLi4WRZikAuj3aSlRODXpirDyssURaDrJV7MLIpZcSAqG9dkLMyd8ZBPJwApgNvVgvmZwcX124FqFA0Qa6omZxH4wH27XMLRTNMoEgUAWN7g7uPRItxzj3rXuwtsRwu/YUPWXH+2QNhujralEh1i/YBmZ2SKPg6IB+WCt/++2D7m/ewkroiaWA/BPwBMcz5zcGXvO03+urb16bmlhoNO7IX3YJ4y+Ng4hpiPhx0rPsYMCkJF5VsVlGk0WBgZJ8N2qnQFUlpiIggZi5rRtT2R1b5uMnbZ2D1WqRdFLUpTM0+g==";
        const string TestDesk="MIIDHjCCAgagAwIBAgICXAEwDQYJKoZIhvcNAQELBQAwKjEoMCYGA1UEAxMfVGVtcGUgU2VsZi1UZXN0IFJvb3QgQSA4YzQxZDI3ZTAeFw0yNjAxMDIwMDAwMDBaFw00NTEyMzEwMDAwMDBaMCgxJjAkBgNVBAMTHVRlbXBlIFNlbGYtVGVzdCBEZXNrIDhjNDFkMjdlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtHENFryIGlWYTItmxR0s0kCXxwZ3pNsN68XDjkuo45y1GGPAQttLqzCJavDL/yPejDRLpvfznUSA/o/icYvWNCOK8C7FBlPHks4wIqemxf4eZfuvzIrNpm+KMt3paB0h5/fMHzIZ2YRH1JIq/fg5letRIPHZbX2hN/1vZCaX3g/h515Ft/v9TvkLS5kecoFuwzUqHy97iaM4xkZit8+1mc3KN/dPJ3IVpIaU7MWqFI5Sg6e/+YcW7ptHf51jjRErQUeFgIJE7s0dxHP+QGPciFBJITAJw3Md3mTpk+HzwHiSbPIlObZxUTfUp3bhbf2CMRmQ1KeKQcmFGHXDTAgRJwIDAQABo1AwTjAMBgNVHRMBAf8EAjAAMB0GA1UdDgQWBBTMBsAaIYtvrt3tOlph9icajZV8mDAfBgNVHSMEGDAWgBRd+FgtRrpxKoIcBvMqmWJRq3c+WzANBgkqhkiG9w0BAQsFAAOCAQEADygzzGPP0p8qb13Vl6GoGdW1yKgWNkvnGRhldrxi4I8f2+BFZS5+DNwFpuA7xfN8xlDj2fJQJ515Jv7hxIq7zyyK8Dbx1GaJoozKIVsueM1CTGMGREN8H/krRpSlglVd2dUi2F1V+Gnr7YepJzb1Z74SvSqKVK9rdWhcLeLKiyMleFrnXDUhWtIbh8BsIH88Nee8lmjO01GRTkWj/IMyfIvOUQ2C1qjv9mX/Cfo1jUW71mUv0sTWViilLbds/dDqfKIQf1KRCqIoPC5OGBeJSEb2b2/zK5VistpCa2LUHFzOZH1X/cvebKAMB6SchJim/reQ6dWUGViXTexfVRj2tA==";
        static EbayHello Hello(EbayReport report=null,bool accepting=true,bool available=true){return new EbayHello {workerId="test-worker",accepting=accepting,available=available,report=report};}
        static EbayHello Working(string lease,EbayReport report=null,int sequence=1000){var h=Hello(report);h.working=lease??"";h.sequence=sequence;return h;}
        static EbayReport Report(EbayReply claim,string status,int sequence,bool typed=false){return new EbayReport {orderNumber=claim.order.orderNumber,lease=claim.lease,status=status,message=status,progress="",sequence=sequence,typed=typed};}
        static HttpInput Request(string method,string path,string token,string origin=null,object body=null) {
            var r=new HttpInput {method=method,path=path,body=body==null?"":Wire.Json(body),headers=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase)};
            if(token!=null)r.headers["authorization"]="Bearer "+token;
            if(origin!=null)r.headers["origin"]=origin;
            if(body!=null)r.headers["content-type"]="application/json";
            return r;
        }
        static T Body<T>(HttpOutput o){return Wire.Read<T>(Encoding.UTF8.GetString(o.bytes));}
        const string Extension="chrome-extension://abcdefghijklmnopabcdefghijklmnop";
        static ControlInfo Mk(long h,long parent,string cls,int x,int y,int w,int hh,string text) {
            return new ControlInfo {Handle=h,Parent=parent,Class=cls,Visible=true,Enabled=true,Bounds=new[]{x,y,w,hh},RelativeBounds=new[]{x,y,w,hh},Text=text,TextState="read"};
        }
        const string ST="WindowsForms10.STATIC.app.0.1",ED="WindowsForms10.EDIT.app.0.1",WN="WindowsForms10.Window.8.app.0.1",BT="WindowsForms10.BUTTON.app.0.1";
        // COSTAR's item grid as in the 10 Oct captures: one panel per line, 25 lines. lines[n] = code,
        // description, quantity, net for line n (1-based).
        static List<ControlInfo> Grid(Dictionary<int,string[]> lines) {
            var s=new List<ControlInfo>{Mk(20,300,ST,69,341,79,27,"ITEM"),Mk(21,300,ST,223,341,87,27,"DESCRIPTION"),Mk(22,300,ST,728,341,45,27,"QTY OR HRS"),Mk(23,300,ST,769,341,56,26,"LIST"),Mk(24,300,ST,873,341,56,27,"NET")};
            for(int i=0;i<25;i++) {
                int y=369+19*i;long panel=500+i,b=1000+10*i;string[] v;if(!lines.TryGetValue(i+1,out v))v=new[]{"","","",""};
                s.Add(Mk(panel,300,WN,37,y,1010,20,""));
                s.Add(Mk(b,panel,ED,72,y,155,20,v[0]));s.Add(Mk(b+1,panel,ED,225,y,480,20,v[1]));s.Add(Mk(b+2,panel,ED,728,y,40,20,v[2]));s.Add(Mk(b+3,panel,ED,769,y,56,20,v[3]));s.Add(Mk(b+4,panel,ED,873,y,56,20,v[3]));
            }
            return s;
        }
        static Dictionary<int,string[]> Example() {
            return new Dictionary<int,string[]> {
                {1,new[]{"W43116","WINRUN 265/70R16 112T MAXCLAW A/T","1","140.00"}},{3,new[]{"F","Freight","1","10.00"}},
                {5,new[]{"M E","EBAY ITEM # 175288170173","",""}},{7,new[]{"M BUY","EBAY BUYER NAME: TESTBUYER1","",""}},
                {9,new[]{"M DFE","SENT VIA DIRECT FREIGHT EXPRESS {Phone # 1300347397} CONSIGNMENT #","",""}}};
        }
        internal static void Cases(Action<string,Action> Case) {
            Case("eBay order: a valid order checks out, its lines are spaced as in RO 07497644, and it maps onto the delivery engine",()=>{
                var o=Wire.Copy(Sample());o.Validate();
                var plan=o.Plan();
                Check(plan.Select(l=>l.Line).SequenceEqual(new[]{1,3,5,7,9}),"The lines must be 1, 3, 5, 7, 9 (an empty line between entries).");
                Check(plan.Select(l=>l.Code).SequenceEqual(new[]{"W43116","F","M E","M BUY","M DFE"}),"The codes must be the item, F, M E, M BUY, M DFE.");
                Check(plan[0].Kind=="product"&&plan[0].Quantity==1&&plan[0].UnitCents==14000&&plan[1].Kind=="freight"&&plan[1].UnitCents==1000,"Item and freight amounts are wrong.");
                Check(plan[2].Text=="EBAY ITEM # 175288170173"&&plan[3].Text=="EBAY BUYER NAME: TESTBUYER1"&&plan[4].Kind=="code"&&plan[4].Text==null,"Note texts are wrong (M DFE keeps COSTAR's own text).");
                Check(o.CardNumber=="11-11111-11111 "+o.orderDate&&o.Reference=="EBAY 11-11111-11111","Card# must be the order number and its date.");
                var e=o.EngineOrder();
                Check(e.IsDelivery&&e.orderId=="11-11111-11111"&&e.comment=="EBAY DFE"&&e.shipping.shipVia=="DFE"&&e.freightCents==1000&&e.totalCents==15000,"Engine order header is wrong.");
                Check(e.customer.name=="TEST BUYER"&&e.customer.phone=="0400000001"&&e.customer.email=="abc123def456@members.ebay.com"&&e.customer.streetAddress=="1 TEST CRESCENT"&&e.customer.suburb=="TESTVILLE","Billing must be the buyer (name in capitals, phone digits, email as sent).");
                Check(e.shipping.name=="TEST BUYER"&&e.shipping.mobilePhone=="0400000001"&&e.shipping.contact==""&&e.shipping.businessPhone==""&&e.shipping.instructions=="","Ship to must be the buyer with the mobile only.");
                Check(e.lines.Count==1&&e.lines[0].code=="W43116"&&e.lines[0].quantity==1&&e.lines[0].unitCents==14000&&e.lines[0].kind=="product","Engine lines are wrong.");
                Check(EbayOrder.Comment=="EBAY DFE"&&EbayOrder.Staff=="SA"&&EbayOrder.RebillCode=="EBAY"&&EbayOrder.ExpectedTerms=="7INV","Tommy's 23 Oct rules changed.");
            });
            Case("eBay order: bad or incomplete orders are refused before anything reaches COSTAR",()=>{
                var bad=new List<Action<EbayOrder>> {
                    x=>x.schema="tempe.ebay-order.v0", x=>x.orderNumber="11-1111-11111", x=>x.submissionId="EBY-22-22222-22222", x=>x.createdUtc="", x=>x.orderDate="2026-10-23", x=>x.orderDate="31/02/26",
                    x=>x.orderDate=DateTime.UtcNow.AddDays(5).ToString("dd/MM/yy",CultureInfo.InvariantCulture), x=>x.buyer.name=" ", x=>x.buyer.phone="12345", x=>x.buyer.phone="0400 ABC 001",
                    x=>x.buyer.email="not an email", x=>x.buyer.username="two words", x=>x.buyer.username="", x=>x.address.street="", x=>x.address.suburb="", x=>x.address.state="XX", x=>x.address.postcode="279",
                    x=>x.items.Clear(), x=>x.items[0].sku="F", x=>x.items[0].sku="w43116", x=>x.items[0].sku="NO SKU", x=>x.items[0].itemId="", x=>x.items[0].quantity=0, x=>x.items[0].quantity=21,
                    x=>x.items[0].unitCents=0, x=>x.totalCents=15001, x=>x.freightCents=-1, x=>x.buyer.name="LINE\nBREAK", x=>x.buyer=null, x=>x.items=null,
                    x=>{x.items.Add(new EbayItem {sku="W1",itemId="175288170173",quantity=1,unitCents=100});x.totalCents+=100;},
                    x=>{for(int i=0;i<4;i++)x.items.Add(new EbayItem {sku="W"+i,itemId="17528817019"+i,quantity=1,unitCents=100});x.totalCents+=400;} };
                for(int i=0;i<bad.Count;i++){var o=Sample();bad[i](o);int n=i;Reject(delegate{o.Validate();},"Bad eBay order case "+n+" was accepted.");}
                var free=Sample();free.freightCents=0;free.totalCents=14000;free.Validate();
                Check(free.Plan().Select(l=>l.Code).SequenceEqual(new[]{"W43116","M E","M BUY","M DFE"}),"Free postage must have no F line.");
                var noEmail=Sample();noEmail.buyer.email="";noEmail.Validate();
            });
            Case("eBay order: four items fit COSTAR's 25 lines with one M E per item, and the content hash ignores the send time",()=>{
                var o=Sample();o.items.Clear();
                for(int i=0;i<4;i++) o.items.Add(new EbayItem {sku="TYRE"+i,itemId="17528817010"+i,quantity=2,unitCents=10000+i});
                o.totalCents=o.items.Sum(i=>i.quantity*i.unitCents)+o.freightCents;o.Validate();
                var plan=o.Plan();
                Check(plan.Count==11&&plan.Last().Line==21&&plan.Last().Code=="M DFE","Four items must end with M DFE on line 21.");
                Check(plan.Where(l=>l.Code=="M E").Select(l=>l.Text).SequenceEqual(o.items.Select(i=>"EBAY ITEM # "+i.itemId)),"Each item needs its own M E line, in item order.");
                Check(plan.Take(4).Select(l=>l.Line).SequenceEqual(new[]{1,3,5,7})&&plan[4].Code=="F"&&plan[4].Line==9,"Items first, then F.");
                var again=Wire.Copy(o);again.createdUtc=DateTime.UtcNow.AddMinutes(3).ToString("o",CultureInfo.InvariantCulture);again.sentFrom="other";
                Check(again.ContentHash()==o.ContentHash(),"A second click on Send must count as the same order.");
                var changed=Wire.Copy(o);changed.items[0].unitCents++;changed.totalCents+=2;
                Check(changed.ContentHash()!=o.ContentHash(),"Changed details must not count as the same order.");
            });
            Case("Desk eBay queue: one receipt per order number; a re-send is the same order; changes before pickup replace it; later they conflict; removed can be sent again",()=>{
                var q=Queue();var a=q.Submit(Sample());
                Check(a.status=="queued"&&a.version==1&&q.List().Count==1,"New eBay order not queued.");
                var again=Sample();again.createdUtc=DateTime.UtcNow.AddMinutes(1).ToString("o",CultureInfo.InvariantCulture);
                Check(q.Submit(again).version==1&&q.List().Count==1,"A second click created a second order.");
                var price=Sample();price.items[0].unitCents=13000;price.totalCents=14000;
                var replaced=q.Submit(price);Check(replaced.status=="queued"&&replaced.version==2&&q.List()[0].order.totalCents==14000,"Changed details before pickup did not replace the order.");
                var claim=q.Poll(Hello());Check(claim.command=="enter"&&claim.order.totalCents==14000,"The order was not handed to the helper.");
                bool conflict=false;try{q.Submit(Sample());}catch(InvalidOperationException e){conflict=e.Message.StartsWith("CONFLICT:",StringComparison.Ordinal);}
                Check(conflict,"Different details after pickup must conflict.");
                q.Poll(Hello(Report(claim,"failed",1)));q.Remove(price.orderNumber,true);
                var removed=q.List()[0];Check(removed.status=="removed"&&removed.hidden,"Remove did not hide the order.");
                var back=q.Submit(Sample());var r=q.List()[0];
                Check(back.status=="queued"&&r.fresh&&!r.startAgain&&!r.hidden&&r.lease==null&&q.List().Count==1,"A removed order sent again must be queued fresh, once.");
                var resent=q.Poll(Hello());
                Check(resent.command=="enter"&&resent.fresh&&!resent.startAgain,"Remove and send again must use a new Repair Order but must NOT pass the helper's 'already entered' guard.");
                q.Poll(Hello(Report(resent,"failed",1)));q.StartAgain(price.orderNumber);
                Check(q.List()[0].startAgain,"Start again must be recorded.");
                q.Remove(price.orderNumber,true);q.Submit(Sample());
                Check(q.List()[0].fresh&&!q.List()[0].startAgain,"Start again must not survive Remove and send again.");
                q.Poll(Hello(Report(q.Poll(Hello()),"failed",1)));q.StartAgain(price.orderNumber);
                var again2=q.Poll(Hello());Check(again2.fresh&&again2.startAgain,"Start again must reach the helper.");
                Check(q.Poll(Hello()).startAgain,"A lost Start again claim must be replayed as Start again.");
                q.Poll(Hello(Report(again2,"entering",1)));
                Check(!q.List()[0].startAgain&&!q.List()[0].fresh,"Start again must end with the helper's first report.");
            });
            Case("Desk eBay queue: FIFO claim with a lease, progress, ready; a lost claim replays the same lease; one order at a time per helper",()=>{
                var q=Queue();q.Submit(Sample("11-11111-11111"));Thread.Sleep(5);q.Submit(Sample("22-22222-22222"));
                Check(q.Poll(Hello(null,false,true)).command=="wait","A helper that is not accepting was given work.");
                Check(q.Poll(Hello(null,true,false)).command=="wait","An unavailable helper was given work.");
                var first=q.Poll(Hello());Check(first.command=="enter"&&first.order.orderNumber=="11-11111-11111"&&first.lease.Length>20,"FIFO claim failed.");
                var lost=q.Poll(Hello());Check(lost.command=="enter"&&lost.lease==first.lease&&lost.order.orderNumber==first.order.orderNumber,"A lost claim reply must come back with the same lease.");
                var progress=q.Poll(Hello(Report(first,"entering",1)));
                Check(progress.command=="wait"&&progress.ack==1&&q.Get("11-11111-11111").status=="entering","While one order is entered nothing else may be handed out.");
                var done=q.Poll(Hello(Report(first,"ready_for_review",2,true)));
                Check(done.ack==2&&q.Get("11-11111-11111").status=="ready_for_review"&&q.Get("11-11111-11111").typed,"Ready report not applied.");
                Check(done.command=="enter"&&done.order.orderNumber=="22-22222-22222"&&done.lease!=first.lease,"The next order must follow with its own lease.");
                var late=q.Poll(Hello(Report(first,"failed",3)));
                Check(q.Get("11-11111-11111").status=="ready_for_review"&&late.command=="enter"&&late.lease==done.lease,"A late report must not change a finished order (and the next order's claim is replayed).");
                var stale=q.Poll(Hello(new EbayReport {orderNumber="11-11111-11111",lease="old-lease",status="failed",sequence=4}));
                Check(stale.command=="forget"&&stale.ack==4&&q.Get("11-11111-11111").status=="ready_for_review","A report with another lease must be forgotten.");
                q.Poll(Hello(Report(done,"entering",1)));q.Poll(Hello(Report(done,"entering",1)));
                Check(q.Get("22-22222-22222").version==3,"A repeated report must apply once.");
            });
            Case("Desk eBay queue: Retry (new lease, old report forgotten), Start again (fresh), Mark done and Remove only when safe",()=>{
                var q=Queue();q.Submit(Sample());var claim=q.Poll(Hello());q.Poll(Hello(Report(claim,"failed",1,true)));
                Check(q.Get(claim.order.orderNumber).status=="failed"&&q.Get(claim.order.orderNumber).typed,"Failed report not applied.");
                q.Retry(claim.order.orderNumber);var retried=q.Poll(Hello());
                Check(retried.command=="enter"&&retried.lease!=claim.lease&&!retried.fresh,"Retry must hand the order out again with a new lease (same Repair Order).");
                Check(q.Poll(Hello(Report(claim,"ready_for_review",2))).command=="forget","The old lease's report must be forgotten.");
                q.Poll(Hello(Report(retried,"failed",1)));
                Reject(delegate{q.StartAgain("33-33333-33333");},"Start again on an unknown order.");
                q.StartAgain(claim.order.orderNumber);var fresh=q.Poll(Hello());
                Check(fresh.command=="enter"&&fresh.fresh,"Start again must ask for a new Repair Order.");
                Reject(delegate{q.Remove(claim.order.orderNumber,true);},"An order being entered was removed.");
                Reject(delegate{q.MarkDone(claim.order.orderNumber,true);},"An order being entered was marked done.");
                q.Poll(Hello(Report(fresh,"entering",1)));
                q.MarkDone(claim.order.orderNumber,false);
                Check(q.Get(claim.order.orderNumber).status=="ready_for_review","With the helper out of touch a stranded order can be marked done.");
                Reject(delegate{q.Remove(claim.order.orderNumber,true);},"A finished order was removed.");
                Reject(delegate{q.StartAgain(claim.order.orderNumber);},"A finished order was started again.");
                q.Hide(claim.order.orderNumber);Check(q.List()[0].hidden,"Hide did not hide a finished order.");
                Check(q.Poll(Hello(Report(fresh,"failed",2))).command=="wait"&&q.Get(claim.order.orderNumber).status=="ready_for_review","A late failure must not undo Mark done.");
            });
            Case("Desk eBay queue: a partly typed order removed and sent again continues (never new); details are fixed once handed out",()=>{
                var q=Queue();q.Submit(Sample());var claim=q.Poll(Hello());q.Poll(Hello(Report(claim,"failed",1,true)));
                q.Remove(claim.order.orderNumber,true);
                var changed=Sample();changed.items[0].unitCents=13000;changed.totalCents=14000;
                bool conflict=false;try{q.Submit(changed);}catch(InvalidOperationException e){conflict=e.Message.StartsWith("CONFLICT:",StringComparison.Ordinal);}
                Check(conflict&&q.List()[0].status=="removed","A partly typed order sent again with other details must conflict.");
                var back=q.Submit(Sample());var r=q.List()[0];
                Check(back.status=="queued"&&!r.fresh&&!r.startAgain&&r.typed&&!r.hidden,"A partly typed order sent again must keep its typed record and NOT ask for a new Repair Order.");
                var again=q.Poll(Hello());
                Check(again.command=="enter"&&!again.fresh&&!again.startAgain&&again.status.typed,"The helper must be told it was typed (so it continues or refuses).");
                var q2=Queue();q2.Submit(Sample());var c2=q2.Poll(Hello());q2.Poll(Hello(Report(c2,"failed",1)));q2.Retry(c2.order.orderNumber);
                bool fixedDetails=false;try{q2.Submit(changed);}catch(InvalidOperationException e){fixedDetails=e.Message.StartsWith("CONFLICT:",StringComparison.Ordinal);}
                Check(fixedDetails,"Details must not be replaced once the helper has had the order (even back in line after Retry).");
            });
            Case("Desk eBay queue: a claim the helper can't start goes back in line; an order it no longer enters is stopped, never stuck",()=>{
                var q=Queue();q.Submit(Sample());var claim=q.Poll(Hello());
                Reject(delegate{q.Remove(claim.order.orderNumber,true);},"A claimed order was removed while the helper is in touch.");
                var declined=Hello(null,true,false);declined.declined=claim.lease;declined.declineReason="COSTAR Branch 1 (Sydney) is not open\u0085 in this session";
                Check(q.Poll(declined).command=="wait","An unavailable helper got work after declining.");
                var r=q.List()[0];
                Check(r.status=="queued"&&r.lease==null&&!r.awaitingWorker&&r.message.StartsWith("Waiting: COSTAR Branch 1",StringComparison.Ordinal)&&!r.message.Any(Char.IsControl),"A declined claim must wait in line again with the reason.");
                q.Remove(claim.order.orderNumber,true);Check(q.Get(claim.order.orderNumber).status=="removed","A declined order can be removed.");
                var q2=Queue();q2.Submit(Sample());var c2=q2.Poll(Hello());q2.Poll(Hello(Report(c2,"failed",1)));q2.StartAgain(c2.order.orderNumber);
                var c3=q2.Poll(Hello());var d2=Hello(null,true,false);d2.declined=c3.lease;q2.Poll(d2);
                var back=q2.Poll(Hello());Check(back.command=="enter"&&back.fresh&&back.startAgain&&back.lease!=c3.lease,"Start again must survive a declined claim.");
                var q3=Queue();q3.Submit(Sample());var c4=q3.Poll(Hello());
                q3.Poll(Working("",null));Check(q3.Get(c4.order.orderNumber).status=="entering","A claim not yet confirmed must not be stopped.");
                q3.Poll(Working(c4.lease,Report(c4,"entering",1)));
                q3.Poll(Working(c4.lease));Check(q3.Get(c4.order.orderNumber).status=="entering","An order the helper is entering must stay.");
                q3.Poll(Working("",Report(c4,"entering",2)));Check(q3.Get(c4.order.orderNumber).status=="entering","An order reported on in the same poll must stay.");
                q3.Poll(Hello());Check(q3.Get(c4.order.orderNumber).status=="entering","A helper that doesn't say what it works on changes nothing.");
                q3.Poll(Working("",null,1));Check(q3.Get(c4.order.orderNumber).status=="entering","A hello written before the desk's last report for the order must not stop it (a late poll).");
                q3.Poll(Working(""));var lost=q3.Get(c4.order.orderNumber);
                Check(lost.status=="failed"&&lost.message.Contains("no longer entering")&&lost.typed,"An order the helper no longer enters must be stopped (and counted as possibly typed).");
                q3.Submit(Sample("22-22222-22222"));var next=q3.Poll(Working(""));
                Check(next.command=="enter"&&next.order.orderNumber=="22-22222-22222","The next order must not be held up by a lost one.");
                Check(EbayText.Clean("a\u0085b\tc\u009b",100)=="a b c "&&EbayText.Clean(new string('x',500),400).Length==400&&EbayText.Clean(null,5)=="","Words from the helper: control characters become spaces, cut to the limit.");
                var q4=Queue();q4.Submit(Sample());var c5=q4.Poll(Hello());
                var off=Hello(null,false,false);var replay=q4.Poll(off);
                Check(replay.command=="enter"&&replay.lease==c5.lease,"An unconfirmed claim must come back to a helper that is switched off (so it can hand it back).");
                off.declined=c5.lease;off.declineReason="Waiting for a quiet moment: someone is using the COSTAR PC";q4.Poll(off);
                var w=q4.List()[0];Check(w.status=="queued"&&w.message=="Waiting for a quiet moment: someone is using the COSTAR PC","A handed-back claim waits again, its reason said once.");
                var better=Sample();better.items[0].unitCents=13000;better.totalCents=14000;
                Check(q4.Submit(better).status=="queued"&&q4.List()[0].order.totalCents==14000,"Details may still change while nothing was started.");
                var c6=q4.Poll(Hello());q4.Poll(Working(c6.lease,Report(c6,"entering",1)));
                bool locked=false;try{q4.Submit(Sample());}catch(InvalidOperationException e){locked=e.Message.StartsWith("CONFLICT:",StringComparison.Ordinal);}
                Check(locked,"Details are fixed once the helper has reported on the order.");
            });
            Case("Desk eBay queue: a failed save rolls back, and old finished orders are pruned past the limit",()=>{
                bool fail=false;var q=new EbayQueue(null,s=>{if(fail)throw new IOException("disk full");});
                q.Submit(Sample());fail=true;
                Reject(delegate{try{q.Poll(Hello());}catch(IOException e){throw new InvalidOperationException(e.Message);}},"Save failure not raised.");
                fail=false;Check(q.Get(Sample().orderNumber).status=="queued"&&q.List()[0].lease==null,"A failed save left the order claimed.");
                var state=new EbayState();
                for(int i=0;i<EbayQueue.Keep+5;i++){var o=Sample(String.Format(CultureInfo.InvariantCulture,"{0:00}-{1:00000}-11111",i%100,i));state.orders.Add(new EbayReceipt {order=o,hash=o.ContentHash(),status="ready_for_review",updatedUtc=DateTime.UtcNow.AddMinutes(i).ToString("o",CultureInfo.InvariantCulture),receivedUtc="x"});}
                var big=new EbayQueue(state,s=>{});big.Submit(Sample("99-99999-99999"));
                var all=big.List();
                Check(all.Count==EbayQueue.Keep&&all.Any(o=>o.order.orderNumber=="99-99999-99999")&&!all.Any(o=>o.order.orderNumber=="00-00000-11111"),"Pruning must drop the oldest finished orders and keep the new one.");
            });
            Case("Receiver eBay API: its own key, the extension's origin only on eBay routes, health with the waiting reason, submit, status, retry, conflict",()=>{
                var settings=new ReceiverSettings {address="192.168.1.2",phoneToken="phone-test",workerToken="worker-test",workerId="test-worker",ebayToken="ebay-test",webUrl="https://example.com/Fitment_Planner.html"};
                var api=new ReceiverApi(settings,new JobQueue(null,s=>{}),Path.GetTempPath(),()=>false,id=>{});
                const string root="/api/ebay/v1";
                Check(api.Handle(Request("GET",root+"/health","ebay-test")).status==400,"eBay routes must say eBay is not set up before the queue exists.");
                var q=Queue();int incoming=0;api.UseEbay(q);api.EbayIncoming=n=>incoming++;
                Check(api.Handle(Request("GET",root+"/health",null)).status==401,"Unauthenticated eBay health.");
                Check(api.Handle(Request("GET",root+"/health","phone-test")).status==401,"The phone key opened the eBay routes.");
                Check(api.Handle(Request("GET","/api/mobile/v1/health","ebay-test")).status==401,"The eBay key opened the phone routes.");
                Check(api.Handle(Request("GET",root+"/health","ebay-test","https://example.com")).status==403,"The website may not use the eBay routes.");
                Check(api.Handle(Request("GET","/api/mobile/v1/health","phone-test",Extension)).status==403,"The extension may not use the phone routes.");
                var health=api.Handle(Request("GET",root+"/health","ebay-test",Extension));
                Check(health.status==200&&health.headers["Access-Control-Allow-Origin"]==Extension,"The extension's health check failed.");
                var h=Body<Dictionary<string,object>>(health);
                Check((string)h["service"]=="tempe-ebay"&&!(bool)h["helperConnected"]&&((string)h["waiting"]).Contains("not running"),"Health must say the RDP helper is not in touch.");
                Check(api.Handle(Request("OPTIONS",root+"/orders",null,Extension)).status==204,"Extension preflight failed.");
                var posted=api.Handle(Request("POST",root+"/orders","ebay-test",Extension,Sample()));
                Check(posted.status==200&&incoming==1,"An order must be taken while the RDP helper is offline (it waits).");
                var s1=Body<EbayStatus>(posted);Check(s1.status=="queued"&&s1.waiting.Contains("not running"),"Queued status must say why it waits.");
                api.Handle(Request("POST",root+"/orders","ebay-test",Extension,Sample()));Check(incoming==1&&q.List().Count==1,"A re-send counted as new.");
                api.Handle(Request("POST","/api/worker/v1/ebay","worker-test",null,Hello(null,true,false)));
                var waiting=Body<EbayStatus>(api.Handle(Request("GET",root+"/orders/11-11111-11111","ebay-test",Extension)));
                Check(waiting.status=="queued"&&waiting.waiting.Length>0&&!waiting.waiting.Contains("not running"),"With the helper in touch the reason must change.");
                var claim=Body<EbayReply>(api.Handle(Request("POST","/api/worker/v1/ebay","worker-test",null,Hello())));
                Check(claim.command=="enter"&&claim.order.orderNumber=="11-11111-11111","The worker route did not hand the order out.");
                var changed=Sample();changed.items[0].unitCents=13000;changed.totalCents=14000;
                Check(api.Handle(Request("POST",root+"/orders","ebay-test",Extension,changed)).status==409,"A conflict must be 409.");
                Check(api.Handle(Request("GET",root+"/orders/33-33333-33333","ebay-test",Extension)).status==404,"Unknown order must be 404.");
                Check(api.Handle(Request("GET",root+"/orders/not-a-number","ebay-test",Extension)).status==400,"A malformed order number must be refused.");
                api.Handle(Request("POST","/api/worker/v1/ebay","worker-test",null,Hello(Report(claim,"failed",1))));
                Check(api.Handle(Request("POST",root+"/orders/11-11111-11111/retry","ebay-test",Extension,new Dictionary<string,string>{{"orderNumber","22-22222-22222"}})).status==400,"Retry with a mismatched number accepted.");
                var retried=Body<EbayStatus>(api.Handle(Request("POST",root+"/orders/11-11111-11111/retry","ebay-test",Extension,new Dictionary<string,string>{{"orderNumber","11-11111-11111"}})));
                Check(retried.status=="queued","Retry from the extension did not queue the order again.");
                Check(api.Handle(Request("POST","/api/worker/v1/ebay","phone-test",null,Hello())).status==401&&api.Handle(Request("POST","/api/worker/v1/ebay","worker-test",null,new EbayHello {workerId="intruder"})).status==400,"The eBay worker route must need the worker key and ID.");
                settings.ebayToken=null;Check(api.Handle(Request("GET",root+"/health","")).status==401&&api.Handle(Request("GET",root+"/health","ebay-test")).status==401,"An empty eBay key must never match.");
                Check(ReceiverApi.ExtensionOrigin(Extension)&&!ReceiverApi.ExtensionOrigin("chrome-extension://abc")&&!ReceiverApi.ExtensionOrigin("https://evil.example")&&!ReceiverApi.ExtensionOrigin("chrome-extension://abcdefghijklmnopabcdefghijklmnoz"),"Extension origin rule.");
                settings.ebayToken="ebay-test";
                Check(api.Handle(Request("GET",root+"/health","ebay-test",settings.Origin)).status==403,"The desk's own pages may not use the eBay routes.");
                var noisy=Hello(Report(claim,"failed",2));noisy.detail="COSTAR\u0085 not open "+new string('x',600);noisy.report.message="Stopped\u009b here";
                var cleaned=api.Handle(Request("POST","/api/worker/v1/ebay","worker-test",null,noisy));
                Check(cleaned.status==200&&!api.EbayDetail.Any(Char.IsControl)&&api.EbayDetail.Length<=400,"Words from the helper must be cleaned, never refused.");
            });
            Case("Receiver eBay PIN pairing: only while open, six digits, five tries, one use; it hands out the eBay key",()=>{
                var settings=new ReceiverSettings {address="192.168.1.2",phoneToken="phone-test",workerToken="worker-test",workerId="test-worker",ebayToken="ebay-test"};
                var api=new ReceiverApi(settings,new JobQueue(null,s=>{}),Path.GetTempPath(),()=>false,id=>{});api.UseEbay(Queue());int paired=0;api.EbayPaired=x=>paired++;
                const string pair="/api/ebay/v1/pair";
                Func<string,HttpOutput> tryPin=pin=>api.Handle(Request("POST",pair,null,Extension,new Dictionary<string,string>{{"pin",pin}}));
                Check(tryPin("123456").status==400,"Pairing worked while it was not open.");
                string code=api.Pairing.Begin();Check(code.Length==6&&code.All(Char.IsDigit),"The PIN must be six digits.");
                Check(tryPin("12345").status==400&&api.Pairing.Active,"A short PIN must be refused without using a try.");
                string wrong=code=="000000"?"111111":"000000";
                Check(tryPin(wrong).status==403&&api.Pairing.Active,"A wrong PIN must be refused.");
                var ok=tryPin(code);var b=Body<Dictionary<string,object>>(ok);
                Check(ok.status==200&&(string)b["key"]=="ebay-test"&&(string)b["receiver"]=="https://192.168.1.2:8790"&&paired==1,"The right PIN must hand out the eBay key and the receiver address.");
                Check(!api.Pairing.Active&&tryPin(code).status==400,"A PIN must work once.");
                code=api.Pairing.Begin();for(int i=0;i<EbayPairing.Tries;i++)tryPin(wrong);
                Check(!api.Pairing.Active&&tryPin(code).status==400,"Five wrong tries must close pairing.");
                Check(api.Handle(Request("POST",pair,null,"https://example.com",new Dictionary<string,string>{{"pin","123456"}})).status==403,"A website may not pair.");
                settings.webUrl="https://example.com/Fitment_Planner.html";code=api.Pairing.Begin();
                foreach(var sneaky in new[]{"/api/%65bay/v1/pair","/api/ebay/v1/%70air","/api/ebay/v1/./pair"}) {
                    var o=api.Handle(Request("POST",sneaky,null,"https://example.com",new Dictionary<string,string>{{"pin",code}}));
                    Check(o.status!=200&&api.Pairing.Active,"A website reached the PIN pairing through "+sneaky+" ("+o.status+").");
                }
                Check(tryPin(code).status==200,"The PIN must still work for the extension.");
            });
            Case("Receiver eBay worker poll: in touch and accepting are tracked, and a held poll wakes when an order arrives",()=>{
                var settings=new ReceiverSettings {address="192.168.1.2",phoneToken="phone-test",workerToken="worker-test",workerId="test-worker",ebayToken="ebay-test"};
                var api=new ReceiverApi(settings,new JobQueue(null,s=>{}),Path.GetTempPath(),()=>false,id=>{});var q=Queue();api.UseEbay(q);
                const string poll="/api/worker/v1/ebay";
                var hello=Hello();hello.waitMs=400;var clock=System.Diagnostics.Stopwatch.StartNew();
                var idle=Body<EbayReply>(api.Handle(Request("POST",poll,"worker-test",null,hello)));
                Check(idle.command=="wait"&&idle.held&&clock.ElapsedMilliseconds>=350,"An idle eBay poll was not held.");
                bool connected,on,ready;string detail;api.EbaySide(out connected,out on,out ready,out detail);
                Check(connected&&on&&ready&&api.EbayConnected,"The desk must see the helper's eBay side in touch, on and ready.");
                hello.waitMs=2500;var waker=new Thread(delegate(){Thread.Sleep(150);q.Submit(Sample());});waker.IsBackground=true;clock.Restart();waker.Start();
                var woken=Body<EbayReply>(api.Handle(Request("POST",poll,"worker-test",null,hello)));
                Check(woken.command=="enter"&&woken.held&&clock.ElapsedMilliseconds<1800,"A new eBay order did not wake the held poll.");
                var off=Hello(null,false,false);off.detail="eBay orders switched off on the RDP helper";
                api.Handle(Request("POST",poll,"worker-test",null,off));api.EbaySide(out connected,out on,out ready,out detail);
                Check(connected&&!on&&!ready&&api.EbayWaiting.Contains("switched off"),"Switched off must show on the desk and in the waiting reason.");
                api.Receiving=false;Check(api.EbayWaiting.Contains("stopped receiving"),"Stop receiving must be the reason.");
            });
            Case("eBay layout rules: Rebill to's boxes, which tab is showing, and the Written By / Salesperson / Terms boxes under their headings",()=>{
                var rebill=new List<ControlInfo>{Mk(700,600,WN,590,128,440,200,""),
                    Mk(701,700,BT,598,137,180,22,"National Accounts..."),Mk(702,700,BT,800,137,155,22,"Rebilll Accounts..."),
                    Mk(703,700,ST,596,164,358,17,"Rebill to Customer"),Mk(704,700,ED,596,181,120,20,""),Mk(705,700,ED,718,181,236,20,""),
                    Mk(706,700,ST,596,198,230,17,"Card#"),Mk(707,700,ED,596,215,230,20,""),
                    Mk(708,700,ST,596,234,432,17,"Rebill Notes"),Mk(709,700,"WindowsForms10.EDIT.app.0.1",596,251,380,74,""),Mk(710,700,BT,978,252,48,34,"...")};
                var m=EbaySelectors.Rebill(rebill);
                Check(m.Code.Handle==704&&m.Name.Handle==705&&m.Card.Handle==707&&m.Notes!=null&&m.Notes.Handle==709,"Rebill to's boxes were not found.");
                Check(EbaySelectors.OnRebillTab(rebill)&&!EbaySelectors.OnShipToTab(rebill),"The Rebill to tab must be recognised by its heading.");
                var ship=new List<ControlInfo>{Mk(40,5,ST,789,250,113,15,"Ship Via"),Mk(41,5,ED,790,265,113,20,"")};
                Check(EbaySelectors.OnShipToTab(ship)&&!EbaySelectors.OnRebillTab(ship),"The Ship to tab must be recognised by Ship Via.");
                Check(!EbaySelectors.OnShipToTab(ship.Concat(rebill).ToList()),"Both pages showing at once is not the Ship to tab.");
                Reject(delegate{EbaySelectors.Rebill(rebill.Where(c=>c.Handle!=705).ToList());},"One customer box must not pass for Rebill to.");
                Reject(delegate{EbaySelectors.Rebill(rebill.Where(c=>c.Handle!=706).ToList());},"Without its Card# heading nothing may be typed.");
                Check(EbaySelectors.Rebill(rebill.Where(c=>c.Handle!=708).ToList()).Notes==null,"Rebill Notes is optional.");
                var header=new List<ControlInfo>{Mk(1,100,ST,28,298,75,17,"Written By"),Mk(2,100,ED,28,315,58,20,"TOG"),Mk(3,100,BT,88,315,18,20,""),
                    Mk(4,100,ST,380,218,95,17,"Terms"),Mk(5,100,ED,380,235,75,20,""),Mk(6,100,ST,380,253,95,17,"Salesperson"),Mk(7,100,ED,380,270,75,20,""),
                    Mk(8,100,ST,120,298,70,17,"Time in"),Mk(9,100,ST,270,298,100,17,"PO#"),Mk(10,100,ED,270,315,100,20,"")};
                Check(EbaySelectors.UnderLabel(header,"WRITTEN BY").Handle==2&&EbaySelectors.UnderLabel(header,"SALESPERSON").Handle==7&&EbaySelectors.UnderLabel(header,"TERMS").Handle==5,"Staff and Terms boxes not found under their headings.");
                var panelled=header.Select(c=>c.Handle==7?Mk(7,150,ED,381,271,75,20,""):c).ToList();
                Check(EbaySelectors.UnderLabel(panelled,"SALESPERSON").Handle==7,"A box in its own small panel under the heading must still be found.");
                Check(EbaySelectors.UnderLabel(header.Where(c=>c.Handle!=1).ToList(),"WRITTEN BY")==null,"Without its heading nothing is found.");
                var two=header.Concat(new[]{Mk(11,100,ED,30,316,58,20,"")}).ToList();
                Check(EbaySelectors.UnderLabel(two,"WRITTEN BY")==null,"Two boxes under a heading must not be guessed.");
            });
            Case("eBay final line check: the spaced example passes; a wrong price, quantity, text, line or extra line fails; one-after-another works too",()=>{
                var o=Sample();o.buyer.username="TESTBUYER1";var plan=o.Plan();
                EbayCheck.Lines(Grid(Example()),plan,true);
                Func<Action<Dictionary<int,string[]>>,bool> fails=change=>{var g=Example();change(g);try{EbayCheck.Lines(Grid(g),plan,true);return false;}catch(InvalidOperationException){return true;}};
                Check(fails(g=>g[1][3]="150.00"),"A tyre at another price must fail.");
                Check(fails(g=>g[1][2]="2"),"A wrong quantity must fail.");
                Check(fails(g=>g[3][3]="12.00"),"Wrong freight must fail.");
                Check(fails(g=>g[5][1]="EBAY ITEM # 999"),"A wrong item number must fail.");
                Check(fails(g=>g[7][1]="EBAY BUYER NAME:"),"A missing buyer name must fail.");
                Check(fails(g=>{g[2]=g[1];g.Remove(1);}),"An item on the wrong line must fail.");
                Check(fails(g=>g[11]=new[]{"M","EXTRA NOTE","",""}),"An extra line must fail.");
                var levy=Example();levy[2]=new[]{"LEVY","TYRE LEVY","1","2.00"};string said="";
                try{EbayCheck.Lines(Grid(levy),plan,true);}catch(InvalidOperationException e){said=e.Message;}
                Check(said.Contains("Not in this eBay order: LEVY")&&!said.Contains("TEST"),"A line COSTAR added must be named (by its code only).");
                var staffBoxes=new List<ControlInfo>{Mk(1,100,ST,28,298,75,17,"Written By"),Mk(2,100,ED,28,315,58,20,"SA"),Mk(6,100,ST,380,253,95,17,"Salesperson"),Mk(7,100,ED,380,270,75,20,"FSH")};
                Check(EbaySelectors.StaffPrint(staffBoxes)=="W=SA|S=FSH|"&&EbaySelectors.StaffPrint(new List<ControlInfo>())=="W=-|S=-|","Written By and Salesperson must be part of the retry comparison.");
                Check(fails(g=>g.Remove(9)),"A missing M DFE must fail.");
                Check(!fails(g=>g[9][1]="ANYTHING COSTAR WRITES"),"M DFE keeps COSTAR's own text.");
                var packed=new Dictionary<int,string[]>();int n=1;foreach(var kv in Example().OrderBy(k=>k.Key))packed[n++]=kv.Value;
                EbayCheck.Lines(Grid(packed),plan,false);
                Reject(delegate{EbayCheck.Lines(Grid(packed),plan,true);},"Packed lines must fail the spaced check.");
            });
            Case("eBay refusals: entered before (unless Start again), typed before but sent as new, or typed by the desk's word with no record here",()=>{
                const string n="11-11111-11111";var typed=new EbayAttempt {orderNumber=n,typed=true,window=10,stopPrint="p"};var untyped=new EbayAttempt {orderNumber=n,window=10};
                Check(EbayAttempts.Refusal(n,false,false,false,null,null)==null&&EbayAttempts.Refusal(n,true,false,false,untyped,null)==null&&EbayAttempts.Refusal(n,false,false,true,typed,null)==null,"Ordinary orders and retries must not be refused here.");
                Check(EbayAttempts.Refusal(n,false,false,false,null,"Thu 23 Oct, 16:00").StartsWith("Not entered twice",StringComparison.Ordinal),"An order entered before must be refused.");
                Check(EbayAttempts.Refusal(n,true,false,false,typed,null).Contains("partly typed"),"A typed order sent as new must be refused.");
                Check(EbayAttempts.Refusal(n,false,false,true,null,null).Contains("no record"),"Typed by the desk's word, no record here: refused.");
                Check(EbayAttempts.Refusal(n,true,true,true,typed,"x")==null,"Start again (Tommy checked COSTAR) is never refused here.");
            });
            Case("eBay retries: a fresh order, an empty earlier Repair Order reused, a stopped one continued only if recorded, refused when its window is gone",()=>{
                string why;
                Check(EbayAttempts.Decide(null,false,false,out why)==EbayAttempts.Fresh,"No attempt must be fresh.");
                var a=new EbayAttempt {orderNumber="11-11111-11111",window=10,processId=20,stopPrint="print"};
                Check(EbayAttempts.Decide(a,false,true,out why)==EbayAttempts.Reuse&&EbayAttempts.Decide(a,false,false,out why)==EbayAttempts.Fresh,"An untyped attempt reuses its open window or starts fresh.");
                a.typed=true;
                Check(EbayAttempts.Decide(a,false,true,out why)==EbayAttempts.Resume,"A typed, recorded attempt with its window open continues.");
                Check(EbayAttempts.Decide(a,false,false,out why)==EbayAttempts.Refuse&&why.Contains("Mark done by hand")&&why.Contains("Start again"),"A typed attempt whose window is gone must be refused with what to do.");
                a.stopPrint=null;Check(EbayAttempts.Decide(a,false,true,out why)==EbayAttempts.Refuse,"An unrecorded stop must not be continued.");
                Check(EbayAttempts.Decide(a,true,true,out why)==EbayAttempts.Fresh,"Start again (fresh) always starts fresh.");
                var j=new EbayJournal();j.entered.Add("11-11111-11111|2026-10-23T05:00:00.0000000Z");
                Check(EbayAttempts.Entered(j,"11-11111-11111")=="2026-10-23T05:00:00.0000000Z"&&EbayAttempts.Entered(j,"11-11111-1111")==null&&EbayAttempts.Entered(null,"x")==null,"Entered orders must be found by their exact number.");
                var copy=Wire.Copy(new EbayJournal {attempts=new List<EbayAttempt>{a},sequence=3});Check(copy.attempts[0].typed&&copy.sequence==3,"The journal must survive JSON.");
            });
            Case("Desk certificate: the trust download is the root that signed the HTTPS certificate, never another one",()=>{
                var a=new X509Certificate2(Convert.FromBase64String(TestRootA));var b=new X509Certificate2(Convert.FromBase64String(TestRootB));
                var desk=new X509Certificate2(Convert.FromBase64String(TestDesk));
                Check(TrustRoot.Of(desk,new X509Certificate2Collection(new[]{b}))==null,"Without the signing root nothing may be picked (the setup file is used).");
                Check(TrustRoot.Of(null,null)==null,"No certificate, no root.");
                using(var found=TrustRoot.Of(desk,new X509Certificate2Collection(new[]{b,a})))
                    Check(found!=null&&found.Thumbprint==a.Thumbprint&&!found.HasPrivateKey,"The desk must hand out the root that signed its certificate (25 Oct: it handed out another one).");
            });
            Case("eBay Repair Orders are closed once in, unless switched off (2.5.2: on by default, also for settings saved before)",()=>{
                Check(new AppSettings().ebayClose,"New settings must close eBay Repair Orders.");
                Check(Wire.Read<AppSettings>("{\"ebayOn\":true,\"ebayBranch\":1}").ebayClose,"Settings saved before 2.5.2 must close eBay Repair Orders.");
                Check(!Wire.Read<AppSettings>("{\"ebayOn\":true,\"ebayClose\":false}").ebayClose,"Switched off must stay off.");
            });
            Case("Runs by itself (2.8.0): the desk retries an eBay order that typed nothing once, kept in the queue file",()=>{
                EbayState saved=null;var q=new EbayQueue(null,s=>saved=Wire.Copy(s));var order=Sample();q.Submit(order);var claim=q.Poll(Hello());
                var stop=Report(claim,"failed",1);stop.message="Not entered: Add new was not pressed.";q.Poll(Hello(stop));
                var at=DateTime.UtcNow;
                Check(!q.AutoRetry(order.orderNumber,at.AddSeconds(30))&&q.AutoRetry(order.orderNumber,at.AddSeconds(61))&&q.Get(order.orderNumber).status=="queued","Retried once, a minute after it stopped.");
                q=new EbayQueue(saved,s=>saved=Wire.Copy(s));var again=q.Poll(Hello());Check(again.order!=null&&again.order.orderNumber==order.orderNumber,"The retry wasn't handed out again.");
                var stop2=Report(again,"failed",1);stop2.message="Not entered: Add new was not pressed.";q.Poll(Hello(stop2));
                Check(q.Get(order.orderNumber).status=="failed"&&!q.AutoRetry(order.orderNumber,DateTime.UtcNow.AddMinutes(2)),"Retried a second time.");
                var other=new EbayQueue(null,s=>{});var typedOrder=Sample("22-22222-22222");other.Submit(typedOrder);var c=other.Poll(Hello());
                var typed=Report(c,"failed",1,true);typed.message="Not entered: Add new was not pressed.";other.Poll(Hello(typed));
                Check(!other.AutoRetry(typedOrder.orderNumber,DateTime.UtcNow.AddMinutes(2))&&!EbayQueue.AutoRetryDue(null,DateTime.UtcNow),"An order that typed something was retried.");
            });
            Case("Time saved counts finished eBay orders, and stopped ones as needing a hand",()=>{
                var events=new List<Dictionary<string,object>> {
                    new Dictionary<string,object>{{"Kind","ebay_fill_ok"},{"Detail","11-11111-11111 in 42.5 s run=x"}},
                    new Dictionary<string,object>{{"Kind","ebay_fill_stopped"},{"Detail","22-22222-22222 stopped"}},
                    new Dictionary<string,object>{{"Kind","online_fill_ok"},{"Detail","TTW1 in 30 s"}}};
                var d=TimeSaved.Count(DateTime.Today,events);
                Check(d.Ebay==1&&d.Online==1&&d.Stopped==1&&Math.Abs(d.HelperSeconds-72.5)<0.01,"eBay orders not counted.");
                var s=new TimeSaved.Settings();Check(TimeSaved.MinutesSaved(d,s)==8,"eBay minutes not added.");
                var html=TimeSaved.Html(new List<TimeSaved.Day>{d},s,"test");Check(html.Contains("eBay orders")&&!html.Contains("TEST BUYER"),"The report must list eBay orders without details.");
            });
        }
    }
}
