using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    // line: the 1-based grid line the row is on (2.3.0; 0 in tests and older checkpoints).
    public sealed class MobileRow { public string code,description,quantity;public int line; }
    public sealed class MobileView { public string account,name,phone,reference;public List<MobileRow> rows=new List<MobileRow>(); }
    public sealed class MobileCheckpoint {
        public string submissionId;public int processId,sessionId,index,pending=-1,planVersion;public long window,processStart;
        // COSTAR branch of the job's Repair Order (2.3.0+; 0 in older jobs means Branch 11).
        public int branch;
        public bool opening;public MobileView verified;
        // 2.6.2: the Job Card print: "started" once OK is about to go on COSTAR's print form, "done" once it
        // went (a restart never prints it twice).
        public string print;
    }
    // line: where an "add" or "det" step must put its row (0 = after the last row).
    internal sealed class MobileStep {internal string kind,code,value,label;internal int quantity,line;}
    internal static class MobileProof {
        // 3 (2.3.0): DET and its notes first on line 6, then the items on lines 1 down.
        internal const int PlanVersion=3;
        internal static bool Unstarted(MobileCheckpoint cp) {
            // This baseline is persisted before step zero. Every field write is
            // preceded by a pending-step checkpoint, so neither may be present.
            return cp!=null&&cp.planVersion==PlanVersion&&cp.index==0&&cp.pending==-1&&cp.verified==null&&
                !cp.opening&&cp.window!=0&&cp.processId>0&&cp.processStart>0&&cp.sessionId>=0&&!String.IsNullOrWhiteSpace(cp.submissionId);
        }
        internal static void PrepareCheckpoint(MobileCheckpoint cp) {
            if(cp.planVersion==0 && cp.index==0 && cp.pending<0)cp.planVersion=PlanVersion;
            // A job from an older plan that has not started any step has nothing to reinterpret.
            if(cp.planVersion>0 && cp.planVersion<PlanVersion && cp.index==0 && cp.pending<0 && (cp.verified==null || cp.verified.rows.Count==0))cp.planVersion=PlanVersion;
            Order.Require(cp.planVersion==PlanVersion,"This partial job was started with an older helper. Finish it manually or use that helper to resume it; its steps will not be reinterpreted by this update.");
        }
        internal static bool Same(MobileView a,MobileView b) {return a!=null && b!=null && Wire.Json(a)==Wire.Json(b);}
        static bool RowSame(MobileRow a,MobileRow b) {return Wire.Json(a)==Wire.Json(b);}
        internal static List<MobileStep> Plan(MobileJob j) {
            var steps=new List<MobileStep> {
                new MobileStep {kind="phone",value=j.customer.mobile,label="Mobile number and customer lookup"},
                new MobileStep {kind="name",value=j.customer.name.ToUpperInvariant(),label="Customer name"},
                new MobileStep {kind="reference",value=j.Reference,label="Job reference"}
            };
            // DET first on its line, with its notes (and the optional notes row) under it; then
            // the items on lines 1 down, above DET: wheels, tyres, M FB, alignment.
            var ordered=j.Ordered.ToList();
            int itemLines=ordered.Count+1+(j.alignment!=null?1:0);
            int detLine=Order.DetLine(itemLines);
            steps.Add(new MobileStep {kind="det",code="DET",line=detLine,label="Create DET details"});
            steps.Add(new MobileStep {kind="memo",code="M",value="MAKE/MODEL: "+j.vehicle.makeModel.ToUpperInvariant(),label="MAKE/MODEL"});
            steps.Add(new MobileStep {kind="memo",code="M",value="REGO NO: "+j.vehicle.registration.ToUpperInvariant(),label="REGO NO"});
            steps.Add(new MobileStep {kind="memo",code="M ODO",value="ODOMETER: "+j.vehicle.odometer.Value.ToString(CultureInfo.InvariantCulture),label="ODOMETER"});
            if(j.Notes.Length>0) {
                steps.Add(new MobileStep {kind="add",code="M",label="Add notes row"});
                steps.Add(new MobileStep {kind="notes",code="M",value=Order.EntryText(j.Notes),label="Additional notes"});
            }
            int itemLine=0;
            foreach(var p in ordered) {
                itemLine++;
                steps.Add(new MobileStep {kind="add",code=p.sku,line=itemLine,label="Add "+p.type+" "+p.sku});
                steps.Add(new MobileStep {kind="quantity",code=p.sku,quantity=p.quantity,label="Quantity for "+p.sku});
            }
            itemLine++;
            steps.Add(new MobileStep {kind="add",code="M FB",line=itemLine,label="Fitting and balancing"});
            if(j.alignment!=null) {
                itemLine++;
                steps.Add(new MobileStep {kind="add",code=j.alignment,line=itemLine,label="Alignment "+j.alignment});
                steps.Add(new MobileStep {kind="quantity",code=j.alignment,quantity=1,label="Alignment quantity"});
            }
            return steps;
        }
        internal static bool After(MobileStep step,MobileView before,MobileView after) {
            if(before==null||after==null)return false;
            var expected=Wire.Copy(before);
            if(step.kind=="reference")expected.reference=step.value;
            else if(step.kind=="name")expected.name=CustomerEntry.NameForEntry(before.name,step.value);
            else if(step.kind=="phone") {
                // Phone lookup is the only step allowed to select an account/name.
                if(!CustomerEntry.LookupResolved(after.account,after.name,after.phone,step.value))return false;
                expected.account=after.account;expected.name=after.name;expected.phone=after.phone;
            } else if(step.kind=="add") {
                if(after.rows.Count!=before.rows.Count+1)return false;
                MobileRow row;
                if(step.line>0) {
                    // Exactly one new row, on the planned line, which was empty before.
                    var at=after.rows.Where(r=>r.line==step.line).ToList();
                    if(at.Count!=1 || before.rows.Any(r=>r.line==step.line))return false;
                    row=at[0];
                } else row=after.rows.Last();
                if(row.code!=step.code || (step.code!="M" && String.IsNullOrWhiteSpace(row.description)))return false;
                if(step.code=="WA"||step.code=="WAFR") {
                    string d=Order.Norm(row.description);
                    if(!d.Contains("ALIGNMENT")||!d.Contains("FRONT")||(step.code=="WA"?d.Contains("REAR"):!d.Contains("REAR")))return false;
                }
                if(step.line>0) expected.rows.Insert(expected.rows.Count(r=>r.line<step.line),row);
                else expected.rows.Add(row);
            } else if(step.kind=="quantity") {
                var rows=expected.rows.Where(r=>r.code==step.code).ToList();
                var live=after.rows.Where(r=>r.code==step.code).ToList();decimal q;
                if(rows.Count!=1||live.Count!=1||!Decimal.TryParse(live[0].quantity,NumberStyles.Number,CultureInfo.InvariantCulture,out q)||q!=step.quantity)return false;
                rows[0].quantity=live[0].quantity;
            } else if(step.kind=="det") {
                List<MobileRow> added;
                if(step.line>0) {
                    // DET on its planned line and its notes on the lines directly under it.
                    added=after.rows.Where(r=>!before.rows.Any(b=>b.line==r.line)).ToList();
                    if(added.Count==0 || added[0].line!=step.line)return false;
                    for(int i=0;i<added.Count;i++) if(added[i].line!=step.line+i)return false;
                    if(after.rows.Count!=before.rows.Count+added.Count)return false;
                } else added=after.rows.Skip(before.rows.Count).ToList();
                if(added.Count<4 || added[0].code!="DET" || added.Any(r=>!new[]{"DET","M","M ODO"}.Contains(r.code)))return false;
                if(added.Count(r=>r.code=="DET")!=1 || added.Count(r=>r.code=="M"&&r.description.StartsWith("MAKE/MODEL:",StringComparison.OrdinalIgnoreCase))!=1 ||
                    added.Count(r=>r.code=="M"&&r.description.StartsWith("REGO NO:",StringComparison.OrdinalIgnoreCase))!=1 ||
                    added.Count(r=>r.code=="M ODO"&&r.description.StartsWith("ODOMETER:",StringComparison.OrdinalIgnoreCase))!=1)return false;
                int rego=added.FindIndex(r=>r.description.StartsWith("REGO NO:",StringComparison.OrdinalIgnoreCase));
                if(rego+1>=added.Count || !added[rego+1].description.StartsWith("ODOMETER:",StringComparison.OrdinalIgnoreCase))return false;
                expected.rows.AddRange(added);
                if(step.line>0) expected.rows=expected.rows.OrderBy(r=>r.line).ToList();
            } else if(step.kind=="memo") {
                var rows=expected.rows.Where(r=>r.code==step.code && r.description.StartsWith(step.label+":",StringComparison.OrdinalIgnoreCase)).ToList();
                if(rows.Count!=1)return false;rows[0].description=step.value;
            } else if(step.kind=="notes") {
                if(expected.rows.Count==0 || expected.rows.Last().code!="M")return false;
                expected.rows.Last().description=step.value;
            } else return false;
            return Same(expected,after);
        }
        // 2.5.1: a note step stopped between its key press and taking it back: its words plus the key's
        // letter, everything else as After expects. The resume writes and confirms it again.
        internal static bool AfterWithKeyLetter(MobileStep step,MobileView before,MobileView after) {
            if(before==null||after==null||(step.kind!="memo"&&step.kind!="notes")||String.IsNullOrEmpty(step.value))return false;
            var copy=Wire.Copy(after);MobileRow row=null;
            if(step.kind=="memo") {
                var rows=copy.rows.Where(r=>r.code==step.code&&r.description!=null&&r.description.StartsWith(step.label+":",StringComparison.OrdinalIgnoreCase)).ToList();
                if(rows.Count==1)row=rows[0];
            } else if(copy.rows.Count>0&&copy.rows.Last().code=="M")row=copy.rows.Last();
            if(row==null||row.description==null||row.description.Length!=step.value.Length+1||!row.description.StartsWith(step.value,StringComparison.Ordinal))return false;
            char letter=row.description[step.value.Length];
            if(letter!='A'&&letter!='a')return false;
            row.description=step.value;
            return After(step,before,copy);
        }
        internal static bool CanClose(MobileJob job,MobileCheckpoint cp,MobileView live) {
            var expected=cp==null?null:cp.verified;
            return expected!=null && live!=null && cp.submissionId==job.submissionId && expected.reference==job.Reference &&
                Order.Phone(expected.phone)==Order.Phone(job.customer.mobile) && !String.IsNullOrWhiteSpace(expected.name) &&
                live.reference==expected.reference && CustomerEntry.SameIdentity(live.account,live.name,live.phone,expected.account,expected.name,expected.phone);
        }
    }
    // Tempe Order Check (a separate tool) reads a SECOND Tempe COSTAR window's
    // Work-in-Progress list and serves it on this PC. The helper never types into that
    // window, and before an online order is filled it asks Order Check whether the order
    // is already in COSTAR (its TTW number in the PO column, Order Check 1.4.0 or later).
    internal static class OrderCheckLink {
        internal const string WipUrl="http://127.0.0.1:8795/wip.json";
        static string cachedKey="";static DateTime cachedAt=DateTime.MinValue;
        // Order Check remembers its window as "PID@<process start time, local ticks>".
        internal static string WipKey() {
            if(DateTime.UtcNow-cachedAt<TimeSpan.FromSeconds(10)) return cachedKey;
            string key="";
            try {
                string path=System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TempeOrderCheck","settings.json");
                if(System.IO.File.Exists(path)) {
                    var d=new System.Web.Script.Serialization.JavaScriptSerializer().DeserializeObject(System.IO.File.ReadAllText(path,System.Text.Encoding.UTF8)) as Dictionary<string,object>;
                    object v; if(d!=null&&d.TryGetValue("targetKey",out v)&&v!=null) key=Convert.ToString(v,CultureInfo.InvariantCulture);
                }
            } catch(Exception) { key=""; }
            cachedKey=key;cachedAt=DateTime.UtcNow;return key;
        }
        internal static bool IsWipWindow(CostarInstance c) { return c!=null && Matches(WipKey(),c.Pid,c.Started); }
        // Called when Order Check's WIP window was just chosen.
        internal static void Forget() { cachedAt=DateTime.MinValue; }
        // The helper records process start as UTC ticks; Order Check as local ticks.
        internal static bool Matches(string key,int pid,long startedUtcTicks) {
            if(String.IsNullOrEmpty(key)) return false;
            int at=key.IndexOf('@');if(at<=0) return false;
            int keyPid;long ticks;
            if(!Int32.TryParse(key.Substring(0,at),NumberStyles.Integer,CultureInfo.InvariantCulture,out keyPid) || keyPid!=pid) return false;
            if(!Int64.TryParse(key.Substring(at+1),NumberStyles.Integer,CultureInfo.InvariantCulture,out ticks) || ticks<=0 || ticks>=DateTime.MaxValue.Ticks) return false;
            long asUtc;
            try { asUtc=new DateTime(ticks,DateTimeKind.Local).ToUniversalTime().Ticks; } catch(ArgumentException) { return false; }
            return Math.Abs(asUtc-startedUtcTicks)<=2*TimeSpan.TicksPerSecond || Math.Abs(ticks-startedUtcTicks)<=2*TimeSpan.TicksPerSecond;
        }
        // A message when Order Check's latest read already holds this order; null otherwise.
        // 2.8.1: an order from the Tempe Orders page goes in by itself only on a read of COSTAR's Work-in-Progress list
        // (Order Check's) that began after afterUtc (the order's arrival and the end of the last entry here: so what
        // was typed meanwhile, by the helper or a person, shows), with Search pressed, within the last 10 minutes,
        // unfiltered and with a PO# column. Null when there is one; else why not, and kind: "soon" (only the next read is
        // needed), "old" (no read lately: Order Check is asked for one), "stuck" (Order Check stopped: its COSTAR closed,
        // an error, paused) or "fix" (something at the PC: a filter, no PO# column, Search not pressed).
        internal static readonly TimeSpan ReadLate=TimeSpan.FromMinutes(10);
        internal static string FreshIn(string json,DateTimeOffset now,DateTime afterUtc,out string kind) {
            kind="fix";
            var root=Parse(json);
            if(root==null) return "Order Check's data can't be read";
            string state=Field(root,"state"),message=Field(root,"message");
            bool stuck=state=="setup"||state=="error"||state=="paused";
            string reader=state.Length>0&&state!="ok"&&message.Length>0?" (Order Check: "+(message.Length>120?message.Substring(0,120):message)+")":"";
            DateTimeOffset at,from;
            if(!DateTimeOffset.TryParse(Field(root,"readAt"),CultureInfo.InvariantCulture,DateTimeStyles.None,out at)) { kind=stuck?"stuck":"soon";return "Order Check hasn't read COSTAR's Work-in-Progress list yet"+reader; }
            if(!DateTimeOffset.TryParse(Field(root,"readFrom"),CultureInfo.InvariantCulture,DateTimeStyles.None,out from)) from=at;
            if(Field(root,"poColumn").Length==0) return "Order Check's Work-in-Progress list has no PO# column";
            string filter=Field(root,"filter");
            if(filter.Length>0) return "Order Check's Work-in-Progress list is filtered ("+filter+"): clear it at the PC";
            if(Field(root,"searched")=="False") return "Order Check read COSTAR's list without pressing Search"+(message.Length>0&&message!="Reading normally."?" (Order Check: "+(message.Length>120?message.Substring(0,120):message)+")":"")+": in Order Check, tick Press Search before each read, and check that its COSTAR shows Work-in-Progress with its Search button";
            if(now-at>ReadLate||at-now>TimeSpan.FromMinutes(5)) { kind=stuck?"stuck":"old";return "Order Check last read COSTAR at "+at.ToLocalTime().ToString("HH:mm",CultureInfo.InvariantCulture)+reader; }
            if(from.UtcDateTime<=afterUtc) { kind=stuck?"stuck":"soon";return "waiting for Order Check's next read of COSTAR (so what was typed last shows)"+reader; }
            kind="";return null;
        }
        static Dictionary<string,object> Parse(string json) {
            try { return new System.Web.Script.Serialization.JavaScriptSerializer{MaxJsonLength=16*1024*1024}.DeserializeObject(json??"") as Dictionary<string,object>; } catch(Exception) { return null; }
        }
        // 2.8.1: an order from the page against a read of COSTAR's Work-in-Progress list, as the page checks it: "in"
        // (its number is a job's PO#, or in a job's comment, or was on a job that has left Work-in-Progress since:
        // invoiced or deleted), "maybe" (a job for the same customer, or a walk-in, with the same amount, within 2% or $1,
        // that isn't another online order: a person decides), else "missing".
        internal sealed class WipSeen { internal string Kind="missing",Doc="",How="",When=""; }
        // A name's words (two letters or more: LI, WU and NG are surnames), less titles and company words.
        static readonly HashSet<string> NameNoise=new HashSet<string>(StringComparer.Ordinal){"THE","AND","PTY","LTD","MRS","MISS","MR","MS","DR","JR","SR","CO"};
        static HashSet<string> NameWords(string name) {
            var words=new HashSet<string>(StringComparer.Ordinal);
            foreach(string w in System.Text.RegularExpressions.Regex.Split((name??"").ToUpperInvariant(),"[^A-Z]+")) if(w.Length>=2&&!NameNoise.Contains(w)) words.Add(w);
            return words;
        }
        // A job under no particular customer (a walk-in, a cash sale): it could be anyone's order typed by hand.
        static bool AnyCustomer(string name) { return System.Text.RegularExpressions.Regex.IsMatch((name??"").Trim().ToUpperInvariant(),@"^$|WALK|CASH|COUNTER|ONLINE|INTERNET|CUSTOMER"); }
        internal static WipSeen MatchIn(string json,Order o) {
            var seen=new WipSeen();
            var root=Parse(json);
            object rowsValue;var list=root!=null&&root.TryGetValue("rows",out rowsValue)?rowsValue as System.Collections.IEnumerable:null;
            if(list==null||o==null) return seen;
            var rows=list.Cast<object>().Select(x=>x as Dictionary<string,object>).Where(x=>x!=null).ToList();
            string id=(o.orderId??"").Trim().ToUpperInvariant();
            string digits=id.StartsWith("TTW",StringComparison.Ordinal)?id.Substring(3):id;
            var byPo=rows.FirstOrDefault(r=>String.Equals(Field(r,"po").Trim(),id,StringComparison.OrdinalIgnoreCase));
            if(byPo!=null) { seen.Kind="in";seen.Doc=Field(byPo,"doc");seen.How="PO#";return seen; }
            if(digits.Length>=5&&digits.All(Char.IsDigit)) {
                var inText=new System.Text.RegularExpressions.Regex("(^|[^0-9])(TTW)?"+digits+"([^0-9]|$)",System.Text.RegularExpressions.RegexOptions.IgnoreCase|System.Text.RegularExpressions.RegexOptions.CultureInvariant);
                var byComment=rows.FirstOrDefault(r=>inText.IsMatch(Field(r,"comment")));
                if(byComment!=null) { seen.Kind="in";seen.Doc=Field(byComment,"doc");seen.How="comment";return seen; }
            }
            object leftValue;var left=root.TryGetValue("left",out leftValue)?leftValue as System.Collections.IEnumerable:null;
            if(left!=null) foreach(object x in left) {
                var job=x as Dictionary<string,object>;
                if(job==null||(" "+Field(job,"ttw").ToUpperInvariant()+" ").IndexOf(" "+id+" ",StringComparison.Ordinal)<0) continue;
                seen.Kind="in";seen.Doc=Field(job,"doc");seen.How="left";seen.When=Field(job,"lastSeen");return seen;
            }
            decimal amount=o.totalCents/100m;
            if(amount>0) {
                var customer=NameWords(o.customer==null?"":o.customer.name);
                var same=new List<string>();
                foreach(var r in rows) {
                    if(Field(r,"hasTotal")=="False") continue;
                    string po=Field(r,"po").Trim();
                    if(System.Text.RegularExpressions.Regex.IsMatch(po,"^TTW\\d+$",System.Text.RegularExpressions.RegexOptions.IgnoreCase)) continue;   // another online order
                    decimal total;
                    if(!Decimal.TryParse(Field(r,"total"),NumberStyles.Number,CultureInfo.InvariantCulture,out total)) continue;
                    if(Math.Abs(total-amount)>Math.Max(1m,amount*0.02m)) continue;
                    string name=Field(r,"name");
                    if(!AnyCustomer(name)&&!NameWords(name).Overlaps(customer)) continue;   // another customer's job
                    same.Add(Field(r,"doc"));
                }
                if(same.Count>0) { seen.Kind="maybe";seen.Doc=String.Join(", ",same.Take(5).ToArray());seen.How=same.Count==1?"same amount":same.Count+" jobs with the same amount";return seen; }
            }
            return seen;
        }
        internal static string AlreadyInCostar(string orderId,out string note) {
            note="";
            if(String.IsNullOrWhiteSpace(orderId)) return null;
            string json;
            // Order Check runs inside this app (2.0.0+): read its data directly.
            var local=TempeOrderCheck.Hosting.Store;
            if(local!=null) {
                try { json=System.Text.Encoding.UTF8.GetString(local.Snapshot()); }
                catch(Exception) { note="Order Check data unavailable"; return null; }
                return FindInWip(json,orderId,out note);
            }
            try {
                var request=(System.Net.HttpWebRequest)System.Net.WebRequest.Create(WipUrl);
                request.Method="GET";request.Timeout=1500;request.ReadWriteTimeout=1500;request.Proxy=null;request.KeepAlive=false;
                using(var response=(System.Net.HttpWebResponse)request.GetResponse())
                using(var reader=new System.IO.StreamReader(response.GetResponseStream(),System.Text.Encoding.UTF8)) json=reader.ReadToEnd();
            } catch(Exception) { note="Order Check is not running"; return null; }
            return FindInWip(json,orderId,out note);
        }
        internal static string FindInWip(string json,string orderId,out string note) {
            note="";
            Dictionary<string,object> root=null;
            try { root=new System.Web.Script.Serialization.JavaScriptSerializer{MaxJsonLength=16*1024*1024}.DeserializeObject(json??"") as Dictionary<string,object>; } catch(Exception) { root=null; }
            if(root==null) { note="Order Check sent unreadable data"; return null; }
            string column=Field(root,"poColumn");
            if(column.Length==0) {
                string state=Field(root,"state");
                note=state=="ok"?"Order Check's WIP list has no PO column, so it cannot check for duplicates":
                    "Order Check has not read the WIP list yet ("+(state.Length>0?state:"starting")+"), so it cannot check for duplicates";
                return null;
            }
            object rowsValue;var rows=root.TryGetValue("rows",out rowsValue)?rowsValue as System.Collections.IEnumerable:null;
            if(rows==null) { note="Order Check has no rows yet"; return null; }
            string want=orderId.Trim();
            foreach(object o in rows) {
                var row=o as Dictionary<string,object>;
                if(row==null || !String.Equals(Field(row,"po").Trim(),want,StringComparison.OrdinalIgnoreCase)) continue;
                string doc=Field(row,"doc"),by=Field(row,"by"),read=Field(root,"readAt");
                note="already in COSTAR as document "+doc;
                return want+" is already in COSTAR as document "+(doc.Length>0?doc:"?")+(by.Length>0?" (written by "+by+")":"")+", according to Order Check"+
                    (read.Length>=16?" (read at "+read.Substring(11,5)+")":"")+". Not entered twice; check that document.";
            }
            note="not in Order Check's Work-in-Progress list";
            return null;
        }
        static string Field(Dictionary<string,object> d,string key) {
            object v; return d!=null&&d.TryGetValue(key,out v)&&v!=null?Convert.ToString(v,CultureInfo.InvariantCulture):"";
        }
    }
    internal static class CostarWindows {
        internal static bool IsCostar(IntPtr h) {
            ProcessIdentity identity;return LocalProcess.IsNamed((int)Native.Pid(h),"COSTAR",out identity);
        }
        // What the last search saw: COSTAR main-window titles only (never other apps).
        internal static volatile string LastScan="";
        internal static List<CostarInstance> Choices() {
            var result=new List<CostarInstance>();var identities=new Dictionary<int,ProcessIdentity>();
            var seen=new List<string>();int costarWindows=0;
            Native.EnumWindows(delegate(IntPtr h,IntPtr unused) {
                if(!Native.IsWindowVisible(h))return true;
                string title=Native.Caption(h);
                if(title.StartsWith("COSTAR",StringComparison.OrdinalIgnoreCase)){costarWindows++;if(seen.Count<6)seen.Add(title.Length>48?title.Substring(0,48):title);}
                if(Branches.OfMain(title)==0)return true;
                int pid=(int)Native.Pid(h);ProcessIdentity identity;
                if(!identities.TryGetValue(pid,out identity)) {
                    if(!LocalProcess.IsNamed(pid,"COSTAR",out identity))identity=null;
                    identities[pid]=identity;
                }
                if(identity!=null)result.Add(new CostarInstance(pid,h.ToInt64(),identity.Started,identity.Session,title));
                else if(seen.Count<8)seen.Add("(window of process "+pid+" is not a COSTAR process in this session)");
                return true;
            },IntPtr.Zero);
            LastScan=costarWindows+" COSTAR window(s) seen"+(seen.Count>0?": "+String.Join(" | ",seen):"");
            return result.OrderBy(x=>x.Pid).ThenBy(x=>x.MainWindow).ToList();
        }
        internal static IntPtr Main(CostarInstance target) {
            Order.Require(target!=null,"Select a COSTAR in the list above.");
            var h=new IntPtr(target.MainWindow);
            Order.Require(Native.IsWindow(h)&&Native.Pid(h)==target.Pid&&Branches.MainTitle(Native.Caption(h),target.Branch),"The selected COSTAR ("+target.Label+") was closed or changed branch. Refresh and select a target.");
            ProcessIdentity identity;
            Order.Require(LocalProcess.IsNamed(target.Pid,"COSTAR",out identity)&&identity.Started==target.Started&&identity.Session==target.Session,"The selected COSTAR restarted or is unavailable. Select it again; no replacement was chosen automatically.");
            return h;
        }
        internal static List<IntPtr> Orders(CostarInstance target) {
            Main(target);var result=new List<IntPtr>();
            Native.EnumWindows(delegate(IntPtr h,IntPtr unused) {
                // Filter by the selected PID before reading any other window.
                if(Native.Pid(h)==target.Pid&&Native.IsWindowVisible(h)&&Native.Caption(h).StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase))result.Add(h);
                return true;
            },IntPtr.Zero);return result;
        }
        // 2.6.8: Work-in-Progress first. Only there does Add new start a Repair Order; a Repair Order open
        // meanwhile is looked at (and may be closed first for the phone) once the list is back.
        internal static bool Available(CostarInstance target,out string detail) {
            try {
                string why=WhyNotOnWip(target);
                if(why!=null){detail=why;return false;}
                if(Orders(target).Count>0){detail="A Repair Order is open in the selected COSTAR";return false;}
                detail="Selected COSTAR ready ("+target.Label+")";return true;
            } catch(Exception e){detail=e.Message;return false;}
        }
        // 2.6.8 (29 Oct 01:05: Tommy left COSTAR Sydney on "Orders yet to be filled", the wholesale orders):
        // COSTAR's main window shows one list at a time, each with its own Add new in the same place, and on
        // another list Add new starts that list's document (a wholesale Order there), not a Repair Order. Every
        // Add new the helper presses (online orders, phone jobs, eBay orders) needs Work-in-Progress showing,
        // found the way Order Check and the phone's Repair Orders find it (TempeOrderCheck.WipScreen.Locate).
        // For the waits (Available, the eBay worker, the phone's Repair Orders): another list, or
        // Work-in-Progress named but not found, holds work back with the reason (null: go ahead). A COSTAR too
        // busy to say doesn't: OpenNew's own look waits for it (as before 2.6.8, work isn't held for that).
        internal static string WhyNotOnWip(CostarInstance target) {
            string showing=Showing(Main(target));
            return String.IsNullOrEmpty(showing)?null:NotOnWip(target.Label,showing);
        }
        // The list the main window shows: null when it is Work-in-Progress; else its title (ListTitle), or ""
        // when it couldn't be read. A COSTAR that doesn't answer a no-op message within 250 ms is asked
        // nothing more (each label read could wait) and reads as "".
        internal static string Showing(IntPtr main) {
            UIntPtr answer;
            if(Native.SendNull(main,0,UIntPtr.Zero,IntPtr.Zero,0x0002,250,out answer)==IntPtr.Zero) return "";
            return TempeOrderCheck.WipScreen.Locate(main)!=null?null:ListTitle(main);
        }
        // A list whose title isn't COSTAR's short words: another list all the same, its words never repeated.
        internal const string UnnamedList="(another list)";
        // How wide the title over the list is at least: it spans the list (1713 px on the PC's maximised COSTAR,
        // 29 Oct maps); the search panel's labels are 235 px at most.
        internal const int TitleWidth=400;
        // How long OpenNew waits for a COSTAR too busy to say which list it shows (or Work-in-Progress still
        // loading) before it refuses: about as long as the helper's other waits for a busy COSTAR.
        internal const int WipWaitMs=15000;
        // 2.6.11: how long a window over Add new (a desktop switch still on screen) is waited out.
        internal const int AddNewCoverMs=1500;
        // Whose window is over a point: the program's name (never its title: another program's title can name a
        // customer), or "nothing" / "unknown".
        internal static string CoverOwner(Native.Point point) {
            try {
                var h=Native.WindowFromPoint(point);if(h==IntPtr.Zero) return "nothing";
                int pid=(int)Native.Pid(h);if(pid<=0) return "unknown";
                return Process.GetProcessById(pid).ProcessName;
            } catch(Exception) { return "unknown"; }
        }
        // Another list's title was read: waiting doesn't help. Work-in-Progress's own title without the list
        // found is that list still loading; "" is COSTAR busy (or no title found).
        internal static bool OtherList(string showing) {
            if(showing==UnnamedList) return true;
            string t=TitleWords(showing);
            return t!=null&&!String.Equals(t,"Work-in-Progress",StringComparison.OrdinalIgnoreCase);
        }
        // What is said when Add new can't be pressed (showing: as Showing gives it, never null here).
        internal static string NotOnWip(string costar,string showing) {
            const string what=", not Work-in-Progress (Add new there doesn't start a Repair Order). Put it back on Work-in-Progress";
            if(showing==UnnamedList) return "COSTAR "+costar+" is showing another list"+what;
            string t=TitleWords(showing);
            if(t==null) return "COSTAR "+costar+" isn't answering: which list it shows couldn't be read (it must show Work-in-Progress)";
            if(!OtherList(t)) return "COSTAR "+costar+"'s Work-in-Progress list isn't ready yet";
            return "COSTAR "+costar+" is showing \""+t+"\""+what;
        }
        // A list title is COSTAR's own short words ("Work-in-Progress", "Orders yet to be filled"); anything
        // longer or with other characters is never shown or logged.
        internal static string TitleWords(string text) {
            string t=(text??"").Trim();
            return t.Length>0&&t.Length<=40&&Regex.IsMatch(t,@"^[A-Za-z][A-Za-z0-9 '&/().,-]*$")?t:null;
        }
        // The title over the main window's list (Title): read with Windows' 100 ms text read, nothing pressed.
        // The first label that doesn't answer ends the look: "" (unreadable), so a lower label is never taken
        // for the title.
        internal static string ListTitle(IntPtr main) {
            var wide=new List<Tuple<int,int,string>>();bool failed=false;
            Native.EnumChildWindows(main,delegate(IntPtr h,IntPtr unused) {
                if(!Native.IsWindowVisible(h)||Native.Class(h).IndexOf("STATIC",StringComparison.OrdinalIgnoreCase)<0) return true;
                string t;Native.Rect r;
                if(!Native.TryText(h,out t)) { failed=true;return false; }
                if(Native.GetWindowRect(h,out r)&&r.Right-r.Left>=TitleWidth) wide.Add(Tuple.Create(r.Top,r.Left,t??""));
                return true;
            },IntPtr.Zero);
            return failed?"":Title(wide);
        }
        // Of the wide labels (top, left, words): the topmost (the leftmost when level) is the title. Its words
        // when they are COSTAR's short words, else UnnamedList; "" when there's none or it's empty.
        internal static string Title(IEnumerable<Tuple<int,int,string>> wide) {
            var best=wide.OrderBy(x=>x.Item1).ThenBy(x=>x.Item2).FirstOrDefault();
            if(best==null||String.IsNullOrWhiteSpace(best.Item3)) return "";
            return TitleWords(best.Item3)??UnnamedList;
        }
        internal static IntPtr OnlineOrder(CostarInstance target) {
            var orders=Orders(target);
            Order.Require(orders.Count==1 && Branches.OrderTitle(Native.Caption(orders[0]),target.Branch),"Open one NEW empty Repair Order in the selected COSTAR ("+target.Label+"). Other COSTAR instances can stay open.");
            return orders[0];
        }
        // allowExisting: earlier Repair Orders may stay open (online orders left for review);
        // the new window is the one that was not there before the click.
        internal static IntPtr OpenNew(CostarInstance target,Action beforeClick,Func<bool> cancelled,bool allowExisting=false) {
            var before=new HashSet<long>(Orders(target).Select(h=>h.ToInt64()));
            Order.Require(allowExisting || before.Count==0,"A Repair Order is already open in the selected COSTAR; it will not be overwritten.");
            var main=Main(target);var buttons=new List<IntPtr>();
            // 2.6.8: Add new only while Work-in-Progress shows (WhyNotOnWip). Another list's title refuses at
            // once; a list that can't be read (COSTAR busy) or is still loading is looked at again for up to
            // WipWaitMs, then refused.
            string showing=Showing(main);
            for(var look=Stopwatch.StartNew();showing!=null&&!OtherList(showing)&&!cancelled()&&look.ElapsedMilliseconds<WipWaitMs;showing=Showing(Main(target))) Thread.Sleep(250);
            Order.Require(!cancelled(),"Stopped before Add new. Nothing was pressed.");
            if(showing!=null) { string why=NotOnWip(target.Label,showing);AppLog.Note("add_new_refused",why);throw new InvalidOperationException(why+". Add new was not pressed."); }
            Native.EnumChildWindows(main,delegate(IntPtr h,IntPtr unused){string t;
                if(Native.IsWindowVisible(h)&&Native.IsWindowEnabled(h)&&Native.Class(h).IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)>=0&&Native.TryText(h,out t)&&Order.Norm(t).Replace("&","")=="ADD NEW")buttons.Add(h);return true;
            },IntPtr.Zero);
            Order.Require(buttons.Count==1,before.Count>0?"Add New is not available while another Repair Order is open in this COSTAR. Save or close the previous order, then click Fill again.":"Could not identify the recorded Add new button. Leave the selected COSTAR on Work-in-Progress.");
            Native.BringToFront(main); // Works even when an order arrives while Chrome is in front.
            var activation=Stopwatch.StartNew();
            while(!cancelled()&&Native.GetForegroundWindow()!=main&&activation.ElapsedMilliseconds<2000)Thread.Sleep(25);
            Order.Require(!cancelled()&&Native.GetForegroundWindow()==main&&Native.IsWindowEnabled(main)&&Orders(target).Count==before.Count,"The selected COSTAR is not ready to open a new order.");
            var button=buttons[0];Native.Rect box;Order.Require(Native.GetWindowRect(button,out box),"Add new moved.");
            var point=new Native.Point{X=(box.Left+box.Right)/2,Y=(box.Top+box.Bottom)/2};
            Order.Require(Native.GetAncestor(button,2)==main,"Add new moved.");
            bool covered=Native.WindowFromPoint(point)!=button;
            // 2.6.11: looked at again for a moment (30 Oct 08:14, 26 Oct x3: COSTAR Sydney on a Windows desktop of its
            // own; the switch to it was still on the screen 0.1 s after COSTAR was asked forward, so the order
            // stopped and went in on Retry). A cover that stays is still refused, saying whose window it is.
            if(covered&&before.Count==0) {
                var cover=Stopwatch.StartNew();
                while(covered&&!cancelled()&&cover.ElapsedMilliseconds<AddNewCoverMs) { Thread.Sleep(50);covered=Native.WindowFromPoint(point)!=button; }
                Order.Require(!cancelled(),"Stopped before Add new. Nothing was pressed.");
                string owner=covered?CoverOwner(point):"";
                AppLog.Note("add_new_covered",(covered?"still covered after ":"clear after ")+cover.ElapsedMilliseconds+" ms"+(covered?" by "+owner:""));
                Order.Require(!covered,"Add new is covered by another window ("+owner+"). Add new was not pressed.");
            }
            Main(target);
            // 2.6.8: a last look: another list's title now (switched meanwhile) refuses; nothing is pressed.
            showing=Showing(main);
            if(showing!=null&&OtherList(showing)) { string why=NotOnWip(target.Label,showing);AppLog.Note("add_new_refused",why);throw new InvalidOperationException(why+". Add new was not pressed."); }
            // 2.6.8: and Add new itself still showing and usable (another list hides it), and for a click still
            // the window under the point: read without any text, so even a busy COSTAR can't slip past it.
            bool mouse=!covered&&!Direct.On;
            if(!(Native.IsWindowVisible(button)&&Native.IsWindowEnabled(button)&&(!mouse||Native.WindowFromPoint(point)==button))) {
                string why="COSTAR "+target.Label+"'s Add new changed before it could be pressed (another list?)";AppLog.Note("add_new_refused",why);throw new InvalidOperationException(why+". Add new was not pressed.");
            }
            beforeClick();
            // 2.6.5: pressed directly (its own click, BM_CLICK, as when an open order covers it): no mouse. Never
            // followed by a click (a second Add New would open a second Repair Order).
            if(mouse) Native.Click(point);
            else { UIntPtr pressed; Native.WriteMessage(button,0xF5,UIntPtr.Zero,null,3,1000,out pressed); }
            var timer=Stopwatch.StartNew();var settle=Stopwatch.StartNew();IntPtr candidate=IntPtr.Zero;bool promptNoted=false;
            while(timer.ElapsedMilliseconds<30000) {
                Order.Require(!cancelled(),"Stopped while waiting for Add New. Check COSTAR before retrying.");
                // 4 Oct: Add New took 31 s with the reviewed order still open. Record any COSTAR
                // prompt shown meanwhile (title and type only); nothing is pressed.
                IntPtr fg=Native.GetForegroundWindow();
                // "Order Entry" is COSTAR's own new-order window (5 Oct, every order), not a prompt.
                if(!promptNoted && fg!=IntPtr.Zero && fg!=main && Native.Pid(fg)==target.Pid && !Native.Caption(fg).StartsWith("RepairOrder",StringComparison.OrdinalIgnoreCase) && Native.Caption(fg)!="Order Entry") {
                    promptNoted=true;AppLog.Note("add_new_prompt","COSTAR showed \""+Native.Caption(fg)+"\" ("+Native.Class(fg)+") after Add New, at "+timer.ElapsedMilliseconds+" ms");
                }
                var fresh=Orders(target).Where(h=>!before.Contains(h.ToInt64())).ToList();
                Order.Require(fresh.Count<=1,"More than one Repair Order appeared in the selected COSTAR.");
                if(fresh.Count==1) {
                    Order.Require(Branches.OrderTitle(Native.Caption(fresh[0]),target.Branch),"The new Repair Order is not in "+target.Label+".");
                    // COSTAR can show a first window while it builds the order and then replace
                    // it (3 Oct: the window returned here was gone a moment later). Hand over
                    // only a window that has stayed the same for 300 ms.
                    if(fresh[0]==candidate && settle.ElapsedMilliseconds>=300) return fresh[0];
                    if(fresh[0]!=candidate) { candidate=fresh[0]; settle.Restart(); }
                } else candidate=IntPtr.Zero;
                Thread.Sleep(50);
            }
            throw new InvalidOperationException("Add New did not appear. A second click will not be sent automatically.");
        }
        // True when a job's Repair Order window no longer exists in its COSTAR process
        // (closed by hand, or COSTAR was closed or restarted). Cheap: no process query.
        internal static bool OrderWindowGone(MobileCheckpoint cp) {
            if(cp==null || cp.window==0) return false;
            var h=new IntPtr(cp.window);
            return !(Native.IsWindow(h) && (int)Native.Pid(h)==cp.processId);
        }
        // True when the COSTAR process a job was pinned to is no longer running.
        internal static bool PinnedProcessGone(MobileCheckpoint cp) {
            if(cp==null || cp.processId<=0) return false;
            ProcessIdentity identity;
            return !(LocalProcess.IsNamed(cp.processId,"COSTAR",out identity) && identity.Started==cp.processStart && identity.Session==cp.sessionId);
        }
        internal static void ValidateTarget(MobileCheckpoint c) {
            var h=new IntPtr(c.window);Order.Require(Native.IsWindow(h)&&Native.Pid(h)==c.processId&&Branches.OrderTitle(Native.Caption(h),Branches.OrLegacy(c.branch)),"The original Repair Order no longer exists; it will not be recreated on Retry.");
            ProcessIdentity identity;Order.Require(LocalProcess.IsNamed(c.processId,"COSTAR",out identity)&&identity.Started==c.processStart&&identity.Session==c.sessionId,"COSTAR restarted or changed session. Check the partial order manually.");
        }
    }
    internal sealed partial class Runner {
        internal IntPtr Target {get{return root;}}
        FieldMap mobileHeader;
        List<ControlInfo> WaitForMobileStartup() {
            Say("Waiting for the new Repair Order's customer fields and item grid to load.");
            var wait=Diag.Wait("ro_startup");
            try {
            var timer=Stopwatch.StartNew();string problem="COSTAR has not finished opening the Repair Order.";
            while(timer.ElapsedMilliseconds<30000) {
                wait.Tick();Check(false);
                var front=Native.GetForegroundWindow();
                if(front==root&&Native.IsWindowEnabled(root)) {
                    var snapshot=Snapshot(root);Check(true);
                    if(lastSnapshotBusy){problem="COSTAR is busy drawing the new order.";Pause(150);continue;}
                    try {
                        // A blank row may not create its quantity/price editors
                        // until a SKU is entered. Require the same initial form
                        // structure as the working online blank-order check.
                        Selectors.Header(snapshot);Selectors.ProductGrid(snapshot);Selectors.Total(snapshot);
                        // A field that could not be read means COSTAR was still drawing the
                        // order (a normal idle form reads every field). Wait, do not stop.
                        if(lastSnapshotBusy || snapshot.Any(c=>c.TextState=="read-failed-or-timed-out")){problem="COSTAR was still drawing the new order.";Pause(150);continue;}
                        wait.Done("ok");return snapshot;
                    } catch(InvalidOperationException e){problem=e.Message;}
                } else {
                    if(front!=root)Diag.ForegroundLost(front,Native.IsWindowEnabled(root));
                    problem="Blocking/foreground window: "+Native.Caption(front)+" (PID "+Native.Pid(front)+"). Leave the original Repair Order in front and close any prompt yourself.";
                }
                Pause(60);
            }
            wait.Done("timeout");
            throw new InvalidOperationException("The new Repair Order did not finish loading. No job fields were entered. Leave its window open and retry. "+problem);
            } finally {wait.End();}
        }
        MobileView MobileSnapshot() {
            FieldMap h=mobileHeader;List<ControlInfo> s;
            if(h!=null) {
                try {CheckTarget(h.Account);CheckTarget(h.Name);CheckTarget(h.Phone);CheckTarget(h.PO);}
                catch(InvalidOperationException){h=null;}
            }
            if(h==null){s=Current();h=Selectors.Header(s);mobileHeader=h;}else s=GridCurrent();
            var g=Selectors.ProductGrid(s);
            var v=new MobileView {account=ReadLive(h.Account),name=ReadLive(h.Name),phone=ReadLive(h.Phone),reference=ReadLive(h.PO)};
            for(int i=0;i<g.Rows.Count;i++) {
                var row=g.Rows[i];
                if(row.Value.Length==0) continue;
                string code=Order.Norm(row.Value),quantity="";
                if(!new[]{"M","M FB","M ODO","DET"}.Contains(code))quantity=Selectors.Cell(s,row,g.Quantity).Value;
                v.rows.Add(new MobileRow {code=code,description=Selectors.Cell(s,row,g.Description).Value,quantity=quantity,line=i+1});
            }
            return v;
        }
        MobileView StableMobileView() {
            var wait=Diag.Wait("stable_view");
            try {
            MobileView prior=null;var timer=Stopwatch.StartNew();string problem="";
            while(timer.ElapsedMilliseconds<8000) {
                wait.Tick();Ready();
                try{var v=MobileSnapshot();if(MobileProof.Same(prior,v)){wait.Done("ok");return v;}prior=v;}
                catch(InvalidOperationException e){Check(true);prior=null;problem=e.Message;}
                Pause(40);
            }
            wait.Done("timeout");
            throw new InvalidOperationException("The mobile order did not settle for verification. "+problem);
            } finally {wait.End();}
        }
        MobileView WaitAfterMobileStep(MobileStep step,MobileView before) {
            var wait=Diag.Wait("verify_after_step");
            try {
            var timer=Stopwatch.StartNew();
            while(timer.ElapsedMilliseconds<4000) {
                wait.Tick();Ready();
                try {var view=MobileSnapshot();if(MobileProof.After(step,before,view)){wait.Done("ok");return view;}}
                catch(InvalidOperationException) { /* A COSTAR row may still be expanding. */ }
                Pause(25);
            }
            wait.Done("timeout");
            throw new InvalidOperationException("Verification failed after "+step.label+". Retry will inspect this operation before doing anything.");
            } finally {wait.End();}
        }
        void MobileDo(MobileStep step,MobileView before) {
            if(step.kind=="reference")Put(HeaderNow().PO,step.value,step.label,true);
            else if(step.kind=="name") {if(String.IsNullOrWhiteSpace(before.name))CustomerField(m=>m.Name,step.value,step.label);}
            else if(step.kind=="phone") {
                lookupPhone=step.value;Put(HeaderNow().Phone,step.value,step.label,true);
                bool existing=LookupCustomer();mobileHeader=null;Say(existing?"Matched phone; retaining COSTAR's account and name.":"No customer found; entering the job card name.");
            }
            else if(step.kind=="add")AddCode(step.code,step.code=="M",false,false,step.line);
            else if(step.kind=="quantity") {
                var s=GridCurrent();var g=Selectors.ProductGrid(s);var row=Selectors.One(g.Rows.Where(r=>Order.Norm(r.Value)==step.code),step.code);
                PutQuantity(Selectors.Cell(s,row,g.Quantity),step.quantity,step.label);
            } else if(step.kind=="det") {AddCode("DET",false,commitOutsideGrid:true,line:step.line);WaitForDetailsTemplate();}
            else if(step.kind=="memo")Memo(step.label,step.value.Substring(step.label.Length+1).TrimStart(),step.code,false);
            else if(step.kind=="notes") {
                Func<MemoTarget> locate=delegate {var s=GridCurrent();var g=Selectors.ProductGrid(s);var r=g.Rows.Last(x=>x.Value.Length>0);Order.Require(Order.Norm(r.Value)=="M","Additional notes row changed.");return new MemoTarget {Row=r,Editor=Selectors.Cell(s,r,g.Description)};};
                var target=FocusMemo(locate,"Additional notes");WriteNote(target.Editor,step.value,"Additional notes");
            }
        }
        internal void RunMobile(MobileJob job,MobileCheckpoint cp,Action<MobileCheckpoint> persist) {
            job.Validate();Order.Require(cp.submissionId==job.submissionId&&cp.window==root.ToInt64(),"Wrong target checkpoint.");
            runClock.Restart();var plan=MobileProof.Plan(job);Diag.Kind="mobile";
            try {
                stageCount=plan.Count+4;Diag.BeginStage("Startup: wait for Repair Order and verify");Stage("Opening the Repair Order");
                MobileProof.PrepareCheckpoint(cp);persist(cp);
                if(cp.verified!=null)Diag.EventRaw("resume","checkpoint index "+cp.index+", pending "+cp.pending+", plan "+plan.Count+" steps");
                if(cp.verified==null) {
                    // A visible title is not proof that a freshly opened form's
                    // children have loaded. Do not treat startup as phone lookup.
                    enteringCustomer=false;Activate();
                    var startup=WaitForMobileStartup();Diag.Layout(startup);Selectors.Blank(startup,branch);cp.verified=StableMobileView();persist(cp);
                    enteringCustomer=true;
                } else {enteringCustomer=true;ActivateAndWait();}
                if(cp.pending>=0 && cp.pending<plan.Count) {
                    var pending=plan[cp.pending];var view=MobileSnapshot();
                    if(pending.kind=="phone" && MobileProof.After(pending,cp.verified,view)) {
                        var phone=Selectors.Header(Current()).Phone;
                        if(Native.Focus(root).ToInt64()==phone.Handle)CommitField(phone);
                        LookupCustomer();
                    } else if((pending.kind=="memo"||pending.kind=="notes") && (MobileProof.After(pending,cp.verified,view)||MobileProof.AfterWithKeyLetter(pending,cp.verified,view))) {
                        // 2.5.1: a note stopped before or during its key press shows its words (or its words and
                        // the key's letter), but COSTAR may not keep them: written and confirmed again.
                        enteringCustomer=false;MobileDo(pending,cp.verified);enteringCustomer=true;
                    }
                }
                if(cp.pending>=0 && cp.pending<plan.Count && plan[cp.pending].kind=="det") {
                    var view=MobileSnapshot();
                    if(view.rows.Count>cp.verified.rows.Count && view.reference==order.orderId) {LeaveGrid("while recovering DET");WaitForDetailsTemplate();}
                }
                var live=StableMobileView();
                if(cp.pending>=0) {
                    Order.Require(cp.pending==cp.index&&cp.index<plan.Count,"Invalid checkpoint position.");
                    if(MobileProof.After(plan[cp.index],cp.verified,live)) {cp.verified=live;cp.index++;cp.pending=-1;persist(cp);}
                    else if(MobileProof.Same(cp.verified,live)) {cp.pending=-1;persist(cp);}
                    else throw new InvalidOperationException("The interrupted operation is only partly applied or the order changed. Retry cannot safely guess; finish/check it manually. No rows were repeated.");
                }
                Order.Require(MobileProof.Same(cp.verified,live),"COSTAR no longer matches the last verified step. Nothing will be overwritten.");
                Diag.EndStage(true);
                // The first step re-reads COSTAR after startup or resume. Later steps start
                // from the view this run verified moments earlier; any edit in between still
                // fails the next step's whole-order verification.
                bool continuing=false;
                while(cp.index<plan.Count) {
                    var step=plan[cp.index];Say((cp.index+1)+"/"+plan.Count+": "+step.label);
                    // Customer-popup recovery is only for the phone, name and reference steps.
                    enteringCustomer=step.kind=="phone"||step.kind=="name"||step.kind=="reference";
                    if(!continuing){Ready();Order.Require(MobileProof.Same(cp.verified,MobileSnapshot()),"The order was edited between steps; stopped to prevent mixing changes.");}
                    // One durable write per step records every verified step and marks this
                    // one pending. A stop after the step is reconciled by the pending check.
                    cp.pending=cp.index;persist(cp);MobileView after=null;
                    Timed(step.label,delegate {MobileDo(step,cp.verified);after=WaitAfterMobileStep(step,cp.verified);});
                    cp.verified=after;cp.index++;cp.pending=-1;continuing=true;
                }
                persist(cp);enteringCustomer=false;
                Diag.BeginStage("Final verification and report");Stage("Final check");Ready();var final=MobileSnapshot();Order.Require(MobileProof.Same(cp.verified,final)&&MobileProof.CanClose(job,cp,final),"Final mobile order verification failed.");
                // The phone's choices (2.6.2): ordered (Ship Via SHOP, Repair Date today, Customer Waiting) and
                // the Job Card printed, each only when chosen (an older phone: ordered, not printed). Not part
                // of the mobile proof (account, name, phone, PO#, rows), so done after it; never fatal.
                bool ordering=job.Ordering,printing=job.PrintingJobCard,shop=false,today=false,waiting=false,stopped=false;
                Diag.EventRaw("job_choices",(job.options==null?"none sent (an older phone): ":"")+"order "+(ordering?"yes":"no")+", print "+(printing?"yes":"no"));
                if(ordering) {
                    try { Timed("Ship Via SHOP",delegate { OrderWindowBack("Ship Via SHOP");shop=SetShipViaShop(true); }); }
                    catch(InvalidOperationException e) { Say("Ship Via SHOP not entered ("+e.Message+"). Enter it by hand."); }
                    try { Timed("Repair Date today",delegate { OrderWindowBack("Repair Date today");today=RepairDateToday(); }); }
                    catch(InvalidOperationException e) { Say("Repair Date not set to today ("+e.Message+"). Check it by hand."); }
                } else { Say("Not ordered (as chosen on the phone): Ship Via, Customer Waiting and Repair Date left as COSTAR made them.");JobNotes.Add("Not ordered (as chosen on the phone)."); }
                // Only for the report: a window COSTAR opened meanwhile must not stop a job that is in.
                try { Dump("after-controls",Current()); } catch(Exception) { }
                if(printing) {
                    if(cp.print=="done"||cp.print=="started") {
                        string note=cp.print=="done"?"Job Card printed earlier.":"The Job Card may have printed already (the helper stopped while printing it): check the printer.";
                        Say(note);JobNotes.Add(note);
                    } else {
                        string number=ShownNumber();
                        Diag.EventRaw("ro_number",number==null?"not read beside the RepairOrder label":"read");
                        var print=PrintJobCard(number,delegate { cp.print="started";persist(cp); });
                        // Printed, or may have: never printed again for this job (a Retry says so instead).
                        if(print.Printed||(print.Maybe&&cp.print==null)) { cp.print=print.Printed?"done":"started";try { persist(cp); } catch(Exception) { } }
                        stopped=print.Stopped;
                        JobNotes.Add(print.Words);
                    }
                }
                if(ordering) {
                    // Last: COSTAR may print a picking slip once it's ticked. A Stop here (or during the print)
                    // leaves it to do by hand.
                    if(stopped) Say("Customer Waiting not ticked (stopped). Tick it by hand.");
                    else try { Timed("Customer Waiting",delegate { OrderWindowBack("Customer Waiting");waiting=TickCustomerWaiting(); }); }
                    catch(OperationCanceledException) { Say("Customer Waiting not ticked (stopped). Tick it by hand."); }
                    catch(Exception e) { Say("Customer Waiting not ticked ("+e.Message+"). Tick it by hand."); }
                    JobNotes.Add(OrderNote(shop,today,waiting));
                }
                Say("READY FOR REVIEW — mobile job entered; COSTAR prices retained.");
                if(Checks.Count>0) Say("CHECK BY HAND before saving: "+String.Join(" ",Checks.ToArray()));
                // After a Stop, COSTAR is left as it is (the print form may be open).
                if(!stopped) Activate();
                Diag.EndStage(true);Diag.Completed();
            } catch(Exception e) {
                Diag.Stopped(e);Say("STOPPED: "+e.Message);
                try{System.IO.File.WriteAllText(System.IO.Path.Combine(Folder,"mobile-checkpoint.json"),Wire.Json(cp));}catch{}
                try{CaptureForegroundWindow(e.Message);Dump("stopped-controls",Snapshot(root));}catch{}throw;
            }
        }
        // 2.6.11: the Repair Order back in front for an ordered part (Ship Via SHOP, Customer Waiting), after a
        // print that someone at the PC held back (29 Oct 11:34: the person had clicked COSTAR's main window, so
        // Customer Waiting stopped with "lost focus" and was left to do by hand). Waits for a quiet moment (nobody
        // at the PC for OrderQuietMs) for up to OrderBackMs, then brings the Repair Order forward; stops with why
        // when it can't (the part is then said to be done by hand, as before).
        internal const int OrderBackMs=20000,OrderQuietMs=3000;
        void OrderWindowBack(string label) {
            var timer=Stopwatch.StartNew();int brought=0;
            while(true) {
                Check(false);
                if(Native.GetForegroundWindow()==root&&Native.IsWindowEnabled(root)) { if(brought>0) Diag.EventRaw("order_window_back",label+": back in front after "+timer.ElapsedMilliseconds+" ms, "+brought+" time(s) brought forward"); return; }
                Order.Require(timer.ElapsedMilliseconds<OrderBackMs,"the Repair Order isn't in front"+(Native.UserActiveWithin(OrderQuietMs)?" and someone is using the PC":"")+(Native.IsWindowEnabled(root)?"":"; COSTAR has a window open over it"));
                // Brought forward a few times at most (as focus recoveries are), with a quiet PC and nothing of
                // COSTAR's open over it.
                if(brought<5&&!Native.UserActiveWithin(OrderQuietMs)&&Native.IsWindowEnabled(root)) { brought++;Native.BringToFront(root);Pause(300); }
                else Pause(200);
            }
        }
        // 2.6.2: what the phone job's choices came to, said with READY FOR REVIEW (phone and desk).
        internal readonly List<string> JobNotes=new List<string>();
        internal static string OrderNote(bool shop,bool today,bool waiting) {
            if(shop&&today&&waiting) return "Ordered: Ship Via SHOP, Customer Waiting ticked, Repair Date today.";
            var done=new List<string>();var hand=new List<string>();
            (shop?done:hand).Add("Ship Via SHOP");(waiting?done:hand).Add("Customer Waiting");(today?done:hand).Add("Repair Date today");
            return done.Count==0?"Not ordered: do Ship Via SHOP, Customer Waiting and Repair Date today by hand.":"Ordered in part ("+String.Join(", ",done.ToArray())+"); by hand: "+String.Join(", ",hand.ToArray())+".";
        }
        // 2.6.2 (Tommy: "make sure date is today"): a new Repair Order's Repair Date normally is today; typed
        // in the box's own format when it isn't and the box takes typing. True when it is today.
        bool RepairDateToday() {
            string kind;var s=Current();var box=RoSelectors.DateIn(s,out kind);
            if(box==null) {
                // 2.6.9 (29 Oct 11:34, the first phone job with the choices: "box not found"): COSTAR's own date
                // box (RoSelectors.DatePanel), read only; a new Repair Order's is today unless COSTAR says otherwise.
                var panel=RoSelectors.DatePanel(s);
                if(panel==null) { Say("Repair Date box not found: make sure it is today.");Diag.EventRaw("repair_date","box not found");return false; }
                DateTime shown;string how;
                if(!ReadCostarDate(new IntPtr(panel.Handle),out shown,out how)) { Say("Repair Date couldn't be read: make sure it is today.");Diag.EventRaw("repair_date","not read: "+how);return false; }
                if(shown.Date==DateTime.Today) { Say("Repair Date is today.");Diag.EventRaw("repair_date","today ("+how+")");return true; }
                Say("Repair Date isn't today ("+shown.ToString("dd MMM yyyy",CultureInfo.InvariantCulture)+"): set it to today by hand.");Diag.EventRaw("repair_date","not today ("+how+")");return false;
            }
            string now;DateTime have;string format;
            if(!Native.TryText(new IntPtr(box.Handle),out now)) now="";
            now=Order.Clean(now);
            if(RoRead.ParseDate(now,out have,out format)&&have.Date==DateTime.Today) { Say("Repair Date is today ("+now+").");Diag.EventRaw("repair_date","today");return true; }
            if(kind!="edit"&&kind!="combo") { Say("Repair Date isn't today and can't be typed into here: set it to today by hand.");Diag.EventRaw("repair_date","not today ("+kind+")");return false; }
            RoDateIn(DateTime.Today.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture));
            Diag.EventRaw("repair_date","typed");Say("Repair Date set to today.");return true;
        }
        // 2.6.9: the date COSTAR's own date box shows: its accessibility value first (the 28 Oct maps: a combo box
        // whose value is the shown date, 11 letters like the Work-in-Progress list's "29 Oct 2026"), then its
        // window text. Read only; COSTAR answering first. how: where it was read (or why not).
        bool ReadCostarDate(IntPtr h,out DateTime date,out string how) {
            date=DateTime.MinValue;how="neither its accessibility value nor its text reads as a date";
            WaitIdle(2000);Check(true);
            var values=AccessibleValues(h,2000);
            if(values==null) how="its accessibility didn't answer";
            else foreach(string v in values) if(RoSelectors.CostarDate(v,out date)) { how="accessibility value";return true; }
            string text;
            if(Native.TryText(h,out text)&&RoSelectors.CostarDate(text,out date)) { how="window text";return true; }
            date=DateTime.MinValue;return false;
        }
        // 2.6.9: a COSTAR box's accessibility value, and its first child's when its own isn't a date, read on a thread
        // of its own: an accessibility call into a COSTAR that has stopped answering would wait for ever, so the run
        // waits at most ms for it (Stop still works meanwhile). Null when not read in time.
        string[] AccessibleValues(IntPtr h,int ms) {
            var values=new string[2];var done=new ManualResetEvent(false);bool answered=false;
            var th=new Thread(delegate() {
                Accessibility.IAccessible a=null,inner=null;
                try {
                    a=Msaa.FromWindow(h);values[0]=a.get_accValue(0);DateTime unused;
                    if(!RoSelectors.CostarDate(values[0],out unused)) { inner=Msaa.Count(a)>0?Msaa.Child(a,1):null;if(inner!=null) values[1]=inner.get_accValue(0); }
                    answered=true;
                } catch(Exception) { }
                finally { Msaa.Release(inner);Msaa.Release(a);done.Set(); }
            });
            th.IsBackground=true;
            try { th.SetApartmentState(ApartmentState.MTA); } catch(PlatformNotSupportedException) { }   // the self-tests' runtime
            th.Start();
            var timer=Stopwatch.StartNew();
            while(!done.WaitOne(25)) { Check(false);if(timer.ElapsedMilliseconds>=ms) { Diag.EventRaw("repair_date","its accessibility didn't answer within "+ms+" ms");return null; } }
            return answered?values:null;
        }
        internal void CloseMobile(MobileJob job,MobileCheckpoint cp) {
            Diag.Kind="mobile-close";ActivateAndWait();Check(true);var h=Selectors.Header(Current());
            var live=new MobileView {account=h.Account.Value,name=h.Name.Value,phone=h.Phone.Value,reference=h.PO.Value};
            Order.Require(MobileProof.CanClose(job,cp,live),"The open order belongs to another customer/reference. Close it manually if appropriate.");
            UIntPtr result;Native.WriteMessage(root,0x10,UIntPtr.Zero,null,3,1000,out result);
            var timer=Stopwatch.StartNew();while(timer.ElapsedMilliseconds<5000){if(!Native.IsWindow(root)){Diag.Completed();return;}Thread.Sleep(100);}
            throw new InvalidOperationException("COSTAR did not close the reviewed order. Resolve its prompt manually, then resume the RDP worker. No confirmation was accepted.");
        }
    }
}
