// The RDP helper's Wholesale tab (2.9.0, stage 1 of the wholesale orders: a dry run). A button runs the dry run
// (WholesaleRun: nothing typed, sold or changed); Stop stops it; the list shows each BUF order of COSTAR Sydney's
// "Orders yet to be filled" and what the helper would do with it; picking one shows its lines as read.
using System;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed partial class WorkerForm {
        readonly TabPage wholesalePage=new TabPage("Wholesale");
        readonly Label wholesaleLine=Ui.Text("",820),wholesaleDetail=Ui.Hint("",820);
        readonly Button wholesaleStart=Ui.PrimaryButton("Check wholesale orders (dry run)",290),wholesaleStop=Ui.DangerButton("Stop",100);
        readonly ListView wholesaleList=new ListView {View=View.Details,FullRowSelect=true,HideSelection=false,Font=Ui.Base,MultiSelect=false,Dock=DockStyle.Fill};
        readonly RichTextBox wholesaleLog=Ui.Log();
        readonly BoundedLog wholesaleMessages=new BoundedLog();
        volatile WholesaleRun wholesale;string wholesaleShown="";
        void WholesaleAppend(string text){wholesaleMessages.Add(text);}
        void BuildWholesalePage() {
            wholesalePage.BackColor=Ui.Canvas;wholesalePage.Padding=new Padding(0);
            var layout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=5,Padding=new Padding(12),BackColor=Ui.Canvas};
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent,60));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,40));
            var card=Ui.Card();card.Dock=DockStyle.Top;
            var lines=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Surface};
            lines.Controls.Add(Ui.Title("Wholesale orders in COSTAR Sydney: dry run (stage 1)"));
            lines.Controls.Add(Ui.Hint("Opens each BUF order on \"Orders yet to be filled\" whose Comment is empty, WWW, BUF, BUFF or BUFFALO (or WWW with one of those) and whose ShipDate isn't after today, oldest first; presses OK on the customer's Notes and a Point-of-sale Memo; reads its Comment, Terms, the Notes (card details: yes or no only) and its lines; "+
                "when those are fine, clicks each tyre line open (one click into its words) to read Sydney's stock (ThisBr = Avail: more than 4 is enough; NON-STOCKING is short), then reads the order again and closes it as it was (if anything changed, it's left open for you). "+
                "It shows what it WOULD do: sell (Sell, then Cancel), add CHECK STOCK or NO CARD DETAILS to the Comment, or leave it. Nothing is typed, sold or changed. "+
                "COSTAR Sydney comes to the front: leave the PC alone until it's done (it stops if the PC is used). eBay orders wait meanwhile; COSTAR Sydney goes back to Repair Order at the end.",820));
            lines.Controls.Add(wholesaleLine);
            card.Controls.Add(lines);
            var buttons=Ui.Row();buttons.Margin=new Padding(0,10,0,6);buttons.Controls.Add(wholesaleStart);buttons.Controls.Add(wholesaleStop);
            foreach(var c in new[]{new ColumnHeader {Text="Order",Width=100},new ColumnHeader {Text="Ordered",Width=90},new ColumnHeader {Text="Ship date",Width=90},new ColumnHeader {Text="Ship Via",Width=80},
                new ColumnHeader {Text="Comment",Width=120},new ColumnHeader {Text="Customer",Width=160},new ColumnHeader {Text="Terms",Width=70},new ColumnHeader {Text="What it would do",Width=700}}) wholesaleList.Columns.Add(c);
            wholesaleDetail.Margin=new Padding(0,6,0,6);
            layout.Controls.Add(card,0,0);layout.Controls.Add(buttons,0,1);layout.Controls.Add(wholesaleList,0,2);layout.Controls.Add(wholesaleDetail,0,3);layout.Controls.Add(wholesaleLog,0,4);
            wholesalePage.Controls.Add(layout);
            wholesaleStart.Click+=delegate{DeskForm.Attempt(StartWholesale);};
            wholesaleStop.Click+=delegate{var run=wholesale;if(run!=null&&run.Running){run.Cancel=true;WholesaleAppend("Stopping the dry run ...");}};
            wholesaleList.SelectedIndexChanged+=delegate{ShowWholesaleOrder();};
            wholesaleStop.Enabled=false;
            Ui.SetText(wholesaleLine,"Not run yet.");
        }
        void StartWholesale() {
            var last=wholesale;
            Order.Require(last==null||!last.Running,"The dry run is already running.");
            Order.Require(!coordinator.Busy,(coordinator.Owner.Length>0?coordinator.Owner:"An entry")+" is using COSTAR: wait for it to finish.");
            var run=new WholesaleRun(coordinator,WholesaleAppend);wholesale=run;wholesaleShown="";
            AppLog.Note("wholesale_dry_run_start","");
            var thread=new Thread(delegate() { run.Run();WholesaleAppend(run.Summary); });
            thread.IsBackground=true;thread.Start();
            UpdateStatus();
        }
        void StopWholesale() { var run=wholesale;if(run!=null&&run.Running) run.Cancel=true; }
        void UpdateWholesaleTab() {
            Ui.AppendColoured(wholesaleLog,wholesaleMessages.Drain());
            var run=wholesale;bool running=run!=null&&run.Running;
            wholesaleStart.Enabled=!running&&!coordinator.Busy;wholesaleStop.Enabled=running;
            if(run==null) return;
            Ui.SetText(wholesaleLine,running?"Running: "+run.Count()+" so far.":run.Summary);
            var looks=run.Looks;
            string key=looks.Count+"|"+String.Join(",",looks.Select(l=>(l.Opened?"o":"")+(l.Verdict==null?"":l.Verdict.Action)+(l.Skip==null?"":"s")+(l.Changed==null?"":"c")+(l.LeftOpen==null?"":"l")).ToArray());
            if(key==wholesaleShown) return;
            wholesaleShown=key;
            string selected=wholesaleList.SelectedItems.Count>0?wholesaleList.SelectedItems[0].Text:null;
            wholesaleList.BeginUpdate();
            try {
                wholesaleList.Items.Clear();
                foreach(var l in looks) {
                    var r=l.Row;var v=l.Verdict;
                    string result=l.Skip!=null?"Not opened: "+l.Skip:v!=null?WholesaleRules.Plain(v)+(l.LeftOpen!=null?" (left open in COSTAR: "+l.LeftOpen+")":"")
                        :l.LeftOpen!=null?"Left open in COSTAR: "+l.LeftOpen:l.Opened?"Reading ...":"To open";
                    var item=new ListViewItem(new[]{r.Doc,r.OrderDate,r.ShipDate,r.ShipVia,r.Comment,r.Name,v!=null?l.Terms??"(unread)":"",result}) {Tag=l};
                    if(v!=null) item.ForeColor=v.Action=="sell"?Color.FromArgb(21,128,61):v.Action=="comment"?Color.FromArgb(180,83,9):v.Action=="stock"?Color.FromArgb(29,78,216):Color.FromArgb(185,28,28);
                    else if(l.Skip!=null) item.ForeColor=Ui.Muted;
                    wholesaleList.Items.Add(item);
                    if(selected!=null&&r.Doc==selected) item.Selected=true;
                }
            } finally { wholesaleList.EndUpdate(); }
        }
        // The picked order: its lines as read (a tyre or not, quantities), its notices, card details yes/no.
        void ShowWholesaleOrder() {
            var item=wholesaleList.SelectedItems.Count>0?wholesaleList.SelectedItems[0]:null;var l=item==null?null:item.Tag as WholesaleLook;
            if(l==null) { Ui.SetText(wholesaleDetail,"");return; }
            string open=l.LeftOpen!=null?" Left open in COSTAR: "+l.LeftOpen+(l.ChangedValues!=null?" ("+l.ChangedValues+")":"")+".":"";
            if(l.Verdict==null) { Ui.SetText(wholesaleDetail,"Order "+l.Row.Doc+": "+(l.Skip!=null?"not opened ("+l.Skip+").":l.LeftOpen!=null?"not read through."+open:"not read yet."));return; }
            var lines=l.Lines.Select(x=>"line "+x.Number+" "+x.Item+(x.Note?" (note)":x.Tyre?" TYRE "+x.Size+(x.NonStocking||x.Available!=null||x.StockWhy!=null?" ("+WholesaleRules.StockWords(l,x)+")":""):" (not a tyre)")+(x.Note?"":" order qty "+x.OrderQty+(x.BackOrder.Length>0?", back order "+x.BackOrder:"")+(x.ShipQty.Length>0?", ship "+x.ShipQty:""))).ToArray();
            string card=l.Card==true?"yes":l.Card==false?"no":"can't tell";
            Ui.SetText(wholesaleDetail,"Order "+l.Row.Doc+": Terms "+(l.Terms??"(unread)")+"; Comment \""+(l.OrderComment??"(unread)")+"\"; card details in the Notes: "+card+(l.NotesShown?"":" (no Notes popped up"+(l.Card==null?"; it may have notes: check them by hand)":")"))+
                (l.Memos.Count>0?"; "+String.Join("; ",l.Memos.ToArray()):"")+". "+(lines.Length>0?String.Join("; ",lines):"No lines read")+"."+open);
        }
    }
}
