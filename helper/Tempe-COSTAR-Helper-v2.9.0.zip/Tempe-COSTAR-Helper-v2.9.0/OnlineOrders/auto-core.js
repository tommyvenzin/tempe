/* Auto (helper 2.8.1): which orders the Tempe Orders page sends to the helper by itself. Pure; shared by the page and its tests. */
(function (scope) {
    'use strict';
    // Sydney's date ("YYYYMMDD", as the page's pickup keys), weekday (0 = Sunday) and minutes past midnight.
    function sydneyParts(date) {
        const parts = new Intl.DateTimeFormat('en-AU', { timeZone: 'Australia/Sydney', weekday: 'short', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(date);
        const get = type => (parts.find(p => p.type === type) || {}).value || '';
        const days = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
        const hour = Number(get('hour')) % 24;
        return { key: get('year') + get('month') + get('day'), weekday: days[get('weekday').slice(0, 3)], minutes: hour * 60 + Number(get('minute')) };
    }
    // Shop hours, as the helper's (Order Check reads COSTAR then), Sydney time. Tempe Tyres is open Mon-Fri 8:00-17:00,
    // Sat 8:00-16:00, Sun 9:00-14:00 (Tommy, 3 Nov); Auto works from an hour before opening to an hour and a half after
    // closing: Mon-Fri 7:00-18:30, Sat 7:00-17:30, Sun 8:00-15:30.
    function shopWindow(weekday) { return weekday === 0 ? [8 * 60, 15 * 60 + 30] : weekday === 6 ? [7 * 60, 17 * 60 + 30] : [7 * 60, 18 * 60 + 30]; }
    function inShopHours(date) {
        const p = sydneyParts(date), w = shopWindow(p.weekday);
        return p.minutes >= w[0] && p.minutes <= w[1];
    }
    function addDays(key, n) {
        const d = new Date(Date.UTC(Number(key.slice(0, 4)), Number(key.slice(4, 6)) - 1, Number(key.slice(6, 8)) + n));
        return d.getUTCFullYear() + String(d.getUTCMonth() + 1).padStart(2, '0') + String(d.getUTCDate()).padStart(2, '0');
    }
    // The pickup days Auto looks at: today and tomorrow (open 7 days), as the helper's Customer Waiting rule (today
    // 14:00-16:00, tomorrow 08:00-09:00).
    function autoDays(date) {
        const today = sydneyParts(date).key;
        return [today, addDays(today, 1)];
    }
    // A delivery method that names a delivery, whatever the website calls it (a pickup is collected in store).
    const DELIVERY_WORDS = /AUSTRALIA|DELIVER|PARTNER|FREIGHT|COURIER|POSTAGE|SHIPPING|EBAY/i;
    // Tempe pickups (Tommy, 3 Nov: "Tempe pickups only") for those days, from the page's order list.
    function autoCandidates(orders, days) {
        return (orders || []).filter(o => o && /^TTW\d+$/.test(o.orderId || '') && /\bTempe\b/i.test(o.store || '') && days.indexOf(o.pickupDateKey) >= 0 && !DELIVERY_WORDS.test(o.deliveryMethod || ''));
    }
    // An order against Order Check's read of COSTAR's Work-in-Progress list (and the helper's own entered list): "in"
    // (its number is a job's PO#, or in a job's comment, or the helper entered it, or it was on a job that has left
    // Work-in-Progress since: invoiced or deleted), "maybe" (a job with the same amount, within 2% or $1, that isn't
    // another online order), else "missing". The helper checks the same before typing (and, for "maybe", that the job
    // is the same customer's or a walk-in's: the page's list has no names).
    function costarMatch(order, rows, entered, left) {
        const id = String(order.orderId || "").toUpperCase();
        const digits = id.replace(/^TTW/, "");
        const numberInText = new RegExp("(^|[^0-9])(TTW)?" + digits + "([^0-9]|$)", "i");
        const byPo = rows.find(r => String(r.po || "").trim().toUpperCase() === id);
        if (byPo) return { kind: "in", doc: byPo.doc, how: "PO#" };
        const byComment = /^\d{5,}$/.test(digits) ? rows.find(r => numberInText.test(String(r.comment || ""))) : null;
        if (byComment) return { kind: "in", doc: byComment.doc, how: "comment" };
        const mine = entered && entered.get(id);
        if (mine) return { kind: "in", doc: "", how: "helper", at: mine };
        const gone = (left || []).find(g => g && (" " + String(g.ttw || "").toUpperCase() + " ").includes(" " + id + " "));
        if (gone) return { kind: "in", doc: gone.doc, how: "left" };
        const amount = Number(order.amountNumber);
        if (Number.isFinite(amount) && amount > 0) {
            const same = rows.filter(r => r.hasTotal !== false && !/^TTW\d+$/i.test(String(r.po || "").trim()) && Math.abs(Number(r.total) - amount) <= Math.max(1, amount * 0.02));
            if (same.length) return { kind: "maybe", doc: same.map(r => r.doc).join(", "), how: same.length === 1 ? "same amount" : same.length + " jobs with the same amount" };
        }
        return { kind: "missing" };
    }
    // What a round does with each candidate: COSTAR's check ("in", "maybe", "missing"; "sent": sent from this page by
    // hand) and the helper's record (its state, or none). Sent: missing, or "maybe" (a job with the same amount: the
    // helper decides on its own read, with the customer's name, and holds it for a person if it's that customer's or a
    // walk-in's), and unknown to the helper. The helper is asked about those only.
    function autoPlan(candidates, costar, helper) {
        const send = [], known = [];
        for (const o of candidates) {
            const c = costar[o.orderId] || { kind: 'missing' };
            if (c.kind !== 'missing' && c.kind !== 'maybe') continue;
            if (helper && helper[o.orderId]) known.push(o.orderId); else send.push(o);
        }
        return { send, known };
    }
    // How the page shows the helper's record of an order (null: nothing to show). make: the page offers Make it.
    function helperView(record) {
        if (!record || !record.state) return null;
        const at = record.at ? ' ' + record.at : '';
        switch (record.state) {
            case 'waiting': return { kind: 'sent', text: 'Waiting in the helper' + at };
            case 'entering': return { kind: 'sent', text: 'Being entered by the helper' + at };
            case 'entered': return { kind: 'in', text: 'Entered by the helper' + at + (/left open/i.test(record.message || '') ? ': ' + record.message : '') };
            case 'in_costar': return { kind: 'in', text: 'Already in COSTAR (the helper checked)' + at };
            case 'by_hand': return { kind: 'sent', make: true, text: 'Sent by hand: the Online orders tab has it' + at };
            case 'held': return { kind: 'maybe', make: true, text: 'Held for you by the helper' + at + ': ' + (record.message || 'a job with the same amount is in COSTAR') };
            case 'stopped': return { kind: 'stopped', make: true, text: 'Stopped in the helper' + at + ': ' + (record.message || 'check COSTAR') };
            default: return null;
        }
    }
    // Make it / Make all missing: never for an order the helper has or entered (a stopped, held or by-hand one is a
    // person's call).
    function helperHasIt(record) {
        return !!(record && record.state && record.state !== 'stopped' && record.state !== 'held' && record.state !== 'by_hand');
    }
    // The helper this page is paired with, among the Order Checks answering on this PC (an RDP server can run several,
    // one per Windows session): the one whose /health names the pairing. Pairing: the ones showing a code.
    function pairedHelper(checks, pair) {
        return pair ? (checks || []).find(c => c && c.health && c.health.autoPair === pair) || null : null;
    }
    function pairingHelpers(checks) {
        return (checks || []).filter(c => c && c.health && c.health.autoPairing === true);
    }
    // What the page keeps of a pairing (localStorage): the key and the pairing's id; anything else is no pairing.
    function readPairing(text) {
        try {
            const p = JSON.parse(text || '');
            return p && typeof p.key === 'string' && p.key && typeof p.pair === 'string' && p.pair ? { key: p.key, pair: p.pair } : null;
        } catch (e) { return null; }
    }
    const api = { sydneyParts, inShopHours, addDays, autoDays, autoCandidates, costarMatch, autoPlan, helperView, helperHasIt, pairedHelper, pairingHelpers, readPairing };
    scope.TempeAuto = api;
    if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window === 'undefined' ? globalThis : window);
