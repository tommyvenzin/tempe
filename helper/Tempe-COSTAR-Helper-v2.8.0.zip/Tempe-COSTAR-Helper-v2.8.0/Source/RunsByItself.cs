// 2.8.0 "Runs by itself": the windows' side (the rules are in Unattended.cs). RDP helper: Start with Windows, mobile
// back on at start, updates outside shop hours, Discord alerts, Import connection. Desk PC: Start with Windows,
// updates outside shop hours, one retry of a job that stopped before anything was typed, and a tray message when
// the RDP helper is out of touch.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed partial class WorkerForm {
        WorkerSettings connection;string workerFolder;
        readonly CheckBox autoStartBox=Ui.Check("Start this helper when you sign in to Windows",false),
            resumeBox=Ui.Check("Turn mobile back on by itself when the helper starts (if it was on, and the last job ended cleanly)",true),
            autoUpdateBox=Ui.Check("Install updates by themselves outside shop hours (nothing being entered, nobody using this PC)",true),
            closeCleanBox=Ui.Check("Close online orders that need no checking (they stay in Work-in-Progress)",true);
        readonly Label alertsLine=Ui.Text("",800);
        DateTime shownAt=DateTime.MaxValue,lastAutoUpdate=DateTime.MinValue,noCostarSince=DateTime.MinValue;
        bool deskDownSaid,noCostarSaid;int runsTicks;

        // Called from the constructor (before the tabs are built).
        void RunsByItselfSetup(WorkerSettings settings,string folder) {
            connection=settings;workerFolder=folder;
            Alerts.Load(folder);
        }
        // The Runs by itself card, under the settings on Files & settings.
        Control RunsByItselfCard() {
            var card=Ui.Card();card.Dock=DockStyle.Top;
            var f=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Surface};
            f.Controls.Add(Ui.Title("Runs by itself"));
            string mode=Updater.LaunchMode;
            autoStartBox.Checked=AutoStart.On(mode);
            autoStartBox.CheckedChanged+=delegate {
                if(syncingRuns) return;
                try { AutoStart.Set(mode,autoStartBox.Checked);Append(autoStartBox.Checked?"This helper now starts when you sign in to Windows (Startup folder: "+Path.GetFileName(AutoStart.FileFor(mode))+").":"This helper no longer starts with Windows."); }
                catch(Exception e) { Append("Start with Windows: "+e.Message);syncingRuns=true;try{autoStartBox.Checked=AutoStart.On(mode);}finally{syncingRuns=false;} }
            };
            resumeBox.Checked=AppSettings.Current.resumeMobile;
            resumeBox.CheckedChanged+=delegate{AppSettings.Current.resumeMobile=resumeBox.Checked;AppSettings.Current.Save();AppLog.Note("setting_resume_mobile",resumeBox.Checked?"on":"off");};
            autoUpdateBox.Checked=AppSettings.Current.autoUpdate;
            autoUpdateBox.CheckedChanged+=delegate{AppSettings.Current.autoUpdate=autoUpdateBox.Checked;AppSettings.Current.Save();AppLog.Note("setting_auto_update",autoUpdateBox.Checked?"on":"off");};
            closeCleanBox.Checked=AppSettings.Current.onlineCloseClean;
            closeCleanBox.CheckedChanged+=delegate{AppSettings.Current.onlineCloseClean=closeCleanBox.Checked;AppSettings.Current.Save();AppLog.Note("setting_online_close",closeCleanBox.Checked?"on":"off");Append(closeCleanBox.Checked?"Online orders that need no checking are closed once they are in (they stay in Work-in-Progress).":"Online orders are left open for review, as before 2.8.0.");};
            f.Controls.Add(autoStartBox);f.Controls.Add(resumeBox);f.Controls.Add(autoUpdateBox);f.Controls.Add(closeCleanBox);
            // Discord alerts.
            var alerts=Ui.Row();alerts.Margin=new Padding(0,8,0,0);
            var set=Ui.SecondaryButton("Set Discord alerts...",190);set.Click+=delegate{DeskForm.Attempt(SetDiscordAlerts);};
            var test=Ui.SecondaryButton("Send a test",130);test.Click+=delegate{DeskForm.Attempt(TestDiscordAlerts);};
            var off=Ui.SecondaryButton("Turn alerts off",150);off.Click+=delegate{DeskForm.Attempt(delegate{Alerts.Remove();Append("Discord alerts are off (the webhook was removed from this PC).");ShowAlertsLine();});};
            alerts.Controls.Add(set);alerts.Controls.Add(test);alerts.Controls.Add(off);
            f.Controls.Add(alertsLine);f.Controls.Add(alerts);
            // The desk PC connection.
            var conn=Ui.Row();conn.Margin=new Padding(0,8,0,0);
            var import=Ui.PrimaryButton("Import connection...",200);import.Click+=delegate{DeskForm.Attempt(ImportConnection);};
            conn.Controls.Add(import);
            f.Controls.Add(conn);
            f.Controls.Add(Ui.Hint("Import connection: after Setup-Desk.cmd was run on the desk PC (it makes a new certificate), click Export RDP connection there, copy worker-connection.json to this PC, and pick it here. No restart needed.",800));
            ShowAlertsLine();
            card.Controls.Add(f);
            return card;
        }
        bool syncingRuns;
        void ShowAlertsLine() { Ui.SetText(alertsLine,Alerts.On?"Discord alerts: on. A message goes to your channel when a job stops, the desk PC can't be reached for 5 minutes, or no COSTAR is selected.":"Discord alerts: off. Paste your channel's webhook with Set Discord alerts (it stays on this PC, encrypted)."); }
        void SetDiscordAlerts() {
            using(var dialog=new Form {Text="Discord alerts",FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false,MinimizeBox=false,StartPosition=FormStartPosition.CenterParent,ClientSize=new Size(620,190),Font=Font,ShowInTaskbar=false}) {
                var note=new Label {AutoSize=false,Location=new Point(14,12),Size=new Size(590,58),Text="In Discord: the channel's settings, Integrations, Webhooks, New Webhook, Copy Webhook URL. Paste it here. It is kept on this PC only (encrypted) and never shown again."};
                var box=new TextBox {Location=new Point(14,78),Width=590,UseSystemPasswordChar=true};
                var ok=new Button {Text="Save",Location=new Point(424,128),Size=new Size(85,36),DialogResult=DialogResult.OK};
                var cancel=new Button {Text="Cancel",Location=new Point(519,128),Size=new Size(85,36),DialogResult=DialogResult.Cancel};
                dialog.Controls.Add(note);dialog.Controls.Add(box);dialog.Controls.Add(ok);dialog.Controls.Add(cancel);dialog.AcceptButton=ok;dialog.CancelButton=cancel;
                if(dialog.ShowDialog(this)!=DialogResult.OK) return;
                Alerts.Save(box.Text);box.Text="";
            }
            Append("Discord alerts are on.");ShowAlertsLine();
            if(MessageBox.Show(this,"Send a test message to the channel now?","Discord alerts",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes) TestDiscordAlerts();
        }
        void TestDiscordAlerts() {
            Order.Require(Alerts.On,"Discord alerts are off: Set Discord alerts first.");
            Append("Sending a test message to Discord ...");
            ThreadPool.QueueUserWorkItem(delegate {
                string error=Alerts.Test();
                try { BeginInvoke(new Action(delegate{Append(error==null?"Test message sent: check the Discord channel.":"The test message didn't go: "+error+".");})); } catch(InvalidOperationException) { }
            });
        }
        // 2.8.0 (2 Nov: Setup-Desk.cmd was run again on the desk PC, so its certificate changed; the new connection
        // file then had to go into the one folder the helper reads it from, with the helper restarted): the desk's
        // worker-connection.json picked here, checked, kept encrypted, and used at once.
        void ImportConnection() {
            string file;
            using(var pick=new OpenFileDialog {Title="The desk PC's worker-connection.json (Export RDP connection)",Filter="Connection file (worker-connection*.json)|worker-connection*.json|JSON files (*.json)|*.json",InitialDirectory=Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)}) {
                if(pick.ShowDialog(this)!=DialogResult.OK) return;
                file=pick.FileName;
            }
            var c=Wire.Read<WorkerSettings>(File.ReadAllText(file));
            NetworkRules.Worker(c);
            PrivateFiles.Save(Path.Combine(workerFolder,"settings.dat"),c);
            // Copies the launcher would import again at the next start (an older one there would undo this).
            foreach(string old in new[]{Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"worker-connection.json"),AutoStart.PackageFolder()==null?null:Path.Combine(AutoStart.PackageFolder(),"worker-connection.json")}) {
                try { if(old!=null&&File.Exists(old)&&!String.Equals(Path.GetFullPath(old),Path.GetFullPath(file),StringComparison.OrdinalIgnoreCase)) { File.Delete(old);Append("Removed an older copy of the connection file: "+old); } } catch(Exception e) { Append("Couldn't remove "+old+": "+e.Message); }
            }
            Uri u=new Uri(c.baseUrl);
            AppLog.Note("connection_imported",u.Host+":"+u.Port);
            if(connection!=null) {
                connection.baseUrl=c.baseUrl;connection.token=c.token;connection.workerId=c.workerId;connection.certificateHash=c.certificateHash;
                if(engine!=null) engine.Reconnect();if(ebay!=null) ebay.Reconnect();if(ro!=null) ro.Reconnect();
                Append("Connection imported (desk PC "+u.Host+"). Connecting now.");
            } else Append("Connection imported (desk PC "+u.Host+"). Close this helper and start it again to connect.");
            if(MessageBox.Show(this,"Connection imported.\r\n\r\nThe file holds the private pairing key. Delete it now?\r\n\r\n"+file,"Import connection",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes) {
                try { File.Delete(file);Append("Deleted "+file+"."); } catch(Exception e) { Append("Couldn't delete it: "+e.Message); }
            }
        }
        // Remembers whether mobile is on: a person's Start, or Stop all (the button or Ctrl+Alt+F10). A stop by an error,
        // by closing the helper or by Windows shutting down isn't one: mobile comes back on after those.
        void RememberMobile(bool on) {
            var s=AppSettings.Current;var selected=coordinator.Selected;
            s.mobileOn=on;if(on&&selected!=null) s.mobileBranch=selected.Branch;
            s.Save();
        }
        void RunsByItselfShown() {
            shownAt=DateTime.Now;nextResume=shownAt.AddSeconds(20);
            AutoStart.Refresh(Updater.LaunchMode);
            // An update that installed itself says it is running (silence after "updating itself" then means it didn't).
            var s=AppSettings.Current;
            if(!String.IsNullOrEmpty(s.autoUpdateTried)&&Updater.Parse(s.autoUpdateTried)==Updater.Current) {
                AppLog.Note("update_auto_running",s.autoUpdateTried);
                Alerts.Raise("update_done","The RDP helper updated itself to "+s.autoUpdateTried+" and is running","");
                s.autoUpdateTried="";s.Save();
            }
        }
        // Every second from the window's timer.
        void RunsByItselfTick() {
            var now=DateTime.Now;
            // Mobile back on by itself: 20 s after the window opened (COSTAR found, the desk reached), then every 30 s
            // while it can't yet (e.g. started with Windows before COSTAR was opened).
            if(!resumeDone&&now>=nextResume) { nextResume=now.AddSeconds(30);ResumeMobile(now); }
            if(++runsTicks%5==0) Alerts.Tick();
            if(runsTicks%30!=0) return;
            WatchForAlerts(now);
            // No COSTAR selected: looked for again every minute (quietly), as at start.
            if(runsTicks%60==0&&coordinator.Selected==null&&!coordinator.Busy&&!targets.DroppedDown) RefreshTargets(true);
            // Not while anything is being entered or waits: an online order loaded or waiting in the tab (a restart would
            // drop it), a phone job stopped part way (after a restart mobile wouldn't come back on), or a stop that typed
            // nothing in the last 3 minutes (the desk PC retries it).
            bool busy=coordinator.Busy||(online!=null&&online.HasWork)||(engine!=null&&(engine.Busy||engine.CanRelease))||(ebay!=null&&ebay.Busy)||(ro!=null&&ro.Busy)||Alerts.Waiting>0;
            bool tried=updateOffer!=null&&AppSettings.Current.autoUpdateTried==updateOffer.version;
            if(Unattended.UpdateDue(updateOffer!=null,AppSettings.Current.autoUpdate,now,busy,Native.UserActiveWithin((int)Unattended.QuietForUpdate.TotalMilliseconds),lastAutoUpdate,tried)) {
                lastAutoUpdate=now;AppLog.Note("update_auto",updateOffer.version);
                InstallUpdate(true);
            }
            // Outside shop hours, a new version is looked for every hour (in shop hours every 6 hours, as before).
            if(runsTicks%3600==0&&!TempeOrderCheck.Text.InShopHours(now)) CheckForUpdate();
        }
        DateTime nextResume=DateTime.MaxValue;bool resumeDone;string resumeWhy;
        // Done once mobile is on (by itself or a person's Start), or it isn't to come back (not wanted, off when the
        // helper closed, a person's Stop all meanwhile). Why it can't yet is said when that changes.
        void ResumeMobile(DateTime now) {
            if(engine==null||engine.Enabled) { resumeDone=true;return; }
            var s=AppSettings.Current;var selected=coordinator.Selected;
            if(selected!=null&&(OrderCheckLink.IsWipWindow(selected)||!CostarAlive(selected))) selected=null;
            bool paused=coordinator.MobilePaused;
            string why=Unattended.WhyNotResume(s.resumeMobile,s.mobileOn,engine.CanRelease,paused,selected==null?0:selected.Branch,s.mobileBranch);
            if(why==null) {
                resumeDone=true;engine.Start();AppLog.Note("mobile_resumed",selected.Label);
                Append("Mobile is back on by itself (it was on when the helper last closed): jobs go into "+selected.Label+".");UpdateStatus();
                if(mobileOffSaid) Alerts.Raise("mobile_back","Mobile is back on in the RDP helper","");
                return;
            }
            if(why.Length==0) { resumeDone=true;return; }
            if(why==resumeWhy) return;
            resumeWhy=why;resumeQuiet=paused||selected==null;resumeSince=now;mobileOffSaid=false;
            Append("Mobile isn't back on yet: "+why+". It turns itself on once that's sorted (or click Start / resume mobile).");AppLog.Note("mobile_not_resumed",why);
        }
        // resumeQuiet: the reason is said elsewhere (no COSTAR: its own alert) or a person is at it (the Online tab).
        DateTime resumeSince=DateTime.MaxValue;bool mobileOffSaid,resumeQuiet;
        // Mobile waiting to come back on by itself.
        bool ResumeWaiting { get { return !resumeDone&&engine!=null&&!engine.Enabled&&AppSettings.Current.resumeMobile&&AppSettings.Current.mobileOn; } }
        // The selected COSTAR's process is still the one picked (not closed, not another program on its number).
        static bool CostarAlive(CostarInstance c) {
            ProcessIdentity identity;
            return c!=null&&LocalProcess.IsNamed(c.Pid,"COSTAR",out identity)&&identity.Started==c.Started&&identity.Session==c.Session;
        }
        // In shop hours only: at night the desk PC may be off and COSTAR closed on purpose (what is still wrong at 7:00
        // is said 5 minutes later).
        void WatchForAlerts(DateTime now) {
            bool open=TempeOrderCheck.Text.InShopHours(now);
            if(!open) { noCostarSince=DateTime.MinValue;return; }
            bool starting=now-now.Date<TimeSpan.FromMinutes(7*60+5);   // the first 5 minutes of the day: it may be starting
            if(engine!=null) {
                int since=engine.SecondsSinceContact;
                bool down=since>300||(since<0&&now-shownAt>TimeSpan.FromMinutes(5));
                if(down&&starting) down=false;
                // Each flag is set only when Discord was told (a message held back by the limits is tried again later).
                if(down&&!deskDownSaid) deskDownSaid=Alerts.Raise("desk_down","The RDP helper can't reach the desk PC (phone jobs, eBay orders and phone Repair Orders wait)",engine.Connection);
                else if(!down&&since>=0&&since<60&&deskDownSaid&&Alerts.Raise("desk_back","The RDP helper reaches the desk PC again","")) deskDownSaid=false;
            }
            // A COSTAR selected whose program has closed counts as none (the helper never switches to another by itself).
            // Phone jobs and the phone's Repair Orders need it (eBay orders have COSTAR Sydney of their own).
            var selected=coordinator.Selected;bool usable=selected!=null&&CostarAlive(selected);
            bool wanted=(engine!=null&&(engine.Enabled||ResumeWaiting))||(ro!=null&&ro.Enabled);
            if(wanted&&!usable) {
                if(noCostarSince==DateTime.MinValue) noCostarSince=now;
                else if(now-noCostarSince>TimeSpan.FromMinutes(5)&&!noCostarSaid&&!starting)
                    noCostarSaid=Alerts.Raise("no_costar",selected==null?"No COSTAR is selected in the RDP helper (is it open?)":"The COSTAR the RDP helper uses has closed","phone jobs and phone Repair Orders wait. Open COSTAR, then pick it in the helper (Refresh COSTAR list).");
            } else {
                noCostarSince=DateTime.MinValue;
                if(noCostarSaid&&usable&&Alerts.Raise("costar_back","A COSTAR is selected in the RDP helper again","")) noCostarSaid=false;
            }
            // Mobile still off 10 minutes after it couldn't come back on for another reason (no COSTAR is said above; the
            // Online tab showing means someone is at it).
            if(ResumeWaiting&&resumeWhy!=null&&!resumeQuiet&&usable&&!mobileOffSaid&&!starting&&now-resumeSince>TimeSpan.FromMinutes(10))
                mobileOffSaid=Alerts.Raise("mobile_off","Mobile hasn't come back on in the RDP helper",resumeWhy+". Click Start / resume mobile when it's right.");
        }
    }

    internal sealed partial class DeskForm {
        readonly CheckBox deskAutoStart=Ui.Check("Start the receiver when you sign in to Windows",false),
            deskAutoUpdate=Ui.Check("Install updates by themselves outside shop hours",true);
        DateTime deskLastAutoUpdate=DateTime.MinValue;bool workerOutSaid,syncingDeskRuns;int deskTicks;
        Control DeskRunsRow() {
            var row=Ui.Row();
            deskAutoStart.Checked=AutoStart.On("Desk");
            deskAutoStart.CheckedChanged+=delegate {
                if(syncingDeskRuns) return;
                try { AutoStart.Set("Desk",deskAutoStart.Checked); }
                catch(Exception e) { MessageBox.Show(this,e.Message,"Start with Windows");syncingDeskRuns=true;try{deskAutoStart.Checked=AutoStart.On("Desk");}finally{syncingDeskRuns=false;} }
            };
            deskAutoUpdate.Checked=AppSettings.Current.autoUpdate;
            deskAutoUpdate.CheckedChanged+=delegate{AppSettings.Current.autoUpdate=deskAutoUpdate.Checked;AppSettings.Current.Save();AppLog.Note("setting_auto_update",deskAutoUpdate.Checked?"on":"off");};
            row.Controls.Add(deskAutoStart);row.Controls.Add(deskAutoUpdate);
            AutoStart.Refresh("Desk");
            return row;
        }
        // Every second from the refresh timer.
        void DeskRunsTick() {
            if(++deskTicks%10!=0) return;
            var now=DateTime.Now;
            RetryOnce(now);
            // The RDP helper out of touch for 5 minutes (it was in touch before): a tray message here (the desk has no
            // Discord link: that stays on the RDP PC).
            int since=api.SecondsSinceWorker;
            if(since>300&&!workerOutSaid) { workerOutSaid=true;tray.ShowBalloonTip(10000,"RDP helper out of touch","The RDP helper hasn't been in touch for 5 minutes: phone jobs, eBay orders and phone Repair Orders wait. Check it on the RDP PC.",ToolTipIcon.Warning);AppLog.Note("worker_out_of_touch",since+" s"); }
            else if(since>=0&&since<60&&workerOutSaid) workerOutSaid=false;
            // An update installed by itself restarts once nothing is being entered.
            if(installedUpdate!=null&&!DeskEntering()) RestartIntoUpdate(installedUpdate,true);
            if(deskTicks%60==0) {
                bool tried=updateOffer!=null&&AppSettings.Current.deskAutoUpdateTried==updateOffer.version;
                if(installedUpdate==null&&Unattended.UpdateDue(updateOffer!=null,AppSettings.Current.autoUpdate,now,DeskEntering(),Native.UserActiveWithin((int)Unattended.QuietForUpdate.TotalMilliseconds),deskLastAutoUpdate,tried)) {
                    deskLastAutoUpdate=now;AppLog.Note("update_auto",updateOffer.version+" desk");InstallUpdate(true);
                }
                if(deskTicks%3600==0&&!TempeOrderCheck.Text.InShopHours(now)) CheckForUpdate();
            }
        }
        // A phone job or an eBay order that stopped before anything was typed (COSTAR busy, Add new covered, someone
        // at the PC) is retried once by itself, Unattended.RetryAfter after it stopped; the stop time and the "once"
        // are kept in the queue (JobQueue/EbayQueue.AutoRetry), so a restart neither repeats it nor loses it. Only
        // while the RDP helper is in touch and taking that work (else the one retry would be spent waiting). A second
        // stop waits for a person.
        void RetryOnce(DateTime now) {
            var utc=now.ToUniversalTime();
            if(api.Connected&&api.Accepting) foreach(var j in queue.List()) {
                if(j.job==null||!JobQueue.AutoRetryDue(j,utc)) continue;
                try { if(queue.AutoRetry(j.job.submissionId,utc)) { AppLog.Note("auto_retry",j.job.Reference);UpdateStatus(); } } catch(Exception e) { AppLog.Note("auto_retry_failed",j.job.Reference+" "+e.Message); }
            }
            if(ebayQueue!=null&&api.EbayConnected&&api.EbayAccepting) foreach(var o in ebayQueue.List()) {
                if(o.order==null||!EbayQueue.AutoRetryDue(o,utc)) continue;
                try { if(ebayQueue.AutoRetry(o.order.orderNumber,utc)) { AppLog.Note("auto_retry","ebay "+o.order.orderNumber);UpdateStatus(); } } catch(Exception e) { AppLog.Note("auto_retry_failed","ebay "+o.order.orderNumber+" "+e.Message); }
            }
        }
    }
}
