// 2.9.15 "Invoice read (dry run)" (spec of 20 Nov 2026): the RDP helper's Invoice tab, last after Wholesale so the other
// tabs keep their places. Read open invoice reads the COSTAR Invoice staff have already opened (InvoiceRun, on a thread
// of its own) and shows what was read and what Buffalo's delivery label would need; Copy Buffalo Details puts exactly
// the text of the Buffalo box on the clipboard (checked: read back, tried again). Reading never means sold or complete:
// the Sold button is always disabled and has nothing on its click (InvoiceDryRun.SellingEnabled is false). The timer
// only shows what the run has already read; nothing here looks at COSTAR.
using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace TempeCostar {
    internal sealed partial class WorkerForm {
        readonly TabPage invoicePage=new TabPage("Invoice");
        readonly Button invoiceRead=Ui.PrimaryButton("Read open invoice",190),invoiceStop=Ui.DangerButton("Stop",100),
            invoiceCopy=Ui.SecondaryButton("Copy Buffalo Details",190),invoiceSold=InvoiceUi.SoldButton();
        readonly TextBox invoiceExpected=new TextBox {Width=170,Font=Ui.Base,Margin=new Padding(0,6,16,0)};
        readonly Label invoiceStatus=Ui.Text("Not read yet.",1000),invoiceCopyLine=Ui.Hint("",1000);
        TextBox invoiceReview,invoiceBuffalo;
        volatile InvoiceRun invoiceRun;InvoiceOutcome invoiceShown;string invoiceBuffaloShown="";
        // The read is using COSTAR (for Stop all).
        bool InvoiceBusy { get { var r=invoiceRun;return r!=null&&r.Running; } }
        void BuildInvoicePage() {
            invoicePage.BackColor=Ui.Canvas;invoicePage.Padding=new Padding(0);
            var card=Ui.Card();
            var lines=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,BackColor=Ui.Surface};
            lines.Controls.Add(Ui.Title("Invoice (dry run: read only)"));
            lines.Controls.Add(Ui.Hint("Reads the COSTAR Invoice that is already open (open it in COSTAR first: any COSTAR, any branch) and prepares its details for review and for Buffalo delivery labels. "+
                "It never sells, saves, prints, books freight or sends anything to Buffalo; it doesn't open or close anything, type, click, switch COSTAR's tabs or answer its windows. "+
                "The only thing it may do in COSTAR is scroll the invoice's line list when there are more than 25 lines, and scroll it back: leave the PC alone while it reads. "+
                "Reading is not selling: Sold stays disabled. Customer details show here only and are never written to the day log.",820));
            var expectedRow=Ui.Row(36);expectedRow.Margin=new Padding(0,6,0,0);
            expectedRow.Controls.Add(new Label {Text="Expected invoice #:",AutoSize=true,Font=Ui.Base,ForeColor=Ui.Ink,Margin=new Padding(0,9,6,0)});
            expectedRow.Controls.Add(invoiceExpected);
            expectedRow.Controls.Add(Ui.Hint("Optional. When given, the open invoice must be this number, or nothing is prepared. Needed when more than one Invoice is open.",460));
            lines.Controls.Add(expectedRow);
            var buttons=Ui.Row();buttons.Margin=new Padding(0,8,0,4);
            buttons.Controls.Add(invoiceRead);buttons.Controls.Add(invoiceStop);buttons.Controls.Add(invoiceCopy);buttons.Controls.Add(invoiceSold);
            lines.Controls.Add(buttons);
            lines.Controls.Add(invoiceStatus);lines.Controls.Add(invoiceCopyLine);
            invoiceReview=InvoiceUi.Box();invoiceBuffalo=InvoiceUi.Box();
            var layout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=4,BackColor=Ui.Canvas,Padding=new Padding(0),Margin=new Padding(0)};
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,62));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,38));
            card.Controls.Add(lines);card.Dock=DockStyle.Top;
            layout.Controls.Add(card,0,0);
            layout.Controls.Add(invoiceReview,0,1);
            layout.Controls.Add(new Label {Text="Buffalo details (what Copy puts on the clipboard)",AutoSize=true,Font=Ui.Bold,ForeColor=Ui.Ink,Margin=new Padding(0,8,0,4)},0,2);
            layout.Controls.Add(invoiceBuffalo,0,3);
            invoicePage.Controls.Add(layout);
            invoiceRead.Click+=delegate{DeskForm.Attempt(StartInvoiceRead);};
            invoiceStop.Click+=delegate{StopInvoice();};
            invoiceCopy.Click+=delegate{DeskForm.Attempt(CopyInvoiceBuffalo);};
            // invoiceSold: no Click handler, ever (dry run).
            invoiceStop.Enabled=false;invoiceCopy.Enabled=false;
            invoiceReview.Text="Open the invoice in COSTAR, then press Read open invoice. What was read shows here: the invoice's identity, X (customer), Y (Ship to), "+
                "the header fields, every line with its exact Item, freight, the totals check, and anything missing or unclear.";
        }
        void StartInvoiceRead() {
            var last=invoiceRun;
            Order.Require(last==null||!last.Running,"The invoice is already being read.");
            Order.Require(!coordinator.Busy,(coordinator.Owner.Length>0?coordinator.Owner:"An entry")+" is using COSTAR: wait for it to finish, then press Read open invoice.");
            var run=new InvoiceRun(coordinator,invoiceExpected.Text);
            invoiceRun=run;invoiceShown=null;invoiceBuffaloShown="";
            invoiceReview.Text="";invoiceBuffalo.Text="";Show(invoiceCopyLine,"");
            AppLog.Note("invoice_dry_run_start",invoiceExpected.Text.Trim().Length>0?"expected given":"no expected #");
            var thread=new Thread(delegate() { run.Run(); }) {IsBackground=true,Name="Invoice read (dry run)"};
            thread.Start();
            UpdateStatus();
        }
        void StopInvoice() { var run=invoiceRun;if(run!=null&&run.Running) { run.Cancel=true;run.Line="Stopping the read ..."; } }
        void UpdateInvoiceTab() {
            if(invoiceReview==null) return;
            var run=invoiceRun;bool running=run!=null&&run.Running;
            invoiceRead.Enabled=!running&&!coordinator.Busy;invoiceStop.Enabled=running;invoiceExpected.ReadOnly=running;
            if(run!=null) {
                if(running) Show(invoiceStatus,run.Line);
                else {
                    var o=run.Outcome;
                    if(o!=null&&!Object.ReferenceEquals(o,invoiceShown)) {
                        invoiceShown=o;
                        invoiceReview.Text=o.Review;invoiceBuffalo.Text=o.Buffalo;invoiceBuffaloShown=invoiceBuffalo.Text;
                        Show(invoiceStatus,o.Status);
                    }
                }
            }
            var shown=invoiceShown;
            invoiceCopy.Enabled=!running&&shown!=null&&shown.Read!=null&&invoiceBuffaloShown.Length>0;
        }
        static void Show(Label label,string text) { text=text??"";if(label.Text!=text) label.Text=text; }
        // Exactly the Buffalo box's text (the one InvoicePreview.Buffalo gave for the read shown), checked on the clipboard.
        void CopyInvoiceBuffalo() {
            // An earlier "Copied ..." never stays on screen over a copy that didn't work.
            Show(invoiceCopyLine,"");
            var shown=invoiceShown;
            Order.Require(shown!=null&&shown.Read!=null&&invoiceBuffaloShown.Length>0,"Read an invoice first: there are no Buffalo details to copy.");
            string text=invoiceBuffalo.Text;
            Order.Require(text==invoiceBuffaloShown&&text==shown.Buffalo,"The Buffalo box doesn't hold what was prepared: press Read open invoice again.");
            int attempts;string why=InvoiceClipboard.Copy(text,out attempts);
            int count=InvoiceUi.LineCount(text);
            string tries=attempts<0?"unknown":attempts.ToString(System.Globalization.CultureInfo.InvariantCulture);
            AppLog.Note("invoice_copy",why==null?"copied lines="+count+" attempts="+tries:"not copied attempts="+tries);
            if(why!=null) Show(invoiceCopyLine,"Not copied: "+why+". Nothing was sent to Buffalo.");
            Order.Require(why==null,"The Buffalo details weren't copied: "+why+". Try Copy Buffalo Details again.");
            Show(invoiceCopyLine,"Copied the Buffalo details ("+count+" lines). Nothing was sent to Buffalo.");
        }
    }

    internal static class InvoiceUi {
        // The Sold action exists only as this button: always disabled, nothing on its click.
        internal static Button SoldButton() {
            var b=Ui.SecondaryButton("Sold (disabled in dry run)",210);
            b.Enabled=false;
            return b;
        }
        // How many handlers a button's Click has (-1: it can't be told).
        internal static int ClickHandlers(Control c) {
            try {
                var key=typeof(Control).GetField("EventClick",BindingFlags.NonPublic|BindingFlags.Static);
                var events=typeof(Component).GetProperty("Events",BindingFlags.NonPublic|BindingFlags.Instance);
                if(key==null||events==null) return -1;
                var list=events.GetValue(c,null) as EventHandlerList;
                if(list==null) return -1;
                var d=list[key.GetValue(null)];
                return d==null?0:d.GetInvocationList().Length;
            } catch(Exception) { return -1; }
        }
        // A large read-only monospace box (fixed-width columns line up).
        internal static TextBox Box() {
            return new TextBox {Multiline=true,ReadOnly=true,WordWrap=false,ScrollBars=ScrollBars.Both,Dock=DockStyle.Fill,Font=new Font("Consolas",9.5F),
                BackColor=Ui.Surface,ForeColor=Ui.Ink,BorderStyle=BorderStyle.FixedSingle,HideSelection=false,Margin=new Padding(0)};
        }
        internal static int LineCount(string text) {
            if(String.IsNullOrEmpty(text)) return 0;
            var lines=text.Replace("\r\n","\n").Split('\n').ToList();
            while(lines.Count>0&&lines[lines.Count-1].Length==0) lines.RemoveAt(lines.Count-1);
            return lines.Count;
        }
    }

    // The Windows clipboard, on an STA thread of its own (ported from Ebay-auto's RoClipboard): Unicode text, set, then
    // read back; tried up to Attempts times. Only ever on a person's click of Copy Buffalo Details.
    internal static class InvoiceClipboard {
        internal const int Attempts=3,PauseMs=250,TimeoutMs=8000;
        // Pure: set, then read back, up to Attempts times; null once exactly text was read back, else why not.
        internal static string CopyChecked(string text,Action<string> set,Func<string> get,Action<int> pause,out int attempts) {
            return CopyChecked(text,set,get,pause,null,out attempts);
        }
        // given up: once true (the caller stopped waiting), nothing more is put on the clipboard.
        internal static string CopyChecked(string text,Action<string> set,Func<string> get,Action<int> pause,Func<bool> givenUp,out int attempts) {
            string why="not tried";attempts=0;
            for(int i=1;i<=Attempts;i++) {
                if(givenUp!=null&&givenUp()) return "given up (the clipboard didn't answer in time)";
                attempts=i;
                try {
                    set(text);
                    string back=get();
                    if(back==text) return null;
                    why=String.IsNullOrEmpty(back)?"nothing was read back":"something else was read back ("+back.Length+" characters)";
                } catch(Exception e) { why=Failure(e); }
                if(i<Attempts) pause(PauseMs);
            }
            return why;
        }
        static string Failure(Exception e) {
            return e is ExternalException?"the clipboard was busy ("+e.GetType().Name+")":e.GetType().Name+": "+Sanitize.Text(e.Message,120);
        }
        internal const string TimedOut="the clipboard didn't answer within 8 s (a copy still under way may land late: check what you paste)";
        // Copies text: null once it was read back the same, else why not. attempts: -1 when it timed out (unknown).
        internal static string Copy(string text,out int attempts) {
            int tries=0;var gaveUp=new bool[1];
            string why=OnSta(delegate {
                return CopyChecked(text,
                    delegate(string t) { if(Volatile.Read(ref gaveUp[0])) return;var data=new DataObject();data.SetData(DataFormats.UnicodeText,false,t);Clipboard.SetDataObject(data,true,10,100); },
                    delegate { return Clipboard.ContainsText(TextDataFormat.UnicodeText)?Clipboard.GetText(TextDataFormat.UnicodeText):null; },
                    delegate(int ms) { Thread.Sleep(ms); },delegate { return Volatile.Read(ref gaveUp[0]); },out tries);
            },delegate { Volatile.Write(ref gaveUp[0],true); });
            attempts=why==TimedOut?-1:tries;
            return why;
        }
        static string OnSta(Func<string> work,Action giveUp) {
            string result="not done";
            var thread=new Thread(delegate() { try { result=work(); } catch(Exception e) { result=Failure(e); } });
            thread.SetApartmentState(ApartmentState.STA);thread.IsBackground=true;thread.Name="Invoice clipboard";
            thread.Start();
            if(!thread.Join(TimeoutMs)) { giveUp();return TimedOut; }
            return result;
        }
    }
}
