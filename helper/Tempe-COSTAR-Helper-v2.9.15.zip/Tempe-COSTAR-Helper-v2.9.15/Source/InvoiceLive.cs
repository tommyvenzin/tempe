// 2.9.15 "Invoice read (dry run)" (spec of 20 Nov 2026): the live side of reading the COSTAR Invoice that staff have
// already opened, so its details can be prepared for Buffalo delivery labels. READ + PREPARE ONLY: nothing is sold,
// saved, typed, booked, printed or sent; no COSTAR window is opened, closed, pressed, switched or answered.
//
// Everything this file does to COSTAR goes through IInvoiceScreen, whose members are reads (the Invoice windows, one
// window's state, the windows over it, a snapshot of its controls with every box's text, the selected tab, the line
// grid scroll bar's position) plus exactly ONE input: ScrollGrid, which scrolls the invoice's line grid by its own
// scroll bar when the invoice has more than 25 lines (and scrolls it back). InvoiceScreenRules.Check and the self-tests
// hold the interface to that list; Build.ps1 refuses any Invoice*.cs file that names a press, key, click, close,
// keyboard-focus or text-setting call (InvoiceSourceGuard.Patterns is the same list).
//
// How the grid is scrolled (chosen and documented here; NEVER SEEN ON A REAL COSTAR, needs live verification): the
// 3 Nov 14:47:35 map shows the grid's scroll bar as a WinForms SCROLLBAR control [1030,370,17,475], a child of the line
// grid panel [37,340,1010,692], disabled while every line fits. The reader sends WM_VSCROLL (0x0115) to that panel with
// lParam = the scroll bar's handle and SB_PAGEDOWN / SB_PAGEUP (SB_LINEUP / SB_LINEDOWN to land exactly), each followed
// by SB_ENDSCROLL, as a real scroll bar does; WinForms reflects the message to the scroll bar, which moves its Value.
// The position is read with GetScrollInfo(SB_CTL) (read only). No mouse wheel, no keys, no keyboard focus, no clicks,
// COSTAR isn't brought to the front. Pages are merged by COSTAR's own line-number labels (InvoiceReader.Merge).
//
// Locks: the whole read holds the EntryCoordinator gate (TryBeginRead: the same one-at-a-time gate TryBegin takes, so
// no other job can type into COSTAR meanwhile). Scrolling, the only input, also needs CostarInputLock and a quiet
// moment with nobody at the PC, watched (RoOpenWatch) before every scroll; Stop is honoured between scrolls.
// Privacy: customer words are only shown in the helper's own window; the day log gets counts, states and codes.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace TempeCostar {
    // A top-level window (an Invoice) as the screen sees it now.
    internal sealed class InvoiceWindow { internal IntPtr Handle;internal uint Pid;internal string Caption="";internal bool Enabled,Visible; }
    // The line grid scroll bar's position (GetScrollInfo, SB_CTL). Top: the furthest position it can reach.
    internal sealed class InvoiceScroll {
        internal bool Found,Enabled;internal int Min,Max,Page,Pos;
        internal int Top { get { int page=Math.Max(1,Page);return Math.Max(Min,Max-page+1); } }
    }

    // The ONLY way the invoice reader touches COSTAR. Reads, plus exactly one input (ScrollGrid).
    internal interface IInvoiceScreen {
        // Visible top-level windows of COSTAR processes whose caption is an Invoice's (InvoiceReader.IsInvoiceCaption).
        List<InvoiceWindow> InvoiceWindows();
        // That window now (null when it is gone).
        InvoiceWindow Window(IntPtr window);
        // The visible windows of its process owned by it (directly or through others): their captions.
        List<string> Over(IntPtr window);
        // Its visible controls with every box's text read (TextState "read"; password boxes never read).
        List<ControlInfo> Snapshot(IntPtr window);
        // The MSAA name of the selected page tab of its tab control (null when it can't be told).
        string SelectedTab(IntPtr window,List<ControlInfo> snapshot);
        // The line grid scroll bar's position (read only).
        InvoiceScroll ScrollInfo(IntPtr scrollBar);
        // The control that has the keyboard on the invoice window's GUI thread (GetGUIThreadInfo, read only): its handle,
        // 0 when none, -1 when it can't be told.
        long KeyboardFocus(IntPtr window);
        // THE one input: scroll the line grid by its scroll bar (code: InvoiceScreenRules.LineUp/LineDown/PageUp/PageDown).
        bool ScrollGrid(IntPtr grid,IntPtr scrollBar,int code);
    }

    internal static class InvoiceScreenRules {
        internal static readonly string[] Reads={"InvoiceWindows","Window","Over","Snapshot","SelectedTab","ScrollInfo","KeyboardFocus"};
        internal static readonly string[] Inputs={"ScrollGrid"};
        internal const int LineUp=0,LineDown=1,PageUp=2,PageDown=3;
        internal static bool Allowed(int code) { return code>=LineUp&&code<=PageDown; }
        // null when the interface's methods are exactly the allowed reads plus the one input (no properties, no events).
        internal static string Check(Type screen) {
            var flags=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static|BindingFlags.DeclaredOnly;
            var names=screen.GetMethods(flags).Select(m=>m.Name).OrderBy(n=>n,StringComparer.Ordinal).ToList();
            var allowed=Reads.Concat(Inputs).OrderBy(n=>n,StringComparer.Ordinal).ToList();
            if(screen.GetProperties(flags).Length>0||screen.GetEvents(flags).Length>0) return "it has properties or events";
            if(names.Count!=names.Distinct().Count()) return "a method is overloaded";
            var extra=names.Except(allowed).ToList();var missing=allowed.Except(names).ToList();
            if(extra.Count>0) return "it has more than the allowed methods: "+String.Join(", ",extra.ToArray());
            if(missing.Count>0) return "it lacks "+String.Join(", ",missing.ToArray());
            return null;
        }
    }

    // The build's source guard (Build.ps1 holds the same list): no Invoice*.cs file may name a press, key, click,
    // close, keyboard focus, text-setting or selling call. Each pattern is written so it doesn't match its own text.
    internal static class InvoiceSourceGuard {
        internal static readonly string[] Patterns={
            @"\bDirec[t]\s*\.",@"BM_CLIC[K]",@"(?i)\b0x0*F[5]\b",@"KeyNo[w]",
            @"\bNative\s*\.\s*(?:Ke[y]|Clic[k]|DoubleClic[k]|RightClic[k]|Whee[l]|Chor[d]|BringToFron[t]|SetForegroundWindo[w]|ShowWindo[w]|WriteMessag[e])",
            @"DoubleClic[k]",@"SendInpu[t]",@"keybd_even[t]",@"mouse_even[t]",@"WM_CLOS[E]",@"CloseWindo[w]",@"(?i)\b0x0*1[0]\b",
            @"WM_SETTEX[T]",@"(?i)\b0x0*[C]\b",@"SetFocu[s]",@"accDoDefaultActio[n]",@"(?i)\bsel[l]\w*\s*\(",@"\bSetTex[t]\s*\(",
            @"SetWindowTex[t]",@"PostMessag[e]",@"SendKey[s]",@"(?i)MOUSEWHEE[L]",@"(?i)\bWM_(?:KEY|SYSKEY|CHAR|[LRM]BUTTON|COMMAN[D])",
            @"ShowTa[b]",@"PressLate[r]",@"\bRoWi[p]\s*\.\s*(?:Ope[n]|Fron[t]|PressSearc[h]|ClearFilte[r])",
            // The project's own MSAA press / tab-switch / focus wrappers (the MSAA default action, child selection).
            @"\bDoDefaul[t]",@"SelectChil[d]",@"accSelec[t]",
            // No using-alias (it would hide a class name from the list below).
            @"\busin[g]\s+\w+\s*=",
            // An allow-list on the classes that can press COSTAR: only these read members may be named.
            @"\bNativ[e]\s*\.\s*(?!(?:Caption|Class|EnumChildWindows|EnumWindows|Focus|GetGUIThreadInfo|GetParent|GetWindowThreadProcessId|GuiInfo|GetWindow|GetWindowLong|GetWindowRect|IsWindow|IsWindowEnabled|IsWindowVisible|NotePointer|Pid|Rect|SendNull|TryText|UserActiveWithin)\b)\w",
            @"\bRunne[r]\s*\.\s*(?!Decoration\b)\w",@"\bCostarWindow[s]\s*\.\s*(?!IsCostar\b)\w",@"\bWholesaleOrderReade[r]\s*\.\s*(?!(?:Beside|Snapshot|Tab)\b)\w",
            @"\b(?:Msa[a]|Wi[n]|RoWi[p]|RoEngin[e]|WipScree[n]|WipScrol[l]|WipSearc[h]|CostarWipScree[n]|Costa[r]|WholesaleRu[n]|GridReade[r]|Unattende[d])\s*\.\s*\w",
            @"\btypeo[f]\s*\(\s*(?:Native|Msaa|Direct|Runner|RoWip|RoEngine|Win|Costar|CostarWindows|WholesaleOrderReader)\s*\)",
            @"\bGetMetho[d]\s*\(|\bInvokeMembe[r]\b|CreateDelegat[e]|GetDelegateForFunctionPointe[r]",
            // The one input is structural: the only P/Invokes are GetScrollInfo and the scroll message (SendMessageTimeoutW),
            // which is only ever called with WmVScroll, itself 0x0115; the WM_NULL ping only with message 0.
            @"\bexter[n]\s+[\w.]+\s+(?!(?:ScrollMessag[e]|GetScrollInf[o])\s*\()\w+\s*\(",@"EntryPoin[t]\s*=\s*\x22(?!SendMessageTimeoutW\x22)",
            @"\bScrollMessag[e]\s*\((?!\s*IntPtr\s+h\s*,\s*uint\s+msg\s*,)(?!\s*grid\s*,\s*WmVScrol[l]\s*,)",@"\bWmVScrol[l]\s*=\s*(?!0x0115\b)",
            @"\bSendNul[l]\s*\(\s*[^,()]+,\s*(?!0\s*,)"
        };
        // The patterns found in a file's text (none: clean).
        internal static List<string> Hits(string text) {
            var hits=new List<string>();
            foreach(var p in Patterns) if(Regex.IsMatch(text??"",p)) hits.Add(p);
            return hits;
        }
    }

    // The pure parts the reading uses (InvoiceModel's, unless a test gives its own).
    internal delegate InvoicePage InvoicePageReader(List<ControlInfo> s,Func<ControlInfo,string> text,out string why);
    internal delegate bool InvoicePageMerger(List<InvoicePage> pages,out List<InvoiceLine> merged,out string why);
    internal sealed class InvoiceParts {
        internal InvoicePageReader Page;internal InvoicePageMerger Merge;
        internal Func<List<ControlInfo>,Func<ControlInfo,string>,string,List<InvoicePage>,string,InvoiceRead> Parse;
        internal Func<List<ControlInfo>,Func<ControlInfo,string>,string> Fingerprint;
        internal Func<InvoiceRead,string> Review,Buffalo,Status,LogLine;
        internal Action<int> Pause;
        internal static InvoiceParts Live() {
            return new InvoiceParts {Page=InvoiceReader.Page,Merge=InvoiceReader.Merge,Parse=InvoiceReader.Parse,Fingerprint=InvoiceReader.Fingerprint,
                Review=InvoicePreview.Review,Buffalo=InvoicePreview.Buffalo,Status=InvoicePreview.Status,LogLine=InvoicePreview.LogLine,Pause=Thread.Sleep};
        }
    }

    // What protects the one input (scrolling): Begin before the first scroll (throws why it can't), Problem before each
    // scroll (null: go on), End once scrolling is over (on the thread that began it).
    internal interface IInvoiceInputGuard {
        void Begin(Func<bool> cancelled);
        string Problem();
        void End();
    }
    // The project's protections for COSTAR input: a quiet moment (3 s with nobody at the PC, within 30 s), the
    // CostarInputLock, then nobody may use the PC (RoOpenWatch, as the wholesale dry run). watchPerson false: the lock
    // only (a harness driving a made-up window).
    internal sealed class InvoiceInputGuard : IInvoiceInputGuard {
        readonly bool watchPerson;CostarInputLock input;RoOpenWatch watch;
        internal InvoiceInputGuard(bool watchPerson) { this.watchPerson=watchPerson; }
        public void Begin(Func<bool> cancelled) {
            if(watchPerson) {
                var waiting=Stopwatch.StartNew();
                while(Native.UserActiveWithin(3000)) {
                    if(cancelled!=null&&cancelled()) throw new InvalidOperationException("Stop was pressed");
                    if(waiting.ElapsedMilliseconds>=30000) throw new InvalidOperationException("someone kept using the PC, so the line list wasn't scrolled");
                    Thread.Sleep(200);
                }
            }
            input=new CostarInputLock();
            watch=new RoOpenWatch();Native.NotePointer();
        }
        public string Problem() {
            if(!watchPerson||watch==null) return null;
            if(watch.UserActive||Native.UserActiveWithin((int)Math.Min(600000,watch.Clock.ElapsedMilliseconds+1000))) {
                watch.UserActive=true;
                return "someone used the PC while the line list was being scrolled";
            }
            return null;
        }
        public void End() { var held=input;input=null;if(held!=null) held.Dispose(); }
    }

    // The result of one press of Read: a read (complete or not) or a refusal, with the texts the tab shows.
    internal sealed class InvoiceOutcome {
        internal InvoiceRead Read;internal string Refused,RefusedLog;
        internal int Pages=1,Scrolls;internal string Warn;
        // Details shown in the window only (they may name a COSTAR window): added to the read's Problems, never logged.
        internal readonly List<string> Shown=new List<string>();
        internal readonly List<string> LogWhy=new List<string>();
        internal string Status="",Review="",Buffalo="";
        internal bool Complete { get { return Read!=null&&Read.Complete; } }
    }

    // Reading one Invoice window (no discovery): the e2e harness drives this with a made-up window by handle.
    internal static class InvoiceReading {
        internal const int MaxPages=80,MaxBackSteps=400;
        internal const string Stopped="Stopped: nothing was prepared. Nothing changed in COSTAR.";
        internal static string TextOf(ControlInfo c) { return c!=null&&c.TextState=="read"?c.Text:null; }
        static string Norm(string s) { return Regex.Replace((s??"").Trim(),@"\s+"," ").ToUpperInvariant(); }

        internal static InvoiceOutcome ReadWindow(IInvoiceScreen screen,IntPtr window,string expected,Func<bool> cancelled) {
            return ReadWindow(screen,window,expected,cancelled,new InvoiceInputGuard(true),InvoiceParts.Live(),null);
        }
        internal static InvoiceOutcome ReadWindow(IInvoiceScreen screen,IntPtr window,string expected,Func<bool> cancelled,IInvoiceInputGuard guard,InvoiceParts parts,Action<string> say) {
            if(cancelled==null) cancelled=delegate { return false; };
            if(parts==null) parts=InvoiceParts.Live();
            if(guard==null) guard=new InvoiceInputGuard(true);
            var o=new InvoiceOutcome();
            string want=(expected??"").Trim();
            var w=screen.Window(window);
            if(w==null||!w.Visible) return Refuse(o,"The invoice window closed in COSTAR: nothing was read. Open the invoice in COSTAR, then press Read.","window_gone",parts);
            int branch;string branchName;
            if(!InvoiceReader.IsInvoiceCaption(w.Caption,out branch,out branchName)) return Refuse(o,"That COSTAR window isn't an Invoice: nothing was read.","not_invoice",parts);
            string over=Blocker(screen,w);
            if(over!=null) return Refuse(o,"Something is open over the invoice in COSTAR ("+over+"): close it, then press Read.","window_over",parts);
            if(cancelled()) return Refuse(o,Stopped,"stopped",parts);
            Tell(say,"Reading the invoice (read only) ...");
            List<ControlInfo> s;
            try { s=screen.Snapshot(window); } catch(InvalidOperationException e) { return Refuse(o,e.Message+" Nothing was read.","no_answer",parts); }
            Func<ControlInfo,string> text=TextOf;
            string tab=screen.SelectedTab(window,s);
            string start=parts.Fingerprint(s,text);
            string why;var first=parts.Page(s,text,out why);
            string pagingWhy=null;
            if(first==null) {
                first=new InvoicePage {Lines=new List<InvoiceLine>()};
                pagingWhy="the lines could not be read: "+(String.IsNullOrEmpty(why)?"the line grid wasn't recognised":why);
                o.LogWhy.Add("grid_not_recognised");
            }
            if(first.Lines==null) first.Lines=new List<InvoiceLine>();
            var pages=new List<InvoicePage>{first};
            // The number first: an invoice other than the one expected is refused before anything is scrolled.
            var early=parts.Parse(s,text,tab,new List<InvoicePage>{first},pagingWhy);
            string number=early==null||early.Number==null?"":early.Number.Trim();
            if(want.Length>0&&number!=want)
                return Refuse(o,number.Length==0?"The open invoice's number could not be read, so it can't be checked against "+want+": nothing was prepared.":"The open invoice is "+number+", not "+want+": nothing was prepared.","not_expected",parts);
            if(pagingWhy==null) pagingWhy=PageThrough(screen,window,s,first,pages,guard,parts,cancelled,o,say);
            o.Pages=pages.Count;
            // The consistency guard: everything read again at the end must read the same.
            bool changed=false;string overNow=null;
            try {
                var now=screen.Window(window);
                overNow=now==null?"the invoice closed":Blocker(screen,now);
                if(overNow==null) {
                    var end=screen.Snapshot(window);
                    changed=parts.Fingerprint(end,text)!=start||screen.SelectedTab(window,end)!=tab;
                }
            } catch(InvalidOperationException e) { overNow=e.Message; }
            var r=parts.Parse(s,text,tab,pages,pagingWhy);
            if(r==null) r=new InvoiceRead {Complete=false};
            if(r.Problems==null) r.Problems=new List<string>();
            InvoiceReader.SetCaption(r,w.Caption);
            // The run's own reasons go to MarkIncomplete (they may be logged: no window titles in them); the detail,
            // which can name a COSTAR window, stays in Problems (shown only).
            if(overNow!=null) { InvoiceReader.MarkIncomplete(r,"the invoice could not be read again at the end: press Read again");r.Problems.Add("the invoice could not be read again at the end ("+overNow+")");o.LogWhy.Add("end_not_read"); }
            else if(changed) { InvoiceReader.MarkIncomplete(r,"the invoice changed while it was read: press Read again");o.LogWhy.Add("changed"); }
            if(o.Warn!=null) r.Problems.Add(o.Warn);
            foreach(var shown in o.Shown) if(!r.Problems.Contains(shown)) r.Problems.Add(shown);
            if(pagingWhy!=null) r.Complete=false;
            string read=r.Number==null?"":r.Number.Trim();
            if(want.Length>0&&read!=want) return Refuse(o,"The open invoice is "+(read.Length>0?read:"(number not read)")+", not "+want+": nothing was prepared.","not_expected",parts);
            o.Read=r;
            return Finish(o,parts);
        }
        static void Tell(Action<string> say,string words) { if(say!=null) try { say(words); } catch(Exception) { } }
        // Why nothing may be read (or scrolled) now: a window over the invoice, or the invoice disabled. null: none.
        internal static string Blocker(IInvoiceScreen screen,InvoiceWindow w) {
            if(w==null) return "the invoice closed";
            var over=screen.Over(w.Handle);
            if(over!=null&&over.Count>0) { string t=(over[0]??"").Trim();return t.Length>0?t:"a COSTAR window"; }
            if(!w.Enabled) return "COSTAR is asking something on it";
            return null;
        }
        internal static InvoiceOutcome Refuse(InvoiceOutcome o,string message,string code,InvoiceParts parts) {
            o.Read=null;o.Refused=message;o.RefusedLog=code;
            return Finish(o,parts);
        }
        internal static InvoiceOutcome Finish(InvoiceOutcome o,InvoiceParts parts) {
            if(o.Read==null) {
                o.Status=o.Refused??"";
                o.Review=Crlf((o.Refused??"")+"\n\nNothing was read or prepared. Not sold, not booked, nothing changed in COSTAR.");
                o.Buffalo="";
                return o;
            }
            o.Status=parts.Status(o.Read)??"";o.Review=Crlf(parts.Review(o.Read));o.Buffalo=Crlf(parts.Buffalo(o.Read));
            return o;
        }
        internal static string Crlf(string s) { return (s??"").Replace("\r\n","\n").Replace("\r","\n").Replace("\n","\r\n"); }

        // The line grid's scroll bar: a SCROLLBAR over 200 px tall in the panel that holds the "Item" heading, below it.
        internal static ControlInfo GridScrollBar(List<ControlInfo> s,out string why) {
            var items=s.Where(c=>c.Static&&c.RelativeBounds!=null&&Norm(c.Peek)=="ITEM").ToList();
            var bars=s.Where(c=>c.Visible&&c.Class!=null&&c.Class.IndexOf("SCROLLBAR",StringComparison.OrdinalIgnoreCase)>=0&&c.RelativeBounds!=null&&c.H>200&&c.W<=40).ToList();
            var mine=bars.Where(b=>items.Any(i=>i.Parent==b.Parent&&b.Y>i.Y)).ToList();
            if(mine.Count==1) { why=null;return mine[0]; }
            why=mine.Count>1?mine.Count+" scroll bars sit in the line grid":bars.Count==0?"the line grid's scroll bar wasn't found":"no scroll bar sits in the line grid";
            return null;
        }
        internal static string LineKey(InvoiceLine l) {
            if(l==null) return "";
            var parts=new[]{l.Number.ToString(System.Globalization.CultureInfo.InvariantCulture),l.ItemRaw,l.Item,l.Description,l.Size,l.Qty,l.List,l.Disc,l.Net,l.Tax,l.LineTotal,l.Note,l.Kind,
                l.Hidden==null?"":String.Join("\u001e",l.Hidden.ToArray())};
            return String.Join("\u001f",parts.Select(p=>p??"\u0000").ToArray());
        }
        internal static string PageKey(InvoicePage p) { return p==null||p.Lines==null?"":String.Join("\n",p.Lines.Select(LineKey).ToArray()); }
        static string Numbers(InvoicePage p) { return p==null||p.Lines==null?"":String.Join(",",p.Lines.Select(l=>l.Number.ToString(System.Globalization.CultureInfo.InvariantCulture)).ToArray()); }

        // Pages through the lines when there are more than fit (25), merges them by line number, and scrolls back.
        // null: every line is in pages; else why not (the read is then INCOMPLETE for it).
        static string PageThrough(IInvoiceScreen screen,IntPtr window,List<ControlInfo> s,InvoicePage first,List<InvoicePage> pages,IInvoiceInputGuard guard,InvoiceParts parts,Func<bool> cancelled,InvoiceOutcome o,Action<string> say) {
            string barWhy;var bar=GridScrollBar(s,out barWhy);
            if(bar==null) {
                if(first.Lines.Any(l=>l.Number>=25)) { o.LogWhy.Add("no_scroll_bar");return "lines 26+ could not be read: "+barWhy; }
                return null;
            }
            var barHandle=new IntPtr(bar.Handle);var grid=new IntPtr(bar.Parent);
            var info=screen.ScrollInfo(barHandle)??new InvoiceScroll();
            first.ScrollEnabled=bar.Enabled&&info.Found&&info.Enabled;first.ScrollPos=info.Pos;first.ScrollMax=info.Top;
            // More lines than show: a line number over 25 shows (every number label seen, filled or empty), or the 25th
            // line is filled (the list may go on); else the scroll bar's range says so.
            var seenNumbers=(first.Numbers??new List<int>()).Concat(first.Lines.Select(l=>l.Number)).ToList();
            bool beyond=seenNumbers.Any(n=>n>25);
            bool full=first.Lines.Any(l=>l.Number==25);
            bool disabled=!bar.Enabled||(info.Found&&!info.Enabled);
            string lead=info.Found&&info.Pos>info.Min?"some lines could not be read: ":"lines 26+ could not be read: ";
            // A disabled bar means everything fits (as in the 3 Nov map) unless the screen itself suggests more lines: the
            // range a disabled bar keeps was never seen (it may be left over), so it alone doesn't overrule the disabled state.
            if(disabled&&!beyond&&!full) return null;
            if(!info.Found) {
                if(!bar.Enabled&&!beyond) return null;
                o.LogWhy.Add("scroll_unread");return lead+"the line grid's scroll bar position couldn't be read";
            }
            if(info.Top<=info.Min&&!beyond) return null;
            if(disabled) { o.LogWhy.Add("scroll_disabled");return lead+"the line grid's scroll bar is disabled although the invoice seems to have more lines"; }
            if(info.Top<=info.Min) { o.LogWhy.Add("scroll_range");return lead+"the line grid's scroll bar has nowhere to go although line numbers over 25 show"; }
            // A box in the line list that has COSTAR's keyboard may hold typing not yet saved: never scroll under it.
            string focus=FocusProblem(screen,window,s,bar.Parent);
            if(focus!=null) { o.LogWhy.Add("focus_in_lines");return lead+focus; }
            int origin=info.Pos,pos=info.Pos;
            try { guard.Begin(cancelled); }
            catch(Exception e) { o.LogWhy.Add("not_scrolled");return lead+e.Message; }
            string why=null;bool stopInput=false;
            var pager=new Pager {Screen=screen,Window=window,Grid=grid,Bar=barHandle,Guard=guard,Parts=parts,Cancelled=cancelled,Outcome=o,Snap=s};
            try {
                Tell(say,"The invoice has more than 25 lines: scrolling its line list to read them (nothing else is touched) ...");
                // Staff left it scrolled down: to the top first.
                if(pos>info.Min) {
                    for(int i=0;i<MaxBackSteps&&pos>info.Min&&why==null;i++) {
                        bool moved;why=pager.Step(InvoiceScreenRules.PageUp,ref pos,out moved);
                        if(why==null&&!moved) { why="the scroll position did not move";o.LogWhy.Add("position_stuck"); }
                    }
                    if(why==null&&pos>info.Min) { why="the line list didn't reach its top";o.LogWhy.Add("no_top"); }
                    if(why==null) {
                        InvoicePage top;why=pager.Settled(pos,info,out top);
                        // The merge needs the screens in scroll order from the top: the screen staff left showing is
                        // read again on the way down (and checked once more after scrolling back), so it is dropped here.
                        if(why==null) { pages.Clear();pages.Add(top); }
                    }
                }
                // Then down a page at a time until the position stops at its end.
                var previous=pages[pages.Count-1];int prevPos=pos;
                for(int n=0;why==null&&pos<info.Top;n++) {
                    if(n>=MaxPages) { why="the invoice has more than "+MaxPages+" pages of lines";o.LogWhy.Add("too_many_pages");break; }
                    bool moved;why=pager.Step(InvoiceScreenRules.PageDown,ref pos,out moved);
                    if(why!=null) break;
                    if(!moved||pos<=prevPos) { why="the scroll position did not move";o.LogWhy.Add("position_stuck");break; }
                    InvoicePage page;why=pager.Settled(pos,info,out page);
                    if(why!=null) break;
                    string before=Numbers(previous),after=Numbers(page);
                    if(after.Length>0&&after==before) {
                        why=PageKey(page)==PageKey(previous)?"the lines did not change after a scroll":"the line numbers did not change after a scroll (the lines did)";
                        o.LogWhy.Add("numbers_same");break;
                    }
                    pages.Add(page);previous=page;prevPos=pos;
                    // The furthest place, as COSTAR's scroll bar reports it now.
                    var nowInfo=screen.ScrollInfo(barHandle);if(nowInfo!=null&&nowInfo.Found) info=nowInfo;
                }
                if(why==null) {
                    List<InvoiceLine> merged;string mergeWhy;
                    if(!parts.Merge(pages,out merged,out mergeWhy)) { why=String.IsNullOrEmpty(mergeWhy)?"the pages of lines did not fit together":mergeWhy;o.LogWhy.Add("merge"); }
                }
                stopInput=pager.StopInput;
            } catch(InvalidOperationException e) { why=e.Message;o.LogWhy.Add("scroll_failed");stopInput=true; }
            finally {
                try {
                    stopInput=stopInput||pager.StopInput;
                    if(pos!=origin&&!stopInput) Back(pager,ref pos,origin,info,first,o);
                    else if(pos!=origin) { o.Warn="the line list in COSTAR was left scrolled to another place ("+(pager.StopWhy??"stopped")+"): scroll it back in COSTAR if needed";o.LogWhy.Add("not_scrolled_back"); }
                } catch(InvalidOperationException e) { o.Warn="the lines did not come back to where they were ("+e.Message+")";o.LogWhy.Add("not_back"); }
                finally { guard.End(); }
            }
            return why==null?null:lead+why;
        }
        // Back to where the line list was, then the first page must read as it did at the start.
        static void Back(Pager pager,ref int pos,int origin,InvoiceScroll info,InvoicePage first,InvoiceOutcome o) {
            int page=Math.Max(1,info.Page);string why=null;
            for(int i=0;i<MaxBackSteps&&pos!=origin&&why==null;i++) {
                int code=pos>origin?(pos-origin>=page?InvoiceScreenRules.PageUp:InvoiceScreenRules.LineUp):(origin-pos>=page?InvoiceScreenRules.PageDown:InvoiceScreenRules.LineDown);
                bool moved;why=pager.Step(code,ref pos,out moved);
                if(why==null&&!moved) why="the scroll position did not move";
            }
            if(why==null&&pos!=origin) why="it didn't get back in "+MaxBackSteps+" steps";
            if(why!=null) { o.Warn="the lines did not come back to where they were ("+why+")";o.LogWhy.Add("not_back");return; }
            InvoicePage again;why=pager.Settled(pos,info,out again);
            if(why!=null||PageKey(again)!=PageKey(first)) { o.Warn="the lines did not come back to where they were";o.LogWhy.Add("not_back"); }
        }
        internal const string FocusInLines="a box in the line list has the keyboard in COSTAR – click outside the lines (or save) in COSTAR, then press Read again";
        // Why the line list must not be scrolled now because of where COSTAR's keyboard is (null: fine). The grid is the
        // line grid panel (the scroll bar's parent): a focused control inside it may hold typing COSTAR hasn't taken yet,
        // which a scroll (COSTAR reuses its line boxes) could commit to a line or move to another. A box elsewhere on the
        // invoice isn't under the scroll. A focus that can't be told: not scrolled either.
        internal static string FocusProblem(IInvoiceScreen screen,IntPtr window,List<ControlInfo> s,long grid) {
            long f=screen.KeyboardFocus(window);
            if(f==0) return null;
            if(f<0) return "where COSTAR's keyboard is couldn't be told, so the line list wasn't scrolled";
            if(f==grid) return FocusInLines;
            var byHandle=new Dictionary<long,ControlInfo>();
            foreach(var c in s??new List<ControlInfo>()) byHandle[c.Handle]=c;
            ControlInfo at;long h=f;
            for(int i=0;i<16&&byHandle.TryGetValue(h,out at);i++) { if(at.Parent==grid) return FocusInLines;h=at.Parent; }
            return null;
        }
        // One scroll and its reading, with the checks before each scroll.
        sealed class Pager {
            internal IInvoiceScreen Screen;internal IntPtr Window,Grid,Bar;internal IInvoiceInputGuard Guard;internal InvoiceParts Parts;internal Func<bool> Cancelled;internal InvoiceOutcome Outcome;
            internal bool StopInput;internal string StopWhy;internal List<ControlInfo> Snap;
            internal string Step(int code,ref int pos,out bool moved) {
                moved=false;
                if(Cancelled()) { StopInput=true;StopWhy="Stop was pressed";Outcome.LogWhy.Add("stopped");return "Stop was pressed"; }
                string person=Guard.Problem();
                if(person!=null) { StopInput=true;StopWhy=person;Outcome.LogWhy.Add("person");return person; }
                // The reason is fixed words (it can reach the day log); the window's title is shown in the window only.
                string over=Blocker(Screen,Screen.Window(Window));
                if(over!=null) { StopInput=true;StopWhy="something is open over the invoice";Outcome.LogWhy.Add("over");Outcome.Shown.Add("something was open over the invoice in COSTAR while its lines were scrolled ("+over+")");return "something is open over the invoice in COSTAR"; }
                string focus=FocusProblem(Screen,Window,Snap,Grid.ToInt64());
                if(focus!=null) { StopInput=true;StopWhy="a box in the line list has the keyboard";Outcome.LogWhy.Add("focus_in_lines");return focus; }
                if(!Screen.ScrollGrid(Grid,Bar,code)) { StopInput=true;StopWhy="COSTAR didn't take the scroll";Outcome.LogWhy.Add("scroll_refused");return "COSTAR didn't take the scroll"; }
                Outcome.Scrolls++;
                // The new position: looked at for up to 1 s (25 looks 40 ms apart).
                InvoiceScroll now=null;
                for(int look=0;look<25;look++) {
                    if(look>0) Parts.Pause(40);
                    now=Screen.ScrollInfo(Bar);
                    if(now!=null&&now.Found&&now.Pos!=pos) break;
                }
                if(now==null||!now.Found) { StopInput=true;StopWhy="the scroll bar went away";return "the line grid's scroll bar position couldn't be read after a scroll"; }
                moved=now.Pos!=pos;pos=now.Pos;
                return null;
            }
            // The lines once COSTAR has drawn them after a scroll: the same twice running.
            internal string Settled(int pos,InvoiceScroll info,out InvoicePage page) {
                page=null;string lastKey=null;string why="the lines kept changing after a scroll";
                for(int i=0;i<12;i++) {
                    Parts.Pause(i==0?150:120);
                    List<ControlInfo> snap;
                    try { snap=Screen.Snapshot(Window); } catch(InvalidOperationException e) { return e.Message; }
                    Snap=snap;
                    string pageWhy;var p=Parts.Page(snap,TextOf,out pageWhy);
                    if(p==null) { why="the lines could not be read after a scroll"+(String.IsNullOrEmpty(pageWhy)?"":" ("+pageWhy+")");lastKey=null;continue; }
                    if(p.Lines==null) p.Lines=new List<InvoiceLine>();
                    string key=PageKey(p);
                    if(lastKey!=null&&key==lastKey) { p.ScrollPos=pos;p.ScrollEnabled=true;p.ScrollMax=info.Top;page=p;return null; }
                    lastKey=key;
                }
                Outcome.LogWhy.Add("unsettled");
                return why;
            }
        }
    }

    // One press of Read: finds the Invoice already open in COSTAR, reads it (InvoiceReading), and logs counts only.
    // Runs on a thread of its own; the tab shows Line while it runs and Outcome once Running is false.
    internal sealed class InvoiceRun {
        internal const string Owner="The invoice read (read only)";
        internal const string NoneOpen="No COSTAR Invoice is open: open the invoice in COSTAR, then press Read.";
        internal volatile bool Cancel;
        internal volatile bool Running=true;   // from before its thread starts, so it can't be started twice
        internal volatile string Line="Starting ...";
        volatile InvoiceOutcome outcome;
        internal InvoiceOutcome Outcome { get { return outcome; } }
        readonly EntryCoordinator coordinator;readonly string expected;readonly IInvoiceScreen screen;readonly IInvoiceInputGuard guard;readonly InvoiceParts parts;
        internal InvoiceRun(EntryCoordinator entries,string expected) : this(entries,expected,new InvoiceWin32Screen(),new InvoiceInputGuard(true),InvoiceParts.Live()) { }
        internal InvoiceRun(EntryCoordinator entries,string expected,IInvoiceScreen screen,IInvoiceInputGuard guard,InvoiceParts parts) {
            coordinator=entries;this.expected=(expected??"").Trim();this.screen=screen;this.guard=guard;this.parts=parts??InvoiceParts.Live();
        }
        internal string Summary { get { var o=outcome;return o==null?"":o.Status; } }
        bool Cancelled() { return Cancel; }
        void Say(string words) { Line=words; }
        internal void Run() {
            EntryLease lease=null;var clock=Stopwatch.StartNew();InvoiceOutcome o=null;
            try {
                if(coordinator!=null) {
                    lease=coordinator.TryBeginRead(Owner);
                    if(lease==null) { o=InvoiceReading.Refuse(new InvoiceOutcome(),(coordinator.Owner.Length>0?coordinator.Owner:"Something")+" is using COSTAR: press Read again when it's done. Nothing was read.","busy",parts);return; }
                }
                o=Read();
            } catch(Exception e) {
                o=InvoiceReading.Refuse(new InvoiceOutcome(),"The invoice couldn't be read: "+e.Message+" Nothing changed in COSTAR.","error_"+e.GetType().Name,parts);
            } finally {
                if(lease!=null) lease.Dispose();
                if(o==null) o=InvoiceReading.Refuse(new InvoiceOutcome(),"The invoice couldn't be read. Nothing changed in COSTAR.","no_outcome",parts);
                outcome=o;Log(o,clock.ElapsedMilliseconds);
                Running=false;
            }
        }
        InvoiceOutcome Read() {
            Say("Looking for the Invoice open in COSTAR ...");
            var all=screen.InvoiceWindows()??new List<InvoiceWindow>();
            if(all.Count==0) return InvoiceReading.Refuse(new InvoiceOutcome(),NoneOpen,"none_open",parts);
            if(all.Count==1) return InvoiceReading.ReadWindow(screen,all[0].Handle,expected,Cancelled,guard,parts,Say);
            // Several: which one is known by its number only (read, never pressed).
            Say("Several Invoices are open in COSTAR: reading their numbers ...");
            var numbers=new List<string>();var matches=new List<IntPtr>();
            foreach(var w in all) {
                if(Cancel) return InvoiceReading.Refuse(new InvoiceOutcome(),InvoiceReading.Stopped,"stopped",parts);
                string n=NumberOf(w);numbers.Add(n);
                if(expected.Length>0&&n==expected) matches.Add(w.Handle);
            }
            string list=String.Join(", ",numbers.ToArray());
            if(expected.Length==0) return InvoiceReading.Refuse(new InvoiceOutcome(),"COSTAR has "+all.Count+" Invoices open ("+list+"): type the one to read in Expected invoice #, then press Read. Nothing was prepared.","several_open",parts);
            if(matches.Count==1) return InvoiceReading.ReadWindow(screen,matches[0],expected,Cancelled,guard,parts,Say);
            if(matches.Count==0) return InvoiceReading.Refuse(new InvoiceOutcome(),"None of the "+all.Count+" open Invoices is "+expected+" (open: "+list+"): nothing was prepared.","not_expected",parts);
            return InvoiceReading.Refuse(new InvoiceOutcome(),matches.Count+" open Invoices show "+expected+": close the extra one in COSTAR, then press Read. Nothing was prepared.","several_same",parts);
        }
        // An open invoice's number, read only ("?" with why when it can't be).
        string NumberOf(InvoiceWindow w) {
            if(InvoiceReading.Blocker(screen,w)!=null) return "? (something is open over it)";
            try {
                var s=screen.Snapshot(w.Handle);string why;
                var page=parts.Page(s,InvoiceReading.TextOf,out why)??new InvoicePage {Lines=new List<InvoiceLine>()};
                var r=parts.Parse(s,InvoiceReading.TextOf,null,new List<InvoicePage>{page},null);
                string n=r==null||r.Number==null?"":r.Number.Trim();
                return n.Length>0?n:"? (its number wasn't read)";
            } catch(InvalidOperationException) { return "? (COSTAR isn't answering on it)"; }
        }
        // The day log: counts, states, codes and the invoice number only (never customer words, descriptions or SKUs).
        void Log(InvoiceOutcome o,long ms) {
            try {
                string tail=" pages="+o.Pages+" scrolls="+o.Scrolls+" ms="+ms;
                if(o.Read==null) { AppLog.Note("invoice_dry_run_refused",(o.RefusedLog??"refused")+tail);return; }
                string line=parts.LogLine(o.Read)??"";
                AppLog.Note("invoice_dry_run",line+tail);
                if(!o.Read.Complete) {
                    var why=o.LogWhy.Distinct().ToList();
                    int problems=o.Read.Problems==null?0:o.Read.Problems.Count;
                    AppLog.Note("invoice_dry_run_incomplete",line+" why="+(why.Count>0?String.Join(",",why.ToArray()):"lines_or_fields")+" problems="+problems+tail);
                }
            } catch(Exception) { }
        }
    }

    // The Win32 screen: COSTAR's windows by handle, read with WM_GETTEXT / GetScrollInfo / MSAA; the one input is
    // WM_VSCROLL to the line grid with its scroll bar's handle.
    internal sealed class InvoiceWin32Screen : IInvoiceScreen {
        const uint WmVScroll=0x0115,SbEndScroll=8,SmtoAbortIfHung=0x0002,SmtoBlock=0x0001;
        const int SbCtl=2;const uint SifRangePagePos=0x7;
        [StructLayout(LayoutKind.Sequential)] struct ScrollInfoData { public uint cbSize,fMask;public int nMin,nMax;public uint nPage;public int nPos,nTrackPos; }
        [DllImport("user32.dll",SetLastError=true)] static extern bool GetScrollInfo(IntPtr h,int bar,ref ScrollInfoData info);
        [DllImport("user32.dll",EntryPoint="SendMessageTimeoutW",SetLastError=true)] static extern IntPtr ScrollMessage(IntPtr h,uint msg,UIntPtr w,IntPtr l,uint flags,uint timeout,out UIntPtr result);
        public List<InvoiceWindow> InvoiceWindows() {
            var found=new List<InvoiceWindow>();var costar=new Dictionary<uint,bool>();
            Native.EnumWindows(delegate(IntPtr h,IntPtr unused) {
                if(!Native.IsWindowVisible(h)) return true;
                string caption=Native.Caption(h);int branch;string name;
                if(!InvoiceReader.IsInvoiceCaption(caption,out branch,out name)) return true;
                uint pid=Native.Pid(h);bool yes;
                if(!costar.TryGetValue(pid,out yes)) { yes=CostarWindows.IsCostar(h);costar[pid]=yes; }
                if(yes) found.Add(new InvoiceWindow {Handle=h,Pid=pid,Caption=caption,Enabled=Native.IsWindowEnabled(h),Visible=true});
                return true;
            },IntPtr.Zero);
            return found;
        }
        public InvoiceWindow Window(IntPtr window) {
            if(window==IntPtr.Zero||!Native.IsWindow(window)) return null;
            return new InvoiceWindow {Handle=window,Pid=Native.Pid(window),Caption=Native.Caption(window),Enabled=Native.IsWindowEnabled(window),Visible=Native.IsWindowVisible(window)};
        }
        public List<string> Over(IntPtr window) {
            var found=new List<string>();uint pid=Native.Pid(window);
            Native.EnumWindows(delegate(IntPtr w,IntPtr unused) {
                if(w==window||Native.Pid(w)!=pid||!Native.IsWindowVisible(w)||Runner.Decoration(w)) return true;
                var o=Native.GetWindow(w,4);
                for(int i=0;i<16&&o!=IntPtr.Zero;i++,o=Native.GetWindow(o,4)) if(o==window) { string c=Native.Caption(w);found.Add(c.Length>0?c:"a COSTAR window");break; }
                return true;
            },IntPtr.Zero);
            return found;
        }
        // As WholesaleOrderReader.Snapshot (visible controls of the window's process, at most 4000, after COSTAR has
        // answered WM_NULL), then every box's text read with WM_GETTEXT (password boxes never).
        public List<ControlInfo> Snapshot(IntPtr window) {
            var s=new List<ControlInfo>();
            Native.Rect rb;Order.Require(Native.GetWindowRect(window,out rb),"The invoice window closed in COSTAR.");
            UIntPtr answer;Order.Require(Native.SendNull(window,0,UIntPtr.Zero,IntPtr.Zero,SmtoAbortIfHung,3000,out answer)!=IntPtr.Zero,"COSTAR isn't answering (the invoice may still be loading).");
            uint owner=Native.Pid(window);var handles=new List<IntPtr>();
            Native.EnumChildWindows(window,delegate(IntPtr h,IntPtr unused) { if(Native.Pid(h)==owner&&Native.IsWindowVisible(h)) handles.Add(h);return handles.Count<4000; },IntPtr.Zero);
            foreach(var h in handles) {
                Native.Rect box;if(!Native.GetWindowRect(h,out box)) continue;
                var c=new ControlInfo {Handle=h.ToInt64(),Root=window.ToInt64(),Parent=Native.GetParent(h).ToInt64(),Class=Native.Class(h),Style=Native.GetWindowLong(h,-16),Visible=true,Enabled=Native.IsWindowEnabled(h),
                    Bounds=new[]{box.Left,box.Top,box.Right-box.Left,box.Bottom-box.Top},RelativeBounds=new[]{box.Left-rb.Left,box.Top-rb.Top,box.Right-box.Left,box.Bottom-box.Top},TextState="not-read"};
                c.Password=c.Class.IndexOf("EDIT",StringComparison.OrdinalIgnoreCase)>=0&&(c.Style&0x20)!=0;
                string t;if(!c.Password&&Native.TryText(h,out t)) { c.Text=t;c.TextState="read"; }
                s.Add(c);
            }
            return s;
        }
        public string SelectedTab(IntPtr window,List<ControlInfo> snapshot) { return snapshot==null?null:WholesaleOrderReader.Tab(snapshot); }
        public long KeyboardFocus(IntPtr window) {
            if(window==IntPtr.Zero||!Native.IsWindow(window)) return -1;
            uint pid;var info=new Native.GuiInfo();info.size=Marshal.SizeOf(typeof(Native.GuiInfo));
            if(!Native.GetGUIThreadInfo(Native.GetWindowThreadProcessId(window,out pid),ref info)) return -1;
            return info.focus.ToInt64();
        }
        public InvoiceScroll ScrollInfo(IntPtr scrollBar) {
            var r=new InvoiceScroll();
            if(scrollBar==IntPtr.Zero||!Native.IsWindow(scrollBar)) return r;
            var d=new ScrollInfoData {cbSize=(uint)Marshal.SizeOf(typeof(ScrollInfoData)),fMask=SifRangePagePos};
            if(!GetScrollInfo(scrollBar,SbCtl,ref d)) return r;
            r.Found=true;r.Enabled=Native.IsWindowEnabled(scrollBar);r.Min=d.nMin;r.Max=d.nMax;r.Page=(int)d.nPage;r.Pos=d.nPos;
            return r;
        }
        // The one input. Only to a SCROLLBAR control of a COSTAR process, enabled, whose parent is the grid given; only
        // line/page up/down; nothing else is sent.
        public bool ScrollGrid(IntPtr grid,IntPtr scrollBar,int code) {
            if(!InvoiceScreenRules.Allowed(code)) return false;
            if(grid==IntPtr.Zero||scrollBar==IntPtr.Zero||!Native.IsWindow(scrollBar)||!Native.IsWindow(grid)) return false;
            if(Native.GetParent(scrollBar)!=grid||Native.Pid(scrollBar)!=Native.Pid(grid)) return false;
            if(Native.Class(scrollBar).IndexOf("SCROLLBAR",StringComparison.OrdinalIgnoreCase)<0||!Native.IsWindowEnabled(scrollBar)) return false;
            if(!CostarWindows.IsCostar(scrollBar)) return false;
            UIntPtr result;
            bool sent=ScrollMessage(grid,WmVScroll,new UIntPtr((uint)code),scrollBar,SmtoAbortIfHung|SmtoBlock,2000,out result)!=IntPtr.Zero;
            if(sent) ScrollMessage(grid,WmVScroll,new UIntPtr(SbEndScroll),scrollBar,SmtoAbortIfHung|SmtoBlock,2000,out result);
            return sent;
        }
    }

    // The live side's self-tests (made-up screens only; no COSTAR window is looked at). InvoiceTests.Cases calls
    // InvoiceLiveChecks.Cases(Case). The line pages here are made up by the test's own page reader, so these cases
    // test the paging driver, the refusals and the dry-run guarantees, not InvoiceModel's reading of a screen.
    internal static class InvoiceLiveChecks {
        static void Check(bool value,string message) { if(!value) throw new InvalidOperationException(message); }
        const long GridH=500,BarH=501,StateH=502,ItemH=503;
        // A made-up COSTAR: Invoice windows (handle -> number), one line grid of Total lines, 25 showing from Pos.
        internal sealed class FakeScreen : IInvoiceScreen {
            internal readonly List<InvoiceWindow> Windows=new List<InvoiceWindow>();
            internal readonly Dictionary<long,string> Numbers=new Dictionary<long,string>();
            internal readonly Dictionary<long,List<string>> OverIt=new Dictionary<long,List<string>>();
            internal int Total=20,Pos,Version;internal bool BarEnabled,Stuck,SameNumbers;
            internal readonly List<int> Codes=new List<int>();internal int Snapshots;
            internal Action<FakeScreen> AfterScroll;
            internal int Top { get { return Math.Max(0,Total-25); } }
            internal IntPtr Add(long handle,string number) {
                Windows.Add(new InvoiceWindow {Handle=new IntPtr(handle),Pid=7,Caption="Invoice  Branch 1  Tempe Tyres Sydney",Enabled=true,Visible=true});
                Numbers[handle]=number;return new IntPtr(handle);
            }
            public List<InvoiceWindow> InvoiceWindows() { return Windows.ToList(); }
            public InvoiceWindow Window(IntPtr window) { return Windows.FirstOrDefault(w=>w.Handle==window); }
            public List<string> Over(IntPtr window) { List<string> o;return OverIt.TryGetValue(window.ToInt64(),out o)?o.ToList():new List<string>(); }
            static ControlInfo Mk(long h,long parent,string cls,int x,int y,int w,int hh,string text,bool enabled) {
                return new ControlInfo {Handle=h,Parent=parent,Class=cls,Visible=true,Enabled=enabled,Bounds=new[]{x,y,w,hh},RelativeBounds=new[]{x,y,w,hh},Text=text,TextState="read"};
            }
            public List<ControlInfo> Snapshot(IntPtr window) {
                Snapshots++;
                string n;Numbers.TryGetValue(window.ToInt64(),out n);
                return new List<ControlInfo> {
                    Mk(GridH,1,"WindowsForms10.Window.8.app.0.1",37,340,1010,692,"",true),
                    Mk(ItemH,GridH,"WindowsForms10.STATIC.app.0.1",61,341,79,27,"Item",true),
                    Mk(BarH,GridH,"WindowsForms10.SCROLLBAR.app.0.1",1030,370,17,475,"",BarEnabled),
                    Mk(StateH,1,"WindowsForms10.STATIC.app.0.1",0,0,1,1,"num="+n+";pos="+Pos+";v="+Version+";n="+Total+";same="+(SameNumbers?1:0),true)
                };
            }
            public string SelectedTab(IntPtr window,List<ControlInfo> snapshot) { return "Ship to"; }
            // A disabled bar's leftover range (WinForms' default 0..100, page 10) when LeftoverRange is set.
            internal bool LeftoverRange;internal long Focus;
            public InvoiceScroll ScrollInfo(IntPtr scrollBar) {
                if(scrollBar.ToInt64()!=BarH) return new InvoiceScroll();
                if(LeftoverRange&&!BarEnabled) return new InvoiceScroll {Found=true,Enabled=false,Min=0,Max=100,Page=10,Pos=0};
                return new InvoiceScroll {Found=true,Enabled=BarEnabled,Min=0,Max=Math.Max(24,Total-1),Page=25,Pos=Pos};
            }
            public long KeyboardFocus(IntPtr window) { return Focus; }
            public bool ScrollGrid(IntPtr grid,IntPtr scrollBar,int code) {
                Check(grid.ToInt64()==GridH&&scrollBar.ToInt64()==BarH,"a scroll went somewhere other than the line grid's own scroll bar");
                Check(InvoiceScreenRules.Allowed(code),"a scroll code other than line/page up/down");
                Codes.Add(code);
                if(!Stuck) {
                    int step=code==InvoiceScreenRules.PageDown?25:code==InvoiceScreenRules.LineDown?1:code==InvoiceScreenRules.PageUp?-25:-1;
                    Pos=Math.Max(0,Math.Min(Top,Pos+step));
                }
                if(AfterScroll!=null) AfterScroll(this);
                return true;
            }
        }
        internal sealed class FakeGuard : IInvoiceInputGuard {
            internal int Began,Ended,Asked;internal int PersonAfter=-1;internal string Refuse;
            public void Begin(Func<bool> cancelled) { if(Refuse!=null) throw new InvalidOperationException(Refuse);Began++; }
            public string Problem() { Asked++;return PersonAfter>=0&&Asked>PersonAfter?"someone used the PC while the line list was being scrolled":null; }
            public void End() { Ended++; }
        }
        static Dictionary<string,string> State(List<ControlInfo> s) {
            var d=new Dictionary<string,string>();
            var c=s.First(x=>x.Handle==StateH);
            foreach(var part in c.Text.Split(';')) { int i=part.IndexOf('=');d[part.Substring(0,i)]=part.Substring(i+1); }
            return d;
        }
        static InvoiceLine Line(int number,string content) { return new InvoiceLine {Number=number,Item="T"+content,ItemRaw="T"+content,Description="tyre "+content,Qty="1",Net="10.00",LineTotal="11.00",Kind="product"}; }
        static bool FakeMerge(List<InvoicePage> pages,out List<InvoiceLine> merged,out string why) {
            var by=new SortedDictionary<int,InvoiceLine>();merged=null;why=null;
            foreach(var p in pages) foreach(var l in p.Lines) {
                InvoiceLine seen;
                if(by.TryGetValue(l.Number,out seen)&&InvoiceReading.LineKey(seen)!=InvoiceReading.LineKey(l)) { why="line "+l.Number+" read differently on two pages";return false; }
                by[l.Number]=l;
            }
            int k=0;foreach(var n in by.Keys) if(n!=++k) { why="line "+k+" is missing";return false; }
            merged=by.Values.ToList();return true;
        }
        static InvoicePage FakePage(List<ControlInfo> s,Func<ControlInfo,string> text,out string why) {
            why=null;var d=State(s);int pos=Int32.Parse(d["pos"]),n=Int32.Parse(d["n"]),v=Int32.Parse(d["v"]);bool same=d["same"]=="1";
            var lines=new List<InvoiceLine>();
            for(int i=1;i<=25&&pos+i<=n;i++) lines.Add(Line(same?i:pos+i,(pos+i)+(v>0?"v"+v:"")));
            return new InvoicePage {Lines=lines};
        }
        // The made-up InvoiceModel: lines Pos+1..Pos+25 of Total (or always numbered 1..25 when SameNumbers).
        internal static InvoiceParts Parts() {
            return new InvoiceParts {
                Page=FakePage,Merge=FakeMerge,
                Parse=delegate(List<ControlInfo> s,Func<ControlInfo,string> text,string tab,List<InvoicePage> pages,string pagingWhy) {
                    var r=new InvoiceRead {Number=State(s)["num"],Branch=1,YShown=tab=="Ship to"};
                    List<InvoiceLine> merged;string why;
                    if(pagingWhy==null&&FakeMerge(pages,out merged,out why)) { r.Lines=merged;r.LinesComplete=true; }
                    else { r.Lines=pages[0].Lines;r.LinesComplete=false;r.LinesWhy=pagingWhy??"merge";r.Problems.Add(r.LinesWhy); }
                    r.Complete=r.LinesComplete;
                    return r;
                },
                Fingerprint=delegate(List<ControlInfo> s,Func<ControlInfo,string> text) { var d=State(s);return d["num"]+"|"+d["pos"]+"|"+d["v"]+"|"+d["n"]; },
                Review=delegate(InvoiceRead r) { return "Invoice "+r.Number+"\n"+r.Lines.Count+" lines"; },
                Buffalo=delegate(InvoiceRead r) { return "NOT READY FOR BOOKING – 1 items unresolved"; },
                Status=delegate(InvoiceRead r) { return r.Complete?InvoicePreview.ReadComplete:"Read INCOMPLETE — "+String.Join("; ",r.Incomplete.Concat(r.Problems).ToArray())+"; nothing changed in COSTAR."; },
                LogLine=delegate(InvoiceRead r) { return "invoice="+r.Number+" lines="+r.Lines.Count; },
                Pause=delegate(int ms) { }
            };
        }
        static InvoiceOutcome Run(FakeScreen screen,string expected,FakeGuard guard) {
            var run=new InvoiceRun(null,expected,screen,guard,Parts());
            run.Run();
            Check(!run.Running&&run.Outcome!=null,"the run didn't end with an outcome");
            return run.Outcome;
        }
        interface IWithAPress { List<InvoiceWindow> InvoiceWindows();bool Press(IntPtr button); }
        internal static void Cases(Action<string,Action> Case) {
            Case("Invoice live (2.9.15): the reader's only way into COSTAR is reads plus one scroll of the line grid (IInvoiceScreen, by reflection)",()=>{
                Check(InvoiceScreenRules.Check(typeof(IInvoiceScreen))==null,"IInvoiceScreen: "+InvoiceScreenRules.Check(typeof(IInvoiceScreen)));
                Check(InvoiceScreenRules.Inputs.Length==1&&InvoiceScreenRules.Inputs[0]=="ScrollGrid","more than one input method is allowed");
                Check(InvoiceScreenRules.Check(typeof(IWithAPress))!=null,"an interface with a Press method passed the check");
                Check(!InvoiceScreenRules.Allowed(4)&&!InvoiceScreenRules.Allowed(6)&&!InvoiceScreenRules.Allowed(7)&&!InvoiceScreenRules.Allowed(-1),"a scroll code other than line/page up/down is allowed");
                Check(typeof(IInvoiceScreen).IsAssignableFrom(typeof(InvoiceWin32Screen)),"the Win32 screen doesn't implement IInvoiceScreen");
            });
            Case("Invoice live (2.9.15): selling is off and the Sold button is made disabled with nothing on its click",()=>{
                var field=typeof(InvoiceDryRun).GetField("SellingEnabled",BindingFlags.NonPublic|BindingFlags.Public|BindingFlags.Static);
                Check(field!=null&&field.IsLiteral&&Equals(field.GetRawConstantValue(),false),"InvoiceDryRun.SellingEnabled isn't a false constant");
                using(var sold=InvoiceUi.SoldButton()) {
                    Check(!sold.Enabled,"the Sold button is enabled");
                    Check(sold.Text=="Sold (disabled in dry run)","the Sold button's words changed");
                    Check(InvoiceUi.ClickHandlers(sold)==0,"the Sold button has a click handler");
                }
                using(var probe=new System.Windows.Forms.Button()) { probe.Click+=delegate { };Check(InvoiceUi.ClickHandlers(probe)==1,"the click-handler count can't be read (the Sold check would be blind)"); }
            });
            Case("Invoice live (2.9.15): the build's source guard catches each press, key, click, close, focus, text-setting or sell call",()=>{
                var planted=new[]{"Direct"+".Act(x)","Direct"+".Press(h,1)","BM_"+"CLICK","Send(h,0x00"+"F5)","Nati"+"ve.Key"+"Now(13)","Nati"+"ve.Key(9)","Nati"+"ve.Double"+"ClickNow(p)",
                    // 2.9.15 review: the MSAA wrappers, a using-alias, press helpers in other files, any other message.
                    "Ms"+"aa.DoDef"+"ault(a);","Nati"+"ve.Select"+"Child(p,c);","a.acc"+"Select(3,0);","us"+"ing N=Native; N.Click(p)","us"+"ing D=TempeCostar.Direct;",
                    "Ro"+"Wip.ReadList(t,true,false,null)","Ru"+"nner.Press(b)","Costar"+"Windows.Front(w)","Wholesale"+"OrderReader.SelectTab(s)","Wi"+"n.Click(h)",
                    "typ"+"eof(Native).GetField(\"x\")","t.GetMeth"+"od(\"Click\")","[DllImport(\"user32.dll\")] static ex"+"tern IntPtr SendMessageW(IntPtr h,uint m,IntPtr w,IntPtr l);",
                    "[DllImport(\"user32.dll\",EntryPo"+"int=\"Post"+"MessageW\")] static extern IntPtr ScrollMessage(IntPtr h,uint msg,UIntPtr w,IntPtr l,uint flags,uint timeout,out UIntPtr result);",
                    "Scroll"+"Message(grid,0x0100,new UIntPtr(13),bar,2,2000,out r)","Scroll"+"Message(grid,0x0201,UIntPtr.Zero,bar,2,2000,out r)","Scroll"+"Message(h,WmVScroll,c,bar,2,2000,out r)",
                    "const uint WmV"+"Scroll=0x0111","Nati"+"ve.Send"+"Null(h,245,UIntPtr.Zero,IntPtr.Zero,2,100,out a)","Nati"+"ve.Send"+"Null(h,16,UIntPtr.Zero,IntPtr.Zero,2,100,out a)",
                    "Send"+"Input(1,a,2)","keybd"+"_event(1)","mouse"+"_event(2)","WM_"+"CLOSE","Ro"+"Engine.Close"+"Window(w)","Send(w,0x00"+"10,0,0)","WM_"+"SETTEXT","Send(w,0x00"+"0C,0,s)",
                    "Set"+"Focus(h)","Direct"+".Focus(h)","a.acc"+"DoDef"+"aultAction(0)","run.Se"+"ll(order)","Sel"+"lNow()","box.Set"+"Text(\"x\")","Ui.Set"+"Text(l,t)","Set"+"WindowText(h,s)","Post"+"Message(h,1,2,3)"};
                foreach(var p in planted) Check(InvoiceSourceGuard.Hits(p).Count>0,"the guard missed a planted call ("+p.Length+" characters)");
                Check(InvoiceSourceGuard.Hits("var info=screen.ScrollInfo(bar);if(InvoiceDryRun.SellingEnabled) return;const uint WmVScroll=0x0115;label.Text=\"Sold\";").Count==0,"the guard refused clean code");
                // The sources built with this EXE (Build.ps1 keeps them beside the bin folder), when they are there.
                string folder=Path.Combine(Path.GetDirectoryName(typeof(InvoiceLiveChecks).Assembly.Location)??"","..","Source");
                if(Directory.Exists(folder)) foreach(var f in Directory.GetFiles(folder,"Invoice*.cs")) {
                    var hits=InvoiceSourceGuard.Hits(File.ReadAllText(f));
                    Check(hits.Count==0,Path.GetFileName(f)+" names a forbidden call: "+String.Join(" ",hits.ToArray()));
                }
            });
            Case("Invoice live (2.9.15): refusals: none open, several open, another number expected, a window over it, disabled; nothing scrolled",()=>{
                var none=new FakeScreen();
                var o=Run(none,"",new FakeGuard());
                Check(o.Read==null&&o.Status==InvoiceRun.NoneOpen,"none open: "+o.Status);
                var two=new FakeScreen();two.Add(11,"1001");two.Add(12,"1002");
                o=Run(two,"",new FakeGuard());
                Check(o.Read==null&&o.Status.Contains("1001")&&o.Status.Contains("1002")&&o.Status.Contains("Expected invoice #"),"two open, none expected: "+o.Status);
                o=Run(two,"1002",new FakeGuard());
                Check(o.Read!=null&&o.Read.Number=="1002"&&o.Complete,"two open, 1002 expected: "+o.Status);
                o=Run(two,"1003",new FakeGuard());
                Check(o.Read==null&&o.Status.StartsWith("None of the 2 open Invoices is 1003"),"two open, 1003 expected: "+o.Status);
                var one=new FakeScreen();one.Add(11,"1001");
                o=Run(one,"  1002 ",new FakeGuard());
                Check(o.Read==null&&o.Status=="The open invoice is 1001, not 1002: nothing was prepared.","another number: "+o.Status);
                Check(o.Buffalo.Length==0,"a refusal prepared Buffalo details");
                o=Run(one," 1001 ",new FakeGuard());
                Check(o.Complete&&o.Status==InvoicePreview.ReadComplete,"the expected number trimmed: "+o.Status);
                one.OverIt[11]=new List<string>{"Notes"};
                o=Run(one,"",new FakeGuard());
                Check(o.Read==null&&o.Status=="Something is open over the invoice in COSTAR (Notes): close it, then press Read.","a window over it: "+o.Status);
                one.OverIt.Clear();one.Windows[0].Enabled=false;
                o=Run(one,"",new FakeGuard());
                Check(o.Read==null&&o.Status.StartsWith("Something is open over the invoice in COSTAR (")&&o.Status.EndsWith("): close it, then press Read."),"disabled: "+o.Status);
                Check(none.Codes.Count+two.Codes.Count+one.Codes.Count==0,"a refusal scrolled COSTAR");
            });
            Case("Invoice live (2.9.15): up to 25 lines: read without any input; read twice, the same",()=>{
                var screen=new FakeScreen {Total=20};var guard=new FakeGuard();screen.Add(11,"1001");
                var a=Run(screen,"",guard);var b=Run(screen,"",guard);
                Check(a.Complete&&a.Read.Lines.Count==20&&a.Pages==1,"20 lines: "+a.Status);
                Check(screen.Codes.Count==0&&guard.Began==0,"COSTAR was scrolled (or the input lock taken) for 20 lines");
                Check(a.Review==b.Review&&a.Buffalo==b.Buffalo&&a.Status==b.Status,"two reads of the same invoice differ");
                Check(a.Review.Contains("\r\n")&&!a.Review.Replace("\r\n","").Contains("\n"),"the shown text isn't in Windows lines");
            });
            Case("Invoice live (2.9.15): 60 lines: paged by the grid's scroll bar only, merged by line number 1..60, scrolled back and read the same",()=>{
                var screen=new FakeScreen {Total=60,BarEnabled=true};var guard=new FakeGuard();screen.Add(11,"1001");
                var o=Run(screen,"",guard);
                Check(o.Complete&&o.Read.Lines.Count==60,"60 lines: "+o.Status);
                for(int i=0;i<60;i++) Check(o.Read.Lines[i].Number==i+1,"line "+(i+1)+" out of place");
                Check(screen.Pos==0,"the line list wasn't scrolled back (at "+screen.Pos+")");
                Check(guard.Began==1&&guard.Ended==1,"the input guard wasn't begun and ended once");
                Check(screen.Codes.Count(c=>c==InvoiceScreenRules.PageDown)==2&&screen.Codes.All(c=>c==InvoiceScreenRules.PageDown||c==InvoiceScreenRules.PageUp||c==InvoiceScreenRules.LineUp),"unexpected scrolls: "+String.Join(",",screen.Codes.Select(c=>c.ToString()).ToArray()));
                Check(o.Pages==3&&o.Scrolls==screen.Codes.Count,"pages "+o.Pages+", scrolls "+o.Scrolls);
                // Staff left it scrolled to line 26: read from the top, then put back at 26.
                screen.Codes.Clear();screen.Pos=25;
                o=Run(screen,"",guard);
                Check(o.Complete&&o.Read.Lines.Count==60&&screen.Pos==25,"started at line 26: "+o.Status+" (at "+screen.Pos+")");
                // The same with InvoiceModel's own Merge (screens in scroll order from the top, positions rising).
                foreach(int start in new[]{0,25}) {
                    screen.Codes.Clear();screen.Pos=start;
                    var real=Parts();real.Merge=InvoiceReader.Merge;
                    var run=new InvoiceRun(null,"",screen,guard,real);run.Run();o=run.Outcome;
                    Check(o!=null&&o.Complete&&o.Read.Lines.Count==60&&screen.Pos==start,"InvoiceReader.Merge, started at "+start+": "+(o==null?"no outcome":o.Status));
                }
            });
            Case("Invoice live (2.9.15): paging that can't be trusted is INCOMPLETE with its reason, never guessed",()=>{
                var stuck=new FakeScreen {Total=60,BarEnabled=true,Stuck=true};stuck.Add(11,"1001");
                var o=Run(stuck,"",new FakeGuard());
                Check(!o.Complete&&o.Read!=null&&o.Status.Contains("lines 26+ could not be read: the scroll position did not move"),"stuck: "+o.Status);
                var same=new FakeScreen {Total=60,BarEnabled=true,SameNumbers=true};same.Add(11,"1001");
                o=Run(same,"",new FakeGuard());
                Check(!o.Complete&&o.Status.Contains("the line numbers did not change after a scroll"),"numbers unchanged: "+o.Status);
                var disabled=new FakeScreen {Total=60,BarEnabled=false};disabled.Add(11,"1001");
                o=Run(disabled,"",new FakeGuard());
                Check(!o.Complete&&o.Status.Contains("lines 26+ could not be read")&&disabled.Codes.Count==0,"disabled bar with more lines: "+o.Status);
                var person=new FakeScreen {Total=80,BarEnabled=true};person.Add(11,"1001");
                o=Run(person,"",new FakeGuard {PersonAfter=1});
                Check(!o.Complete&&o.Status.Contains("someone used the PC")&&person.Codes.Count==1,"someone at the PC: "+o.Status+" ("+person.Codes.Count+" scrolls)");
                Check(o.Read.Problems.Any(p=>p.Contains("left scrolled")),"not said that the line list was left scrolled");
                var refused=new FakeScreen {Total=60,BarEnabled=true};refused.Add(11,"1001");
                o=Run(refused,"",new FakeGuard {Refuse="Another COSTAR helper is entering data"});
                Check(!o.Complete&&o.Status.Contains("lines 26+ could not be read: Another COSTAR helper")&&refused.Codes.Count==0,"input lock held elsewhere: "+o.Status);
            });
            Case("Invoice live (2.9.15): an invoice that changes while it is read is INCOMPLETE (press Read again)",()=>{
                var screen=new FakeScreen {Total=60,BarEnabled=true};screen.Add(11,"1001");
                screen.AfterScroll=delegate(FakeScreen f) { if(f.Pos==f.Top&&f.Version==0) f.Version=1; };
                var o=Run(screen,"",new FakeGuard());
                Check(!o.Complete&&o.Status.Contains("the invoice changed while it was read: press Read again"),"changed: "+o.Status);
            });
            Case("Invoice live (2.9.15): the Buffalo copy is set, read back and tried again up to 3 times",()=>{
                int sets=0;string board=null;int attempts;
                string why=InvoiceClipboard.CopyChecked("a\r\nb",delegate(string t) { sets++;board=sets<3?"":t; },delegate { return board; },delegate(int ms) { },out attempts);
                Check(why==null&&attempts==3&&sets==3,"third try: "+why);
                why=InvoiceClipboard.CopyChecked("a",delegate(string t) { board="other"; },delegate { return board; },delegate(int ms) { },out attempts);
                Check(why!=null&&attempts==3,"never read back the same, yet copied");
                Check(InvoiceUi.LineCount("a\r\nb\r\n")==2&&InvoiceUi.LineCount("")==0,"lines counted wrongly");
                // Timed out: nothing more is put on the clipboard once the caller has given up.
                bool gaveUp=false;sets=0;
                why=InvoiceClipboard.CopyChecked("a",delegate(string t) { sets++;gaveUp=true; },delegate { return "x"; },delegate(int ms) { },delegate { return gaveUp; },out attempts);
                Check(why!=null&&sets==1,"the copy went on setting the clipboard after it was given up ("+sets+" sets)");
            });
            Case("Invoice live (2.9.15 review): a disabled scroll bar with a leftover range is 'everything fits' unless the screen shows more",()=>{
                var two=new FakeScreen {Total=2,BarEnabled=false,LeftoverRange=true};two.Add(11,"1001");
                var o=Run(two,"",new FakeGuard());
                Check(o.Complete&&o.Read.Lines.Count==2&&two.Codes.Count==0,"2 lines, disabled bar with range 0..100: "+o.Status);
                var full=new FakeScreen {Total=60,BarEnabled=false,LeftoverRange=true};full.Add(11,"1001");
                o=Run(full,"",new FakeGuard());
                Check(!o.Complete&&o.Status.Contains("scroll bar is disabled although")&&full.Codes.Count==0,"25 filled, disabled bar with a range: "+o.Status);
            });
            Case("Invoice live (2.9.15 review): never scrolled while a box in the line list has COSTAR's keyboard",()=>{
                var screen=new FakeScreen {Total=60,BarEnabled=true,Focus=ItemH};screen.Add(11,"1001");var guard=new FakeGuard();
                var o=Run(screen,"",guard);
                Check(!o.Complete&&o.Status.Contains("lines 26+ could not be read: "+InvoiceReading.FocusInLines)&&screen.Codes.Count==0&&guard.Began==0,"focus in the lines: "+o.Status);
                Check(o.LogWhy.Contains("focus_in_lines"),"not coded for the log");
                screen.Focus=GridH;o=Run(screen,"",guard);
                Check(!o.Complete&&screen.Codes.Count==0,"focus on the grid panel itself: "+o.Status);
                screen.Focus=-1;o=Run(screen,"",guard);
                Check(!o.Complete&&o.Status.Contains("keyboard is couldn't be told")&&screen.Codes.Count==0,"focus unknown: "+o.Status);
                // Focus elsewhere on the invoice (not under the line list): read as usual.
                screen.Focus=StateH;o=Run(screen,"",guard);
                Check(o.Complete&&o.Read.Lines.Count==60,"focus outside the lines: "+o.Status);
                // Someone clicks into the lines while it pages: stopped there, not scrolled back under the keyboard.
                var later=new FakeScreen {Total=80,BarEnabled=true};later.Add(11,"1001");
                later.AfterScroll=delegate(FakeScreen f) { f.Focus=ItemH; };
                o=Run(later,"",new FakeGuard());
                Check(!o.Complete&&o.Status.Contains(InvoiceReading.FocusInLines)&&later.Codes.Count==1,"focus moved into the lines: "+o.Status+" ("+later.Codes.Count+" scrolls)");
            });
            Case("Invoice live (2.9.15 review): a window opened over the invoice while paging: its title is shown, never logged",()=>{
                const string secret="JANE MOCKS 0400555111 Notes";
                var screen=new FakeScreen {Total=80,BarEnabled=true};screen.Add(11,"1001");
                screen.AfterScroll=delegate(FakeScreen f) { f.OverIt[11]=new List<string>{secret}; };
                var parts=Parts();
                var fakeParse=parts.Parse;
                // As the real Parse: the paging reason becomes an incomplete reason (InvoicePreview.LogLine logs those).
                parts.Parse=delegate(List<ControlInfo> s,Func<ControlInfo,string> text,string tab,List<InvoicePage> pages,string pagingWhy) {
                    var r=fakeParse(s,text,tab,pages,pagingWhy);if(pagingWhy!=null) InvoiceReader.MarkIncomplete(r,pagingWhy);return r;
                };
                parts.LogLine=InvoicePreview.LogLine;
                var run=new InvoiceRun(null,"",screen,new FakeGuard(),parts);run.Run();var o=run.Outcome;
                Check(o!=null&&o.Read!=null&&!o.Complete,"not incomplete: "+(o==null?"no outcome":o.Status));
                string log=InvoicePreview.LogLine(o.Read)+" "+String.Join(",",o.LogWhy.ToArray());
                Check(log.IndexOf("JANE",StringComparison.OrdinalIgnoreCase)<0&&log.IndexOf("0400555111",StringComparison.Ordinal)<0,"the window's title reached the log line");
                Check(o.Read.Incomplete.All(x=>x.IndexOf("JANE",StringComparison.Ordinal)<0),"the window's title is an incomplete reason");
                Check(o.Read.Problems.Any(x=>x.Contains(secret)),"the window's title isn't shown");
            });
        }
    }
}
